# Interpreter protocol (the only document an interpreter receives)

You will label small square cells on historical satellite and aerial imagery. Your labels are used as an independent human reference, so they must come from what **you see in the imagery**, nothing else.

## 1. What you receive

* A form (CSV) with one row per cell: `anon_id`, `lat`, `lon`, followed by empty columns for each year.
* A KML file showing the cells as yellow 30 m squares.
* This protocol.
* A template for the small metadata file you return (§8).

You must not receive, look up or use anything else. In particular, do not use:

* maps of land-cover or built-up products (e.g. WorldCover, Esri land cover, Dynamic World, GHSL, WSF, GLC);
* any AI or automatic classification tool;
* any other person's labels — and do not discuss cells with the other interpreter.

## 2. Unit and years

* **Unit:** the 30 m square (the yellow polygon). Judge what covers the square, not the surrounding area.
* **Years ("epochs"), in this order:** 2020, then 2000, then 2010, then 1990. Finish all cells for one year before starting the next.

## 3. Imagery rules

1. Use Google Earth Pro with the historical-imagery slider.
2. Use an image dated within **±2 calendar years** of the epoch: for 2000, any image from 1998 to 2002. Prefer the image closest to the epoch; if several are equally close, prefer one from the dry season (January-May).
3. Record the **date of the image you actually used** (`imagery_date`, YYYY-MM-DD) and its source (`imagery_source`):
   * `GEP_historical` for very-high-resolution historical imagery;
   * `Landsat_context` if only a coarse (Landsat-like, about 30 m) image exists for that year;
   * `field` for a field visit;
   * `other_vhr` for another very-high-resolution source.
4. With `Landsat_context`, use at most confidence 2.
5. If no usable image exists within ±2 years, or the cell is hidden by cloud or haze in every available image, set the status to `unavailable` and leave the class empty. **Never guess.** Many cells will legitimately be `unavailable` for 1990, and that is the correct answer.

## 4. Classes (`dominant_class`)

| class | the cell is mainly covered by |
|---|---|
| `built_up` | roofs, paved surfaces, compounds, built structures |
| `agriculture` | field parcels (cropped or fallow, with visible parcel geometry) or orchards |
| `natural_vegetation` | forest, scrub or grassland **without** parcel structure |
| `water` | open water visible on the image date. For reservoirs whose shoreline moves, label what the image shows and mention the season in `notes` |
| `bare_sparse` | rock, quarries, construction sites, bare soil without parcels |
| `other` | a clearly identifiable surface not covered above (describe it in `notes`) |
| `uncertain` | an image exists but does not let you decide |
| `ambiguous` | a genuine mixture, or a definition problem (explain in `notes`) |

* `dominant_share_3bins`: share of the square covered by the dominant class: `>=75`, `50-75` or `<50`.
* `second_class`: the next class present in the square, or `none`.
* `confidence_1to3`: 3 = unambiguous, 2 = likely, 1 = weak.
* `status`: `done` (labelled, including `uncertain`/`ambiguous`), `unavailable` (no usable image), or `skipped` (not looked at).
* `notes`: anything that helps a reviewer understand your decision.

## 5. Rules

* Keep `anon_id`, `lat` and `lon` exactly as given.
* Keep every row, even rows you do not label.
* Do not add, remove or reorder columns.
* Work alone. Do not consult the other interpreter.
* If you see the same place in more than one row, label each row on its own.

## 6. When you are finished

1. Return the filled CSV **unchanged after you hand it in**.
2. Return the metadata file (§8) with it.

## 7. Corrections after you have handed in

Never send an edited copy of a form you have already handed in. If you realise a mistake:

* send a **correction record**: which file, which cells/years, the reason and the date, signed with your pseudonym;
* send the corrected form with it.

The evaluator registers both, and the old and new versions stay on record.

## 8. Metadata file (same name as your CSV, ending in `.meta.json`)

```json
{"interpreter_role": "A", "interpreter_id": "<your pseudonym>", "interpreter_type": "human", "software": "Google Earth Pro <version>",
 "interpretation_start": "YYYY-MM-DD", "interpretation_end": "YYYY-MM-DD", "blind_declaration": true}
```

* `interpreter_role` is `B` if you received a B form.
* `blind_declaration: true` means you saw only the form, the KML and this protocol, and used none of the forbidden sources in §1.
