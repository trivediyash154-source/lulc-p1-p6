# Phase 5 — product cards (Stage 4)

No product is ground truth. Comparisons report **agreement or disagreement between products**, never accuracy.

Provenance comes from the acquisition sidecars (`data/products_ext/*/*.json`, `data/labels/pune_G30/*.json`). Definitions and limitations come from `docs/phase4_existing_products.md`, which takes them from the producers' documentation. Phase-5 analyses: P5-X2 (disagreement descriptors), P5-X3 (G5 envelope), P5-X4 (water).

| product | version / provenance (sidecar) | native resolution → district grid | temporal coverage used | class definition used here | known limitations | role / tier | used in |
|---|---|---|---|---|---|---|---|
| GLC_FCS30D | v2, Zenodo 10.5281/zenodo.15063683 (CC-BY 4.0), tiles E70N20 + E75N20 | 30 m → nearest onto pune_G30 | 1985, 1990, 1995, annual 2000-2022 (26 layers) | LCCS fine classes → L1 crosswalk; impervious = class 190; water = 210; forest = 51-92 | producer accuracy is global (80.88 % basic 10 classes; user guide), not Pune-specific; impervious ≠ built-up land cover; temporal consistency imposed by the producer's change detection | Tier B (independent) | X2, X3, X4, E2 (PIF) |
| GISA 2.0 | Ren, Huang et al. 2025, ISPRS J. 220:354-376; Zenodo 10.5281/zenodo.14848113 | 30 m → nearest | first year of impervious surface, 1972-2021 (producer LUT) | built = first year ≤ epoch | impervious surface, irreversible by construction; early years sparse | Tier B | X3 |
| WSF-Evolution | Marconcini et al. 2021, DLR; tiles 72/16, 72/18, 74/16, 74/18 | ~30 m → nearest | first settled year 1985-2015 | built = first year ≤ epoch (no 2020) | settlement extent (mixed settled cells count as settled); ends in 2015 | Tier B | X2 (settlement context), X3, E2 (PIF) |
| GHSL BUILT-S R2023A | Pesaresi & Politis 2023, JRC | 100 m (Mollweide) → bilinear onto a 90 m grid nested 3×3 in pune_G30 | 1990, 1995, … 2020 | built surface fraction (fraction-weighted area) | modelled epochs; fractional; resampled | Tier B | X2 (urban core), X3 |
| JRC Global Surface Water | Pekel et al. 2016; PC item 70E_20Nv1_3_2020 | 30 m → nearest | occurrence 1984-2021 (statistic, not a yearly map) | water occurrence classes (≥ 75, 25-75, 1-25, 0 %) | surface water only; occurrence is a long-term frequency | Tier B | X4, E2 (water PIF), design strata |
| ESA CCI LC | PC esa-cci-lc | 300 m → nearest onto a 300 m grid aligned with pune_G30 | 1992-2020 | LCCS → L1 | too coarse for 30 m comparison; area trends only | Tier B (coarse) | Phase-4 trajectories only |
| ESA WorldCover | PC esa-worldcover | 10 m → GDAL mode onto pune_G30 | 2020, 2021 (two algorithm versions) | L1 crosswalk (configs/labels.yaml) | silver-label source, so not independent of the Phase-2/3 models; the mode aggregate under-represents fragmented built-up; the 2020→2021 change includes an algorithm change | Tier C | X2, X4, design strata |
| Esri IO LULC | PC io-lulc-annual-v02 | 10 m → GDAL mode | 2017-2023 | L1 crosswalk | silver-label source (2020-21); mode aggregate | Tier C | X2, X4, design strata |
| Copernicus DEM GLO-30 | PC cop-dem-glo-30 (DSM; tiles listed in the sidecar) | 30 m → bilinear | static | elevation, slope | surface model (includes canopy and buildings) | covariate | X2 (slope), design strata |

**Not compared, with the reason:**

| product | reason |
|---|---|
| Dynamic World, GAIA | need an Earth Engine project |
| ALOS FNF, MS building footprints | acquirable, not acquired |
| India decadal LULC 1985/1995/2005 | needs an Earthdata login |
| NRSC LULC 50K | view-only licence |

**Definitions differ, so no single product equals this project's 'built-up' class.** Every comparison states the definition it uses:

* built SURFACE fraction (GHSL);
* impervious surface (GISA, GLC_FCS30D);
* settlement extent (WSF);
* built-area land cover (WorldCover, Esri).
