# Phase 5 — district 30 m data cube: specification, execution routes, validation

Hard dependency of every confirmatory record (P4-C1..C6@v2: "district cube v1 (to be built)") and of Gate G1. Status on 2026-10-02: **key-epoch pilot built** (Landsat dry season
1990, 2000, 2010, 2020 on the full district at 30 m); full cube **not built** (compute + disk beyond this sandbox). Pilot numbers are in §7 (generated from
`results/phase5/cube_pilot/*.json` and `results/phase5/cube_validation/validation_report.json`).

## 1. Grid

`pune_G30` = the native Landsat Collection-2 lattice: EPSG:32643, 30 m, origin x0 = 322065, y1 = 2146035, 6546 × 5624 cells (bounds 322065-518445 E, 1977315-2146035 N),
district mask `data/products_ext/district/district_mask_30m.tif`. Landsat is never resampled on this grid; Sentinel enters by area-weighted aggregation only (configs/grid.yaml).

## 2. Reference implementation (what the window cubes were built with)

The repository engine (`src/pune_eo/compositing/engine.py`) on **Planetary Computer** (anonymous access verified):

| step | rule (configs/landsat.yaml, temporal.yaml) |
|---|---|
| scenes | `data/manifests/landsat_manifest.parquet`, `selected == True`: Collection 2 Level-2, Tier 1, scene cloud ≤ 70 %, ≥ 1 % district overlap, L7 excluded after 2021-12-31; WRS-2 146/047, 146/048, 147/047, 147/048 |
| QA | QA_PIXEL bits fill 0, dilated cloud 1, cirrus 2, cloud 3, shadow 4, snow 5 → not clear; fill → not observed (SLC-off gaps are not observations) |
| decoding | DN valid 7273..43636; DN 1..7272 (negative reflectance) clipped to 0 and counted; DN 0 or > 43636 invalid; ×2.75e-5 − 0.2 |
| harmonisation | `local_pune_g30_v2`: landsat-7 pooled RMA → OLI; landsat-5/4/9 identity (results/harmonization/local_pune_g30_v2.yaml) |
| periods | annual; dry Jan-May; wet Jun-Sep; post-monsoon Oct-Dec (complete only if before the archive cut-off 2026-10-01) |
| reduction | per-pixel median of clear observations; SE of the median from scaled MAD (n ≥ 3) |
| outputs per period | `optical_composite.tif` (6 bands int16 ×1e4, nodata −32768), `uncertainty.tif`, `observation_count.tif`, `valid_mask.tif` (0 outside, 1 no clear obs, 2 one-two, 3 three+), `qa.tif` (n_observed, n_clear, clear_pct, n_clear per platform L4/L5/L7/L8/L9, median DOY of clear obs), `metadata.json` (every source scene with item id, date, platform, cloud, clear pixels; harmonisation; processing; SHA-256 of every file; code/config hashes) |
| missing data | a period without clear observations stays nodata; **nothing is filled or interpolated**; any gap-filled product must be a separately named, separately validated product |

District-size driver: `scripts/phase5_district_cube_pilot.py` (row strips bound the per-observation cache and memory; per-strip reductions are kept until the period is written,
so a crash resumes at strip level) + `src/pune_eo/compositing/lean_writer.py` (the engine writer built a float64 QA stack and was OOM-killed twice at 6 GB on the district grid;
the lean writer writes the same files and metadata schema, verified by `tests/test_lean_writer.py`).

## 3. Required content

| domain | years | periods | used by |
|---|---|---|---|
| Landsat SR + QA + counts | minimum: 1990-1992, 1998-2002, 2008-2012, 2018-2022 (registered features = B3 + 5-year window t−2..t+2 around the gold epochs; 1988-89 are not in the manifest except 6 post-monsoon 1989 scenes → t−2/t−1 of 1990 stay NaN, as in the window cubes); full: 1990-2026 | annual, dry, post_monsoon, wet | P4-C1..C6, G1, G5 |
| feature cube `data/features/cube/pune_G30.zarr` | as above | 23 Landsat features (configs/features.yaml; dry bands + indices, post-monsoon indices, annual NDVI, local SD), 3 quality, 12 terrain | all confirmatory |
| terrain | static | — | `data/products_ext/dem/copdem30_district_30m.tif` exists (Copernicus GLO-30) |
| Sentinel-1 RTC gamma0 (repository engine) | 2020 (minimum), 2015-2026 (full) | seasonal | P4-C6 |
| Sentinel-2 L2A (SCL mask) | 2020 (optional) | seasonal | none registered |

Observation support differs by year and region (P5-X1): pre-2013 post-monsoon support is mostly below the G1 rule, the dry season fails it in 1995, 1997, 2003, 2004 and 2005
(240 m). The cube must therefore carry `n_clear`, per-platform counts and DOY with every period; claims at annual resolution are allowed only where the G1 rule holds.

## 4. Execution routes

| route | status | command | notes |
|---|---|---|---|
| A. repository engine on Planetary Computer (**reference**) | key-epoch pilot run here; full cube needs a larger machine | `python3 scripts/phase5_district_cube_pilot.py --years 1990,1991,... --periods annual,dry,post_monsoon,wet --threads N --min-strips 4` | identical processing to the window cubes; no credentials |
| B. Google Earth Engine | never executed (no credentials) | `python3 scripts/gee/export_district_cube.py --project <GEE_PROJECT> [--dry-run]` | aligned to route A in Phase 5 (§6); remaining differences listed; S1 not exported (GRD ≠ RTC) |

Measured costs (route A, this sandbox, 2 CPUs, 2 threads):

* Landsat stage 1 took 27-30 s **wall-clock** per scene (1990: 486 s for 16 scenes; 2020: 1 939 s for 71). The scene with 91 % district overlap took 90 s single-threaded.
* One district season-year product is ≈ 0.35 GB on disk.

Estimate for the full cube, not a measurement:

* 2 685 selected scenes ≈ 22 wall-clock hours on 2 CPUs (≈ 40-45 CPU-hours). All periods reduce from the same stage-1 cache.
* ≈ 50 GB for 148 Landsat products (37 years × 4 periods).
* The district Sentinel-1 RTC route is untested at this size.

## 5. Post-export / post-build QA (validator)

`python3 src/data/validate_district_cube.py [root] [--layout reference|gee] [--require min|<year:period,...>]` → `results/phase5/cube_validation/*.json`; exit 0 only if every check passes.

| check | failure means |
|---|---|
| opens, every block decodes | corrupted file |
| CRS EPSG:32643, 30 m, transform and shape == pune_G30 | shifted / resampled lattice, wrong extent, missing tiles |
| band names/order, dtype, nodata | wrong product |
| composite valid exactly where n_clear ≥ 1 inside the district (`FILLED`) | missing observations converted into data |
| n_clear ≤ n_observed; per-platform clear counts sum to n_clear; valid_mask consistent | inconsistent QA |
| reflectance within [−0.1, 1] (negatives only from the L7 RMA intercepts; reported) | decoding error |
| platform dates (no L8 before 2013-04-11, L7 after 2021-12-31, L5 after 2011-11-18, L9 before 2021-10-31); source dates inside the product year | wrong scene selection |
| metadata present; every file's SHA-256 equals metadata; sources carry item ids | broken provenance |
| identical file hashes across products | duplicated files |
| source dates inside the product's season months | wrong period assignment |
| required year/period list complete | temporal gaps |
| never-observed share (warning) | footprint gaps |

Static check of the GEE route (no Earth Engine call): `python3 src/data/validate_district_cube.py --static-gee` → `results/phase5/cube_validation/gee_static_check.json`.

## 6. Static review of the original GEE script (Phase 4) — 8 differences found before any execution (7 aligned, Sentinel-1 removed)

| original | reference | fix |
|---|---|---|
| QA bits 1-4 only (no fill bit 0, no snow bit 5) | bits 0-5 | bits read from configs/landsat.yaml |
| no DN valid-range handling; QA_RADSAT == 0 | DN 7273..43636, negatives clipped to 0, saturation by range | aligned; RADSAT dropped |
| no scene-cloud filter | ≤ 70 % | added |
| L7 used after 2021 | excluded after 2021-12-31 | added |
| no Landsat-4 | L4 primary | added |
| no annual period | annual needed by the feature cube (ann_ndvi) | added |
| only n_clear | n_clear, n_observed, per-platform counts | added |
| Sentinel-1 GRD sigma0 | Sentinel-1 RTC gamma0 | S1 removed from the GEE route |

Remaining differences (documented, not fixable without running GEE): no SE-of-median band, no median-DOY band, no 1 % overlap rule, GEE vs numpy median tie handling,
S2 Cloud Score+ vs SCL. Masked pixels are exported as −9999 (`formatOptions.noData`). The validator gives GEE files only geometry, band, fill and range checks (no metadata.json provenance). A GEE-built cube must therefore be validated and, before mixing with window cubes, compared on overlap cells with route A.

## 7. Key-epoch pilot results (generated by scripts/write_phase5_docs.py)

Landsat C2 L2, dry season (Jan-May), full district at 30 m, harmonisation local_pune_g30_v2; all cells of the district (census, no sampling uncertainty). Sources: `results/phase5/cube_pilot/pilot_<year>_dry.json`, `results/phase5/cube_validation/validation_report.json`, P5-X1.

| year | scenes (sensors) | valid (≥ 1 clear obs) | reliable (≥ 3) | n_clear median | never observed | 240 m reliable, same year | validator |
|---|---|---|---|---|---|---|---|
| 1990 | 16 (landsat-5 16) | 1.0000 | 0.958 | 7 | 0.0000 | 0.957 | PASS |
| 2000 | 17 (landsat-5 9, landsat-7 8) | 1.0000 | 0.984 | 4 | 0.0000 | 0.979 | PASS |
| 2010 | 34 (landsat-5 12, landsat-7 22) | 1.0000 | 1.000 | 10 | 0.0000 | 0.996 | PASS (1 warnings) |
| 2020 | 71 (landsat-7 37, landsat-8 34) | 1.0000 | 1.000 | 16 | 0.0000 | 1.000 | PASS |

Reliable share (≥ 3 clear obs) by rainfall region (P5-X1):

| year | wet west ≥ 1200 mm | transition | dry east < 700 mm |
|---|---|---|---|
| 1990 | 1.000 (median 6) | 0.998 (median 7) | 0.857 (median 6) |
| 2000 | 0.944 (median 3) | 0.998 (median 4) | 1.000 (median 6) |
| 2010 | 1.000 (median 10) | 1.000 (median 10) | 1.000 (median 12) |
| 2020 | 1.000 (median 16) | 1.000 (median 16) | 1.000 (median 24) |

Validator warnings are listed per product in `validation_report.json` (e.g. negative values after the L7 RMA, never-observed cells). The pilot is NOT the registered feature cube: post-monsoon, wet, annual composites and the t−2..t+2 years are missing (G1 = PARTIAL).
