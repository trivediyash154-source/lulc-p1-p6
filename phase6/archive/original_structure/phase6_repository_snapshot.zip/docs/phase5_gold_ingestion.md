# Phase 5: Tier-A gold ingestion and audit

**Status on 2026-10-02:** pipeline built and tested; **0 human labels exist**, so Gate G2 = **FAIL** (`results/phase5/gold/gold_audit.json`).
Nothing in this pipeline creates, infers, imputes or edits a label. It only checks, freezes and assembles what human interpreters supply.

* Code: `src/validation/ingest_gold.py` and `src/validation/audit_gold.py`.
* Tests: `tests/test_gold_ingestion.py`, 26 tests on SYNTHETIC TEST DATA only.
* Revision 2 (2026-10-02, after an independent review, still before any gold or T1 label existed): see §8.
* Protocol it enforces: `docs/phase4_gold_protocol.md` and `configs/phase4_evaluation_protocol.yaml` (v2, frozen; unchanged).

## 1. What the interpreters hand back

| file | rule |
|---|---|
| `raw_interpreter_A/<name>.csv` | the blind form `form_interpreter_A.csv`, filled in; all 641 rows kept, even unlabelled ones |
| `raw_interpreter_B/<name>.csv` | `form_interpreter_B.csv` (the 160 double-interpretation points), filled in |
| `<name>.meta.json` next to each form | `interpreter_role` (A/B), `interpreter_id` (a pseudonym), `interpreter_type` = `"human"`, `software`, `interpretation_start`, `interpretation_end` (ISO dates), `blind_declaration` = `true` (the interpreter received only the `blind/` folder) |
| `adjudicated/<name>.csv` | `anon_id, epoch, label_A, label_B, adjudicated_label, rule, reviewer, date` |

Example meta file. Placeholders only; there is no real interpreter yet:

```json
{"interpreter_role": "A", "interpreter_id": "INT-01", "interpreter_type": "human", "software": "Google Earth Pro 7.3.6",
 "interpretation_start": "YYYY-MM-DD", "interpretation_end": "YYYY-MM-DD", "blind_declaration": true}
```

## 2. Workflow

1. Copy the returned files unchanged into `raw_interpreter_A/` and `raw_interpreter_B/`. Add adjudication rows to `adjudicated/` after A and B are complete.
2. **Freeze** the completed pass. This records the SHA-256 of every raw, meta and adjudication file and is immutable:
   `python3 src/validation/ingest_gold.py freeze pass2020_2000 --by <name>`
3. **Ingest**. Exit code 1 and a list of every violation if anything is wrong:
   `python3 src/validation/ingest_gold.py ingest`
4. **Audit and G2**: `python3 src/validation/audit_gold.py` → `results/phase5/gold/gold_audit.json`

The ingested outputs go to `data/labels/gold/phase4/ingested/`:

| file | content |
|---|---|
| `gold_reference_labels.csv` | one row per point and epoch |
| `gold_long_all_interpreters.csv` | every interpreter record |
| `validation_report.json` | all checks |
| `PROVENANCE.json` | hashes of raw files, adjudication and key; code version |

## 3. Checks (each violation is a named error; ingestion refuses to write labels if any error exists)

| group | check | error code |
|---|---|---|
| provenance | raw, meta and adjudication files are frozen and equal the **latest** freeze of their path | `UNFROZEN`, `HASH_MISMATCH`, `STALE_RAW` |
| | a path frozen again with different contents is refused unless an interpreter-signed correction record covers the change | `RAW_REFROZEN` (warning `RAW_CORRECTED` when covered) |
| | sidecar meta complete; `interpreter_type == "human"`; `blind_declaration == true`; no model or product named in the interpreter id or software | `META_MISSING`, `NOT_HUMAN`, `NOT_BLIND` |
| | A and B are different people | `SAME_INTERPRETER` |
| | a **declared** imagery source naming a product or model (WorldCover, Esri, Dynamic World, GHSL, WSF, GISA, GLC, CCI, OSM, "model", "AI", Claude, GPT, "silver", "synthetic", …) is rejected. Software cannot detect undeclared use; that is excluded by the blind process (interpreters get only form + KML) and the signed declaration | `FORBIDDEN_SOURCE` |
| identity | every point ID is in the design key; no duplicate (point, epoch) | `UNKNOWN_ID`, `DUPLICATE` |
| | A covers all 641 points; B covers exactly the 160 double points | `MISSING_POINTS`, `NOT_IN_SUBSET` |
| geometry / leakage | lat/lon equal the design (tolerance 1e-6°) | `COORDINATES_CHANGED` |
| | cell inside the district and inside a validation block | `OUTSIDE_DISTRICT`, `OUTSIDE_VALIDATION_BLOCK` |
| | cell ≥ 2 km from training-eligible cells; cell > 2 km from the Phase-3 windows | `TOO_CLOSE_TO_TRAINING`, `INSIDE_PHASE3_WINDOWS` |
| values | status ∈ {done, unavailable, skipped, empty}; class, share bin, second class and confidence within their vocabularies | `STATUS`, `CLASS`, `SHARE`, `SECOND_CLASS`, `CONFIDENCE` |
| | `unavailable` class ⇔ `unavailable` status; a done record needs a class, a source and an ISO imagery date | `UNAVAILABLE_STATUS`, `DONE_NO_CLASS`, `SOURCE_MISSING`, `IMAGERY_DATE` |
| | imagery date in calendar years epoch−2 … epoch+2 (exact year comparison), not after the interpretation end date, not before 1972 | `IMAGERY_DATE_WINDOW`, `IMAGERY_DATE_FUTURE` |
| T1 only (`kind=training`) | cell training-eligible, outside validation blocks, ≥ 2 km from every gold point | `TRAINING_NOT_ELIGIBLE`, `TRAINING_IN_VALIDATION_BLOCK`, `TOO_CLOSE_TO_GOLD` |
| adjudication | every A/B disagreement where **at least one** interpreter gave a definite class (including definite vs uncertain/unavailable) has exactly one adjudication row | `ADJUDICATION_MISSING`, `ADJ_DUPLICATE` |
| | the label_A / label_B quoted there equal the raw forms (no silent overwrite) | `ADJ_OVERWRITE` |
| | reviewer is not A or B unless the rule is `joint_review`; date is ISO | `ADJ_REVIEWER`, `ADJ_DATE` |

Spatial checks need the design rasters. Production `ingest()` loads them and raises if they are missing. Only the unit tests may run without them, and that is recorded as the warning `SPATIAL_NOT_CHECKED`.

## 4. How the reference label is assembled

| case | reference label | `label_source` |
|---|---|---|
| single-interpreted point | A | `A` |
| double point, A = B | A | `A=B` |
| double point, A ≠ B, both definite | adjudicated label (required) | `adjudicated` |
| double point, one definite and one abstention/unavailable | adjudicated label (required) | `adjudicated` |
| double point, both abstained differently | `uncertain` (an abstention, never a class) | `both_abstained_differently` |
| B labelled, A not | empty (A is the reference interpreter) | `B_only_A_not_labelled` |
| disagreement needing adjudication but without it | empty, so it blocks G2; no tier | `unadjudicated` |

* `uncertain`, `ambiguous` and `unavailable` are abstentions (protocol `abstention_codes`). They are kept, counted and excluded from the accuracy set.
* `bare_sparse` and `other` stay in the accuracy set and count as map errors (protocol `reference_outside_legend`).

## 5. Gate G2: operational definitions fixed before any gold exists

The protocol text is checked verbatim by `audit_gold._check_protocol_text()`; any change to it stops the audit.

| criterion (2020 **and** 2000) | definition |
|---|---|
| labelled ≥ 80 % | share of the 641 points whose resolved reference is a **definite class** or `unavailable` (revision 2: `uncertain`/`ambiguous` are reported as abstentions but do not count, so a pass of mostly `uncertain` cannot meet G2) |
| double ≥ 20 % | share of the 641 points with a `done`/`unavailable` record from both A and B |
| κ ≥ 0.6 | **primary:** Cohen's κ, A vs B, over double points where both gave a definite class, computed only with ≥ 30 such points (otherwise NOT MEASURED → fail). **Secondary (reported, not gating):** κ and Krippendorff's α with the abstention codes as extra categories |
| adjudication logged | no `unadjudicated` point-epoch; adjudication rows validated as in §3 |

These definitions resolve ambiguities in the one-line G2 text: per-epoch κ, and how abstentions are handled. They were written on 2026-10-02 (revision 2 the same day, after review), before any interpretation, and they do not change the frozen protocol file.

## 6. Leakage audit for training labels

`audit_gold.audit_training_labels(df, spatial, key, grid)` checks any training-label table with `x_utm` and `y_utm`. A table passes only if every label is:

* not in a validation block;
* on a training-eligible cell;
* at least 2 km from every gold point.

It was applied to the T1 design (passed: minimum 2 220 m to gold). Returned T1 labels are ingested with `--kind training` and audited with `audit_gold.py --t1`; the P4-C1@v2 checklist requires that audit to pass.

## 7. Current result

`gold_audit.json`: ingest **FAIL** (`NO_INTERPRETER_A`: there is no Tier-A gold to ingest) and G2 **FAIL**, with reason "no Tier-A gold has been ingested (0 labels)". This is the expected and correct state. No substitute labels were produced.

## 8. Revision log

| rev | date | change | why |
|---|---|---|---|
| 1 | 2026-10-02 | pipeline built | Phase 5 Stage 2 |
| 2 | 2026-10-02 (no gold or T1 label existed) | (a) G2 'labelled' counts only definite classes + `unavailable`; (b) κ needs ≥ 30 definite double points; (c) definite-vs-abstention mismatches need adjudication; (d) re-freeze of a changed raw file needs an interpreter-signed correction record; (e) exact calendar-year date window (rev 1 accepted 1 Jan of epoch+3); (f) tier 'A' only for resolved labels; (g) T1 training mode with training-leakage rules; (h) wording: declared sources only | independent review of Phase 5 (no HIGH findings; these were MEDIUM/LOW) |
