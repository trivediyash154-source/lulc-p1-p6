# Phase 6 — district Sentinel-1 for P4-C6@v2: processing definition and expected schema

**Status:** driver and writer implemented. The writer is tested equal to the engine on synthetic data; the strip driver has no automated test (it needs Planetary Computer access) and has not been run at district scale. The district S1 2020 product is **not built** here (compute boundary, `docs/phase6_D3_compute_decision.md`). The processing is exactly the repository's RTC route used for the window cubes; no visually similar substitute (GEE GRD, other providers) is allowed.

## 1. Processing (from `configs/sentinel1.yaml`, `src/pune_eo/compositing/observations.py`, `engine.py`, `preprocessing/sar.py`, `lean_writer.py`)

| aspect | definition |
|---|---|
| product | Planetary Computer `sentinel-1-rtc`: gamma0, **radiometrically terrain corrected**, linear power, 10 m posting |
| mode / polarisation | IW; VV and VH |
| orbit handling | one orbit direction per year (`selection.geometry: dominant_orbit_state`); 2020: all 107 selected scenes are **descending**. Relative orbit and orbit state are recorded per source in `metadata.json` |
| incidence angle | no normalisation beyond RTC (gamma0 terrain flattening). Residual incidence-angle dependence across the swath is not modelled — a documented limitation |
| terrain correction | RTC by the provider (radiometric terrain flattening and geocoding) |
| speckle | no explicit filter. Area-average of linear gamma0 from 10 m to the 30 m Landsat lattice (GDAL `average`, ≈ 3×3 looks), then temporal compositing |
| invalid values | values ≤ 0, nodata (−32768) or non-finite are missing (`sar.clean_linear`); never filled |
| compositing | per period: mean in **linear power → dB**; median and temporal standard deviation in dB; count of valid observations |
| periods | annual; dry (Jan-May); wet (Jun-Sep); post-monsoon (Oct-Dec); 12 months |
| spatial alignment | pune_G30 (EPSG:32643, 30 m, origin 322065 / 2146035), the native Landsat lattice; no interpolation |
| missingness | per-cell `observation_count`, `valid_mask` and `qa` (n_observed, n_clear, per-platform counts S1A/B/C/D, median DOY); cells with no valid observation stay nodata (−9999) |
| driver | `scripts/phase6_district_s1.py` (row strips; ≈ 1 GB of intermediate disk per period → ≈ 16 GB transient) |
| writer | `lean_writer.write_products_from_strips('sentinel1', …)`; identical output to `engine.write_products` (`tests/test_lean_writer.py::test_lean_writer_equals_engine_sentinel1`) |

## 2. Expected input schema for P4-C6@v2

P4-C6@v2 compares "C1 vs C4 sets". The treatment arm C4 = B3 optical + S1F (6 features) + terrain (12).

| S1F feature | definition (`feature_engineering/cube.py::sentinel_year`) | needs |
|---|---|---|
| `s1_vv_dry` | dry-season VV median (dB) | `seasonal/dry/backscatter_median_db.tif` |
| `s1_vh_dry` | dry-season VH median (dB) | same |
| `s1_vh_wet` | wet-season VH median (dB) | `seasonal/wet/backscatter_median_db.tif` |
| `s1_ratio` | dry VH − VV (dB) | dry |
| `s1_vv_min` | minimum of monthly VV medians | ≥ 6 monthly products |
| `s1_vh_sd` | standard deviation of monthly VH medians | ≥ 6 monthly products |

Reference: all three window cubes carry this schema for 2020, with full S1F coverage inside the district. `validate_feature_cube.py` requires S1 year 2020 to be present and every S1F feature to be finite on ≥ 90 % of district cells.
