# Provisional AI visual interpretation — instructions (Tier C, NEVER gold)

You are a blind visual interpreter of Sentinel-2 10 m image sheets over Pune District, India (2021).
Read `docs/gold_sample_protocol.md` sections 3-4 first (classes, unit, decision rules). Then follow this file.

## Blindness rules (hard)
- Open ONLY: `docs/gold_sample_protocol.md`, this file, and the sheet PNGs you are assigned in
  `data/labels/gold/blind/sheets_s2_2021/`. Do NOT open anything under `data/labels/gold/_key/`, any `gold_sample*`, `gold_form.csv`,
  any results/predictions/maps/labels, other interpreters' part files, or `results/gold/provisional_ai_pass*.csv`.
- Do not use coordinates, window names, or any other data. Judge only from the pixels in the sheet.

## Sheet layout
Each sheet has up to 5 rows; the bold label at the left of each row is the anonymous ID (e.g. G-0123). Columns:
1. dry-season 2021 true colour, 1.2 km context (yellow = 30 m cell, cyan dotted = 330 m box)
2. dry true colour, zoomed 330 m (yellow 3x3-pixel square = the 30 m cell to label)
3. dry NIR-R-G false colour, 330 m (vegetation = red)
4. post-monsoon (Oct-Dec) NIR-R-G false colour, 330 m
Black areas = no clear Sentinel-2 observation.

## What to label
The class covering the largest share of the 30 m yellow cell, 2021 state:
`built_up`, `agriculture`, `natural_vegetation`, `water`, `bare_sparse`, `other`,
or abstain with `uncertain` (evidence insufficient, e.g. no-data/black, cloud) or `ambiguous` (genuine mix/boundary/class-definition problem).
DO NOT FORCE A CLASS. Abstaining is a correct answer when the evidence does not decide.
Confidence: 3 unambiguous, 2 likely, 1 weak. Abstentions get confidence 1.
ambiguity_flag: True for every `uncertain`/`ambiguous`, and also True for a class label where a specific competing class is plausible
(name it in ambiguity_reason, e.g. "fallow vs scrub"). Reservoir drawdown margins: label the dry-season state, flag True.
Orchards/tree crops in field geometry -> agriculture (flag if unsure vs natural woody vegetation). Urban tree canopy inside built fabric -> say so.

## Output
Write a CSV (path given in your task) with EXACTLY this header and one row per ID, in sheet order:
`anon_id,reference_class_2021,confidence_1to3,ambiguity_flag,ambiguity_reason,notes`
- ambiguity_flag is `True`/`False`; ambiguity_reason empty when False; notes = short evidence (no commas — use semicolons).
- Examples (style only):
  `G-0001,ambiguous,1,True,fallow field vs grassland/scrub,patchy dry-brown cell; weak post-monsoon greening; no parcel geometry at 330 m`
  `G-0004,agriculture,3,False,,inside a field parcel; seasonal contrast`
  `G-0011,water,3,False,,reservoir`
  `G-0092,uncertain,1,True,S2 no-data boundary,cell at edge of clear-observation coverage`
Append rows to the CSV after every sheet (so partial progress is kept). Read the ID labels from the image itself; the last sheet may have fewer than 5 rows.
