# Pune EO Data QA Report — sentinel2_on_G30 — grid `pune_G30_khadakwasla_mutha`

Generated automatically by `pune-eo qa`. Thresholds: `configs/qa.yaml`. Every product's full QA record is
also written into its own `metadata.json` (`qa` block).

## Summary

| period   |   WARNING |
|:---------|----------:|
| dry      |         1 |

## Per-year records

### 2024

**dry** — Status: **WARNING**
- Sensors: sentinel-2a,sentinel-2b · scenes: 29
- Valid district coverage: 100.0% · reliable (≥3 clear obs): 100.0%
- Median clear observations per pixel: 26 · mean clear fraction of observations: 92.3%
- Permanent-water negative control (share of JRC permanent-water cells with MNDWI>0): 100%
- Residual-cloud check (valid pixels with blue SR > 0.15): 1.56%
- Reasons: possible residual cloud/haze: 1.6% of valid pixels transiently bright (blue SR > 0.15)
