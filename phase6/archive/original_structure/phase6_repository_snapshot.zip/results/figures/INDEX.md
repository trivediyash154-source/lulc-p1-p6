# Figure index (all computed from real products in this repository)

| Figure | What it shows | Source data |
|---|---|---|
| `satellite_availability_timeline.png` | Mission history + selected Landsat scenes per year + Sentinel-1/2 acquisition dates over the district | manifests |
| `observation_depth_pune_G240.png` | Share of district with ≥3 clear Landsat observations, every year × season, and automated QA status | `results/qa/landsat/pune_G240/qa_summary.csv` |
| `data_depth_pune_G240_dry.png` | Per pixel: in how many of 37 years the dry-season composite is statistically supported (WRS-2 footprints visible) | `observation_count.tif` × 37 |
| `contact_sheet_landsat_pune_G240_dry.png` / `_wet.png` | Every year 1990–2026, harmonised median composites with QA badge (visual QA only) | district G240 products |
| `map_pune_G240_1990_dry.png`, `map_pune_G240_2025_dry.png` | Publication-template map (graticule, scale, north arrow, method, uncertainty, QA, provenance) | single products |
| `district_dry_season_series_pune_G240.png` | Dry-season NDVI distribution, open-water area, and preceding-monsoon rainfall, 1990–2026; low-support years marked; exploratory Spearman ρ | `results/timeline/district_dry_season_series_pune_G240.csv` |
| `harmonization_evidence.png` | Held-out NDVI bias and band RMSD for each sensor pair and transform | `results/harmonization/harmonization_report.json` |
| `harmonization_stability.png` | Is the correction transferable across resolution (240/30 m) and landscape (peri-urban / irrigated)? | `results/harmonization/harmonization_stability.csv` |
| `aoi_water_pune_G30_khadakwasla_mutha.png` | 30 m Khadakwasla→Mutha: dry-season water frequency 1990–2026 and annual water area | G30 window products |
| `contact_sheet_landsat_pune_G30_khadakwasla_mutha_dry.png`, `data_depth_pune_G30_khadakwasla_mutha_dry.png` | Same at 30 m for the window | G30 window products |
| `s2_monthly_pune_G240_2024.png` | Sentinel-2 every month 2024: NDVI maps + per-stratum monthly NDVI (monsoon blackout visible) | S2 monthly products |
| `s1_monthly_pune_G240_2024.png` | Sentinel-1 every month 2024: VV maps + per-stratum backscatter; acquisition gap Jun–Aug | S1 monthly products |
| `sentinel1_monthly_availability_pune_G240.png`, `sentinel2_monthly_availability_pune_G240.png` | Month × year coverage matrices for the Sentinel era | monthly product metadata |
| `s2_field_phenology_pune_G10_baramati_agri_2024.png` | 10 m field-scale monthly NDVI around Baramati + exploratory seasonal-amplitude feature | G10 window products |

Every map footer states sensor, period, method, grid and data source. Visual composites are labelled "visual QA only":
quantitative claims come from the tables named in the right-hand column.
