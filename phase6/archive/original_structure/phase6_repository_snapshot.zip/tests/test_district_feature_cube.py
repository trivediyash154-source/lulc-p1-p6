"""District feature-cube builder (strip-wise) must reproduce the window builder; the validator must catch missing years. SYNTHETIC TEST DATA — NOT RESEARCH DATA."""
import importlib.util, json, shutil, uuid
from pathlib import Path
import numpy as np, pandas as pd, rasterio, xarray as xr
from rasterio.transform import Affine
from pune_eo import config
from pune_eo.grid import Grid
from pune_eo.compositing import engine as E
from pune_eo.compositing.periods import Period
from pune_eo.feature_engineering import cube as C
ROOT = Path(__file__).resolve().parents[1]
__import__("sys").path.insert(0, str(ROOT / "src"))
def _mod(path, name):
    spec = importlib.util.spec_from_file_location(name, ROOT / path); m = importlib.util.module_from_spec(spec); spec.loader.exec_module(m); return m

def _write_synthetic(g, years, inside, rng):
    cut = pd.Timestamp("2026-10-01", tz="UTC"); H, W = g.shape
    for y in years:
        for kind, name, months in (("season", "dry", (1, 2, 3, 4, 5)), ("season", "post_monsoon", (10, 11, 12)), ("annual", "annual", tuple(range(1, 13)))):
            n = rng.integers(1, 9, (H, W)).astype(np.uint16)
            res = {"n_observed": n, "n_clear": n, "per_platform": np.stack([np.zeros_like(n), n, np.zeros_like(n), np.zeros_like(n), np.zeros_like(n)]).astype(np.uint16),
                   "doy_median": np.full((H, W), 50.0, np.float32), "composite": rng.uniform(0.02, 0.45, (6, H, W)).astype(np.float32), "uncertainty": rng.uniform(0, 0.01, (6, H, W)).astype(np.float32)}
            P = Period(y, kind, name, months)
            E.write_products("landsat", P, g, res, inside, [{"item_id": f"SYN{y}{name}", "platform": "landsat-5", "date": f"{y}-{months[0]:02d}-10", "doy": 10, "cloud_cover": 1.0, "tile_id": "t", "n_clear_px": 1}],
                             config.path("data/composites", g.id, str(y), "landsat", P.relpath), cut, "local_pune_g30_v2", {"processing": {}})
    for rel, months in [("seasonal/dry", (1, 2, 3, 4, 5)), ("seasonal/wet", (6, 7, 8, 9))] + [(f"monthly/2020-{m:02d}", (m,)) for m in range(1, 13)]:
        n = rng.integers(2, 6, (H, W)).astype(np.uint16); m = rng.uniform(-22, -6, (2, H, W)).astype(np.float32)
        res = {"n_observed": n, "n_clear": n, "per_platform": np.stack([n, 0 * n, 0 * n, 0 * n]).astype(np.uint16), "doy_median": np.full((H, W), 50.0, np.float32), "mean_db": m, "median_db": m + 0.1, "std_db": np.ones((2, H, W), np.float32)}
        kind = "month" if rel.startswith("monthly") else "season"; name = rel.split("/")[1]
        E.write_products("sentinel1", Period(2020, kind, name, months), g, res, inside, [{"item_id": "SYNS1", "platform": "sentinel-1a", "date": f"2020-{months[0]:02d}-05", "doy": 5, "cloud_cover": None, "tile_id": "s", "n_clear_px": 1}],
                         config.path("data/composites", g.id, "2020", "sentinel1", rel), cut, None, {"processing": {}})
    td = config.path("data/features/terrain", g.id); td.mkdir(parents=True, exist_ok=True)
    t = rng.uniform(0, 100, (12, H, W)).astype(np.float32); t[:, ~inside] = np.nan
    with rasterio.open(td / "terrain.tif", "w", driver="GTiff", width=W, height=H, count=12, dtype="float32", crs=g.crs, transform=Affine(*g.transform[:6]) if not hasattr(g.transform, "a") else g.transform, nodata=np.nan) as d:
        d.write(t); d.descriptions = tuple(C.TERRAIN.values())

def test_district_builder_equals_window_builder_and_validator():
    gid = "synthetic_G30_fc_" + uuid.uuid4().hex[:6]; H, W = 40, 28; g = Grid(gid, "EPSG:32643", 30.0, 300015.0, 2000015.0, W, H, 15.0)
    inside = np.ones((H, W), bool); inside[:4, :5] = False; years = [2018, 2019, 2020]; rng = np.random.default_rng(11)
    out2 = config.path("data/features/cube", f"{gid}_district.zarr")
    try:
        _write_synthetic(g, years, inside, rng)
        C.build_cube(g, years=years, s_years=[2020])
        ref = xr.open_zarr(config.path("data/features/cube", f"{gid}.zarr")).load()
        B = _mod("scripts/phase6_build_feature_cube.py", "fcb"); B.build(g, years, [2020], out2, strip=16, mask=inside, chunk=8, log=lambda *a: None)
        new = xr.open_zarr(out2).load()
        for v in ("landsat", "quality", "terrain", "sentinel"):
            assert np.allclose(ref[v].values, new[v].values, atol=1e-6, equal_nan=True), v
        V = _mod("src/data/validate_feature_cube.py", "vfc")
        grid = {"crs": g.crs, "res": 30.0, "x0": g.x0, "y1": g.y1, "width": W, "height": H}
        # window-builder values exist outside 'inside' (synthetic composites are not masked there by the builder): validate only coverage-type checks on inside
        r = V.validate(out2, grid=grid, mask=np.ones((H, W), bool), required_years=years, syears=(2020,))
        assert r["checks"]["required_years_present"]["ok"] and r["checks"]["feature_names"]["ok"] and r["checks"]["grid_30m_lattice"]["ok"] and r["checks"]["sentinel_years_present"]["ok"]
        assert r["checks"]["provenance_sidecar_and_source_hashes"]["ok"]
        r2 = V.validate(out2, grid=grid, mask=np.ones((H, W), bool), required_years=years + [2021], syears=(2020,))
        assert not r2["checks"]["required_years_present"]["ok"] and not r2["ok"]
    finally:
        for p in (config.path("data/composites", gid), config.path("data/features/terrain", gid), config.path("data/features/cube", f"{gid}.zarr"), out2):
            shutil.rmtree(p, ignore_errors=True)
        for p in (config.path("data/features/cube", f"{gid}.json"), out2.with_suffix(".json")):
            if p.exists(): p.unlink()

def test_c2_treatment_cube_fallback_and_report_binding():
    """SYNTHETIC TEST DATA — NOT RESEARCH DATA. Treatment family (landsat_c2tm): years without treatment products fall back to the standard family ONLY when
    the standard products contain no TM observation; the feature-cube report records path, family and sidecar SHA; the cube validator checks the transform."""
    import pytest
    gid = "synthetic_G30_c2_" + uuid.uuid4().hex[:6]; H, W = 24, 20; g = Grid(gid, "EPSG:32643", 30.0, 300015.0, 2000015.0, W, H, 15.0)
    inside = np.ones((H, W), bool); rng = np.random.default_rng(5); out = config.path("data/features/cube", f"{gid}_landsat_c2tm.zarr")
    B = _mod("scripts/phase6_build_feature_cube.py", "fcb2"); V = _mod("src/data/validate_feature_cube.py", "vfc2"); DV = __import__("importlib").import_module("data.validate_district_cube")
    try:
        _write_synthetic(g, [2010, 2011], inside, rng)                                   # synthetic sources are landsat-5 (TM)
        base = config.path("data/composites", gid)
        shutil.copytree(base / "2010/landsat", base / "2010/landsat_c2tm")               # treatment product exists for 2010 only
        assert B.family_for_year(g, 2010, "landsat_c2tm", "landsat") == "landsat_c2tm"
        with pytest.raises(RuntimeError): B.family_for_year(g, 2011, "landsat_c2tm", "landsat")   # TM present, treatment missing -> error, never a silent substitution
        for rel in B.FEATURE_RELS:                                                         # make 2011 a year without TM: zero landsat-4/5 clear observations
            m = base / "2011/landsat" / rel / "metadata.json"; d = json.loads(m.read_text())
            d["statistics"]["sensor_contribution_clear_px"] = {"landsat-4": 0, "landsat-5": 0, "landsat-7": 5, "landsat-8": 0, "landsat-9": 0}; m.write_text(json.dumps(d))
        assert B.family_for_year(g, 2011, "landsat_c2tm", "landsat") == "landsat"
        meta = B.build(g, [2010, 2011], [2020], out, strip=8, family="landsat_c2tm", mask=inside, chunk=8, log=lambda *a: None, fallback_family="landsat")
        assert meta["family_per_year"] == {2010: "landsat_c2tm", 2011: "landsat"}
        grid = {"crs": g.crs, "res": 30.0, "x0": g.x0, "y1": g.y1, "width": W, "height": H}
        r = V.validate(out, grid=grid, mask=inside, required_years=[2010, 2011], family="landsat_c2tm", family_years={2010: "landsat_c2tm"})
        assert r["checks"]["landsat_family"]["ok"] and r["checks"]["family_per_year"]["ok"] and r["path"] == str(out.resolve()) and len(r["sidecar_sha256"]) == 64
        r2 = V.validate(out, grid=grid, mask=inside, required_years=[2010, 2011], family="landsat_c2tm", family_years={2011: "landsat_c2tm"})
        assert not r2["checks"]["family_per_year"]["ok"]
        rv = DV.validate(base, grid=DV.GridSpec(g.crs, 30.0, g.x0, g.y1, W, H), district=inside, family="landsat_c2tm", expect_harmonization="c2_tm_pif_v1")
        assert rv["n_products"] == 3 and rv["family"] == "landsat_c2tm" and all(any("HARMONIZATION" in e for e in p["errors"]) for p in rv["products"]) and not rv["ok"]   # written with local_pune_g30_v2
    finally:
        for p in (config.path("data/composites", gid), config.path("data/features/terrain", gid), out): shutil.rmtree(p, ignore_errors=True)
        if out.with_suffix(".json").exists(): out.with_suffix(".json").unlink()
