"""Phase-5 guards on the REAL repository state (read-only): confirmatory runs must be refused while prerequisites are missing; protocol v2 must be unchanged."""
import importlib.util, sys
from pathlib import Path
import pytest
ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "src"))
from pune_eo.evaluation4 import protocol as P4

def _checklists():
    spec = importlib.util.spec_from_file_location("prerun", ROOT / "scripts/phase5_prerun_checklists.py"); m = importlib.util.module_from_spec(spec); spec.loader.exec_module(m); return m

def test_protocol_v2_unchanged():
    fz = P4.load_protocol()["frozen"]
    assert P4.code_hash() == fz["code_sha256"] == "3bb40f9c982d601db88f75913f7d00acb4944136a3f9771079b9413ec31a14ab"
    assert P4.protocol_hash() == fz["protocol_sha256"]

@pytest.mark.parametrize("eid", ["P4-C1@v2", "P4-C2@v2", "P4-C3@v2", "P4-C4@v2", "P4-C5@v2", "P4-C6@v2"])
def test_confirmatory_refused_without_gold(eid):
    if not (ROOT / "results/phase5/entry/entry_checks.json").exists(): pytest.skip("entry checks not generated")
    gold_raw = list((ROOT / "data/labels/gold/phase4/raw_interpreter_A").glob("*.csv"))
    if gold_raw: pytest.skip("gold present: guard outcome depends on the full checklist")
    with pytest.raises(RuntimeError): _checklists().assert_runnable(eid)
    assert P4.load(eid)["status"] == "PENDING"
