"""Phase 6 guards (no research data is created; temporary files are SYNTHETIC TEST DATA — NOT RESEARCH DATA)."""
import hashlib, importlib.util, json, subprocess, sys
from pathlib import Path
import pytest
ROOT = Path(__file__).resolve().parents[1]

def _checklist():
    spec = importlib.util.spec_from_file_location("chk6", ROOT / "scripts/phase5_prerun_checklists.py"); m = importlib.util.module_from_spec(spec); spec.loader.exec_module(m); return m

def test_pilot_refuses_treatment_transform_into_standard_family():
    r = subprocess.run([sys.executable, "scripts/phase5_district_cube_pilot.py", "--years", "1990", "--transform", "c2_tm_pif_v1"], cwd=ROOT, capture_output=True, text=True, timeout=120)
    assert r.returncode != 0 and "separate --out-family" in (r.stderr + r.stdout)

def test_t1_design_is_not_overwritten():
    if not (ROOT / "data/labels/training/phase6_T1v2/_key/T1_key.csv").exists(): pytest.skip("T1 v2 key absent")
    before = hashlib.sha256((ROOT / "data/labels/training/phase6_T1v2/_key/T1_key.csv").read_bytes()).hexdigest()
    r = subprocess.run([sys.executable, "scripts/phase6_training_sample_T1v2.py"], cwd=ROOT, capture_output=True, text=True, timeout=120)
    assert r.returncode != 0 and "not overwritten" in (r.stderr + r.stdout)
    assert hashlib.sha256((ROOT / "data/labels/training/phase6_T1v2/_key/T1_key.csv").read_bytes()).hexdigest() == before

def test_countersignature_must_match_addendum(tmp_path, monkeypatch):
    C = _checklist(); add = "experiments/registry4/addenda/P4-C1_at_v2_addendum_1.json"
    p = tmp_path / "cs.json"; monkeypatch.setattr(C, "COUNTERSIGN", str(p)); monkeypatch.setattr(C.config, "path", lambda *a: Path(*a) if Path(a[0]).is_absolute() else ROOT.joinpath(*a))
    assert not C.countersigned("D1", add)[0]
    good = {"researcher_name": "SYNTHETIC TEST", "signed_utc": "2026-10-02T00:00:00Z", "decisions": {"D1": {"verdict_accepted": True, "addendum_sha256": C.SHA(add)}}}
    p.write_text(json.dumps(good)); assert C.countersigned("D1", add)[0]
    good["decisions"]["D1"]["addendum_sha256"] = "0" * 64; p.write_text(json.dumps(good)); assert not C.countersigned("D1", add)[0]

def test_all_records_do_not_run_without_prerequisites():
    C = _checklist()
    if (C.J("results/phase5/gold/gold_audit.json") or {}).get("ingest") == "PASS": pytest.skip("gold ingested: this guard applies only while Tier-A gold is absent")
    for e in C.EPOCHS: assert not C.checklist(e)["run_allowed"]
