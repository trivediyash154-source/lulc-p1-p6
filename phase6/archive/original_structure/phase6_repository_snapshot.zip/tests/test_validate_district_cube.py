"""District-cube validator tests. Every raster here is SYNTHETIC TEST DATA — NOT RESEARCH DATA (10 x 10 synthetic grid, temp dirs only)."""
import hashlib, json, sys
from pathlib import Path
import numpy as np, pytest, rasterio
from rasterio.transform import Affine
sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "src"))
from data import validate_district_cube as V

G = V.GridSpec("EPSG:32643", 30.0, 0.0, 300.0, 10, 10)
PL = ["landsat-4", "landsat-5", "landsat-7", "landsat-8", "landsat-9"]

def w(p, arr, dtype, nodata=None, desc=None, transform=None, crs="EPSG:32643"):
    arr = np.asarray(arr)
    if arr.ndim == 2: arr = arr[None]
    with rasterio.open(p, "w", driver="GTiff", width=arr.shape[2], height=arr.shape[1], count=arr.shape[0], dtype=dtype, crs=crs,
                       transform=transform or Affine(30, 0, 0, 0, -30, 300), nodata=nodata) as d:
        d.write(arr.astype(dtype))
        if desc: d.descriptions = tuple(desc)

def make_product(d: Path, year=2020, period="dry", n_clear=None, filled=False, platform_sources=None, mutate=None):
    d.mkdir(parents=True); inside = np.ones((10, 10), bool); inside[0, 0] = False
    nc = np.full((10, 10), 4, np.uint16) if n_clear is None else n_clear.astype(np.uint16); nc[~inside] = 0
    nobs = nc + 1; nobs[~inside] = 0
    comp = np.full((6, 10, 10), 1500, np.int16); comp[:, nc == 0] = -32768
    if filled: comp[:, 5, 5] = 1200; nc[5, 5] = 0
    per = np.zeros((5, 10, 10), np.uint16); per[3] = nc
    qa = np.concatenate([nobs[None], nc[None], np.full((1, 10, 10), 80, np.uint16), per, np.full((1, 10, 10), 60, np.uint16)])
    vm = np.where(nc >= 3, 3, np.where(nc >= 1, 2, 1)).astype(np.uint8); vm[~inside] = 0
    if mutate: comp, qa, vm, nc = mutate(comp, qa, vm, nc)
    w(d / "optical_composite.tif", comp, "int16", -32768, V.BANDS); w(d / "uncertainty.tif", np.full((6, 10, 10), 10), "int16", -32768)
    w(d / "observation_count.tif", nc, "uint16"); w(d / "valid_mask.tif", vm, "uint8")
    w(d / "qa.tif", qa, "uint16", None, ["n_observed", "n_clear", "clear_pct"] + [f"n_clear_{p}" for p in PL] + ["doy_median_clear"])
    files = {k: {"path": str(d / f"{k}.tif"), "sha256": hashlib.sha256((d / f"{k}.tif").read_bytes()).hexdigest()} for k in ("optical_composite", "uncertainty", "observation_count", "valid_mask", "qa")}
    srcs = platform_sources or [{"item_id": f"SYN_{year}0115", "platform": "landsat-8", "date": f"{year}-01-15"}]
    meta = {"temporal": {"year": year, "period": period, "complete": True}, "sources": srcs, "sensors": {"landsat-8": 1}, "processing": {"harmonization": "local_pune_g30_v2"}, "files": files,
            "note": "SYNTHETIC TEST DATA — NOT RESEARCH DATA"}
    (d / "metadata.json").write_text(json.dumps(meta)); return inside

def run(tmp, **kw):
    inside = make_product(tmp / "2020/landsat/seasonal/dry", **kw)
    return V.validate(tmp, "reference", grid=G, district=inside)

def errs(r): return " ".join(e for p in r["products"] for e in p["errors"])

def test_valid_product_passes(tmp_path):
    r = run(tmp_path); assert r["ok"], errs(r)
    assert r["products"][0]["stats"]["valid_fraction"] == 1.0

def test_filled_missing_observation_is_caught(tmp_path):
    r = run(tmp_path, filled=True); assert not r["ok"] and "FILLED" in errs(r)

def test_platform_outside_operating_period(tmp_path):
    r = run(tmp_path / "a", platform_sources=[{"item_id": "SYN", "platform": "landsat-8", "date": "2010-01-15"}]); assert "PLATFORM_DATE" in errs(r)
    r2 = run(tmp_path / "b", platform_sources=[{"item_id": "SYN", "platform": "landsat-7", "date": "2022-01-15"}]); assert "PLATFORM_DATE" in errs(r2)   # L7 after the admitted 2021-12-31

def test_counts_inconsistent(tmp_path):
    def m(comp, qa, vm, nc): qa[3:8] = 0; return comp, qa, vm, nc       # per-platform counts zeroed
    r = run(tmp_path, mutate=m); assert "COUNTS" in errs(r)

def test_tampered_file_breaks_provenance(tmp_path):
    inside = make_product(tmp_path / "2020/landsat/seasonal/dry")
    w(tmp_path / "2020/landsat/seasonal/dry/valid_mask.tif", np.zeros((10, 10)), "uint8")
    r = V.validate(tmp_path, "reference", grid=G, district=inside); assert "PROVENANCE" in errs(r)

def test_wrong_lattice(tmp_path):
    inside = make_product(tmp_path / "2020/landsat/seasonal/dry")
    shifted = V.GridSpec("EPSG:32643", 30.0, 15.0, 300.0, 10, 10)
    r = V.validate(tmp_path, "reference", grid=shifted, district=inside); assert "TRANSFORM" in errs(r)

def test_out_of_range_reflectance(tmp_path):
    def m(comp, qa, vm, nc): comp[2, 3, 3] = 12000; return comp, qa, vm, nc
    r = run(tmp_path, mutate=m); assert "RANGE" in errs(r)

def test_missing_required_epochs_and_duplicates(tmp_path):
    inside = make_product(tmp_path / "2020/landsat/seasonal/dry"); make_product(tmp_path / "2020/landsat/seasonal/wet", period="wet")
    r = V.validate(tmp_path, "reference", grid=G, district=inside, required=[(1990, "dry"), (2020, "dry")])
    assert r["missing_required"] == ["1990/dry"] and not r["complete_for_required"]
    assert r["duplicates"] and not r["ok"]          # identical synthetic files in two products are flagged as duplicates

def test_gee_layout_filled_detection(tmp_path):
    a = np.full((len(V.GEE_BANDS), 10, 10), 0.1, np.float32); i = V.GEE_BANDS.index("n_clear"); a[i] = 3; a[i, 2, 2] = 0       # n_clear 0 but reflectance present
    w(tmp_path / "landsat_2000_dry.tif", a, "float32", None, V.GEE_BANDS)
    r = V.validate(tmp_path, "gee", grid=G, district=np.ones((10, 10), bool)); assert "FILLED" in errs(r)

def test_static_gee_check_passes():
    r = V.static_gee_check(); assert r["ok"], {k: v for k, v in r["checks"].items() if not v}
