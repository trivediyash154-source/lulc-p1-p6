"""Phase-5 gold ingestion / audit tests. Every label, form, key and raster here is SYNTHETIC TEST DATA — NOT RESEARCH DATA.
The synthetic key uses ids 'SYN-xxxx' and a 10 x 10 synthetic grid; nothing is written to data/labels/gold/."""
import json, sys
from pathlib import Path
import numpy as np, pandas as pd, pytest
sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "src"))
from validation import ingest_gold as IG, audit_gold as AG

EP = IG.EPOCHS
CLS = ["built_up", "agriculture", "natural_vegetation", "water"]

def make_gold(tmp: Path, n=20, n_double=6):
    g = tmp / "gold"
    for d in ("_key", "raw_interpreter_A", "raw_interpreter_B", "adjudicated", "metadata", "sampling_design"): (g / d).mkdir(parents=True)
    rng = np.random.default_rng(0)
    K = pd.DataFrame({"anon_id": [f"SYN-{i:04d}" for i in range(n)], "stratum": ["s1", "s2"] * (n // 2), "row": np.arange(n) % 10, "col": np.arange(n) // 2 % 10,
                      "x_utm": 1000.0 + np.arange(n) * 30, "y_utm": 5000.0 - np.arange(n) * 30, "region": ["wet", "dry"] * (n // 2), "block": "0:0", "lon": 73.0 + np.arange(n) * 0.001,
                      "lat": 18.0 + np.arange(n) * 0.001, "stratum_area_cells": 100, "n_stratum_sample": n // 2, "inclusion_prob_frame": 0.1, "double_interpretation": [i < n_double for i in range(n)]})
    K.to_csv(g / "_key/phase4_gold_key.csv", index=False)
    truth = {(r.anon_id, e): CLS[(i + e) % 4] for i, r in K.iterrows() for e in EP}
    return g, K, truth

def form(K, truth, ids, flip=(), status="done", source="GEP_historical", date_offset=0, override=None):
    rows = []
    for _, r in K[K.anon_id.isin(ids)].iterrows():
        rec = {"anon_id": r.anon_id, "lat": r.lat, "lon": r.lon}
        for e in EP:
            c = truth[(r.anon_id, e)]
            if (r.anon_id, e) in flip: c = CLS[(CLS.index(c) + 1) % 4]
            rec.update({f"dominant_class_{e}": c if status == "done" else "", f"dominant_share_3bins_{e}": ">=75" if status == "done" else "", f"second_class_{e}": "none" if status == "done" else "",
                        f"confidence_1to3_{e}": "3" if status == "done" else "", f"imagery_source_{e}": source if status == "done" else "",
                        f"imagery_date_{e}": f"{e + date_offset}-03-15" if status == "done" else "", f"status_{e}": status, f"notes_{e}": "SYNTHETIC TEST DATA — NOT RESEARCH DATA"})
        rows.append(rec)
    df = pd.DataFrame(rows)
    if override: override(df)
    return df

def meta(role, iid, **kw):
    m = {"interpreter_role": role, "interpreter_id": iid, "interpreter_type": "human", "software": "Google Earth Pro 7.3", "interpretation_start": "2026-01-01",
         "interpretation_end": "2026-02-01", "blind_declaration": True, "note": "SYNTHETIC TEST DATA — NOT RESEARCH DATA"}; m.update(kw); return m

def put(g, role, df, m, name="pass1"):
    p = g / f"raw_interpreter_{role}" / f"{name}.csv"; df.to_csv(p, index=False); p.with_suffix(".meta.json").write_text(json.dumps(m)); return p

def spatial_ok(n=10):
    return IG.Spatial(np.ones((n, n), bool), np.ones((n, n), bool), np.full((n, n), 5000.0), np.full((n, n), 9000.0))

def setup_valid(tmp, flip_b=(), adjudicate=True, n=20, n_double=6):
    g, K, truth = make_gold(tmp, n, n_double); dbl = K.anon_id[K.double_interpretation].tolist()
    pa = put(g, "A", form(K, truth, K.anon_id), meta("A", "INT-A")); pb = put(g, "B", form(K, truth, dbl, flip=flip_b), meta("B", "INT-B"))
    files = [pa, pb]
    if flip_b and adjudicate:
        rows = [{"anon_id": a, "epoch": e, "label_A": truth[(a, e)], "label_B": CLS[(CLS.index(truth[(a, e)]) + 1) % 4], "adjudicated_label": truth[(a, e)], "rule": "decision rule built_up", "reviewer": "INT-C", "date": "2026-02-10"} for a, e in flip_b]
        p = g / "adjudicated/adj1.csv"; pd.DataFrame(rows).to_csv(p, index=False); files.append(p)
    IG.freeze_pass("p1", files, "tester", gold=g)
    return g, K, truth

def codes(exc): return str(exc.value)

def test_valid_pass_assembles_and_passes_g2(tmp_path):
    g, K, truth = setup_valid(tmp_path, flip_b=[("SYN-0001", 2020)], n=100, n_double=40)
    final, rep = IG.ingest(g, spatial=spatial_ok(), write=True)
    assert rep.ok and len(final) == len(K) * len(EP)
    r = final[(final.anon_id == "SYN-0001") & (final.epoch == 2020)].iloc[0]
    assert r.label_source == "adjudicated" and r.reference_label == truth[("SYN-0001", 2020)]
    assert (final[(final.anon_id == "SYN-0002")].label_source == "A=B").all()
    long = pd.read_csv(g / "ingested/gold_long_all_interpreters.csv", dtype={"confidence_1to3": str}, keep_default_na=False)
    res = AG.g2(final, long)
    assert res["status"] == "PASS" and res["per_epoch"][2020]["double_share_of_design"] == pytest.approx(40 / 100)

def test_unfrozen_and_edited_files_refused(tmp_path):
    g, K, truth = make_gold(tmp_path); put(g, "A", form(K, truth, K.anon_id), meta("A", "INT-A"))
    with pytest.raises(IG.GoldProtocolError) as e: IG.ingest(g, spatial=spatial_ok(), write=False)
    assert "UNFROZEN" in codes(e)
    g2_, K2, t2 = setup_valid(tmp_path / "b")
    p = g2_ / "raw_interpreter_A/pass1.csv"; df = pd.read_csv(p); df.loc[0, "dominant_class_2020"] = "water" if df.loc[0, "dominant_class_2020"] != "water" else "built_up"; df.to_csv(p, index=False)
    with pytest.raises(IG.GoldProtocolError) as e: IG.ingest(g2_, spatial=spatial_ok(), write=False)
    assert "HASH_MISMATCH" in codes(e)

def test_freeze_is_immutable(tmp_path):
    g, K, truth = setup_valid(tmp_path)
    p = g / "raw_interpreter_A/pass1.csv"; p.write_text(p.read_text() + "\n")
    with pytest.raises(IG.GoldProtocolError): IG.freeze_pass("p1", [p], "tester", gold=g)

@pytest.mark.parametrize("mut,code", [
    (lambda df: df.__setitem__("lat", df["lat"] + 0.01), "COORDINATES_CHANGED"),
    (lambda df: df.__setitem__("imagery_source_2020", "WorldCover 2020"), "FORBIDDEN_SOURCE"),
    (lambda df: df.__setitem__("imagery_source_2000", "Claude interpretation"), "FORBIDDEN_SOURCE"),
    (lambda df: df.__setitem__("imagery_date_1990", "1995-06-01"), "IMAGERY_DATE_WINDOW"),
    (lambda df: df.__setitem__("imagery_date_2010", "15/03/2010"), "IMAGERY_DATE"),
    (lambda df: df.__setitem__("dominant_class_2020", "forest"), "CLASS"),
    (lambda df: df.__setitem__("confidence_1to3_2000", "5"), "CONFIDENCE"),
    (lambda df: df.__setitem__("dominant_share_3bins_2010", "80"), "SHARE"),
    (lambda df: df.__setitem__("status_1990", "unavailable"), "UNAVAILABLE_STATUS"),
    (lambda df: df.__setitem__("second_class_2020", df["dominant_class_2020"]), "SECOND_CLASS"),
    (lambda df: df.__setitem__("imagery_source_2000", "Landsat_context"), "LANDSAT_CONFIDENCE"),
])
def test_value_and_geometry_violations_fail_loudly(tmp_path, mut, code):
    g, K, truth = make_gold(tmp_path); pa = put(g, "A", form(K, truth, K.anon_id, override=mut), meta("A", "INT-A")); IG.freeze_pass("p1", [pa], "t", gold=g)
    with pytest.raises(IG.GoldProtocolError) as e: IG.ingest(g, spatial=spatial_ok(), write=False)
    assert code in codes(e)

def test_identity_violations(tmp_path):
    g, K, truth = make_gold(tmp_path)
    df = form(K, truth, K.anon_id.iloc[:-1]); extra = df.iloc[[0]].copy(); extra["anon_id"] = "SYN-9999"; df = pd.concat([df, extra, df.iloc[[1]]])
    pa = put(g, "A", df, meta("A", "INT-A")); pb = put(g, "B", form(K, truth, K.anon_id.iloc[10:13]), meta("B", "INT-A")); IG.freeze_pass("p1", [pa, pb], "t", gold=g)
    with pytest.raises(IG.GoldProtocolError) as e: IG.ingest(g, spatial=spatial_ok(), write=False)
    for c in ("UNKNOWN_ID", "MISSING_POINTS", "DUPLICATE", "NOT_IN_SUBSET", "SAME_INTERPRETER"): assert c in codes(e), c

def test_non_human_or_not_blind_interpreter_refused(tmp_path):
    g, K, truth = make_gold(tmp_path); pa = put(g, "A", form(K, truth, K.anon_id), meta("A", "INT-A", interpreter_type="ai_model", blind_declaration=False)); IG.freeze_pass("p1", [pa], "t", gold=g)
    with pytest.raises(IG.GoldProtocolError) as e: IG.ingest(g, spatial=spatial_ok(), write=False)
    assert "NOT_HUMAN" in codes(e) and "NOT_BLIND" in codes(e)

def test_disagreement_needs_adjudication_and_no_overwrite(tmp_path):
    g, K, truth = setup_valid(tmp_path, flip_b=[("SYN-0002", 2000)], adjudicate=False)
    with pytest.raises(IG.GoldProtocolError) as e: IG.ingest(g, spatial=spatial_ok(), write=False)
    assert "ADJUDICATION_MISSING" in codes(e)
    g2_, K2, t2 = make_gold(tmp_path / "b"); dbl = K2.anon_id[K2.double_interpretation].tolist()
    pa = put(g2_, "A", form(K2, t2, K2.anon_id), meta("A", "INT-A")); pb = put(g2_, "B", form(K2, t2, dbl, flip=[("SYN-0002", 2000)]), meta("B", "INT-B"))
    p = g2_ / "adjudicated/adj.csv"; pd.DataFrame([{"anon_id": "SYN-0002", "epoch": 2000, "label_A": "other", "label_B": "x", "adjudicated_label": "water", "rule": "r", "reviewer": "INT-A", "date": "2026-02-02"}]).to_csv(p, index=False)
    IG.freeze_pass("p1", [pa, pb, p], "t", gold=g2_)
    with pytest.raises(IG.GoldProtocolError) as e: IG.ingest(g2_, spatial=spatial_ok(), write=False)
    assert "ADJ_OVERWRITE" in codes(e) and "ADJ_REVIEWER" in codes(e)

def test_spatial_leakage_checks(tmp_path):
    g, K, truth = setup_valid(tmp_path); sp = spatial_ok(); sp.validation_block[0, 0] = False; sp.dist_training_m[1, 0] = 500.0; sp.dist_windows_m[2, 1] = 100.0
    with pytest.raises(IG.GoldProtocolError) as e: IG.ingest(g, spatial=sp, write=False)
    for c in ("OUTSIDE_VALIDATION_BLOCK", "TOO_CLOSE_TO_TRAINING", "INSIDE_PHASE3_WINDOWS"): assert c in codes(e), c

def test_missing_spatial_context_is_recorded(tmp_path):
    g, K, truth = setup_valid(tmp_path); final, rep = IG.ingest(g, spatial=None, write=False)
    assert any(w["code"] == "SPATIAL_NOT_CHECKED" for w in rep.warnings)

def test_g2_fails_on_low_completeness_and_kappa(tmp_path):
    g, K, truth = make_gold(tmp_path); dbl = K.anon_id[K.double_interpretation].tolist()
    def blank_half(df):
        for e in EP:
            for f in IG.FIELDS: df.loc[df.index[:12], f"{f}_{e}"] = ""
    pa = put(g, "A", form(K, truth, K.anon_id, override=blank_half), meta("A", "INT-A")); pb = put(g, "B", form(K, truth, dbl), meta("B", "INT-B"))
    IG.freeze_pass("p1", [pa, pb], "t", gold=g); final, rep = IG.ingest(g, spatial=spatial_ok(), write=True)
    long = pd.read_csv(g / "ingested/gold_long_all_interpreters.csv", dtype={"confidence_1to3": str}, keep_default_na=False)
    res = AG.g2(final, long); assert res["status"] == "FAIL" and not res["per_epoch"][2020]["criteria"]["labelled_ge_0.80"]

def test_no_gold_gives_g2_fail(tmp_path):
    g, K, truth = make_gold(tmp_path)
    with pytest.raises(IG.GoldProtocolError) as e: IG.ingest(g, spatial=spatial_ok(), write=False)
    assert "NO_INTERPRETER_A" in codes(e)
    assert AG.g2(None, None)["status"] == "FAIL"

def test_training_label_leakage_audit(tmp_path):
    g, K, truth = make_gold(tmp_path); sp = spatial_ok(); sp.validation_block[:] = False; sp.validation_block[0, 0] = True; sp.dist_training_m[:] = 0.0
    grid = {"x0": 0.0, "y1": 300.0}
    T = pd.DataFrame({"x_utm": [15.0, 105.0], "y_utm": [285.0, 195.0]})
    res = AG.audit_training_labels(T, sp, K, grid)
    assert res["in_validation_blocks"] == 1 and not res["ok"]

def test_kappa_not_measured_below_30_double_points(tmp_path):
    g, K, truth = setup_valid(tmp_path)          # 6 double points
    final, rep = IG.ingest(g, spatial=spatial_ok(), write=True)
    long = pd.read_csv(g / "ingested/gold_long_all_interpreters.csv", dtype={"confidence_1to3": str}, keep_default_na=False)
    res = AG.g2(final, long); assert res["status"] == "FAIL" and not res["per_epoch"][2020]["kappa_measured"]

def test_mostly_uncertain_cannot_pass_g2(tmp_path):
    g, K, truth = make_gold(tmp_path, 100, 40); dbl = K.anon_id[K.double_interpretation].tolist()
    def unc(df):
        for e in EP: df.loc[df.index[:30], f"dominant_class_{e}"] = "uncertain"
    pa = put(g, "A", form(K, truth, K.anon_id, override=unc), meta("A", "INT-A")); pb = put(g, "B", form(K, truth, dbl, override=unc), meta("B", "INT-B"))
    IG.freeze_pass("p1", [pa, pb], "t", gold=g); final, rep = IG.ingest(g, spatial=spatial_ok(), write=True)
    long = pd.read_csv(g / "ingested/gold_long_all_interpreters.csv", dtype={"confidence_1to3": str}, keep_default_na=False)
    res = AG.g2(final, long); assert res["per_epoch"][2020]["labelled_share"] == pytest.approx(0.70) and not res["per_epoch"][2020]["criteria"]["labelled_ge_0.80"]

def test_definite_vs_abstention_needs_adjudication(tmp_path):
    g, K, truth = make_gold(tmp_path); dbl = K.anon_id[K.double_interpretation].tolist()
    def b_unc(df): df.loc[df.anon_id == "SYN-0003", "dominant_class_2020"] = "uncertain"
    pa = put(g, "A", form(K, truth, K.anon_id), meta("A", "INT-A")); pb = put(g, "B", form(K, truth, dbl, override=b_unc), meta("B", "INT-B"))
    IG.freeze_pass("p1", [pa, pb], "t", gold=g)
    with pytest.raises(IG.GoldProtocolError) as e: IG.ingest(g, spatial=spatial_ok(), write=False)
    assert "ADJUDICATION_MISSING" in codes(e)

def test_refreeze_after_edit_is_refused_unless_signed_correction(tmp_path):
    g, K, truth = setup_valid(tmp_path)
    p = g / "raw_interpreter_A/pass1.csv"; df = pd.read_csv(p); df.loc[0, "notes_2020"] = "edited"; df.to_csv(p, index=False)
    IG.freeze_pass("p2", [p], "tester", gold=g)       # an edited form frozen under a new pass id
    with pytest.raises(IG.GoldProtocolError) as e: IG.ingest(g, spatial=spatial_ok(), write=False)
    assert "RAW_REFROZEN" in codes(e)
    fz = IG.frozen_hashes(g)["raw_interpreter_A/pass1.csv"]
    (g / "metadata/correction_A_pass1.json").write_text(json.dumps({"file": "raw_interpreter_A/pass1.csv", "previous_sha256": fz[0][1], "new_sha256": fz[-1][1], "interpreter_id": "INT-A",
                                                                    "reason": "typo in notes (SYNTHETIC TEST DATA)", "date": "2026-02-03", "signed_by_interpreter": True}))
    final, rep = IG.ingest(g, spatial=spatial_ok(), write=False); assert any(w["code"] == "RAW_CORRECTED" for w in rep.warnings)

def test_training_mode_leakage_rules(tmp_path):
    g, K, truth = make_gold(tmp_path); (g / "_key/phase4_gold_key.csv").rename(g / "_key/T1_key.csv")
    pa = put(g, "A", form(K, truth, K.anon_id), meta("A", "INT-A")); IG.freeze_pass("p1", [pa], "t", gold=g)
    ok = IG.Spatial(np.ones((10, 10), bool), np.zeros((10, 10), bool), np.zeros((10, 10)), np.full((10, 10), 9000.0), np.array([[1e6, 1e6]]))
    final, rep = IG.ingest(g, spatial=ok, write=False, kind="training"); assert rep.ok
    bad = IG.Spatial(np.ones((10, 10), bool), np.zeros((10, 10), bool), np.zeros((10, 10)), np.full((10, 10), 9000.0), np.array([[1000.0, 5000.0]]))
    bad.validation_block[1, 0] = True; bad.dist_training_m[2, 1] = 60.0
    with pytest.raises(IG.GoldProtocolError) as e: IG.ingest(g, spatial=bad, write=False, kind="training")
    for c in ("TRAINING_IN_VALIDATION_BLOCK", "TRAINING_NOT_ELIGIBLE", "TOO_CLOSE_TO_GOLD"): assert c in codes(e), c

def test_training_mode_tuning_partition(tmp_path):
    g, K, truth = make_gold(tmp_path); K["split"] = ["tuning" if i % 2 else "train" for i in range(len(K))]; K.to_csv(g / "_key/T1_key.csv", index=False)
    pa = put(g, "A", form(K, truth, K.anon_id), meta("A", "INT-A")); IG.freeze_pass("p1", [pa], "t", gold=g)
    dt = np.full((10, 10), 5000.0); dt[K.row[K.split == "tuning"], K.col[K.split == "tuning"]] = 0.0
    sp = IG.Spatial(np.ones((10, 10), bool), np.zeros((10, 10), bool), np.zeros((10, 10)), np.full((10, 10), 9000.0), np.array([[1e6, 1e6]]), dt)
    final, rep = IG.ingest(g, spatial=sp, write=False, kind="training"); assert rep.ok
    sp.dist_tuning_m[K.row.iloc[0], K.col.iloc[0]] = 500.0                      # a TRAIN point (index 0) within 2 km of a tuning block
    with pytest.raises(IG.GoldProtocolError) as e: IG.ingest(g, spatial=sp, write=False, kind="training")
    assert "TRAIN_POINT_NEAR_TUNING_BLOCK" in codes(e)

def test_training_mode_partition_never_skipped_and_split_description(tmp_path):
    """SYNTHETIC TEST DATA — NOT RESEARCH DATA. A key with a split column but no tuning raster must FAIL (not skip); run_t1 reports labelled share per split."""
    g, K, truth = make_gold(tmp_path); K["split"] = ["tuning" if i % 2 else "train" for i in range(len(K))]; K.to_csv(g / "_key/T1_key.csv", index=False)
    pa = put(g, "A", form(K, truth, K.anon_id), meta("A", "INT-A")); IG.freeze_pass("p1", [pa], "t", gold=g)
    no_raster = IG.Spatial(np.ones((10, 10), bool), np.zeros((10, 10), bool), np.zeros((10, 10)), np.full((10, 10), 9000.0), np.array([[1e6, 1e6]]))
    with pytest.raises(IG.GoldProtocolError) as e: IG.ingest(g, spatial=no_raster, write=False, kind="training")
    assert "TUNING_PARTITION_UNCHECKABLE" in codes(e)
    dt = np.full((10, 10), 5000.0); dt[K.row[K.split == "tuning"], K.col[K.split == "tuning"]] = 0.0
    sp = IG.Spatial(np.ones((10, 10), bool), np.zeros((10, 10), bool), np.zeros((10, 10)), np.full((10, 10), 9000.0), np.array([[1e6, 1e6]]), dt)
    rep = AG.run_t1(t1=g, out=tmp_path / "t1out", spatial=sp); assert rep["ingest"] == "PASS"
    bs = json.loads((tmp_path / "t1out/t1_audit.json").read_text())["description_by_split"]
    assert set(bs) == {"train", "tuning"} and all(bs[s]["2020"]["labelled_share"] == 1.0 for s in bs)
