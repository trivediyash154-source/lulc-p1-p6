"""Phase 6: DISTRICT feature cube data/features/cube/pune_G30.zarr with the registered feature definition (window-cube schema, src/pune_eo/feature_engineering/cube.py):
  landsat  (year, feature[23], y, x)  quality (year, qfeature[3], y, x)  terrain (tfeature[12], y, x)  sentinel (syear, sfeature[7], y, x)
The window builder holds the whole cube in memory; the district (6546 x 5624 cells) is built in row strips of 512 rows (+2-row halo for the 5x5 local-SD
features), each feature computed by the SAME functions (landsat_year / sentinel_year / terrain with a window), and written region by region into a zarr store
created from a lazy template. Missing composites stay NaN (never interpolated). Numerically equivalent to the window builder (tests/test_district_feature_cube.py).
Default years = the registered minimum (1990-1992, 1998-2002, 2008-2012, 2018-2022, 2021); syears = 2020 (P4-C6@v2).
Writes <zarr>.json with availability, district coverage per year/feature and the SHA-256 of every source composite metadata file."""
import argparse, hashlib, json, sys, time
from pathlib import Path
import numpy as np
sys.path.insert(0, "src")
import dask.array as da, xarray as xr
from rasterio.windows import Window
from pune_eo import config
from pune_eo.grid import district_grid, Grid
from pune_eo.feature_engineering import cube as C
from pune_eo.provenance import utcnow
REQ = sorted({y for e in (1990, 2000, 2010, 2020) for y in range(e - 2, e + 3) if y >= 1990} | {2021})

FEATURE_RELS = ("annual", "seasonal/dry", "seasonal/post_monsoon")   # the composites the Landsat features are computed from

def family_for_year(grid: Grid, year: int, family: str, fallback: str | None) -> str:
    """The P4-C2@v2 treatment family (landsat_c2tm) exists only for years with TM observations. For any other year the treatment composite is, by
    construction, identical to the standard one (the treatment changes ONLY the landsat-5/4 transform), so the standard family is used - but only after
    checking that its products contain zero landsat-4/5 clear observations; otherwise this is an error (never a silent substitution)."""
    root = config.path("data", "composites", grid.id, str(year))
    if fallback is None or family == fallback or any((root / family / r / "metadata.json").exists() for r in FEATURE_RELS): return family
    ms = [root / fallback / r / "metadata.json" for r in FEATURE_RELS]
    if not any(m.exists() for m in ms): return family          # nothing to use: stays NaN, reported by the validator
    tm = sum(int(json.loads(m.read_text()).get("statistics", {}).get("sensor_contribution_clear_px", {}).get(p, 0)) for m in ms if m.exists() for p in ("landsat-4", "landsat-5"))
    if tm: raise RuntimeError(f"{year}: '{family}' products missing although the '{fallback}' products contain {tm} TM clear observations - build the treatment family for this year")
    return fallback

def build(grid: Grid, years, syears, out: Path, strip=512, family="landsat", mask=None, log=print, chunk=256, fallback_family: str | None = None) -> dict:
    H, W = grid.shape; t0 = time.time(); fam_y = {int(yr): family_for_year(grid, int(yr), family, fallback_family) for yr in years}
    x = grid.x0 + (np.arange(W) + 0.5) * grid.res; y = grid.y1 - (np.arange(H) + 0.5) * grid.res
    ch = (min(chunk, H), min(chunk, W))
    tmpl = xr.Dataset({"landsat": (("year", "feature", "y", "x"), da.full((len(years), len(C.LANDSAT_FEATURES), H, W), np.nan, dtype=np.float32, chunks=(1, len(C.LANDSAT_FEATURES)) + ch)),
                       "quality": (("year", "qfeature", "y", "x"), da.full((len(years), len(C.QUALITY), H, W), np.nan, dtype=np.float32, chunks=(1, len(C.QUALITY)) + ch)),
                       "terrain": (("tfeature", "y", "x"), da.full((len(C.TERRAIN), H, W), np.nan, dtype=np.float32, chunks=(len(C.TERRAIN),) + ch)),
                       "sentinel": (("syear", "sfeature", "y", "x"), da.full((len(syears), len(C.SENTINEL_FEATURES), H, W), np.nan, dtype=np.float32, chunks=(1, len(C.SENTINEL_FEATURES)) + ch))},
                      coords={"year": list(years), "feature": C.LANDSAT_FEATURES, "qfeature": C.QUALITY, "tfeature": list(C.TERRAIN), "syear": list(syears), "sfeature": C.SENTINEL_FEATURES, "y": y, "x": x})
    tmpl.attrs.update({"grid": json.dumps(grid.to_dict()), "crs": str(grid.crs), "created_utc": utcnow(), "registry": "configs/features.yaml", "builder": "scripts/phase6_build_feature_cube.py (row strips)",
                       "landsat_family": family, "harmonization": "per composite metadata.json (landsat: local_pune_g30_v2 unless the family says otherwise)"})
    tmpl.to_zarr(out, mode="w", compute=False, consolidated=True)
    has_terrain = config.path("data", "features", "terrain", grid.id, "terrain.tif").exists(); avail = {}
    cov = {int(yr): {"n": 0, **{f: 0 for f in C.LANDSAT_FEATURES}} for yr in years}; scov = {int(yr): {"n": 0, **{f: 0 for f in C.SENTINEL_FEATURES}} for yr in syears}; tcov = {"n": 0, **{f: 0 for f in C.TERRAIN}}
    step = strip if strip % ch[0] == 0 or strip >= H else ch[0] * max(1, strip // ch[0])
    for r0 in range(0, H, step):
        r1 = min(H, r0 + step); h0, h1 = max(0, r0 - 2), min(H, r1 + 2); win = Window(0, h0, W, h1 - h0); cr = slice(r0 - h0, r0 - h0 + (r1 - r0))
        Lr = np.full((len(years), len(C.LANDSAT_FEATURES), r1 - r0, W), np.nan, np.float32); Qr = np.full((len(years), len(C.QUALITY), r1 - r0, W), np.nan, np.float32)
        Sr = np.full((len(syears), len(C.SENTINEL_FEATURES), r1 - r0, W), np.nan, np.float32)
        Tr = C.terrain(grid, win)[:, cr] if has_terrain else np.full((len(C.TERRAIN), r1 - r0, W), np.nan, np.float32)
        ins = mask[r0:r1] if mask is not None else np.ones((r1 - r0, W), bool)
        for i, yr in enumerate(years):
            F, Q, av = C.landsat_year(grid, yr, win, fam_y[int(yr)]); Lr[i], Qr[i] = F[:, cr], Q[:, cr]; avail.setdefault(int(yr), av)
            cov[int(yr)]["n"] += int(ins.sum())
            for j, f in enumerate(C.LANDSAT_FEATURES): cov[int(yr)][f] += int(np.isfinite(Lr[i, j][ins]).sum())
        for i, yr in enumerate(syears):
            S, av = C.sentinel_year(grid, yr, win); Sr[i] = S[:, cr]; avail.setdefault(int(yr), {}).update(av)
            scov[int(yr)]["n"] += int(ins.sum())
            for j, f in enumerate(C.SENTINEL_FEATURES): scov[int(yr)][f] += int(np.isfinite(Sr[i, j][ins]).sum())
        tcov["n"] += int(ins.sum())
        for j, f in enumerate(C.TERRAIN): tcov[f] += int(np.isfinite(Tr[j][ins]).sum())
        xr.Dataset({"landsat": (("year", "feature", "y", "x"), Lr), "quality": (("year", "qfeature", "y", "x"), Qr), "terrain": (("tfeature", "y", "x"), Tr),
                    "sentinel": (("syear", "sfeature", "y", "x"), Sr)}).to_zarr(out, region={"year": slice(None), "feature": slice(None), "qfeature": slice(None), "tfeature": slice(None),
                                                                                    "syear": slice(None), "sfeature": slice(None), "y": slice(r0, r1), "x": slice(None)})
        log(f"rows {r0}-{r1} written ({time.time() - t0:.0f}s)")
    src = {}
    for yr, fam in fam_y.items():
        for m in sorted(config.path("data", "composites", grid.id, str(yr), fam).glob("**/metadata.json")): src[str(m.relative_to(config.ROOT))] = hashlib.sha256(m.read_bytes()).hexdigest()
    for yr in syears:
        for m in sorted(config.path("data", "composites", grid.id, str(yr), "sentinel1").glob("**/metadata.json")): src[str(m.relative_to(config.ROOT))] = hashlib.sha256(m.read_bytes()).hexdigest()
    frac = lambda d: {k: (v / d["n"] if d["n"] else None) for k, v in d.items() if k != "n"}
    meta = {"zarr": str(out.relative_to(config.ROOT)) if str(out).startswith(str(config.ROOT)) else str(out), "grid": grid.to_dict(), "years": [int(v) for v in years], "syears": [int(v) for v in syears],
            "landsat_family": family, "fallback_family": fallback_family, "family_per_year": fam_y, "availability": avail, "district_coverage_landsat": {yr: frac(d) for yr, d in cov.items()}, "district_coverage_sentinel": {yr: frac(d) for yr, d in scov.items()},
            "district_coverage_terrain": frac(tcov), "terrain_present": has_terrain, "source_metadata_sha256": src, "seconds": round(time.time() - t0, 1), "created_utc": utcnow()}
    out.with_suffix(".json").write_text(json.dumps(meta, indent=1, default=str)); return meta

if __name__ == "__main__":
    ap = argparse.ArgumentParser(); ap.add_argument("--years", default=",".join(map(str, REQ))); ap.add_argument("--syears", default="2020"); ap.add_argument("--family", default="landsat")
    ap.add_argument("--fallback-family", default=None, help="P4-C2@v2 treatment cube: --family landsat_c2tm --fallback-family landsat (years without TM observations only; checked)")
    ap.add_argument("--out", default=None); ap.add_argument("--strip", type=int, default=512); a = ap.parse_args()
    import rasterio
    G = district_grid("G30"); out = Path(a.out) if a.out else config.path("data/features/cube", f"{G.id}{'' if a.family == 'landsat' else '_' + a.family}.zarr")
    with rasterio.open(config.path("data/products_ext/district/district_mask_30m.tif")) as s: mask = s.read(1).astype(bool)
    m = build(G, [int(v) for v in a.years.split(",")], [int(v) for v in a.syears.split(",") if v], out, a.strip, a.family, mask, fallback_family=a.fallback_family)
    print(json.dumps({k: m[k] for k in ("zarr", "years", "syears", "terrain_present", "seconds")}, indent=1))
