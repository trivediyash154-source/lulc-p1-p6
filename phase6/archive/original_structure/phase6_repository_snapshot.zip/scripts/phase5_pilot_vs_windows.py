"""Consistency check (data product, not an experiment): does the district 30 m pilot reproduce the Phase-1/3 WINDOW composites cell by cell where they overlap?
Same engine, same manifest, same harmonisation -> reflectance and n_clear should be identical; any difference would mean the district cube is not comparable with
the windows the Phase-3 models were trained on. Read-only; writes results/phase5/cube_validation/pilot_vs_window_composites.json."""
import json, sys
from pathlib import Path
import numpy as np, rasterio
sys.path.insert(0, "src")
from pune_eo import config
from pune_eo.provenance import utcnow
OUT = config.path("results/phase5/cube_validation/pilot_vs_window_composites.json"); res = {"created_utc": utcnow(), "comparisons": []}
for y in (1990, 2000, 2010, 2020):
    D = config.path("data/composites/pune_G30", str(y), "landsat/seasonal/dry")
    if not (D / "optical_composite.tif").exists(): continue
    with rasterio.open(D / "optical_composite.tif") as s: dt = s.transform; dc = s.read(); dd = list(s.descriptions)
    with rasterio.open(D / "observation_count.tif") as s: dn = s.read(1)
    for w in ("khadakwasla_mutha", "baramati_agri", "mulshi_ghats"):
        W = config.path(f"data/composites/pune_G30_{w}", str(y), "landsat/seasonal/dry")
        if not (W / "optical_composite.tif").exists(): res["comparisons"].append({"year": y, "window": w, "status": "window raster absent locally"}); continue
        with rasterio.open(W / "optical_composite.tif") as s: wt = s.transform; wc = s.read(); wd = list(s.descriptions)
        with rasterio.open(W / "observation_count.tif") as s: wn = s.read(1)
        c0, r0 = (wt.c - dt.c) / 30.0, (dt.f - wt.f) / 30.0
        if abs(c0 - round(c0)) > 1e-6 or abs(r0 - round(r0)) > 1e-6: res["comparisons"].append({"year": y, "window": w, "status": "lattice mismatch"}); continue
        c0, r0 = int(round(c0)), int(round(r0)); h, ww = wn.shape
        rr0, cc0 = max(r0, 0), max(c0, 0); rr1, cc1 = min(r0 + h, dn.shape[0]), min(c0 + ww, dn.shape[1])
        sub_d = dc[:, rr0:rr1, cc0:cc1]; sub_w = wc[:, rr0 - r0:rr1 - r0, cc0 - c0:cc1 - c0][[wd.index(b) for b in dd]]
        nd, nw = dn[rr0:rr1, cc0:cc1], wn[rr0 - r0:rr1 - r0, cc0 - c0:cc1 - c0]
        both = (sub_d != -32768).all(0) & (sub_w != -32768).all(0)
        diff = np.abs(sub_d.astype(np.int32) - sub_w.astype(np.int32))[:, both]
        res["comparisons"].append({"year": y, "window": w, "status": "compared", "overlap_cells": int(nd.size), "cells_both_valid": int(both.sum()),
                                   "reflectance_identical_share": float((diff == 0).all(0).mean()) if both.any() else None, "reflectance_max_abs_diff_x1e4": int(diff.max()) if both.any() else None,
                                   "n_clear_identical_share": float((nd == nw).mean()), "valid_status_identical_share": float(((sub_d != -32768).all(0) == (sub_w != -32768).all(0)).mean())})
c = [x for x in res["comparisons"] if x.get("status") == "compared"]
res["summary"] = {"n_comparisons": len(c), "total_cells_both_valid": int(sum(x["cells_both_valid"] for x in c)),
                  "all_reflectance_identical": all(x["reflectance_identical_share"] == 1.0 for x in c), "all_n_clear_identical": all(x["n_clear_identical_share"] == 1.0 for x in c),
                  "min_reflectance_identical_share": min((x["reflectance_identical_share"] for x in c), default=None), "max_abs_diff_x1e4": max((x["reflectance_max_abs_diff_x1e4"] for x in c), default=None)}
OUT.write_text(json.dumps(res, indent=1)); print(json.dumps(res["summary"], indent=1))
for x in res["comparisons"]: print(x)
