"""P5-X1 (EXPLORATORY, pre-registered): district Landsat observation support -> which temporal resolution can be claimed (G1 rule).
240 m: every year/season from the Phase-1 composite metadata (data/inventory/composites.csv; n_clear per 240 m cell, conservative QA).
30 m: the Phase-5 key-epoch pilot (data/composites/pune_G30/<year>/landsat/seasonal/dry/), district and per rainfall region.
G1 temporal-resolution rule (protocol v2): annual claims only where >= 3 clear dry-season observations cover >= 80 % of the district."""
import json, os, sys, tempfile, warnings
import numpy as np, pandas as pd, rasterio
from rasterio.enums import Resampling
sys.path.insert(0, "src"); warnings.filterwarnings("ignore")
from pune_eo import config
from pune_eo.grid import district_grid
from pune_eo.labels import sources as SRC
from pune_eo.evaluation4 import protocol as P4
OUT = config.path("results/phase5/observation_support"); OUT.mkdir(parents=True, exist_ok=True); G = district_grid("G30")
run = P4.Run("P5-X1")
C = pd.read_csv(config.path("data/inventory/composites.csv")); L = C[(C.grid == "pune_G240") & (C.family == "landsat") & (C.kind == "season")]
T = L.pivot_table(index="year", columns="period", values=["reliable_fraction_ge3", "valid_fraction", "n_clear_median"]).round(4)
T.columns = [f"{a}|{b}" for a, b in T.columns]; T.to_csv(OUT / "support_240m_by_year_season.csv")
dry = T["reliable_fraction_ge3|dry"]; annual_ok = sorted(int(y) for y in dry.index[dry >= 0.80]); annual_fail = sorted(int(y) for y in dry.index[dry < 0.80])
post_ok = sorted(int(y) for y in T.index[T["reliable_fraction_ge3|post_monsoon"] >= 0.80])
R = {"rule": "annual claims only where >= 3 clear dry-season obs over >= 80 % of the district (G1)", "g240": {"annual_supported_years_dry": annual_ok, "annual_not_supported_years_dry": annual_fail,
     "post_monsoon_ge3_over_80pct_years": post_ok, "note": "240 m n_clear is conservative (a 240 m cell is clear only if all QA samples are clear)"}}
# 30 m key-epoch pilot
with rasterio.open(config.path("data/products_ext/district/district_mask_30m.tif")) as s: mask = s.read(1).astype(bool)
with rasterio.open(config.path("data/processed/climate/chirps_v2_monthly_stack.tif")) as s:
    idx = [i + 1 for i, d in enumerate(s.descriptions) if d and 1991 <= int(d[:4]) <= 2020]; tot = sum(np.nan_to_num(s.read(i).astype(float)) for i in idx) / 30.0; prof = s.profile
tmp = tempfile.NamedTemporaryFile(suffix=".tif", delete=False).name; prof.update(count=1, dtype="float32", nodata=-1)
with rasterio.open(tmp, "w", **prof) as d: d.write(tot.astype(np.float32), 1)
rain = SRC._warp(tmp, G, Resampling.bilinear, dst_nodata=-1, dtype="float32", sign=False); os.unlink(tmp)
region = np.where(rain >= 1200, 1, np.where(rain >= 700, 2, 3)).astype(np.uint8); del rain; RN = {1: "wet_west_ge1200mm", 2: "transition_700_1200mm", 3: "dry_east_lt700mm"}
g30 = {}
for y in (1990, 2000, 2010, 2020):
    d = config.path("data/composites/pune_G30", str(y), "landsat/seasonal/dry")
    if not (d / "metadata.json").exists(): g30[y] = "NOT BUILT"; continue
    meta = json.loads((d / "metadata.json").read_text())
    with rasterio.open(d / "qa.tif") as s: q = s.read(); qd = list(s.descriptions)
    nc = q[qd.index("n_clear")]; nob = q[qd.index("n_observed")]
    rec = {"district": {"valid_fraction": float((nc[mask] >= 1).mean()), "reliable_fraction_ge3": float((nc[mask] >= 3).mean()), "n_clear_median": float(np.median(nc[mask])),
                        "never_observed_fraction": float((nob[mask] == 0).mean())}, "regions": {},
           "sensors": meta["sensors"], "n_sources": len(meta["sources"]), "g240_reliable_fraction_ge3_same_year": float(dry.get(y, np.nan))}
    for k, nm in RN.items():
        m = mask & (region == k); rec["regions"][nm] = {"valid_fraction": float((nc[m] >= 1).mean()), "reliable_fraction_ge3": float((nc[m] >= 3).mean()), "n_clear_median": float(np.median(nc[m]))}
    pp = {p: int(q[qd.index(f"n_clear_{p}")][mask].sum()) for p in ("landsat-5", "landsat-7", "landsat-8") if f"n_clear_{p}" in qd}; tt = sum(pp.values()) or 1
    rec["clear_obs_share_by_platform"] = {p: v / tt for p, v in pp.items()}
    g30[y] = rec; del q, nc, nob
R["g30_key_epochs_dry"] = g30
R["epoch_claims_supported_30m"] = [y for y, v in g30.items() if isinstance(v, dict) and v["district"]["reliable_fraction_ge3"] >= 0.80]
json.dump(R, open(OUT / "observation_support.json", "w"), indent=1, default=float)
txt = (f"240 m: dry-season annual support (>=3 obs over >=80 %) in {len(annual_ok)}/{len(dry)} years; not in {annual_fail}; post-monsoon >=80 % only in {len(post_ok)} years. 30 m dry: "
       + "; ".join(f"{y}: " + (f"reliable {v['district']['reliable_fraction_ge3']:.3f} (240 m {v['g240_reliable_fraction_ge3_same_year']:.3f}), wet-west {v['regions']['wet_west_ge1200mm']['reliable_fraction_ge3']:.3f}, dry-east {v['regions']['dry_east_lt700mm']['reliable_fraction_ge3']:.3f}" if isinstance(v, dict) else v) for y, v in g30.items()))
run.complete({"annual_supported_years_dry_240m": annual_ok, "annual_not_supported_dry_240m": annual_fail, "post_monsoon_ok_years_240m": post_ok,
              "g30": {y: (v["district"] if isinstance(v, dict) else v) for y, v in g30.items()}}, "NA", txt,
             outputs={"table_240m": "results/phase5/observation_support/support_240m_by_year_season.csv", "summary": "results/phase5/observation_support/observation_support.json"})
print(txt)
