"""Phase 5 entry audit: machine-checks of what the Phase-4 reports claim (results/phase5/entry/entry_checks.json).
Independent re-implementation where possible (block hashing, frame, leakage buffer) rather than re-running the Phase-4 design script.
Read-only with respect to all Phase-1..4 artefacts."""
import glob, hashlib, json, subprocess, sys, warnings
from pathlib import Path
import numpy as np, pandas as pd, rasterio
from scipy.ndimage import distance_transform_edt
sys.path.insert(0, "src"); warnings.filterwarnings("ignore")
from pune_eo import config
from pune_eo.grid import district_grid
from pune_eo.evaluation4 import protocol as P4
from pune_eo.provenance import utcnow
OUT = config.path("results/phase5/entry"); OUT.mkdir(parents=True, exist_ok=True)
G = district_grid("G30"); GOLD = config.path("data/labels/gold/phase4"); R = {"created_utc": utcnow(), "checks": {}}
def chk(name, ok, **detail): R["checks"][name] = {"ok": bool(ok), **detail}; print(("PASS " if ok else "FAIL ") + name, json.dumps(detail, default=str)[:200])
def sha(p): return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def rd(p, b=1):
    with rasterio.open(p) as s: return s.read(b)

# ---------------- 1. frozen protocol and registry
fz = P4.load_protocol()["frozen"]
chk("protocol_code_hash_unchanged", P4.code_hash() == fz["code_sha256"], current=P4.code_hash(), frozen=fz["code_sha256"])
chk("protocol_yaml_hash_unchanged", P4.protocol_hash() == fz["protocol_sha256"], current=P4.protocol_hash(), frozen=fz["protocol_sha256"])
chk("protocol_v1_archive_present", config.path("configs/phase4/evaluation_protocol_v1_frozen.yaml").exists(), sha256=sha(config.path("configs/phase4/evaluation_protocol_v1_frozen.yaml")))
cc = P4.check_confirmatory_records(); chk("G8_check_confirmatory_records", cc["ok"], records=cc["records"], protocol_version=cc["protocol_version"])
reg = {}
for p in sorted(glob.glob(str(config.path("experiments/registry4/*.json")))):
    r = json.load(open(p)); reg[r["experiment_id"]] = {"kind": r.get("kind"), "status": r.get("status"), "outcome": r.get("outcome"), "family": r.get("family")}
R["registry4"] = reg
active = {k: v for k, v in reg.items() if v["kind"] == "confirmatory" and v["status"] != "SUPERSEDED"}
chk("confirmatory_active_all_pending_none_executed", all(v["status"] == "PENDING" for v in active.values()) and len(active) == 6, active=sorted(active))
for reg_dir in ("registry", "registry3"):
    n = len(glob.glob(str(config.path("experiments", reg_dir, "*.json")))); R.setdefault("older_registries", {})[reg_dir] = n

# ---------------- 2. human gold presence
raw = {d: sorted(Path(GOLD / d).glob("*")) for d in ("raw_interpreter_A", "raw_interpreter_B", "adjudicated", "metadata")}
chk("tier_A_gold_files_present", any(len(v) for k, v in raw.items() if k != "metadata"), files={k: [p.name for p in v] for k, v in raw.items()})

# ---------------- 3. design v2 re-verification (independent)
K = pd.read_csv(GOLD / "_key/phase4_gold_key.csv"); A = pd.read_csv(GOLD / "blind/form_interpreter_A.csv"); B = pd.read_csv(GOLD / "blind/form_interpreter_B.csv")
design = json.load(open(GOLD / "sampling_design/design.json"))
chk("design_n_points_641", len(K) == 641 == design["n_points"], n_key=len(K), n_design=design["n_points"])
chk("design_unique_ids_and_cells", K.anon_id.is_unique and not K.duplicated(["row", "col"]).any(), dup_cells=int(K.duplicated(["row", "col"]).sum()))
chk("design_n_blocks_125", K.block.nunique() == 125, n_blocks=int(K.block.nunique()))
chk("design_n_strata_13_drawn", K.stratum.nunique() == 13, n=int(K.stratum.nunique()), drawn=K.stratum.value_counts().to_dict())
xs, ys = G.x0 + (K.col + 0.5) * 30, G.y1 - (K.row + 0.5) * 30
chk("design_xy_consistent_with_rowcol", np.allclose(xs, K.x_utm) and np.allclose(ys, K.y_utm))
mask = rd(config.path("data/products_ext/district/district_mask_30m.tif")).astype(bool)
chk("design_points_inside_district", bool(mask[K.row, K.col].all()), n_outside=int((~mask[K.row, K.col]).sum()))
# block hash re-implemented
bx = ((np.arange(G.width) * 30 + G.x0) // 6000).astype(int); by = ((G.y1 - np.arange(G.height) * 30) // 6000).astype(int)
hv = lambda a, b: int(hashlib.sha256(f"phase4-v1:{a}:{b}".encode()).hexdigest(), 16) % 100
pt_val = np.array([hv(bx[c], by[r]) < 30 for r, c in zip(K.row, K.col)])
chk("design_points_in_hashed_validation_blocks", pt_val.all(), n_not=int((~pt_val).sum()))
vb = rd(GOLD / "sampling_design/validation_blocks_30m.tif").astype(bool)
ubx, uby = np.unique(bx), np.unique(by); tab = np.array([[hv(a, b) < 30 for a in ubx] for b in uby]); vb_re = tab[np.searchsorted(uby, by)][:, np.searchsorted(ubx, bx)] & mask
chk("validation_block_raster_matches_reimplementation", bool((vb_re == vb).all()), n_diff=int((vb_re != vb).sum()))
blk_in = {}
for r_ in range(0, G.height, 200):
    sub = mask[r_:r_ + 200]; rows_ = by[r_:r_ + 200]
    for rr, ry in zip(sub, rows_):
        for cx in np.unique(bx[rr]): blk_in[(cx, ry)] = True
nb_in = len(blk_in); nv_in = sum(hv(a, b) < 30 for a, b in blk_in)
R["block_shares"] = {"blocks_in_bbox": int(tab.size), "val_share_of_bbox_blocks": float(tab.mean()), "blocks_intersecting_district": nb_in, "val_blocks_intersecting_district": int(nv_in),
                     "val_share_of_district_blocks": nv_in / nb_in, "val_share_of_district_area": float(vb[mask].mean())}
chk("block_share_numbers_reported", True, **R["block_shares"], doc_claim_blocks="27.6 %", doc_claim_area="26.7 %", design_json_blocks=design["validation_blocks_share_of_blocks"])
# Phase-3 windows + 2 km exclusion
win = np.zeros(G.shape, bool)
for w in ("khadakwasla_mutha", "baramati_agri", "mulshi_ghats"):
    gj = json.load(open(config.path("data/labels", f"pune_G30_{w}", "splits.json")))["grid"]; c0 = int(round((gj["x0"] - G.x0) / 30)); r0 = int(round((G.y1 - gj["y1"]) / 30))
    win[max(r0, 0):r0 + gj["height"], max(c0, 0):c0 + gj["width"]] = True
dwin = distance_transform_edt(~win) * 30
chk("design_points_outside_phase3_windows_plus_2km", bool((dwin[K.row, K.col] > 2000).all()), min_distance_m=float(dwin[K.row, K.col].min()))
# training eligibility and leakage buffer
te = rd(GOLD / "sampling_design/training_eligible_30m.tif").astype(bool)
dval = distance_transform_edt(~vb) * 30
chk("training_eligible_cells_ge_2km_from_validation_blocks", bool((dval[te] >= 2000 - 1e-6).all()), min_m=float(dval[te].min()), eligible_share=float(te[mask].mean()))
chk("training_eligible_disjoint_from_validation_blocks", not bool((te & vb).any()))
dte = distance_transform_edt(~te) * 30
chk("design_points_ge_2km_from_training_eligible", bool((dte[K.row, K.col] >= 2000).all()), min_m=float(dte[K.row, K.col].min()), median_m=float(np.median(dte[K.row, K.col])))
# strata, regions
st = rd(GOLD / "sampling_design/strata_30m.tif"); names = design["strata_priority_order"]
chk("design_stratum_matches_raster", bool((np.array(names)[st[K.row, K.col] - 1] == K.stratum.values).all()))
reg_re = np.where(K.rain_mm >= 1200, "wet_west_ge1200mm", np.where(K.rain_mm >= 700, "transition_700_1200mm", "dry_east_lt700mm"))
chk("design_region_matches_rain_rule", bool((reg_re == K.region.values).all()), counts=K.region.value_counts().to_dict())
# frame coverage per stratum (how much of each stratum's population the frame can see)
frame = vb & mask & (dwin > 2000)
cov = {nm: {"population_cells": int((st == i).sum()), "frame_cells": int(((st == i) & frame).sum()), "frame_share": float(((st == i) & frame).sum() / max(1, (st == i).sum())),
            "in_phase3_windows_plus_2km_share": float(((st == i) & (dwin <= 2000)).sum() / max(1, (st == i).sum()))} for i, nm in enumerate(names, 1)}
R["frame_coverage_by_stratum"] = cov
chk("frame_share_of_district", True, frame_share=float(frame[mask].mean()), design_json=design["frame_share_of_district"])
# blind forms vs key
chk("form_A_ids_equal_key", set(A.anon_id) == set(K.anon_id) and len(A) == len(K))
chk("form_B_is_double_subset", set(B.anon_id) == set(K.anon_id[K.double_interpretation]) and len(B) == int(K.double_interpretation.sum()), n_B=len(B), share=len(B) / len(K))
m = A.merge(K[["anon_id", "lat", "lon"]], on="anon_id", suffixes=("", "_k"))
chk("form_A_coordinates_equal_key", np.allclose(m.lat, m.lat_k) and np.allclose(m.lon, m.lon_k))
blind_cols = set(A.columns) | set(B.columns)
chk("blind_forms_contain_no_design_fields", not (blind_cols & {"stratum", "region", "block", "row", "col", "double_interpretation", "inclusion_prob_frame"}), columns=sorted(blind_cols)[:6])
chk("blind_forms_empty", A.drop(columns=["anon_id", "lat", "lon"]).isna().all().all() and B.drop(columns=["anon_id", "lat", "lon"]).isna().all().all())
kml = (GOLD / "blind/phase4_gold_cells.kml").read_text(); chk("kml_has_641_placemarks", kml.count("<Placemark>") == 641, n=kml.count("<Placemark>"))
chk("key_tracked_in_git_(blindness_by_process)", True, note="key is in the repository; blindness depends on giving interpreters only the blind/ folder")

# ---------------- 4. data on disk
prod = {}
for p in sorted(glob.glob(str(config.path("data/products_ext/*/*.tif")))) + sorted(glob.glob(str(config.path("data/labels/pune_G30/*.tif")))):
    with rasterio.open(p) as s: prod[str(Path(p).relative_to(config.ROOT))] = {"bytes": Path(p).stat().st_size, "shape": [s.count, s.height, s.width], "crs": str(s.crs), "res": s.res[0], "descriptions": list(s.descriptions)[:3]}
R["district_layers_on_disk"] = prod
chk("district_product_layers_present", len(prod) >= 10, n=len(prod))
gitignored = subprocess.run(["git", "check-ignore"] + list(prod), capture_output=True, text=True, cwd=config.ROOT).stdout.split()
R["district_layers_gitignored_regenerable"] = gitignored
cubes = {Path(p).stem: json.load(open(p)) for p in glob.glob(str(config.path("data/features/cube/*.json")))}
R["window_cubes"] = {k: {kk: v.get(kk) for kk in ("years", "n_features", "shape", "created_utc") if kk in v} for k, v in cubes.items()}
cov_ = json.load(open(config.path("data/inventory/coverage.json")))
chk("district_30m_cube_absent", cov_["district_30m_cube"] == "NOT BUILT" and not config.path("data/composites/pune_G30").exists(), windows_share=cov_["windows_share_of_district"])
C = pd.read_csv(config.path("data/inventory/composites.csv"))
R["composites_by_grid"] = C.groupby("grid").size().to_dict()
R["composites_files_present_by_grid"] = (C.files_present == C.files_declared).groupby(C.grid).mean().round(3).to_dict()
# ---------------- 5. access
try:
    from pune_eo.acquisition import auth; R["access"] = auth.check()
except Exception as e: R["access"] = {"error": repr(e)}
chk("planetary_computer_reachable", str(R["access"].get("planetary_computer", "")).startswith("OK"), status=R["access"].get("planetary_computer"))
chk("earth_engine_configured", str(R["access"].get("google_earth_engine", "")).startswith("OK"), status=R["access"].get("google_earth_engine"))
R["git_head"] = subprocess.run(["git", "rev-parse", "--short", "HEAD"], capture_output=True, text=True, cwd=config.ROOT).stdout.strip()
json.dump(R, open(OUT / "entry_checks.json", "w"), indent=1, default=str)
print("written", OUT / "entry_checks.json")
