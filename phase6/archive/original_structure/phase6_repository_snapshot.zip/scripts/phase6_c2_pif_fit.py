"""Phase 6 / decision D2: deterministic PIF fit of the Landsat TM -> OLI-equivalent transform for P4-C2@v2 (treatment arm), specified in
experiments/registry4/addenda/P4-C2_at_v2_addendum_1.json BEFORE this script was run. No gold label, no model, no validation block is touched.

Specification (identical to the addendum):
  pairs     selected manifest scenes, Landsat-5 (TM) x Landsat-7 (ETM+), same WRS-2 path/row, |dt| <= 8 days, months Jan-May, scene cloud <= 20 %, years 1999-2011
  grid      native 30 m pune_G30 (no resampling); QA/decoding exactly as the cube (repository loader; clear = status 2 in BOTH scenes)
  PIF cells pre-declared classes (P4-E1/P5-E2): water (JRC occurrence >= 95 and GLC_FCS30D water in all 26 epochs), forest (GLC_FCS30D forest 51-92 in all epochs),
            impervious (GLC_FCS30D 190 in all epochs and WSF first year 1985); each mask eroded 3x3; TRAINING-ELIGIBLE cells only (>= 2 km from every validation block)
  target    L7 reflectance AFTER local_pune_g30_v2 (the cube's OLI-equivalent space); predictor: raw TM reflectance
  sample    per pair and class at most 2000 cells (seed 20261141); pooled over pairs and classes
  estimator per band reduced major axis: b = sign(r) sd(y)/sd(x), a = mean(y) - b mean(x)
  CI        cluster bootstrap over TM acquisition days (2000 reps, seed 20261142)
  QA        leave-one-path/row-out prediction residual (reported, never used to choose)
  feasibility (fixed in advance): >= 15 TM acquisition days with >= 50 clear PIF cells, >= 500 pooled impervious cells, |r| >= 0.7 in every band;
            otherwise the treatment falls back to the published Roy et al. (2016) RMA ETM+->OLI coefficients applied to TM (addendum §fallback).
Output: results/harmonization/c2_tm_pif_v1.yaml (+ .sha256), results/phase6/d2/pif_fit_report.json."""
import hashlib, json, sys, time, warnings
from concurrent.futures import ThreadPoolExecutor
import numpy as np, pandas as pd, rasterio, geopandas as gpd, yaml
from scipy.ndimage import binary_erosion
sys.path.insert(0, "src"); warnings.filterwarnings("ignore")
from pune_eo import config
from pune_eo.grid import district_grid
from pune_eo.compositing import observations as obs
from pune_eo.harmonization import landsat as harm
from pune_eo.provenance import utcnow
G = district_grid("G30"); BANDS = obs.BAND_NAMES["landsat"]; TR = "local_pune_g30_v2"
OUT = config.path("results/phase6/d2"); OUT.mkdir(parents=True, exist_ok=True)
ADD = config.path("experiments/registry4/addenda/P4-C2_at_v2_addendum_1.json")
if not ADD.exists(): sys.exit("refusing to fit: the P4-C2@v2 addendum (fit specification) must be registered first")
add_sha = hashlib.sha256(ADD.read_bytes()).hexdigest()
def rd(p, b=None):
    with rasterio.open(p) as s: return s.read() if b is None else s.read(b)
PX = config.path("data/products_ext"); LB = config.path("data/labels/pune_G30")
glc = rd(PX / "glc_fcs30d/glc_fcs30d_district_30m.tif"); jrc = rd(LB / "jrc_gsw.tif", 1); wsf = rd(LB / "wsf_evolution_first_year.tif", 1)
elig = rd(config.path("data/labels/gold/phase4/sampling_design/training_eligible_30m.tif"), 1).astype(bool)
FOREST = [51, 52, 61, 62, 71, 72, 81, 82, 91, 92]
aw, af, ai = (np.ones(glc.shape[1:], bool) for _ in range(3))
for band in glc: aw &= band == 210; af &= np.isin(band, FOREST); ai &= band == 190
K3 = np.ones((3, 3), bool)
PIF = {"water": binary_erosion((jrc >= 95) & (jrc != 255) & aw, K3) & elig, "forest": binary_erosion(af, K3) & elig, "impervious": binary_erosion(ai & (wsf == 1985), K3) & elig}
del glc, jrc, wsf, aw, af, ai
CLS = np.zeros(G.shape, np.uint8)
for i, k in enumerate(PIF, 1): CLS[PIF[k]] = i
U = CLS > 0; UIDX = np.flatnonzero(U.ravel()); UCLS = CLS.ravel()[UIDX]; del PIF
counts = {k: int((UCLS == i).sum()) for i, k in enumerate(("water", "forest", "impervious"), 1)}; print("PIF cells (eroded, eligible):", counts)
m = gpd.read_parquet(config.path("data/manifests/landsat_manifest.parquet")); s = m[m.selected & (m.month <= 5) & (m.cloud_cover <= 20)].copy(); del m
s["d"] = pd.to_datetime(s.date); s["pr"] = s.wrs_path.astype(str) + "/" + s.wrs_row.astype(str)
A_, B_ = s[(s.platform == "landsat-5") & s.year.between(1999, 2011)], s[(s.platform == "landsat-7") & s.year.between(1999, 2011)]
P = A_.merge(B_, on="pr", suffixes=("_a", "_b")); P = P[(P.d_b - P.d_a).dt.days.abs() <= 8].sort_values(["d_a", "pr"]).reset_index(drop=True)
print(len(P), "pairs")
CACHE = config.path("data/raw/phase6_c2_pif_cache"); CACHE.mkdir(parents=True, exist_ok=True)
def load(pid):
    f = CACHE / f"{pid}.npz"
    if f.exists(): return pid, "cached"                      # memory: vectors are re-loaded per pair below (an all-in-memory run was OOM-killed)
    row = s[s.product_id == pid].iloc[0]
    for attempt in range(3):
        try:
            r = obs.landsat(row, G, None)
            if r is None: return pid, None
            w = r["win"]; r0, c0 = int(w.row_off), int(w.col_off); h, ww = r["values"].shape[1:]
            rr, cc = np.divmod(UIDX, G.width); inside = (rr >= r0) & (rr < r0 + h) & (cc >= c0) & (cc < c0 + ww)
            v = np.full((len(BANDS), len(UIDX)), np.nan, np.float32)
            vals = r["values"][:, rr[inside] - r0, cc[inside] - c0]; st = r["status"][rr[inside] - r0, cc[inside] - c0]
            vals[:, st != 2] = np.nan; v[:, inside] = vals; del r
            np.savez(f, v=v, plat=np.array(row["platform"])); del v; return pid, "cached"
        except Exception as e:
            err = repr(e); time.sleep(3)
    return pid, ("ERROR", err)
need = sorted(set(P.product_id_a) | set(P.product_id_b)); t0 = time.time()
with ThreadPoolExecutor(2) as ex: DATA = dict(ex.map(load, need))
bad = lambda v: v != "cached"
print(f"read {len(DATA)} scenes in {time.time() - t0:.0f}s; missing/errors {sum(bad(v) for v in DATA.values())}")
def get(pid):
    z = np.load(CACHE / f"{pid}.npz"); return z["v"], str(z["plat"])
rng = np.random.default_rng(20261141); rows = []
for _, r in P.iterrows():
    if bad(DATA.get(r.product_id_a)) or bad(DATA.get(r.product_id_b)): continue
    a, b = get(r.product_id_a), get(r.product_id_b)
    xa = a[0]; xb = np.stack([harm.apply({bn: b[0][i]}, b[1], TR)[bn] for i, bn in enumerate(BANDS)])
    ok = np.isfinite(xa).all(0) & np.isfinite(xb).all(0)
    for ci, cn in enumerate(("water", "forest", "impervious"), 1):
        idx = np.flatnonzero(ok & (UCLS == ci))
        if len(idx) > 2000: idx = np.sort(rng.choice(idx, 2000, replace=False))
        for j in idx: rows.append((str(r.d_a.date()), r.pr, cn, *xa[:, j], *xb[:, j]))
D = pd.DataFrame(rows, columns=["day_a", "pr", "pif"] + [f"tm_{b}" for b in BANDS] + [f"l7h_{b}" for b in BANDS])
D.to_parquet(OUT / "pif_fit_sample.parquet", index=False)
def rma(x, y):
    r = np.corrcoef(x, y)[0, 1]; bb = np.sign(r) * np.std(y) / np.std(x); return float(y.mean() - bb * x.mean()), float(bb), float(r)
day_n = D.groupby("day_a").size(); n_days = int((day_n >= 50).sum()); n_imp = int((D.pif == "impervious").sum())
coef = {bn: rma(D[f"tm_{bn}"].values, D[f"l7h_{bn}"].values) for bn in BANDS}
feasible = n_days >= 15 and n_imp >= 500 and all(abs(c[2]) >= 0.7 for c in coef.values())
days = D.day_a.unique(); idx_by_day = {d: np.flatnonzero(D.day_a.values == d) for d in days}; ci = {}
brng = np.random.default_rng(20261142)
for bn in BANDS:
    x, y = D[f"tm_{bn}"].values, D[f"l7h_{bn}"].values; bs = []
    for _ in range(2000):
        ii = np.concatenate([idx_by_day[d] for d in brng.choice(days, len(days))]); a_, b_, _ = rma(x[ii], y[ii]); bs.append((a_, b_))
    bs = np.array(bs); ci[bn] = {"intercept": [float(np.percentile(bs[:, 0], 2.5)), float(np.percentile(bs[:, 0], 97.5))], "slope": [float(np.percentile(bs[:, 1], 2.5)), float(np.percentile(bs[:, 1], 97.5))]}
lopo = {}
for pr in sorted(D.pr.unique()):
    tr, te = D[D.pr != pr], D[D.pr == pr]
    if len(te) < 100 or len(tr) < 100: continue
    lopo[pr] = {bn: float(np.median((rma(tr[f"tm_{bn}"].values, tr[f"l7h_{bn}"].values)[0] + rma(tr[f"tm_{bn}"].values, tr[f"l7h_{bn}"].values)[1] * te[f"tm_{bn}"].values) - te[f"l7h_{bn}"].values)) for bn in BANDS}
    lopo[pr]["identity_median_residual"] = {bn: float(np.median(te[f"tm_{bn}"].values - te[f"l7h_{bn}"].values)) for bn in BANDS}
loc = yaml.safe_load(open(config.path("results/harmonization/local_pune_g30_v2.yaml")))["per_platform"]["landsat-7"]
ROY_RMA = {"blue": (-0.0095, 0.9785), "green": (-0.0016, 0.9542), "red": (-0.0022, 0.9825), "nir08": (-0.0021, 1.0073), "swir16": (-0.0030, 1.0171), "swir22": (0.0029, 0.9949)}
report = {"created_utc": utcnow(), "addendum_sha256": add_sha, "n_pairs_planned": int(len(P)), "n_pairs_used": int(D.groupby(["day_a", "pr"]).ngroups), "n_tm_days_ge50": n_days,
          "n_cells": {k: int((D.pif == k).sum()) for k in ("water", "forest", "impervious")}, "feasible": bool(feasible),
          "coefficients_rma": {bn: {"intercept": c[0], "slope": c[1], "r": c[2]} for bn, c in coef.items()}, "cluster_bootstrap_ci": ci,
          "leave_one_path_row_out_median_residual": lopo, "reflectance_range_tm": {bn: [float(D[f"tm_{bn}"].quantile(q)) for q in (0.01, 0.5, 0.99)] for bn in BANDS},
          "descriptive_comparison_not_used_to_choose": {"local_pune_g30_v2_landsat7": {bn: {"intercept": loc["intercept"][bn], "slope": loc["slope"][bn]} for bn in BANDS},
                                                        "roy2016_rma_etm_to_oli": {bn: {"intercept": a_, "slope": b_} for bn, (a_, b_) in ROY_RMA.items()}}}
if feasible:
    T = {"name": "c2_tm_pif_v1", "description": "P4-C2@v2 treatment: local_pune_g30_v2 for landsat-7/8/9 unchanged; landsat-5 and landsat-4 mapped to the cube's OLI-equivalent space by a PIF-fitted RMA",
         "created_utc": utcnow(), "addendum": str(ADD.relative_to(config.ROOT)), "addendum_sha256": add_sha, "base_transform": TR,
         "per_platform": {**{p: v for p, v in yaml.safe_load(open(config.path("results/harmonization/local_pune_g30_v2.yaml")))["per_platform"].items()},
                          **{p: {"slope": {bn: coef[bn][1] for bn in BANDS}, "intercept": {bn: coef[bn][0] for bn in BANDS}} for p in ("landsat-5", "landsat-4")}},
         "fit": {k: report[k] for k in ("n_pairs_used", "n_tm_days_ge50", "n_cells", "cluster_bootstrap_ci")}}
else:
    T = {"name": "c2_tm_roy2016_v1", "description": "P4-C2@v2 treatment (pre-declared FALLBACK, PIF fit infeasible): Roy et al. 2016 Table 2 RMA ETM+->OLI applied to landsat-5/4; local_pune_g30_v2 unchanged for landsat-7/8/9",
         "created_utc": utcnow(), "addendum": str(ADD.relative_to(config.ROOT)), "addendum_sha256": add_sha, "base_transform": TR,
         "per_platform": {**yaml.safe_load(open(config.path("results/harmonization/local_pune_g30_v2.yaml")))["per_platform"],
                          **{p: {"slope": {bn: ROY_RMA[bn][1] for bn in BANDS}, "intercept": {bn: ROY_RMA[bn][0] for bn in BANDS}} for p in ("landsat-5", "landsat-4")}}}
fn = config.path("results/harmonization", f"{T['name']}.yaml"); txt = yaml.safe_dump(T, sort_keys=False); fn.write_text(txt)
sha = hashlib.sha256(txt.encode()).hexdigest(); fn.with_suffix(".sha256").write_text(sha + f"  {fn.name}\n"); report["transform_file"] = str(fn.relative_to(config.ROOT)); report["transform_sha256"] = sha
(OUT / "pif_fit_report.json").write_text(json.dumps(report, indent=1)); print(json.dumps({k: report[k] for k in ("n_pairs_used", "n_tm_days_ge50", "n_cells", "feasible", "transform_file")}, indent=1))
print(json.dumps(report["coefficients_rma"], indent=1))
