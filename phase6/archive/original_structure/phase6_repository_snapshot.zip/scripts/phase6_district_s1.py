"""Phase 6: district Sentinel-1 RTC composites on pune_G30 (needed by P4-C6@v2: S1F = VV/VH dry, VH wet, VH-VV ratio, VV min and VH sd over >= 6 months).
Same engine as the window cubes (src/pune_eo/compositing: observations.sentinel1 loader, engine.reduce_period, lean_writer for district-size products):
  source    Planetary Computer `sentinel-1-rtc` (gamma0, radiometrically terrain corrected, linear power, 10 m posting), IW, VV + VH (configs/sentinel1.yaml)
  geometry  manifest selection keeps one orbit direction per year (2020: all 107 selected scenes descending); no incidence-angle normalisation beyond RTC
  to 30 m   area average of linear gamma0 (GDAL 'average' from 10 m onto the Landsat lattice; no interpolation), i.e. ~3x3 multi-look; no other speckle filter
  composite per period: mean in LINEAR power -> dB, median and temporal std in dB; count of valid observations; invalid/<=0 values are missing (never filled)
  periods   annual, dry (Jan-May), wet (Jun-Sep), post-monsoon (Oct-Dec), 12 months (the feature cube needs dry, wet and >= 6 monthly composites)
Row strips bound memory; intermediate per-strip reductions need ~1 GB per period on disk (~16 GB for 16 periods) - run on the Route-A machine (docs/phase6_D3_compute_decision.md).
Output: data/composites/pune_G30/<year>/sentinel1/{annual,seasonal/<s>,monthly/<YYYY-MM>}/ ; status results/phase6/s1/."""
import argparse, json, logging, math, shutil, sys, time, warnings
import numpy as np
sys.path.insert(0, "src"); warnings.filterwarnings("ignore")
from rasterio.windows import Window
import pandas as pd
from pune_eo import config
from pune_eo.grid import district_grid
from pune_eo.compositing import engine as E, lean_writer as LW
from pune_eo.compositing.periods import standard_periods
from pune_eo.io import write_json
from pune_eo.provenance import utcnow
logging.basicConfig(level=logging.INFO, format="%(asctime)s %(levelname)s %(message)s"); log = logging.getLogger("s1")
ap = argparse.ArgumentParser(); ap.add_argument("--year", type=int, default=2020); ap.add_argument("--threads", type=int, default=4); ap.add_argument("--min-strips", type=int, default=16); a = ap.parse_args()
G = district_grid("G30"); MAN = E.load_manifest("sentinel1"); CUT = pd.to_datetime(MAN["archive_cutoff_utc"].iloc[0]); inside = E.district_mask(G)
WORK = config.path("data/raw/ard_cache/phase6_s1", str(a.year)); STATUS = config.path("results/phase6/s1"); STATUS.mkdir(parents=True, exist_ok=True)
PER = standard_periods(a.year, include_months=True); items = MAN[MAN["year"] == a.year]
n_strips = max(a.min_strips, math.ceil(len(items) / 8)); edges = np.linspace(0, G.height, n_strips + 1).astype(int); t0 = time.time()
log.info("S1 %d: %d scenes (%s), %d strips", a.year, len(items), items["orbit_state"].value_counts().to_dict(), n_strips)
for s in range(n_strips):
    win = Window(0, int(edges[s]), G.width, int(edges[s + 1] - edges[s])); mf = WORK / f"strip{s}_metas.json"
    reds = {P.relpath: WORK / f"strip{s}_{P.relpath.replace('/', '_')}.npz" for P in PER}
    if mf.exists() and all(r.exists() for r in reds.values()): continue
    cache = WORK / f"cache_strip{s}"; plog = []
    metas = E.stage1("sentinel1", items, G, win, cache, a.threads, plog)
    for P in PER:
        pm = [m for m in metas if int(m["date"][5:7]) in P.months]; np.savez(reds[P.relpath], **E.reduce_period("sentinel1", pm, cache, win, None))
    json.dump(metas, open(mf, "w")); json.dump(plog, open(WORK / f"strip{s}_plog.json", "w")); shutil.rmtree(cache, ignore_errors=True)
    log.info("strip %d/%d (%d obs) %.0fs", s + 1, n_strips, len(metas), time.time() - t0)
per_item = {}
for s in range(n_strips):
    for m in json.load(open(WORK / f"strip{s}_metas.json")):
        q = per_item.setdefault(m["item_id"], {**m, "n_clear_px": 0, "n_observed_px": 0}); q["n_clear_px"] += m["n_clear_px"]; q["n_observed_px"] += m["n_observed_px"]
metas_y = sorted(per_item.values(), key=lambda m: m["date"]); summ = {}
for P in PER:
    out = config.path("data/composites", G.id, str(a.year), "sentinel1", P.relpath)
    strips = [(int(edges[s]), int(edges[s + 1]), WORK / f"strip{s}_{P.relpath.replace('/', '_')}.npz") for s in range(n_strips)]
    meta = LW.write_products_from_strips("sentinel1", P, G, strips, inside, [m for m in metas_y if int(m["date"][5:7]) in P.months], out, CUT, None,
                                         {"processing": E.processing_block("sentinel1", G) | {"driver": "scripts/phase6_district_s1.py (row strips, lean writer)", "n_strips": n_strips}})
    summ[P.relpath] = {k: meta["statistics"][k] for k in ("district_valid_fraction", "n_clear_median", "n_items")}
write_json(STATUS / f"s1_{a.year}.json", {"year": a.year, "n_items": int(len(items)), "orbit_states": items["orbit_state"].value_counts().to_dict(), "periods": summ, "seconds": round(time.time() - t0, 1), "finished_utc": utcnow(),
                                           "failed_items": [p for s in range(n_strips) for p in json.load(open(WORK / f"strip{s}_plog.json")) if p.get("status") == "failed"]})
shutil.rmtree(WORK, ignore_errors=True); log.info("done")
