"""P5-X2 and P5-X3 (EXPLORATORY, pre-registered by scripts/phase5_register.py). No product is treated as ground truth; agreement is never called accuracy.
P5-X3: district/region built share of the Tier-B built products per epoch -> the G5 reference envelope, FROZEN (SHA-256) before any district model prediction exists.
P5-X2: L1 no-consensus share (GLC_FCS30D vs Esri vs WorldCover, 2020) by pre-declared descriptors: class boundary (registered definition + a leave-one-product-out
       robustness version fixed before running), settlement context (urban core / fringe / rural), rainfall region x slope; pairwise per-class conditional agreement."""
import hashlib, json, os, sys, tempfile, warnings
import numpy as np, rasterio
from rasterio.enums import Resampling
from scipy.ndimage import distance_transform_edt, maximum_filter, minimum_filter
sys.path.insert(0, "src"); warnings.filterwarnings("ignore")
from pune_eo import config
from pune_eo.grid import district_grid
from pune_eo.labels import sources as SRC
from pune_eo.evaluation4 import protocol as P4
from pune_eo.provenance import utcnow
G = district_grid("G30"); PX = config.path("data/products_ext"); LB = config.path("data/labels/pune_G30"); OUT = config.path("results/phase5/benchmark"); OUT.mkdir(parents=True, exist_ok=True)
def rd(p, b=1):
    with rasterio.open(p) as s: return s.read(b)
mask = rd(PX / "district/district_mask_30m.tif").astype(bool); CELL_KM2 = 0.0009; AREA = float(mask.sum() * CELL_KM2)
with rasterio.open(config.path("data/processed/climate/chirps_v2_monthly_stack.tif")) as s:
    idx = [i + 1 for i, d in enumerate(s.descriptions) if d and 1991 <= int(d[:4]) <= 2020]; tot = sum(np.nan_to_num(s.read(i).astype(float)) for i in idx) / 30.0; prof = s.profile
tmp = tempfile.NamedTemporaryFile(suffix=".tif", delete=False).name; prof.update(count=1, dtype="float32", nodata=-1)
with rasterio.open(tmp, "w", **prof) as d: d.write(tot.astype(np.float32), 1)
rain = SRC._warp(tmp, G, Resampling.bilinear, dst_nodata=-1, dtype="float32", sign=False); os.unlink(tmp)
region = np.where(rain >= 1200, 1, np.where(rain >= 700, 2, 3)).astype(np.uint8); del rain
RN = {1: "wet_west_ge1200mm", 2: "transition_700_1200mm", 3: "dry_east_lt700mm"}

# ------------------------------------------------------------------ P5-X3 envelope
run3 = P4.Run("P5-X3")
wsf = rd(LB / "wsf_evolution_first_year.tif"); gisa = rd(PX / "gisa/gisa2_first_year_district_30m.tif")
with rasterio.open(PX / "glc_fcs30d/glc_fcs30d_district_30m.tif") as s: gy = [int(d) for d in s.descriptions]; glc = {e: s.read(gy.index(e) + 1) == 190 for e in (1990, 2000, 2010, 2020)}
with rasterio.open(LB / "ghsl_built_fraction_90m.tif") as s: gdesc = list(s.descriptions); gh = {e: s.read(gdesc.index(f"built_frac_{e}") + 1).astype(np.float32) for e in (1990, 2000, 2010, 2020)}
def up90(a):
    a = np.repeat(np.repeat(a, 3, 0), 3, 1)[:G.height, :G.width]; return np.pad(a, ((0, G.height - a.shape[0]), (0, G.width - a.shape[1])), constant_values=np.nan)
env = {"created_utc": utcnow(), "definition": "district (or region) built share = built area / land area of the 30 m district cells; GHSL as fraction-weighted surface; WSF and GISA as first-year <= epoch; GLC_FCS30D class 190",
       "tier_B_products": ["WSF_Evolution", "GHSL_BUILT_S", "GISA_2.0", "GLC_FCS30D_impervious"], "g5_tolerance_abs": 0.02, "epochs": {}}
for e in (1990, 2000, 2010, 2020):
    prods = {"GISA_2.0": (gisa > 0) & (gisa <= e), "GLC_FCS30D_impervious": glc[e]}
    if e <= 2015: prods["WSF_Evolution"] = (wsf > 0) & (wsf <= e)
    ghf = np.nan_to_num(up90(gh[e]), nan=0.0)
    rec = {"district": {}, "regions": {}}
    for scope, m in [("district", mask)] + [(RN[k], mask & (region == k)) for k in RN]:
        n = int(m.sum()); sh = {p: float(v[m].sum() / n) for p, v in prods.items()}; sh["GHSL_BUILT_S"] = float(ghf[m].sum() / n)
        r = {"shares": sh, "min": min(sh.values()), "max": max(sh.values()), "min_product": min(sh, key=sh.get), "max_product": max(sh, key=sh.get),
             "envelope_with_tolerance": [max(0.0, min(sh.values()) - 0.02), max(sh.values()) + 0.02], "land_km2": n * CELL_KM2, "km2": {p: v * n * CELL_KM2 for p, v in sh.items()}}
        if scope == "district": rec["district"] = r
        else: rec["regions"][scope] = r
    if e > 2015: rec["note"] = "WSF-Evolution ends in 2015 and is not part of the 2020 envelope"
    env["epochs"][e] = rec
del wsf, gisa, glc, gh
f3 = OUT / "g5_built_envelope_frozen.json"; txt = json.dumps(env, indent=1, sort_keys=True); f3.write_text(txt); env_sha = hashlib.sha256(txt.encode()).hexdigest()
(OUT / "g5_built_envelope_frozen.sha256").write_text(env_sha + "  g5_built_envelope_frozen.json\n")
run3.complete({str(e): {"min": v["district"]["min"], "max": v["district"]["max"], "min_product": v["district"]["min_product"], "max_product": v["district"]["max_product"]} for e, v in env["epochs"].items()} | {"sha256": env_sha}, "NA",
              "district built-share envelope (Tier B): " + "; ".join(f"{e}: {v['district']['min']:.4f}-{v['district']['max']:.4f} ({v['district']['min_product']}..{v['district']['max_product']})" for e, v in env["epochs"].items()),
              outputs={"envelope": str(f3.relative_to(config.ROOT)), "sha256": env_sha})
print("P5-X3", {e: (round(v["district"]["min"], 4), round(v["district"]["max"], 4)) for e, v in env["epochs"].items()})

# ------------------------------------------------------------------ P5-X2 disagreement descriptors
run2 = P4.Run("P5-X2")
GLC_L1 = {10: 2, 11: 2, 12: 2, 20: 2, **{c: 3 for c in (51, 52, 61, 62, 71, 72, 81, 82, 91, 92, 120, 121, 122, 130, 140)}, 150: 5, 152: 5, 153: 5, **{c: 6 for c in range(181, 188)}, 190: 1, 200: 5, 201: 5, 202: 5, 210: 4, 220: 6}
cw = config.load("labels")["crosswalks"]
def l1(a, table):
    out = np.zeros(a.shape, np.uint8)
    for k, v in table.items(): out[a == int(k)] = v
    return out
with rasterio.open(PX / "glc_fcs30d/glc_fcs30d_district_30m.tif") as s: P = {"GLC_FCS30D": l1(s.read(gy.index(2020) + 1), GLC_L1)}
with rasterio.open(PX / "esri/esri_district_30m_mode.tif") as s: ey = [int(d) for d in s.descriptions]; P["Esri"] = l1(s.read(ey.index(2020) + 1), cw["esri_lulc"])
with rasterio.open(PX / "worldcover/worldcover_district_30m_mode.tif") as s: wy = [int(d) for d in s.descriptions]; P["WorldCover"] = l1(s.read(wy.index(2020) + 1), cw["esa_worldcover"])
valid = mask & np.all([p > 0 for p in P.values()], axis=0)
nocons = ~((P["GLC_FCS30D"] == P["Esri"]) & (P["Esri"] == P["WorldCover"]))
def boundary(a): return (maximum_filter(a, 3) != minimum_filter(a, 3))
B = {k: boundary(v) for k, v in P.items()}
share = lambda m: {"share": float(nocons[m & valid].mean()) if (m & valid).any() else None, "area_share": float((m & valid).sum() / valid.sum())}
R = {"district_no_consensus_share": float(nocons[valid].mean()), "n_cells": int(valid.sum())}
anyb = B["GLC_FCS30D"] | B["Esri"] | B["WorldCover"]
R["class_boundary_registered"] = {"boundary_in_any_product": share(anyb), "interior_in_all_products": share(~anyb)}
lopo = {}
for k in P:                                       # robustness: boundary from product k; disagreement between the OTHER two products
    o = [x for x in P if x != k]; dis = P[o[0]] != P[o[1]]
    lopo[k] = {"boundary": float(dis[B[k] & valid].mean()), "interior": float(dis[~B[k] & valid].mean()), "pair": f"{o[0]} vs {o[1]}"}
R["class_boundary_leave_one_product_out"] = lopo
with rasterio.open(LB / "ghsl_built_fraction_90m.tif") as s: gh20 = np.nan_to_num(up90(s.read(gdesc.index("built_frac_2020") + 1).astype(np.float32)), nan=0.0)
wsf = rd(LB / "wsf_evolution_first_year.tif"); settled = (wsf > 0) & (wsf <= 2015); del wsf
dset = distance_transform_edt(~settled) * 30.0; core = gh20 >= 0.3; del gh20
R["settlement_context"] = {"urban_core_ghsl2020_ge0.3": share(core), "fringe_le1km_from_wsf2015_not_core": share(~core & (dset <= 1000)), "rural_gt1km": share(~core & (dset > 1000))}
del dset
dem = rd(PX / "dem/copdem30_district_30m.tif").astype(np.float32); dem[dem == -9999] = np.nan
gyy, gxx = np.gradient(np.nan_to_num(dem, nan=float(np.nanmedian(dem))), 30.0); slope = np.degrees(np.arctan(np.hypot(gxx, gyy))).astype(np.float32); del gyy, gxx, dem
sc = {"lt3deg": slope < 3, "3_8deg": (slope >= 3) & (slope < 8), "ge8deg": slope >= 8}; del slope
R["region_x_slope"] = {f"{RN[k]}|{sn}": share((region == k) & m) for k in RN for sn, m in sc.items()}
names = {1: "built_up", 2: "agriculture", 3: "natural_vegetation", 4: "water", 5: "bare_sparse", 6: "other"}; pc = {}
for a_ in P:
    for b_ in P:
        if a_ >= b_: continue
        for c, nm in names.items():
            ma, mb = valid & (P[a_] == c), valid & (P[b_] == c)
            if ma.sum() < 100 or mb.sum() < 100: continue
            both = (ma & mb).sum(); pc[f"{a_}~{b_}|{nm}"] = {f"P({b_}={nm} | {a_}={nm})": float(both / ma.sum()), f"P({a_}={nm} | {b_}={nm})": float(both / mb.sum()),
                                                            f"area_km2_{a_}": float(ma.sum() * CELL_KM2), f"area_km2_{b_}": float(mb.sum() * CELL_KM2)}
R["pairwise_conditional_agreement_not_accuracy"] = pc
json.dump(R, open(OUT / "disagreement_descriptors_p5x2.json", "w"), indent=1)
summ = (f"no-consensus {R['district_no_consensus_share']:.3f}; boundary(any) {R['class_boundary_registered']['boundary_in_any_product']['share']:.3f} vs interior {R['class_boundary_registered']['interior_in_all_products']['share']:.3f}; "
        + "LOPO " + ", ".join(f"{k}: {v['boundary']:.3f}/{v['interior']:.3f}" for k, v in lopo.items()) + "; context " + ", ".join(f"{k.split('_')[0]} {v['share']:.3f}" for k, v in R["settlement_context"].items()))
run2.complete({"district_no_consensus_share": R["district_no_consensus_share"], "boundary_any": R["class_boundary_registered"], "lopo": lopo, "settlement_context": R["settlement_context"]}, "NA", summ,
              outputs={"summary": "results/phase5/benchmark/disagreement_descriptors_p5x2.json"})
print("P5-X2", summ)
