"""Phase-5 figures (figures/phase5/) from saved results only (no recomputation of any number). Palette and style as the Phase-4 figures."""
import json, sys, warnings
import numpy as np, pandas as pd, rasterio
import matplotlib; matplotlib.use("Agg"); import matplotlib.pyplot as plt
from matplotlib.colors import ListedColormap, BoundaryNorm
sys.path.insert(0, "src"); warnings.filterwarnings("ignore")
from pune_eo import config
OUT = config.path("figures/phase5"); OUT.mkdir(parents=True, exist_ok=True)
CAT = ["#2a78d6", "#eb6834", "#1baf7a", "#eda100", "#e87ba4", "#008300", "#4a3aa7", "#e34948"]; INK, MUTED = "#0b0b0b", "#52514e"
plt.rcParams.update({"font.size": 8, "axes.spines.top": False, "axes.spines.right": False, "axes.edgecolor": MUTED, "axes.labelcolor": INK, "xtick.color": MUTED, "ytick.color": MUTED,
                     "axes.grid": True, "grid.color": "#e6e5e0", "grid.linewidth": 0.6, "figure.dpi": 150, "legend.frameon": False})
done, skipped = [], []
def fig(name):
    def deco(f):
        try: f(); plt.savefig(OUT / f"{name}.png", bbox_inches="tight", facecolor="#fcfcfb"); plt.close("all"); done.append(name)
        except Exception as e: plt.close("all"); skipped.append((name, repr(e)[:200]))
    return deco
J = lambda p: json.loads(config.path(p).read_text())

@fig("P5F1_observation_support")
def _():
    T = pd.read_csv(config.path("results/phase5/observation_support/support_240m_by_year_season.csv"), index_col=0); S = J("results/phase5/observation_support/observation_support.json")
    f, ax = plt.subplots(figsize=(9, 3.4))
    for i, (p, lab) in enumerate((("dry", "dry Jan-May (240 m)"), ("post_monsoon", "post-monsoon Oct-Dec (240 m)"), ("wet", "wet Jun-Sep (240 m)"))):
        ax.plot(T.index, T[f"reliable_fraction_ge3|{p}"], color=CAT[i], lw=2, label=lab)
    g = {int(y): v for y, v in S["g30_key_epochs_dry"].items() if isinstance(v, dict)}
    ax.scatter(list(g), [v["district"]["reliable_fraction_ge3"] for v in g.values()], color=INK, zorder=5, s=28, marker="D", label="dry, 30 m key-epoch pilot")
    ax.axhline(0.8, color=CAT[7], ls="--", lw=1); ax.text(1990.2, 0.82, "G1 rule: annual claims need >= 3 clear obs over >= 80 % of the district", color=CAT[7], fontsize=7)
    ax.set_ylim(-0.02, 1.05); ax.set_xlabel("year"); ax.set_ylabel("share of district with >= 3 clear observations"); ax.legend(fontsize=7, loc="lower right", ncol=2)
    ax.set_title("Observation support 1990-2026 (P5-X1): dry season mostly sufficient; post-monsoon rarely before 2013; wet season almost never", fontsize=9)

@fig("P5F2_pilot_nclear_maps")
def _():
    ys = [y for y in (1990, 2000, 2010, 2020) if config.path("data/composites/pune_G30", str(y), "landsat/seasonal/dry/observation_count.tif").exists()]
    f, ax = plt.subplots(1, len(ys), figsize=(3.2 * len(ys), 3.2))
    ax = np.atleast_1d(ax); cmap = ListedColormap(["#d9d8d3", CAT[7], CAT[3], "#9fd3bd", CAT[2], CAT[5]]); norm = BoundaryNorm([0, 1, 2, 3, 6, 11, 99], cmap.N)
    for a, y in zip(ax, ys):
        with rasterio.open(config.path("data/composites/pune_G30", str(y), "landsat/seasonal/dry/observation_count.tif")) as s: n = s.read(1, out_shape=(s.height // 6, s.width // 6))
        with rasterio.open(config.path("data/products_ext/district/district_mask_30m.tif")) as s: m = s.read(1, out_shape=(s.height // 6, s.width // 6)).astype(bool)
        im = a.imshow(np.ma.masked_where(~m, n), cmap=cmap, norm=norm, interpolation="nearest"); a.set_title(f"{y} dry season", fontsize=8); a.set_xticks([]); a.set_yticks([]); a.grid(False); [sp_.set_visible(False) for sp_ in a.spines.values()]
    cb = f.colorbar(im, ax=list(ax), shrink=0.8, ticks=[0.5, 1.5, 2.5, 4.5, 8.5, 50]); cb.ax.set_yticklabels(["0", "1", "2", "3-5", "6-10", ">10"]); cb.set_label("clear Landsat observations (30 m)")
    f.suptitle("District 30 m key-epoch pilot: clear-observation counts per cell (Planetary Computer, repository engine)", fontsize=9)

@fig("P5F3_disagreement_descriptors")
def _():
    R = J("results/phase5/benchmark/disagreement_descriptors_p5x2.json"); f, ax = plt.subplots(1, 2, figsize=(11, 3.2))
    lab, val, col = [], [], []
    b = R["class_boundary_registered"]; lab += ["boundary (any product)", "interior (all products)"]; val += [b["boundary_in_any_product"]["share"], b["interior_in_all_products"]["share"]]; col += [CAT[1], CAT[0]]
    for k, v in R["class_boundary_leave_one_product_out"].items(): lab += [f"{k} boundary: {v['pair']}", f"{k} interior: {v['pair']}"]; val += [v["boundary"], v["interior"]]; col += [CAT[1], CAT[0]]
    ax[0].barh(range(len(val)), val, color=col); ax[0].set_yticks(range(len(val))); ax[0].set_yticklabels(lab, fontsize=6.5); ax[0].invert_yaxis(); ax[0].set_xlabel("share of cells where products disagree")
    ax[0].set_title("class boundary vs interior (registered + leave-one-product-out)", fontsize=8)
    c = R["settlement_context"]; ks = list(c); ax[1].bar(range(len(ks)), [c[k]["share"] for k in ks], color=[CAT[6], CAT[3], CAT[2]])
    ax[1].set_xticks(range(len(ks))); ax[1].set_xticklabels(["urban core\n(GHSL 2020 >= 0.3)", "fringe\n(<= 1 km of WSF 2015)", "rural\n(> 1 km)"], fontsize=7)
    ax[1].axhline(R["district_no_consensus_share"], color=MUTED, ls=":", lw=1); ax[1].set_ylabel("no-consensus share"); ax[1].set_title("settlement context (dotted: district 0.40)", fontsize=8)
    f.suptitle("Where existing products disagree (P5-X2, exploratory; agreement is not accuracy)", fontsize=9)

@fig("P5F4_g5_envelope")
def _():
    E = J("results/phase5/benchmark/g5_built_envelope_frozen.json")["epochs"]; ys = sorted(int(y) for y in E); f, ax = plt.subplots(figsize=(7, 3.4))
    prods = ["WSF_Evolution", "GHSL_BUILT_S", "GISA_2.0", "GLC_FCS30D_impervious"]
    lo = [E[str(y)]["district"]["envelope_with_tolerance"][0] for y in ys]; hi = [E[str(y)]["district"]["envelope_with_tolerance"][1] for y in ys]
    ax.fill_between(ys, lo, hi, color="#e6e5e0", label="G5 acceptance band (min-max +- 0.02)")
    for i, p in enumerate(prods):
        pts = [(y, E[str(y)]["district"]["shares"][p]) for y in ys if p in E[str(y)]["district"]["shares"]]
        ax.plot([a for a, _ in pts], [b for _, b in pts], marker="o", color=CAT[i], lw=1.8, label=p.replace("_", " "))
    ax.set_xticks(ys); ax.set_ylabel("district built share"); ax.legend(fontsize=7, loc="upper left"); ax.set_title("G5 built-up reference envelope, frozen before any district prediction (P5-X3)", fontsize=9)

@fig("P5F5_sensor_pairs")
def _():
    S = pd.read_csv(config.path("results/phase5/sensor_pairs/contrast_summary.csv")); bands = ["red", "nir08", "swir16", "ndvi"]
    S["lab"] = S.contrast.str.replace("E2ab_", "").str.replace("E2c2_", "").str.replace("E2c_", "").str.replace("E2d_", "") + " / " + S.variant
    f, ax = plt.subplots(1, len(bands), figsize=(13, 3.6), sharey=True)
    for j, b in enumerate(bands):
        d = S[S.band == b].reset_index(drop=True)
        for i, r in d.iterrows():
            if b == "ndvi" and r.pif == "water_pif": continue          # water NDVI = ratio of near-zero reflectances: unstable, omitted
            ax[j].errorbar(r.mean_diff, i, xerr=[[r.mean_diff - r.ci_lo], [r.ci_hi - r.mean_diff]], fmt="o", color={"forest_pif": CAT[2], "water_pif": CAT[0], "impervious_pif": CAT[1]}[r.pif], ms=4)
        ax[j].axvline(0, color=MUTED, lw=1); ax[j].set_title(b, fontsize=8); ax[j].set_yticks(range(len(d))); ax[j].set_yticklabels([f"{l} | {p.replace('_pif', '')} (n={n})" for l, p, n in zip(d.lab, d.pif, d.n_pairs)], fontsize=6)
    ax[0].set_xlabel("sensor a minus sensor b (reflectance / NDVI)"); ax[-1].set_xlabel("NDVI (forest PIF only; water NDVI unstable, omitted)")
    f.suptitle("Near-coincident cross-sensor pairs (8 days, same path/row) on pseudo-invariant targets, P5-E2 (exploratory): mean of per-pair medians, pair-bootstrap 95 % CI", fontsize=8.5)

@fig("P5F6_gold_and_T1_design")
def _():
    K = pd.read_csv(config.path("data/labels/gold/phase4/_key/phase4_gold_key.csv")); T = pd.read_csv(config.path("data/labels/training/phase5_T1/_key/phase5_T1_key.csv"))
    with rasterio.open(config.path("data/labels/gold/phase4/sampling_design/validation_blocks_30m.tif")) as s: vb = s.read(1, out_shape=(s.height // 8, s.width // 8)); tr = s.transform; W, H = s.width, s.height
    with rasterio.open(config.path("data/labels/gold/phase4/sampling_design/training_eligible_30m.tif")) as s: te = s.read(1, out_shape=(s.height // 8, s.width // 8))
    f, ax = plt.subplots(figsize=(7, 6)); ext = [tr.c, tr.c + tr.a * W, tr.f + tr.e * H, tr.f]
    img = np.where(vb > 0, 2, np.where(te > 0, 1, 0)); ax.imshow(np.ma.masked_equal(img, 0), cmap=ListedColormap(["#e8f1fb", "#f6e3d8"]), vmin=1, vmax=2, extent=ext, interpolation="nearest")
    ax.scatter(K.x_utm, K.y_utm, s=7, color=CAT[7], label=f"gold design v2 (n={len(K)}, validation blocks)")
    for sp, c in (("train", CAT[0]), ("tuning", CAT[2])):
        d = T[T.split == sp]; ax.scatter(d.x_utm, d.y_utm, s=7, color=c, marker="^", label=f"T1 training sample, {sp} (n={len(d)})")
    ax.legend(fontsize=7, loc="lower left"); ax.set_xticks([]); ax.set_yticks([]); ax.grid(False); [sp_.set_visible(False) for sp_ in ax.spines.values()]
    ax.set_title("Independent evaluation vs training: gold in validation blocks (orange), T1 only in training-eligible cells (blue, >= 2 km away)", fontsize=8)

json.dump({"done": done, "skipped": skipped}, open(OUT / "figures_index.json", "w"), indent=1); print(done, skipped)
