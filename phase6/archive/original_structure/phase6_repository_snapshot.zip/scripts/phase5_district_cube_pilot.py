"""Phase 5 / Stage 3: district 30 m KEY-EPOCH PILOT cube (Landsat C2 L2, dry season Jan-May) on the full pune_G30 district grid.

Why: the district cube was reported as blocked on Earth Engine. The repository's own engine reads Landsat from Planetary Computer anonymously, so a
key-epoch cube can be built here; the full 37-year x 3-season cube cannot (compute + disk), see docs/phase5_district_cube_spec.md.
What: for each year in --years, every SELECTED manifest scene of Jan-May (data/manifests/landsat_manifest.parquet) is read at native 30 m
(no resampling: pune_G30 is the Landsat lattice), QA-masked exactly as the window cubes (engine stage 1), reduced per pixel to the median of
clear observations with the active G30 harmonisation (local_pune_g30_v2), and written with the engine's own product writer
(optical_composite, uncertainty, observation_count, valid_mask, qa incl. per-platform clear counts and median DOY, metadata.json with every source scene).
Missing observations stay missing (n_clear = 0 -> nodata); nothing is filled or interpolated.
Memory/disk: the district is processed in row strips (stage-1 cache per strip, deleted after reduction); per-strip reductions are kept until the year
is written, so a crash resumes at the strip level.
Output: data/composites/pune_G30/<year>/landsat/seasonal/dry/  (identical layout to the window composites)."""
import argparse, json, logging, math, shutil, sys, time, warnings
from pathlib import Path
import numpy as np
sys.path.insert(0, "src"); warnings.filterwarnings("ignore")
from rasterio.windows import Window
from pune_eo import config
from pune_eo.grid import district_grid
from pune_eo.compositing import engine as E
from pune_eo.compositing.periods import Period
from pune_eo.compositing import lean_writer as LW
from pune_eo.harmonization import landsat as harm
from pune_eo.io import write_json
from pune_eo.provenance import utcnow
logging.basicConfig(level=logging.INFO, format="%(asctime)s %(levelname)s %(message)s")
log = logging.getLogger("cube_pilot")
ap = argparse.ArgumentParser(); ap.add_argument("--years", default="1990,2000,2010,2020"); ap.add_argument("--threads", type=int, default=3)
ap.add_argument("--items-per-strip", type=int, default=24); ap.add_argument("--min-strips", type=int, default=4, help="bounds stage-1 memory per scene read (full-width reads x 3 threads were OOM-killed at 6 GB)")
ap.add_argument("--transform", default=None, help="harmonisation transform name (default: the active G30 transform local_pune_g30_v2); P4-C2@v2 treatment: c2_tm_pif_v1 (or the pre-declared fallback)")
ap.add_argument("--out-family", default="landsat", help="product family directory; the P4-C2@v2 treatment MUST use a separate family, e.g. landsat_c2tm")
ap.add_argument("--periods", default="dry", help="comma list of dry,post_monsoon,wet,annual (production cube: all four; the feature cube needs annual, dry, post_monsoon)"); a = ap.parse_args()
PER_MONTHS = {"annual": tuple(range(1, 13)), "dry": (1, 2, 3, 4, 5), "wet": (6, 7, 8, 9), "post_monsoon": (10, 11, 12)}
if a.transform and a.transform != harm.active_for_grid("pune_G30") and a.out_family == "landsat":
    sys.exit("a non-default --transform must be written to a separate --out-family (e.g. landsat_c2tm), never into the standard 'landsat' family")
G = district_grid("G30"); TR = a.transform or harm.active_for_grid(G.id); MAN = E.load_manifest("landsat"); CUT = __import__("pandas").to_datetime(MAN["archive_cutoff_utc"].iloc[0])
WORK = config.path("data/raw/ard_cache/phase5_pilot") / (a.out_family if a.out_family != "landsat" else ""); STATUS = config.path("results/phase5/cube_pilot"); STATUS.mkdir(parents=True, exist_ok=True)
inside_full = E.district_mask(G)
_tf = config.path("results/harmonization", f"{TR}.yaml")   # Phase 6: fitted transforms are files; record their SHA-256 in every product (checked by the C2 checklist)
TR_SHA = __import__("hashlib").sha256(_tf.read_bytes()).hexdigest() if _tf.exists() else None
for year in [int(y) for y in a.years.split(",")]:
    PERIODS = [Period(year, "annual", "annual", PER_MONTHS["annual"]) if n == "annual" else Period(year, "season", n, PER_MONTHS[n]) for n in a.periods.split(",")]
    todo = [P for P in PERIODS if not (config.path("data/composites", G.id, str(year), a.out_family, P.relpath) / "metadata.json").exists()]
    if not todo: log.info("%d done, skip", year); continue
    months = sorted({m for P in todo for m in P.months}); items = MAN[(MAN["year"] == year) & (MAN["month"].isin(months))]
    n_strips = max(a.min_strips, math.ceil(len(items) / a.items_per_strip)); edges = np.linspace(0, G.height, n_strips + 1).astype(int)
    log.info("%d: %d scenes, %d strips, periods %s, transform %s", year, len(items), n_strips, [P.name for P in todo], TR); t0 = time.time(); plog_all = []
    for s in range(n_strips):
        win = Window(0, int(edges[s]), G.width, int(edges[s + 1] - edges[s])); mfile = WORK / str(year) / f"strip{s}_metas.json"
        reds = {P.name: WORK / str(year) / f"strip{s}_{P.name}.npz" for P in todo}
        if mfile.exists() and all(r.exists() for r in reds.values()): continue
        cache = WORK / str(year) / f"cache_strip{s}"; plog = []
        metas = E.stage1("landsat", items, G, win, cache, a.threads, plog); plog_all += plog
        for P in todo:
            pm = [m for m in metas if int(m["date"][5:7]) in P.months]
            res = E.reduce_period("landsat", pm, cache, win, TR); np.savez(reds[P.name], **res); del res
        json.dump(metas, open(mfile, "w")); json.dump(plog, open(WORK / str(year) / f"strip{s}_plog.json", "w")); shutil.rmtree(cache, ignore_errors=True)
        log.info("%d strip %d/%d done (%d obs with data) %.0fs", year, s + 1, n_strips, len(metas), time.time() - t0)
    per_item = {}
    for s in range(n_strips):
        for m in json.load(open(WORK / str(year) / f"strip{s}_metas.json")):
            q = per_item.setdefault(m["item_id"], {**m, "n_clear_px": 0, "n_observed_px": 0}); q["n_clear_px"] += m["n_clear_px"]; q["n_observed_px"] += m["n_observed_px"]
    metas_y = sorted(per_item.values(), key=lambda m: m["date"])
    plog_all = [r for s in range(n_strips) if (WORK / str(year) / f"strip{s}_plog.json").exists() for r in json.load(open(WORK / str(year) / f"strip{s}_plog.json"))]   # incl. strips of interrupted runs
    for P in todo:
        out_dir = config.path("data/composites", G.id, str(year), a.out_family, P.relpath)
        strips = [(int(edges[s]), int(edges[s + 1]), WORK / str(year) / f"strip{s}_{P.name}.npz") for s in range(n_strips)]
        metas = [m for m in metas_y if int(m["date"][5:7]) in P.months]
        meta = LW.write_products_from_strips("landsat", P, G, strips, inside_full, metas, out_dir, CUT, TR,
                                             {"processing": E.processing_block("landsat", G) | {"driver": "scripts/phase5_district_cube_pilot.py (row strips, lean writer)", "n_strips": n_strips}
                                              | ({"transform_sha256": TR_SHA, "transform_file": str(_tf.relative_to(config.ROOT))} if TR_SHA else {})}, out_family=a.out_family)
        try:
            from pune_eo.qa.checks import check_product
            from pune_eo.acquisition.reference import permanent_water
            qa = check_product(out_dir / "metadata.json", permanent_water(G))["status"]
        except Exception as e: qa = f"QA_ERROR: {e!r}"
        summ = {"year": year, "period": P.name, "n_items_selected": int(len([1 for _, r in items.iterrows() if r["month"] in P.months])), "n_items_with_data": len(metas), "n_strips": n_strips,
                "seconds_year_total": round(time.time() - t0, 1), "qa": qa, "failed_items": [p for p in plog_all if p.get("status") == "failed"],
                "statistics": {k: meta["statistics"][k] for k in ("district_valid_fraction", "district_reliable_fraction_ge3", "n_clear_median", "n_clear_p10", "n_clear_p90", "sensor_contribution_clear_px")},
                "finished_utc": utcnow()}
        write_json(STATUS / f"pilot_{year}_{P.name}{'' if a.out_family == 'landsat' else '_' + a.out_family}.json", summ); log.info("%d %s written: %s", year, P.name, json.dumps(summ["statistics"]))
    shutil.rmtree(WORK / str(year), ignore_errors=True)
log.info("pilot finished")
