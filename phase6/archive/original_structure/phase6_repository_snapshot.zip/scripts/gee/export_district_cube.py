"""Google Earth Engine export of the DISTRICT 30 m cube (Phase 4 dependency H; aligned with the repository engine in Phase 5).
NEVER EXECUTED in this repository (no Earth Engine credentials in the sandbox). The REFERENCE implementation of the district cube is the repository's own engine
on Planetary Computer (scripts/phase5_district_cube_pilot.py, docs/phase5_district_cube_spec.md). This script is the alternative for users with an Earth Engine project.
    pip install earthengine-api && earthengine authenticate
    python3 scripts/gee/export_district_cube.py --project <GEE_PROJECT> [--years 1990-2026] [--what landsat,s2,dw,gaia] [--folder pune_eo_exports] [--dry-run]
Design (Phase-5 alignment with configs/landsat.yaml so district products are comparable with the 3 window cubes; checked by
`python3 src/data/validate_district_cube.py --static-gee`):
  * grid pune_G30 = native Landsat lattice, EPSG:32643, crsTransform [30,0,322065,0,-30,2146035], 6546 x 5624 -> no resampling of Landsat;
  * Landsat C2 L2 SR, Tier 1 only (LT04, LT05, LE07 until 2021-12-31, LC08, LC09), scene CLOUD_COVER <= 70;
    QA_PIXEL bits from configs/landsat.yaml (fill 0, dilated cloud 1, cirrus 2, cloud 3, shadow 4, snow 5) -> not clear; DN valid range 7273..43636
    (DN 1..7272 = negative reflectance -> clipped to 0, as the repository decoder; DN 0 or > 43636 -> invalid); scale 2.75e-5, offset -0.2;
    harmonisation results/harmonization/local_pune_g30_v2.yaml (landsat-7 pooled RMA to OLI; others identity);
  * periods: annual, dry Jan-May, wet Jun-Sep, post-monsoon Oct-Dec (configs/temporal.yaml); per period: median SR of clear observations, n_clear, n_observed,
    clear counts per platform; periods with no clear observation stay MASKED (never filled);
  * Sentinel-2 SR harmonized with Cloud Score+ (cs_cdf >= 0.6) seasonal medians (2017+) - NOT identical to the repository S2 (SCL mask), document if used;
  * Sentinel-1: NOT exported here. GEE offers GRD sigma0 only; the repository uses Sentinel-1 RTC gamma0 (terrain-flattened, Planetary Computer). Mixing them would make the
    district S1 features incomparable with the windows -> build S1 with the repository engine (pune-eo composite --family sentinel1).
  * Dynamic World seasonal mean class probabilities (2016+, reduceResolution mean to 30 m) and GAIA change-year index: BENCHMARK products only, never training labels.
Known remaining differences to the reference engine (documented in docs/phase5_district_cube_spec.md §6): no SE-of-median uncertainty band, no median-DOY band, no 1 % district-overlap
scene rule, GEE median vs numpy median tie handling. Outputs are GeoTIFFs in Google Drive; validate them with src/data/validate_district_cube.py --layout gee."""
import argparse, json, sys
from pathlib import Path
import yaml
ROOT = Path(__file__).resolve().parents[2]
GRID = json.load(open(ROOT / "data/products_ext/district/district_grid.json"))["grid"]; HARM = yaml.safe_load(open(ROOT / "results/harmonization/local_pune_g30_v2.yaml"))
LCFG = yaml.safe_load(open(ROOT / "configs/landsat.yaml"))
CRS, TR, W, H = GRID["crs"], [GRID["res"], 0, GRID["x0"], 0, -GRID["res"], GRID["y1"]], GRID["width"], GRID["height"]
PERIODS = {"annual": (1, 12), "dry": (1, 5), "wet": (6, 9), "post_monsoon": (10, 12)}
QA_BITS = sorted(int(b) for b in LCFG["qa_mask_bits"].values())          # [0, 1, 2, 3, 4, 5]
VALID_DN = tuple(LCFG["valid_dn"]); SCALE, OFFSET = LCFG["scale"], LCFG["offset"]; MAX_CLOUD = LCFG["selection"]["max_scene_cloud"]
PLATFORM_WINDOWS = {p: (v["start"], v.get("end") or "2100-01-01") for p, v in LCFG["platforms"].items()}
LS = {"LT04": ("LANDSAT/LT04/C02/T1_L2", ["SR_B1", "SR_B2", "SR_B3", "SR_B4", "SR_B5", "SR_B7"], "landsat-4"),
      "LT05": ("LANDSAT/LT05/C02/T1_L2", ["SR_B1", "SR_B2", "SR_B3", "SR_B4", "SR_B5", "SR_B7"], "landsat-5"),
      "LE07": ("LANDSAT/LE07/C02/T1_L2", ["SR_B1", "SR_B2", "SR_B3", "SR_B4", "SR_B5", "SR_B7"], "landsat-7"),
      "LC08": ("LANDSAT/LC08/C02/T1_L2", ["SR_B2", "SR_B3", "SR_B4", "SR_B5", "SR_B6", "SR_B7"], "landsat-8"),
      "LC09": ("LANDSAT/LC09/C02/T1_L2", ["SR_B2", "SR_B3", "SR_B4", "SR_B5", "SR_B6", "SR_B7"], "landsat-9")}
NAMES = ["blue", "green", "red", "nir08", "swir16", "swir22"]
OUTPUT_BANDS = NAMES + ["ndvi", "mndwi", "ndmi", "nbr", "ndbi", "n_clear", "n_observed"] + [f"n_clear_{v[2]}" for v in LS.values()]

def plan(years, what):
    tasks = []
    for y in years:
        for s in PERIODS:
            if "landsat" in what: tasks.append(("landsat", y, s))
            if s == "annual": continue
            if "s2" in what and y >= 2017: tasks.append(("s2", y, s))
            if "dw" in what and y >= 2016: tasks.append(("dw", y, s))
    if "gaia" in what: tasks.append(("gaia", None, None))
    return tasks

def main():
    ap = argparse.ArgumentParser(); ap.add_argument("--project"); ap.add_argument("--years", default="1990-2026"); ap.add_argument("--what", default="landsat,s2,dw,gaia")
    ap.add_argument("--folder", default="pune_eo_exports"); ap.add_argument("--dry-run", action="store_true"); a = ap.parse_args()
    y0, _, y1 = a.years.partition("-"); years = list(range(int(y0), int(y1 or y0) + 1)); tasks = plan(years, a.what.split(","))
    if "s1" in a.what.split(","): sys.exit("Sentinel-1 is not exported from GEE (GRD sigma0 != repository RTC gamma0): use `pune-eo composite --family sentinel1`")
    print(json.dumps({"grid": GRID["id"], "crs": CRS, "crsTransform": TR, "dimensions": f"{W}x{H}", "n_tasks": len(tasks), "qa_bits": QA_BITS, "valid_dn": VALID_DN, "max_scene_cloud": MAX_CLOUD,
                      "landsat_output_bands": OUTPUT_BANDS}, indent=1))
    if a.dry_run:
        for t in tasks[:12]: print("would export", t)
        return
    if not a.project: sys.exit("--project <GEE_PROJECT> required")
    import ee
    ee.Initialize(project=a.project)
    region = ee.Geometry.Rectangle([GRID["bounds"][0], GRID["bounds"][1], GRID["bounds"][2], GRID["bounds"][3]], ee.Projection(CRS), False)
    qa_mask_value = sum(1 << b for b in QA_BITS)
    def ls_prep(key):
        cid, bands, plat = LS[key]; h = HARM["per_platform"].get(plat); t0, t1 = PLATFORM_WINDOWS[plat]
        def f(img):
            qa = img.select("QA_PIXEL"); observed = qa.bitwiseAnd(1).eq(0); clear = qa.bitwiseAnd(qa_mask_value).eq(0)
            dn = img.select(bands, NAMES)
            sr = dn.multiply(SCALE).add(OFFSET)
            sr = sr.where(dn.gt(0).And(dn.lt(VALID_DN[0])), 0)                       # negative reflectance -> 0 (repository decoder)
            ok = dn.gt(0).And(dn.lte(VALID_DN[1])).reduce(ee.Reducer.min())          # all six bands valid
            if h:
                sr = sr.multiply(ee.Image.constant([h["slope"][n] for n in NAMES])).add(ee.Image.constant([h["intercept"][n] for n in NAMES])).rename(NAMES)
            cl = clear.And(observed).And(ok)
            return sr.updateMask(cl).addBands(cl.rename("clear_flag").toUint8()).addBands(observed.rename("obs_flag").toUint8()).copyProperties(img, ["system:time_start"])
        return ee.ImageCollection(cid).filterBounds(region).filter(ee.Filter.lte("CLOUD_COVER", MAX_CLOUD)).filterDate(t0, ee.Date(t1).advance(1, "day")).map(f), plat
    def indices(img):
        nd = lambda x, y, n: img.normalizedDifference([x, y]).rename(n)
        return img.addBands([nd("nir08", "red", "ndvi"), nd("green", "swir16", "mndwi"), nd("nir08", "swir16", "ndmi"), nd("nir08", "swir22", "nbr"), nd("swir16", "nir08", "ndbi")])
    def export(img, name):
        t = ee.batch.Export.image.toDrive(image=img, description=name[:100], folder=a.folder, fileNamePrefix=name, crs=CRS, crsTransform=TR, region=region, maxPixels=int(1e10),
                                          fileFormat="GeoTIFF", formatOptions={"cloudOptimized": True, "noData": -9999}); t.start(); print("started", name, t.id)   # masked = -9999, never 0
    for kind, y, s in tasks:
        if kind == "gaia":
            export(ee.Image("Tsinghua/FROM-GLC/GAIA/v10").toUint8(), "gaia_v10_change_year_index"); continue   # index -> year mapping: verify against the catalog page before use
        m0, m1 = PERIODS[s]; start = ee.Date.fromYMD(y, m0, 1); end = ee.Date.fromYMD(y, m1, 1).advance(1, "month")
        if kind == "landsat":
            parts = [ls_prep(k) for k in LS]; col = ee.ImageCollection([])
            for c, _ in parts: col = col.merge(c)
            col = col.filterDate(start, end)
            med = col.select(NAMES).median()
            counts = [col.select("clear_flag").sum().rename("n_clear"), col.select("obs_flag").sum().rename("n_observed")]
            counts += [c.filterDate(start, end).select("clear_flag").sum().unmask(0).rename(f"n_clear_{p}") for c, p in parts]
            img = indices(med).addBands(counts).toFloat(); export(img, f"landsat_{y}_{s}")
        elif kind == "s2":
            cs = ee.ImageCollection("GOOGLE/CLOUD_SCORE_PLUS/V1/S2_HARMONIZED")
            col = ee.ImageCollection("COPERNICUS/S2_SR_HARMONIZED").filterBounds(region).filterDate(start, end).linkCollection(cs, ["cs_cdf"]) \
                    .map(lambda i: i.updateMask(i.select("cs_cdf").gte(0.6)).select(["B2", "B3", "B4", "B8", "B11", "B12"], ["blue", "green", "red", "nir", "swir16", "swir22"]).divide(10000))
            export(col.median().addBands(col.select("red").count().rename("n_clear")).toFloat(), f"s2_{y}_{s}")
        elif kind == "dw":
            dw = ee.ImageCollection("GOOGLE/DYNAMICWORLD/V1").filterBounds(region).filterDate(start, end)
            probs = dw.select(["water", "trees", "grass", "flooded_vegetation", "crops", "shrub_and_scrub", "built", "bare", "snow_and_ice"]).mean()
            probs = probs.reduceResolution(ee.Reducer.mean(), maxPixels=64).reproject(crs=CRS, crsTransform=TR)
            export(probs.addBands(dw.select("label").count().rename("n_obs")).toFloat(), f"dynamicworld_{y}_{s}")
if __name__ == "__main__": main()
