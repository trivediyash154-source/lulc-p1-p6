"""POST-HOC (not pre-registered) sensitivity analyses for P5-E2, added after an independent review:
(1) acquisition order: pairs split by whether sensor b was imaged 8 days later or earlier; if sign and size persist in both orders, monotonic within-season phenology
    does not explain the difference;
(2) cluster bootstrap: pairs sharing an acquisition day of sensor a (same orbit pass, e.g. rows 047 and 048; shared atmosphere) are resampled together, replacing the
    registered pair bootstrap's independence assumption -> wider, more honest CIs. The registered pair-bootstrap CIs stay reported unchanged."""
import json, sys
import numpy as np, pandas as pd
sys.path.insert(0, "src")
from pune_eo import config
D = pd.read_csv(config.path("results/phase5/sensor_pairs/pair_differences.csv")); rng = np.random.default_rng(20261132); out = {"label": "POST-HOC sensitivity, not pre-registered", "contrasts": {}}
for (c, v, p), g in D[D.pif == "forest_pif"].groupby(["contrast", "variant", "pif"]):
    rec = {}
    for order, gg in (("b_later", g[g.dt_days > 0]), ("b_earlier", g[g.dt_days < 0])):
        r = {"n_pairs": int(len(gg))}
        for b in ("red", "nir08", "ndvi"):
            x = gg[b].dropna().values
            if len(x) >= 3:
                bs = [rng.choice(x, len(x)).mean() for _ in range(2000)]; r[b] = {"mean": float(x.mean()), "ci": [float(np.percentile(bs, 2.5)), float(np.percentile(bs, 97.5))]}
        rec[order] = r
    out["contrasts"][f"{c}|{v}|{p}"] = rec
json.dump(out, open(config.path("results/phase5/sensor_pairs/posthoc_order_balance.json"), "w"), indent=1)
rows = []
for (c, v, p), g in D.groupby(["contrast", "variant", "pif"]):
    cl = g.date_a.values; uc = np.unique(cl)
    for b in ("blue", "green", "red", "nir08", "swir16", "swir22", "ndvi"):
        x = g[b].values
        if np.isnan(x).any(): rows.append({"contrast": c, "variant": v, "pif": p, "band": b, "n_pairs": len(x), "n_clusters": len(uc), "mean_diff": None, "ci_lo": None, "ci_hi": None, "note": "NaN pair value(s): NOT MEASURED"}); continue
        idx = {u: np.flatnonzero(cl == u) for u in uc}; bs = []
        for _ in range(2000):
            pick = rng.choice(uc, len(uc)); ii = np.concatenate([idx[u] for u in pick]); bs.append(x[ii].mean())
        lo, hi = np.percentile(bs, [2.5, 97.5])
        rows.append({"contrast": c, "variant": v, "pif": p, "band": b, "n_pairs": len(x), "n_clusters": len(uc), "mean_diff": float(x.mean()), "ci_lo": float(lo), "ci_hi": float(hi), "excludes_zero": bool(lo > 0 or hi < 0)})
pd.DataFrame(rows).to_csv(config.path("results/phase5/sensor_pairs/posthoc_cluster_bootstrap.csv"), index=False)
print(pd.DataFrame(rows)[lambda d: d.pif == "forest_pif"][["contrast", "variant", "band", "n_pairs", "n_clusters", "mean_diff", "ci_lo", "ci_hi"]].to_string())
for k, v in out["contrasts"].items(): print(k, {o: (r["n_pairs"], {b: round(r[b]["mean"], 4) for b in ("red", "ndvi") if b in r}) for o, r in v.items()})
