"""Phase 5: design of the HUMAN TRAINING sample T1 (needed by P4-C1@v2 arms C-E; see experiments/registry4/addenda/P4-C1_at_v2_addendum_1_PROPOSED.json).
Design only - no label is produced. Interpreters fill the blind forms exactly as for gold (docs/phase4_gold_protocol.md §3); ingestion re-uses src/validation.
Rules (fixed before any data):
  * population: training-eligible 30 m cells (data/labels/gold/phase4/sampling_design/training_eligible_30m.tif = district cells >= 2 km from every validation block);
  * strata: the Phase-4 strata raster (same 13 strata) restricted to eligible cells, each split into BOUNDARY (any of GLC_FCS30D/Esri/WorldCover 2020 L1 has another class
    in the 3x3 neighbourhood) and INTERIOR cells -> the sample deliberately includes the boundary / mixed / transitional cells that the silver labels lack (audit W4);
  * allocation: N = 640; sqrt(area) per stratum with x1.6 for the Phase-4 hard strata, floor 20, tiny strata (< 0.25 % of district) <= 5; within each stratum 50 % boundary
    cells (as far as available); at most 4 points per stratum per 6 km block;
  * tuning split (protocol v2 'tuning blocks inside the training share', rule fixed here): a training-share 6 km block is a TUNING block iff
    sha256('phase5-tuning-v1:{bx}:{by}') % 100 < 25; every T1 point carries split = train | tuning;
  * seed 20261121. Leakage audit (audit_gold.audit_training_labels) must pass before the design is written.
Outputs: data/labels/training/phase5_T1/{sampling_design, blind, _key, raw_interpreter_A, raw_interpreter_B, adjudicated, metadata}."""
import hashlib, json, sys, warnings
import numpy as np, pandas as pd, rasterio
from scipy.ndimage import maximum_filter, minimum_filter
sys.path.insert(0, "src"); warnings.filterwarnings("ignore")
from pune_eo import config
from pune_eo.grid import district_grid
from pune_eo.io import write_cog
from pune_eo.provenance import utcnow
from validation import ingest_gold as IG, audit_gold as AG
SEED = 20261121; rng = np.random.default_rng(SEED); G = district_grid("G30"); GOLD = config.path("data/labels/gold/phase4"); OUT = config.path("data/labels/training/phase5_T1")
for d in ("sampling_design", "blind", "_key", "raw_interpreter_A", "raw_interpreter_B", "adjudicated", "metadata"): (OUT / d).mkdir(parents=True, exist_ok=True)
def rd(p, b=1):
    with rasterio.open(p) as s: return s.read(b)
PX = config.path("data/products_ext"); mask = rd(PX / "district/district_mask_30m.tif").astype(bool)
elig = rd(GOLD / "sampling_design/training_eligible_30m.tif").astype(bool) & mask; st = rd(GOLD / "sampling_design/strata_30m.tif")
design = json.load(open(GOLD / "sampling_design/design.json")); names = design["strata_priority_order"]
GLC_L1 = {10: 2, 11: 2, 12: 2, 20: 2, **{c: 3 for c in (51, 52, 61, 62, 71, 72, 81, 82, 91, 92, 120, 121, 122, 130, 140)}, 150: 5, 152: 5, 153: 5, **{c: 6 for c in range(181, 188)}, 190: 1, 200: 5, 201: 5, 202: 5, 210: 4, 220: 6}
cw = config.load("labels")["crosswalks"]
def l1(a, t):
    o = np.zeros(a.shape, np.uint8)
    for k, v in t.items(): o[a == int(k)] = v
    return o
bnd = np.zeros(G.shape, bool)
with rasterio.open(PX / "glc_fcs30d/glc_fcs30d_district_30m.tif") as s: gy = [int(d) for d in s.descriptions]; a = l1(s.read(gy.index(2020) + 1), GLC_L1); bnd |= maximum_filter(a, 3) != minimum_filter(a, 3)
with rasterio.open(PX / "esri/esri_district_30m_mode.tif") as s: ey = [int(d) for d in s.descriptions]; a = l1(s.read(ey.index(2020) + 1), cw["esri_lulc"]); bnd |= maximum_filter(a, 3) != minimum_filter(a, 3)
with rasterio.open(PX / "worldcover/worldcover_district_30m_mode.tif") as s: wy = [int(d) for d in s.descriptions]; a = l1(s.read(wy.index(2020) + 1), cw["esa_worldcover"]); bnd |= maximum_filter(a, 3) != minimum_filter(a, 3)
del a
bx = ((np.arange(G.width) * 30 + G.x0) // 6000).astype(int); by = ((G.y1 - np.arange(G.height) * 30) // 6000).astype(int)
tune = lambda a_, b_: int(hashlib.sha256(f"phase5-tuning-v1:{a_}:{b_}".encode()).hexdigest(), 16) % 100 < 25
ubx, uby = np.unique(bx), np.unique(by); tt = np.array([[tune(a_, b_) for a_ in ubx] for b_ in uby]); tuning_cell = tt[np.searchsorted(uby, by)][:, np.searchsorted(ubx, bx)] & elig
write_cog(OUT / "sampling_design/tuning_blocks_30m.tif", tuning_cell.astype(np.uint8), G, nodata=None, dtype="uint8", descriptions=["tuning_block (training share only)"], overview_resampling="nearest")
N, FLOOR, MAXPB = 640, 20, 4; area = {nm: int(((st == i) & elig).sum()) for i, nm in enumerate(names, 1)}; TINY = 0.0025 * int(mask.sum())
hard = {"product_disagreement_2020", "peri_urban_transforming_2001_2021", "reservoir_margin_le1km", "river_corridor_le300m", "urban_core_settled_by_2000", "rainfed_dry_agriculture"}
w = {k: np.sqrt(v) * (1.6 if k in hard else 1.0) for k, v in area.items() if v > 0}; tot = sum(w.values())
alloc = {k: (min(5, max(1, int(round(N * v / tot)))) if area[k] < TINY else max(FLOOR, int(round(N * v / tot)))) for k, v in w.items()}
rows = []
for i, nm in enumerate(names, 1):
    if nm not in alloc: continue
    for part, want in (("boundary", alloc[nm] // 2 + alloc[nm] % 2), ("interior", alloc[nm] // 2)):
        m = (st == i) & elig & (bnd if part == "boundary" else ~bnd); cand = rng.permutation(np.flatnonzero(m.ravel())); per_block, pick = {}, []
        for p in cand:
            if len(pick) >= want: break
            r_, c_ = divmod(int(p), G.width); kb = (bx[c_], by[r_])
            if per_block.get((kb, nm), 0) >= MAXPB: continue
            per_block[(kb, nm)] = per_block.get((kb, nm), 0) + 1; pick.append(p)
        for p in pick:
            r, c = divmod(int(p), G.width); rows.append({"stratum": nm, "boundary": part == "boundary", "row": r, "col": c, "x_utm": G.x0 + (c + 0.5) * 30, "y_utm": G.y1 - (r + 0.5) * 30,
                                                         "block": f"{bx[c]}:{by[r]}", "split": "tuning" if tuning_cell[r, c] else "train"})
D = pd.DataFrame(rows)
from pyproj import Transformer
t = Transformer.from_crs(G.crs, 4326, always_xy=True); D["lon"], D["lat"] = t.transform(D.x_utm.values, D.y_utm.values)
D["stratum_area_cells_eligible"] = D.stratum.map(area)
D = D.sample(frac=1, random_state=SEED).reset_index(drop=True); D.insert(0, "anon_id", [f"T1-{i + 1:04d}" for i in range(len(D))])
D["double_interpretation"] = False; D.loc[D.sample(frac=0.2, random_state=SEED + 1).index, "double_interpretation"] = True
# leakage audit BEFORE writing anything a human would use
sp = IG.load_spatial(GOLD); K = IG.load_key(GOLD); aud = AG.audit_training_labels(D, sp, K, design["grid"])
if not aud["ok"]: raise SystemExit(f"T1 leakage audit failed: {aud}")
D.to_csv(OUT / "_key/phase5_T1_key.csv", index=False)
EP = list(IG.EPOCHS); cols = ["anon_id", "lat", "lon"] + [f"{f}_{e}" for e in EP for f in IG.FIELDS]
blind = D[["anon_id", "lat", "lon"]].copy()
for c in cols[3:]: blind[c] = ""
blind.to_csv(OUT / "blind/form_T1_interpreter_A.csv", index=False); blind[D.double_interpretation.values].sample(frac=1, random_state=SEED + 2).to_csv(OUT / "blind/form_T1_interpreter_B.csv", index=False)
half = 15.0
def ring(x, y):
    pts = [(x - half, y - half), (x + half, y - half), (x + half, y + half), (x - half, y + half), (x - half, y - half)]; lo, la = t.transform(*zip(*pts)); return " ".join(f"{a_:.7f},{b_:.7f},0" for a_, b_ in zip(lo, la))
k = ['<?xml version="1.0" encoding="UTF-8"?><kml xmlns="http://www.opengis.net/kml/2.2"><Document><name>Pune Phase-5 training sample T1 (blind)</name>'
     '<Style id="c"><LineStyle><color>ff00ffff</color><width>2</width></LineStyle><PolyStyle><fill>0</fill></PolyStyle></Style>']
for _, r in D.iterrows():
    k.append(f'<Placemark><name>{r.anon_id}</name><styleUrl>#c</styleUrl><MultiGeometry><Point><coordinates>{r.lon:.7f},{r.lat:.7f},0</coordinates></Point>'
             f'<Polygon><outerBoundaryIs><LinearRing><coordinates>{ring(r.x_utm, r.y_utm)}</coordinates></LinearRing></outerBoundaryIs></Polygon></MultiGeometry></Placemark>')
k.append("</Document></kml>"); (OUT / "blind/phase5_T1_cells.kml").write_text("".join(k))
meta = {"design": "phase5_T1", "created_utc": utcnow(), "seed": SEED, "n_points": len(D), "allocation_requested": alloc, "drawn": D.stratum.value_counts().to_dict(),
        "boundary_share": float(D.boundary.mean()), "split_counts": D.split.value_counts().to_dict(), "double_interpretation": int(D.double_interpretation.sum()),
        "eligible_share_of_district": float(elig[mask].mean()), "boundary_share_of_eligible": float(bnd[elig].mean()), "tuning_share_of_eligible": float(tuning_cell[elig].mean()),
        "tuning_rule": "sha256('phase5-tuning-v1:{bx}:{by}') % 100 < 25 on training-share 6 km blocks", "leakage_audit": aud,
        "key_sha256": hashlib.sha256((OUT / "_key/phase5_T1_key.csv").read_bytes()).hexdigest(), "status": "DESIGN ONLY - no labels; arms C-E definitions PROPOSED (registry4 addendum)"}
json.dump(meta, open(OUT / "sampling_design/design.json", "w"), indent=1, default=str); print(json.dumps({k_: meta[k_] for k_ in ("n_points", "drawn", "boundary_share", "split_counts", "leakage_audit")}, indent=1, default=str))
