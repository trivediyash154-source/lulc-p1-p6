"""Phase 6: terrain features on the whole district grid (pune_G30), identical method to the window terrain (src/pune_eo/feature_engineering/terrain.py):
Copernicus GLO-30 DSM (Planetary Computer) on a 3 km-buffered district grid, Horn slope/aspect, Zevenbergen-Thorne curvature, TPI 150/1050 m, pysheds pit/depression
filling, flat resolution, D8, accumulation, HAND, distance to drainage, TWI; cropped to the district grid. LIMIT: upstream area outside the 3 km buffer is not routed
(rivers entering the district: flow accumulation and HAND near inflow edges are underestimated), as for the windows. Output data/features/terrain/pune_G30/."""
import json, sys
sys.path.insert(0, "src")
from pune_eo.feature_engineering.terrain import build_terrain
meta = build_terrain("district", "G30", buffer_m=3000, stream_km2=1.0)
print(json.dumps({k: meta[k] for k in ("grid", "stream_threshold_km2", "bands")}, indent=1, default=str))
