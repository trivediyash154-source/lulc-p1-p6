"""Pre-register the Phase-5 EXPLORATORY analyses in registry4 BEFORE running them (protocol v2 unchanged; exploratory records never decide a gate).
Confirmatory records P4-C1..C6@v2 are not touched here."""
import sys
sys.path.insert(0, "src")
from pune_eo.evaluation4 import protocol as P4
COMMON = dict(kind="exploratory", label_tier="none", model="none", seeds=[], splits="none")
SPECS = [
    dict(experiment_id="P5-X1", family="data_foundation",
         hypothesis="district Landsat observation support is sufficient for ANNUAL claims (G1 rule: >= 3 clear dry-season obs over >= 80 % of the district) only in some years; elsewhere only epoch-level claims are supportable",
         comparator="G1 temporal-resolution rule of protocol v2", primary_metric="share of district with >= 3 clear dry-season observations per year (240 m all years; 30 m at 1990/2000/2010/2020)",
         direction="descriptive", threshold="G1 rule (0.80 of district with >= 3 clear dry obs)", dataset_version="data/composites/pune_G240 metadata (Phase 1) + data/composites/pune_G30 key-epoch pilot (Phase 5)",
         evaluation_set="district", region="Pune District", years="1990-2026", features="n_clear per season", labels="none",
         metrics_planned=["reliable_fraction_ge3 by year and season", "valid_fraction", "n_clear median", "30 m vs 240 m agreement at the 4 key epochs", "annual-support years list"]),
    dict(experiment_id="P5-X2", family="benchmark",
         hypothesis="disagreement among existing land-cover products (GLC_FCS30D, Esri, WorldCover, L1, 2020) is higher on class boundaries and in peri-urban/rural-fringe context than in interiors and in urban cores or remote rural land",
         comparator="district-wide no-consensus share (P4-X3: 0.40)", primary_metric="no-consensus share by pre-declared descriptor class",
         direction="descriptive", threshold="none (exploratory)", dataset_version="data/products_ext v1 + data/labels/pune_G30 (WSF, GHSL, JRC)", evaluation_set="district",
         region="Pune District", years="2020", features="-", labels="none",
         metrics_planned=["no-consensus share: class-boundary (any 3x3 neighbour with another consensus-or-product class) vs interior",
                          "no-consensus share by settlement context: urban core (GHSL 2020 built fraction >= 0.3), fringe (<= 1 km from WSF-2015 settlement, not core), rural (> 1 km)",
                          "no-consensus share by rainfall region x slope class", "pairwise per-class agreement (user's/producer's style, product vs product, never accuracy)"]),
    dict(experiment_id="P5-X3", family="benchmark",
         hypothesis="the independent built-up reference envelope used by Gate G5 can be fixed from Tier-B products before any district model prediction exists",
         comparator="none", primary_metric="min-max district built share of Tier-B built products (WSF-Evolution, GHSL BUILT-S, GISA 2.0, GLC_FCS30D impervious) per epoch 1990/2000/2010/2020",
         direction="descriptive", threshold="none (pre-specification of the G5 envelope)", dataset_version="data/products_ext v1 + data/labels/pune_G30", evaluation_set="district",
         region="Pune District and the 3 rainfall regions", years="1990, 2000, 2010, 2020", features="-", labels="none",
         metrics_planned=["envelope [min, max] district built share per epoch and per region", "envelope +- 0.02 (G5 tolerance)", "SHA-256 of the frozen envelope file"]),
]

# P5-X4 and P5-E2 were first registered with inline commands (2026-10-02, before running); their exact registered specifications are mirrored here so the
# registration text lives in the repository. Re-running this script never overwrites an existing record.
SPECS_INLINE = [
 {
  "experiment_id": "P5-X4",
  "family": "benchmark",
  "hypothesis": "surface-water products agree on permanent open water but diverge on seasonal water (reservoir margins, rivers), so district water extent depends on the product definition",
  "comparator": "JRC GSW occurrence (1984-2021 composite statistic, not a 2020 map)",
  "primary_metric": "2020 water area by product; pairwise F1/IoU of water masks (agreement, never accuracy); agreement by JRC seasonality class",
  "direction": "descriptive",
  "threshold": "none (exploratory)",
  "dataset_version": "data/labels/pune_G30/jrc_gsw.tif + data/products_ext (GLC_FCS30D, Esri, WorldCover 2020)",
  "evaluation_set": "district",
  "region": "Pune District",
  "years": "2020 (JRC: 1984-2021 occurrence)",
  "features": "-",
  "labels": "none",
  "metrics_planned": [
   "water km2 per product",
   "pairwise F1, IoU",
   "share of JRC-occurrence classes (>=75, 25-75, 1-25, 0) mapped as water by each product"
  ],
  "label_tier": "B/C",
  "model": "none",
  "seeds": [],
  "splits": "none"
 },
 {
  "experiment_id": "P5-E2",
  "family": "sensor_era",
  "hypothesis": "on pseudo-invariant targets observed by two sensors 8 days apart (same WRS-2 path/row, dry season), residual sensor differences exist: (a) L5 vs L7-raw ~ 0 (TM ~ ETM+); (b) L5 vs L7-harmonised != 0, i.e. the identity transform for L5 leaves an L5-vs-OLI-equivalent offset; (c) L7-harmonised vs L8 ~ 0 in 2013-2016; (d) L8 vs L9 ~ 0",
  "comparator": "zero difference",
  "primary_metric": "mean over pairs of the per-pair median PIF reflectance difference (blue..swir22, NDVI), pair-bootstrap 95 % CI",
  "direction": "two-sided",
  "threshold": "none (exploratory; 'CI excludes 0' reported, not decisive)",
  "dataset_version": "Landsat C2 L2 (Planetary Computer, manifest 2026-10-01) read on pune_G240 (SR overviews averaged, QA conservative) + PIF masks from GLC_FCS30D/JRC/WSF",
  "evaluation_set": "pure 240 m PIF cells (all 64 sub-cells PIF) in TRAINING-ELIGIBLE cells only (validation blocks + 2 km excluded)",
  "region": "Pune District",
  "years": "1999-2011 (L5/L7), 2013-2016 primary and 2017-2021 secondary (L7/L8), 2021-2026 (L8/L9)",
  "features": "dry-season SR bands + NDVI",
  "labels": "none",
  "metrics_planned": [
   "per contrast x PIF class x band: mean of per-pair medians, pair-bootstrap CI (2000)",
   "n pairs, n PIF cells per pair",
   "identifiability limits"
  ],
  "label_tier": "B (PIF selection)",
  "model": "none",
  "seeds": [
   20261131
  ],
  "splits": "none"
 }
]
for s in SPECS + SPECS_INLINE:          # spec fields override COMMON
    if P4.load(s["experiment_id"]) is None: P4.register(**{**COMMON, **s}); print("registered", s["experiment_id"])
    else: print("exists", s["experiment_id"], P4.load(s["experiment_id"])["status"])
