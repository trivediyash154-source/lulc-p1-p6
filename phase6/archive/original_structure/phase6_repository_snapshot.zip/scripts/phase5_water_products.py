"""P5-X4 (EXPLORATORY, pre-registered): agreement of surface-water products (never accuracy). JRC GSW occurrence is a 1984-2021 statistic, not a 2020 map."""
import json, sys, warnings
import numpy as np, rasterio
sys.path.insert(0, "src"); warnings.filterwarnings("ignore")
from pune_eo import config
from pune_eo.evaluation4 import protocol as P4
OUT = config.path("results/phase5/benchmark"); PX = config.path("data/products_ext"); LB = config.path("data/labels/pune_G30"); run = P4.Run("P5-X4"); K = 0.0009
def rd(p, b=1):
    with rasterio.open(p) as s: return s.read(b), list(s.descriptions)
mask = rd(PX / "district/district_mask_30m.tif")[0].astype(bool)
occ = rd(LB / "jrc_gsw.tif", 1)[0]; occv = occ != 255
with rasterio.open(PX / "glc_fcs30d/glc_fcs30d_district_30m.tif") as s: gy = [int(d) for d in s.descriptions]; glc = s.read(gy.index(2020) + 1) == 210
with rasterio.open(PX / "esri/esri_district_30m_mode.tif") as s: ey = [int(d) for d in s.descriptions]; esri = s.read(ey.index(2020) + 1) == 1
with rasterio.open(PX / "worldcover/worldcover_district_30m_mode.tif") as s: wy = [int(d) for d in s.descriptions]; wc = s.read(wy.index(2020) + 1) == 80
P = {"JRC_occ_ge50": occv & (occ >= 50), "JRC_occ_ge25": occv & (occ >= 25), "GLC_FCS30D_2020": glc, "Esri_2020": esri, "WorldCover_2020": wc}
R = {"area_km2": {k: float((v & mask).sum() * K) for k, v in P.items()}, "pairwise": {}, "by_jrc_occurrence_class": {}}
ks = list(P)
for i, a in enumerate(ks):
    for b in ks[i + 1:]:
        A, B = P[a] & mask, P[b] & mask; tp = (A & B).sum(); R["pairwise"][f"{a}~{b}"] = {"F1": float(2 * tp / max(1, A.sum() + B.sum())), "IoU": float(tp / max(1, (A | B).sum()))}
cls = {"occ_ge75": occv & (occ >= 75), "occ_25_75": occv & (occ >= 25) & (occ < 75), "occ_1_25": occv & (occ >= 1) & (occ < 25), "occ_0": occv & (occ == 0)}
for c, m in cls.items():
    m = m & mask; R["by_jrc_occurrence_class"][c] = {"area_km2": float(m.sum() * K), **{f"share_mapped_water_{k}": float(P[k][m].mean()) if m.any() else None for k in ("GLC_FCS30D_2020", "Esri_2020", "WorldCover_2020")}}
json.dump(R, open(OUT / "water_products_p5x4.json", "w"), indent=1)
txt = "water km2 2020: " + ", ".join(f"{k} {v:.0f}" for k, v in R["area_km2"].items()) + "; mapped-as-water share by JRC class (GLC/Esri/WC): " + "; ".join(
      f"{c} {v['share_mapped_water_GLC_FCS30D_2020']:.2f}/{v['share_mapped_water_Esri_2020']:.2f}/{v['share_mapped_water_WorldCover_2020']:.2f}" for c, v in R["by_jrc_occurrence_class"].items())
run.complete({"area_km2": R["area_km2"], "by_jrc_occurrence_class": R["by_jrc_occurrence_class"]}, "NA", txt, outputs={"summary": "results/phase5/benchmark/water_products_p5x4.json"}); print(txt)
