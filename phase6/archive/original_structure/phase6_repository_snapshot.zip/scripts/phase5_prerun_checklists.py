"""Automated PRE-RUN CHECKLIST for every active confirmatory record (P4-C1@v2 ... P4-C6@v2). Read-only.
If any item fails the experiment MUST NOT run; `assert_runnable(eid)` is the guard any future confirmatory runner must call first.
LIMIT: the frozen registry class protocol.Run cannot call this guard (protocol.py is hash-pinned); enforcement is by convention + tests/test_phase5_guards.py.
Items: protocol hashes unchanged; registry status PENDING + G8 check; Tier-A gold ingested and G2 passed for the experiment's epochs; human training labels (C1 arms C-E);
addendum approved where the record is under-specified; validation blocks and training exclusion verified; district cube validated for the registered epochs/periods;
registered feature set available on the district grid; model-selection prerequisites (tuning rule; C1 completed for C2-C6); seeds == protocol seeds; test + FDR family defined."""
import hashlib, json, sys
from pathlib import Path
sys.path.insert(0, "src")
import yaml
from pune_eo import config
from pune_eo.evaluation4 import protocol as P4
from pune_eo.provenance import utcnow
OUT = config.path("results/phase5/confirmatory"); OUT.mkdir(parents=True, exist_ok=True)
EPOCHS = {"P4-C1@v2": [2020, 2010, 2000, 1990], "P4-C2@v2": [1990, 2000], "P4-C3@v2": [1990, 2000, 2010, 2020], "P4-C4@v2": [2020], "P4-C5@v2": [2020, 2000], "P4-C6@v2": [2020]}
def J(p):
    p = config.path(p); return json.loads(p.read_text()) if p.exists() else None
def SHA(p):
    p = config.path(p); return hashlib.sha256(p.read_bytes()).hexdigest() if p.exists() else None
C2_TRANSFORM = "c2_tm_pif_v1"; C2_TRANSFORM_SHA256 = "782eaef3e95c9dbe4b79868d936fd1e96ff1aa681d93ad609b5463ddd119db47"   # frozen in Phase 6 (D2), commit 0282f07
C2TM_YEARS = [1990, 1991, 1992, 1998, 1999, 2000, 2001, 2008, 2009, 2010, 2011]
PERIOD_RELS = ("annual", "seasonal/dry", "seasonal/post_monsoon", "seasonal/wet")
COUNTERSIGN = "experiments/registry4/addenda/phase6_countersignature.json"   # template: docs/templates/phase6_countersignature_TEMPLATE.json
T1_MIN_LABELLED_SHARE = 0.8   # per split (train, tuning) and epoch (2020, 2000): 'labelled' = definite class or unavailable, as for gold

def feature_cube_ok(cube: str, report: str, family: str) -> tuple[bool, str]:
    """The validation report must belong to THIS cube: same resolved path, same sidecar SHA-256, expected Landsat family, ok = true."""
    c = config.path(cube); fv = J(report) or {}; side = c.with_suffix(".json")
    if not c.exists(): return False, f"{cube} absent"
    if fv.get("ok") is not True: return False, f"{report}: not validated / not ok"
    if fv.get("path") != str(c.resolve()): return False, f"{report} validated {fv.get('path')}, not {cube}"
    if not side.exists() or fv.get("sidecar_sha256") != SHA(side): return False, "cube sidecar changed after validation (or missing)"
    if fv.get("family") != family: return False, f"report family {fv.get('family')} != {family}"
    return True, f"{cube} validated (sidecar {fv['sidecar_sha256'][:12]})"

def countersigned(decision: str, addendum: str) -> tuple[bool, str]:
    cs = J(COUNTERSIGN) or {}; d = (cs.get("decisions") or {}).get(decision) or {}
    ok = bool(str(cs.get("researcher_name", "")).strip()) and bool(cs.get("signed_utc")) and d.get("verdict_accepted") is True and d.get("addendum_sha256") == SHA(addendum)
    return ok, (f"countersigned by {cs.get('researcher_name')} {cs.get('signed_utc')}" if ok else f"no valid researcher countersignature for {decision} in {COUNTERSIGN}")

def checklist(eid: str) -> dict:
    rec = P4.load(eid); proto = P4.load_protocol(); fz = proto["frozen"]; items = {}
    def it(name, ok, evidence): items[name] = {"ok": bool(ok), "evidence": evidence}
    it("protocol_code_hash_unchanged", P4.code_hash() == fz["code_sha256"] == rec.get("eval_code_sha256"), P4.code_hash()[:12])
    it("protocol_yaml_hash_unchanged", P4.protocol_hash() == fz["protocol_sha256"], P4.protocol_hash()[:12])
    it("protocol_version_matches_record", rec.get("protocol_version") == proto["protocol_version"], rec.get("protocol_version"))
    cc = P4.check_confirmatory_records(); it("registry_status_pending_and_G8_ok", rec["status"] == "PENDING" and cc["records"].get(eid, {}).get("ok", False), rec["status"])
    ga = J("results/phase5/gold/gold_audit.json") or {}
    it("tier_A_gold_ingested", ga.get("ingest") == "PASS", ga.get("ingest_error", "no audit")[:120] if ga.get("ingest") != "PASS" else "PASS")
    g2 = ga.get("g2", {}); per = g2.get("per_epoch", {})
    need = [e for e in EPOCHS[eid] if e in (2020, 2000)]
    it("G2_passed_for_2020_and_2000", g2.get("status") == "PASS", g2.get("reason"))
    for e in EPOCHS[eid]:
        d = (ga.get("description") or {}).get(str(e)) or (ga.get("description") or {}).get(e)
        it(f"gold_labelled_epoch_{e}", bool(d) and d.get("labelled_share", 0) >= 0.8, f"labelled_share={d.get('labelled_share') if d else 0}")
    ec = J("results/phase5/entry/entry_checks.json")["checks"]
    it("validation_blocks_correct", ec["design_points_in_hashed_validation_blocks"]["ok"] and ec["validation_block_raster_matches_reimplementation"]["ok"], "entry_checks.json")
    it("training_exclusion_2km_correct", ec["training_eligible_cells_ge_2km_from_validation_blocks"]["ok"] and ec["design_points_ge_2km_from_training_eligible"]["ok"], "entry_checks.json")
    cv = J("results/phase5/cube_validation/validation_report_min.json") or {}
    it("district_cube_validated_for_registered_years_and_periods", cv.get("ok") and cv.get("complete_for_required"), f"missing {len(cv.get('missing_required', ['all']))} year/period products" if cv else "no validation of the confirmatory minimum")
    fok, fev = feature_cube_ok("data/features/cube/pune_G30.zarr", "results/phase6/feature_cube_validation.json", "landsat")
    it("registered_feature_set_on_district_grid", fok, fev)
    seeds = proto["seeds"]["values"]; it("seeds_equal_protocol", rec.get("seeds") == seeds, rec.get("seeds"))
    it("statistical_test_and_FDR_family_defined", bool(proto["tests"]["decision_rule"]) and proto["tests"]["multiplicity"]["method"] == "benjamini_hochberg" and bool(rec.get("family")), rec.get("family"))
    A1 = "experiments/registry4/addenda/P4-C1_at_v2_addendum_1.json"; add = config.path(A1).exists()
    it("tuning_split_rule_adopted", add, f"adopted ({A1}, sha {str(SHA(A1))[:12]})" if add else "PROPOSED only (addendum not approved)")
    if eid == "P4-C1@v2":
        it("arms_operationally_defined (addendum approved)", add, f"adopted with corrections: {A1} + erratum-1" if add else "experiments/registry4/addenda/P4-C1_at_v2_addendum_1_PROPOSED.json awaits approval")
        ok_cs, ev_cs = countersigned("D1", A1); it("researcher_countersignature_D1", ok_cs, ev_cs)
        ta = J("results/phase5/t1/t1_audit.json") or {}; desc = ta.get("description_by_split") or {}
        short = {f"{sp}/{e}": (desc.get(sp) or {}).get(str(e), {}).get("labelled_share", 0) for sp in ("train", "tuning") for e in (2020, 2000)}
        t1ok = ta.get("ingest") == "PASS" and all(v >= T1_MIN_LABELLED_SHARE for v in short.values())
        it("human_training_labels_T1_ingested", t1ok, f"PASS; labelled share {short}" if t1ok else ((ta.get("ingest_error") or "no T1 audit")[:120] if ta.get("ingest") != "PASS" else f"labelled share below {T1_MIN_LABELLED_SHARE}: {short}"))
        sv = J("results/phase6/district_silver_validation.json") or {}
        it("district_silver_arm_A_built", config.path("data/labels/pune_G30_district_silver").exists() and sv.get("ok") is True,
           "district silver validated" if sv.get("ok") is True else "district silver (WorldCover/Esri 10 m purity) not built / no validation report results/phase6/district_silver_validation.json with ok = true")
    else:
        c1 = P4.load("P4-C1@v2")
        it("selection_prerequisite_P4-C1@v2_completed", c1["status"] == "PASS", f"P4-C1@v2 is {c1['status']} (selection uses its TUNING-split results)")
    if eid == "P4-C6@v2":
        S1 = config.path("data/composites/pune_G30/2020/sentinel1"); months = len(list(S1.glob("monthly/*/metadata.json"))) if S1.exists() else 0
        s1ok = (S1 / "seasonal/dry/metadata.json").exists() and (S1 / "seasonal/wet/metadata.json").exists() and months >= 6
        it("sentinel1_rtc_2020_on_district_grid", s1ok, f"dry/wet seasonal + {months} monthly S1 RTC products" if S1.exists() else "S1 RTC district 2020 not built")
    if eid == "P4-C2@v2":
        A2 = "experiments/registry4/addenda/P4-C2_at_v2_addendum_1.json"; c2a = config.path(A2).exists()
        it("cross_sensor_transform_fixed (decision D2)", c2a, "approved addendum fixing 'published coefficients' vs 'PIF-fitted on non-validation blocks'" if c2a else "decision D2 open: the record allows two transforms; choosing after gold results would be a forking path")
        ok_cs, ev_cs = countersigned("D2", A2); it("researcher_countersignature_D2", ok_cs, ev_cs)
        tfp = f"results/harmonization/{C2_TRANSFORM}.yaml"; rep_ = J("results/phase6/d2/pif_fit_report.json") or {}
        tf_ok = SHA(tfp) == C2_TRANSFORM_SHA256 and rep_.get("transform_sha256") == C2_TRANSFORM_SHA256 and rep_.get("addendum_sha256") == SHA(A2)
        it("c2_treatment_transform_frozen", tf_ok, f"{tfp} sha256 {C2_TRANSFORM_SHA256[:12]} (pinned)" if tf_ok else "treatment transform missing or hash differs from the pinned value")
        good, n = 0, 0
        for y in C2TM_YEARS:
            for rel in PERIOD_RELS:
                n += 1; m = J(f"data/composites/pune_G30/{y}/landsat_c2tm/{rel}/metadata.json") or {}; pr = m.get("processing", {})
                good += pr.get("harmonization") == C2_TRANSFORM and pr.get("transform_sha256") == C2_TRANSFORM_SHA256
        cv2 = J("results/phase6/cube_validation_c2tm.json") or {}
        cv2_ok = cv2.get("ok") is True and cv2.get("complete_for_required") is True and cv2.get("family") == "landsat_c2tm" and cv2.get("expect_transform_sha256") == C2_TRANSFORM_SHA256
        it("c2_treatment_family_built", good == n and cv2_ok, f"{good}/{n} landsat_c2tm products made with {C2_TRANSFORM} (sha pinned); family validation ok = {cv2.get('ok')}, complete = {cv2.get('complete_for_required')}")
        fok2, fev2 = feature_cube_ok("data/features/cube/pune_G30_landsat_c2tm.zarr", "results/phase6/feature_cube_validation_pune_G30_landsat_c2tm.json", "landsat_c2tm")
        it("c2_treatment_feature_cube_validated", fok2, fev2)
    ok = all(v["ok"] for v in items.values())
    return {"experiment_id": eid, "run_allowed": ok, "decision": "RUN" if ok else "DO NOT RUN", "failed": [k for k, v in items.items() if not v["ok"]], "items": items}

def assert_runnable(eid: str):
    c = checklist(eid)
    if not c["run_allowed"]: raise RuntimeError(f"{eid}: pre-run checklist failed ({len(c['failed'])} items): {c['failed']}")
    return c

if __name__ == "__main__":
    res = {"created_utc": utcnow(), "records": {e: checklist(e) for e in EPOCHS}}
    (OUT / "prerun_checklists.json").write_text(json.dumps(res, indent=1, default=str))
    for e, c in res["records"].items(): print(e, c["decision"], f"{len(c['failed'])} failed:", c["failed"])
