"""Phase 6: final blind interpreter kits (gold A/B, T1 v2 A/B) -> /mnt/user-data/outputs/phase6/kits/ and a machine-readable kit manifest.
Each kit contains ONLY: the form, a KML with that interpreter's cells only, docs/phase6_interpreter_protocol.md, a metadata template.
Blindness checks (fail loudly): no design/key fields in forms or KML names; B kits contain only the double-interpretation subset; no strata/product/region words in the
protocol; form IDs equal the key IDs of that role. The Phase-4/5 kits included the full gold protocol (with the sampling design and product names) and, for B, a KML of
all 641 points: they are superseded by these kits."""
import hashlib, json, os, re, sys, zipfile
from pathlib import Path
import pandas as pd
sys.path.insert(0, "src")
from pune_eo import config
from pune_eo.grid import district_grid
from pune_eo.provenance import utcnow
from pyproj import Transformer
R = config.ROOT; OUT = Path(os.environ.get("KIT_OUT", "/mnt/user-data/outputs/phase6/kits")); OUT.mkdir(parents=True, exist_ok=True)
PROTO = R / "docs/phase6_interpreter_protocol.md"; G = district_grid("G30"); t = Transformer.from_crs(G.crs, 4326, always_xy=True)
FORBIDDEN = re.compile(r"stratum|strata|validation block|disagreement|worldcover|esri|glc|ghsl|wsf|gisa|dynamic world|prediction|model output|region", re.I)
def ring(x, y, half=15.0):
    pts = [(x - half, y - half), (x + half, y - half), (x + half, y + half), (x - half, y + half), (x - half, y - half)]; lo, la = t.transform(*zip(*pts)); return " ".join(f"{a:.7f},{b:.7f},0" for a, b in zip(lo, la))
def kml(sub, title):
    k = [f'<?xml version="1.0" encoding="UTF-8"?><kml xmlns="http://www.opengis.net/kml/2.2"><Document><name>{title}</name>'
         '<Style id="c"><LineStyle><color>ff00ffff</color><width>2</width></LineStyle><PolyStyle><fill>0</fill></PolyStyle></Style>']
    for _, r in sub.iterrows():
        k.append(f'<Placemark><name>{r.anon_id}</name><styleUrl>#c</styleUrl><MultiGeometry><Point><coordinates>{r.lon:.7f},{r.lat:.7f},0</coordinates></Point>'
                 f'<Polygon><outerBoundaryIs><LinearRing><coordinates>{ring(r.x_utm, r.y_utm)}</coordinates></LinearRing></outerBoundaryIs></Polygon></MultiGeometry></Placemark>')
    return "".join(k) + "</Document></kml>"
def meta_template(role): return json.dumps({"interpreter_role": role, "interpreter_id": "<your pseudonym>", "interpreter_type": "human", "software": "Google Earth Pro <version>",
                                            "interpretation_start": "YYYY-MM-DD", "interpretation_end": "YYYY-MM-DD", "blind_declaration": True}, indent=1)
proto_txt = PROTO.read_text(); hits = [m.group(0) for m in FORBIDDEN.finditer(proto_txt.split("## 1.")[1].split("You must not receive")[0])]
assert not hits, f"protocol leaks design words: {hits}"
KITS = {"gold": (R / "data/labels/gold/phase4", "_key/phase4_gold_key.csv", "blind/form_interpreter_A.csv", "blind/form_interpreter_B.csv"),
        "T1v2": (R / "data/labels/training/phase6_T1v2", "_key/T1_key.csv", "blind/form_T1_interpreter_A.csv", "blind/form_T1_interpreter_B.csv")}
man = {"created_utc": utcnow(), "protocol_sha256": hashlib.sha256(PROTO.read_bytes()).hexdigest(), "kits": {}}
for name, (base, key, fa, fb) in KITS.items():
    K = pd.read_csv(base / key)
    for role, f in (("A", fa), ("B", fb)):
        form = pd.read_csv(base / f); ids = set(form.anon_id)
        expect = set(K.anon_id) if role == "A" else set(K.anon_id[K.double_interpretation.astype(bool)])
        assert ids == expect, f"{name} {role}: form IDs differ from the key subset"
        assert not (set(form.columns) & {"stratum", "region", "block", "row", "col", "split", "boundary", "double_interpretation"}), f"{name} {role}: design fields in form"
        assert form.drop(columns=["anon_id", "lat", "lon"]).isna().all().all(), f"{name} {role}: form not blank"
        sub = K[K.anon_id.isin(ids)].merge(form[["anon_id"]], on="anon_id"); kx = kml(sub, f"Pune cells to interpret ({role})")
        assert kx.count("<Placemark>") == len(ids)
        zp = OUT / f"phase6_{name}_kit_INTERPRETER_{role}.zip"
        with zipfile.ZipFile(zp, "w", zipfile.ZIP_DEFLATED) as z:
            z.writestr(f"{name}_form_interpreter_{role}.csv", (base / f).read_text()); z.writestr(f"{name}_cells_interpreter_{role}.kml", kx)
            z.writestr("INTERPRETER_PROTOCOL.md", proto_txt); z.writestr(f"{name}_form_interpreter_{role}.meta.json.TEMPLATE", meta_template(role))
        man["kits"][f"{name}_{role}"] = {"zip": zp.name, "sha256": hashlib.sha256(zp.read_bytes()).hexdigest(), "n_cells": len(ids), "form_sha256": hashlib.sha256((base / f).read_bytes()).hexdigest(),
                                          "key_sha256": hashlib.sha256((base / key).read_bytes()).hexdigest()}
(R / "results/phase6").mkdir(parents=True, exist_ok=True); (R / "results/phase6/kit_manifest.json").write_text(json.dumps(man, indent=1)); print(json.dumps(man, indent=1))
