"""Phase 6: execution status, readiness gate, machine-readable decision records and the reproducibility manifest - generated FROM SAVED FILES ONLY
(registry, addenda, checklists, audits, fit report, kit manifest, validation reports). Writes docs/phase6_execution_status.md, docs/phase6_readiness_gate.md,
results/phase6/decisions/{D1,D2,D3}.json, results/phase6/phase6_status.json, results/phase6/reproducibility_manifest.json."""
import glob, hashlib, json, platform, subprocess, sys
from pathlib import Path
sys.path.insert(0, "src")
from pune_eo import config
from pune_eo.evaluation4 import protocol as P4
from pune_eo.provenance import utcnow
R6 = config.path("results/phase6"); (R6 / "decisions").mkdir(parents=True, exist_ok=True); D = config.path("docs")
git = lambda *a: subprocess.run(["git", *a], capture_output=True, text=True, cwd=config.ROOT).stdout.strip()
DIRTY0 = bool(git("status", "--porcelain"))
def J(p):
    p = config.path(p); return json.loads(p.read_text()) if p.exists() else None
def sha(p):
    h = hashlib.sha256()
    with open(p, "rb") as f:
        for b in iter(lambda: f.read(1 << 22), b""): h.update(b)
    return h.hexdigest()
pre = J("results/phase5/confirmatory/prerun_checklists.json"); gold = J("results/phase5/gold/gold_audit.json"); t1a = J("results/phase5/t1/t1_audit.json")
fit = J("results/phase6/d2/pif_fit_report.json"); kits = J("results/phase6/kit_manifest.json"); cvmin = J("results/phase5/cube_validation/validation_report_min.json")
fcv = J("results/phase6/feature_cube_validation.json"); TER = J("data/features/terrain/pune_G30/metadata.json") or {}; TRS = J("results/phase6/terrain_run_status.json");t1d = J("data/labels/training/phase6_T1v2/sampling_design/design.json")
A1 = config.path("experiments/registry4/addenda/P4-C1_at_v2_addendum_1.json"); A2 = config.path("experiments/registry4/addenda/P4-C2_at_v2_addendum_1.json")
E1 = config.path("experiments/registry4/addenda/P4-C1_at_v2_addendum_1_erratum_1.json"); E2 = config.path("experiments/registry4/addenda/P4-C2_at_v2_addendum_1_erratum_1.json")
CS = J("experiments/registry4/addenda/phase6_countersignature.json") or {}
fz = P4.load_protocol()["frozen"]; cc = P4.check_confirmatory_records()
gold_n = 0
if gold and gold.get("ingest") == "PASS":
    import pandas as pd
    f = pd.read_csv(config.path("data/labels/gold/phase4/ingested/gold_reference_labels.csv")); gold_n = int(f.labelled.sum())
# ---------------------------------------------------------------- decision records
D1 = {"decision": "D1", "verdict": "APPROVE WITH SPECIFIC CORRECTION", "record": "P4-C1@v2", "addendum": str(A1.relative_to(config.ROOT)), "addendum_sha256": sha(A1),
      "proposal": "experiments/registry4/addenda/P4-C1_at_v2_addendum_1_PROPOSED.json", "proposal_sha256": sha(config.path("experiments/registry4/addenda/P4-C1_at_v2_addendum_1_PROPOSED.json")),
      "review": "docs/phase6_D1_review.md", "corrections": json.loads(A1.read_text())["corrections_vs_proposal"], "T1": json.loads(A1.read_text())["T1"],
      "erratum": {"path": str(E1.relative_to(config.ROOT)), "sha256": sha(E1), "items": list(json.loads(E1.read_text())["items"])} if E1.exists() else None,
      "researcher_countersignature": CS.get("decisions", {}).get("D1", {}).get("verdict_accepted") is True, "protocol_changed": False, "created_utc": utcnow()}
D2 = {"decision": "D2", "record": "P4-C2@v2", "addendum": str(A2.relative_to(config.ROOT)), "addendum_sha256": sha(A2), "selected": json.loads(A2.read_text())["selected"],
      "fallback": json.loads(A2.read_text())["fallback"], "fit": ({k: fit[k] for k in ("feasible", "n_pairs_used", "n_tm_days_ge50", "n_cells", "transform_file", "transform_sha256", "coefficients_rma")} if fit else "NOT RUN"),
      "treatment_in_force": (fit or {}).get("transform_file"),
      "count_definitions": {"n_pairs_used": "distinct TM scenes (TM date x path/row) = 45; 61 L5xL7 pairs planned over them; 16 TM scenes have two L7 partners (104 831 of 195 457 sample rows)",
                            "n_cells": "cell x pair samples; distinct eroded eligible PIF cells: water 75 246, forest 986 475, impervious 3 406", "pair_years": "2000-2001, 2008-2011 (searched 1999-2011)"},
      "erratum": {"path": str(E2.relative_to(config.ROOT)), "sha256": sha(E2)} if E2.exists() else None,
      "researcher_countersignature": CS.get("decisions", {}).get("D2", {}).get("verdict_accepted") is True,
      "doc": "docs/phase6_D2_sensor_correction_decision.md", "gold_used": False, "protocol_changed": False, "created_utc": utcnow()}
D3 = {"decision": "D3", "selected": "Route A: repository engine on Planetary Computer, larger machine (8 vCPU, 32 GB RAM, >= 200 GB SSD, Azure West Europe recommended)",
      "rejected": "Route B: Earth Engine export (different code path, never executed, no S1 RTC)", "doc": "docs/phase6_D3_compute_decision.md",
      "executed_here": False, "reason_not_executed": "sandbox: 2 CPUs, 6 GB memory cgroup, ~13 GB free disk; registered minimum needs ~65-80 GB (85-110 GB with the C2 treatment feature cube) and ~10 h on 2 CPUs; district terrain OOM-killed at 6 GB",
      "scenes_registered_minimum": 1203, "scenes_c2_treatment_family": 477, "s1_2020_scenes": 107, "created_utc": utcnow()}
for n, d in (("D1", D1), ("D2", D2), ("D3", D3)): (R6 / "decisions" / f"{n}.json").write_text(json.dumps(d, indent=1, default=str))
# ---------------------------------------------------------------- status
recs = {e: c for e, c in pre["records"].items()}
st = {"created_utc": utcnow(), "git": git("rev-parse", "HEAD"), "protocol": {"code_sha256": P4.code_hash(), "yaml_sha256": P4.protocol_hash(), "unchanged": P4.code_hash() == fz["code_sha256"] and P4.protocol_hash() == fz["protocol_sha256"]},
      "g8_check_confirmatory_records": cc["ok"], "human_gold": {"available": bool(gold and gold.get("ingest") == "PASS"), "valid_labels": gold_n, "double_interpretations": 0 if gold_n == 0 else None,
      "g2": (gold or {}).get("g2", {}).get("status", "FAIL")}, "t1": {"available": bool(t1a and t1a.get("ingest") == "PASS"), "status": (t1a or {}).get("ingest", "NOT RUN"), "design_points": (t1d or {}).get("n_points")},
      "district_cube": {"state": "PILOT" if not (cvmin and cvmin.get("complete_for_required")) else "COMPLETE", "validation_min": {k: (cvmin or {}).get(k) for k in ("ok", "complete_for_required")},
                        "missing_required": len((cvmin or {}).get("missing_required", [])), "feature_cube_validation": (fcv or {}).get("ok", "NOT BUILT")},
      "confirmatory": {e: ("DO NOT RUN" if not c["run_allowed"] else "RUNNABLE") if P4.load(e)["status"] == "PENDING" else P4.load(e)["status"] for e, c in recs.items()},
      "confirmatory_failed_items": {e: c["failed"] for e, c in recs.items()}, "readiness": "NOT_READY"}
(R6 / "phase6_status.json").write_text(json.dumps(st, indent=1, default=str))
L = ["# Phase 6 — execution status", "", f"_Generated {utcnow()} by `scripts/write_phase6_docs.py` from saved files; git {git('rev-parse', '--short', 'HEAD')}._", "",
     f"Protocol v2 unchanged: code `{P4.code_hash()[:12]}`, YAML `{P4.protocol_hash()[:12]}` (frozen values match: {st['protocol']['unchanged']}); `check_confirmatory_records()` ok = {cc['ok']}. "
     "**No confirmatory experiment was run**: every pre-run checklist says DO NOT RUN, and no result was overridden.", "",
     "## 1. Decisions", "", "| decision | outcome | record |", "|---|---|---|",
     f"| D1 (P4-C1@v2 arms, tuning split, T1) | **{D1['verdict']}** | `{D1['addendum']}` (sha `{D1['addendum_sha256'][:12]}`); proposal kept unchanged |",
     f"| D2 (P4-C2@v2 cross-sensor transform) | **PIF-fitted TM → cube OLI-equivalent (RMA)**{', fit feasible' if fit and fit.get('feasible') else (', FALLBACK to Roy et al. 2016' if fit else ', fit NOT RUN')} | `{D2['addendum']}`; `{D2['treatment_in_force']}` |",
     f"| D3 (full cube compute) | **Route A**, not executable in this sandbox | `docs/phase6_D3_compute_decision.md` |", "",
     "## 2. Human labels", "", "| set | design | labels | ingestion | gate |", "|---|---|---|---|---|",
     f"| Tier-A gold | 641 points, 160 double | {gold_n} | {(gold or {}).get('ingest', 'NOT RUN')} | G2 {st['human_gold']['g2']} |",
     f"| T1 v2 (training/selection) | {(t1d or {}).get('n_points')} points ({(t1d or {}).get('split_counts')}) | 0 | {st['t1']['status']} | required by P4-C1@v2 |", "",
     "Blind kits (form + role-specific KML + interpreter protocol + metadata template only): " + (", ".join(f"`{v['zip']}` ({v['n_cells']} cells)" for v in kits["kits"].values()) if kits else "not built") + ".", "",
     "## 3. District data foundation", "", "| component | state | evidence |", "|---|---|---|",
     f"| Landsat standard family (18 years × 4 periods) | {st['district_cube']['state']}: {72 - st['district_cube']['missing_required']}/72 products | `validate_district_cube.py --require min`: ok = {(cvmin or {}).get('ok')}, complete_for_required = {(cvmin or {}).get('complete_for_required')} |",
     "| C2 treatment family (11 TM years × 4 periods) + treatment feature cube | not built | needs Route A; checked by `c2_treatment_family_built` (transform SHA pinned) and `c2_treatment_feature_cube_validated` |", "| Sentinel-1 RTC 2020 | not built (writer tested equal to the engine; strip driver untested, needs Planetary Computer) | `docs/phase6_sentinel1_spec.md` |",
     (f"| district terrain | **built** (12 bands; {TER.get('grid', {}).get('width')} x {TER.get('grid', {}).get('height')}; 3 km buffer) | `data/features/terrain/pune_G30/metadata.json` |" if TER else
      f"| district terrain | not built: attempted here, **{(TRS or {}).get('outcome', 'not attempted')}** (6 GB memory limit) → Route A; district mode implemented, window behaviour unchanged | `results/phase6/terrain_run_status.json` |"),
     f"| feature cube `pune_G30.zarr` | {'validated' if (fcv or {}).get('ok') else 'not built'} (strip builder tested equal to the window builder) | `scripts/phase6_build_feature_cube.py`, `src/data/validate_feature_cube.py` |",
     "| district silver (arm A) | not built; **no district builder yet** (window code `src/pune_eo/labels/silver.py`) | must write `data/labels/pune_G30_district_silver` + `results/phase6/district_silver_validation.json` (ok) |", "",
     "## 3b. Code still to be written before P4-C1@v2 can run (engineering, no data needed)", "",
     "* District silver builder + validator (arm A; strip-wise version of `labels/silver.py`).",
     "* The confirmatory runner for P4-C1@v2: arms A-E, PELT extension (arm B), RF/TempCNN training, selection on the T1 tuning split, gold evaluation, BH. It must call `assert_runnable()` first. It can be written and unit-tested on synthetic data before any label exists.", "",
     "## 4. Confirmatory records (pre-run checklists, never overridden)", "", "| record | decision | failed items |", "|---|---|---|"]
for e, c in recs.items(): L.append(f"| {e} | {st['confirmatory'][e]} | {len(c['failed'])}: {', '.join(c['failed'])} |")
L += ["", "## 5. Not done, by rule", "", "* No confirmatory run, no model trained for any P4 record, no historical maps, no district-wide inference, no scenarios.",
      "* No label of any kind was produced: gold and T1 come only from human interpreters.", "* Protocol v2 unchanged; records changed only by append-only `addenda` pointers (P4-C1@v2, P4-C2@v2)."]
(D / "phase6_execution_status.md").write_text("\n".join(L))
# ---------------------------------------------------------------- readiness gate
gates = [("G1 Data foundation", "PARTIAL", "4 dry-season district epochs validated and bit-identical to the windows; registered minimum 4/72 products; district terrain attempted here and OOM-killed; feature cube not built", "Route A not executed (compute boundary)", "run the Route-A command block (docs/phase6_D3_compute_decision.md §4)"),
         ("G2 Human validation", st["human_gold"]["g2"], f"gold_audit.json: {gold_n} Tier-A labels", "no human interpretation yet", "hand phase6_gold_kit_INTERPRETER_A/B to two independent interpreters (2020, then 2000)"),
         ("G3 Existing-product benchmark", "PARTIAL", "unchanged from Phase 5 (7 products + JRC; DW/GAIA need Earth Engine)", "Dynamic World, GAIA; ALOS FNF and MS buildings not acquired", "optional; does not block confirmatory runs"),
         ("G4 Training-label quality", "FAIL", f"P4-C1@v2 {st['confirmatory']['P4-C1@v2']} ({len(recs['P4-C1@v2']['failed'])} items); D1 resolved", "gold, T1 labels, D1 countersignature, district silver (builder not yet written), feature cube, confirmatory runner", "researcher countersigns D1; T1 interpretation (phase6_T1v2 kits); Route A; silver builder + runner"),
         ("G5 Historical validity", "FAIL", "no admissible reconstruction (none allowed before C1-C3); envelope frozen (P5-X3); D2 fixed", "gold 1990/2000/2010/2020, C1-C3", "after G2 and G1"),
         ("G6 Spatial generalisation", "FAIL", f"P4-C4@v2 {st['confirmatory']['P4-C4@v2']}", "gold, cube, C1 selection", "after G2 and G1"),
         ("G7 Uncertainty", "FAIL", f"P4-C5@v2 {st['confirmatory']['P4-C5@v2']}", "gold", "after G2"),
         ("G8 Confirmatory experiment", "PARTIAL", f"check_confirmatory_records ok = {cc['ok']}; hashes unchanged; addenda registered before any data; 0/6 executed", "all prerequisites", "re-run the checklists; run each record once when RUN"),
         ("G9 District scale", "FAIL", "requires G1, G5, G6, G7", "G1, G5, G6, G7", "-")]
GL = ["# Phase 6 — readiness gate", "", f"_Generated {utcnow()} by `scripts/write_phase6_docs.py`. Framework G1-G9 of protocol v2 (unchanged)._", "",
      "| gate | STATUS | EVIDENCE | BLOCKER | NEXT ACTION |", "|---|---|---|---|---|"] + [f"| {a} | **{b}** | {c} | {d} | {e} |" for a, b, c, d, e in gates]
GL += ["", "## FINAL STATUS: **NOT_READY**", "", "The hypotheses still cannot be tested. The project stopped at two boundaries:", "",
       "1. **Human-label boundary:** 0 Tier-A gold labels and 0 T1 labels.", "2. **Compute boundary:** the registered district cube needs the Route-A machine.", "",
       "Every decision that could be taken without data has been taken and registered (D1, D2, D3), pending the researcher's countersignature of D1 and D2. Label ingestion, the cube/S1/terrain/feature-cube builders and the validators are built; most are tested on synthetic data (the S1 strip driver is not). Still to be written: the district silver builder and the confirmatory runner (`docs/phase6_execution_status.md` §3b). District terrain was attempted here and OOM-killed.", "",
       "Single next action: **two independent human interpreters label the 641 gold points for 2020 (then 2000) using `phase6_gold_kit_INTERPRETER_A/B.zip`.** In parallel, the Route-A machine builds the cube."]
(D / "phase6_readiness_gate.md").write_text("\n".join(GL))
# ---------------------------------------------------------------- manifest
code = sorted(set(glob.glob(str(config.path("scripts/phase6_*.py"))) + [str(config.path(p)) for p in ("scripts/write_phase6_docs.py", "scripts/phase5_prerun_checklists.py", "scripts/phase5_district_cube_pilot.py", "src/validation/ingest_gold.py",
        "src/validation/audit_gold.py", "src/data/validate_district_cube.py", "src/data/validate_feature_cube.py", "src/pune_eo/compositing/lean_writer.py", "src/pune_eo/feature_engineering/cube.py",
        "src/pune_eo/feature_engineering/terrain.py", "src/pune_eo/harmonization/landsat.py",
        "tests/test_phase6_guards.py", "tests/test_district_feature_cube.py", "tests/test_gold_ingestion.py", "tests/test_lean_writer.py")]))
datasets = [p for p in glob.glob(str(config.path("data/labels/training/phase6_T1v2/**/*")), recursive=True) if Path(p).is_file()] + \
           [str(config.path(p)) for p in ("experiments/registry4/addenda/P4-C1_at_v2_addendum_1.json", "experiments/registry4/addenda/P4-C2_at_v2_addendum_1.json", "experiments/registry4/P4-C1_at_v2.json", "experiments/registry4/P4-C2_at_v2.json",
                                         "docs/phase6_interpreter_protocol.md", "docs/templates/phase6_countersignature_TEMPLATE.json",
                                         "experiments/registry4/addenda/P4-C1_at_v2_addendum_1_erratum_1.json", "experiments/registry4/addenda/P4-C2_at_v2_addendum_1_erratum_1.json")] + glob.glob(str(config.path("results/harmonization/c2_tm_*.yaml"))) + \
           [p for p in glob.glob(str(config.path("results/phase6/**/*")), recursive=True) if Path(p).is_file() and "reproducibility_manifest" not in p and not p.endswith(".log")]
import importlib.metadata as md
pk = {}
for n in ("numpy", "pandas", "rasterio", "scipy", "xarray", "zarr", "dask", "geopandas", "pystac-client", "planetary-computer", "pysheds", "scikit-learn"):
    try: pk[n] = md.version(n)
    except Exception: pk[n] = None
man = {"created_utc": utcnow(), "git_head": git("rev-parse", "HEAD"), "git_dirty_before_doc_generation": DIRTY0, "python": platform.python_version(), "packages": pk,
       "protocol": {"version": 2, "code_sha256": P4.code_hash(), "yaml_sha256": P4.protocol_hash()},
       "seeds": {"T1 v2 design": 20261221, "D2 PIF sampling": 20261141, "D2 cluster bootstrap": 20261142, "confirmatory (protocol)": [20261201, 20261202, 20261203, 20261204, 20261205]},
       "commands_in_order": ["python3 scripts/phase6_c2_pif_fit.py  (after registering experiments/registry4/addenda/P4-C2_at_v2_addendum_1.json)", "python3 scripts/phase6_training_sample_T1v2.py",
                             "python3 scripts/phase6_make_kits.py", "python3 src/validation/audit_gold.py", "python3 src/validation/audit_gold.py --t1", "python3 scripts/phase5_prerun_checklists.py",
                             "python3 scripts/write_phase6_docs.py", "python3 -m pytest -q tests"],
       "code_sha256": {str(Path(p).relative_to(config.ROOT)): sha(p) for p in code}, "datasets_and_configs_sha256": {str(Path(p).relative_to(config.ROOT)): sha(p) for p in sorted(set(datasets))},
       "kits_sha256": {k: v["sha256"] for k, v in (kits or {}).get("kits", {}).items()}, "registry_records_sha256": {Path(p).stem: sha(p) for p in sorted(glob.glob(str(config.path("experiments/registry4/*.json"))))}}
(R6 / "reproducibility_manifest.json").write_text(json.dumps(man, indent=1, default=str))
print("written: docs/phase6_execution_status.md, docs/phase6_readiness_gate.md, results/phase6/decisions/*.json, results/phase6/phase6_status.json, results/phase6/reproducibility_manifest.json")
