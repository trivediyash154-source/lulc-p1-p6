"""P5-E2 (EXPLORATORY, pre-registered): residual sensor differences from NEAR-COINCIDENT cross-sensor pairs on pseudo-invariant features (PIFs).
Why: P4-E1 compared sensor regimes ACROSS YEARS, so sensor and time (land change, climate) were confounded. Two Landsat sensors image the same WRS-2 path/row 8 days apart;
on PIFs, land change over 8 days is negligible, so a systematic difference across many pairs is attributable to sensor/processing (plus 8-day phenology/water-level change and
atmosphere/geometry noise - see the identifiability notes written to the output).
Design (fixed before running): selected manifest scenes, Jan-May, scene cloud <= 20 %, same path/row, |dt| <= 8 days.
  E2a/E2b: L5 vs L7 1999-2011 (all pairs; L7 raw and L7 harmonised with local_pune_g30_v2);  E2c: L7-harmonised vs L8 2013-2016 (40 pairs) + 2017-2021 (20 pairs, orbit drift);
  E2d: L8 vs L9 2021-2026 (40 pairs). Pairs sampled with seed 20261131.
Read on pune_G240 (SR overviews averaged; a 240 m cell is clear only if all QA samples are clear). PIF cell = all 64 sub-cells PIF and training-eligible
(water: JRC occurrence >= 95 and GLC_FCS30D water in all 26 epochs; forest: GLC_FCS30D forest in all epochs; impervious: GLC_FCS30D impervious in all epochs and WSF first year 1985).
Per pair x PIF class x band: median over cells clear in both scenes of (a - b); summary: mean over pairs, pair-bootstrap 95 % CI (2000 reps)."""
import json, sys, time, warnings
from concurrent.futures import ThreadPoolExecutor
import numpy as np, pandas as pd, rasterio, geopandas as gpd
sys.path.insert(0, "src"); warnings.filterwarnings("ignore")
from pune_eo import config
from pune_eo.grid import district_grid
from pune_eo.compositing import observations as obs
from pune_eo.harmonization import landsat as harm
from pune_eo.evaluation4 import protocol as P4
OUT = config.path("results/phase5/sensor_pairs"); OUT.mkdir(parents=True, exist_ok=True); SEED = 20261131; rng = np.random.default_rng(SEED)
G30, G240 = district_grid("G30"), district_grid("G240"); TR = "local_pune_g30_v2"; BANDS = obs.BAND_NAMES["landsat"]
run = P4.Run("P5-E2")
def rd(p, b=None):
    with rasterio.open(p) as s: return s.read() if b is None else s.read(b)
PX = config.path("data/products_ext"); LB = config.path("data/labels/pune_G30")
glc = rd(PX / "glc_fcs30d/glc_fcs30d_district_30m.tif"); jrc = rd(LB / "jrc_gsw.tif", 1); wsf = rd(LB / "wsf_evolution_first_year.tif", 1)
elig = rd(config.path("data/labels/gold/phase4/sampling_design/training_eligible_30m.tif"), 1).astype(bool)
FOREST = [51, 52, 61, 62, 71, 72, 81, 82, 91, 92]
aw, af, ai = np.ones(glc.shape[1:], bool), np.ones(glc.shape[1:], bool), np.ones(glc.shape[1:], bool)
for band in glc: aw &= band == 210; af &= np.isin(band, FOREST); ai &= band == 190
pif30 = {"water_pif": (jrc >= 95) & (jrc != 255) & aw, "forest_pif": af, "impervious_pif": ai & (wsf == 1985)}
del glc, jrc, wsf, aw, af, ai
H8, W8 = G240.height, G240.width
RO, CO = int(round((G240.y1 - G30.y1) / 30)), int(round((G30.x0 - G240.x0) / 30))      # G240 lattice is offset from G30 (rows +2, cols +7): place G30 inside the G240 frame
assert (G240.y1 - G30.y1) % 30 == 0 and (G30.x0 - G240.x0) % 30 == 0 and RO >= 0 and CO >= 0
def pure(m):
    big = np.zeros((H8 * 8, W8 * 8), bool); hh, ww = min(G30.height, H8 * 8 - RO), min(G30.width, W8 * 8 - CO)
    big[RO:RO + hh, CO:CO + ww] = (m & elig)[:hh, :ww]; return big.reshape(H8, 8, W8, 8).all(axis=(1, 3))
pif = {k: pure(v) for k, v in pif30.items()}; del pif30
counts = {k: int(v.sum()) for k, v in pif.items()}; print("pure 240 m PIF cells (training-eligible):", counts)
U = np.any(list(pif.values()), axis=0); pif = {k: v[U] for k, v in pif.items()}      # keep only PIF cells in memory (vectors over U)
m = gpd.read_parquet(config.path("data/manifests/landsat_manifest.parquet")); s = m[m.selected & (m.month <= 5) & (m.cloud_cover <= 20)].copy(); del m
s["d"] = pd.to_datetime(s.date); s["pr"] = s.wrs_path.astype(str) + "/" + s.wrs_row.astype(str)
def pairs(a, b, y0, y1, n):
    A, B = s[(s.platform == a) & s.year.between(y0, y1)], s[(s.platform == b) & s.year.between(y0, y1)]
    mm = A.merge(B, on="pr", suffixes=("_a", "_b")); mm = mm[(mm.d_b - mm.d_a).dt.days.abs() <= 8].sort_values(["d_a", "pr"]).reset_index(drop=True)
    return mm if n is None or len(mm) <= n else mm.iloc[np.sort(rng.choice(len(mm), n, replace=False))].reset_index(drop=True)
PLAN = {"E2ab_L5_vs_L7": pairs("landsat-5", "landsat-7", 1999, 2011, None), "E2c_L7h_vs_L8_2013_2016": pairs("landsat-7", "landsat-8", 2013, 2016, 40),
        "E2c2_L7h_vs_L8_2017_2021": pairs("landsat-7", "landsat-8", 2017, 2021, 20), "E2d_L8_vs_L9": pairs("landsat-8", "landsat-9", 2021, 2026, 40)}
need = {}
for k, P in PLAN.items():
    for _, r in P.iterrows():
        for sfx in ("_a", "_b"): need[r["product_id" + sfx]] = r
cols = [c for c in s.columns]
def load(pid):
    row = s[s.product_id == pid].iloc[0]
    for attempt in range(3):
        try:
            r = obs.landsat(row, G240, None)
            if r is None: return pid, None
            w = r["win"]; full = np.full((len(BANDS), H8, W8), np.nan, np.float32); st = np.zeros((H8, W8), np.uint8)
            r0, c0 = int(w.row_off), int(w.col_off); h, ww = r["values"].shape[1:]
            hh, wl = min(h, H8 - r0), min(ww, W8 - c0)
            full[:, r0:r0 + hh, c0:c0 + wl] = r["values"][:, :hh, :wl]; st[r0:r0 + hh, c0:c0 + wl] = r["status"][:hh, :wl]
            full[:, st != 2] = np.nan; return pid, (full[:, U].copy(), row["platform"])
        except Exception as e:
            err = repr(e); time.sleep(3)
    return pid, ("ERROR", err)
t0 = time.time(); CACHE = config.path("data/raw/phase5_sensor_pairs_cache.npz")    # attempt 1 crashed after reading (string/array comparison bug) - reads are now cached
if CACHE.exists():
    z = np.load(CACHE, allow_pickle=True); DATA = {k: (z[k], str(z[k + "__plat"])) for k in z.files if not k.endswith("__plat")}
    DATA.update({pid: None for pid in need if pid not in DATA})
else:
    with ThreadPoolExecutor(3) as ex: DATA = dict(ex.map(load, list(need)))
    ok_ = {k: v for k, v in DATA.items() if v is not None and not isinstance(v[0], str)}
    np.savez(CACHE, **{k: v[0] for k, v in ok_.items()}, **{k + "__plat": np.array(v[1]) for k, v in ok_.items()})
bad = lambda v: v is None or isinstance(v[0], str)
print(f"read {len(DATA)} scenes in {time.time() - t0:.0f}s; missing/errors {sum(1 for v in DATA.values() if bad(v))}")
def ndvi(x): return (x[3] - x[2]) / (x[3] + x[2])
def harmonise(x, plat): return np.stack([harm.apply({b: x[i]}, plat, TR)[b] for i, b in enumerate(BANDS)])   # x: (bands, cells)
rows = []
for k, P in PLAN.items():
    for _, r in P.iterrows():
        a, b = DATA.get(r.product_id_a), DATA.get(r.product_id_b)
        if bad(a) or bad(b): continue
        variants = {"raw": (a[0], b[0])}
        if k.startswith("E2ab"): variants["b_harmonised"] = (a[0], harmonise(b[0], b[1]))
        else: variants = {"harmonised": (harmonise(a[0], a[1]), harmonise(b[0], b[1]))}
        for vname, (xa, xb) in variants.items():
            for pc, pm in pif.items():
                ok = pm & np.isfinite(xa).all(0) & np.isfinite(xb).all(0)
                if ok.sum() < 5: continue
                rec = {"contrast": k, "variant": vname, "pif": pc, "pr": r.pr, "date_a": str(r.d_a.date()), "date_b": str(r.d_b.date()), "dt_days": int((r.d_b - r.d_a).days), "n_cells": int(ok.sum())}
                for i, bn in enumerate(BANDS): rec[bn] = float(np.median(xa[i][ok] - xb[i][ok]))
                rec["ndvi"] = float(np.median(ndvi(xa)[ok] - ndvi(xb)[ok])); rows.append(rec)
D = pd.DataFrame(rows); D.to_csv(OUT / "pair_differences.csv", index=False)
summ = []
for (c, v, pc), g in D.groupby(["contrast", "variant", "pif"]):
    for bn in BANDS + ["ndvi"]:
        x = g[bn].values; bs = [rng.choice(x, len(x)).mean() for _ in range(2000)]; lo, hi = np.percentile(bs, [2.5, 97.5])
        summ.append({"contrast": c, "variant": v, "pif": pc, "band": bn, "n_pairs": len(x), "mean_diff": float(x.mean()), "ci_lo": float(lo), "ci_hi": float(hi), "excludes_zero": bool(lo > 0 or hi < 0),
                     "median_cells_per_pair": float(g.n_cells.median())})
S = pd.DataFrame(summ); S.to_csv(OUT / "contrast_summary.csv", index=False)
ident = {"identified": "systematic sensor/processing difference on PIFs between two sensors 8 days apart on the same path/row",
         "not_separated": ["8-day phenology (forest, dry season: small) and reservoir level/turbidity change (water PIF)", "acquisition-time / sun-angle differences (L7 drift after ~2017: secondary period only)",
                           "BRDF and view geometry (same path: nominally identical; residual)", "atmosphere: random per date, averages out over pairs but not within a pair",
                           "240 m aggregation: PIF purity enforced, QA conservative; differences in SR overviews vs native 30 m not tested here"],
         "not_addressed": "land-cover change over decades (by design: 8-day pairs); seasonal composition differences of composites (pairs are single dates)"}
json.dump({"pif_cells_240m": counts, "n_pairs": {k: int(len(P)) for k, P in PLAN.items()}, "identifiability": ident}, open(OUT / "design_and_identifiability.json", "w"), indent=1)
key = S[(S.band.isin(["red", "nir08", "ndvi"]))]
txt = "; ".join(f"{r.contrast}/{r.variant}/{r.pif}/{r.band}: {r.mean_diff:+.4f} [{r.ci_lo:+.4f},{r.ci_hi:+.4f}] n={r.n_pairs}" for r in key.itertuples())
run.complete({"n_pairs_used": D.groupby("contrast").apply(lambda g: g[["date_a", "pr"]].drop_duplicates().shape[0]).to_dict(), "share_contrasts_excluding_zero": float(S.excludes_zero.mean()), "pif_cells_240m": counts},
             "NA", txt[:3000], outputs={"pairs": "results/phase5/sensor_pairs/pair_differences.csv", "summary": "results/phase5/sensor_pairs/contrast_summary.csv",
                                        "identifiability": "results/phase5/sensor_pairs/design_and_identifiability.json"})
print(S[S.band.isin(["red", "nir08", "ndvi"])].to_string())
