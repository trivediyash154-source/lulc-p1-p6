# pune-eo-phd — Multi-decadal Earth Observation infrastructure for Pune District

A reproducible research data system for the **entire Pune District, Maharashtra (15,650 km²)**,
1990–2026: real satellite archive → manifests → QA → harmonisation → fixed-grid temporal cube →
(next) features, change, coupled systems, ML, uncertainty, hindcast, scenarios, digital twin.

> **Status (first milestone — data foundation).** Built and executed on real data in this repo:
> boundary, grids, complete acquisition manifests, evidence-based sensor harmonisation, a resumable
> compositing engine, every-year Landsat products 1990–2026 (district benchmark grid), full-resolution
> 30 m products for a named window (all 37 years), Sentinel-1 monthly products 2015–2026, Sentinel-2
> monthly products 2018–2026, 10 m field-scale Sentinel-2 (2024) for an irrigated window, a CHIRPS rainfall driver 1990–2026, a harmonisation stability test, flood-event
> checks, a stratified reference-sample design, automated QA, figures and tests. **No model, map classification, accuracy value or
> scenario exists yet — none is claimed.**

## 1. Why not four snapshots
See `docs/methodology.md §0`. In short: 10-year gaps hide transition timing; unharmonised sensors
fake trends (the L7→L8 switch alone moves NDVI by −0.047 here); and without per-pixel observation
counts, uncertainty and provenance, a composite is a picture, not a measurement.

## 2. Temporal architecture
| Scale | Years | Products |
|---|---|---|
| Long-term | **every year 1990–2026** | annual, dry (Jan–May), wet (Jun–Sep), post-monsoon (Oct–Dec): composite, uncertainty, observation count, valid mask, per-pixel QA (incl. per-sensor counts, temporal support), metadata |
| Dense modern | S2 2018+, S1 2015+ | monthly + seasonal + annual |
| Events | per cited event | Sentinel-1 pre / during / post (only if the satellite actually imaged the event) |

2026 is a **partial year**: products whose period extends past the archive cut-off carry `complete=false`.
Real satellite history: `results/figures/satellite_availability_timeline.png`, `docs/archive_findings.md`.

## 3. Product layout
```
data/composites/<grid_id>/<YEAR>/
  landsat/annual/  landsat/seasonal/{dry,wet,post_monsoon}/
  sentinel2/{annual,seasonal/*,monthly/YYYY-MM}/      sentinel1/{…, events/<id>/}
  metadata/<family>_year_summary.json
each period dir: optical_composite.tif  uncertainty.tif  observation_count.tif  valid_mask.tif  qa.tif  metadata.json
```
Grids: **G30** = native Landsat lattice (no resampling) · **G10/G20** = native Sentinel lattice ·
**G240** = 8×G30 district benchmark (diagnostic only). Details: `docs/architecture.md`, `docs/data_dictionary.md`.

## 4. Run it in VS Code (macOS / Linux)
1. **Install** (conda-forge is the most reliable way to get GDAL on a Mac):
   ```bash
   conda env create -f environment.yml && conda activate pune-eo
   # or: python3.12 -m venv .venv && source .venv/bin/activate && pip install -e ".[dev]"
   ```
2. **Open the folder** in VS Code → `Python: Select Interpreter` → the `pune-eo` env (or `.venv`).
3. **Credentials:** `cp .env.example .env`. Nothing is required for the default backend
   (Planetary Computer is anonymous). Check: `python -m pune_eo auth-check`.
4. **Run the pipeline** — Terminal ▸ Run Task (`.vscode/tasks.json`) in order, or the debugger configs in
   `.vscode/launch.json`, or the CLI:
   ```bash
   python -m pune_eo boundary          # study area: download, validate, version, save geojson/gpkg/shp
   python -m pune_eo grid              # grids + native-lattice evidence
   python -m pune_eo discover          # Landsat / Sentinel-2 / Sentinel-1 manifests (GeoParquet)
   python -m pune_eo coverage && python -m pune_eo timeline
   python -m pune_eo harmonize --grid G240       # overlap composites + held-out calibration
   python -m pune_eo composite --family landsat --grid G240 --years 1990-2026     # resumable
   python -m pune_eo composite --family landsat --grid G30 --window khadakwasla_mutha --years 1990-2026
   python -m pune_eo composite --family sentinel2 --grid G240 --years 2018-2026
   python -m pune_eo composite --family sentinel1 --grid G240 --years 2015-2026
   python -m pune_eo event pune_2024_07_25
   python -m pune_eo climate                     # CHIRPS monthly rainfall, area-weighted district mean
   python -m pune_eo sample-design               # stratified reference points (labels empty) -> KML for Google Earth Pro
   python -m pune_eo qa --grid-id pune_G240 && python -m pune_eo figures
   python -m pune_eo status            # done / failed / pending jobs
   python -m pytest -q
   ```
5. **Interrupt any time.** Re-running the same command skips finished years, reuses cached
   observations of an interrupted year, and refuses to run a job another process holds.
6. **Full 30 m district:** `python -m pune_eo gee-export --years 1990-2026 --grid G30` (plan) and
   `--submit` once `GEE_PROJECT` is set and `earthengine authenticate` has been run; or run
   `composite --grid G30` on a workstation/cloud VM.

Typical runtimes (2-core sandbox): G240 Landsat 45–150 s/year; G30 window 20–40 s/year; S2 G240 one year ≈ 4 min.

## 5. Benchmark executed in this build (real data)
**Archive and frame**

- Study area: **15,650.14 km²** (equal-area), version `5ef4c24587a9`, +0.046 % vs official; GADM 4.1 cross-check IoU 0.978.
- landsat manifest: 4,291 scenes discovered, **2,685 selected** (1972-09-04 → 2026-09-21; archive cut-off 2026-10-01).
- sentinel2 manifest: 7,953 scenes discovered, **3,526 selected** (2015-11-20 → 2026-09-30; archive cut-off 2026-10-01).
- sentinel1 manifest: 1,049 scenes discovered, **884 selected** (2015-02-24 → 2026-09-30; archive cut-off 2026-10-01).

**Products built** (each with composite, uncertainty, observation count, valid mask, per-pixel QA, metadata and checksums):

| group                                          | grid                       |   res_m |   products |   years |   first |   last |
|:-----------------------------------------------|:---------------------------|--------:|-----------:|--------:|--------:|-------:|
| landsat                                        | pune_G240                  |     240 |        148 |      37 |    1990 |   2026 |
| landsat                                        | pune_G30_khadakwasla_mutha |      30 |        148 |      37 |    1990 |   2026 |
| landsat calibration (per-sensor, unharmonised) | pune_G240                  |     240 |         18 |       9 |    2000 |   2023 |
| landsat calibration (per-sensor, unharmonised) | pune_G30_baramati_agri     |      30 |         18 |       9 |    2000 |   2023 |
| landsat calibration (per-sensor, unharmonised) | pune_G30_khadakwasla_mutha |      30 |         18 |       9 |    2000 |   2023 |
| sentinel1                                      | pune_G240                  |     240 |        192 |      12 |    2015 |   2026 |
| sentinel2                                      | pune_G10_baramati_agri     |      10 |         16 |       1 |    2024 |   2024 |
| sentinel2                                      | pune_G240                  |     240 |        144 |       9 |    2018 |   2026 |

Total: **702 products**.

**Landsat district cube (G240) — automated QA**

| period       |   FAIL |   IN_PROGRESS |   PASS |   WARNING |
|:-------------|-------:|--------------:|-------:|----------:|
| annual       |      0 |             0 |     30 |         7 |
| dry          |      0 |             0 |     30 |         7 |
| post_monsoon |      0 |             1 |     18 |        18 |
| wet          |     16 |             0 |      4 |        17 |

- Dry season: share of district with ≥3 clear observations — median 100 %, minimum 15.3 % (1997).
- Monsoon: same metric median 5.4 %; in 16 of 37 years under half the district had even one clear view.
- Permanent-water negative control (dry): at least 99.1% of JRC permanent-water cells read as water in every year.
- Residual-cloud check: flags the 1992 monsoon composite (88.5 % of pixels haze-bright); no dry-season product affected.

**Sentinel-1 monthly QA (2015–2026):** 90 PASS, 26 WARNING, 25 FAIL (real acquisition gaps), 3 in progress.
**Sentinel-2 monthly QA (2018–2026):** 60 PASS, 23 WARNING, 22 FAIL (monsoon cloud), 3 in progress.

**Sensor harmonisation (held-out years, district 240 m)**

| pair | NDVI bias, none | NDVI bias, local fit | band RMSD change | decision |
|---|---|---|---|---|
| L5→L7 | 0.0002 | 0.0033 | −0.8 % | identity |
| L7→L8 | 0.0467 | 0.0011 | −36.0 % | apply |
| L9→L8 | 0.0151 | 0.0001 | −10.7 % | apply |

Stability at 30 m (peri-urban and irrigated windows): the L7→L8 NDVI offset is 0.035–0.051 in every context and its correction is always adopted; the L9→L8 correction is **not** reproduced at 30 m and is marked provisional.

**Rainfall driver (CHIRPS v2.0, area-weighted district mean):** 452 months; annual mean 985 mm (min 633 mm in 2002, max 1416 mm in 2010).

**First exploratory coupling signal:** dry-season open water vs preceding-monsoon rainfall, Spearman ρ = 0.70 (p < 0.001, n = 35 supported years). This is an association at 240 m. It is not a causal claim: reservoir operations are not yet in the data.

**Reference sample design:** 1,345 stratified points (8 strata, ≥60 per stratum) with empty label columns for 5 epochs. KML file for Google Earth Pro: `data/labels/reference_sample_design_v1_seed20261001.kml`.

Figures: `results/figures/INDEX.md`. QA reports: `results/qa/<family>/<grid>/QA_REPORT.md`. Product inventory: `results/cube_inventory/cube_inventory.csv`.

**Pending jobs at packaging time** (resumable; finished years are skipped):

- none

## 6. Repository map
```
configs/   study_area, grid, temporal, landsat, sentinel1, sentinel2, dem, climate, reference, events, qa, aois
docs/      research_questions, hypotheses, methodology, architecture, data_dictionary, validation,
           experiment_protocol, reproducibility, archive_findings, roadmap
src/pune_eo/
  acquisition/     boundary, stac, manifest, coverage, reference, climate, auth, gee_backend
  preprocessing/   landsat_qa, s2_scl, sar
  harmonization/   landsat (transforms), calibrate (held-out fitting + decision rule)
  compositing/     reader, observations, engine, stats, periods, windows
  qa/              checks, report          flood/  s1_event
  feature_engineering/ indices (each with a stated purpose)   validation/ spatial_cv, sample_design
  visualization/   style, cartography, timeline, figures
  classification/ change_detection/ agriculture/ water/ urban/ stress/ modelling/ uncertainty/  ← milestone scaffolds
scripts/   discover_all, run_calibration, run_landsat_cube, run_sentinel, harmonization_stability,
           build_inventory, make_data_dictionary, fill_readme
notebooks/ 01_explore_cube.ipynb (opens real products, traces a pixel to its scenes)
tests/     unit tests (SYNTHETIC TEST DATA — NOT RESEARCH DATA) + data-contract tests on real manifests
```

## 7. Not done yet (explicitly)
- Full-resolution (30 m) district cube for all years — pipeline ready; needs workstation/cloud/GEE.
- Sentinel dense products at 10/20 m district-wide (built at 240 m benchmark); S1 GRD→RTC for missing 2025 frames.
- Reference samples, LULC classification, change trajectories, agriculture/water/urban/stress
  modules, ML, hindcast, scenarios, digital twin.
- External data: flood-line vectors (2011/2017/MERI 2025), command areas, dam releases, IMD rainfall, groundwater (see `docs/roadmap.md`).
- Labels: the reference sample is designed (1,345 points) but **not interpreted** — no accuracy can be reported until it is.

## Phase 2 — from data to science (2026-10-02)

Start here: **`docs/phase2_results.md`** (all results, generated from the experiment registry), `docs/phase1_audit.md`,
`docs/label_protocol.md`, `docs/feature_registry.md`. Every result is an immutable record in `experiments/registry/`.

| step | command | output |
|---|---|---|
| audit | `python3 scripts/audit_phase1.py && python3 scripts/write_phase1_audit.py` | `docs/phase1_audit.md` |
| labels & splits | `python3 scripts/build_labels.py --steps fractions,ghsl,wsf,jrc,silver,splits` | `data/labels/<window>/` |
| feature cube | `python3 scripts/build_cubes.py` | `data/features/cube/<window>.zarr` |
| baselines / leakage / transfer | `scripts/run_baselines.py`, `scripts/run_lowo.py` | `results/classification/` |
| temporal LULC | `scripts/run_temporal_lulc.py`, `run_temporal_remedies.py`, `select_remedy.py`, `run_temporal_aoa.py` | `data/products/lulc*/`, `results/temporal/` |
| thematic | `run_changepoints.py`, `run_trajectories.py`, `run_urban.py`, `run_agri_models.py`, `run_phenology.py`, `run_water.py`, `run_flood.py`, `run_stress_veg.py` | `results/<theme>/` |
| uncertainty, hindcast | `run_uncertainty.py`, `run_hindcast.py` | `results/uncertainty/`, `results/temporal/hindcast.json` |
| figures & docs | `python3 -c "from pune_eo.visualization import phase2; phase2.all_available()"`, `scripts/write_phase2_results.py` | `results/figures/phase2/`, `docs/` |

Benchmark windows (30 m): Khadakwasla–Mutha corridor (urban/peri-urban/river/reservoir), Baramati (irrigated & rainfed agriculture),
Mulshi (Ghats forest/reservoir). District-wide 30 m products are PENDING (compute).

## Phase 3 — historical reconstruction, temporal AI, multimodal fusion, transferability (2026-10-02)

Start here: **`docs/phase3_results.md`**, then `docs/phase3_start_audit.md`, `docs/phase3_methodology.md`, `docs/phase3_experiment_matrix.md`,
`docs/phase3_limitations.md`. Every experiment is pre-registered in `experiments/registry3/` before it runs (immutable; corrections are `@v2`).
Gate criteria: `configs/phase3.yaml`. Run order (each script is also a VS Code task "P3 …"):

| step | command | output |
|---|---|---|
| audit + registration | `scripts/audit_phase2.py`, `scripts/phase3_register.py`, `scripts/write_phase3_start_audit.py` | `docs/phase3_start_audit.md`, `experiments/registry3/` |
| gold kit (blind) | `scripts/gold_blind_kit.py`, `scripts/gold_s2_chips.py` | `data/labels/gold/blind/` (key: `_key/`, evaluator only) |
| gold evaluation | `scripts/eval_gold.py` (refuses without `results/gold/provisional_ai_FROZEN.json`) | `results/phase3/gold/` |
| S1 2017-2025 + cubes + HET | `scripts/run_phase3_s1_chain.sh`, `scripts/build_cubes.py`, `python3 -c "from pune_eo.historical_reconstruction import het; het.build()"` | `data/features/het_v1/` |
| baseline (A) | `scripts/run_phase3_baseline.py` | `results/phase3/baseline/` |
| temporal (B), climate (D) | `scripts/run_phase3_temporal.py`, `scripts/run_phase3_temporal_recompare.py`, `scripts/run_phase3_climate.py` | `results/phase3/temporal/`, `climate/` |
| fusion (C), transfer (E, J) | `scripts/run_phase3_fusion.py`, `scripts/run_phase3_transfer.py` | `results/phase3/fusion/`, `transfer/` |
| calibration (H) | `scripts/run_phase3_calibration.py` | `results/phase3/calibration/` |
| SSL (G), labels (L), deep (F) | `scripts/run_phase3_ssl.py`, `scripts/run_phase3_labels.py`, `scripts/run_phase3_deep_temporal.py` | `results/phase3/ssl/`, `labels/`, `deep_temporal/` |
| change (K), harmonisation (I), agriculture (M), flood (N) | `scripts/run_phase3_change.py`, `scripts/run_phase3_harmonization.py`, `scripts/run_phase3_agriculture.py m1m3|m2`, `scripts/flood_inventory.py` | `results/phase3/<group>/` |
| selection, product, errors, gates | `scripts/run_phase3_product.py`, `scripts/run_phase3_errors.py`, `scripts/phase3_gates.py` | `results/phase3/product/`, `gates.json` |
| figures, docs, package | `scripts/make_phase3_figures.py`, `scripts/write_phase3_docs.py`, `scripts/write_phase3_matrix.py`, `scripts/package_phase3.py` | `results/figures/phase3/`, `docs/` |
| tests | `python3 -m pytest -q tests/` | |

Hardware used: 2 CPU cores, 7 GB RAM; the full Phase-3 chain runs in a few hours. Network is needed only for S1/S2 reads and same-day pairs.

## Phase 4 — data foundation, labels, independent validation (2026-10-02)

Start here: **`docs/phase4_final_report.md`** and **`docs/phase4_readiness_gate.md`** (decision: NOT_READY), then `docs/phase4_audit.md` (weakness matrix, dependency graph).
Inventory: `data/inventory/` (`scripts/phase4_inventory.py`, `phase4_label_audit.py`, `phase4_product_availability.py`). Evaluation protocol (frozen, v2): `configs/phase4_evaluation_protocol.yaml`, code `src/pune_eo/evaluation4/`,
tests `tests/test_evaluation4.py`; registry `experiments/registry4/` (confirmatory runs refuse to execute if code or protocol change).

| step | command |
|---|---|
| district products | `python3 scripts/phase4_products_acquire.py` (GLC_FCS30D, GISA, WSF, GHSL, JRC, ESA CCI, Esri, WorldCover -> `data/products_ext/`) |
| validation design + blind kit | `python3 scripts/phase4_validation_design.py` -> `data/labels/gold/phase4/` (give interpreters ONLY `blind/`) |
| product benchmark | `python3 scripts/phase4_product_benchmark.py`, `python3 scripts/phase4_disagreement_descriptors.py` |
| sensor-era PIF test | `python3 scripts/phase4_sensor_era_pif.py` |
| district cube (needs Earth Engine) | `python3 scripts/gee/export_district_cube.py --project <GEE_PROJECT>` (`--dry-run` to preview) — *Phase-5 note: the Earth Engine requirement was overstated; see Phase 5 below* |
| figures + docs | `python3 scripts/make_phase4_figures.py && python3 scripts/write_phase4_audit_docs.py && python3 scripts/write_phase4_docs.py` |

## Phase 5 — independent-evidence readiness (2026-10-02)

Start here: **`docs/phase5_entry_audit.md`** (what actually exists), **`docs/phase5_results.md`**, **`docs/phase5_readiness_gate.md`** (decision: NOT_READY),
`docs/phase5_execution_plan.md` (decisions D1-D3, human and compute workstreams). Protocol v2 unchanged; no confirmatory record executed (pre-run checklists: DO NOT RUN).

| step | command | output |
|---|---|---|
| entry audit (machine checks) | `python3 scripts/phase5_entry_checks.py` | `results/phase5/entry/` |
| gold: freeze / ingest / audit (G2) | `python3 src/validation/ingest_gold.py freeze <pass> --by <name>`; `... ingest`; `python3 src/validation/audit_gold.py` | `data/labels/gold/phase4/ingested/`, `results/phase5/gold/` |
| district 30 m cube (reference route) | `python3 scripts/phase5_district_cube_pilot.py --years <list> --periods dry[,post_monsoon,wet,annual] --threads 2 --min-strips 4` | `data/composites/pune_G30/` |
| cube validation | `python3 src/data/validate_district_cube.py [--require min]`; `--static-gee` | `results/phase5/cube_validation/` |
| exploratory (registered first) | `python3 scripts/phase5_register.py`; `phase5_observation_support.py` (P5-X1), `phase5_product_benchmark.py` (X2, X3), `phase5_water_products.py` (X4), `phase5_sensor_pairs.py` (E2) | `results/phase5/` |
| human training sample T1 | `python3 scripts/phase5_training_sample_T1.py` | `data/labels/training/phase5_T1/` (arms C-E: addendum PROPOSED) |
| confirmatory pre-run checklists | `python3 scripts/phase5_prerun_checklists.py` | `results/phase5/confirmatory/` |
| figures, docs, manifest | `python3 scripts/make_phase5_figures.py && python3 scripts/write_phase5_docs.py` | `figures/phase5/`, `docs/`, `results/phase5/reproducibility_manifest.json` |

## Phase 6 — decisions resolved, unblocking infrastructure (2026-10-02)

Start here: **`docs/phase6_readiness_gate.md`** (NOT_READY: human-label and compute boundaries), `docs/phase6_execution_status.md`, `docs/phase6_entry_audit.md`.
Decisions: `docs/phase6_D1_review.md` (P4-C1@v2 addendum APPROVED WITH CORRECTION), `docs/phase6_D2_sensor_correction_decision.md` (P4-C2@v2 transform fixed before gold),
`docs/phase6_D3_compute_decision.md` (Route A). Errata (clarifications, registered before any label): `experiments/registry4/addenda/P4-C{1,2}_at_v2_addendum_1_erratum_1.json`. Human labels: `docs/phase6_human_gold_workflow.md`, `docs/phase6_T1_training_protocol.md`, interpreter-only `docs/phase6_interpreter_protocol.md`.

| step | command |
|---|---|
| blind kits (gold A/B, T1 v2 A/B) | `python3 scripts/phase6_make_kits.py` |
| D2 PIF fit (after the C2 addendum) | `python3 scripts/phase6_c2_pif_fit.py` |
| T1 v2 design (done; pinned — the script refuses to overwrite) | `python3 scripts/phase6_training_sample_T1v2.py` |
| researcher countersignature of D1/D2 (required by the checklists) | copy `docs/templates/phase6_countersignature_TEMPLATE.json` → `experiments/registry4/addenda/phase6_countersignature.json` and fill it |
| full cube (Route A machine) | command block in `docs/phase6_D3_compute_decision.md` §4 (Landsat + C2 family, `phase6_district_s1.py`, `phase6_district_terrain.py`, `phase6_build_feature_cube.py`, validators) |
| status docs + manifest | `python3 scripts/write_phase6_docs.py` |
