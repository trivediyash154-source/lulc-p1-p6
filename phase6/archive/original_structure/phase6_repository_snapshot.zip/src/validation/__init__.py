"""Phase-5 Tier-A gold ingestion and audit (human interpretation of the Phase-4 district design v2).
Nothing in this package creates, infers or edits a label: it only checks, freezes and assembles what human interpreters supplied."""
