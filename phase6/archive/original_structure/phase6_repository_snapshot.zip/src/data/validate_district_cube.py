"""Validate a district 30 m Landsat cube BEFORE it is used for any experiment (Phase 5, Stage 3; docs/phase5_district_cube_spec.md).

Two layouts are understood:
  reference  data/composites/pune_G30/<year>/landsat/{annual|seasonal/<season>}/  (repository engine, Planetary Computer; scripts/phase5_district_cube_pilot.py)
             files: optical_composite.tif (6 bands int16 x1e4, nodata -32768), uncertainty.tif, observation_count.tif, valid_mask.tif, qa.tif, metadata.json
  gee        <folder>/landsat_<year>_<season>*.tif from scripts/gee/export_district_cube.py (bands blue..swir22, ndvi, mndwi, ndmi, nbr, ndbi, n_clear)
Checks (each product, then the set): file opens and every block decodes (corruption); CRS EPSG:32643; 30 m; transform/shape == pune_G30 (no shift, no resampling);
band set/order; dtype/nodata; reflectance in [0, 1]; observation counts consistent (n_clear <= n_observed, sum of per-platform clear counts == n_clear);
NO FILLED VALUES (composite valid exactly where n_clear >= 1 inside the district: a value where n_clear == 0 means missing data were converted into data);
district coverage (valid >= 1 obs, reliable >= 3 obs); never-observed share (missing scenes/tiles); platform plausibility per date (no L8 before 2013-04-11, no L7 after
2021-12-31 (repository rule), no L5 after 2011-11-18, no L9 before 2021-10-31); provenance (metadata.json present, every file's SHA-256 matches, sources listed with item ids);
duplicates (identical file hashes across products); temporal coverage vs a required year/period list.
Exit code 0 only if no product has an error. Never modifies the cube.
LIMITS: sources are not compared with the manifest (a dropped scene is visible only through never-observed cells or n_clear); the GEE layout has no per-file provenance
(metadata.json) and therefore gets geometry/band/fill/range checks only."""
from __future__ import annotations
import argparse, hashlib, json, re, sys
from dataclasses import dataclass, field
from pathlib import Path
import numpy as np

ROOT = Path(__file__).resolve().parents[2]
BANDS = ["blue", "green", "red", "nir08", "swir16", "swir22"]
GEE_BANDS = BANDS + ["ndvi", "mndwi", "ndmi", "nbr", "ndbi", "n_clear", "n_observed"] + [f"n_clear_landsat-{k}" for k in (4, 5, 7, 8, 9)]   # == export_district_cube.OUTPUT_BANDS
PLATFORM_DATES = {"landsat-4": ("1982-08-22", "1993-12-14"), "landsat-5": ("1984-03-01", "2011-11-18"), "landsat-7": ("1999-05-28", "2021-12-31"),
                  "landsat-8": ("2013-04-11", "9999-12-31"), "landsat-9": ("2021-10-31", "9999-12-31")}
PERIODS = ("annual", "dry", "post_monsoon", "wet")
PERIOD_MONTHS = {"annual": tuple(range(1, 13)), "dry": (1, 2, 3, 4, 5), "wet": (6, 7, 8, 9), "post_monsoon": (10, 11, 12)}
# minimum years for the registered confirmatory features (B3 + 5-year window t-2..t+2 around 1990/2000/2010/2020; silver years 2020-21)
REQUIRED_YEARS_MIN = sorted({y for e in (1990, 2000, 2010, 2020) for y in range(e - 2, e + 3) if y >= 1990} | {2021})
C2TM_YEARS = [1990, 1991, 1992, 1998, 1999, 2000, 2001, 2008, 2009, 2010, 2011]   # Phase 6: years with TM observations (P4-C2@v2 treatment family landsat_c2tm)

@dataclass
class GridSpec:
    crs: str; res: float; x0: float; y1: float; width: int; height: int
    @property
    def transform(self): return (self.res, 0.0, self.x0, 0.0, -self.res, self.y1)

def pune_g30() -> GridSpec:
    g = json.load(open(ROOT / "data/products_ext/district/district_grid.json"))["grid"]
    return GridSpec(g["crs"], float(g["res"]), float(g["x0"]), float(g["y1"]), int(g["width"]), int(g["height"]))

@dataclass
class Result:
    product: str
    errors: list = field(default_factory=list)
    warnings: list = field(default_factory=list)
    stats: dict = field(default_factory=dict)
    def err(self, code, msg): self.errors.append(f"[{code}] {msg}")
    def warn(self, code, msg): self.warnings.append(f"[{code}] {msg}")

def sha256(p: Path) -> str:
    h = hashlib.sha256()
    with open(p, "rb") as f:
        for b in iter(lambda: f.read(1 << 22), b""): h.update(b)
    return h.hexdigest()

def _open_check(path: Path, grid: GridSpec, res: Result, name: str, count=None, dtype=None):
    import rasterio
    try:
        s = rasterio.open(path)
    except Exception as e:
        res.err("CORRUPT", f"{name}: cannot open ({e!r})"); return None
    if str(s.crs) != grid.crs: res.err("CRS", f"{name}: CRS {s.crs} != {grid.crs}")
    if abs(s.res[0] - grid.res) > 1e-6 or abs(s.res[1] - grid.res) > 1e-6: res.err("RESOLUTION", f"{name}: resolution {s.res} != {grid.res}")
    t = tuple(s.transform)[:6]
    if any(abs(a - b) > 1e-6 for a, b in zip(t, grid.transform)): res.err("TRANSFORM", f"{name}: transform {t} != {grid.transform} (shifted or resampled lattice)")
    if (s.height, s.width) != (grid.height, grid.width): res.err("SHAPE", f"{name}: shape {(s.height, s.width)} != {(grid.height, grid.width)} (missing tiles / wrong extent)")
    if count is not None and s.count != count: res.err("BANDS", f"{name}: {s.count} bands, expected {count}")
    if dtype is not None and s.dtypes[0] != dtype: res.err("DTYPE", f"{name}: dtype {s.dtypes[0]} != {dtype}")
    return s

def _read_all(s, res: Result, name: str):
    try: return s.read()
    except Exception as e: res.err("CORRUPT", f"{name}: block decode failed ({e!r})"); return None

def validate_reference_product(d: Path, grid: GridSpec, district: np.ndarray | None) -> Result:
    res = Result(str(d)); m = d / "metadata.json"
    if not m.exists(): res.err("PROVENANCE", "metadata.json missing"); return res
    meta = json.loads(m.read_text()); files = meta.get("files", {})
    for k in ("optical_composite", "uncertainty", "observation_count", "valid_mask", "qa"):
        if k not in files: res.err("FILES", f"metadata lists no '{k}'")
    for k, f in files.items():
        p = ROOT / f["path"] if not Path(f["path"]).is_absolute() else Path(f["path"])
        if not p.exists(): p = d / Path(f["path"]).name
        if not p.exists(): res.err("FILES", f"{k}: file missing"); continue
        if sha256(p) != f.get("sha256"): res.err("PROVENANCE", f"{k}: SHA-256 differs from metadata (file changed after production)")
    if res.errors: return res
    oc = _open_check(d / "optical_composite.tif", grid, res, "optical_composite", 6, "int16")
    qa = _open_check(d / "qa.tif", grid, res, "qa", None, "uint16")
    cnt = _open_check(d / "observation_count.tif", grid, res, "observation_count", 1)
    vm = _open_check(d / "valid_mask.tif", grid, res, "valid_mask", 1, "uint8")
    if None in (oc, qa, cnt, vm) or res.errors: return res
    desc = list(oc.descriptions)
    if desc != BANDS: res.err("BANDS", f"band order {desc} != {BANDS}")
    if oc.nodata != -32768: res.err("NODATA", f"composite nodata {oc.nodata} != -32768")
    A = _read_all(oc, res, "optical_composite"); Q = _read_all(qa, res, "qa"); N = _read_all(cnt, res, "observation_count"); V = _read_all(vm, res, "valid_mask")
    if any(x is None for x in (A, Q, N, V)): return res
    N = N[0].astype(np.int64); qdesc = list(qa.descriptions); nobs = Q[qdesc.index("n_observed")].astype(np.int64); ncl = Q[qdesc.index("n_clear")].astype(np.int64)
    inside = district if district is not None else (V[0] > 0)
    if not np.array_equal(N, ncl): res.err("COUNTS", "observation_count differs from qa.n_clear")
    if (ncl > nobs).any(): res.err("COUNTS", f"n_clear > n_observed in {int((ncl > nobs).sum())} cells")
    plat = [i for i, n in enumerate(qdesc) if n.startswith("n_clear_landsat")]
    if plat:
        ssum = Q[plat].astype(np.int64).sum(0)
        if not np.array_equal(ssum[inside], ncl[inside]): res.err("COUNTS", f"per-platform clear counts do not sum to n_clear in {int((ssum != ncl)[inside].sum())} cells")
    valid_pix = (A != -32768).all(0); any_pix = (A != -32768).any(0)
    filled = inside & any_pix & (ncl == 0)
    if filled.any(): res.err("FILLED", f"{int(filled.sum())} district cells have reflectance but n_clear == 0 (missing observations converted into data)")
    lost = inside & (ncl >= 1) & ~valid_pix
    if lost.mean() > 0.001: res.warn("LOST", f"{lost.mean():.4f} of district cells have clear observations but an incomplete composite (saturation/invalid DN)")
    out = (~inside) & any_pix
    if out.any(): res.err("OUTSIDE", f"{int(out.sum())} cells outside the district carry values")
    vals = A[A != -32768]; lo, hi = (float(vals.min()) / 1e4, float(vals.max()) / 1e4) if vals.size else (0.0, 0.0)
    neg_share = float((vals < 0).mean()) if vals.size else 0.0; del vals
    if lo < -0.1 or hi > 1.0 + 1e-6: res.err("RANGE", f"reflectance range [{lo:.4f}, {hi:.4f}] outside [-0.1, 1] (decoded SR is clipped to [0, 1]; only the linear L7->OLI transform can push dark targets slightly below 0)")
    elif lo < 0: res.warn("NEGATIVE_AFTER_HARMONISATION", f"{neg_share:.2e} of composite values < 0 (min {lo:.4f}); expected only from the L7->OLI RMA intercepts on dark targets")
    vexp = np.where(ncl >= 3, 3, np.where(ncl >= 1, 2, 1)); vexp[~inside] = 0
    if not np.array_equal(V[0], vexp.astype(np.uint8)): res.err("VALID_MASK", "valid_mask inconsistent with n_clear classes")
    # platforms vs dates
    for s_ in meta.get("sources", []):
        p, dte = s_.get("platform"), str(s_.get("date"))
        if p in PLATFORM_DATES and not (PLATFORM_DATES[p][0] <= dte <= PLATFORM_DATES[p][1]): res.err("PLATFORM_DATE", f"{s_.get('item_id')}: {p} on {dte} outside operating/admitted period")
        if not s_.get("item_id"): res.err("PROVENANCE", "a source without item_id")
    tm = meta.get("temporal", {}); yr = tm.get("year"); months = PERIOD_MONTHS.get(tm.get("period"))
    for s_ in meta.get("sources", []):
        if yr and not str(s_.get("date", "")).startswith(str(yr)): res.err("PLATFORM_DATE", f"{s_.get('item_id')}: date {s_.get('date')} not in product year {yr}")
        elif months and len(str(s_.get("date", ""))) >= 7 and int(str(s_["date"])[5:7]) not in months: res.err("PERIOD_DATE", f"{s_.get('item_id')}: date {s_.get('date')} outside the {tm.get('period')} months {months}")
    if not meta.get("processing", {}).get("harmonization"): res.warn("PROVENANCE", "no harmonisation recorded")
    din = int(inside.sum())
    res.stats = {"year": yr, "period": tm.get("period"), "complete": tm.get("complete"), "n_sources": len(meta.get("sources", [])), "sensors": meta.get("sensors"),
                 "valid_fraction": float((ncl[inside] >= 1).mean()) if din else 0.0, "reliable_fraction_ge3": float((ncl[inside] >= 3).mean()) if din else 0.0,
                 "never_observed_fraction": float((nobs[inside] == 0).mean()) if din else 0.0, "n_clear_median": float(np.median(ncl[inside])) if din else 0.0,
                 "file_sha256": {k: f.get("sha256") for k, f in files.items()}}
    if res.stats["never_observed_fraction"] > 0.0: res.warn("NEVER_OBSERVED", f"{res.stats['never_observed_fraction']:.4f} of the district never observed in this period (footprint gap / missing scenes)")
    return res

def validate_gee_file(p: Path, grid: GridSpec, district: np.ndarray | None) -> Result:
    res = Result(str(p)); s = _open_check(p, grid, res, p.name, len(GEE_BANDS))
    if s is None or res.errors: return res
    desc = [d or "" for d in s.descriptions]
    if desc and any(desc) and desc != GEE_BANDS: res.err("BANDS", f"bands {desc} != {GEE_BANDS}")
    A = _read_all(s, res, p.name)
    if A is None: return res
    n = A[GEE_BANDS.index("n_clear")]; refl = A[:6]; inside = district if district is not None else np.isfinite(n)
    n0 = inside & ~(n >= 1)
    filled = n0 & np.isfinite(refl).any(0)
    if s.nodata is not None: filled &= (refl != s.nodata).any(0)
    if filled.any(): res.err("FILLED", f"{int(filled.sum())} cells with reflectance but n_clear < 1")
    v = refl[:, inside & (n >= 1)]
    if v.size and (np.nanmin(v) < -0.2 - 1e-6 or np.nanmax(v) > 1.6): res.err("RANGE", f"reflectance range [{np.nanmin(v):.3f}, {np.nanmax(v):.3f}] implausible")
    if v.size and np.nanmin(v) < 0: res.warn("NEGATIVE", "negative reflectance present (reference implementation clips to 0)")
    m = re.match(r"landsat_(\d{4})_(dry|wet|post_monsoon)", p.name)
    res.stats = {"year": int(m.group(1)) if m else None, "period": m.group(2) if m else None, "valid_fraction": float((n[inside] >= 1).mean()), "reliable_fraction_ge3": float((n[inside] >= 3).mean()), "sha256": sha256(p)}
    return res

def validate(root: Path, layout: str = "reference", grid: GridSpec | None = None, district: np.ndarray | None = None, required: list[tuple[int, str]] | None = None,
             family: str = "landsat", expect_harmonization: str | None = None, expect_transform_sha256: str | None = None) -> dict:
    """family: product family directory (default 'landsat', unchanged); Phase 6: 'landsat_c2tm' for the P4-C2@v2 treatment family, validated with
    expect_harmonization / expect_transform_sha256 so that a product made with any other transform is an error."""
    grid = grid or pune_g30()
    if district is None and layout in ("reference", "gee"):
        mp = ROOT / "data/products_ext/district/district_mask_30m.tif"
        if mp.exists():
            import rasterio
            with rasterio.open(mp) as s: district = s.read(1).astype(bool)
    results = []
    if layout == "reference":
        for m in sorted(root.glob(f"*/{family}/**/metadata.json")):
            r = validate_reference_product(m.parent, grid, district); pr = json.loads(m.read_text()).get("processing", {})
            if expect_harmonization and pr.get("harmonization") != expect_harmonization: r.err("HARMONIZATION", f"{pr.get('harmonization')} != {expect_harmonization}")
            if expect_transform_sha256 and pr.get("transform_sha256") != expect_transform_sha256: r.err("TRANSFORM_SHA", f"{str(pr.get('transform_sha256'))[:12]} != {expect_transform_sha256[:12]}")
            results.append(r)
    else:
        for p in sorted(root.glob("landsat_*.tif")): results.append(validate_gee_file(p, grid, district))
    present = {(r.stats.get("year"), r.stats.get("period")) for r in results if r.stats}
    shas = {}
    for r in results:
        for k, h in (r.stats.get("file_sha256") or {"file": r.stats.get("sha256")}).items():
            if h: shas.setdefault(h, []).append(f"{r.product}:{k}")
    dups = {h: v for h, v in shas.items() if len(v) > 1}
    req = required or []
    missing = [f"{y}/{p}" for y, p in req if (y, p) not in present]
    out = {"layout": layout, "root": str(root), "family": family, "expect_harmonization": expect_harmonization, "expect_transform_sha256": expect_transform_sha256, "grid": grid.__dict__, "n_products": len(results), "products": [{"product": r.product, "errors": r.errors, "warnings": r.warnings, "stats": r.stats} for r in results],
           "duplicates": dups, "required": [f"{y}/{p}" for y, p in req], "missing_required": missing,
           "temporal_coverage": sorted(f"{y}/{p}" for y, p in present if y)}
    out["n_errors"] = sum(len(r.errors) for r in results) + len(dups) + (1 if results == [] else 0)
    out["ok"] = out["n_errors"] == 0
    out["complete_for_required"] = not missing
    return out

def static_gee_check(script: Path = ROOT / "scripts/gee/export_district_cube.py") -> dict:
    """Static validation of the (never executed) GEE export against the repository configuration + a dry run. No Earth Engine call is made."""
    import importlib.util, subprocess, yaml
    spec = importlib.util.spec_from_file_location("gee_export", script); mod = importlib.util.module_from_spec(spec); spec.loader.exec_module(mod)
    L = yaml.safe_load(open(ROOT / "configs/landsat.yaml")); T = yaml.safe_load(open(ROOT / "configs/temporal.yaml"))["periods"]; g = pune_g30()
    checks = {
        "grid_crs": mod.CRS == g.crs, "grid_transform": tuple(mod.TR) == g.transform, "grid_shape": (mod.W, mod.H) == (g.width, g.height),
        "qa_bits_equal_config": mod.QA_BITS == sorted(int(b) for b in L["qa_mask_bits"].values()),
        "valid_dn_equal_config": list(mod.VALID_DN) == list(L["valid_dn"]), "scale_offset_equal_config": (mod.SCALE, mod.OFFSET) == (L["scale"], L["offset"]),
        "max_scene_cloud_equal_config": mod.MAX_CLOUD == L["selection"]["max_scene_cloud"], "tier1_only": all("/T1_L2" in v[0] for v in mod.LS.values()),
        "landsat7_end_2021_12_31": mod.PLATFORM_WINDOWS["landsat-7"][1] == "2021-12-31",
        "platforms_equal_config": sorted(v[2] for v in mod.LS.values()) == sorted(L["platforms"]),
        "periods_equal_temporal_yaml": all(tuple(range(mod.PERIODS[k][0], mod.PERIODS[k][1] + 1)) == tuple(T[k]["months"]) for k in mod.PERIODS),
        "harmonisation_landsat7_only": sorted(mod.HARM["per_platform"]) == ["landsat-7"], "output_bands_equal_validator": list(mod.OUTPUT_BANDS) == GEE_BANDS,
        "s1_refused": "GRD sigma0" in open(script).read()}
    dry = subprocess.run([sys.executable, str(script), "--dry-run", "--years", "1990-1991"], capture_output=True, text=True, cwd=ROOT)
    checks["dry_run_exit_0"] = dry.returncode == 0
    s1 = subprocess.run([sys.executable, str(script), "--dry-run", "--what", "landsat,s1"], capture_output=True, text=True, cwd=ROOT)
    checks["dry_run_s1_refused"] = s1.returncode != 0
    n_full = len(mod.plan(list(range(1990, 2027)), ["landsat", "s2", "dw", "gaia"]))
    return {"ok": all(checks.values()), "checks": checks, "dry_run_stdout_head": dry.stdout[:1500], "n_tasks_full_1990_2026": n_full,
            "remaining_differences_to_reference_engine": ["no SE-of-median uncertainty band", "no median-DOY band", "no 1 % district-overlap scene rule", "GEE vs numpy median tie handling",
                                                          "S2 Cloud Score+ mask vs repository SCL mask", "not executed: behaviour of the EE graph itself is untested"]}

def main(argv=None):
    ap = argparse.ArgumentParser(description="validate a district 30 m cube"); ap.add_argument("root", nargs="?", default=str(ROOT / "data/composites/pune_G30"))
    ap.add_argument("--layout", choices=["reference", "gee"], default="reference"); ap.add_argument("--require", default="", help="e.g. 1990:dry,2000:dry; 'min' = confirmatory minimum (all four periods); 'c2tm' = the TM years x 4 periods (treatment family)")
    ap.add_argument("--family", default="landsat"); ap.add_argument("--expect-harmonization", default=None); ap.add_argument("--expect-transform-sha256", default=None)
    ap.add_argument("--out", default=str(ROOT / "results/phase5/cube_validation/validation_report.json")); ap.add_argument("--static-gee", action="store_true"); a = ap.parse_args(argv)
    if a.static_gee:
        r = static_gee_check(); o = ROOT / "results/phase5/cube_validation/gee_static_check.json"; o.parent.mkdir(parents=True, exist_ok=True); o.write_text(json.dumps(r, indent=1))
        print(json.dumps(r["checks"], indent=1)); return 0 if r["ok"] else 1
    req = [(y, p) for y in REQUIRED_YEARS_MIN for p in PERIODS] if a.require == "min" else [(y, p) for y in C2TM_YEARS for p in PERIODS] if a.require == "c2tm" else \
        [(int(t.split(":")[0]), t.split(":")[1]) for t in a.require.split(",") if t]
    r = validate(Path(a.root), a.layout, required=req, family=a.family, expect_harmonization=a.expect_harmonization, expect_transform_sha256=a.expect_transform_sha256); Path(a.out).parent.mkdir(parents=True, exist_ok=True); Path(a.out).write_text(json.dumps(r, indent=1, default=str))
    print(json.dumps({k: r[k] for k in ("ok", "n_products", "n_errors", "missing_required", "temporal_coverage")}, indent=1))
    for p in r["products"]:
        print(p["product"], "OK" if not p["errors"] else "ERRORS", p["errors"][:3], {k: p["stats"].get(k) for k in ("valid_fraction", "reliable_fraction_ge3", "never_observed_fraction", "n_clear_median")})
    return 0 if r["ok"] else 1

if __name__ == "__main__": sys.exit(main())
