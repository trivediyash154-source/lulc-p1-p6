"""Phase-5 district data-cube validation (src/data/validate_district_cube.py)."""
