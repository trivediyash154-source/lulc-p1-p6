"""Validate the DISTRICT feature cube (data/features/cube/pune_G30.zarr) against the registered feature definition before any confirmatory use (Phase 6).
Checks: variables/dims/feature names == src/pune_eo/feature_engineering/cube.py; CRS EPSG:32643; 30 m; x/y coordinates on the pune_G30 lattice; required years
(registered minimum) and t-2..t+2 windows around 1990/2000/2010/2020 present (years < 1990 are outside the archive and allowed missing, as in the window cubes);
S1 year 2020 present; district coverage per year: dry-season features >= 0.90 of district cells finite (G1 coverage rule), post-monsoon/annual features reported
(observation-limited, never filled); S1F features for 2020 >= 0.90; terrain >= 0.99; no values outside the district; provenance sidecar present and every listed
source metadata.json still has the recorded SHA-256. Exit code 0 only if every check passes. Never modifies the cube."""
from __future__ import annotations
import argparse, hashlib, json, sys
from pathlib import Path
import numpy as np
ROOT = Path(__file__).resolve().parents[2]
sys.path.insert(0, str(ROOT / "src"))
REQ = sorted({y for e in (1990, 2000, 2010, 2020) for y in range(e - 2, e + 3) if y >= 1990} | {2021})
DRY = ["dry_blue", "dry_green", "dry_red", "dry_nir", "dry_swir1", "dry_swir2", "dry_ndvi"]
S1F = ["s1_vv_dry", "s1_vh_dry", "s1_vh_wet", "s1_ratio", "s1_vv_min", "s1_vh_sd"]

def validate(path: Path, grid: dict | None = None, mask: np.ndarray | None = None, required_years=REQ, syears=(2020,), check_sources=True, family: str = "landsat",
             family_years: dict | None = None) -> dict:
    """family: expected Landsat family of the cube (attrs + sidecar). family_years {year: family}: years that MUST come from that family
    (P4-C2@v2 treatment cube: every TM year from landsat_c2tm). The report records the resolved cube path and the sidecar SHA-256 so that a
    checklist can tie the report to the exact cube it validated."""
    import xarray as xr
    from pune_eo.feature_engineering import cube as C
    res = {"path": str(Path(path).resolve()), "family": family, "checks": {}}
    def chk(name, ok, **d): res["checks"][name] = {"ok": bool(ok), **d}
    try: ds = xr.open_zarr(path)
    except Exception as e:
        chk("opens", False, error=repr(e)); res["ok"] = False; return res
    chk("opens", True)
    want = {"landsat": ("year", "feature", "y", "x"), "quality": ("year", "qfeature", "y", "x"), "terrain": ("tfeature", "y", "x"), "sentinel": ("syear", "sfeature", "y", "x")}
    chk("variables_and_dims", all(v in ds and tuple(ds[v].dims) == d for v, d in want.items()), found={v: list(ds[v].dims) for v in ds.data_vars})
    chk("feature_names", list(ds.feature.values) == C.LANDSAT_FEATURES and list(ds.qfeature.values) == C.QUALITY and list(ds.tfeature.values) == list(C.TERRAIN) and list(ds.sfeature.values) == C.SENTINEL_FEATURES)
    g = json.loads(ds.attrs.get("grid", "{}")); grid = grid or json.load(open(ROOT / "data/products_ext/district/district_grid.json"))["grid"]
    chk("crs", ds.attrs.get("crs") == grid["crs"] == "EPSG:32643", crs=ds.attrs.get("crs"))
    x, y = ds.x.values, ds.y.values
    ok_lat = len(x) == grid["width"] and len(y) == grid["height"] and np.allclose(np.diff(x), grid["res"]) and np.allclose(np.diff(y), -grid["res"]) and \
        abs(x[0] - (grid["x0"] + grid["res"] / 2)) < 1e-6 and abs(y[0] - (grid["y1"] - grid["res"] / 2)) < 1e-6
    chk("grid_30m_lattice", ok_lat and g.get("res") == grid["res"], shape=[len(y), len(x)])
    yrs = [int(v) for v in ds.year.values]; miss = [v for v in required_years if v not in yrs]
    chk("required_years_present", not miss, missing=miss)
    win_ok = {e: [v for v in range(e - 2, e + 3) if v >= 1990 and v not in yrs] for e in (1990, 2000, 2010, 2020)}
    chk("temporal_windows_t-2..t+2", not any(win_ok.values()), missing=win_ok, note="1988-1989 are outside the archive window and stay NaN (as in the window cubes)")
    sy = [int(v) for v in ds.syear.values]; chk("sentinel_years_present", all(v in sy for v in syears), syears=sy)
    if mask is None:
        import rasterio
        with rasterio.open(ROOT / "data/products_ext/district/district_mask_30m.tif") as s: mask = s.read(1).astype(bool)
    cov = {}
    for yr in yrs:
        L = ds.landsat.sel(year=yr); c = {}
        for f in C.LANDSAT_FEATURES:
            a = L.sel(feature=f).values; c[f] = float(np.isfinite(a[mask]).mean());
            if np.isfinite(a[~mask]).any(): chk(f"no_values_outside_district_{yr}_{f}", False)
        cov[yr] = c
    res["coverage_landsat"] = cov
    low = {yr: {f: round(c[f], 4) for f in DRY if c[f] < 0.90} for yr, c in cov.items() if yr in required_years}
    chk("dry_features_coverage_ge_0.90", not any(low.values()), below=low)
    scov = {}
    for yr in sy:
        S = ds.sentinel.sel(syear=yr); scov[yr] = {f: float(np.isfinite(S.sel(sfeature=f).values[mask]).mean()) for f in C.SENTINEL_FEATURES}
    res["coverage_sentinel"] = scov
    chk("s1_features_2020_coverage_ge_0.90", all(scov.get(v, {}).get(f, 0) >= 0.90 for v in syears for f in S1F), coverage={v: scov.get(v) for v in syears})
    tc = {f: float(np.isfinite(ds.terrain.sel(tfeature=f).values[mask]).mean()) for f in C.TERRAIN}; res["coverage_terrain"] = tc
    chk("terrain_coverage_ge_0.99", all(v >= 0.99 for v in tc.values()), coverage=tc)
    chk("landsat_family", ds.attrs.get("landsat_family") == family, found=ds.attrs.get("landsat_family"))
    side = Path(str(path)).with_suffix(".json")
    if side.exists():
        res["sidecar_sha256"] = hashlib.sha256(side.read_bytes()).hexdigest()
        meta = json.loads(side.read_text()); src = meta.get("source_metadata_sha256", {})
        if family_years:
            fy = {int(k): v for k, v in (meta.get("family_per_year") or {}).items()}
            wrong = {y: fy.get(int(y)) for y, f in family_years.items() if fy.get(int(y)) != f}
            chk("family_per_year", not wrong, wrong=wrong)
        bad = [k for k, h in src.items() if check_sources and (not (ROOT / k).exists() or hashlib.sha256((ROOT / k).read_bytes()).hexdigest() != h)]
        chk("provenance_sidecar_and_source_hashes", bool(src) and not bad, n_sources=len(src), changed_or_missing=bad[:10])
    else: chk("provenance_sidecar_and_source_hashes", False, error="sidecar json missing")
    res["ok"] = all(v["ok"] for v in res["checks"].values()); return res

def main(argv=None):
    ap = argparse.ArgumentParser(); ap.add_argument("path", nargs="?", default=str(ROOT / "data/features/cube/pune_G30.zarr"))
    ap.add_argument("--family", default="landsat", help="landsat_c2tm for the P4-C2@v2 treatment cube (then every TM year must come from landsat_c2tm)")
    ap.add_argument("--out", default=None, help="default results/phase6/feature_cube_validation.json for pune_G30.zarr, else feature_cube_validation_<stem>.json"); a = ap.parse_args(argv)
    stem = Path(a.path).stem; a.out = a.out or str(ROOT / "results/phase6" / ("feature_cube_validation.json" if stem == "pune_G30" else f"feature_cube_validation_{stem}.json"))
    fy = None
    if a.family == "landsat_c2tm":
        sys.path.insert(0, str(ROOT / "src")); from data.validate_district_cube import C2TM_YEARS; fy = {y: "landsat_c2tm" for y in C2TM_YEARS}
    r = validate(Path(a.path), family=a.family, family_years=fy); Path(a.out).parent.mkdir(parents=True, exist_ok=True); Path(a.out).write_text(json.dumps(r, indent=1, default=str))
    print(json.dumps({k: v["ok"] for k, v in r["checks"].items()}, indent=1)); return 0 if r["ok"] else 1

if __name__ == "__main__": sys.exit(main())
