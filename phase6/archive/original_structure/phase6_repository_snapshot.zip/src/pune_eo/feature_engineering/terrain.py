"""Terrain feature layer from Copernicus GLO-30 (a SURFACE model: buildings and canopy are included).

Computed on a buffered window (default 3 km) so that flow routing is not truncated at the edge, then
cropped to the analysis window on the fixed grid. Hydrology: pit/depression filling, flat resolution,
D8 flow directions, flow accumulation, stream network (accumulation >= `stream_km2`), HAND (height
above nearest drainage along the flow path), Euclidean distance to drainage, TWI.
"""
from __future__ import annotations
import json, tempfile
from pathlib import Path
import numpy as np
import rasterio
from rasterio.enums import Resampling
from rasterio.vrt import WarpedVRT
from scipy import ndimage as ndi
from .. import config
from ..grid import Grid
from ..io import write_cog, write_json
from ..provenance import utcnow, code_block
from ..acquisition.stac import client
from ..acquisition.boundary import load_study_area

BANDS = ["elevation_m", "slope_deg", "aspect_sin", "aspect_cos", "curv_profile", "curv_plan", "tpi_150m", "tpi_1050m",
         "flow_acc_km2", "hand_m", "dist_drainage_m", "twi"]

def _dem_on(grid: Grid) -> np.ndarray:
    from pyproj import Transformer
    t = Transformer.from_crs(grid.crs, 4326, always_xy=True)
    x0, y0, x1, y1 = grid.bounds; lo0, la0 = t.transform(x0, y0); lo1, la1 = t.transform(x1, y1)
    items = list(client().search(collections=[config.load("dem")["primary"]["collection"]], bbox=[lo0, la0, lo1, la1]).items())
    out = np.full(grid.shape, np.nan, np.float32)
    for it in items:
        with rasterio.Env(**config.GDAL_ENV), rasterio.open(it.assets["data"].href) as src:
            with WarpedVRT(src, crs=grid.crs, transform=grid.transform, width=grid.width, height=grid.height,
                           resampling=Resampling.bilinear, src_nodata=src.nodata, nodata=np.nan, dtype="float32") as v:
                a = v.read(1)
        m = np.isfinite(a); out[m] = a[m]
    return out, [i.id for i in items]

def _slope_aspect_curv(z: np.ndarray, res: float):
    zp = np.pad(z, 1, mode="edge")
    a, b, c = zp[:-2, :-2], zp[:-2, 1:-1], zp[:-2, 2:]
    d, e, f = zp[1:-1, :-2], zp[1:-1, 1:-1], zp[1:-1, 2:]
    g, h, i = zp[2:, :-2], zp[2:, 1:-1], zp[2:, 2:]
    dzdx = ((c + 2 * f + i) - (a + 2 * d + g)) / (8 * res)          # Horn (1981)
    dzdy = ((g + 2 * h + i) - (a + 2 * b + c)) / (8 * res)          # +y = south (row direction)
    slope = np.degrees(np.arctan(np.hypot(dzdx, dzdy)))
    aspect = np.arctan2(dzdx, -dzdy)                                 # 0 = north, clockwise
    # Zevenbergen & Thorne (1987) second derivatives
    D = ((d + f) / 2 - e) / res ** 2; E = ((b + h) / 2 - e) / res ** 2
    F = (-a + c + g - i) / (4 * res ** 2); G = (-d + f) / (2 * res); H = (b - h) / (2 * res)
    with np.errstate(invalid="ignore", divide="ignore"):
        prof = -2 * (D * G ** 2 + E * H ** 2 + F * G * H) / (G ** 2 + H ** 2)
        plan = 2 * (D * H ** 2 + E * G ** 2 - F * G * H) / (G ** 2 + H ** 2)
    prof[~np.isfinite(prof)] = 0; plan[~np.isfinite(plan)] = 0
    return slope, np.sin(aspect), np.cos(aspect), prof, plan

def _tpi(z: np.ndarray, radius_px: int):
    return z - ndi.uniform_filter(z, size=2 * radius_px + 1, mode="nearest")

def _hydrology(z: np.ndarray, grid: Grid, stream_km2: float):
    if not hasattr(np, "in1d"):                  # compat: pysheds 0.5 calls np.in1d (removed in NumPy 2.x); isin is the documented replacement
        np.in1d = lambda a, b, **kw: np.isin(np.ravel(a), b, **kw)
    from pysheds.grid import Grid as PG
    with tempfile.TemporaryDirectory() as td:
        p = Path(td) / "dem.tif"
        with rasterio.open(p, "w", driver="GTiff", width=grid.width, height=grid.height, count=1, dtype="float32",
                           crs=grid.crs, transform=grid.transform, nodata=-9999) as d:
            d.write(np.nan_to_num(z, nan=-9999).astype("float32"), 1)
        pg = PG.from_raster(str(p)); dem = pg.read_raster(str(p))
        dem = pg.fill_pits(dem); dem = pg.fill_depressions(dem); dem = pg.resolve_flats(dem)
        fdir = pg.flowdir(dem)
        acc = pg.accumulation(fdir)
        cell_km2 = grid.res ** 2 / 1e6
        streams_r = acc > (stream_km2 / cell_km2)          # pysheds Raster (keeps grid view metadata)
        streams = np.asarray(streams_r).astype(bool)
        hand = pg.compute_hand(fdir, dem, streams_r)
        acc = np.asarray(acc, dtype=np.float64); hand = np.asarray(hand, dtype=np.float32)
    dist = ndi.distance_transform_edt(~streams) * grid.res
    return acc * cell_km2, streams, hand, dist.astype(np.float32)

def build_terrain(window_name: str, grid_name: str = "G30", buffer_m: float = 3000, stream_km2: float = 1.0) -> dict:
    """window_name = a named window (configs/aois.yaml) or 'district' (Phase 6: the whole district grid, output data/features/terrain/<grid.id>/)."""
    from ..compositing.windows import resolve
    from rasterio.windows import Window as _W
    g, win, wname = resolve(grid_name, window_name)
    if win is None:                                    # district: full grid, output id == grid id (e.g. pune_G30)
        win = _W(0, 0, g.width, g.height); sub = g.subgrid(win, "")
    else:
        sub = g.subgrid(win, f"_{wname}")
    pad = int(np.ceil(buffer_m / g.res))
    from rasterio.windows import Window
    if wname == "district":     # Phase 6: buffer extends beyond the grid on all sides (DEM read on the buffered subgrid); windows keep the original clipped buffer
        bwin = Window(int(win.col_off) - pad, int(win.row_off) - pad, int(win.width) + 2 * pad, int(win.height) + 2 * pad)
    else:
        bwin = Window(max(0, int(win.col_off) - pad), max(0, int(win.row_off) - pad), int(win.width) + 2 * pad, int(win.height) + 2 * pad)
    big = g.subgrid(bwin, f"_{wname}_buffered")
    z, items = _dem_on(big)
    if np.isnan(z).any():
        z = np.where(np.isnan(z), ndi.generic_filter(np.nan_to_num(z, nan=np.nanmean(z)), np.nanmean, size=3), z)
    slope, asin, acos, prof, plan = _slope_aspect_curv(z, g.res)
    t150, t1050 = _tpi(z, 5), _tpi(z, 35)
    acc, streams, hand, dist = _hydrology(z, big, stream_km2)
    tanb = np.tan(np.radians(np.maximum(slope, 0.1)))
    twi = np.log((acc * 1e6 / g.res) / tanb)                         # specific catchment area / tan(slope)
    r0, c0 = int(win.row_off) - int(bwin.row_off), int(win.col_off) - int(bwin.col_off)
    crop = lambda a: a[r0:r0 + int(win.height), c0:c0 + int(win.width)]
    stack = np.stack([crop(x).astype(np.float32) for x in (z, slope, asin, acos, prof, plan, t150, t1050, acc, hand, dist, twi)])
    out = config.path("data", "features", "terrain", sub.id); out.mkdir(parents=True, exist_ok=True)
    write_cog(out / "terrain.tif", stack, sub, nodata=np.nan, dtype="float32", descriptions=BANDS)
    write_cog(out / "streams.tif", crop(streams).astype(np.uint8), sub, nodata=None, dtype="uint8",
              descriptions=[f"stream_acc_ge_{stream_km2}km2"], overview_resampling="nearest")
    meta = {"product": "terrain", "grid": sub.to_dict(), "source": "Copernicus DEM GLO-30 (DSM, TanDEM-X 2011-2015)", "items": items,
            "buffer_m": buffer_m, "stream_threshold_km2": stream_km2, "bands": BANDS,
            "methods": {"slope/aspect": "Horn 1981", "curvature": "Zevenbergen & Thorne 1987", "tpi": "z - mean(z) in 11x11 / 71x71 windows",
                        "hydrology": "pysheds: fill pits/depressions, resolve flats, D8, accumulation, HAND", "twi": "ln(a / tan(beta)), beta>=0.1 deg"},
            "limitations": ["DSM: buildings and canopy raise elevation; HAND in dense urban and forest is biased",
                            "stream network is topographic (accumulation threshold), not mapped rivers"],
            "stats": {b: {"p5": float(np.nanpercentile(stack[i], 5)), "median": float(np.nanmedian(stack[i])), "p95": float(np.nanpercentile(stack[i], 95))} for i, b in enumerate(BANDS)},
            "created_utc": utcnow(), "code": code_block(config.config_hash("dem", "grid"))}
    write_json(out / "metadata.json", meta)
    return meta
