"""Analysis-ready FEATURE CUBE per window (Zarr, chunked, resumable per year).

  <grid.id>.zarr
    landsat   (year, feature, y, x) float32   1990-2026, features from configs/features.yaml (landsat_*, derived, texture)
    quality   (year, qfeature, y, x) float32  n_dry, n_post, se_dry_nir  (uncertainty / area of applicability only)
    terrain   (tfeature, y, x)       float32  static
    sentinel  (syear, sfeature, y, x) float32 S1/S2 annual features where Sentinel composites exist (2017+)
Every value is computed from an existing, QA'd composite; a missing composite gives NaN (never interpolated here)."""
from __future__ import annotations
import json, time
import numpy as np, rasterio, xarray as xr
from scipy.ndimage import uniform_filter
from .. import config
from ..grid import Grid
from ..io import write_json
from ..provenance import utcnow

LANDSAT_FEATURES = ["dry_blue", "dry_green", "dry_red", "dry_nir", "dry_swir1", "dry_swir2", "dry_ndvi", "dry_evi", "dry_savi",
                    "dry_mndwi", "dry_ndwi", "dry_ndmi", "dry_ndbi", "dry_bsi", "dry_nbr", "post_ndvi", "post_mndwi", "post_ndmi",
                    "d_ndvi", "d_mndwi", "ann_ndvi", "sd_ndvi_5", "sd_nir_5"]
QUALITY = ["n_dry", "n_post", "se_dry_nir"]
TERRAIN = {"elevation": "elevation_m", "slope": "slope_deg", "aspect_sin": "aspect_sin", "aspect_cos": "aspect_cos",
           "curv_prof": "curv_profile", "curv_plan": "curv_plan", "tpi_150": "tpi_150m", "tpi_1050": "tpi_1050m",
           "log_facc": "flow_acc_km2", "hand": "hand_m", "dist_drain": "dist_drainage_m", "twi": "twi"}
SENTINEL_FEATURES = ["s1_vv_dry", "s1_vh_dry", "s1_vh_wet", "s1_ratio", "s1_vv_min", "s1_vh_sd", "s2_ndre_post"]
BANDS = ["blue", "green", "red", "nir08", "swir16", "swir22"]

def _nd(a, b):
    with np.errstate(divide="ignore", invalid="ignore"): return (a - b) / (a + b)

def _local_sd(a, k=5):
    f = np.isfinite(a); x = np.where(f, a, 0.0); n = uniform_filter(f.astype(float), k)
    m = uniform_filter(x, k) / np.maximum(n, 1e-9); m2 = uniform_filter(x * x, k) / np.maximum(n, 1e-9)
    return np.where(f & (n * k * k >= 13), np.sqrt(np.maximum(m2 - m * m, 0)), np.nan)   # >= 13 of 25 valid

def _read_comp(grid: Grid, year: int, family: str, rel: str, window=None):
    """window (rasterio Window) reads a sub-window (Phase 6 district strips); None reads the whole grid (window cubes, unchanged)."""
    d = config.path("data", "composites", grid.id, str(year), family, rel)
    p = d / "optical_composite.tif"
    if not p.exists(): return None
    with rasterio.open(p) as s:
        a = s.read(window=window).astype(np.float32); desc = list(s.descriptions)
    a[a == -32768] = np.nan; a /= 10000.0
    out = {b: a[desc.index(b)] for b in desc}
    with rasterio.open(d / "observation_count.tif") as s: out["_n"] = s.read(1, window=window).astype(np.float32)
    if (d / "uncertainty.tif").exists():
        with rasterio.open(d / "uncertainty.tif") as s:
            u = s.read(window=window).astype(np.float32); u[u == -32768] = np.nan; out["_se_nir"] = u[desc.index("nir08")] / 10000.0
    return out

def landsat_year(grid: Grid, year: int, window=None, family: str = "landsat") -> tuple[np.ndarray, np.ndarray, dict]:
    H, W = grid.shape if window is None else (int(window.height), int(window.width)); F = np.full((len(LANDSAT_FEATURES), H, W), np.nan, np.float32); Q = np.full((len(QUALITY), H, W), np.nan, np.float32)
    dry = _read_comp(grid, year, family, "seasonal/dry", window); post = _read_comp(grid, year, family, "seasonal/post_monsoon", window)
    ann = _read_comp(grid, year, family, "annual", window); f = {}
    if dry:
        b, g, r, n, s1, s2 = (dry[k] for k in BANDS)
        f.update(dry_blue=b, dry_green=g, dry_red=r, dry_nir=n, dry_swir1=s1, dry_swir2=s2, dry_ndvi=_nd(n, r),
                 dry_evi=2.5 * (n - r) / (n + 6 * r - 7.5 * b + 1), dry_savi=1.5 * (n - r) / (n + r + 0.5), dry_mndwi=_nd(g, s1),
                 dry_ndwi=_nd(g, n), dry_ndmi=_nd(n, s1), dry_ndbi=_nd(s1, n), dry_bsi=_nd(s1 + r, n + b), dry_nbr=_nd(n, s2))
        f["sd_ndvi_5"] = _local_sd(f["dry_ndvi"]); f["sd_nir_5"] = _local_sd(n)
        Q[0] = dry["_n"]; Q[2] = dry.get("_se_nir", np.nan)
    if post:
        f.update(post_ndvi=_nd(post["nir08"], post["red"]), post_mndwi=_nd(post["green"], post["swir16"]), post_ndmi=_nd(post["nir08"], post["swir16"]))
        Q[1] = post["_n"]
    if dry and post: f["d_ndvi"] = f["post_ndvi"] - f["dry_ndvi"]; f["d_mndwi"] = f["post_mndwi"] - f["dry_mndwi"]
    if ann: f["ann_ndvi"] = _nd(ann["nir08"], ann["red"])
    for i, k in enumerate(LANDSAT_FEATURES):
        if k in f: F[i] = f[k]
    F[~np.isfinite(F)] = np.nan            # zero denominators (e.g. EVI, ratios of clipped-to-0 reflectance) -> missing, not inf
    return F, Q, {"dry": dry is not None, "post": post is not None, "annual": ann is not None}

def terrain(grid: Grid, window=None) -> np.ndarray:
    with rasterio.open(config.path("data", "features", "terrain", grid.id, "terrain.tif")) as s:
        a = s.read(window=window).astype(np.float32); desc = list(s.descriptions)
    out = np.stack([a[desc.index(v)] for v in TERRAIN.values()])
    out[list(TERRAIN).index("log_facc")] = np.log10(1 + out[list(TERRAIN).index("log_facc")])
    return out

def _sar_db(grid, year, rel, window=None):
    """Sentinel-1 composite already in dB (backscatter_median_db.tif: bands vv_median_db, vh_median_db; nodata -9999)."""
    p = config.path("data", "composites", grid.id, str(year), "sentinel1", rel, "backscatter_median_db.tif")
    if not p.exists(): return None
    with rasterio.open(p) as s:
        a = s.read(window=window).astype(np.float32); desc = [d.lower() for d in s.descriptions]
    a[(a == -9999) | ~np.isfinite(a)] = np.nan
    return {("vv" if "vv" in d else "vh"): a[i] for i, d in enumerate(desc)}

def sentinel_year(grid: Grid, year: int, window=None) -> tuple[np.ndarray, dict]:
    H, W = grid.shape if window is None else (int(window.height), int(window.width)); F = np.full((len(SENTINEL_FEATURES), H, W), np.nan, np.float32); f = {}
    dry = _sar_db(grid, year, "seasonal/dry", window); wet = _sar_db(grid, year, "seasonal/wet", window)
    months = [m for m in (_sar_db(grid, year, f"monthly/{year}-{mm:02d}", window) for mm in range(1, 13)) if m]
    if dry:
        f["s1_vv_dry"], f["s1_vh_dry"] = dry.get("vv"), dry.get("vh")
        if dry.get("vv") is not None and dry.get("vh") is not None: f["s1_ratio"] = dry["vh"] - dry["vv"]
    if wet: f["s1_vh_wet"] = wet.get("vh")
    if len(months) >= 6:
        vv = np.stack([m["vv"] for m in months if "vv" in m]); vh = np.stack([m["vh"] for m in months if "vh" in m])
        with np.errstate(all="ignore"):
            f["s1_vv_min"] = np.nanmin(vv, 0); f["s1_vh_sd"] = np.nanstd(vh, 0)
    s2 = _read_comp(grid, year, "sentinel2", "seasonal/post_monsoon", window)
    if s2 and "re1" in s2 and "nir08" in s2: f["s2_ndre_post"] = _nd(s2["nir08"], s2["re1"])
    for i, k in enumerate(SENTINEL_FEATURES):
        if f.get(k) is not None: F[i] = f[k]
    F[~np.isfinite(F)] = np.nan
    return F, {"s1_dry": dry is not None, "s1_wet": wet is not None, "s1_months": len(months), "s2_post": s2 is not None}

def build_cube(grid: Grid, years=range(1990, 2027), s_years=range(2017, 2026)) -> dict:
    out = config.path("data", "features", "cube", f"{grid.id}.zarr"); out.parent.mkdir(parents=True, exist_ok=True)
    years = list(years); s_years = list(s_years); H, W = grid.shape; t0 = time.time()
    x = grid.x0 + (np.arange(W) + 0.5) * grid.res; y = grid.y1 - (np.arange(H) + 0.5) * grid.res
    L = np.full((len(years), len(LANDSAT_FEATURES), H, W), np.nan, np.float32); Q = np.full((len(years), len(QUALITY), H, W), np.nan, np.float32)
    S = np.full((len(s_years), len(SENTINEL_FEATURES), H, W), np.nan, np.float32); avail = {}
    for i, yr in enumerate(years):
        L[i], Q[i], avail[yr] = landsat_year(grid, yr)
    for i, yr in enumerate(s_years):
        S[i], a = sentinel_year(grid, yr); avail.setdefault(yr, {}).update(a)
    ds = xr.Dataset({"landsat": (("year", "feature", "y", "x"), L), "quality": (("year", "qfeature", "y", "x"), Q),
                     "terrain": (("tfeature", "y", "x"), terrain(grid)), "sentinel": (("syear", "sfeature", "y", "x"), S)},
                    coords={"year": years, "feature": LANDSAT_FEATURES, "qfeature": QUALITY, "tfeature": list(TERRAIN),
                            "syear": s_years, "sfeature": SENTINEL_FEATURES, "y": y, "x": x})
    ds.attrs.update({"grid": json.dumps(grid.to_dict()), "crs": str(grid.crs), "created_utc": utcnow(),
                     "registry": "configs/features.yaml", "harmonization": "local_pune_g30_v2 (Landsat); S2 native unless fused"})
    enc = {v: {"chunks": (1, ds[v].shape[1], min(256, H), min(256, W))} for v in ("landsat", "quality", "sentinel")}
    enc["terrain"] = {"chunks": (len(TERRAIN), min(256, H), min(256, W))}
    ds.to_zarr(out, mode="w", encoding=enc, consolidated=True)
    meta = {"zarr": str(out.relative_to(config.ROOT)), "shape": {k: list(ds[k].shape) for k in ds.data_vars}, "availability": avail,
            "valid_fraction_landsat_dry_ndvi": {int(yr): float(np.isfinite(L[i, LANDSAT_FEATURES.index("dry_ndvi")]).mean()) for i, yr in enumerate(years)},
            "seconds": round(time.time() - t0, 1), "created_utc": utcnow()}
    write_json(out.with_suffix(".json"), meta)
    return meta
