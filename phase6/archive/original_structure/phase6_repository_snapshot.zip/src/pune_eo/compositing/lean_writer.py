"""Memory-lean equivalent of engine.write_products for DISTRICT-size optical products assembled from row strips (Phase 5).

engine.write_products holds the full float32 composite + uncertainty and builds the QA stack through a float64 intermediate; for the 6546 x 5624 district grid this peaks
above the 6 GB sandbox limit (two OOM kills recorded in results/phase5/cube_pilot/pilot.log). This writer produces the SAME files, band order, dtypes, nodata, descriptions,
tags and metadata schema, assembling one output file at a time from the per-strip reductions (engine.reduce_period outputs saved as .npz).
Differences (tested in tests/test_lean_writer.py): statistics 'band_medians' / 'uncertainty_medians' are medians of the stored int16 values (/1e4) instead of the unrounded
float values (difference <= 0.5e-4 reflectance). Families: landsat, sentinel2 (optical) and sentinel1 (Phase 6: backscatter_mean_db, backscatter_median_db,
vv_minus_vh_db, uncertainty = temporal std in dB; nodata -9999; same files and metadata as engine.write_products)."""
from __future__ import annotations
from pathlib import Path
import numpy as np
from .. import config
from ..io import write_cog, write_json
from ..provenance import utcnow, code_block, sha256
from ..acquisition.boundary import study_area_version
from . import observations as obs
from .engine import PLATFORM_ORDER, PROCESSING_VERSION

def _median_int16(v: np.ndarray):
    if v.size == 0: return None
    h = np.bincount(v.astype(np.int64) + 32768, minlength=65536); c = np.cumsum(h); n = c[-1]
    lo = int(np.searchsorted(c, (n - 1) // 2 + 1)); hi = int(np.searchsorted(c, n // 2 + 1))
    return float(((lo - 32768) + (hi - 32768)) / 2.0) / 10000.0

def write_products_from_strips(family, period, grid, strips: list[tuple[int, int, Path]], inside: np.ndarray, metas: list[dict], out_dir: Path, cutoff,
                               transform_name, extra: dict, out_family: str | None = None) -> dict:
    """strips: [(row0, row1, npz_path)] partitioning the grid rows; each npz holds engine.reduce_period keys for rows row0:row1 of the full width."""
    assert family in ("landsat", "sentinel2", "sentinel1")
    out_dir = Path(out_dir); out_dir.mkdir(parents=True, exist_ok=True)
    bands = obs.BAND_NAMES[family]; plats = PLATFORM_ORDER[family]; H, W = grid.height, grid.width; files = {}
    def assemble(fn, nb, dtype, fill):
        a = np.full((nb, H, W), fill, dtype) if nb else np.full((H, W), fill, dtype)
        for r0, r1, p in strips:
            with np.load(p) as z: part = fn(z, inside[r0:r1])
            if nb: a[:, r0:r1] = part
            else: a[r0:r1] = part
        return a
    if family == "sentinel1":
        nb = len(bands); f32 = lambda key: assemble(lambda z, ins: np.where(ins, z[key], np.nan).astype(np.float32), nb, np.float32, np.nan)
        mdb = f32("mean_db")
        files["backscatter_mean_db"] = write_cog(out_dir / "backscatter_mean_db.tif", np.nan_to_num(mdb, nan=-9999), grid, nodata=-9999, dtype="float32", descriptions=[f"{b}_mean_db" for b in bands])
        sar_medians = {b: (float(np.nanmedian(mdb[i][inside])) if np.isfinite(mdb[i][inside]).any() else None) for i, b in enumerate(bands)}
        files["vv_minus_vh_db"] = write_cog(out_dir / "vv_minus_vh_db.tif", np.nan_to_num((mdb[0] - mdb[1])[None], nan=-9999), grid, nodata=-9999, dtype="float32", descriptions=["vv_minus_vh_db"]); del mdb
        med = f32("median_db"); files["backscatter_median_db"] = write_cog(out_dir / "backscatter_median_db.tif", np.nan_to_num(med, nan=-9999), grid, nodata=-9999, dtype="float32",
                                                                           descriptions=[f"{b}_median_db" for b in bands]); del med
        sd = f32("std_db"); files["uncertainty"] = write_cog(out_dir / "uncertainty.tif", np.nan_to_num(sd, nan=-9999), grid, nodata=-9999, dtype="float32", descriptions=[f"{b}_temporal_std_db" for b in bands]); del sd
        band_medians = unc_medians = None
    else:
        comp = assemble(lambda z, ins: np.where(np.isfinite(z["composite"]) & ins, np.round(z["composite"] * 10000), -32768).astype(np.int16), len(bands), np.int16, -32768)
        files["optical_composite"] = write_cog(out_dir / "optical_composite.tif", comp, grid, nodata=-32768, dtype="int16", descriptions=bands,
                                               tags={"units": "surface reflectance x 10000", "method": "per-pixel median of clear observations"})
        band_medians = {b: _median_int16(comp[i][inside & (comp[i] != -32768)]) for i, b in enumerate(bands)}; del comp
        unc = assemble(lambda z, ins: np.where(np.isfinite(z["uncertainty"]) & ins, np.round(z["uncertainty"] * 10000), -32768).astype(np.int16), len(bands), np.int16, -32768)
        files["uncertainty"] = write_cog(out_dir / "uncertainty.tif", unc, grid, nodata=-32768, dtype="int16", descriptions=[f"{b}_se_median" for b in bands],
                                         tags={"units": "reflectance x 10000", "method": "1.2533*1.4826*MAD/sqrt(n), n>=3"})
        unc_medians = {b: _median_int16(unc[i][inside & (unc[i] != -32768)]) for i, b in enumerate(bands)}; del unc
    n_clear = assemble(lambda z, ins: z["n_clear"].astype(np.uint16), 0, np.uint16, 0)
    files["observation_count"] = write_cog(out_dir / "observation_count.tif", np.where(inside, n_clear, 0).astype(np.uint16), grid, nodata=None, dtype="uint16",
                                           descriptions=["n_clear_observations"], overview_resampling="nearest")
    vm = np.where(n_clear >= 3, 3, np.where(n_clear >= 1, 2, 1)).astype(np.uint8); vm[~inside] = 0
    files["valid_mask"] = write_cog(out_dir / "valid_mask.tif", vm, grid, nodata=None, dtype="uint8",
                                    descriptions=["0 outside district | 1 no clear obs | 2 one-two clear obs | 3 three+ clear obs"], overview_resampling="nearest"); del vm
    def qa_part(z, ins):
        nob = z["n_observed"].astype(np.uint16); ncl = z["n_clear"].astype(np.uint16)
        cp = np.where(nob > 0, np.round(100.0 * ncl / np.maximum(nob, 1)), 0).astype(np.uint16)
        q = np.concatenate([nob[None], ncl[None], cp[None], z["per_platform"].astype(np.uint16), np.nan_to_num(z["doy_median"], nan=0).astype(np.uint16)[None]])
        q[:, ~ins] = 0; return q
    qa = assemble(qa_part, 3 + len(plats) + 1, np.uint16, 0)
    files["qa"] = write_cog(out_dir / "qa.tif", qa, grid, nodata=None, dtype="uint16",
                            descriptions=["n_observed", "n_clear", "clear_pct"] + [f"n_clear_{p}" for p in plats] + ["doy_median_clear"], overview_resampling="nearest")
    din = int(inside.sum()); nc = n_clear[inside]; nob_in = qa[0][inside]; cp_in = qa[2][inside]
    stats = {"district_pixels": din, "district_valid_fraction": float((nc >= 1).mean()) if din else 0.0, "district_reliable_fraction_ge3": float((nc >= 3).mean()) if din else 0.0,
             "single_obs_fraction": float((nc == 1).mean()) if din else 0.0, "n_clear_median": float(np.median(nc)) if din else 0.0,
             "n_clear_p10": float(np.percentile(nc, 10)) if din else 0.0, "n_clear_p90": float(np.percentile(nc, 90)) if din else 0.0,
             "clear_pct_mean": float(cp_in[nob_in > 0].mean()) if (nob_in > 0).any() else 0.0,
             "sensor_contribution_clear_px": {p: int(qa[3 + i][inside].sum()) for i, p in enumerate(plats)},
             "n_items": len(metas), "n_items_with_clear_px": int(sum(m["n_clear_px"] > 0 for m in metas)),
             "scene_cloud_mean": float(np.nanmean([m["cloud_cover"] for m in metas if m.get("cloud_cover") is not None])) if any(m.get("cloud_cover") is not None for m in metas) else None,
             **({"backscatter_median_db": sar_medians} if family == "sentinel1" else {"band_medians": band_medians, "uncertainty_medians": unc_medians})}
    del qa, n_clear
    stats.update(extra.get("stats", {}))
    meta = {"product_id": f"{out_family or family}/{grid.id}/{period.year}/{period.relpath}", "sensor_family": family, "schema_version": "1.0.0", "processing_version": PROCESSING_VERSION,
            "created_utc": utcnow(), "study_area": study_area_version(), "grid": grid.to_dict(),
            "temporal": {"year": period.year, "period": period.name, "kind": period.kind, "start": period.start.strftime("%Y-%m-%d"), "end": period.end.strftime("%Y-%m-%d"),
                         "complete": bool(period.complete(cutoff)), "archive_cutoff_utc": str(cutoff),
                         "first_observation": min((m["date"] for m in metas), default=None), "last_observation": max((m["date"] for m in metas), default=None)},
            "sources": [{k: m.get(k) for k in ("item_id", "platform", "date", "tile_id", "cloud_cover", "n_clear_px", "processing_baseline", "orbit_state", "relative_orbit") if k in m} for m in metas],
            "sensors": {p: sum(m["platform"] == p for m in metas) for p in plats if any(m["platform"] == p for m in metas)},
            "processing": extra.get("processing", {}) | {"harmonization": transform_name, "writer": "lean_writer.write_products_from_strips"},
            "statistics": stats, "files": {k: {"path": str(Path(v).relative_to(config.ROOT)) if str(v).startswith(str(config.ROOT)) else str(v), "sha256": sha256(Path(v))} for k, v in files.items()},
            "code": code_block(config.config_hash(family, "grid", "temporal", "study_area"))}
    write_json(out_dir / "metadata.json", meta)
    return meta
