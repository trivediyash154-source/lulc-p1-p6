"""Sensor harmonisation layer: per-observation linear transforms to the OLI reference."""
from __future__ import annotations
import functools
from pathlib import Path
import numpy as np
import yaml
from .. import config

BANDS = list(config.load("landsat")["bands"])

@functools.lru_cache(maxsize=None)
def transform_spec(name: str | None = None) -> dict:
    h = config.load("landsat")["harmonization"]
    name = name or h["active_transform"]
    if name in ("local_pune_v1", "local_pune_g30_v2") or (name not in h.get("transforms", {}) and config.path("results", "harmonization", f"{name}.yaml").exists()):
        # fitted transforms live in results/harmonization/<name>.yaml (e.g. the P4-C2@v2 treatment c2_tm_pif_v1, Phase 6 D2)
        p = config.path("results", "harmonization", f"{name}.yaml")
        if not p.exists():
            raise FileNotFoundError("local_pune_v1 requested but not fitted yet: run `pune-eo harmonize`")
        spec = yaml.safe_load(p.read_text())
    else:
        spec = h["transforms"][name]
    return {"name": name, **spec}

def apply(refl: dict[str, np.ndarray] | np.ndarray, platform: str, name: str | None = None):
    """Transform reflectance of one observation to OLI-equivalent. Identity where not applicable."""
    spec = transform_spec(name)
    if spec["name"] == "none":
        return refl
    per = spec.get("per_platform")
    if per:                                    # local fit: coefficients per platform
        coef = per.get(platform)
        if coef is None:
            return refl
        slope, icpt = coef["slope"], coef["intercept"]
    else:
        if platform not in spec.get("applies_to", []):
            return refl
        slope, icpt = spec["slope"], spec["intercept"]
    if isinstance(refl, dict):
        return {b: refl[b] * slope[b] + icpt[b] for b in refl}
    s = np.array([slope[b] for b in BANDS], np.float32)[:, None, None]
    i = np.array([icpt[b] for b in BANDS], np.float32)[:, None, None]
    return refl * s + i


def active_for_grid(grid_id: str) -> str:
    """Resolution-specific active transform, e.g. 'pune_G30_khadakwasla_mutha' -> configs active_transform_by_grid['G30']."""
    h = config.load("landsat")["harmonization"]
    key = grid_id.split("_")[1] if grid_id.startswith("pune_") else grid_id
    return h.get("active_transform_by_grid", {}).get(key, h["active_transform"])
