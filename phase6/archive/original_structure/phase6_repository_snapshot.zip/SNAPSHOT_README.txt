Pune EO PhD repository snapshot at git 7b85b69 (Phase 6).
Included: every tracked file <= 1.5 MB (code, configs, tests, docs, registry, results JSON/CSV) + results/phase6/d2/pif_fit_sample.parquet.
Excluded: data/_phase1_snapshot rasters and other tracked files > 1.5 MB (see Phase 1/5 zips), all evaluator keys (_key/: see phase6_KEYS_evaluator_only.zip), gitignored products (regenerate per docs/phase6_D3_compute_decision.md).
