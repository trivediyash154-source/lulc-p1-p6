"""District silver (arm A) rule and builder. Synthetic fractions are SYNTHETIC TEST DATA — NOT RESEARCH DATA; the window check reads real window files read-only."""
import json, sys
from pathlib import Path
import numpy as np, rasterio, pytest
ROOT = Path(__file__).resolve().parents[1]; sys.path.insert(0, str(ROOT / "src"))
from pune_eo import config
from pune_eo.grid import Grid
from pune_eo.labels import district_silver as DS

def test_rule_reproduces_window_silver_from_window_fractions():
    sc = config.load("labels")["silver_consensus"]; n = 0
    for w in ("khadakwasla_mutha", "baramati_agri", "mulshi_ghats"):
        d = ROOT / "data/labels" / f"pune_G30_{w}"
        if not all((d / f"{s}_l1_fractions.tif").exists() for s in sc["sources"]) or not (d / "silver_l1.tif").exists(): continue
        fr = []
        for s in sc["sources"]:
            with rasterio.open(d / f"{s}_l1_fractions.tif") as src: a = src.read().astype(np.float32); a[a < 0] = np.nan; fr.append(a)
        with rasterio.open(d / "silver_l1.tif") as src: ref = src.read(1)
        assert (DS.silver_rule(fr, sc["min_purity"]) == ref).all(), w; n += 1
    if n == 0: pytest.skip("window silver files absent")

def test_build_strips_validate_and_window_equality(tmp_path):
    H, W = 50, 40; g = Grid("synthetic_ds", "EPSG:32643", 30.0, 300000.0, 2001500.0, W, H, 15.0); rng = np.random.default_rng(3)
    full = [rng.dirichlet(np.ones(6) * 0.3, size=(H, W)).transpose(2, 0, 1).astype(np.float32) for _ in range(4)]
    full[1] = full[0].copy(); full[2] = full[0].copy(); full[3] = full[0].copy(); full[3][:, :5, :5] = np.nan     # unanimous except a no-data corner
    def fetch(sub, sources):
        r0 = int(round((g.y1 - sub.y1) / g.res)); return [f[:, r0:r0 + sub.height] for f in full], {s: ["SYN"] for s in sources}
    dm = np.ones((H, W), bool); dm[-3:, :] = False
    meta = DS.build(g, dm, tmp_path / "ds", strip=16, fetch=fetch, log=lambda *a: None)
    ref = DS.silver_rule(full, config.load("labels")["silver_consensus"]["min_purity"]); ref[~dm] = 0
    with rasterio.open(tmp_path / "ds/silver_l1.tif") as s: out = s.read(1)
    assert (out == ref).all() and meta["labelled_cells"] == int((ref > 0).sum()) and (out[:5, :5] == 0).all()
    wg = Grid("synthetic_win", g.crs, 30.0, g.x0 + 300.0, g.y1 - 600.0, 12, 10, 15.0); wp = tmp_path / "win.tif"
    with rasterio.open(wp, "w", driver="GTiff", width=12, height=10, count=1, dtype="uint8", crs=g.crs, transform=wg.transform) as d: d.write(ref[20:30, 10:22][None])
    def wfetch(sub, sources):
        r0 = int(round((g.y1 - sub.y1) / g.res)); c0 = int(round((sub.x0 - g.x0) / g.res)); return [f[:, r0:r0 + sub.height, c0:c0 + sub.width] for f in full], {}
    r = DS.validate(tmp_path / "ds", g, dm, {"w": (wg, wp)}, fetch=wfetch); assert r["ok"], r["checks"]
    with rasterio.open(wp, "r+") as d: x = d.read(1); x[0, 0] = (x[0, 0] % 6) + 1; d.write(x[None])           # one changed cell: window no longer reproduced exactly
    r2 = DS.validate(tmp_path / "ds", g, dm, {"w": (wg, wp)}, fetch=wfetch)
    assert not r2["checks"]["window_extent_reproduces_window_silver_exactly"]["ok"] and not r2["ok"]
    with rasterio.open(wp, "r+") as d: x = d.read(1); x[:5] = (x[:5] % 6) + 1; d.write(x[None])               # half the window differs: agreement check fails too
    assert not DS.validate(tmp_path / "ds", g, dm, {"w": (wg, wp)}, fetch=wfetch)["checks"][f"agreement_with_window_silver_on_overlap_ge_{DS.AGREEMENT_MIN}"]["ok"]
