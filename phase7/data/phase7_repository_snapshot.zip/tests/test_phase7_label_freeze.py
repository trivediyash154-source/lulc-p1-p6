"""Phase 7 label freeze (Stages 3-4). Every label here is SYNTHETIC TEST DATA — NOT RESEARCH DATA (helpers from tests/test_gold_ingestion.py)."""
import importlib.util, json, sys
from pathlib import Path
import numpy as np, pandas as pd, pytest
ROOT = Path(__file__).resolve().parents[1]; sys.path.insert(0, str(ROOT / "src"))
def _mod(p, n):
    s = importlib.util.spec_from_file_location(n, ROOT / p); m = importlib.util.module_from_spec(s); s.loader.exec_module(m); return m
TG = _mod("tests/test_gold_ingestion.py", "tg7"); LF = _mod("scripts/phase7_label_freeze.py", "lf7")
from validation import ingest_gold as IG

def test_not_available_without_forms(tmp_path):
    g, K, truth = TG.make_gold(tmp_path)
    r = LF.freeze_labels("gold", "tester", base=g, audit_out=tmp_path / "a", mdir=tmp_path / "m", report=tmp_path / "r.md", spatial=TG.spatial_ok(), kit_manifest=tmp_path / "none.json")
    assert r["manifest"]["status"] == "NOT_AVAILABLE" and not list((tmp_path / "m").glob("manifest_v*.json")) and "No label was created" in (tmp_path / "r.md").read_text()

def test_gold_freeze_versioning_and_refreeze_refusal(tmp_path):
    g, K, truth = TG.setup_valid(tmp_path, n=40, n_double=10)
    kw = dict(base=g, audit_out=tmp_path / "a", mdir=tmp_path / "m", report=tmp_path / "r.md", spatial=TG.spatial_ok(), kit_manifest=tmp_path / "none.json")
    r = LF.freeze_labels("gold", "tester", **kw); M = r["manifest"]
    assert M["status"] == "FROZEN" and M["version"] == 1 and M["n_points"] == 40 and M["verification_ok"], {k: v for k, v in r["verification"].items() if not v["ok"]}
    for k in ("expected_ids", "no_duplicate_ids", "no_missing_ids", "valid_class_values", "valid_epochs", "valid_distinct_interpreter_ids", "coordinates_unchanged",
              "no_prohibited_or_leakage_fields", "double_interpretation_subset_complete", "disagreement_statistics_generated"): assert r["verification"][k]["ok"], k
    v1 = (tmp_path / "m/manifest_v1.json").read_text()
    r2 = LF.freeze_labels("gold", "tester", **kw); assert r2["manifest"]["status"] == "FROZEN" and r2["manifest"]["version"] == 1 and not (tmp_path / "m/manifest_v2.json").exists()
    p = g / "raw_interpreter_A/pass1.csv"; df = pd.read_csv(p); df.loc[0, "notes_2020"] = "edited after freeze (SYNTHETIC)"; df.to_csv(p, index=False)   # silent edit, no correction record
    r3 = LF.freeze_labels("gold", "tester", **kw); assert r3["manifest"]["status"] == "INGEST_FAIL" and "HASH_MISMATCH" in r3["manifest"]["reason"]
    assert (tmp_path / "m/manifest_v1.json").read_text() == v1 and not (tmp_path / "m/manifest_v2.json").exists()

def test_training_freeze_reports_balance_and_partition(tmp_path):
    g, K, truth = TG.make_gold(tmp_path, n=40, n_double=10); K["split"] = ["tuning" if i % 2 else "train" for i in range(len(K))]
    K["dist_to_tuning_block_m"] = np.where(K.split == "tuning", 0.0, 5000.0); (g / "_key/phase4_gold_key.csv").unlink(); K.to_csv(g / "_key/T1_key.csv", index=False)
    dbl = K.anon_id[K.double_interpretation].tolist()
    pa = TG.put(g, "A", TG.form(K, truth, K.anon_id), TG.meta("A", "INT-A")); pb = TG.put(g, "B", TG.form(K, truth, dbl), TG.meta("B", "INT-B")); IG.freeze_pass("p1", [pa, pb], "t", gold=g)
    n = 50; dt = np.full((n, n), 5000.0); dt[K.row[K.split == "tuning"], K.col[K.split == "tuning"]] = 0.0
    sp = IG.Spatial(np.ones((n, n), bool), np.zeros((n, n), bool), np.zeros((n, n)), np.full((n, n), 9000.0), np.array([[1e6, 1e6]]), dt)
    r = LF.freeze_labels("training", "tester", base=g, audit_out=tmp_path / "a", mdir=tmp_path / "m", report=tmp_path / "r.md", spatial=sp, kit_manifest=tmp_path / "none.json",
                         grid={"x0": 1000.0, "y1": 5000.0})
    assert r["manifest"]["status"] == "FROZEN", r["manifest"].get("reason")
    assert r["verification"]["spatial_leakage_audit"]["ok"] and r["verification"]["training_tuning_separation"]["ok"] and set(r["verification"]["class_balance_reported"]["counts"]) >= {"train/2020", "tuning/2020"}
