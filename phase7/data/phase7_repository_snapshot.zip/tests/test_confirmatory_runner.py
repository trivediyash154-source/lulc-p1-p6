"""Phase 7 confirmatory runner: frozen-function equivalence, decision logic, fail-closed guards (incl. the P4-C2@v2 transform chain) and an
end-to-end P4-C1@v2 / P4-C2@v2 run on a small synthetic world. Every raster, label and cube here is SYNTHETIC TEST DATA — NOT RESEARCH DATA."""
import importlib.util, json, shutil, sys, uuid
from pathlib import Path
import numpy as np, pandas as pd, pytest, rasterio
ROOT = Path(__file__).resolve().parents[1]; sys.path.insert(0, str(ROOT / "src"))
from pune_eo import config
from pune_eo.evaluation4 import metrics as EM, protocol as P4
from pune_eo.confirmatory import Refusal, analysis as AN, data as D, experiments as EX, guards as GU, spec as SP
def _mod(p, n):
    s = importlib.util.spec_from_file_location(n, ROOT / p); m = importlib.util.module_from_spec(s); s.loader.exec_module(m); return m

# ------------------------------------------------------------------ frozen-function equivalence
def test_design_weighted_metrics_equal_frozen_functions():
    rng = np.random.default_rng(0); n = 400; strata = rng.choice(["s1", "s2", "s3"], n); npop = {"s1": 5000, "s2": 800, "s3": 20000}
    y = rng.choice([1, 2, 3, 4, 5], n, p=[.3, .3, .2, .15, .05]); m = np.where(rng.random(n) < .7, np.minimum(y, 4), rng.integers(1, 5, n))
    w = AN.design_weights(strata, npop)
    assert np.allclose(AN.weighted_confusion(y, m, w), EM.confusion(y, m, AN.ALL, w))
    oa = EM.stratified_estimates(y, m, strata, npop, AN.ALL)["overall_accuracy"]; mv = AN.metric_values(y, m, strata, npop)
    assert abs(mv["oa"] - oa) < 1e-12
    assert abs(mv["macro_f1"] - EM.summary(y, m, AN.ALL, weights=w)["macro_f1_present"]) < 1e-12

def test_paired_test_identical_maps_and_decision_rule():
    rng = np.random.default_rng(1); n = 300; y = rng.integers(1, 5, n); st = rng.choice(["a", "b"], n); bl = rng.choice([f"k{i}" for i in range(40)], n)
    maps = np.stack([np.where(rng.random(n) < .8, y, 1) for _ in range(5)])
    t = AN.paired_test(maps, maps, y, st, bl, {"a": 100, "b": 300}, "oa", n_boot=100)
    assert t["estimate"] == 0 and t["p_two_sided"] == 1.0 and t["seeds_agreeing_in_sign"] == 0
    AN.apply_bh([t]); assert AN.decide(t, "two-sided") == "NOT_SUPPORTED"
    good = {"testable": True, "ci": [0.01, 0.05], "q_bh": 0.01, "seeds_agreeing_in_sign": 4}
    assert AN.decide(good, "improvement") == "SUPPORTED" and AN.decide(dict(good, ci=[-0.05, -0.01]), "improvement") == "NOT_SUPPORTED"
    assert AN.decide(dict(good, seeds_agreeing_in_sign=3), "two-sided") == "NOT_SUPPORTED" and AN.decide(dict(good, q_bh=0.06), "two-sided") == "NOT_SUPPORTED"
    assert AN.decide({"testable": False}, "two-sided") == "NOT_TESTABLE"

def test_bh_untestable_enter_with_p1_and_c1_aggregation():
    ts = [{"p_two_sided": 0.001}, AN.not_testable("oa", 50)]; AN.apply_bh(ts); assert ts[1]["p_two_sided"] == 1.0 and abs(ts[0]["q_bh"] - 0.002) < 1e-12
    mk = lambda c, d: {"contrast": c, "decision": d}
    assert AN.c1_outcome([mk(c, "SUPPORTED") for c in ("B-A", "C-A", "D-A", "E-A")])["outcome"] == "SUPPORTED"
    assert AN.c1_outcome([mk("B-A", "NOT_SUPPORTED")] + [mk(c, "SUPPORTED") for c in ("C-A", "D-A", "E-A")])["outcome"] == "NOT_SUPPORTED"
    assert AN.c1_outcome([mk("B-A", "NOT_TESTABLE")] + [mk(c, "SUPPORTED") for c in ("C-A", "D-A", "E-A")])["outcome"] == "INCONCLUSIVE"

# ------------------------------------------------------------------ guards on the real repository (fail closed now)
def test_preflight_refuses_every_record_today():
    for e in ("P4-C1@v2", "P4-C2@v2", "P4-C3@v2", "P4-C4@v2", "P4-C5@v2", "P4-C6@v2"):
        if (P4.load(e) or {}).get("status") != "PENDING": continue
        with pytest.raises(Refusal) as r: GU.preflight(e)
        f = r.value.failed
        if not GU.label_manifest("gold") or GU.label_manifest("gold").get("status") != "FROZEN": assert "gold" in f and "prerun_checklist" in f
        if e not in ("P4-C1@v2", "P4-C2@v2"): assert "implementation" in f

def test_registration_and_single_execution_guards(tmp_path, monkeypatch):
    monkeypatch.setattr(GU, "implementation_hashes", lambda: {"src/pune_eo/confirmatory/runner.py": "0" * 64})
    with pytest.raises(Refusal) as r: GU.preflight("P4-C1@v2", run_root=str(tmp_path))
    assert "implementation_registration" in r.value.failed
    (tmp_path / "P4-C1_at_v2").mkdir()
    with pytest.raises(Refusal) as r: GU.preflight("P4-C1@v2", run_root=str(tmp_path))
    assert "single_execution" in r.value.failed

def test_specification_requires_adoption_countersignature_and_pointer(tmp_path, monkeypatch):
    add = tmp_path / SP.ADD; add.mkdir(parents=True); body = {"status": "ADOPTED", "items": []}
    p = add / "P4-C3_at_v2_addendum_1.json"; p.write_text(json.dumps(body)); h = SP._sha(p)
    assert not SP.status("P4-C3@v2", tmp_path)["complete"]                                           # no countersignature
    (tmp_path / SP.CS["phase7"]).write_text(json.dumps({"researcher_name": "SYNTHETIC", "signed_utc": "x", "decisions": {"P4-C3": {"adopted_addendum_sha256": h, "accepted": True}}}))
    assert "pointer" in SP.status("P4-C3@v2", tmp_path)["missing"][0]                                  # no record pointer
    rec = P4.load("P4-C3@v2"); monkeypatch.setattr(SP.P4, "load", lambda e: dict(rec, addenda=[{"path": f"{SP.ADD}/P4-C3_at_v2_addendum_1.json", "sha256": h}]))
    assert SP.status("P4-C3@v2", tmp_path)["complete"]
    p.write_text(json.dumps(dict(body, status="PROPOSED"))); assert not SP.status("P4-C3@v2", tmp_path)["complete"]

# ------------------------------------------------------------------ P4-C2@v2 transform chain (fail closed)
def _c2_world(root: Path):
    for rel in ("results/harmonization/c2_tm_pif_v1.yaml", "results/harmonization/c2_tm_pif_v1.sha256", "results/harmonization/local_pune_g30_v2.yaml",
                "results/phase6/d2/pif_fit_report.json", "experiments/registry4/addenda/P4-C2_at_v2_addendum_1.json", "configs/landsat.yaml"):
        (root / rel).parent.mkdir(parents=True, exist_ok=True); shutil.copy(ROOT / rel, root / rel)
    src = {}
    for y in GU.C2TM_YEARS:
        for rel in GU.PERIODS:
            for fam, h, t, sp in (("landsat_c2tm", GU.C2_TRANSFORM, GU.C2_SHA, GU.spec_sha(GU.C2_TRANSFORM, ROOT / "results/harmonization/c2_tm_pif_v1.yaml")),
                                  ("landsat", GU.COMPARATOR_TRANSFORM, GU.COMPARATOR_SHA, GU.spec_sha(GU.COMPARATOR_TRANSFORM, ROOT / "results/harmonization/local_pune_g30_v2.yaml"))):
                q = root / f"data/composites/pune_G30/{y}/{fam}/{rel}/metadata.json"; q.parent.mkdir(parents=True, exist_ok=True)
                q.write_text(json.dumps({"processing": {"harmonization": h, "transform_sha256": t, "transform_spec_sha256": sp}, "note": "SYNTHETIC TEST DATA"}))
                if fam == "landsat_c2tm": src[str(q.relative_to(root))] = GU.sha(q)
    (root / "results/phase6/cube_validation_c2tm.json").write_text(json.dumps({"ok": True, "complete_for_required": True, "family": "landsat_c2tm", "expect_transform_sha256": GU.C2_SHA}))
    for cube, rep, fam in ((GU.CUBE_C2, GU.FCV_C2, "landsat_c2tm"), (GU.CUBE, GU.FCV, "landsat")):
        c = root / cube; c.mkdir(parents=True, exist_ok=True)
        c.with_suffix(".json").write_text(json.dumps({"family_per_year": {str(y): fam for y in GU.C2TM_YEARS}, "source_metadata_sha256": src if fam == "landsat_c2tm" else {}}))
        (root / rep).write_text(json.dumps({"ok": True, "path": str(c.resolve()), "family": fam, "sidecar_sha256": GU.sha(c.with_suffix(".json"))}))

def test_c2_transform_chain_passes_only_when_every_link_holds(tmp_path, monkeypatch):
    _c2_world(tmp_path); monkeypatch.setattr(config, "ROOT", tmp_path)
    F, P = GU.verify_c2_transform(); assert F == {}, F
    assert P["transform_sha256"] == GU.C2_SHA and P["treatment_products_checked"] == 44
    q = tmp_path / "data/composites/pune_G30/2000/landsat_c2tm/seasonal/dry/metadata.json"; d = json.loads(q.read_text())
    q.write_text(json.dumps(dict(d, processing={"harmonization": GU.C2_TRANSFORM, "transform_sha256": "f" * 64})))      # a product made with another transform file
    F, _ = GU.verify_c2_transform(); assert "treatment_products" in F and "treatment_cube_sources" in F
    q.write_text(json.dumps(dict(d, processing=dict(d["processing"], transform_spec_sha256="e" * 64))))                 # same file name/SHA recorded, other coefficients applied
    F, _ = GU.verify_c2_transform(); assert "treatment_products" in F
    q.write_text(json.dumps(d)); assert GU.verify_c2_transform()[0] == {}
    sc = tmp_path / (GU.CUBE_C2.replace(".zarr", ".json")); m = json.loads(sc.read_text()); m["family_per_year"].pop("1990"); sc.write_text(json.dumps(m))   # a TM year silently absent
    F, _ = GU.verify_c2_transform(); assert "treatment_cube_years" in F and "treatment_cube" in F
    m["family_per_year"]["1990"] = "landsat_c2tm"; sc.write_text(json.dumps(m)); rep = tmp_path / GU.FCV_C2; r = json.loads(rep.read_text()); r["sidecar_sha256"] = GU.sha(sc); rep.write_text(json.dumps(r))
    assert GU.verify_c2_transform()[0] == {}
    cf = tmp_path / "results/harmonization/local_pune_g30_v2.yaml"; cf.write_text(cf.read_text() + "\n# edited\n")              # comparator transform altered
    F, _ = GU.verify_c2_transform(); assert "comparator_transform_file" in F
    shutil.copy(ROOT / "results/harmonization/local_pune_g30_v2.yaml", cf)
    t = tmp_path / "results/harmonization/c2_tm_pif_v1.yaml"; t.write_text(t.read_text() + "\n# regenerated\n")                # an accidentally regenerated correction
    F, _ = GU.verify_c2_transform(); assert "transform_file" in F
    shutil.copy(ROOT / "results/harmonization/c2_tm_pif_v1.yaml", t)
    (tmp_path / "configs/landsat.yaml").write_text((ROOT / "configs/landsat.yaml").read_text().replace("transforms:", "transforms:\n    c2_tm_pif_v1: {per_platform: {}}", 1))
    F, _ = GU.verify_c2_transform(); assert "config_shadowing" in F

# ------------------------------------------------------------------ end-to-end on a synthetic world
def _world(tmp: Path):
    FC = _mod("tests/test_district_feature_cube.py", "fct"); B = _mod("scripts/phase6_build_feature_cube.py", "fcb_r")
    from pune_eo.grid import Grid
    gid = "synthetic_G30_run_" + uuid.uuid4().hex[:6]; H, W = 36, 30; g = Grid(gid, "EPSG:32643", 30.0, 300015.0, 2000015.0, W, H, 15.0)
    inside = np.ones((H, W), bool); rng = np.random.default_rng(7); years = [1990, 2000, 2010, 2020]
    FC._write_synthetic(g, years, inside, rng)
    cube = tmp / "cube.zarr"; B.build(g, years, [2020], cube, strip=12, mask=inside, chunk=12, log=lambda *a: None)
    grid = {"x0": g.x0, "y1": g.y1, "res": 30.0}
    def wr(name, arr, desc=None):
        p = tmp / name
        with rasterio.open(p, "w", driver="GTiff", width=W, height=H, count=arr.shape[0], dtype=arr.dtype, crs=g.crs, transform=g.transform) as d:
            d.write(arr)
            if desc: d.descriptions = desc
        return p
    sil = rng.integers(0, 5, (1, H, W)).astype(np.uint8)
    gold = pd.DataFrame({"row": rng.integers(0, H, 120), "col": rng.integers(0, W, 120)}).drop_duplicates().reset_index(drop=True)
    pop = np.ones((1, H, W), np.uint8); pop[0, gold.row, gold.col] = 0
    glc_codes = np.array([10, 190, 210, 51, 150]); glc = np.stack([glc_codes[rng.integers(0, 5, (H, W))] for _ in range(2)]).astype(np.uint16)
    gold["anon_id"] = [f"SYN-{i:04d}" for i in range(len(gold))]; gold["stratum"] = np.where(gold.index % 2, "s1", "s2"); gold["block"] = [f"{r // 6}:{c // 6}" for r, c in zip(gold.row, gold.col)]
    gold["region"] = "r"; gold["stratum_area_cells"] = np.where(gold.stratum == "s1", 600, 400); kp = tmp / "gold_key.csv"; gold.to_csv(kp, index=False)
    names = ["built_up", "agriculture", "natural_vegetation", "water", "bare_sparse"]
    gl = pd.DataFrame([{"anon_id": a, "epoch": e, "reference_label": names[rng.integers(0, 5)], "in_accuracy_set": True} for a in gold.anon_id for e in years]); gp = tmp / "gold_labels.csv"; gl.to_csv(gp, index=False)
    free = np.array([(r, c) for r in range(H) for c in range(W) if pop[0, r, c] and not (r % 7 == 0 and c % 5 == 0)]); t1sel = free[rng.choice(len(free), 80, replace=False)]
    t1c = pd.DataFrame({"row": t1sel[:, 0], "col": t1sel[:, 1]}); t1c["anon_id"] = [f"SYT-{i:04d}" for i in range(80)]; t1c["split"] = np.where(t1c.index % 3 == 0, "tuning", "train")
    t1 = pd.DataFrame([dict(r, epoch=e, reference_label=names[rng.integers(0, 4)], in_accuracy_set=True, labelled=True) for r in t1c.to_dict("records") for e in (2020, 2000)]); tp = tmp / "t1.csv"; t1.to_csv(tp, index=False)
    pop[0, t1c.row[t1c.split == "tuning"], t1c.col[t1c.split == "tuning"]] = 0                      # tuning cells are outside the train population (as tuning_blocks_30m.tif)
    inp = D.Inputs(cube=cube, silver=wr("silver.tif", sil), train_population=wr("pop.tif", pop), glc=wr("glc.tif", glc, ("2020", "2021")), gold_key=kp, gold_labels=gp, t1_labels=tp,
                   block_m=180.0, min_dist_gold_m=0.0)                                           # synthetic 1 km world: 2 km separation impossible; identity checks still apply
    return inp, grid, g, inside

def test_end_to_end_c1_then_c2_on_synthetic_world(tmp_path, monkeypatch):
    inp, grid, g, inside = _world(tmp_path)
    try:
        out = tmp_path / "C1"; out.mkdir(); real = D.gold_labels; calls = []
        def guarded(i, e):
            assert (out / "selection.json").exists(), "gold labels read before the tuning selection was frozen"; calls.append(e); return real(i, e)
        monkeypatch.setattr(D, "gold_labels", guarded)
        r = EX.run_c1(inp, grid, out, [11, 12], n_boot=40, threads=1, log=lambda *a: None)
        assert len(r["tests"]) == 64 and all("q_bh" in t and t["decision"] in ("SUPPORTED", "NOT_SUPPORTED", "NOT_TESTABLE") for t in r["tests"])
        assert r["outcome"] in ("SUPPORTED", "NOT_SUPPORTED", "INCONCLUSIVE") and r["selection"]["gold_consulted"] is False and set(calls) == {2020, 2010, 2000, 1990}
        assert all(EX._sha(out / k) == v for k, v in r["output_sha256"].items())
        pr = pd.read_parquet(out / "predictions/predictions.parquet"); assert "reference_label" not in pr.columns and "y" not in pr.columns
        key = pd.read_csv(inp.gold_key); gcells = set(zip(key.row, key.col))
        for f in (out / "training_rows").glob("*.parquet"):
            R = pd.read_parquet(f); assert not (set(zip(R.row, R.col)) & gcells), f.name                       # no gold cell in any training arm
            if f.name.startswith("D_"): assert set(R.epoch) <= {2020, 2000} and (R.source == "T1_train").all()
        t1 = pd.read_csv(inp.t1_labels); tun = set(zip(t1.row[t1.split == "tuning"], t1.col[t1.split == "tuning"]))
        assert not any(set(zip(pd.read_parquet(f).row, pd.read_parquet(f).col)) & tun for f in (out / "training_rows").glob("D_*.parquet"))
        with pytest.raises(D.Leakage): D.leakage_check(pd.DataFrame({"row": [key.row[0]], "col": [key.col[0]], "source": ["silver"]}), key, t1[t1.split == "tuning"], inp, grid)
        with pytest.raises(D.Leakage): D.leakage_check(pd.DataFrame({"row": [key.row[0]], "col": [key.col[0]], "source": ["silver"]}), key.iloc[1:], t1[t1.split == "tuning"], D.Inputs(**{**inp.__dict__, "min_dist_gold_m": 2000.0}), grid)
        out2 = tmp_path / "C2"; out2.mkdir()
        env = {"epochs": {"1990": {"district": {"shares": {"GHSL": .01, "WSF": .02, "GLC_FCS30D_impervious": .03}, "envelope_with_tolerance": [0, .05]}},
                          "2000": {"district": {"shares": {"GHSL": .02, "WSF": .03, "GLC_FCS30D_impervious": .04}, "envelope_with_tolerance": [0, .06]}}}}
        r2 = EX.run_c2(inp, D.Inputs(**{**inp.__dict__}), grid, out2, [11, 12], r["selection"], env, inside, n_boot=40, threads=1, share_step=3, log=lambda *a: None)
        assert [t["epoch"] for t in r2["tests"]] == [1990, 2000] and r2["outcome"] == "PENDING_FAMILY"
        assert all(abs(t["estimate"]) < 1e-12 for t in r2["tests"] if t["testable"])                            # identical cubes -> zero difference (single factor)
    finally:
        for p in (config.path("data/composites", g.id), config.path("data/features/terrain", g.id)): shutil.rmtree(p, ignore_errors=True)

def test_runner_refuses_without_side_effects_and_family_finalisation(tmp_path, monkeypatch):
    from pune_eo.confirmatory import runner as RU
    with pytest.raises(Refusal): RU.run("P4-C1@v2", run_root=str(tmp_path / "runs"))
    assert not (tmp_path / "runs" / "P4-C1_at_v2").exists()                                             # nothing created on refusal
    recs = {e: dict(P4.load(e)) for e in ("P4-C2@v2", "P4-C3@v2")}; writes = []
    monkeypatch.setattr(RU.P4, "load", lambda e: dict(recs[e])); monkeypatch.setattr(RU.P4, "_write", lambda r: (writes.append(r), recs.__setitem__(r["experiment_id"], r)))
    rr = tmp_path / "runs"; (rr / "P4-C2_at_v2").mkdir(parents=True)
    t = lambda est, p: {"testable": True, "estimate": est, "ci": [est - .01, est + .01], "p_two_sided": p, "seeds_agreeing_in_sign": 5}
    (rr / "P4-C2_at_v2/results.json").write_text(json.dumps({"tests": [dict(t(.05, .001), epoch=1990), dict(t(.04, .002), epoch=2000)]}))
    recs["P4-C2@v2"]["status"] = "PASS"
    assert RU.finalise_family("historical", str(rr)) is None                                              # P4-C3@v2 still PENDING (G-1)
    recs["P4-C3@v2"]["status"] = "FAIL"
    f = RU.finalise_family("historical", str(rr))
    assert f["outcomes"]["P4-C2@v2"] == "SUPPORTED" and f["n_tests"] == 4 and all("q_bh" in x for x in f["tests"]) and len(writes) == 2   # C3's 2 planned tests enter with p = 1
    assert sorted(round(x["q_bh"], 6) for x in f["tests"])[:2] == [0.004, 0.004]
    assert recs["P4-C2@v2"]["family_decision"][0]["outcome"] == "SUPPORTED" and RU.finalise_family("historical", str(rr))["created_utc"] == f["created_utc"]

def test_preflight_refuses_specification_adopted_after_gold_freeze(monkeypatch):
    monkeypatch.setattr(GU, "first_manifest", lambda tag: {"created_utc": "2026-01-01T00:00:00Z"})
    monkeypatch.setattr(GU.spec, "status", lambda e, root=None: {"experiment_id": e, "complete": True, "missing": [], "adopted": [{"path": "x/P4-C1_at_v2_addendum_2.json", "sha256": "0", "countersigned_utc": "2026-12-01T00:00:00Z"}]})
    with pytest.raises(Refusal) as r: GU.preflight("P4-C1@v2")
    assert "adoption_after_gold_P4-C1_at_v2_addendum_2" in r.value.failed and "adoption_after_T1_P4-C1_at_v2_addendum_2" in r.value.failed
    assert any(k.startswith("input_") for k in r.value.failed) or all(GU.input_checks("P4-C1@v2")[1].values())
