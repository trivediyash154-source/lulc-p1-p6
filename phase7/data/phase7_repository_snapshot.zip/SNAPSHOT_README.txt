Pune EO PhD repository snapshot at git 9f24ecc (Phase 7, restored repository).
Included: every tracked file <= 1.5 MB + the D2 fit sample + the frozen district silver (silver_l1.tif, SHA-256 32e1ddb0...).
Excluded: evaluator keys (phase6_KEYS_evaluator_only.zip, unchanged), gitignored products (regenerate: docs/phase7_cube_build_report.md).
Git history: phase7_repository.bundle (git clone phase7_repository.bundle).
