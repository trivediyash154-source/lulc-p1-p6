"""District silver L1 labels (P4-C1@v2 arm A) on pune_G30, built in row strips with the SAME rule and source code as the window silver
(labels/silver.py::build_silver L1 part, labels/sources.py::landcover_fractions):

  a 30 m cell gets L1 class c iff the L1 fraction of c is >= min_purity (configs/labels.yaml silver_consensus: 0.78) in EVERY source
  (ESA WorldCover 2020, 2021; Esri annual LULC 2020, 2021), fractions from the 10 m products on the nested 10 m lattice (G30 refined x3).

Only L1 is built (arm A uses L1; L2 is not part of P4-C1@v2). Cells outside the district are 0. Never uses gold, T1, model output or this
project's composites. Arm restrictions (training-eligible, >= 2 km from tuning blocks) are applied by the confirmatory runner, not here."""
from __future__ import annotations
import hashlib, json
from pathlib import Path
import numpy as np, rasterio
from rasterio.enums import Resampling
from .. import config
from ..grid import Grid
from ..io import write_cog
from ..provenance import utcnow

def silver_rule(fracs: list[np.ndarray], min_purity: float) -> np.ndarray:
    """fracs: one (6, h, w) L1-fraction array per source (NaN = no data). Identical to silver.build_silver L1: min over sources >= P."""
    fr = np.stack(fracs); mn = np.min(np.where(np.isnan(fr), -1, fr), axis=0); l1 = np.zeros(fr.shape[2:], np.uint8)
    for ci in range(6): l1[mn[ci] >= min_purity] = ci + 1
    return l1

def strip_grid(grid: Grid, r0: int, r1: int) -> Grid:
    return Grid(f"{grid.id}_rows{r0}_{r1}", grid.crs, grid.res, grid.x0, grid.y1 - r0 * grid.res, grid.width, r1 - r0, grid.corner_offset)

def fetch_fractions(sub: Grid, sources: list[str]) -> tuple[list[np.ndarray], dict]:
    """L1 fractions of each source on `sub` (network: Planetary Computer, anonymous; same calls as sources.landcover_fractions)."""
    from ..acquisition.stac import client
    from .sources import _bbox_ll, _warp, l1_fractions
    cw = config.load("labels")["crosswalks"]; fine = sub.refine(3, sub.id + "_10m"); bbox = _bbox_ll(sub); cat = client(); items = {}
    for coll, pre in (("esa-worldcover", "esa_worldcover"), ("io-lulc-annual-v02", "esri_lulc")):
        for it in cat.search(collections=[coll], bbox=bbox).items():
            yr = str(it.properties.get("start_datetime", it.datetime))[:4]; name = f"{pre}_{yr}"
            if name in sources: items.setdefault(name, []).append(it)
    out, used = [], {}
    for name in sources:
        its = sorted(items.get(name, []), key=lambda i: i.id); cls = np.zeros(fine.shape, np.uint8)
        for it in its:
            a = _warp(it.assets["map" if "worldcover" in name else "data"].href, fine, Resampling.nearest, dst_nodata=0); cls = np.where(a > 0, a, cls)
        out.append(l1_fractions(cls, cw["esa_worldcover" if "worldcover" in name else "esri_lulc"])); used[name] = [i.id for i in its]
    return out, used

def build(grid: Grid, district: np.ndarray, out_dir: Path, strip: int = 512, fetch=fetch_fractions, log=print) -> dict:
    sc = config.load("labels")["silver_consensus"]; P = float(sc["min_purity"]); S = list(sc["sources"]); out_dir = Path(out_dir); out_dir.mkdir(parents=True, exist_ok=True)
    l1 = np.zeros(grid.shape, np.uint8); items = {}
    for r0 in range(0, grid.height, strip):
        r1 = min(grid.height, r0 + strip); fr, used = fetch(strip_grid(grid, r0, r1), S)
        l1[r0:r1] = silver_rule(fr, P); items[f"{r0}-{r1}"] = used; log(f"silver rows {r0}-{r1}: {int((l1[r0:r1] > 0).sum())} labelled")
    l1[~district] = 0
    write_cog(out_dir / "silver_l1.tif", l1, grid, nodata=None, dtype="uint8", descriptions=["silver_l1_0_unlabelled"], overview_resampling="nearest")
    names = config.load("labels")["level1_classes"]
    meta = {"product": "district silver L1 (P4-C1@v2 arm A)", "grid": grid.to_dict(), "sources": S, "min_purity": P, "rule": "unanimous (min over sources >= min_purity)",
            "strip_rows": strip, "items_per_strip": items, "district_cells": int(district.sum()), "labelled_cells": int((l1 > 0).sum()),
            "labelled_fraction_of_district": float((l1[district] > 0).mean()), "l1_counts": {names[i]: int((l1 == i).sum()) for i in range(1, 7)},
            "files": {"silver_l1.tif": hashlib.sha256((out_dir / "silver_l1.tif").read_bytes()).hexdigest()},
            "code_sha256": {p: hashlib.sha256(config.path(p).read_bytes()).hexdigest() for p in ("src/pune_eo/labels/district_silver.py", "src/pune_eo/labels/sources.py", "configs/labels.yaml")},
            "uses_gold_or_T1": False, "created_utc": utcnow()}
    (out_dir / "metadata.json").write_text(json.dumps(meta, indent=1)); return meta

AGREEMENT_MIN = 0.99

def validate(out_dir: Path, grid: Grid, district: np.ndarray, windows: dict | None = None, fetch=None) -> dict:
    """windows: {name: (Grid, path to the window silver_l1.tif)}.
    (1) code/rule identity: the district code run on each WINDOW's own extent (fetch) must reproduce that window's silver_l1 exactly;
    (2) agreement of the district product with the window silver on the overlap >= AGREEMENT_MIN. Exact equality is not expected: GDAL's
        approximate warp transformer (error threshold 0.125 px) picks nearest source pixels slightly differently for different output extents
        (row strips vs window extents); shown in Phase 7 (0.9965-0.9993 identical cells, 1.0 when the window extent is reused)."""
    out_dir = Path(out_dir); res = {"path": str(out_dir), "checks": {}}
    def chk(n, ok, **d): res["checks"][n] = {"ok": bool(ok), **d}
    f, m = out_dir / "silver_l1.tif", out_dir / "metadata.json"
    if not (f.exists() and m.exists()):
        chk("files_present", False); res["ok"] = False; return res
    chk("files_present", True); meta = json.loads(m.read_text()); sc = config.load("labels")["silver_consensus"]
    chk("file_hash_matches_metadata", hashlib.sha256(f.read_bytes()).hexdigest() == meta["files"]["silver_l1.tif"])
    with rasterio.open(f) as s:
        a = s.read(1); chk("grid", s.crs.to_string() == grid.crs and tuple(s.transform)[:6] == tuple(grid.transform)[:6] and s.shape == grid.shape and s.dtypes[0] == "uint8")
    chk("values_in_0_6", bool(np.isin(np.unique(a), np.arange(7)).all()), values=np.unique(a).tolist())
    chk("no_labels_outside_district", not (a[~district] > 0).any())
    chk("rule_and_sources_equal_config", meta["sources"] == list(sc["sources"]) and meta["min_purity"] == float(sc["min_purity"]) and meta["uses_gold_or_T1"] is False)
    lab = float((a[district] > 0).mean()); chk("labelled_share_positive", lab > 0, labelled_share=lab)
    eq = {}
    for name, (wg, wp) in (windows or {}).items():
        c0 = int(round((wg.x0 - grid.x0) / grid.res)); r0 = int(round((grid.y1 - wg.y1) / grid.res))
        with rasterio.open(wp) as s: w = s.read(1)
        rr0, cc0 = max(r0, 0), max(c0, 0); rr1, cc1 = min(r0 + wg.height, grid.height), min(c0 + wg.width, grid.width)
        D = a[rr0:rr1, cc0:cc1]; Wn = w[rr0 - r0:rr1 - r0, cc0 - c0:cc1 - c0]; ins = district[rr0:rr1, cc0:cc1]
        eq[name] = {"n_cells": int(ins.sum()), "identical_share": float((D[ins] == Wn[ins]).mean()) if ins.any() else None}
    if windows:
        chk(f"agreement_with_window_silver_on_overlap_ge_{AGREEMENT_MIN}", all(v["identical_share"] >= AGREEMENT_MIN for v in eq.values() if v["n_cells"]), per_window=eq)
        if fetch is not None:
            sc_ = config.load("labels")["silver_consensus"]; rep = {}
            for name, (wg, wp) in windows.items():
                with rasterio.open(wp) as s: w = s.read(1)
                rep[name] = float((silver_rule(fetch(wg, list(sc_["sources"]))[0], float(sc_["min_purity"])) == w).mean())
            chk("window_extent_reproduces_window_silver_exactly", all(v == 1.0 for v in rep.values()), identical_share=rep)
        else: chk("window_extent_reproduces_window_silver_exactly", False, error="not checked (no fetch function)")
    res["meta"] = {k: meta[k] for k in ("labelled_cells", "labelled_fraction_of_district", "l1_counts", "created_utc")}
    res["sha256"] = meta["files"]["silver_l1.tif"]; res["ok"] = all(v["ok"] for v in res["checks"].values()); return res
