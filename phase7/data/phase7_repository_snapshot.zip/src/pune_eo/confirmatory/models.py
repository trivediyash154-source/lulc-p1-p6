"""Registered models (addendum-1 'models' + runner specification C1-4, C1-5): Random Forest on B4t and the P3-F1 TempCNN on the B3 5-year sequence."""
from __future__ import annotations
import hashlib, io, pickle
import numpy as np, pandas as pd
from ..historical_reconstruction import features as F
from ..temporal_models import window_sequence
from ..agriculture import timeseries as TS

RF_PARAMS = dict(n_estimators=300, min_samples_leaf=2, max_features="sqrt", class_weight=None)
TEMPCNN = dict(epochs=40, patience=6, lr=1e-3, bs=512)

def design_matrix(H: dict, rows: pd.DataFrame, cell_index: dict, kind: str, feature_set: str = "B4t") -> np.ndarray:
    """rows: (row, col, epoch); features of each row's epoch. kind 'rf' -> features.build(feature_set); 'tempcnn' -> window_sequence (5 x 16)."""
    idx = np.array([cell_index[(r, c)] for r, c in zip(rows.row.values, rows.col.values)]); out = [None] * len(rows); ep = rows.epoch.values
    for e in np.unique(ep):
        k = np.flatnonzero(ep == e)
        X = F.build(H, feature_set, int(e), idx[k])[0] if kind == "rf" else window_sequence(H, int(e), idx[k], half=2)
        for j, i in enumerate(k): out[i] = X[j]
    return np.stack(out).astype(np.float32)

def prep(X, stats=None):
    """P3-F1 input: standardise with training statistics, missing -> 0, two observation-mask channels (TS.train reads the last two)."""
    if stats is None: stats = (np.nanmean(X, axis=(0, 1)), np.nanstd(X, axis=(0, 1)) + 1e-6)
    Z = (X - stats[0]) / stats[1]; ob = np.isfinite(Z).all(-1, keepdims=True); Z = np.where(np.isfinite(Z), Z, 0.0)
    return np.concatenate([Z, ob, ob], -1).astype(np.float32), stats

def fit_rf(X, y, seed: int, n_jobs: int = -1):
    from sklearn.ensemble import RandomForestClassifier
    return RandomForestClassifier(**RF_PARAMS, n_jobs=n_jobs, random_state=seed).fit(X, y)

def proba_rf(m, X) -> np.ndarray:
    """(n, 4) probabilities over the legend classes 1-4 (absent training classes -> 0)."""
    P = np.zeros((len(X), 4)); p = m.predict_proba(X)
    for j, c in enumerate(m.classes_): P[:, int(c) - 1] = p[:, j]
    return P

def fit_tempcnn(Xtr, ytr, Xes, yes, seed: int, threads: int = 2):
    A, st = prep(Xtr); B, _ = prep(Xes, st)
    net, hist = TS.train("tempcnn", A, np.asarray(ytr) - 1, B, np.asarray(yes) - 1, 4, seed=seed, threads=threads, **TEMPCNN); return (net, st), hist

def proba_tempcnn(m, X) -> np.ndarray:
    net, st = m; return TS.predict_proba(net, prep(X, st)[0])

def model_sha256(m) -> str:
    if isinstance(m, tuple):
        import torch
        b = io.BytesIO(); torch.save({k: v.cpu() for k, v in m[0].state_dict().items()}, b); return hashlib.sha256(b.getvalue() + pickle.dumps(m[1])).hexdigest()
    return hashlib.sha256(pickle.dumps(m)).hexdigest()
