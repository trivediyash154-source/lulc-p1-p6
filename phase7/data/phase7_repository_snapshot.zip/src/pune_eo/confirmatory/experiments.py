"""P4-C1@v2 and P4-C2@v2 pipelines (runner specification C1-1..C1-9, C2-1..C2-3; common rules G-1..G-5).
Order inside C1 is fixed so that no gold label can influence a choice: training rows -> features -> models -> predictions (gold POINTS only,
no labels) -> tuning selection written and hashed -> only then gold labels are read and scored."""
from __future__ import annotations
import hashlib, json
from pathlib import Path
import numpy as np, pandas as pd
from .. import config
from ..provenance import utcnow
from . import analysis as AN, data as D, models as M

ARMS = ["A", "B", "C", "D", "E"]; KIND_ORDER = {"rf": 0, "tempcnn": 1}; CONTRASTS = ["B", "C", "D", "E"]
LEGEND_NAMES = [k for k, v in AN.CODES.items() if v in AN.LEGEND]

def _sha(p: Path) -> str: return hashlib.sha256(Path(p).read_bytes()).hexdigest()

def _save(df: pd.DataFrame, p: Path, hashes: dict):
    p.parent.mkdir(parents=True, exist_ok=True); df.to_parquet(p, index=False); hashes[str(p.name if p.parent.name == "" else p.relative_to(p.parents[1]))] = _sha(p)

def _fit_predict(H, ci, R: pd.DataFrame, kind: str, seed: int, targets: dict, threads: int, feature_set="B4t"):
    """train one model on rows R; return (model sha, {target: predicted codes}, history)."""
    y = R.label.values.astype(int); hist = None
    if kind == "rf":
        m = M.fit_rf(M.design_matrix(H, R, ci, "rf", feature_set), y, seed, n_jobs=threads); f = lambda T: M.proba_rf(m, M.design_matrix(H, T, ci, "rf", feature_set))
    else:
        X = M.design_matrix(H, R, ci, "tempcnn"); es = D.es_holdout(R.block.values)
        if es.sum() == 0 or (~es).sum() == 0: raise RuntimeError("early-stopping split empty (C1-5)")
        m, hist = M.fit_tempcnn(X[~es], y[~es], X[es], y[es], seed, threads); f = lambda T: M.proba_tempcnn(m, M.design_matrix(H, T, ci, "tempcnn"))
    preds = {k: f(T).argmax(1) + 1 for k, T in targets.items()}
    return M.model_sha256(m), preds, hist

def select(tuning_scores: dict) -> dict:
    """C1-6: highest seed-mean tuning macro-F1; ties (|diff| < 0.005) -> RF before TempCNN, then arm order A..E."""
    mean = {k: float(np.mean(v)) for k, v in tuning_scores.items()}; best = max(mean.values())
    cands = [k for k, v in mean.items() if best - v < 0.005]; arm, kind = min(cands, key=lambda k: (KIND_ORDER[k[1]], ARMS.index(k[0])))
    return {"arm": arm, "model": kind, "tuning_macro_f1_seed_mean": {f"{a}/{k}": v for (a, k), v in mean.items()}, "tied_within_0.005": [f"{a}/{k}" for a, k in cands],
            "rule": "C1-6: T1 v2 tuning split (2020+2000, legend classes), unweighted macro-F1, seed mean; ties -> RF, then arm order", "gold_consulted": False}

def run_c1(inp: D.Inputs, grid: dict, out: Path, seeds: list[int], n_boot: int = AN.N_BOOT, kinds=("rf", "tempcnn"), threads: int = 2, log=print) -> dict:
    out = Path(out); hashes = {}
    t1 = D.read_t1(inp); tun = t1[(t1.split == "tuning") & t1.epoch.isin(D.T1_EPOCHS) & t1.reference_label.isin(LEGEND_NAMES)].reset_index(drop=True)
    P = D.gold_points(inp)
    rows = {}
    for s in seeds:
        A = D.Arms(inp, grid, s, t1)
        for a in ARMS: rows[(a, s)] = A.arm(a)
        rows[("A_eq", s)] = A.equal_size_control(len(rows[("D", s)]))
        for a in ARMS + ["A_eq"]: _save(rows[(a, s)], out / "training_rows" / f"{a}_seed{s}.parquet", hashes)
        log(f"seed {s}: rows " + ", ".join(f"{a}={len(rows[(a, s)])}" for a in ARMS + ["A_eq"]))
    leak = D.leakage_check(pd.concat(rows.values(), ignore_index=True), P, t1[t1.split == "tuning"], inp, grid); log(f"leakage check passed: {leak}")   # ALL tuning cells
    cells = pd.concat([r[["row", "col"]] for r in rows.values()] + [P[["row", "col"]], tun[["row", "col"]]]).drop_duplicates().reset_index(drop=True)
    H = D.point_H(inp.cube, cells.row.values, cells.col.values); ci = {(r, c): i for i, (r, c) in enumerate(zip(cells.row.values, cells.col.values))}
    targets = {f"gold_{e}": pd.DataFrame({"row": P.row.values, "col": P.col.values, "epoch": e}) for e in D.GOLD_EPOCHS} | {"tuning": tun[["row", "col", "epoch"]]}
    pred, model_sha, hist = {}, {}, {}
    for (a, s), R in rows.items():
        for k in kinds:
            tg = targets if a != "A_eq" else {t: v for t, v in targets.items() if t != "tuning"}
            model_sha[f"{a}/{k}/{s}"], pred[(a, k, s)], hist[f"{a}/{k}/{s}"] = _fit_predict(H, ci, R, k, s, tg, threads)
        log(f"trained {a} seed {s}")
    pg = pd.DataFrame([{"arm": a, "model": k, "seed": s, "target": t, "anon_id": (P.anon_id.values if t != "tuning" else tun.anon_id.values)[i], "pred": int(v)}
                       for (a, k, s), d in pred.items() for t, arr in d.items() for i, v in enumerate(arr)])
    _save(pg, out / "predictions" / "predictions.parquet", hashes)
    # ---- tuning selection (frozen before any gold label is read)
    ytun = tun.reference_label.map(AN.CODES).values.astype(int)
    scores = {(a, k): [AN.unweighted_macro_f1_legend(ytun, pred[(a, k, s)]["tuning"]) for s in seeds] for a in ARMS for k in kinds}
    sel = select(scores) | {"decided_utc": utcnow(), "predictions_sha256": hashes["predictions/predictions.parquet"]}
    (out / "selection.json").write_text(json.dumps(sel, indent=1)); hashes["selection.json"] = _sha(out / "selection.json"); log(f"selection {sel['arm']}/{sel['model']}")
    # ---- gold evaluation
    metrics, tests, secondary = [], [], []
    npop = dict(zip(P.stratum, P.stratum_area_cells))
    for e in D.GOLD_EPOCHS:
        G = D.gold_labels(inp, e)[["anon_id", "y"]].merge(P.reset_index().rename(columns={"index": "pi"}), on="anon_id")      # design (stratum, block) from the key
        pi, y = G.pi.values, G.y.values; st, bl = G.stratum.values, G.block.values; testable = len(G) >= AN.MIN_ACCURACY_SET
        for (a, k, s), d in pred.items():
            mv = AN.metric_values(y, d[f"gold_{e}"][pi], st, npop); metrics.append({"arm": a, "model": k, "seed": s, "epoch": e, "n": int(len(G)), **mv})
        for k in kinds:
            ref = np.stack([pred[("A", k, s)][f"gold_{e}"][pi] for s in seeds])
            for c in CONTRASTS:
                trt = np.stack([pred[(c, k, s)][f"gold_{e}"][pi] for s in seeds])
                for mt in ("oa", "macro_f1"):
                    t = AN.paired_test(trt, ref, y, st, bl, npop, mt, n_boot) if testable else AN.not_testable(mt, len(G))
                    tests.append({"contrast": f"{c}-A", "model": k, "epoch": e, **t})
            dd = np.stack([pred[("D", k, s)][f"gold_{e}"][pi] for s in seeds]); aq = np.stack([pred[("A_eq", k, s)][f"gold_{e}"][pi] for s in seeds])
            for mt in ("oa", "macro_f1"):
                secondary.append({"contrast": "D-A_eq (equal size)", "model": k, "epoch": e, **(AN.paired_test(dd, aq, y, st, bl, npop, mt, n_boot) if testable else AN.not_testable(mt, len(G)))})
    assert len(tests) == 4 * 4 * 2 * len(kinds)
    AN.apply_bh(tests)
    for t in tests: t["decision"] = AN.decide(t, "two-sided", len(seeds))
    agg = AN.c1_outcome(tests)
    pd.DataFrame(metrics).to_csv(out / "gold_metrics.csv", index=False); hashes["gold_metrics.csv"] = _sha(out / "gold_metrics.csv")
    res = {"selection": sel, "leakage_check": leak, "tests": tests, "secondary_equal_size": secondary, "aggregation": agg, "outcome": agg["outcome"], "model_sha256": model_sha,
           "tempcnn_val_loss": {k: v for k, v in hist.items() if v is not None}, "n_seeds": len(seeds), "seeds": seeds, "n_boot": n_boot,
           "family": "label_quality", "bh_scope": "64 tests of P4-C1@v2 (the whole family)", "output_sha256": hashes}
    (out / "results.json").write_text(json.dumps(res, indent=1, default=float)); return res

def run_c2(inp_c: D.Inputs, inp_t: D.Inputs, grid: dict, out: Path, seeds: list[int], selection: dict, envelope: dict, district: np.ndarray,
           n_boot: int = AN.N_BOOT, threads: int = 2, share_step: int = 10, log=print) -> dict:
    """C2-1: identical rows/seeds/hyperparameters; only the feature cube differs. Decisive: gold OA 1990 and 2000 (C2-2)."""
    out = Path(out); hashes = {}; arm, kind = selection["arm"], selection["model"]; t1 = D.read_t1(inp_c) if arm in ("D", "E") else None
    P = D.gold_points(inp_c); rows = {}
    for s in seeds:
        rows[s] = D.Arms(inp_c, grid, s, t1).arm(arm); _save(rows[s], out / "training_rows" / f"{arm}_seed{s}.parquet", hashes)   # arm-B ranges from the standard cube (C2-1)
    tun_ = D.read_t1(inp_c).query("split == 'tuning'") if inp_c.t1_labels.exists() else pd.DataFrame({"row": [], "col": []})
    leak = D.leakage_check(pd.concat(rows.values(), ignore_index=True), P, tun_, inp_c, grid)
    rr, cc = np.nonzero(district[::share_step, ::share_step]); sys_cells = pd.DataFrame({"row": rr * share_step, "col": cc * share_step})
    cells = pd.concat([r[["row", "col"]] for r in rows.values()] + [P[["row", "col"]], sys_cells]).drop_duplicates().reset_index(drop=True)
    ci = {(r, c): i for i, (r, c) in enumerate(zip(cells.row.values, cells.col.values))}
    targets = {f"gold_{e}": pd.DataFrame({"row": P.row.values, "col": P.col.values, "epoch": e}) for e in (1990, 2000)} | \
              {f"share_{e}": sys_cells.assign(epoch=e) for e in (1990, 2000)}
    pred, model_sha = {}, {}
    for arm_name, inp in (("comparator", inp_c), ("treatment", inp_t)):
        H = D.point_H(inp.cube, cells.row.values, cells.col.values)
        for s in seeds:
            model_sha[f"{arm_name}/{s}"], pred[(arm_name, s)], _ = _fit_predict(H, ci, rows[s], kind, s, targets, threads)
        log(f"C2 {arm_name} trained")
    npop = dict(zip(P.stratum, P.stratum_area_cells)); tests, reported = [], {}
    for e in (1990, 2000):
        G = D.gold_labels(inp_c, e)[["anon_id", "y"]].merge(P.reset_index().rename(columns={"index": "pi"}), on="anon_id"); pi, y = G.pi.values, G.y.values
        T_ = np.stack([pred[("treatment", s)][f"gold_{e}"][pi] for s in seeds]); C_ = np.stack([pred[("comparator", s)][f"gold_{e}"][pi] for s in seeds])
        t = AN.paired_test(T_, C_, y, G.stratum.values, G.block.values, npop, "oa", n_boot) if len(G) >= AN.MIN_ACCURACY_SET else AN.not_testable("oa", len(G))
        tests.append({"contrast": "treatment-comparator", "epoch": e, **t})
        ua = {}
        for nm, X in (("treatment", T_), ("comparator", C_)):
            v = []
            for s in range(len(seeds)):
                Mw = AN.weighted_confusion(y, X[s], AN.design_weights(G.stratum.values, npop)); v.append(AN.EM.per_class(Mw, AN.ALL)[1]["precision_users"])
            ua[nm] = float(np.nanmean(v))
        shares = {nm: float(np.mean([(pred[(nm, s)][f"share_{e}"] == 1).mean() for s in seeds])) for nm in ("treatment", "comparator")}
        env = envelope["epochs"][str(e)]["district"]; prods = env["shares"]; noglc = {k: v for k, v in prods.items() if "GLC" not in k}
        env2 = [max(0.0, min(noglc.values()) - 0.02), max(noglc.values()) + 0.02]
        reported[str(e)] = {"built_users_accuracy_seed_mean": ua, "district_built_share_systematic_sample": shares, "envelope_all_products": env["envelope_with_tolerance"],
                            "envelope_without_GLC_FCS30D": env2, "within_envelope": {nm: env["envelope_with_tolerance"][0] <= v <= env["envelope_with_tolerance"][1] for nm, v in shares.items()}}
    res = {"selection": selection, "leakage_check": leak, "tests": tests, "reported_not_decisive": reported, "model_sha256": model_sha, "seeds": seeds, "n_boot": n_boot, "family": "historical",
           "bh_scope": "family 'historical' (P4-C2@v2 + P4-C3@v2): BH and the final outcome are computed by finalise_family() after P4-C3@v2 (G-1)",
           "share_sample": f"every {share_step}th row and column inside the district ({len(sys_cells)} cells)", "output_sha256": hashes, "outcome": "PENDING_FAMILY"}
    (out / "results.json").write_text(json.dumps(res, indent=1, default=float)); return res
