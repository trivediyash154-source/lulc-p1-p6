"""Operational specification of each record = the record + its ADOPTED addenda/errata, each countersigned by the researcher.
Phase-6 decisions (D1, D2) are countersigned in phase6_countersignature.json; Phase-7 runner specifications in phase7_countersignature.json."""
from __future__ import annotations
import hashlib, json
from pathlib import Path
from .. import config
from ..evaluation4 import protocol as P4

ADD = "experiments/registry4/addenda"
REQUIRED = {
    "P4-C1@v2": [("P4-C1_at_v2_addendum_1.json", ("phase6", "D1", "addendum_sha256")), ("P4-C1_at_v2_addendum_1_erratum_1.json", ("phase6", "D1", "erratum_sha256")),
                 ("P4-C1_at_v2_addendum_2.json", ("phase7", "P4-C1", "adopted_addendum_sha256"))],
    "P4-C2@v2": [("P4-C2_at_v2_addendum_1.json", ("phase6", "D2", "addendum_sha256")), ("P4-C2_at_v2_addendum_1_erratum_1.json", ("phase6", "D2", "erratum_sha256")),
                 ("P4-C2_at_v2_addendum_2.json", ("phase7", "P4-C2", "adopted_addendum_sha256"))],
    "P4-C3@v2": [("P4-C3_at_v2_addendum_1.json", ("phase7", "P4-C3", "adopted_addendum_sha256"))],
    "P4-C4@v2": [("P4-C4_at_v2_addendum_1.json", ("phase7", "P4-C4", "adopted_addendum_sha256"))],
    "P4-C5@v2": [("P4-C5_at_v2_addendum_1.json", ("phase7", "P4-C5", "adopted_addendum_sha256"))],
    "P4-C6@v2": [("P4-C6_at_v2_addendum_1.json", ("phase7", "P4-C6", "adopted_addendum_sha256"))]}
CS = {"phase6": f"{ADD}/phase6_countersignature.json", "phase7": f"{ADD}/phase7_countersignature.json"}

def _sha(p: Path) -> str | None: return hashlib.sha256(p.read_bytes()).hexdigest() if p.exists() else None
def _json(p: Path): return json.loads(p.read_text()) if p.exists() else None

def status(eid: str, root: Path | None = None) -> dict:
    root = Path(root or config.ROOT); rec = P4.load(eid) or {}; ptr = {a["path"]: a["sha256"] for a in rec.get("addenda", [])}
    cs = {k: _json(root / v) or {} for k, v in CS.items()}; missing, adopted = [], []
    for fname, (which, dec, field) in REQUIRED[eid]:
        rel = f"{ADD}/{fname}"; p = root / rel; d = _json(p); h = _sha(p)
        if d is None: missing.append(f"{fname}: not adopted (only a _PROPOSED file or nothing exists)"); continue
        if not str(d.get("status", "")).startswith("ADOPTED"): missing.append(f"{fname}: status {d.get('status')!r} is not ADOPTED"); continue
        sig = cs[which]; entry = (sig.get("decisions") or {}).get(dec) or {}
        if not (str(sig.get("researcher_name", "")).strip() and sig.get("signed_utc")): missing.append(f"{fname}: no researcher countersignature file {CS[which]}"); continue
        if entry.get(field) != h or entry.get("verdict_accepted", entry.get("accepted")) is not True: missing.append(f"{fname}: countersignature missing or SHA-256 differs ({CS[which]}:{dec})"); continue
        if ptr.get(rel) != h: missing.append(f"{fname}: no matching append-only pointer in the {eid} record"); continue
        adopted.append({"path": rel, "sha256": h, "countersigned_utc": sig.get("signed_utc")})
    return {"experiment_id": eid, "complete": not missing, "missing": missing, "adopted": adopted}
