"""Fail-closed preconditions of a confirmatory run. `preflight(eid)` collects EVERY failed check and raises Refusal; on success it returns the
provenance proof that goes into the run manifest. `verify_c2_transform()` proves P4-C2@v2 input -> c2_tm_pif_v1 -> treatment feature cube."""
from __future__ import annotations
import glob, hashlib, importlib.util, json
from pathlib import Path
import yaml
from .. import config
from ..evaluation4 import protocol as P4
from . import ORDER, IMPLEMENTED, Refusal, spec

C2_TRANSFORM = "c2_tm_pif_v1"; C2_SHA = "782eaef3e95c9dbe4b79868d936fd1e96ff1aa681d93ad609b5463ddd119db47"; COMPARATOR_TRANSFORM = "local_pune_g30_v2"
COMPARATOR_SHA = "d9bb983437ac60dcca2626d8efe2fbb01f05b38f10739dbdaad029a1d0c5596e"         # results/harmonization/local_pune_g30_v2.yaml (L5/L4 identity)

def spec_sha(name: str, path) -> str | None:
    """SHA-256 of the transform spec exactly as harmonization.landsat.transform_spec builds it from the file ({'name': ..., **yaml});
    the cube driver writes the same digest of the coefficients it APPLIED into every product (processing.transform_spec_sha256)."""
    p = config.path(path) if not Path(path).is_absolute() else Path(path)
    return hashlib.sha256(json.dumps({"name": name, **yaml.safe_load(p.read_text())}, sort_keys=True, default=str).encode()).hexdigest() if p.exists() else None
C2TM_YEARS = [1990, 1991, 1992, 1998, 1999, 2000, 2001, 2008, 2009, 2010, 2011]; PERIODS = ("annual", "seasonal/dry", "seasonal/post_monsoon", "seasonal/wet")
REGISTRATION = "experiments/registry4/addenda/phase7_runner_registration.json"
RUN_ROOT = "results/phase7/runs"
CUBE, CUBE_C2 = "data/features/cube/pune_G30.zarr", "data/features/cube/pune_G30_landsat_c2tm.zarr"
FCV, FCV_C2 = "results/phase6/feature_cube_validation.json", "results/phase6/feature_cube_validation_pune_G30_landsat_c2tm.json"

def sha(p) -> str | None:
    p = config.path(p) if not Path(p).is_absolute() else Path(p); return hashlib.sha256(p.read_bytes()).hexdigest() if p.exists() else None
def J(p):
    p = config.path(p); return json.loads(p.read_text()) if p.exists() else None

IMPORTED = ["scripts/phase7_run_confirmatory.py", "scripts/phase5_prerun_checklists.py", "src/pune_eo/historical_reconstruction/features.py", "src/pune_eo/temporal_models/__init__.py",
            "src/pune_eo/agriculture/timeseries.py", "src/pune_eo/change_detection/changepoints.py", "src/pune_eo/feature_engineering/cube.py", "src/pune_eo/harmonization/landsat.py"]

def implementation_files() -> list[str]:
    """runner package + every repository module it imports for features, models, change points and checks (protocol modules are pinned separately)."""
    return sorted(str(Path(p).relative_to(config.ROOT)) for p in glob.glob(str(config.path("src/pune_eo/confirmatory/*.py")))) + IMPORTED

def implementation_hashes() -> dict: return {p: sha(p) for p in implementation_files()}

def _checklist_module():
    s = importlib.util.spec_from_file_location("prerun_checklists", config.path("scripts/phase5_prerun_checklists.py")); m = importlib.util.module_from_spec(s); s.loader.exec_module(m); return m

def first_manifest(tag: str) -> dict | None:
    p = config.path(f"results/phase7/manifests/{tag}/manifest_v1.json"); return json.loads(p.read_text()) if p.exists() else None

def input_checks(eid: str) -> tuple[dict, dict]:
    """dry-run schema checks of every input the pipeline reads (so that a malformed input cannot consume the single execution) + input hashes."""
    import rasterio, pandas as pd
    F, H = {}, {}
    req = {"district_mask": "data/products_ext/district/district_mask_30m.tif", "train_population": "data/labels/training/phase6_T1v2/sampling_design/train_eligible_T1_30m.tif",
           "glc_fcs30d": "data/products_ext/glc_fcs30d/glc_fcs30d_district_30m.tif", "gold_key": "data/labels/gold/phase4/_key/phase4_gold_key.csv",
           "gold_design": "data/labels/gold/phase4/sampling_design/design.json", "envelope": "results/phase5/benchmark/g5_built_envelope_frozen.json"}
    for k, p in req.items():
        H[k] = sha(p)
        if H[k] is None: F[f"input_{k}"] = f"{p} missing"
    if H.get("glc_fcs30d"):
        with rasterio.open(config.path(req["glc_fcs30d"])) as s_:
            if not {"2020", "2021"} <= {str(d) for d in s_.descriptions}: F["input_glc_fcs30d"] = "band descriptions 2020/2021 missing"
    if H.get("gold_key"):
        miss = {"anon_id", "row", "col", "stratum", "block", "region", "stratum_area_cells", "x_utm", "y_utm"} - set(pd.read_csv(config.path(req["gold_key"]), nrows=0).columns)
        if miss: F["input_gold_key"] = f"columns missing {sorted(miss)}"
    for tag, p in (("gold_labels", "data/labels/gold/phase4/ingested/gold_reference_labels.csv"), ("T1_labels", "data/labels/training/phase6_T1v2/ingested/gold_reference_labels.csv")):
        if config.path(p).exists():
            H[tag] = sha(p); miss = {"anon_id", "epoch", "reference_label", "in_accuracy_set"} | ({"row", "col", "split"} if tag == "T1_labels" else set())
            miss -= set(pd.read_csv(config.path(p), nrows=0).columns)
            if miss: F[f"input_{tag}"] = f"columns missing {sorted(miss)}"
    if eid == "P4-C2@v2" and H.get("envelope"):
        env = J(req["envelope"]) or {}
        if not all(str(e) in env.get("epochs", {}) and "district" in env["epochs"][str(e)] for e in (1990, 2000)): F["input_envelope"] = "1990/2000 district envelope missing"
    return F, H

def label_manifest(tag: str) -> dict | None:
    vs = sorted(glob.glob(str(config.path(f"results/phase7/manifests/{tag}/manifest_v*.json"))), key=lambda p: int(Path(p).stem.split("_v")[1]))
    return json.loads(Path(vs[-1]).read_text()) | {"_file": str(Path(vs[-1]).relative_to(config.ROOT))} if vs else None

def _bound_cube(cube: str, report: str, family: str) -> tuple[bool, str, dict]:
    c = config.path(cube); r = J(report) or {}; side = c.with_suffix(".json")
    ok = c.exists() and r.get("ok") is True and r.get("path") == str(c.resolve()) and r.get("family") == family and side.exists() and r.get("sidecar_sha256") == sha(side)
    return ok, ("validated, report bound to cube" if ok else f"{cube}: absent / not validated / report not bound"), {"cube": cube, "sidecar_sha256": sha(side) if side.exists() else None, "validation": report}

def verify_c2_transform() -> tuple[dict, dict]:
    """returns (failed, proof). Every link of the chain must hold; any failure -> P4-C2@v2 refused."""
    F, P = {}, {}
    T = config.path(f"results/harmonization/{C2_TRANSFORM}.yaml"); A2 = "experiments/registry4/addenda/P4-C2_at_v2_addendum_1.json"
    if sha(T) != C2_SHA: F["transform_file"] = f"{T.name} SHA {str(sha(T))[:12]} != pinned {C2_SHA[:12]}"
    sidecar = config.path(f"results/harmonization/{C2_TRANSFORM}.sha256")
    if not sidecar.exists() or sidecar.read_text().split()[0] != C2_SHA: F["transform_sha256_file"] = "missing or differs"
    rep = J("results/phase6/d2/pif_fit_report.json") or {}
    if rep.get("transform_sha256") != C2_SHA or rep.get("addendum_sha256") != sha(A2): F["fit_report"] = "fit report does not bind the pinned transform to the registered specification"
    h = yaml.safe_load(open(config.path("configs/landsat.yaml")))["harmonization"]
    if C2_TRANSFORM in h.get("transforms", {}): F["config_shadowing"] = "configs/landsat.yaml defines a transform with the same name - it would shadow the frozen file"   # local_pune_g30_v2 is always read from its file (transform_spec special case)
    CMPF = config.path(f"results/harmonization/{COMPARATOR_TRANSFORM}.yaml")
    if sha(CMPF) != COMPARATOR_SHA: F["comparator_transform_file"] = f"{CMPF.name} SHA {str(sha(CMPF))[:12]} != pinned {COMPARATOR_SHA[:12]}"
    exp_t, exp_c = spec_sha(C2_TRANSFORM, T), spec_sha(COMPARATOR_TRANSFORM, CMPF)
    if T.exists():
        spec_ = yaml.safe_load(T.read_text()); cmp_ = yaml.safe_load(config.path(f"results/harmonization/{COMPARATOR_TRANSFORM}.yaml").read_text())
        coef = rep.get("coefficients_rma", {})
        tm = {pl: spec_.get("per_platform", {}).get(pl) for pl in ("landsat-5", "landsat-4")}
        P["tm_coefficients_in_file"] = tm
        same_l7 = all(spec_.get("per_platform", {}).get(pl) == cmp_.get("per_platform", {}).get(pl) for pl in ("landsat-7", "landsat-8", "landsat-9"))
        if not same_l7: F["single_factor"] = "landsat-7/8/9 coefficients differ from the comparator transform"
        if any(pl in cmp_.get("per_platform", {}) for pl in ("landsat-5", "landsat-4")): F["comparator_identity"] = "comparator must apply identity to landsat-5/4 (record: 'L5 identity')"
        if not all(spec_.get("per_platform", {}).get(pl) for pl in ("landsat-5", "landsat-4")): F["treatment_tm"] = "treatment file lacks landsat-5/4 coefficients"
        mism = []
        for pl in ("landsat-5", "landsat-4"):
            e = tm.get(pl) or {}
            for b, c in coef.items():
                if abs(e.get("slope", {}).get(b, 9e9) - c["slope"]) > 1e-12 or abs(e.get("intercept", {}).get(b, 9e9) - c["intercept"]) > 1e-12: mism.append(f"{pl}/{b}")
        if not coef or mism: F["coefficients"] = f"TM coefficients in the file differ from the fit report: {mism or 'no fit coefficients'}"
    bad, n = [], 0
    for y in C2TM_YEARS:
        for rel in PERIODS:
            n += 1; m = J(f"data/composites/pune_G30/{y}/landsat_c2tm/{rel}/metadata.json") or {}; pr = m.get("processing", {})
            if pr.get("harmonization") != C2_TRANSFORM or pr.get("transform_sha256") != C2_SHA or pr.get("transform_spec_sha256") != exp_t: bad.append(f"{y}/{rel}")
    if bad: F["treatment_products"] = f"{len(bad)}/{n} landsat_c2tm products missing or not made with the pinned transform (e.g. {bad[:3]})"
    cmp_bad = [f"{y}/{rel}" for y in C2TM_YEARS for rel in PERIODS
               if (lambda pr: pr.get("harmonization") != COMPARATOR_TRANSFORM or pr.get("transform_sha256") != COMPARATOR_SHA or pr.get("transform_spec_sha256") != exp_c)(
                   (J(f"data/composites/pune_G30/{y}/landsat/{rel}/metadata.json") or {}).get("processing", {}))]
    if cmp_bad: F["comparator_products"] = f"{len(cmp_bad)} standard products missing or not {COMPARATOR_TRANSFORM} (e.g. {cmp_bad[:3]})"
    fv = J("results/phase6/cube_validation_c2tm.json") or {}
    if not (fv.get("ok") is True and fv.get("complete_for_required") is True and fv.get("family") == "landsat_c2tm" and fv.get("expect_transform_sha256") == C2_SHA):
        F["treatment_family_validation"] = "validate_district_cube.py --family landsat_c2tm not ok/complete with the pinned SHA"
    ok_t, msg_t, pt = _bound_cube(CUBE_C2, FCV_C2, "landsat_c2tm"); ok_c, msg_c, pc = _bound_cube(CUBE, FCV, "landsat")
    if not ok_t: F["treatment_cube"] = msg_t
    if not ok_c: F["comparator_cube"] = msg_c
    side = config.path(CUBE_C2).with_suffix(".json")
    if side.exists():
        meta = json.loads(side.read_text()); fy = {int(k): v for k, v in (meta.get("family_per_year") or {}).items()}
        wrong = [y for y in C2TM_YEARS if fy.get(y) != "landsat_c2tm"]
        if wrong: F["treatment_cube_years"] = f"TM years missing or not from landsat_c2tm: {wrong}"
        src = meta.get("source_metadata_sha256", {}); tm_src = [k for k in src if "/landsat_c2tm/" in k]
        if len(tm_src) < len(C2TM_YEARS) * len(PERIODS): F["treatment_cube_source_count"] = f"{len(tm_src)} landsat_c2tm sources < {len(C2TM_YEARS) * len(PERIODS)}"
        chg = [k for k in tm_src if sha(k) != src[k]]
        if chg: F["treatment_cube_sources"] = f"{len(chg)} treatment source products changed after the cube was built"
        P["treatment_cube_sources"] = len(tm_src)
    P.update(transform_file=str(T.relative_to(config.ROOT)), transform_sha256=sha(T), specification=A2, specification_sha256=sha(A2), treatment_products_checked=n,
             treatment_cube=pt, comparator_cube=pc, chain="c2_tm_pif_v1 (pinned SHA) -> landsat_c2tm products (harmonization + transform_sha256 per product) -> family validation -> treatment feature cube (TM years from landsat_c2tm, source hashes unchanged)")
    return F, P

def preflight(eid: str, run_root: str = RUN_ROOT) -> dict:
    F, proof = {}, {"experiment_id": eid}
    rec = P4.load(eid); proto = P4.load_protocol(); fz = proto["frozen"]
    if rec is None: raise Refusal(eid, {"registry": "record not registered"})
    if not (P4.code_hash() == fz["code_sha256"] == rec.get("eval_code_sha256") and P4.protocol_hash() == fz["protocol_sha256"] and rec.get("protocol_version") == proto["protocol_version"]):
        F["protocol"] = "protocol v2 code/YAML hash or version differs from the frozen values / the record"
    if rec.get("status") != "PENDING": F["registry_status"] = f"{eid} is {rec.get('status')} - each confirmatory test runs once"
    cc = P4.check_confirmatory_records()
    if not cc["ok"]: F["G8"] = "check_confirmatory_records() not ok"
    try:
        c = _checklist_module().checklist(eid); proof["checklist"] = {"decision": c["decision"], "failed": c["failed"]}
        if not c["run_allowed"]: F["prerun_checklist"] = f"DO NOT RUN ({len(c['failed'])} items): {c['failed']}"
    except Exception as e: F["prerun_checklist"] = f"checklist error {e!r}"
    st = spec.status(eid); proof["specification"] = st
    if not st["complete"]: F["specification"] = st["missing"]
    if eid not in IMPLEMENTED: F["implementation"] = f"{eid} pipeline NOT_IMPLEMENTED (operational specification not adopted; see docs/phase7_runner_validation.md)"
    reg = J(REGISTRATION); cur = implementation_hashes(); proof["implementation_sha256"] = cur
    if not reg: F["implementation_registration"] = f"{REGISTRATION} missing - the runner is not registered"
    elif reg.get("files_sha256") != cur: F["implementation_registration"] = "runner code differs from its registration (code changed after registration without a registered amendment)"
    else: proof["registration"] = {"file": REGISTRATION, "sha256": sha(REGISTRATION), "registered_utc": reg.get("registered_utc")}
    k = ORDER.index(eid)
    for prev in ORDER[:k]:
        pr = P4.load(prev) or {}
        if pr.get("status") == "PENDING": F[f"order_{prev}"] = f"{prev} has not run yet (registered order C1 -> C6)"
    c1man = None
    if eid != "P4-C1@v2":
        c1 = P4.load("P4-C1@v2") or {}; mp = f"{run_root}/P4-C1_at_v2/run_manifest.json"; c1man = J(mp)
        if c1.get("status") != "PASS" or not c1man or not c1man.get("selection"): F["selection"] = "P4-C1@v2 not completed with a recorded tuning selection"
        elif (c1.get("result") or {}).get("run_manifest_sha256") != sha(mp): F["selection"] = "P4-C1@v2 run manifest differs from the SHA-256 recorded in its registry record"
        else: proof["selection"] = c1man["selection"] | {"from": mp, "manifest_sha256": sha(mp)}
    g = label_manifest("gold"); proof["gold"] = g
    if not g or g.get("status") != "FROZEN": F["gold"] = "Tier-A gold not frozen (results/phase7/manifests/gold)"
    elif sha("data/labels/gold/phase4/ingested/gold_reference_labels.csv") != g.get("dataset_sha256"): F["gold"] = "ingested gold differs from the frozen manifest"
    t = label_manifest("T1"); proof["T1"] = t                        # every record reads T1 (arms D/E, tuning cells in the leakage check, C5 calibration)
    if not t or t.get("status") != "FROZEN": F["T1"] = "T1 v2 not frozen (results/phase7/manifests/T1)"
    elif sha("data/labels/training/phase6_T1v2/ingested/gold_reference_labels.csv") != t.get("dataset_sha256"): F["T1"] = "ingested T1 differs from the frozen manifest"
    if c1man:                                                        # every downstream record uses exactly the label versions C1 used
        for tag in ("gold", "T1"):
            used = ((c1man.get("preflight_proof") or {}).get(tag) or {}).get("dataset_sha256"); now = (proof.get(tag) or {}).get("dataset_sha256")
            if used != now: F[f"{tag}_version"] = f"{tag} dataset {str(now)[:12]} differs from the version P4-C1@v2 used ({str(used)[:12]})"
    g1, t1_ = first_manifest("gold"), first_manifest("T1")           # adoption + countersignature must precede the first freeze of the labels
    for a in st.get("adopted", []):
        for tag, m in (("gold", g1), ("T1", t1_)):
            if m and a.get("countersigned_utc") and str(a["countersigned_utc"]) > str(m.get("created_utc")):
                F[f"adoption_after_{tag}_{Path(a['path']).stem}"] = f"countersigned {a['countersigned_utc']} after the first {tag} freeze {m.get('created_utc')} (forking-path risk)"
    fi, hi = input_checks(eid); proof["inputs_sha256"] = hi; F.update(fi)
    dirty = __import__("subprocess").run(["git", "status", "--porcelain", "--untracked-files=no"], capture_output=True, text=True, cwd=config.ROOT).stdout.strip()
    if dirty: F["clean_tree"] = f"tracked files modified - commit before a confirmatory run: {dirty.splitlines()[:5]}"
    s = label_manifest("silver"); proof["silver"] = s
    if not s or s.get("status") != "FROZEN" or sha("data/labels/pune_G30_district_silver/silver_l1.tif") != s.get("sha256"): F["silver"] = "district silver not frozen / changed"
    ok_c, msg_c, pc = _bound_cube(CUBE, FCV, "landsat"); proof["cube"] = pc
    if not ok_c: F["cube"] = msg_c
    if eid == "P4-C2@v2":
        f2, p2 = verify_c2_transform(); proof["c2_transform_chain"] = p2
        if f2: F["c2_transform_chain"] = f2
    out = config.path(run_root, eid.replace("@", "_at_"))
    if out.exists(): F["single_execution"] = f"{out} exists - outputs are immutable and a record runs once"
    if F: raise Refusal(eid, F)
    return proof
