"""Phase 7 confirmatory runner for the six frozen protocol-v2 records P4-C1@v2 ... P4-C6@v2.

It FAILS CLOSED: before anything is trained it verifies the frozen protocol, the registry, the pre-run checklist (never overridden), the
adopted + countersigned operational specification, its own registered implementation hashes, the frozen label sets, the validated district
products and - for P4-C2@v2 - the whole chain c2_tm_pif_v1 -> landsat_c2tm products -> treatment feature cube. Each record runs once; every
output is hashed into an immutable run manifest. Statistics use only the frozen protocol modules (evaluation4, calibration).
Implemented pipelines: P4-C1@v2 and P4-C2@v2. P4-C3..C6@v2 are refused (NOT_IMPLEMENTED) until their operational specification is adopted
and the pipeline is implemented, tested and registered (docs/phase7_runner_validation.md)."""
ORDER = ["P4-C1@v2", "P4-C2@v2", "P4-C3@v2", "P4-C4@v2", "P4-C5@v2", "P4-C6@v2"]
FAMILIES = {"label_quality": ["P4-C1@v2"], "historical": ["P4-C2@v2", "P4-C3@v2"], "spatial": ["P4-C4@v2", "P4-C6@v2"], "uncertainty": ["P4-C5@v2"]}
IMPLEMENTED = {"P4-C1@v2", "P4-C2@v2"}

class Refusal(RuntimeError):
    """Raised when any precondition fails; carries every failed check (fail closed, nothing is run)."""
    def __init__(self, eid, failed: dict):
        self.eid, self.failed = eid, failed
        super().__init__(f"{eid}: confirmatory run REFUSED ({len(failed)} failed preconditions): " + "; ".join(f"{k}: {v}" for k, v in failed.items()))
