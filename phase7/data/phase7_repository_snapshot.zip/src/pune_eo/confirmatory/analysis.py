"""Design-based gold metrics, paired seed-pooled tests, decisions and BH - composed ONLY of frozen protocol functions
(evaluation4.metrics.per_class / summary semantics, evaluation4.stats.stratified_block_bootstrap / bootstrap_p_two_sided / bh_fdr).
Rules G-2, G-3, G-4 and C1-7 / C1-9 of the runner specification (docs/phase7_runner_specification.md)."""
from __future__ import annotations
import numpy as np
from ..evaluation4 import metrics as EM, stats as ES

CODES = {"built_up": 1, "agriculture": 2, "natural_vegetation": 3, "water": 4, "bare_sparse": 5, "other": 6}
LEGEND = [1, 2, 3, 4]; ALL = [1, 2, 3, 4, 5, 6]
N_BOOT, BOOT_SEED, Q = 2000, 20261110, 0.05            # protocol: uncertainty.designed_samples, tests.multiplicity
MIN_ACCURACY_SET = 100                                   # addendum-1: an epoch with fewer accuracy-set gold labels is NOT TESTABLE

def weighted_confusion(y_ref, y_map, w, classes=ALL) -> np.ndarray:
    """numpy equivalent of evaluation4.metrics.confusion (rows = reference, cols = map); unit-tested for equality."""
    k = len(classes); lut = np.full(max(classes) + 2, -1)
    for i, c in enumerate(classes): lut[c] = i
    yr = np.asarray(y_ref, int); ym = np.asarray(y_map, int)
    r = np.where((yr >= 0) & (yr <= max(classes)), lut[np.clip(yr, 0, max(classes) + 1)], -1); m = np.where((ym >= 0) & (ym <= max(classes)), lut[np.clip(ym, 0, max(classes) + 1)], -1)
    ok = (r >= 0) & (m >= 0)
    return np.bincount(r[ok] * k + m[ok], weights=np.asarray(w, float)[ok], minlength=k * k).reshape(k, k)

def design_weights(strata: np.ndarray, n_pop: dict) -> np.ndarray:
    """w_i = N_h / k_h with k_h = points of stratum h in THIS (re)sample (G-3); equals the Olofsson stratified estimator for OA."""
    s = np.asarray(strata); u, inv, cnt = np.unique(s, return_inverse=True, return_counts=True)
    return np.array([n_pop[x] for x in u], float)[inv] / cnt[inv]

def metric_values(y_ref, y_map, strata, n_pop, classes=ALL) -> dict:
    """design-weighted OA and macro-F1 over classes PRESENT in the reference (outside-legend references count as errors)."""
    M = weighted_confusion(y_ref, y_map, design_weights(strata, n_pop), classes); pc = EM.per_class(M, classes); tot = M.sum()
    present = [c for c in classes if pc[c]["n_ref"] > 0]
    return {"oa": float(np.trace(M) / tot) if tot > 0 else np.nan, "macro_f1": float(np.nanmean([np.nan_to_num(pc[c]["f1"]) for c in present])) if present else np.nan}

def unweighted_macro_f1_legend(y_ref, y_map) -> float:
    """tuning selection metric (C1-6): unweighted macro-F1 over present legend classes."""
    keep = np.isin(y_ref, LEGEND); return EM.summary(np.asarray(y_ref)[keep], np.asarray(y_map)[keep], LEGEND)["macro_f1_present"]

def paired_test(maps_t: np.ndarray, maps_c: np.ndarray, y_ref, strata, blocks, n_pop, metric: str, n_boot=N_BOOT, seed=BOOT_SEED) -> dict:
    """maps_*: (n_seeds, n_points) predicted codes. Pooled statistic = seed-mean metric(treatment) - seed-mean metric(comparator) on identical
    stratified block resamples (G-2). Returns estimate, 95 % CI, two-sided bootstrap p, per-seed differences and sign agreement."""
    y_ref, strata = np.asarray(y_ref), np.asarray(strata); vals = []
    def stat(i):
        d = np.mean([metric_values(y_ref[i], maps_t[s][i], strata[i], n_pop)[metric] for s in range(len(maps_t))]) - \
            np.mean([metric_values(y_ref[i], maps_c[s][i], strata[i], n_pop)[metric] for s in range(len(maps_c))])
        vals.append(d); return d
    r = ES.stratified_block_bootstrap(stat, strata, blocks, n=n_boot, seed=seed)
    allidx = np.arange(len(y_ref))
    per_seed = [metric_values(y_ref, maps_t[s], strata, n_pop)[metric] - metric_values(y_ref, maps_c[s], strata, n_pop)[metric] for s in range(len(maps_t))]
    est = r["estimate"]; agree = int(sum(np.sign(d) == np.sign(est) and d != 0 for d in per_seed))
    return {"metric": metric, "estimate": est, "ci": r["ci"], "p_two_sided": ES.bootstrap_p_two_sided(np.array(vals[1:])), "n_boot": n_boot, "n_psu": r.get("n_psu"),
            "per_seed_difference": per_seed, "seeds_agreeing_in_sign": agree, "n_points": int(len(y_ref)), "testable": True}

def not_testable(metric: str, n: int) -> dict:
    return {"metric": metric, "testable": False, "reason": f"{n} accuracy-set gold labels < {MIN_ACCURACY_SET}", "p_two_sided": 1.0, "n_points": n}

def apply_bh(tests: list[dict], q=Q) -> list[dict]:
    """BH over the full pre-declared family (C1-7: NOT TESTABLE tests enter with p = 1)."""
    if not tests: return tests
    r = ES.bh_fdr([t["p_two_sided"] for t in tests], q)
    for t, qv in zip(tests, r["q_values"]): t["q_bh"] = float(qv)
    return tests

def decide(t: dict, direction: str, n_seeds=5) -> str:
    """decision rule (protocol) + G-4: 'SUPPORTED' / 'NOT_SUPPORTED' / 'NOT_TESTABLE'. Needs t['q_bh']."""
    if not t.get("testable", False): return "NOT_TESTABLE"
    lo, hi = t["ci"]; excl = lo > 0 or hi < 0; up = lo > 0
    ok = excl and t["q_bh"] <= Q and t["seeds_agreeing_in_sign"] >= (4 if n_seeds == 5 else int(np.ceil(0.8 * n_seeds)))
    if direction == "improvement": ok = ok and up
    return "SUPPORTED" if ok else "NOT_SUPPORTED"

def c1_outcome(tests: list[dict]) -> dict:
    """C1-9: contrast DIFFERS iff >= 1 of its tests SUPPORTED; does NOT differ iff none and all its tests testable; else INCONCLUSIVE.
    Record: SUPPORTED iff all four contrasts differ; NOT_SUPPORTED iff >= 1 does not differ; else INCONCLUSIVE."""
    con = {}
    for c in ("B-A", "C-A", "D-A", "E-A"):
        ts = [t for t in tests if t["contrast"] == c]; dec = [t["decision"] for t in ts]
        con[c] = "DIFFERS" if "SUPPORTED" in dec else ("DOES_NOT_DIFFER" if dec and all(d == "NOT_SUPPORTED" for d in dec) else "INCONCLUSIVE")
    out = "SUPPORTED" if all(v == "DIFFERS" for v in con.values()) else ("NOT_SUPPORTED" if any(v == "DOES_NOT_DIFFER" for v in con.values()) else "INCONCLUSIVE")
    return {"contrasts": con, "outcome": out}
