"""Inputs of the confirmatory pipelines: point features from the validated district feature cube (as a Phase-3-style 'H' dict so that the
registered feature sets are built by the SAME code, historical_reconstruction.features / temporal_models.window_sequence), training arms A-E
(addendum-1 + erratum-1 + runner specification C1-1..C1-3, C1-8), and the frozen gold / T1 tables. Never reads a gold label before the tuning
selection is frozen (the experiments call gold_labels() only afterwards)."""
from __future__ import annotations
import hashlib
from dataclasses import dataclass, field
from pathlib import Path
import numpy as np, pandas as pd, rasterio
from .. import config
from ..change_detection import changepoints as CP
from ..feature_engineering import cube as FC
from .analysis import CODES, LEGEND

GOLD_EPOCHS = [2020, 2010, 2000, 1990]; T1_EPOCHS = [2020, 2000]; CAP = 5000
GLC_L1 = {10: 2, 11: 2, 12: 2, 20: 2, **{c: 3 for c in (51, 52, 61, 62, 71, 72, 81, 82, 91, 92, 120, 121, 122, 130, 140)}, 150: 5, 152: 5, 153: 5,
          **{c: 6 for c in range(181, 188)}, 190: 1, 200: 5, 201: 5, 202: 5, 210: 4, 220: 6}          # = scripts/phase6_training_sample_T1v2.py

@dataclass
class Inputs:
    """Paths of every input (production defaults); tests pass synthetic equivalents."""
    cube: Path = field(default_factory=lambda: config.path("data/features/cube/pune_G30.zarr"))
    silver: Path = field(default_factory=lambda: config.path("data/labels/pune_G30_district_silver/silver_l1.tif"))
    train_population: Path = field(default_factory=lambda: config.path("data/labels/training/phase6_T1v2/sampling_design/train_eligible_T1_30m.tif"))
    glc: Path = field(default_factory=lambda: config.path("data/products_ext/glc_fcs30d/glc_fcs30d_district_30m.tif"))
    gold_key: Path = field(default_factory=lambda: config.path("data/labels/gold/phase4/_key/phase4_gold_key.csv"))
    gold_labels: Path = field(default_factory=lambda: config.path("data/labels/gold/phase4/ingested/gold_reference_labels.csv"))
    t1_labels: Path = field(default_factory=lambda: config.path("data/labels/training/phase6_T1v2/ingested/gold_reference_labels.csv"))
    block_m: float = 6000.0
    min_dist_gold_m: float = 2000.0                    # protocol training_exclusion_buffer_km / T1 design (>= 2 km from every gold point)

class Leakage(RuntimeError):
    pass

def leakage_check(rows: pd.DataFrame, gold: pd.DataFrame, tuning: pd.DataFrame, inp: Inputs, grid: dict) -> dict:
    """STOP condition: a training row on a gold cell or a T1 tuning cell, a silver row outside the T1 train population, or a training row closer
    than min_dist_gold_m to a gold point."""
    from scipy.spatial import cKDTree
    tr = set(zip(rows.row.values, rows.col.values)); bad = {"on_gold_cell": len(tr & set(zip(gold.row, gold.col))), "on_tuning_cell": len(tr & set(zip(tuning.row, tuning.col)))}
    pop = rd(inp.train_population).astype(bool); sv = rows[rows.source != "T1_train"]; bad["silver_outside_train_population"] = int((~pop[sv.row.values, sv.col.values]).sum())
    xy = lambda r, c: np.c_[grid["x0"] + (np.asarray(c) + 0.5) * grid["res"], grid["y1"] - (np.asarray(r) + 0.5) * grid["res"]]
    d = cKDTree(xy(gold.row, gold.col)).query(xy(rows.row.values, rows.col.values))[0] if len(rows) else np.array([np.inf])
    bad["closer_than_min_dist_to_gold"] = int((d < inp.min_dist_gold_m).sum())
    rep = {**bad, "min_distance_to_gold_m": float(d.min()), "min_dist_gold_m": inp.min_dist_gold_m, "n_rows": int(len(rows))}
    if any(v for k, v in bad.items()): raise Leakage(f"LEAKAGE DETECTED - run stopped: {rep}")
    return rep

def rd(p, band=1):
    with rasterio.open(p) as s: return s.read(band)

def extract(cube: Path, var: str, rows, cols, features: list[str] | None = None) -> np.ndarray:
    """values of `var` at the cells, reading every needed zarr chunk ONCE (points grouped by chunk). Returns (n_points, *non-spatial dims)."""
    import xarray as xr
    ds = xr.open_zarr(cube); da = ds[var]
    if features is not None: da = da.sel(feature=features)
    ch = ds[var].encoding.get("chunks") or (256, 256); cy, cx = int(ch[-2]), int(ch[-1])
    rows, cols = np.asarray(rows, int), np.asarray(cols, int); out = np.full((len(rows),) + da.shape[:-2], np.nan, np.float32)
    key = (rows // cy) * 100000 + cols // cx
    for k in np.unique(key):
        idx = np.flatnonzero(key == k); by, bx = divmod(int(k), 100000)
        blk = da.isel(y=slice(by * cy, (by + 1) * cy), x=slice(bx * cx, (bx + 1) * cx)).values
        out[idx] = np.moveaxis(blk[..., rows[idx] - by * cy, cols[idx] - bx * cx], -1, 0)
    return out

def point_H(cube: Path, rows: np.ndarray, cols: np.ndarray, pad: int = 2) -> dict:
    """H dict for the given cells: L (N, Y, 23) on a CONSECUTIVE year axis (missing years NaN, so year +-k indexing is exact), T (N, 12), S (N, SY, 7)."""
    import xarray as xr
    ds = xr.open_zarr(cube); cy = [int(v) for v in ds.year.values]; full = list(range(min(cy) - pad, max(cy) + pad + 1))
    Lc = extract(cube, "landsat", rows, cols)                                   # (N, year, feature)
    L = np.full((len(rows), len(full), Lc.shape[2]), np.nan, np.float32)
    for j, y in enumerate(cy): L[:, full.index(y)] = Lc[:, j]
    return {"L": L, "T": extract(cube, "terrain", rows, cols), "S": extract(cube, "sentinel", rows, cols), "meta": pd.DataFrame({"row": rows, "col": cols}),
            "info": {"years": full, "features": [str(v) for v in ds.feature.values], "tfeatures": [str(v) for v in ds.tfeature.values],
                     "syears": [int(v) for v in ds.syear.values], "sfeatures": [str(v) for v in ds.sfeature.values], "cube_years": cy}}

def subset_H(H: dict, idx: np.ndarray) -> dict:
    return {"L": H["L"][idx], "T": H["T"][idx], "S": H["S"][idx], "meta": H["meta"].iloc[idx].reset_index(drop=True), "info": H["info"]}

def block_ids(rows, cols, grid: dict, block_m: float) -> np.ndarray:
    x = grid["x0"] + (np.asarray(cols) + 0.5) * grid["res"]; y = grid["y1"] - (np.asarray(rows) + 0.5) * grid["res"]
    return np.array([f"{int(a // block_m)}:{int(b // block_m)}" for a, b in zip(x, y)])

def es_holdout(blocks: np.ndarray) -> np.ndarray:
    """C1-5: early-stopping rows = 6 km blocks with sha256('phase7-es-v1:{bx}:{by}') % 10 == 0."""
    u = {b: int(hashlib.sha256(f"phase7-es-v1:{b}".encode()).hexdigest(), 16) % 10 == 0 for b in np.unique(blocks)}
    return np.array([u[b] for b in blocks])

def stable_range(t: np.ndarray, series: dict) -> tuple[int, int]:
    """P3-B4m (scripts/run_phase3_temporal.py::stable_range) unchanged: breaks from 'pelt_mean' on dry_ndvi and post_ndvi with |mag| >= 0.05."""
    lo, hi = 1990, 2026
    for f in ("post_ndvi", "dry_ndvi"):
        cps = CP.detect(np.asarray(t), np.asarray(series[f], float), "pelt_mean") or []       # detect() drops missing years, None if < 10 finite
        for yr, mag in cps:
            if abs(mag) < 0.05: continue
            if yr <= 2021: lo = max(lo, yr)
            else: hi = min(hi, yr - 1)
    return lo, hi

class Arms:
    """Training rows per arm for one run seed: DataFrame(row, col, epoch, label, block, source)."""
    def __init__(self, inp: Inputs, grid: dict, seed: int, t1: pd.DataFrame | None):
        self.inp, self.grid, self.seed = inp, grid, seed
        pop = rd(inp.train_population).astype(bool); sil = rd(inp.silver)
        self.cand = np.flatnonzero((pop & np.isin(sil, LEGEND)).ravel()); self.sil_flat = sil.ravel(); self.W = sil.shape[1]
        with rasterio.open(inp.glc) as s: d = [str(x) for x in s.descriptions]; g20, g21 = s.read(d.index("2020") + 1), s.read(d.index("2021") + 1)
        l1 = np.zeros(65536, np.uint8)
        for k, v in GLC_L1.items(): l1[k] = v
        self.glc_ok = (l1[g20.ravel()[self.cand]] == self.sil_flat[self.cand]) & (l1[g21.ravel()[self.cand]] == self.sil_flat[self.cand])   # C1-3 / erratum-1
        self.t1 = t1; self._stable = {}

    def _rows(self, cells, epoch, src):
        r, c = np.divmod(cells, self.W)
        return pd.DataFrame({"row": r, "col": c, "epoch": epoch, "label": self.sil_flat[cells].astype(int), "block": block_ids(r, c, self.grid, self.inp.block_m), "source": src})

    def _sample(self, pool, epoch, salt, accept=None):
        """<= CAP cells per class for this epoch, numpy default_rng(seed) (addendum-1 'sampling'); accept() filters lazily in permutation order
        (identical distribution to filtering first, then sampling uniformly)."""
        rng = np.random.default_rng([self.seed, epoch, salt]); out = []
        for k in LEGEND:
            cells = pool[self.sil_flat[pool] == k]; perm = rng.permutation(cells)
            if accept is None: out.append(perm[:CAP]); continue
            got = []
            for i in range(0, len(perm), 4 * CAP):
                ch = perm[i:i + 4 * CAP]; got.extend(ch[accept(ch, epoch)].tolist())
                if len(got) >= CAP: break
            out.append(np.array(got[:CAP], int))
        return np.concatenate(out) if out else np.array([], int)

    def stable_mask(self, cells, epoch):
        need = [c for c in cells if c not in self._stable]
        if need:
            import xarray as xr
            r, c = np.divmod(np.array(need), self.W); cy = np.array([int(v) for v in xr.open_zarr(self.inp.cube).year.values])
            V = extract(self.inp.cube, "landsat", r, c, ["dry_ndvi", "post_ndvi"])      # (n, year, 2)
            for j, cell in enumerate(need): self._stable[cell] = stable_range(cy, {"dry_ndvi": V[j, :, 0], "post_ndvi": V[j, :, 1]})
        return np.array([self._stable[c][0] <= epoch <= self._stable[c][1] for c in cells])

    def arm(self, name: str) -> pd.DataFrame:
        if name == "A": return pd.concat([self._rows(self._sample(self.cand, e, 1), e, "silver") for e in GOLD_EPOCHS], ignore_index=True)
        if name == "B": return pd.concat([self._rows(self._sample(self.cand, e, 2, self.stable_mask), e, "silver_pelt_stable") for e in GOLD_EPOCHS], ignore_index=True)
        if name == "C": return pd.concat([self._rows(self._sample(self.cand[self.glc_ok], e, 3), e, "silver_glc_agree") for e in GOLD_EPOCHS], ignore_index=True)
        if name == "D": return self.d_rows()
        if name == "E": return pd.concat([self.d_rows(), self.arm("C")], ignore_index=True)
        raise KeyError(name)

    def d_rows(self) -> pd.DataFrame:
        t = self.t1
        if t is None: raise RuntimeError("arm D needs the frozen T1 table")
        t = t[(t.split == "train") & t.epoch.isin(T1_EPOCHS) & t.reference_label.isin([k for k, v in CODES.items() if v in LEGEND])]
        return pd.DataFrame({"row": t.row.values, "col": t.col.values, "epoch": t.epoch.values.astype(int), "label": t.reference_label.map(CODES).values.astype(int),
                             "block": block_ids(t.row.values, t.col.values, self.grid, self.inp.block_m), "source": "T1_train"})

    def equal_size_control(self, n_target: int) -> pd.DataFrame:
        """C1-8: arm A subsampled per class proportionally to the row count of D."""
        a = self.arm("A"); rng = np.random.default_rng([self.seed, 99]); frac = min(1.0, n_target / max(1, len(a)))
        return pd.concat([g.iloc[rng.permutation(len(g))[:int(round(len(g) * frac))]] for _, g in a.groupby("label")], ignore_index=True)

def read_t1(inp: Inputs) -> pd.DataFrame:
    t = pd.read_csv(inp.t1_labels, keep_default_na=False); t["epoch"] = t.epoch.astype(int)
    for c in ("in_accuracy_set", "labelled"): t[c] = t[c].astype(str).str.lower().eq("true")
    return t

def gold_points(inp: Inputs) -> pd.DataFrame:
    """design information only (no labels): anon_id, row, col, stratum, block, region, stratum_area_cells."""
    return pd.read_csv(inp.gold_key)[["anon_id", "row", "col", "stratum", "block", "region", "stratum_area_cells"]]

def gold_labels(inp: Inputs, epoch: int) -> pd.DataFrame:
    g = pd.read_csv(inp.gold_labels, keep_default_na=False); g["epoch"] = g.epoch.astype(int)
    g["in_accuracy_set"] = g.in_accuracy_set.astype(str).str.lower().eq("true"); g = g[(g.epoch == epoch) & g.in_accuracy_set].copy()
    g["y"] = g.reference_label.map(CODES).astype(int); return g
