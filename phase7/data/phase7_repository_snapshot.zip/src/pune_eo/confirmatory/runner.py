"""Orchestration: preflight (fail closed) -> registry Run (frozen class, re-verifies the protocol) -> pipeline -> immutable run manifest ->
registry completion -> family finalisation (BH over the whole family, G-1). One execution per record; outputs are made read-only."""
from __future__ import annotations
import hashlib, json, os, platform, stat, subprocess, time
from pathlib import Path
import numpy as np
from .. import config
from ..evaluation4 import protocol as P4
from ..provenance import utcnow
from . import FAMILIES, Refusal, analysis as AN, data as D, guards as GU, experiments as EX

def _sha(p: Path) -> str: return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def _rel(p: Path) -> str: p = Path(p); return str(p.relative_to(config.ROOT)) if p.is_relative_to(config.ROOT) else str(p)
def _git() -> str: return subprocess.run(["git", "rev-parse", "HEAD"], capture_output=True, text=True, cwd=config.ROOT).stdout.strip()

def _versions() -> dict:
    import importlib.metadata as md
    out = {"python": platform.python_version()}
    for n in ("numpy", "pandas", "scikit-learn", "torch", "xarray", "zarr", "rasterio", "scipy", "ruptures"):
        try: out[n] = md.version(n)
        except Exception: out[n] = None
    return out

def _freeze_dir(d: Path):
    for p in sorted(d.rglob("*"), reverse=True) + [d]:
        m = p.stat().st_mode; p.chmod(m & ~(stat.S_IWUSR | stat.S_IWGRP | stat.S_IWOTH))

def write_manifest(out: Path, body: dict) -> Path:
    p = out / "run_manifest.json"
    if p.exists(): raise RuntimeError(f"{p} exists - run manifests are immutable")
    body["outputs_sha256"] = {str(f.relative_to(out)): _sha(f) for f in sorted(out.rglob("*")) if f.is_file() and f.name != "run_manifest.json"}
    p.write_text(json.dumps(body, indent=1, default=float)); return p

def run(eid: str, threads: int = 2, run_root: str = GU.RUN_ROOT, log=print) -> dict:
    proof = GU.preflight(eid, run_root)                              # raises Refusal with every failed check; nothing is trained
    R = P4.Run(eid)                                                  # frozen registry class: re-verifies protocol version + evaluation-code hash
    out = config.path(run_root, eid.replace("@", "_at_")); out.mkdir(parents=True); t0 = time.time(); rec_sha = _sha(P4.path(eid)); seeds = list(P4.load(eid)["seeds"])
    grid = json.loads(config.path("data/labels/gold/phase4/sampling_design/design.json").read_text())["grid"]
    body = {"experiment_id": eid, "started_utc": utcnow(), "git_head": _git(), "record_sha256_at_start": rec_sha, "protocol": {"code_sha256": P4.code_hash(), "yaml_sha256": P4.protocol_hash()},
            "preflight_proof": proof, "seeds": seeds, "n_boot": AN.N_BOOT, "bootstrap_seed": AN.BOOT_SEED, "environment": _versions(), "threads": threads}
    try:
        if eid == "P4-C1@v2":
            res = EX.run_c1(D.Inputs(), grid, out, seeds, AN.N_BOOT, threads=threads, log=log)
        elif eid == "P4-C2@v2":
            import rasterio
            with rasterio.open(config.path("data/products_ext/district/district_mask_30m.tif")) as s: dm = s.read(1).astype(bool)
            env = json.loads(config.path("results/phase5/benchmark/g5_built_envelope_frozen.json").read_text())
            res = EX.run_c2(D.Inputs(), D.Inputs(cube=config.path(GU.CUBE_C2)), grid, out, seeds, proof["selection"], env, dm, AN.N_BOOT, threads=threads, log=log)
        else:
            raise Refusal(eid, {"implementation": "NOT_IMPLEMENTED"})
    except Refusal: raise
    except Exception as e:
        body.update(status="FAIL", error=repr(e), finished_utc=utcnow()); write_manifest(out, body); _freeze_dir(out)
        R.fail(repr(e), attempted="pipeline", remaining="all outputs after the failure"); raise
    body.update(status="COMPLETED", finished_utc=utcnow(), runtime_s=round(time.time() - t0, 1), selection=res.get("selection"), outcome=res["outcome"],
                tests=res["tests"], c2_chain="C2 input -> frozen c2_tm_pif_v1 -> landsat_c2tm -> treatment cube: see preflight_proof.c2_transform_chain" if eid == "P4-C2@v2" else None)
    mp = write_manifest(out, body); _freeze_dir(out)
    family = P4.load(eid)["family"]; outcome = res["outcome"] if res["outcome"] in P4.OUTCOMES else "NA"
    R.complete(metrics={"n_tests": len(res["tests"])}, outcome=outcome, result={"run_manifest": _rel(mp), "run_manifest_sha256": _sha(mp),
               "family_bh": "complete" if FAMILIES[family] == [eid] else "pending until every record of the family has run (G-1)"},
               outputs={"run_dir": _rel(out)})
    fam = finalise_family(family, run_root)
    return {"manifest": str(mp), "outcome": outcome, "family": fam}

PLANNED_TESTS = {"P4-C1@v2": 64, "P4-C2@v2": 2, "P4-C3@v2": 2, "P4-C4@v2": 0, "P4-C5@v2": 0, "P4-C6@v2": 1}   # p-value tests per record (runner specification C1-7, C2-2, C3-2, C6-2; C4/C5 are threshold criteria)

def _record_outcome(eid: str, tests: list[dict], res: dict) -> str:
    if eid == "P4-C1@v2": return AN.c1_outcome(tests)["outcome"]
    dec = [t["decision"] for t in tests]
    if dec and all(d == "SUPPORTED" for d in dec): return "SUPPORTED"
    return "NOT_SUPPORTED" if any(d == "NOT_SUPPORTED" for d in dec) else "INCONCLUSIVE"

def finalise_family(family: str, run_root: str = GU.RUN_ROOT) -> dict | None:
    """G-1: once every record of the family has run, BH over all its p-value tests at once; per-record outcomes; immutable family file +
    append-only pointer in each record. Returns None while a member is still PENDING."""
    members = FAMILIES[family]; recs = {e: P4.load(e) for e in members}
    if any(r["status"] == "PENDING" for r in recs.values()): return None
    fp = config.path(run_root, f"family_{family}.json")
    if fp.exists(): return json.loads(fp.read_text())
    allt, res = [], {}
    for e in members:
        if recs[e]["status"] != "PASS":                               # C1-7 / G-1: planned tests of a failed record are never dropped: p = 1, m fixed
            allt += [{"experiment_id": e, "testable": False, "p_two_sided": 1.0, "reason": f"record {recs[e]['status']}: planned test not run"} for _ in range(PLANNED_TESTS[e])]; continue
        r = json.loads(config.path(run_root, e.replace("@", "_at_"), "results.json").read_text()); res[e] = r
        if len(r["tests"]) != PLANNED_TESTS[e]: raise RuntimeError(f"{e}: {len(r['tests'])} tests != {PLANNED_TESTS[e]} planned")
        for t in r["tests"]: allt.append(dict(t, experiment_id=e))
    AN.apply_bh(allt)
    for t in allt: t["decision"] = AN.decide(t, "improvement" if recs[t["experiment_id"]]["direction"] == "improvement" else "two-sided", len(recs[t["experiment_id"]]["seeds"]))
    outcomes = {e: (_record_outcome(e, [t for t in allt if t["experiment_id"] == e], res[e]) if e in res else f"no result ({recs[e]['status']})") for e in members}
    body = {"family": family, "members": members, "created_utc": utcnow(), "n_tests": len(allt), "q": AN.Q, "tests": allt, "outcomes": outcomes,
            "rule": "BH over every p-value test of the family at once (runner specification G-1); decision rule of protocol v2 (G-2..G-4)"}
    fp.write_text(json.dumps(body, indent=1, default=float)); h = _sha(fp)
    for e in members:
        rec = P4.load(e); rec.setdefault("family_decision", []).append({"path": _rel(fp), "sha256": h, "outcome": outcomes[e], "finalised_utc": body["created_utc"]})
        P4._write(rec)
    return body

def preflight_all(run_root: str = GU.RUN_ROOT) -> dict:
    from . import ORDER
    out = {}
    for e in ORDER:
        try: GU.preflight(e, run_root); out[e] = {"decision": "RUNNABLE", "failed": {}}
        except Refusal as r: out[e] = {"decision": "DO NOT RUN", "failed": r.failed}
    return out
