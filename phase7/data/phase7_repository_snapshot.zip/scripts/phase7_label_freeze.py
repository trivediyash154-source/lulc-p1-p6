"""Phase 7 / Stages 3-4: ingest, audit and FREEZE the human label sets (Tier-A gold; T1 v2 training/tuning). Never creates, fills or edits a label.

    python3 scripts/phase7_label_freeze.py --kind gold     --frozen-by <evaluator>
    python3 scripts/phase7_label_freeze.py --kind training --frozen-by <evaluator>

Prerequisite: the interpreters' completed forms are in raw_interpreter_A/ (and _B/, adjudicated/) and each pass was frozen with
`python3 src/validation/ingest_gold.py [--kind training] freeze <pass_id> --by <evaluator>` (raw-file SHA-256 records; immutable).
Steps: (1) the tested ingestion + audit (src/validation: schema, ids, coordinates, values, blindness, provenance, freeze, corrections,
adjudication, spatial/leakage rules) - any violation stops here; (2) the Phase-7 verification list (expected ids, duplicates, missing ids, class
values, epochs, interpreter ids, coordinates, raw headers, double subset, disagreement statistics; T1: class balance, leakage and train/tuning
partition); (3) DATASET FREEZE: a versioned manifest results/phase7/manifests/<gold|T1>/manifest_v<N>.json with the SHA-256 of every raw file,
freeze record, adjudication file, key, design and the ingested reference table. A new version is written only when the ingested table changes;
that is possible only through new frozen passes or signed correction records (enforced by the ingestion code) and the previous version is
referenced. Without labels the manifest records status NOT_AVAILABLE and nothing is frozen."""
from __future__ import annotations
import argparse, glob, hashlib, json, subprocess, sys
from pathlib import Path
import numpy as np, pandas as pd
ROOT = Path(__file__).resolve().parents[1]; sys.path.insert(0, str(ROOT / "src"))
from validation import ingest_gold as IG, audit_gold as AG
from pune_eo.provenance import utcnow

KINDS = {"gold": {"base": IG.GOLD, "audit_out": ROOT / "results/phase5/gold", "label": "Tier-A gold", "tag": "gold", "kit": ("gold_A", "gold_B"),
                  "design": "sampling_design/design.json", "required_epochs": (2020, 2000)},
         "training": {"base": IG.T1, "audit_out": ROOT / "results/phase5/t1", "label": "T1 v2 (training + tuning)", "tag": "T1", "kit": ("T1v2_A", "T1v2_B"),
                      "design": "sampling_design/design.json", "required_epochs": (2020, 2000)}}

def sha(p) -> str | None:
    p = Path(p); return hashlib.sha256(p.read_bytes()).hexdigest() if p.exists() else None

def _git() -> str:
    return subprocess.run(["git", "rev-parse", "HEAD"], capture_output=True, text=True, cwd=ROOT).stdout.strip()

def _raw_files(base: Path) -> dict:
    return {d: sorted(str(p.relative_to(base)) for p in (base / d).glob("*.csv")) for d in ("raw_interpreter_A", "raw_interpreter_B", "adjudicated")}

def _versions(mdir: Path) -> list[Path]:
    return sorted(mdir.glob("manifest_v*.json"), key=lambda p: int(p.stem.split("_v")[1]))

def verify(kind: str, base: Path, final: pd.DataFrame, long: pd.DataFrame, irep: dict, spatial, grid: dict | None = None) -> dict:
    """Phase-7 verification list on an ingested (already validated) label set. Returns {item: {ok, ...}}."""
    K = IG.load_key(base, kind); V = {}
    def it(name, ok, **d): V[name] = {"ok": bool(ok), **d}
    ids, kids = set(final.anon_id), set(K.anon_id)
    it("expected_ids", ids == kids, n_expected=len(kids), n_found=len(ids))
    it("no_duplicate_ids", not final.duplicated(["anon_id", "epoch"]).any() and not long.duplicated(["anon_id", "epoch", "interpreter_role"]).any())
    per_ep = final.groupby("epoch").anon_id.nunique().to_dict()
    it("no_missing_ids", all(v == len(kids) for v in per_ep.values()), ids_per_epoch={int(k): int(v) for k, v in per_ep.items()})
    it("valid_class_values", final.reference_label.isin(list(IG.CLASSES) + [""]).all() and long.dominant_class.isin(list(IG.CLASSES) + [""]).all())
    it("valid_epochs", set(final.epoch.astype(int)) <= set(IG.EPOCHS), epochs=sorted(int(e) for e in final.epoch.unique()))
    ii = irep.get("info", {}).get("interpreters", {})
    it("valid_distinct_interpreter_ids", bool(ii.get("A")) and bool(ii.get("B")) and ii.get("A") != ii.get("B"), interpreters=ii)
    kx = K.set_index("anon_id")[["x_utm", "y_utm"]]; fx = final.drop_duplicates("anon_id").set_index("anon_id")[["x_utm", "y_utm"]].loc[kx.index]
    it("coordinates_unchanged", bool(np.allclose(fx.values, kx.values)), note="form lat/lon vs key also checked by ingestion (COORDINATES_CHANGED)")
    allowed = {"anon_id", "lat", "lon"} | {f"{f}_{e}" for e in IG.EPOCHS for f in IG.FIELDS}; extra = {}
    for d in ("raw_interpreter_A", "raw_interpreter_B"):
        for p in (base / d).glob("*.csv"):
            cols = set(pd.read_csv(p, nrows=0).columns); bad = sorted(cols - allowed)
            if bad: extra[p.name] = bad
    it("no_prohibited_or_leakage_fields", not extra, extra_columns=extra, enforced_by_ingestion=["SCHEMA", "FORBIDDEN_SOURCE", "NOT_BLIND", "NOT_HUMAN", "META_*"])
    dbl = set(K.anon_id[K.double_interpretation.astype(bool)]); bids = set(long.anon_id[long.interpreter_role == "B"])
    it("double_interpretation_subset_complete", bids == dbl, n_required=len(dbl), n_B=len(bids))
    ag = {int(e): AG.agreement(final, long, int(e)) for e in sorted(final.epoch.unique())}
    it("disagreement_statistics_generated", len(ag) > 0, per_epoch=ag)
    lab = final.groupby("epoch").labelled.mean().to_dict()
    it("required_epochs_labelled_ge_0.80", all(lab.get(e, 0) >= 0.8 for e in KINDS[kind]["required_epochs"]), labelled_share={int(k): round(float(v), 4) for k, v in lab.items()})
    if kind == "training":
        cb = {}
        for (sp_, e), f in final[final.in_accuracy_set].groupby(["split", "epoch"]): cb[f"{sp_}/{int(e)}"] = f.reference_label.value_counts().to_dict()
        it("class_balance_reported", True, counts=cb, note="legend classes per split/epoch; bare_sparse/other are not training labels (addendum-1)")
        grid = grid or json.loads((IG.GOLD / "sampling_design/design.json").read_text())["grid"]
        xy = final.drop_duplicates("anon_id")[["anon_id", "x_utm", "y_utm"]]
        if spatial is not None and not isinstance(spatial, str):
            la = AG.audit_training_labels(xy, spatial, IG.load_key(IG.GOLD, "gold") if (IG.GOLD / IG.KEYS["gold"]).exists() else K, grid)
            it("spatial_leakage_audit", la["ok"], **{k: v for k, v in la.items() if k != "ok"})
        sk = K.set_index("anon_id"); d_tun = sk.loc[xy.anon_id, "dist_to_tuning_block_m"].values; spl = sk.loc[xy.anon_id, "split"].values
        it("training_tuning_separation", bool(((spl == "tuning") & (d_tun > 0)).sum() == 0 and ((spl == "train") & (d_tun < 2000)).sum() == 0),
           note="design distances (key); ingestion re-checks against tuning_blocks_30m.tif and fails if it is missing")
    return V

def freeze_labels(kind: str, frozen_by: str, base: Path | None = None, audit_out: Path | None = None, mdir: Path | None = None, report: Path | None = None,
                  spatial="load", kit_manifest: Path = ROOT / "results/phase6/kit_manifest.json", grid: dict | None = None) -> dict:
    C = KINDS[kind]; base = Path(base or C["base"]); audit_out = Path(audit_out or C["audit_out"])
    mdir = Path(mdir or ROOT / "results/phase7/manifests" / C["tag"]); mdir.mkdir(parents=True, exist_ok=True)
    report = Path(report or ROOT / f"docs/phase7_{C['tag']}_freeze_report.md")
    raw = _raw_files(base); vers = _versions(mdir); prev = json.loads(vers[-1].read_text()) if vers else None
    kits = json.loads(Path(kit_manifest).read_text())["kits"] if Path(kit_manifest).exists() else {}
    M = {"label_set": C["label"], "kind": kind, "created_utc": utcnow(), "git_head": _git(), "frozen_by": frozen_by, "base": str(base.relative_to(ROOT)) if base.is_relative_to(ROOT) else str(base),
         "key_sha256": sha(base / IG.KEYS[kind]), "design_sha256": sha(base / C["design"]), "kits_sha256": {k: kits.get(k, {}).get("sha256") for k in C["kit"]},
         "code_sha256": {p: sha(ROOT / p) for p in ("src/validation/ingest_gold.py", "src/validation/audit_gold.py", "scripts/phase7_label_freeze.py")}, "raw_files": raw}
    if not raw["raw_interpreter_A"]:
        M.update(status="NOT_AVAILABLE", reason=f"no interpreter-A form in {M['base']}/raw_interpreter_A: no human {C['label']} labels exist; nothing ingested or frozen")
        res = {"manifest": M, "verification": {}, "audit": None}
    else:
        try:
            audit = AG.run(gold=base, out=audit_out, spatial=spatial) if kind == "gold" else AG.run_t1(t1=base, out=audit_out, spatial=spatial)
        except Exception as e:                                     # never swallow: record and stop
            audit = {"ingest": "FAIL", "ingest_error": repr(e)}
        if audit.get("ingest") != "PASS":
            M.update(status="INGEST_FAIL", reason=str(audit.get("ingest_error"))[:2000]); res = {"manifest": M, "verification": {}, "audit": audit}
        else:
            od = base / "ingested"; final = pd.read_csv(od / "gold_reference_labels.csv", dtype={"confidence_1to3": str}, keep_default_na=False)
            final["epoch"] = final.epoch.astype(int)
            for c in ("labelled", "abstained", "in_accuracy_set"): final[c] = final[c].astype(str).str.lower().eq("true")
            long = pd.read_csv(od / "gold_long_all_interpreters.csv", dtype={"confidence_1to3": str}, keep_default_na=False); long["epoch"] = long.epoch.astype(int)
            irep = json.loads((od / "validation_report.json").read_text())
            sp_obj = IG.load_spatial(IG.GOLD) if spatial == "load" else spatial
            V = verify(kind, base, final, long, irep, sp_obj, grid)
            fz = sorted(str(p.relative_to(base)) for p in (base / "metadata").glob("freeze_*.json"))
            cr = sorted(str(p.relative_to(base)) for p in (base / "metadata").glob("correction_*.json"))
            M.update(raw_sha256={f: sha(base / f) for d in raw.values() for f in d}, freeze_records_sha256={f: sha(base / f) for f in fz}, correction_records_sha256={f: sha(base / f) for f in cr},
                     ingested_sha256={p.name: sha(p) for p in sorted(od.glob("*")) if p.is_file()}, dataset_sha256=sha(od / "gold_reference_labels.csv"),
                     n_points=int(final.anon_id.nunique()), epochs=sorted(int(e) for e in final.epoch.unique()), ingest_warnings=[w.get("code") for w in irep.get("warnings", [])],
                     g2=(audit.get("g2") or {}).get("status") if kind == "gold" else None, verification_ok=all(v["ok"] for v in V.values()))
            if not M["verification_ok"]:
                M.update(status="VERIFICATION_FAIL", reason="; ".join(k for k, v in V.items() if not v["ok"]))
            elif prev and prev.get("status") == "FROZEN" and prev.get("dataset_sha256") == M["dataset_sha256"]:
                M.update(status="FROZEN", version=prev["version"], unchanged_since=prev["created_utc"])
            else:
                M.update(status="FROZEN", version=(prev or {}).get("version", 0) + 1 if (prev or {}).get("status") == "FROZEN" else 1,
                         supersedes=({"version": prev["version"], "dataset_sha256": prev["dataset_sha256"], "reason": "ingested table changed: new frozen passes and/or signed correction records (ingestion-enforced)"}
                                     if prev and prev.get("status") == "FROZEN" else None))
            res = {"manifest": M, "verification": V, "audit": {k: audit.get(k) for k in ("ingest", "g2", "description", "description_by_split") if k in audit}}
    M["verification"] = res["verification"]
    if M["status"] == "FROZEN" and not (prev and prev.get("dataset_sha256") == M["dataset_sha256"] and prev.get("status") == "FROZEN"):
        out = mdir / f"manifest_v{M['version']}.json"
        if out.exists(): raise RuntimeError(f"{out} exists - frozen manifests are never overwritten")
        out.write_text(json.dumps(M, indent=1, default=str))
    (mdir / "status_latest.json").write_text(json.dumps(M, indent=1, default=str))
    _report(report, M, res, C)
    return res

def _report(path: Path, M: dict, res: dict, C: dict):
    L = [f"# Phase 7 — {C['label']} freeze report", "", f"_Generated {M['created_utc']} by `scripts/phase7_label_freeze.py --kind {M['kind']}` (git `{M['git_head'][:7]}`)._", "",
         f"## STATUS: **{M['status']}**" + (f" (version {M.get('version')})" if M["status"] == "FROZEN" else ""), ""]
    if M["status"] == "NOT_AVAILABLE":
        L += [M["reason"] + ".", "", "No label was created, inferred or filled. The confirmatory experiments that need this label set stay DO NOT RUN.", "",
              "## What exists (unchanged, hash-verified)", "", "| item | SHA-256 |", "|---|---|", f"| key (evaluator only) | `{M['key_sha256']}` |", f"| design | `{M['design_sha256']}` |"]
        L += [f"| kit {k} | `{v}` |" for k, v in M["kits_sha256"].items()]
        L += ["", "## Procedure when the interpreters return the forms", "",
              f"1. Interpreter A's form → `{M['base']}/raw_interpreter_A/`, B's → `raw_interpreter_B/`, each with its `.meta.json` (template in the kit).",
              f"2. `python3 src/validation/ingest_gold.py{' --kind training' if M['kind'] == 'training' else ''} freeze pass1 --by <evaluator>` (SHA-256 of the raw files; immutable).",
              "3. Disagreements on double points with a definite class → blind adjudication file in `adjudicated/`, then freeze it as a new pass.",
              f"4. `python3 scripts/phase7_label_freeze.py --kind {M['kind']} --frozen-by <evaluator>` → this report, the verification list and `results/phase7/manifests/{C['tag']}/manifest_v1.json`.",
              "5. Genuine recording errors after freezing: only a signed correction record (`metadata/correction_<role>_<pass>.json`); a re-frozen raw file without it is rejected (RAW_REFROZEN)."]
    elif M["status"] in ("INGEST_FAIL",):
        L += ["Ingestion stopped on protocol violations (nothing frozen):", "", "```", M["reason"], "```"]
    else:
        L += ["| verification | result | detail |", "|---|---|---|"]
        for k, v in res["verification"].items():
            L.append(f"| {k} | {'PASS' if v['ok'] else '**FAIL**'} | {json.dumps({a: b for a, b in v.items() if a != 'ok'}, default=str)[:300].replace('|', '/')} |")
        if M["status"] == "FROZEN":
            L += ["", f"Dataset SHA-256 (ingested reference table): `{M['dataset_sha256']}`; G2: {M.get('g2')}.", "", "Once frozen: no edits. Corrections only through signed correction records and a new frozen pass; a new manifest version then references this one."]
    path.write_text("\n".join(L) + "\n")

if __name__ == "__main__":
    ap = argparse.ArgumentParser(description=__doc__.split("\n")[0]); ap.add_argument("--kind", choices=list(KINDS), required=True); ap.add_argument("--frozen-by", required=True)
    a = ap.parse_args(); r = freeze_labels(a.kind, a.frozen_by)
    print(json.dumps({k: r["manifest"].get(k) for k in ("label_set", "status", "version", "dataset_sha256", "reason")}, indent=1, default=str)); sys.exit(0 if r["manifest"]["status"] in ("FROZEN", "NOT_AVAILABLE") else 1)
