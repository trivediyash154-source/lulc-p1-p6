"""Phase 7 (restoration): regenerate the three gitignored WINDOW silver L1 rasters (data/labels/pune_G30_<window>/silver_l1.tif) needed as the
reference of the district-silver validation, with the window code path (L1 fractions of WorldCover/Esri 2020-21 on the window extent + the
unanimous purity rule), and accept a window only if its L1 class counts equal the ORIGINAL window metadata (silver_labels.json, Phase 1) exactly.
Writes results/phase7/restore/window_silver_restore.json; never writes a window whose counts differ."""
import json, sys
import numpy as np
sys.path.insert(0, "src")
from pune_eo import config
from pune_eo.grid import district_grid, Grid
from pune_eo.io import write_cog
from pune_eo.labels import district_silver as DS
from pune_eo.provenance import utcnow
G = district_grid("G30"); sc = config.load("labels")["silver_consensus"]; names = config.load("labels")["level1_classes"]; R = {"created_utc": utcnow(), "windows": {}}
for w in ("khadakwasla_mutha", "baramati_agri", "mulshi_ghats"):
    d = config.path("data/labels", f"pune_G30_{w}"); meta = json.loads((d / "silver_labels.json").read_text()); gj = meta["grid"]
    wg = Grid(gj["id"], gj["crs"], gj["res"], gj["x0"], gj["y1"], gj["width"], gj["height"], gj["corner_offset"])
    fr, used = DS.fetch_fractions(wg, list(sc["sources"])); l1 = DS.silver_rule(fr, float(sc["min_purity"]))
    counts = {names[i]: int((l1 == i).sum()) for i in range(1, 7)}; orig = meta["stats"]["l1_counts"]; ok = counts == orig and int((l1 > 0).sum()) == meta["stats"]["labelled"]
    R["windows"][w] = {"ok": ok, "counts": counts, "original_counts": orig, "items": used, "original_items": json.loads((d / "landcover_sources.json").read_text())["sources"]}
    if ok: write_cog(d / "silver_l1.tif", l1, wg, nodata=None, dtype="uint8", descriptions=["silver_l1_0_unlabelled"], overview_resampling="nearest")
R["ok"] = all(v["ok"] for v in R["windows"].values())
config.path("results/phase7/restore").mkdir(parents=True, exist_ok=True); config.path("results/phase7/restore/window_silver_restore.json").write_text(json.dumps(R, indent=1))
print(json.dumps({w: (v["ok"], v["counts"]) for w, v in R["windows"].items()}, indent=1)); sys.exit(0 if R["ok"] else 1)
