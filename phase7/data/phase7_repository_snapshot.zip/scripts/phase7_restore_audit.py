"""Phase 7 RESTORATION AUDIT: after the session container was reclaimed (2026-10-03), the repository was restored from the Phase-6 snapshot
(/mnt/user-data/outputs/phase6) and the Phase-7 code re-applied from the session transcript. This audit proves that the restored repository is the
frozen Phase-6 state (plus the reconstructed Phase-7 code) wherever the evidence allows, and states what could not be re-verified.
Writes results/phase7/restore/restore_audit.json and docs/phase7_entry_audit.md (original Phase-7 entry audit, transcribed, + this audit)."""
import glob, hashlib, json, subprocess, sys
from pathlib import Path
import numpy as np, pandas as pd, rasterio
from scipy.ndimage import distance_transform_edt
from scipy.spatial import cKDTree
sys.path.insert(0, "src")
from pune_eo import config
from pune_eo.evaluation4 import protocol as P4
from pune_eo.provenance import utcnow
def sha(p):
    p = config.path(p) if not Path(p).is_absolute() else Path(p); return hashlib.sha256(p.read_bytes()).hexdigest() if p.exists() else None
def J(p): return json.loads(config.path(p).read_text()) if config.path(p).exists() else None
def rd(p):
    with rasterio.open(config.path(p)) as s: return s.read(1)
R = {"created_utc": utcnow(), "checks": {}}
def chk(name, ok, **d): R["checks"][name] = {"ok": bool(ok), **d}
fz = P4.load_protocol()["frozen"]
chk("protocol_v2_code_hash", P4.code_hash() == fz["code_sha256"] == "3bb40f9c982d601db88f75913f7d00acb4944136a3f9771079b9413ec31a14ab", value=P4.code_hash())
chk("protocol_v2_yaml_hash", P4.protocol_hash() == fz["protocol_sha256"] == "fe1fad6f8b8eda1618302d6886ab8d90fbb65aefdf6da17f961aee93144cbdbe", value=P4.protocol_hash())
cc = P4.check_confirmatory_records(); chk("registry_G8_check_confirmatory_records", cc["ok"], n=len(cc["records"]))
chk("confirmatory_records_all_PENDING", all(P4.load(f"P4-C{i}@v2")["status"] == "PENDING" for i in range(1, 7)))
man = J("results/phase6/reproducibility_manifest.json")
diff = {k: (v[:12], (sha(k) or "MISSING")[:12]) for k, v in {**man["code_sha256"], **man["datasets_and_configs_sha256"]}.items() if sha(k) != v}
chk("phase6_manifest_files_unchanged (restored snapshot)", not diff, n=len(man["code_sha256"]) + len(man["datasets_and_configs_sha256"]), differences=diff)
rdiff = {k: v[:12] for k, v in man["registry_records_sha256"].items() if sha(f"experiments/registry4/{k}.json") != v}
chk("registry_records_unchanged", not rdiff, n=len(man["registry_records_sha256"]), differences=rdiff)
FRO = {"data/labels/gold/phase4/_key/phase4_gold_key.csv": "42aaf33cfcdd9f836d606c3d0d9f27379222b15d05d09780a49ce6616f65b95e", "data/labels/gold/phase4/sampling_design/design.json": "acc8692a3203944d7d791802b00c799dba75d82768db68d71a4c642608b48dd6",
       "data/labels/training/phase6_T1v2/_key/T1_key.csv": "62868f8da968db6ba55595c1127630433097f3dde5a42960425d427548c955fd", "data/labels/training/phase6_T1v2/sampling_design/design.json": "4058193bc6da90d81c42604a4834c0ef049d3f61c33b91236adb955e1d7d953e",
       "experiments/registry4/addenda/P4-C1_at_v2_addendum_1.json": "db13cfae510bb5b04bb748fbcd95729f14faf55fd844fb397599faf73cd4c0ea", "experiments/registry4/addenda/P4-C1_at_v2_addendum_1_erratum_1.json": "6f13897f6e2128febb79b8bf46472a56dbeb352c0786d9beae6278a1bea41d4d",
       "experiments/registry4/addenda/P4-C2_at_v2_addendum_1.json": "c000e80c3c5beea0a446d8caa4eacd144124c485336478b51ab35be9b058cd82", "experiments/registry4/addenda/P4-C2_at_v2_addendum_1_erratum_1.json": "d78feae7b97ccce3c6dd2ed050e08da4956fe0889ba3ce19c3fcbe678dfbb393",
       "results/harmonization/c2_tm_pif_v1.yaml": "782eaef3e95c9dbe4b79868d936fd1e96ff1aa681d93ad609b5463ddd119db47"}
chk("frozen_hashes_recorded_in_the_original_phase7_audit", all(sha(k) == v for k, v in FRO.items()), mismatches=[k for k, v in FRO.items() if sha(k) != v])
km = J("results/phase6/kit_manifest.json")["kits"]
chk("phase6_kits_unchanged (outputs/phase6/kits)", all(sha(Path("/mnt/user-data/outputs/phase6/kits", v["zip"])) == v["sha256"] for v in km.values()))
sc = J("results/phase7/restore/spatial_context_restore.json") or {}; ws = J("results/phase7/restore/window_silver_restore.json") or {}
chk("spatial_context_restored_pixel_exact", sc.get("status", "").startswith("RESTORED"), files={k: v["byte_identical_to_frozen"] for k, v in sc.get("files", {}).items()})
chk("window_silver_restored_with_original_counts", ws.get("ok") is True)
K = pd.read_csv(config.path("data/labels/gold/phase4/_key/phase4_gold_key.csv")); T = pd.read_csv(config.path("data/labels/training/phase6_T1v2/_key/T1_key.csv"))
vb, te = rd("data/labels/gold/phase4/sampling_design/validation_blocks_30m.tif").astype(bool), rd("data/labels/gold/phase4/sampling_design/training_eligible_30m.tif").astype(bool)
tun, trn = rd("data/labels/training/phase6_T1v2/sampling_design/tuning_blocks_30m.tif").astype(bool), rd("data/labels/training/phase6_T1v2/sampling_design/train_eligible_T1_30m.tif").astype(bool)
dte = distance_transform_edt(~te) * 30.0; dv = distance_transform_edt(~vb) * 30.0; dt = distance_transform_edt(~tun) * 30.0
chk("gold_design_rechecked", len(K) == 641 and K.anon_id.is_unique and not K.duplicated(["row", "col"]).any() and K.block.nunique() == 125 and bool(vb[K.row, K.col].all()) and float(dte[K.row, K.col].min()) >= 2000,
    n=len(K), blocks=int(K.block.nunique()), min_gold_to_training_eligible_m=float(dte[K.row, K.col].min()))
ktr, ktu = T[T.split == "train"], T[T.split == "tuning"]; dg = cKDTree(K[["x_utm", "y_utm"]].values).query(T[["x_utm", "y_utm"]].values)[0]
chk("T1_partition_and_separation", bool(tun[ktu.row, ktu.col].all() and trn[ktr.row, ktr.col].all() and (dt[ktr.row, ktr.col] >= 2000).all() and te[T.row, T.col].all() and (dv[T.row, T.col] >= 2000).all() and (dg >= 2000).all()),
    n=len(T), split=T.split.value_counts().to_dict(), n_double=int(T.double_interpretation.sum()), min_train_to_tuning_m=float(dt[ktr.row, ktr.col].min()), min_T1_to_validation_block_m=float(dv[T.row, T.col].min()), min_T1_to_gold_m=float(dg.min()))
lab = {d: len(list(config.path(d).glob("*.csv"))) for d in ("data/labels/gold/phase4/raw_interpreter_A", "data/labels/gold/phase4/raw_interpreter_B", "data/labels/training/phase6_T1v2/raw_interpreter_A")}
chk("no_human_label_files (as at the original entry)", sum(lab.values()) == 0, files=lab)
run = subprocess.run([sys.executable, "-m", "pytest", "-q", "-p", "no:cacheprovider", "tests"], capture_output=True, text=True, cwd=config.ROOT).stdout.strip().splitlines()[-1]
chk("tests_pass", "passed" in run and "failed" not in run and "error" not in run, result=run, note="the original 151 = 146 passed + 5 skipped here (skips need gitignored data: Landsat manifest parquet, district products, window fraction files)")
R["not_reverified"] = {"git history of Phases 1-6": "not part of the Phase-6 snapshot (snapshot of git 7b85b69)", "strata_30m.tif": "needs every district product (not restored)",
                       "Phase-5 entry-check items on products/cube pilot": "gitignored products not restored (pilot composites, district products, Landsat manifest parquet)",
                       "byte identity of training_eligible_30m.tif / district_mask_30m.tif": "pixel identity proven instead (COG bytes depend on the GDAL version)"}
hard = [k for k, v in R["checks"].items() if not v["ok"]]; R["status"] = "OK - frozen state restored where verifiable" if not hard else "STOP - restored state differs"; R["failed"] = hard
config.path("results/phase7/restore/restore_audit.json").write_text(json.dumps(R, indent=1, default=str))
orig = config.path("results/phase7/restore/original_entry_audit_transcribed.md").read_text()
L = ["# Phase 7 — entry audit", "", "## Part A — original Phase-7 entry audit (2026-10-02T18:48:24Z), transcribed verbatim from the session record", "",
     "The original file was lost when the session container was reclaimed on 2026-10-03. The text below is the tool output that displayed it; the lines after the T1-design hash were not displayed and are not reproduced.", "",
     "> " + "\n> ".join(orig.strip().splitlines()), "", f"## Part B — restoration audit ({R['created_utc']})", "",
     "The repository was restored from `/mnt/user-data/outputs/phase6/phase6_repository_snapshot.zip` (git 7b85b69) + the evaluator keys, and the Phase-7 code was re-applied from the session transcript (`docs/phase7_execution_log.md`).", "",
     f"### RESULT: **{R['status']}**", "", "| check | result | detail |", "|---|---|---|"]
for k, v in R["checks"].items(): L.append(f"| {k} | {'PASS' if v['ok'] else '**FAIL**'} | {json.dumps({a: b for a, b in v.items() if a != 'ok'}, default=str)[:260].replace('|', '/')} |")
L += ["", "### Not re-verifiable after the restoration", ""] + [f"* **{k}**: {v}" for k, v in R["not_reverified"].items()]
config.path("docs/phase7_entry_audit.md").write_text("\n".join(L) + "\n")
print(R["status"], hard)
