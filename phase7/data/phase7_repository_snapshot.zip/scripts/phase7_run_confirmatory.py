"""Phase 7 confirmatory runner CLI (src/pune_eo/confirmatory). Never overrides a check.
    python3 scripts/phase7_run_confirmatory.py --preflight            # all six records: RUNNABLE / DO NOT RUN with every failed precondition
    python3 scripts/phase7_run_confirmatory.py P4-C1@v2 --threads 8   # run ONE record (refused unless every precondition holds)"""
import argparse, json, sys
sys.path.insert(0, "src")
from pune_eo import config
from pune_eo.confirmatory import Refusal, runner
from pune_eo.provenance import utcnow
if __name__ == "__main__":
    ap = argparse.ArgumentParser(); ap.add_argument("eid", nargs="?"); ap.add_argument("--preflight", action="store_true"); ap.add_argument("--threads", type=int, default=2); a = ap.parse_args()
    if a.preflight or not a.eid:
        r = runner.preflight_all(); o = config.path("results/phase7/runner_preflight.json"); o.write_text(json.dumps({"created_utc": utcnow(), "records": r}, indent=1, default=str))
        for e, v in r.items(): print(e, v["decision"], list(v["failed"]))
        sys.exit(0)
    try: print(json.dumps(runner.run(a.eid, a.threads), indent=1, default=str))
    except Refusal as e: print(str(e), file=sys.stderr); sys.exit(2)
