"""Phase 7 / Stage 8: REGISTER the confirmatory runner implementation (SHA-256 of every runner file) BEFORE any label exists.
    python3 scripts/phase7_register_runner.py                      # first registration
    python3 scripts/phase7_register_runner.py --amend "<reason>"   # any later code change = a registered amendment (new version, reason, label state)
The runner refuses to run if its code differs from the latest registered version (guards.preflight: implementation_registration)."""
import argparse, json, subprocess, sys
sys.path.insert(0, "src")
from pune_eo import config
from pune_eo.confirmatory import guards as GU
from pune_eo.provenance import utcnow
P = config.path(GU.REGISTRATION)
if __name__ == "__main__":
    ap = argparse.ArgumentParser(); ap.add_argument("--amend", default=None); a = ap.parse_args()
    cur = GU.implementation_hashes(); old = json.loads(P.read_text()) if P.exists() else None
    if old and old["files_sha256"] == cur: print("registration up to date"); sys.exit(0)
    if old and not a.amend: sys.exit("runner code changed since registration: re-register only with --amend '<reason>' (recorded with the label state)")
    t = subprocess.run([sys.executable, "-m", "pytest", "-q", "tests/test_confirmatory_runner.py"], capture_output=True, text=True, cwd=config.ROOT).stdout.strip().splitlines()[-1]
    if "failed" in t or "error" in t or "passed" not in t: sys.exit(f"runner tests do not pass: {t}")
    labels = {k: (GU.label_manifest(k) or {}).get("status", "NOT_AVAILABLE") for k in ("gold", "T1", "silver")}
    v = {"version": (old["version"] + 1) if old else 1, "registered_utc": utcnow(), "git_head_at_registration": subprocess.run(["git", "rev-parse", "HEAD"], capture_output=True, text=True).stdout.strip(),
         "files_sha256": cur, "tests": t, "label_state_at_registration": labels, "pre_data": labels["gold"] != "FROZEN" and labels["T1"] != "FROZEN",
         "implements": {"P4-C1@v2": "full pipeline", "P4-C2@v2": "full pipeline", "P4-C3@v2..P4-C6@v2": "guards only (NOT_IMPLEMENTED until their specification is adopted)"},
         "specification": "docs/phase7_runner_specification.md (PROPOSED addenda; the runner refuses a record until its addendum is adopted and countersigned)", "amendment_reason": a.amend}
    body = {"files_sha256": cur, "version": v["version"], "registered_utc": v["registered_utc"], "history": (old or {}).get("history", []) + [v]}
    P.write_text(json.dumps(body, indent=1)); print(json.dumps({k: v[k] for k in ("version", "registered_utc", "tests", "label_state_at_registration", "pre_data")}, indent=1))
