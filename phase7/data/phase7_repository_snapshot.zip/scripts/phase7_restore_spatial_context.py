"""Phase 7 (restoration after the session container was reclaimed): regenerate ONLY the gitignored spatial-context rasters that the label
ingestion, the runner and the audits read, and PROVE they equal the frozen originals - without touching the gold key, design, forms or T1 design.
(Re-running scripts/phase4_validation_design.py would rewrite the pinned key/forms/design: never do that.)

  district_mask_30m.tif       = rasterised study_area.gpkg on pune_G30 (code of phase4_products_acquire.py 'grid')
                                check: cells inside == district_grid.json cells_inside (17 380 093)
  validation_blocks_30m.tif   = 6 km hashed blocks, salt phase4-v1, hash % 100 < 30, inside the district (code of phase4_validation_design.py)
                                check: share of district == design.json validation_block_share_of_district; all 641 gold points inside
  training_eligible_30m.tif   = district cells >= 2 km from every validation block (EDT on the 30 m lattice; the rule documented in Phases 4-6)
                                PIXEL-EXACT check: the committed Phase-6 T1 rasters were derived from it - tuning_blocks_30m.tif must equal
                                (tuning 6 km blocks & eligible) and train_eligible_T1_30m.tif must equal (eligible & ~tuning & >= 2 km from tuning);
                                share == training_eligibility.json training_eligible_share_of_district
  strata_30m.tif              = NOT restored (needs every district product); the gold key carries each point's stratum.
Writes results/phase7/restore/spatial_context_restore.json. Refuses to keep a raster whose check fails (it is deleted and reported)."""
import hashlib, json, sys
import numpy as np, rasterio
from scipy.ndimage import distance_transform_edt
sys.path.insert(0, "src")
from pune_eo import config
from pune_eo.grid import district_grid
from pune_eo.io import write_cog
from pune_eo.provenance import utcnow
G = district_grid("G30"); PX = config.path("data/products_ext"); SD = config.path("data/labels/gold/phase4/sampling_design"); T1 = config.path("data/labels/training/phase6_T1v2/sampling_design")
FROZEN_SHA = {"validation_blocks_30m.tif": "66ceb88e422105899d81ebbe5cfa378b329577fb9d64a4576540371f607844bf", "training_eligible_30m.tif": "b0f929001919c76075ca5719d2a670832f651b3a3a246a9468cfe130b88baa2d"}
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
def rd(p):
    with rasterio.open(p) as s: return s.read(1)
R = {"created_utc": utcnow(), "checks": {}, "files": {}}
def chk(name, ok, **d): R["checks"][name] = {"ok": bool(ok), **d}
# district mask
import geopandas as gpd
from rasterio.features import rasterize
ba = gpd.read_file(config.path("data/boundary/study_area.gpkg")).to_crs(G.crs)
mask = rasterize([(g, 1) for g in ba.geometry], out_shape=G.shape, transform=G.transform, fill=0, dtype="uint8").astype(bool)
exp = json.loads((PX / "district/district_grid.json").read_text())["cells_inside"]
chk("district_mask_cells_inside", int(mask.sum()) == exp, found=int(mask.sum()), expected=exp)
# validation blocks
bx = ((np.arange(G.shape[1]) * 30 + G.x0) // 6000).astype(int); by = ((G.y1 - np.arange(G.shape[0]) * 30) // 6000).astype(int); ubx, uby = np.unique(bx), np.unique(by)
tab = np.array([[int(hashlib.sha256(f"phase4-v1:{a}:{b}".encode()).hexdigest(), 16) % 100 for a in ubx] for b in uby], np.uint8)
vb = (tab[np.searchsorted(uby, by)][:, np.searchsorted(ubx, bx)] < 30) & mask
design = json.loads((SD / "design.json").read_text())
chk("validation_block_share", abs(float(vb[mask].mean()) - design["validation_block_share_of_district"]) < 1e-12, found=float(vb[mask].mean()), expected=design["validation_block_share_of_district"])
import pandas as pd
K = pd.read_csv(config.path("data/labels/gold/phase4/_key/phase4_gold_key.csv"))
chk("all_gold_points_in_validation_blocks", bool(vb[K.row.values, K.col.values].all()), n=len(K))
# training eligible
elig = mask & (distance_transform_edt(~vb) * 30.0 >= 2000.0)
te_json = json.loads((SD / "training_eligibility.json").read_text())
chk("training_eligible_share", abs(float(elig[mask].mean()) - te_json["training_eligible_share_of_district"]) < 1e-12, found=float(elig[mask].mean()), expected=te_json["training_eligible_share_of_district"])
d = distance_transform_edt(~elig) * 30.0
chk("gold_point_min_distance_to_eligible", abs(float(d[K.row.values, K.col.values].min()) - te_json["point_distance_to_training_eligible_m"]["min"]) < 1e-9, found=float(d[K.row.values, K.col.values].min()))
tt = np.array([[int(hashlib.sha256(f"phase5-tuning-v1:{a}:{b}".encode()).hexdigest(), 16) % 100 < 25 for a in ubx] for b in uby])
tuning_cell = tt[np.searchsorted(uby, by)][:, np.searchsorted(ubx, bx)] & elig
tun_orig, trn_orig = rd(T1 / "tuning_blocks_30m.tif").astype(bool), rd(T1 / "train_eligible_T1_30m.tif").astype(bool)
chk("pixel_exact_vs_committed_T1_tuning_raster", bool((tuning_cell == tun_orig).all()), n_diff=int((tuning_cell != tun_orig).sum()))
train = elig & ~tuning_cell & (distance_transform_edt(~tuning_cell) * 30.0 >= 2000.0)
chk("pixel_exact_vs_committed_T1_train_raster", bool((train == trn_orig).all()), n_diff=int((train != trn_orig).sum()))
ok = all(v["ok"] for v in R["checks"].values())
(PX / "district").mkdir(parents=True, exist_ok=True); SD.mkdir(parents=True, exist_ok=True)
out = {PX / "district/district_mask_30m.tif": (mask, ["inside_district"]), SD / "validation_blocks_30m.tif": (vb, ["validation_block"]), SD / "training_eligible_30m.tif": (elig, ["training_eligible"])}
for p, (a, desc) in out.items():
    if ok:
        write_cog(p, a.astype(np.uint8), G, nodata=None, dtype="uint8", descriptions=desc, overview_resampling="nearest")
        R["files"][str(p.relative_to(config.ROOT))] = {"sha256": sha(p), "frozen_sha256": FROZEN_SHA.get(p.name), "byte_identical_to_frozen": (sha(p) == FROZEN_SHA[p.name]) if p.name in FROZEN_SHA else None}
    elif p.exists(): p.unlink()
R["status"] = "RESTORED (pixel-exact checks passed)" if ok else "FAILED - rasters not restored"
R["not_restored"] = {"strata_30m.tif": "needs every district product (phase4_products_acquire.py); gold key carries the stratum of every point; only the Phase-5 entry check design_stratum_matches_raster depends on it"}
R["note"] = "byte identity is not required: COG bytes depend on the GDAL/rasterio version; pixel identity is proven against the committed Phase-6 T1 rasters and recorded statistics"
config.path("results/phase7/restore").mkdir(parents=True, exist_ok=True); config.path("results/phase7/restore/spatial_context_restore.json").write_text(json.dumps(R, indent=1))
print(R["status"]); print(json.dumps({k: v["ok"] for k, v in R["checks"].items()}, indent=1)); print(json.dumps(R["files"], indent=1)); sys.exit(0 if ok else 1)
