"""Phase 7 / Stage 1: REFREEZE AUDIT - verifies that the repository is exactly at the Phase-6 frozen state before any Phase-7 change. Read-only except
for results/phase7/entry_audit.json and docs/phase7_entry_audit.md. Any difference is REPORTED (status STOP), never repaired.
Reference = results/phase6/reproducibility_manifest.json (generated at clean HEAD 48fbfca, committed in 7b85b69) + the frozen protocol block.
Spatial re-checks: results/phase7/entry/entry_checks.json (the Phase-5 entry-check code, unchanged, re-run with its output redirected) + T1 v2 partition."""
import glob, hashlib, json, subprocess, sys
from pathlib import Path
import numpy as np, pandas as pd
sys.path.insert(0, "src")
from pune_eo import config
from pune_eo.evaluation4 import protocol as P4
from pune_eo.provenance import utcnow
PHASE6_HEAD = "7b85b69"
git = lambda *a: subprocess.run(["git", *a], capture_output=True, text=True, cwd=config.ROOT).stdout.strip()
def sha(p):
    p = config.path(p); return hashlib.sha256(p.read_bytes()).hexdigest() if p.exists() else None
R = {"created_utc": utcnow(), "checks": {}}
def chk(name, ok, **d): R["checks"][name] = {"ok": bool(ok), **d}

head = git("rev-parse", "HEAD"); status = [l for l in git("status", "--porcelain").splitlines() if l]
own = {"?? scripts/phase7_entry_audit.py", "?? results/phase7/"}            # this audit's own outputs
chk("commit_is_phase6_final", head.startswith(PHASE6_HEAD), head=head)
chk("working_tree_clean", all(l in own for l in status), status=status)
fz = P4.load_protocol()["frozen"]
chk("protocol_v2_code_hash", P4.code_hash() == fz["code_sha256"], value=P4.code_hash())
chk("protocol_v2_yaml_hash", P4.protocol_hash() == fz["protocol_sha256"], value=P4.protocol_hash())
chk("protocol_files_unchanged_since_phase4", git("diff", "--stat", "ffa1ee0..HEAD", "--", "configs/phase4_evaluation_protocol.yaml", "src/pune_eo/evaluation4/protocol.py") == "")
cc = P4.check_confirmatory_records(); chk("registry_G8_check_confirmatory_records", cc["ok"], n=len(cc["records"]))
recs = {Path(p).stem: P4.load(Path(p).stem.replace("_at_", "@")) for p in sorted(glob.glob(str(config.path("experiments/registry4/P4-C*_at_v2.json"))))}
chk("confirmatory_records_all_PENDING", all(r["status"] == "PENDING" and r.get("outcome") is None for r in recs.values()), status={k: r["status"] for k, r in recs.items()})
man = json.loads(config.path("results/phase6/reproducibility_manifest.json").read_text())
diff = {k: (v[:12], (sha(k) or "MISSING")[:12]) for k, v in {**man["code_sha256"], **man["datasets_and_configs_sha256"]}.items() if sha(k) != v}
chk("phase6_manifest_files_unchanged", not diff, n=len(man["code_sha256"]) + len(man["datasets_and_configs_sha256"]), differences=diff)
rdiff = {k: v[:12] for k, v in man["registry_records_sha256"].items() if sha(f"experiments/registry4/{k}.json") != v}
chk("registry_records_unchanged", not rdiff, n=len(man["registry_records_sha256"]), differences=rdiff)
A1, E1 = "experiments/registry4/addenda/P4-C1_at_v2_addendum_1.json", "experiments/registry4/addenda/P4-C1_at_v2_addendum_1_erratum_1.json"
A2, E2 = "experiments/registry4/addenda/P4-C2_at_v2_addendum_1.json", "experiments/registry4/addenda/P4-C2_at_v2_addendum_1_erratum_1.json"
ptr = {e: {a["path"]: a["sha256"] for a in P4.load(e).get("addenda", [])} for e in ("P4-C1@v2", "P4-C2@v2")}
chk("D1_addendum_and_erratum_match_record_pointers", ptr["P4-C1@v2"].get(A1) == sha(A1) and ptr["P4-C1@v2"].get(E1) == sha(E1), addendum=sha(A1), erratum=sha(E1))
chk("D2_specification_and_erratum_match_record_pointers", ptr["P4-C2@v2"].get(A2) == sha(A2) and ptr["P4-C2@v2"].get(E2) == sha(E2), specification=sha(A2), erratum=sha(E2))
T = "results/harmonization/c2_tm_pif_v1.yaml"; PIN = "782eaef3e95c9dbe4b79868d936fd1e96ff1aa681d93ad609b5463ddd119db47"
fit = json.loads(config.path("results/phase6/d2/pif_fit_report.json").read_text())
chk("D2_correction_file_frozen", sha(T) == PIN == fit["transform_sha256"] and config.path("results/harmonization/c2_tm_pif_v1.sha256").read_text().split()[0] == PIN and fit["addendum_sha256"] == sha(A2), value=sha(T))
chk("D2_spec_committed_before_fit", git("log", "--format=%h", "--diff-filter=A", "--", A2).split()[-1:] == ["0633008"] and git("log", "--format=%h", "--diff-filter=A", "--", T).split()[-1:] == ["0282f07"])
D = {"gold_design": "data/labels/gold/phase4/sampling_design/design.json", "gold_key": "data/labels/gold/phase4/_key/phase4_gold_key.csv",
     "validation_blocks_raster": "data/labels/gold/phase4/sampling_design/validation_blocks_30m.tif", "training_eligible_raster": "data/labels/gold/phase4/sampling_design/training_eligible_30m.tif",
     "strata_raster": "data/labels/gold/phase4/sampling_design/strata_30m.tif", "T1_design": "data/labels/training/phase6_T1v2/sampling_design/design.json",
     "T1_key": "data/labels/training/phase6_T1v2/_key/T1_key.csv", "T1_tuning_raster": "data/labels/training/phase6_T1v2/sampling_design/tuning_blocks_30m.tif",
     "T1_train_raster": "data/labels/training/phase6_T1v2/sampling_design/train_eligible_T1_30m.tif", "checklist_code": "scripts/phase5_prerun_checklists.py"}
R["hashes"] = {k: sha(v) for k, v in D.items()} | {"protocol_code": P4.code_hash(), "protocol_yaml": P4.protocol_hash(), "D1_addendum": sha(A1), "D1_erratum": sha(E1),
                                                  "D2_specification": sha(A2), "D2_erratum": sha(E2), "D2_correction_file": sha(T)}
add1 = json.loads(config.path(A1).read_text())["T1"]
chk("T1_design_pinned_by_addendum", add1["design_sha256"] == sha(D["T1_design"]) and add1["key_sha256"] == sha(D["T1_key"]))
ec = json.loads(config.path("results/phase7/entry/entry_checks.json").read_text())["checks"]
need = ["design_n_points_641", "design_unique_ids_and_cells", "design_n_blocks_125", "design_points_in_hashed_validation_blocks", "validation_block_raster_matches_reimplementation",
        "training_eligible_cells_ge_2km_from_validation_blocks", "training_eligible_disjoint_from_validation_blocks", "design_points_ge_2km_from_training_eligible",
        "design_points_outside_phase3_windows_plus_2km", "form_A_ids_equal_key", "form_B_is_double_subset", "blind_forms_contain_no_design_fields", "blind_forms_empty"]
chk("validation_design_rechecked (Phase-5 entry-check code, re-run)", all(ec[k]["ok"] for k in need), failed=[k for k in need if not ec[k]["ok"]])
import rasterio
from scipy.ndimage import distance_transform_edt
from scipy.spatial import cKDTree
rd = lambda p: rasterio.open(config.path(p)).read(1).astype(bool)
tun, trn, vb, te = rd(D["T1_tuning_raster"]), rd(D["T1_train_raster"]), rd(D["validation_blocks_raster"]), rd(D["training_eligible_raster"])
K = pd.read_csv(config.path(D["T1_key"])); G = pd.read_csv(config.path(D["gold_key"]))
dt = distance_transform_edt(~tun) * 30.0; dv = distance_transform_edt(~vb) * 30.0
ktr, ktu = K[K.split == "train"], K[K.split == "tuning"]
dg = cKDTree(G[["x_utm", "y_utm"]].values).query(K[["x_utm", "y_utm"]].values)[0]
chk("T1_partition_and_separation", bool(tun[ktu.row, ktu.col].all() and trn[ktr.row, ktr.col].all() and (dt[ktr.row, ktr.col] >= 2000).all() and te[K.row, K.col].all()
                                       and (dv[K.row, K.col] >= 2000).all() and (dg >= 2000).all() and not (trn & tun).any()),
    n=len(K), split=K.split.value_counts().to_dict(), n_double=int(K.double_interpretation.sum()), min_train_to_tuning_m=float(dt[ktr.row, ktr.col].min()),
    min_T1_to_validation_block_m=float(dv[K.row, K.col].min()), min_T1_to_gold_m=float(dg.min()))
km = json.loads(config.path("results/phase6/kit_manifest.json").read_text())["kits"]
chk("phase6_kits_present_and_unchanged", all(hashlib.sha256(Path("/mnt/user-data/outputs/phase6/kits", v["zip"]).read_bytes()).hexdigest() == v["sha256"] for v in km.values()),
    kits={k: (v["zip"], v["n_cells"]) for k, v in km.items()})
exp = {"cube_builder (Landsat strips)": "scripts/phase5_district_cube_pilot.py", "feature_cube_builder": "scripts/phase6_build_feature_cube.py", "feature_cube_validator": "src/data/validate_feature_cube.py",
       "district_cube_validator": "src/data/validate_district_cube.py", "sentinel1_driver": "scripts/phase6_district_s1.py", "terrain_driver": "scripts/phase6_district_terrain.py",
       "gold_ingestion": "src/validation/ingest_gold.py", "gold_audit": "src/validation/audit_gold.py", "prerun_checklists": "scripts/phase5_prerun_checklists.py",
       "district_silver_builder": "scripts/phase7_district_silver.py", "confirmatory_runner": "src/pune_eo/confirmatory/runner.py"}
R["expected_artifacts"] = {k: config.path(v).exists() for k, v in exp.items()}
chk("expected_phase6_code_present", all(v for k, v in R["expected_artifacts"].items() if k not in ("district_silver_builder", "confirmatory_runner")))
R["not_present_at_entry"] = [f"{k} ({exp[k]})" for k, v in R["expected_artifacts"].items() if not v]
docs6 = ["entry_audit", "D1_review", "D2_sensor_correction_decision", "D3_compute_decision", "human_gold_workflow", "T1_training_protocol", "interpreter_protocol", "sentinel1_spec", "execution_status", "readiness_gate"]
chk("phase6_docs_present", all(config.path(f"docs/phase6_{d}.md").exists() for d in docs6))
lab = {d: sorted(p.name for p in config.path(d).glob("*")) for d in ("data/labels/gold/phase4/raw_interpreter_A", "data/labels/gold/phase4/raw_interpreter_B", "data/labels/gold/phase4/adjudicated",
                                                                     "data/labels/training/phase6_T1v2/raw_interpreter_A", "data/labels/training/phase6_T1v2/raw_interpreter_B")}
R["human_label_files"] = lab; R["countersignature_present"] = config.path("experiments/registry4/addenda/phase6_countersignature.json").exists()
pc = json.loads(config.path("results/phase5/confirmatory/prerun_checklists.json").read_text())
R["prerun_checklists_at_entry"] = {e: {"decision": c["decision"], "n_failed": len(c["failed"])} for e, c in pc["records"].items()}
chk("prerun_checklists_all_DO_NOT_RUN", all(c["decision"] == "DO NOT RUN" for c in pc["records"].values()))
col = subprocess.run([sys.executable, "-m", "pytest", "-q", "--collect-only", "tests"], capture_output=True, text=True, cwd=config.ROOT).stdout
n_tests = sum(1 for l in col.splitlines() if "::" in l); R["tests_collected"] = n_tests
run = subprocess.run([sys.executable, "-m", "pytest", "-q", "tests"], capture_output=True, text=True, cwd=config.ROOT).stdout.strip().splitlines()[-1]
chk("tests_pass", " passed" in run and "failed" not in run and "error" not in run, result=run, collected=n_tests)
hard = [k for k, v in R["checks"].items() if not v["ok"]]
R["status"] = "OK - frozen Phase-6 state reproduced" if not hard else "STOP - differs from the Phase-6 frozen state"; R["failed"] = hard
config.path("results/phase7").mkdir(parents=True, exist_ok=True); config.path("results/phase7/entry_audit.json").write_text(json.dumps(R, indent=1, default=str))
L = ["# Phase 7 — entry audit (refreeze check)", "", f"_Generated {R['created_utc']} by `scripts/phase7_entry_audit.py` (read-only), before any Phase-7 change. Reference: the Phase-6 frozen state "
     f"(`results/phase6/reproducibility_manifest.json`, commit `{PHASE6_HEAD}`)._", "", f"## RESULT: **{R['status']}**", "", "| check | result | detail |", "|---|---|---|"]
for k, v in R["checks"].items():
    d = {a: b for a, b in v.items() if a != "ok"}; L.append(f"| {k} | {'PASS' if v['ok'] else '**FAIL**'} | {json.dumps(d, default=str)[:230].replace('|', '/')} |")
L += ["", "## Frozen hashes (SHA-256)", "", "| item | SHA-256 |", "|---|---|"] + [f"| {k} | `{v}` |" for k, v in R["hashes"].items()]
L += ["", "## State of the external prerequisites at entry", "",
      f"* Human label files: {', '.join(f'`{k}`: {len(v)}' for k, v in lab.items())} → **no human gold and no T1 labels exist**.",
      f"* Researcher countersignature file present: {R['countersignature_present']}.",
      f"* Pre-run checklists at entry: " + "; ".join(f"{e} {c['decision']} ({c['n_failed']} items)" for e, c in R["prerun_checklists_at_entry"].items()) + ".",
      f"* Not present at entry (Phase-6 status §3b; to be written in Phase 7, not a deviation): {', '.join(R['not_present_at_entry']) or 'none'}.",
      "* Entry-check items that changed since Phase 5 by design: `district_30m_cube_absent` (the Phase-5 dry-season pilot now exists), `earth_engine_configured` (not needed: Route A), `tier_A_gold_files_present` (no labels yet).", ""]
config.path("docs/phase7_entry_audit.md").write_text("\n".join(L))
print(R["status"], hard)
