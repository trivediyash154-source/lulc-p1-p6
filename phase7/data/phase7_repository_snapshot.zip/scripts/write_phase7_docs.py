"""Phase 7: cube build report, runner validation, C1-C6 reports, confirmatory freeze, readiness gate, execution log and machine-readable manifests -
generated FROM SAVED FILES and live read-only checks only (never edits a result). Re-run after any change; it never runs an experiment."""
import glob, hashlib, json, os, platform, shutil, subprocess, sys
from pathlib import Path
sys.path.insert(0, "src")
from pune_eo import config
from pune_eo.evaluation4 import protocol as P4
from pune_eo.provenance import utcnow
from pune_eo.confirmatory import ORDER, IMPLEMENTED, guards as GU, runner as RU, spec as SP
R7 = config.path("results/phase7"); MAN = R7 / "manifests"; DOC = config.path("docs"); NOW = utcnow()
git = lambda *a: subprocess.run(["git", *a], capture_output=True, text=True, cwd=config.ROOT).stdout.strip()
def J(p):
    p = config.path(p); return json.loads(p.read_text()) if p.exists() else None
def sha(p):
    p = config.path(p); return hashlib.sha256(p.read_bytes()).hexdigest() if p.exists() and p.is_file() else None
def wj(p, d): p = config.path(p); p.parent.mkdir(parents=True, exist_ok=True); p.write_text(json.dumps(d, indent=1, default=str))
HEAD = git("rev-parse", "HEAD"); DIRTY = bool(git("status", "--porcelain"))
REFPROD = ["results/phase5/benchmark/g5_built_envelope_frozen.json", "data/products_ext/glc_fcs30d/glc_fcs30d_district_30m.tif", "data/products_ext/worldcover/worldcover_district_30m_mode.tif",
           "data/products_ext/esri/esri_district_30m_mode.tif", "data/products_ext/gisa/gisa2_first_year_district_30m.tif", "data/labels/pune_G30/wsf_evolution_first_year.tif", "data/labels/pune_G30/ghsl_built_fraction_90m.tif", "data/labels/pune_G30/jrc_gsw.tif"]
pre = J("results/phase5/confirmatory/prerun_checklists.json")["records"]; pf = RU.preflight_all(); wj("results/phase7/runner_preflight.json", {"created_utc": NOW, "records": pf})
gold, t1, silv = GU.label_manifest("gold"), GU.label_manifest("T1"), GU.label_manifest("silver")
gold_st, t1_st = J("results/phase7/manifests/gold/status_latest.json") or {}, J("results/phase7/manifests/T1/status_latest.json") or {}
cvmin = J("results/phase5/cube_validation/validation_report_min.json") or {}; terr = J("results/phase6/terrain_run_status.json") or {}; sv = J("results/phase6/district_silver_validation.json") or {}
reg = J(GU.REGISTRATION) or {}; cs6 = J("experiments/registry4/addenda/phase6_countersignature.json") or {}; entry = J("results/phase7/entry_audit.json") or {}
# ------------------------------------------------------------------ compute route check (live, read-only)
def sh(c): return subprocess.run(c, shell=True, capture_output=True, text=True).stdout.strip()
route = {"checked_utc": NOW, "required (D3 Route A)": "8 vCPU, 32 GB RAM, >= 200 GB SSD; Planetary Computer; Azure West Europe recommended",
         "this_sandbox": {"cpus": os.cpu_count(), "mem_total": sh("free -g | awk '/Mem:/{print $2\" GB\"}'"), "free_disk": sh("df -h . | tail -1 | awk '{print $4}'"), "memory_limit_note": "6 GB cgroup (OOM kills recorded in Phases 5-6)"},
         "cloud_credentials": sh("gcloud auth list 2>&1 | head -1") or "none", "azure_cli": shutil.which("az") or "not installed / no credentials",
         "linked_computer": "macOS arm64 laptop (MacBook Air, Claude desktop app), no folder connected (observed 2026-10-02T18:56Z via device info) - not the D3 machine",
         "verdict": "no Route-A environment reachable from this session; no credentials were invented; compute boundary stands"}
wj("results/phase7/compute_route_check.json", route)
# ------------------------------------------------------------------ manifests: cube, S1, experiments
prods = sorted(glob.glob(str(config.path("data/composites/pune_G30/*/*/**/metadata.json")), recursive=True))
cube_m = {"created_utc": NOW, "status": "PILOT (not complete)" if not cvmin.get("complete_for_required") else "COMPLETE", "validator": {k: cvmin.get(k) for k in ("ok", "complete_for_required", "n_products")},
          "missing_required": len(cvmin.get("missing_required", [])), "products_present": {str(Path(p).relative_to(config.ROOT)): sha(p) for p in prods if "/sentinel1/" not in p},
          "feature_cube": {"path": GU.CUBE, "exists": config.path(GU.CUBE).exists(), "validation": (J(GU.FCV) or {}).get("ok", "NOT BUILT")},
          "c2_treatment_family": {"products": len(glob.glob(str(config.path("data/composites/pune_G30/*/landsat_c2tm/**/metadata.json")), recursive=True)), "required": 44},
          "terrain": terr.get("outcome", "not attempted") if not config.path("data/features/terrain/pune_G30/metadata.json").exists() else "BUILT",
          "district_silver": {"status": (silv or {}).get("status", "NOT BUILT"), "sha256": (silv or {}).get("sha256"), "validation_ok": sv.get("ok")}, "compute_route": route["verdict"]}
wj("results/phase7/manifests/cube/manifest.json", cube_m)
s1p = sorted(glob.glob(str(config.path("data/composites/pune_G30/2020/sentinel1/**/metadata.json")), recursive=True))
wj("results/phase7/manifests/sentinel1/manifest.json", {"created_utc": NOW, "status": "COMPLETE" if len(s1p) >= 14 else ("NOT BUILT" if not s1p else "INCOMPLETE"), "products": {str(Path(p).relative_to(config.ROOT)): sha(p) for p in s1p},
       "required": "2020: dry + wet seasonal and >= 6 monthly RTC products (docs/phase6_sentinel1_spec.md)", "driver": "scripts/phase6_district_s1.py (writer tested; driver untested)"})
for e in ORDER:
    rec = P4.load(e); st = SP.status(e); run_m = J(f"{GU.RUN_ROOT}/{e.replace('@', '_at_')}/run_manifest.json")
    wj(f"results/phase7/manifests/{e.split('@')[0]}/manifest.json", {"experiment_id": e, "created_utc": NOW, "record_status": rec["status"], "record_sha256": sha(P4.path(e)),
       "decision": pf[e]["decision"] if rec["status"] == "PENDING" else rec["status"], "checklist": {"decision": pre[e]["decision"], "failed": pre[e]["failed"]},
       "runner_preflight_failed": pf[e]["failed"], "specification": st, "implemented": e in IMPLEMENTED, "hypothesis": rec["hypothesis"], "hypothesis_status": "NOT_TESTED" if rec["status"] == "PENDING" else rec["status"], "run_manifest": run_m and f"{GU.RUN_ROOT}/{e.replace('@', '_at_')}/run_manifest.json",
       "results": None if not run_m else {"outcome": run_m.get("outcome"), "n_tests": len(run_m.get("tests", []))}})
# ------------------------------------------------------------------ docs
def table(rows, head): return ["| " + " | ".join(head) + " |", "|" + "---|" * len(head)] + ["| " + " | ".join(str(c).replace("|", "/") for c in r) + " |" for r in rows]
L = ["# Phase 7 — district cube build report", "", f"_Generated {NOW} by `scripts/write_phase7_docs.py`; git `{HEAD[:7]}`._", "",
     f"## STATUS: **{cube_m['status']}** — last validation (`results/phase5/cube_validation/validation_report_min.json`, Phase 5): ok = {cvmin.get('ok')}, complete_for_required = **{cvmin.get('complete_for_required')}** ({72 - cube_m['missing_required']}/72 products). The four dry-season pilot composites are gitignored and are not present in the restored repository ({len(cube_m['products_present'])} products on disk). **STOP: C1 cannot run.**", "",
     "## Compute environment (Stage 5)", ""] + table([[k, v if not isinstance(v, dict) else json.dumps(v)] for k, v in route.items() if k != "checked_utc"], ["item", "finding"]) + [
     "", "The processing engine was **not** changed because the sandbox cannot run it (D3 Route A stands). No credentials were invented.", "",
     "## Products (Stage 6-7)", ""] + table([
        ["Landsat standard family (18 years x 4 periods)", f"{72 - cube_m['missing_required']}/72 (dry-season 1990/2000/2010/2020 pilot)", "Route A"],
        ["C2 treatment family `landsat_c2tm` (11 TM years x 4)", f"{cube_m['c2_treatment_family']['products']}/44", "Route A"],
        ["Sentinel-1 RTC 2020", "NOT BUILT", "Route A (`scripts/phase6_district_s1.py`)"],
        ["district terrain", cube_m["terrain"], "Route A (> 6 GB RAM)"],
        ["feature cube `pune_G30.zarr` (+ treatment cube)", "NOT BUILT", "after the products"],
        ["**district automated-label set (silver L1, arm A)**", f"**BUILT + FROZEN** (manifest v1, SHA-256 `{(silv or {}).get('sha256', '')[:16]}…`)", "this session, strip-wise, same rule/code as the windows"]], ["component", "state", "where"]) + [
     "", "### District silver (Stage 7) — provenance", "",
     f"* Rule: WorldCover 2020 + 2021 and Esri 2020 + 2021 unanimous, L1 purity >= 0.78 (`configs/labels.yaml silver_consensus`), from the 10 m products on the nested 10 m lattice; code `src/pune_eo/labels/district_silver.py` (L1 rule identical to `labels/silver.py`; window fractions re-used unchanged).",
     f"* Coverage: {sv.get('meta', {}).get('labelled_cells')} labelled cells = {round(100 * (sv.get('meta', {}).get('labelled_fraction_of_district') or 0), 1)} % of the district; counts {sv.get('meta', {}).get('l1_counts')}. Cells outside the district = 0; no gold, T1 or model output used.",
     "* Restoration (2026-10-03): rebuilt after the session container was reclaimed - the label raster is **byte-identical** to the frozen original (SHA-256 `32e1ddb0…`), with identical overlap agreements (`results/phase7/restore/silver_rebuild_proof.json`); the window references were regenerated with the original L1 class counts (`results/phase7/restore/window_silver_restore.json`).",
     "* Validation: window extents reproduced **exactly** by the district code (all three windows); overlap agreement with the window silver 0.9968 / 0.9965 / 0.9993. A first strict-equality check failed for this reason (evidence, transcribed from the session record after the container loss: `results/phase7/district_silver_validation_attempt1_strict_equality.json`): GDAL's approximate warp transformer picks nearest source pixels slightly differently for different output extents (row strips vs window extents). The criterion was revised to exact window-extent reproduction + >= 0.99 overlap agreement **before** any label existed and is disclosed here.",
     "* Arm restrictions (training-eligible, >= 2 km from tuning blocks) are applied by the runner (`train_eligible_T1_30m.tif`), not baked into the product.", "",
     "## Exact commands on the Route-A machine", "",
     "**Correction to `docs/phase6_D3_compute_decision.md` §4:** do NOT re-run `scripts/phase4_validation_design.py` - it rewrites the pinned gold key, forms and design. Use `scripts/phase7_restore_spatial_context.py`, which regenerates only the validation-block / eligibility rasters and proves them against the frozen values.", "",
     "```bash", "python3 scripts/phase4_products_acquire.py                 # district Tier-B/C products (gitignored; GLC_FCS30D is needed by arm C)",
     "python3 scripts/phase7_restore_spatial_context.py          # validation blocks + training eligibility, verified; never touches the key/design",
     "# (district silver: already built and frozen - byte-identical rebuild proven; do not rebuild)",
     "Y=1990,1991,1992,1998,1999,2000,2001,2002,2008,2009,2010,2011,2012,2018,2019,2020,2021,2022",
     "python3 scripts/phase5_district_cube_pilot.py --years $Y --periods annual,dry,post_monsoon,wet --threads 8 --min-strips 8",
     "python3 scripts/phase5_district_cube_pilot.py --years 1990,1991,1992,1998,1999,2000,2001,2008,2009,2010,2011 --periods annual,dry,post_monsoon,wet --transform c2_tm_pif_v1 --out-family landsat_c2tm --threads 8 --min-strips 8",
     "python3 scripts/phase6_district_s1.py --year 2020 --threads 8", "python3 scripts/phase6_district_terrain.py",
     "python3 src/data/validate_district_cube.py --require min --out results/phase5/cube_validation/validation_report_min.json      # MUST be ok + complete",
     "python3 src/data/validate_district_cube.py --family landsat_c2tm --require c2tm --expect-harmonization c2_tm_pif_v1 --expect-transform-sha256 782eaef3e95c9dbe4b79868d936fd1e96ff1aa681d93ad609b5463ddd119db47 --out results/phase6/cube_validation_c2tm.json",
     "python3 scripts/phase5_pilot_vs_windows.py", "python3 scripts/phase6_build_feature_cube.py && python3 src/data/validate_feature_cube.py",
     "python3 scripts/phase6_build_feature_cube.py --family landsat_c2tm --fallback-family landsat && python3 src/data/validate_feature_cube.py data/features/cube/pune_G30_landsat_c2tm.zarr --family landsat_c2tm",
     "python3 scripts/phase5_prerun_checklists.py && python3 scripts/phase7_run_confirmatory.py --preflight", "```"]
(DOC / "phase7_cube_build_report.md").write_text("\n".join(L) + "\n")
# runner validation
tests_out = subprocess.run([sys.executable, "-m", "pytest", "-q", "tests/test_confirmatory_runner.py", "tests/test_phase7_label_freeze.py", "tests/test_district_silver.py"], capture_output=True, text=True, cwd=config.ROOT).stdout.strip().splitlines()[-1]
req = [["frozen protocol", "protocol code/YAML hash + version = frozen = record; frozen `protocol.Run` re-verifies", "guards.preflight; Run(eid)", "test_preflight_refuses_every_record_today"],
       ["correct experiment IDs + order C1 -> C6", "record must be PENDING; earlier records must have run; C2-C6 need the C1 selection", "guards.preflight (order_*, selection)", "preflight output"],
       ["pre-run checklist never overridden", "`assert_runnable` logic of `scripts/phase5_prerun_checklists.py` must say RUN", "guards.preflight (prerun_checklist)", "preflight output"],
       ["adopted + countersigned specification", "record + ADOPTED addenda, SHA in the researcher countersignature, append-only record pointer", "spec.status", "test_specification_requires_adoption_countersignature_and_pointer"],
       ["code changes after registration", "SHA-256 of every runner file = registered version (amendments only with a recorded reason)", "guards.preflight (implementation_registration)", "test_registration_and_single_execution_guards"],
       ["training / tuning / evaluation partitions + leakage", "silver rows inside the T1 train population; no training row on a gold or tuning cell; >= 2 km from every gold point -> STOP (Leakage)", "data.leakage_check", "end-to-end test (two forced leaks raise)"],
       ["no gold-based selection", "tuning selection (T1 tuning split) written + hashed BEFORE any gold label is read; predictions stored without labels", "experiments.run_c1", "end-to-end test (gold reader asserts selection.json exists)"],
       ["D1 arm definitions", "A, B (P3-B4m PELT), C (GLC 2020 & 2021 = silver), D (T1 train 2020/2000), E = D + C; caps 5000; equal-size control", "data.Arms", "end-to-end test (D rows: train split, 2020/2000 only)"],
       ["D2 correction enforcement (C2)", "fail closed unless c2_tm_pif_v1 SHA pinned, fit report + spec agree, no config shadowing, TM coefficients = fit, L7/8/9 = comparator, 44 products carry the SHA, family validated, treatment cube TM years from landsat_c2tm with unchanged sources", "guards.verify_c2_transform", "test_c2_transform_chain_passes_only_when_every_link_holds"],
       ["feature sets / models / seeds", "B4t (RF), B3 5-year sequence (TempCNN P3-F1); RF 300/2/sqrt; 5 protocol seeds", "models, experiments", "end-to-end test"],
       ["registered metrics + tests", "design-weighted OA (= Olofsson estimator) and macro-F1 incl. outside-legend errors; seed-pooled paired stratified block bootstrap (n 2000, seed 20261110)", "analysis", "test_design_weighted_metrics_equal_frozen_functions, test_paired_test_identical_maps_and_decision_rule"],
       ["multiple-comparison correction", "BH q 0.05 over the whole family at once (untestable p = 1); family files immutable", "analysis.apply_bh, runner.finalise_family", "test_bh_untestable..., test_runner_refuses...family_finalisation"],
       ["artifact hashing + immutable manifests", "SHA-256 of every output; run manifest written once; run directory made read-only; one execution per record", "runner.write_manifest/_freeze_dir; guards (single_execution)", "test_registration_and_single_execution_guards"]]
L = ["# Phase 7 — confirmatory runner validation", "", f"_Generated {NOW}; git `{HEAD[:7]}`._", "",
     f"## STATUS: runner **implemented and registered** (v{reg.get('version')}, {reg.get('registered_utc')}, before any label: {reg.get('history', [{}])[-1].get('pre_data')}) for **P4-C1@v2 and P4-C2@v2**; P4-C3..C6@v2 are refused (NOT_IMPLEMENTED) until their specification is adopted.", "",
     "Restoration note: the runner was first registered on 2026-10-02T19:20:41Z in the original repository; that registration was lost with the reclaimed container. The code was re-applied from the session transcript (every patch matched its original context) and re-registered here, still before any label exists.", "",
     f"Tests: `{tests_out}` (runner, label freeze, district silver; synthetic data only).", "", "## Requirement → implementation → test", ""] + table(req, ["requirement (brief Stage 8)", "how it is enforced", "code", "test"]) + [
     "", "## Specification status (fail closed until adopted)", "", "The records + protocol v2 + D1/D2 leave execution details open (protocol ambiguities). They are written as PROPOSED addenda in `docs/phase7_runner_specification.md` (pre-data). Two need a genuine researcher choice: **C3-1** (era-specific normalisation vs era-specific models) and **C6-1** (RF vs XGBoost).", ""] + \
    table([[e, "complete" if SP.status(e)["complete"] else "NOT adopted", "; ".join(SP.status(e)["missing"])[:180]] for e in ORDER], ["record", "specification", "missing"]) + [
     "", "## Limitations (honest)", "",
     "* Validated on a synthetic world only (36 x 30 cells, 2 seeds, 40 bootstrap resamples). Production scale (5 seeds, 2000 resamples, about 80 000 rows per arm) is untested; expected several hours on the Route-A machine.",
     "* P4-C3..C6@v2 pipelines are not implemented: implementing them before their open choices are adopted would decide those choices in code.",
     "* The district built share in C2 (reported, not decisive) is estimated on a systematic 1/10 x 1/10 cell sample.",
     "* P4-C2@v2 is completed in the registry with outcome 'NA' and its final outcome is written by the family finalisation (BH over C2 + C3, G-1) as an append-only `family_decision` pointer; a record that fails enters the family BH with p = 1 for every planned test.",
     "* Design-weighted OA re-normalises over the strata present in the accuracy set (w = N_h / k_h); it equals the frozen stratified estimator when every stratum has at least one accuracy-set label (unit-tested), and differs only when a stratum has none.",
     "* Registration covers the runner package and every repository module it imports for features, models, change points, harmonisation and the checklist; pre-flight refuses a run on a tree with modified tracked files and checks every input's schema before the single execution is consumed.", "",
     "## Pre-flight today", ""] + table([[e, v["decision"], ", ".join(v["failed"])] for e, v in pf.items()], ["record", "decision", "failed preconditions"])
(DOC / "phase7_runner_validation.md").write_text("\n".join(L) + "\n")
# C1-C6 reports
for e in ORDER:
    rec = P4.load(e); st = SP.status(e); n = e.split("@")[0].replace("P4-", "")
    L = [f"# Phase 7 — {e} report", "", f"_Generated {NOW}; git `{HEAD[:7]}`._", "", f"## STATUS: **{'DO NOT RUN' if rec['status'] == 'PENDING' else rec['status']}** — not executed; no model was trained and no metric exists.", "",
         "## Registered (frozen, unchanged)", ""] + table([[k, rec[k]] for k in ("hypothesis", "comparator", "primary_metric", "direction", "threshold", "family", "features", "model", "evaluation_set", "seeds")], ["field", "value"]) + [
         "", f"Decision rule (protocol v2): {P4.load_protocol()['tests']['decision_rule']}", "",
         "## Why it did not run", "", f"* Pre-run checklist: **{pre[e]['decision']}** — failed: {', '.join(pre[e]['failed'])}.",
         f"* Runner pre-flight: **{pf[e]['decision']}** — failed preconditions: {', '.join(pf[e]['failed'])}.",
         f"* Operational specification: {'complete' if st['complete'] else 'not adopted (PROPOSED in docs/phase7_runner_specification.md)'}; implemented: {e in IMPLEMENTED}.", "",
         "## Reporting template (filled only by a run)", "", "exact commit · configuration hash · dataset hashes (gold, T1, silver, cube, S1, D2 correction) · model hashes · seed list · metrics · CIs · tests · BH · missing data · failures · interpretation limited to the registered hypothesis — all written by the runner into `results/phase7/runs/" + e.replace("@", "_at_") + "/run_manifest.json`.", "",
         f"Machine-readable: `results/phase7/manifests/P4-{n}/manifest.json`."]
    if e == "P4-C2@v2":
        f2, p2 = GU.verify_c2_transform()
        L += ["", "## C2 correction chain today (fail closed)", "", f"* Transform file `{p2['transform_file']}` SHA-256 `{p2['transform_sha256']}` (pinned `{GU.C2_SHA[:16]}…`): {'OK' if 'transform_file' not in f2 else 'FAIL'}; fit report/specification binding: {'OK' if 'fit_report' not in f2 else 'FAIL'}; config shadowing: {'none' if 'config_shadowing' not in f2 else 'FAIL'}; TM coefficients = fit report: {'OK' if 'coefficients' not in f2 else 'FAIL'}; landsat-7/8/9 = comparator: {'OK' if 'single_factor' not in f2 else 'FAIL'}.",
              f"* Not yet verifiable (not built): {', '.join(k for k in f2 if k in ('treatment_products', 'comparator_products', 'treatment_family_validation', 'treatment_cube', 'comparator_cube')) or 'none'} → C2 refused."]
    (DOC / f"phase7_C{n[1]}_report.md").write_text("\n".join(L) + "\n")
# confirmatory freeze
hyp = [[e, P4.load(e)["hypothesis"], "NOT TESTED (not run: prerequisites missing)"] for e in ORDER]
L = ["# Phase 7 — confirmatory result freeze", "", f"_Generated {NOW}; git `{HEAD[:7]}`._", "", "## No confirmatory experiment was executed, so there is no confirmatory result to freeze. This document freezes the STATE.", "",
     "| # | item | value |", "|---|---|---|",
     f"| 1 | protocol hash | code `{P4.code_hash()}`, YAML `{P4.protocol_hash()}` (unchanged) |", f"| 2 | repository commit | `{HEAD}` |",
     f"| 3 | dataset hashes | district silver `{(silv or {}).get('sha256')}`; T1 design `{sha('data/labels/training/phase6_T1v2/sampling_design/design.json')}`; gold design `{sha('data/labels/gold/phase4/sampling_design/design.json')}` |",
     f"| 4 | gold hash | NOT AVAILABLE ({gold_st.get('status')}) |", f"| 5 | T1 hash | NOT AVAILABLE ({t1_st.get('status')}) |", f"| 6 | cube hash | NOT BUILT (pilot only; `results/phase7/manifests/cube/manifest.json`) |",
     "| 7 | Sentinel-1 hash | NOT BUILT |", f"| 8 | D2 correction hash | `{sha('results/harmonization/c2_tm_pif_v1.yaml')}` |",
     "| 9 | experiment manifests | `results/phase7/manifests/P4-C{1..6}/manifest.json` (status DO NOT RUN); no run manifest exists |", "| 10 | C1-C6 results | none |",
     "| 11 | statistical corrections | none applied (no test was run) |", "| 12 | failed / invalid runs | none (no run was attempted) |",
     "| 13 | deviations | none from protocol v2. Phase-7 notes: (a) district-silver validation criterion revised before any label (see cube report); (b) runner specifications PROPOSED, not adopted; (c) the D1/D2 countersignature was given in the session and recorded by the lead; (d) the session container was reclaimed on 2026-10-03: the repository was restored from the Phase-6 snapshot, the Phase-7 code re-applied from the transcript, the spatial context regenerated (validation blocks byte-identical; eligibility pixel-exact on the T1 footprint + exact statistics) and the district silver rebuilt byte-identical (docs/phase7_entry_audit.md Part B), the countersignature re-materialised with its original signing time |",
     "| 14 | preregistered hypotheses | below (verbatim) |", "| 15 | hypothesis status | NOT TESTED for all six — 'not supported' and 'inconclusive' are reserved for executed tests |", ""] + table(hyp, ["record", "hypothesis (verbatim)", "status"])
(DOC / "phase7_confirmatory_freeze.md").write_text("\n".join(L) + "\n")
# readiness gate
cs7 = J("experiments/registry4/addenda/phase7_countersignature.json")
G = [("DATA", "Gold labels frozen", gold and gold.get("status") == "FROZEN", gold_st.get("status")), ("DATA", "T1 frozen", t1 and t1.get("status") == "FROZEN", t1_st.get("status")),
     ("DATA", "Full district cube complete", bool(cvmin.get("complete_for_required")), f"{72 - cube_m['missing_required']}/72"), ("DATA", "Sentinel-1 district products complete", len(s1p) >= 14, "not built"),
     ("DATA", "Automated-label set frozen", bool(silv and silv.get("status") == "FROZEN"), f"silver manifest v1 {(silv or {}).get('sha256', '')[:12]}"),
     ("DATA", "Required validation/reference products available", all(config.path(p).exists() for p in REFPROD), "present: " + ", ".join(Path(p).name for p in REFPROD if config.path(p).exists()) + "; missing: " + (", ".join(Path(p).name for p in REFPROD if not config.path(p).exists()) or "none")),
     ("METHOD", "D1 countersigned", (cs6.get("decisions", {}).get("D1", {}).get("verdict_accepted") is True), f"Arush {cs6.get('signed_utc')}"), ("METHOD", "D2 countersigned", (cs6.get("decisions", {}).get("D2", {}).get("verdict_accepted") is True), f"Arush {cs6.get('signed_utc')}"),
     ("METHOD", "D2 correction frozen", sha("results/harmonization/c2_tm_pif_v1.yaml") == GU.C2_SHA, GU.C2_SHA[:12]), ("METHOD", "Protocol v2 unchanged", P4.code_hash() == P4.load_protocol()["frozen"]["code_sha256"] and P4.protocol_hash() == P4.load_protocol()["frozen"]["protocol_sha256"], "hashes"),
     ("METHOD", "No gold leakage", True, "no gold exists; design separation re-verified (entry audit); runner leakage stop-check tested"), ("METHOD", "Training/tuning separation verified", True, "T1 partition re-verified (2 010 m); ingestion never skips it"),
     ("METHOD", "Confirmatory runner validated", False, "C1/C2 implemented, registered, synthetic-tested; specifications NOT adopted; C3-C6 not implemented")] + \
    [("EXPERIMENTS", f"{e.split('@')[0].replace('P4-', '')} executed", P4.load(e)["status"] == "PASS", P4.load(e)["status"]) for e in ORDER] + \
    [("EXPERIMENTS", "Multiple-comparison correction applied", False, "no test run"), ("EXPERIMENTS", "All outputs reproducible", False, "no outputs")] + \
    [("INTEGRITY", "No fabricated data", True, "no label, image or result created"), ("INTEGRITY", "No fabricated labels", True, "gold/T1 folders empty"), ("INTEGRITY", "No post-hoc protocol changes", True, "protocol hashes unchanged"),
     ("INTEGRITY", "No test-set model selection", True, "no selection made; runner selects on T1 tuning before reading gold"), ("INTEGRITY", "No exploratory result presented as confirmatory", True, "-"), ("INTEGRITY", "Negative results retained", True, "none produced")]
L = ["# Phase 7 — readiness gate (exit gate)", "", f"_Generated {NOW}; git `{HEAD[:7]}`._", "", "| group | item | | evidence |", "|---|---|---|---|"] + [f"| {a} | {b} | {'[x]' if c else '[ ]'} | {d} |" for a, b, c, d in G]
ready = all(c for _, _, c, _ in G)
L += ["", f"## PHASE 7 = **{'COMPLETE' if ready else 'NOT_READY'}**", "", "Mandatory items unchecked: " + "; ".join(b for _, b, c, _ in G if not c) + ".", "",
      "Phase 8 is **not** permitted by this gate.", "", "Primary blocker: no human gold labels exist (0 of 641 points interpreted).",
      "Next scientific action: two independent interpreters label the 641 gold points for 2020 and 2000 with `phase6_gold_kit_INTERPRETER_A/B`; in parallel the researcher reviews/adopts the runner specifications and the Route-A machine builds the cube."]
(DOC / "phase7_readiness_gate.md").write_text("\n".join(L) + "\n")
st = {"created_utc": NOW, "git": HEAD, "phase7": "COMPLETE" if ready else "NOT_READY", "gate": [{"group": a, "item": b, "ok": bool(c), "evidence": d} for a, b, c, d in G],
      "confirmatory": {e: (pf[e]["decision"] if P4.load(e)["status"] == "PENDING" else P4.load(e)["status"]) for e in ORDER}, "protocol_changed": False, "data_fabricated": False, "leakage_detected": False}
wj("results/phase7/phase7_status.json", st)
# execution log
log = git("log", "--reverse", "--format=%h %cI %s", "--max-count=200").splitlines()
ORIG = [("60afc8e", "Stage 1: refreeze audit - Phase-6 frozen state reproduced"), ("17bbe59", "Stage 2: researcher countersignature of D1 and D2"), ("97d17e9", "Stages 3-4: label freeze tool; gold/T1 NOT_AVAILABLE"),
        ("7e7bece", "Stage 7: district silver built, validated, frozen (SHA 32e1ddb0)"), ("00800de", "Stage 8: confirmatory runner, PROPOSED specifications, runner registered v1"), ("2c89132", "Stages 9-14: checklists, pre-flight, reports, gate NOT_READY")]
L = ["# Phase 7 — execution log", "", f"_Generated {NOW}._", "", "## Part 1 — original execution (2026-10-02, original repository)", "", "| step | original commit | what happened |", "|---|---|---|",
     "| Stage 1 | 60afc8e | refreeze audit: Phase-6 state reproduced (transcribed in `docs/phase7_entry_audit.md` Part A) |",
     "| Stage 2 | 17bbe59 | researcher countersigned D1 and D2 in the session ('Yes, countersign both'), signed 2026-10-02T18:49:28Z |",
     "| Stages 3-4 | 97d17e9 | no interpreter forms → gold and T1 NOT_AVAILABLE; freeze tool built and tested; nothing created |",
     "| Stage 5 | - | no Route-A environment reachable (no cloud credentials; linked laptop without a connected folder) → compute boundary |",
     "| Stage 6 | - | cube NOT built (complete_for_required = false) → STOP for C1 |",
     "| Stage 7 | 7e7bece | district silver built strip-wise (attempt 1 failed a strict window-equality check, diagnosed as a warp-extent effect; criterion revised pre-data; rebuild with identical counts), validated, frozen (SHA 32e1ddb0) |",
     "| Stage 8 | 00800de | runner implemented (C1, C2), PROPOSED specifications for all six records, runner registered v1 pre-data (2026-10-02T19:20:41Z) |",
     "| Stages 9-14 | 2c89132 | checklists + runner pre-flight: all six DO NOT RUN; reports and gate (NOT_READY) |", "",
     "## Part 2 — container loss and restoration (2026-10-03)", "",
     "* The session container was reclaimed before the Phase-7 package was written; the original repository (with its Phase 1-7 git history) was lost. Nothing had been delivered from Phase 7 yet.",
     "* Restored from `/mnt/user-data/outputs/phase6/phase6_repository_snapshot.zip` (git 7b85b69) + `phase6_KEYS_evaluator_only.zip`; the Phase-6 history before the snapshot is not recoverable.",
     "* Phase-7 code, tests and generators re-applied from the session transcript in the original order (12 file writes + 20 patches; every patch's original-context assertion matched). Python packages reinstalled (versions in `results/phase7/reproducibility_manifest.json`).",
     "* Restore commit: the first restore commit (c16f596) was amended into f4e5a7b to add the two committed T1 rasters that the ignore pattern had skipped; both equal their Phase-6 manifest hashes.",
     "* Gitignored spatial context regenerated: validation blocks byte-identical to the frozen SHA; training-eligible raster pixel-exact on the committed T1 footprint (tuning and train rasters reproduced exactly) plus exact district share and gold-distance statistics; district mask checked by its exact cell count. Window silver references regenerated with the original class counts.",
     "* District silver rebuilt: **byte-identical** to the frozen original (SHA-256 32e1ddb0…).",
     "* D1/D2 countersignature re-materialised from the transcript with the original signing time (no new signature asked); original file SHA aea5491e recorded inside the record.",
     "* Runner specifications regenerated (same content, new `written_utc`), runner re-registered pre-data, checklists and pre-flight re-run: identical decisions to the original run.", "",
     "## Restored repository commits", ""] + [f"* `{l}`" for l in log]
(DOC / "phase7_execution_log.md").write_text("\n".join(L) + "\n")
# reproducibility manifest
code = sorted(set(glob.glob(str(config.path("scripts/phase7_*.py"))) + glob.glob(str(config.path("src/pune_eo/confirmatory/*.py"))) + [str(config.path(p)) for p in ("scripts/write_phase7_docs.py", "src/pune_eo/labels/district_silver.py", "scripts/phase5_prerun_checklists.py",
        "src/validation/ingest_gold.py", "src/validation/audit_gold.py", "tests/test_confirmatory_runner.py", "tests/test_phase7_label_freeze.py", "tests/test_district_silver.py")]))
data = [p for p in glob.glob(str(config.path("results/phase7/**/*")), recursive=True) if Path(p).is_file() and "reproducibility_manifest" not in p and not p.endswith(".log")] + \
       [str(config.path(p)) for p in ("data/labels/pune_G30_district_silver/silver_l1.tif", "data/labels/pune_G30_district_silver/metadata.json", "results/phase6/district_silver_validation.json",
                                     "experiments/registry4/addenda/phase6_countersignature.json", GU.REGISTRATION)] + glob.glob(str(config.path("experiments/registry4/addenda/*_PROPOSED.json")))
wj("results/phase7/reproducibility_manifest.json", {"created_utc": NOW, "git_head": HEAD, "git_dirty_before_generation": DIRTY, "python": platform.python_version(),
   "protocol": {"code_sha256": P4.code_hash(), "yaml_sha256": P4.protocol_hash()}, "code_sha256": {str(Path(p).relative_to(config.ROOT)): sha(p) for p in code},
   "datasets_and_records_sha256": {str(Path(p).relative_to(config.ROOT)): sha(p) for p in sorted(set(data))}, "registry_records_sha256": {Path(p).stem: sha(p) for p in sorted(glob.glob(str(config.path("experiments/registry4/*.json"))))}})
print("phase7 docs written:", "COMPLETE" if ready else "NOT_READY")
