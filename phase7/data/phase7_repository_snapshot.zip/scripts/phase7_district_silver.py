"""Phase 7 / Stage 7: build + validate the DISTRICT silver L1 label set (P4-C1@v2 arm A) and freeze it in a manifest.
    python3 scripts/phase7_district_silver.py [--strip 512] [--validate-only]
Output: data/labels/pune_G30_district_silver/{silver_l1.tif, metadata.json}; validation results/phase6/district_silver_validation.json (the path the
frozen pre-run checklist reads); manifest results/phase7/manifests/silver/manifest_v1.json (never overwritten). Rule and code: src/pune_eo/labels/district_silver.py."""
import argparse, json, sys
from pathlib import Path
import numpy as np, rasterio
sys.path.insert(0, "src")
from pune_eo import config
from pune_eo.grid import district_grid, Grid
from pune_eo.labels import district_silver as DS
from pune_eo.provenance import utcnow
OUT = config.path("data/labels/pune_G30_district_silver"); VAL = config.path("results/phase6/district_silver_validation.json"); MAN = config.path("results/phase7/manifests/silver")
def windows(G):
    w = {}
    for name in ("khadakwasla_mutha", "baramati_agri", "mulshi_ghats"):
        d = config.path("data/labels", f"pune_G30_{name}"); gj = json.loads((d / "splits.json").read_text())["grid"]
        if (d / "silver_l1.tif").exists(): w[name] = (Grid(f"pune_G30_{name}", G.crs, G.res, gj["x0"], gj["y1"], gj["width"], gj["height"], G.corner_offset), d / "silver_l1.tif")
    return w
if __name__ == "__main__":
    ap = argparse.ArgumentParser(); ap.add_argument("--strip", type=int, default=512); ap.add_argument("--validate-only", action="store_true"); a = ap.parse_args()
    G = district_grid("G30")
    with rasterio.open(config.path("data/products_ext/district/district_mask_30m.tif")) as s: dm = s.read(1).astype(bool)
    if not a.validate_only:
        if (OUT / "metadata.json").exists(): sys.exit(f"{OUT} exists - a built silver set is never overwritten (validate with --validate-only)")
        DS.build(G, dm, OUT, a.strip)
    r = DS.validate(OUT, G, dm, windows(G), fetch=DS.fetch_fractions); r["validated_utc"] = utcnow(); VAL.parent.mkdir(parents=True, exist_ok=True); VAL.write_text(json.dumps(r, indent=1, default=str))
    MAN.mkdir(parents=True, exist_ok=True)
    if r["ok"] and not list(MAN.glob("manifest_v*.json")):
        (MAN / "manifest_v1.json").write_text(json.dumps({"status": "FROZEN", "version": 1, "sha256": r["sha256"], "metadata_sha256": __import__("hashlib").sha256((OUT / "metadata.json").read_bytes()).hexdigest(),
                                                          "validation": str(VAL.relative_to(config.ROOT)), "created_utc": utcnow()}, indent=1))
    print(json.dumps({k: v["ok"] for k, v in r["checks"].items()}, indent=1), r.get("meta")); sys.exit(0 if r["ok"] else 1)
