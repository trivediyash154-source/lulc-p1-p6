"""Gold-standard reference sample for the benchmark windows (test of record) + interpretation material.

Design: stratified random sample of G30 cells drawn ONLY from TEST blocks (splits.tif == 3), so a gold point can never sit in
or next to a training block. Strata = silver L1 class (built, agriculture, natural vegetation, water) + 'no_silver_label'
(mixed / disputed cells that the silver consensus excludes - the hard cases that silver accuracy cannot see).
Interpretation source of record = very-high-resolution imagery (Google Earth Pro historical imagery / Bing / field visits),
NOT this project's Landsat composites; the Landsat chips produced here only give temporal context and any label made from
them alone must carry source='landsat_context_only' (reported separately, lower confidence).
STATUS: PENDING_INTERPRETATION - no gold label exists until a human analyst fills the form."""
from __future__ import annotations
import numpy as np, pandas as pd, geopandas as gpd, rasterio
from shapely.geometry import Point, box
from .. import config
from ..grid import Grid
from ..io import write_json
from ..provenance import utcnow

FORM_COLUMNS = ["label_L1_{y}", "label_L2_{y}", "confidence_{y}", "vhr_source_{y}", "vhr_date_{y}"]

def design_window_sample(grid: Grid, n_per_stratum: int = 40, seed: int = 20261003, epochs=(1990, 2000, 2010, 2020, 2025)) -> gpd.GeoDataFrame:
    d = config.path("data", "labels", grid.id)
    with rasterio.open(d / "silver_l1.tif") as s: l1 = s.read(1)
    with rasterio.open(d / "splits.tif") as s: sp = s.read(1)
    names = {0: "no_silver_label", 1: "built_up", 2: "agriculture", 3: "natural_vegetation", 4: "water"}
    rng = np.random.default_rng(seed); rows = []
    for code, nm in names.items():
        r, c = np.nonzero((sp == 3) & (l1 == code))
        if r.size == 0: continue
        k = min(n_per_stratum, r.size); pick = rng.choice(r.size, k, replace=False)
        for i in pick:
            x = grid.x0 + (c[i] + 0.5) * grid.res; y = grid.y1 - (r[i] + 0.5) * grid.res
            rows.append({"sample_id": f"{grid.id.replace('pune_G30_', '').upper()[:6]}-{len(rows):04d}", "stratum": nm,
                         "stratum_cells_in_test": int(r.size), "n_stratum": k, "row": int(r[i]), "col": int(c[i]), "x_utm": x, "y_utm": y})
    g = gpd.GeoDataFrame(rows, geometry=[Point(r["x_utm"], r["y_utm"]) for r in rows], crs=grid.crs)
    g["inclusion_prob"] = g.n_stratum / g.stratum_cells_in_test       # for design-based (Olofsson) estimation
    ll = g.to_crs(4326); g["lon"], g["lat"] = ll.geometry.x, ll.geometry.y
    for y in epochs:
        for col in FORM_COLUMNS: g[col.format(y=y)] = None
    g["interpreter"] = None; g["notes"] = None; g["status"] = "PENDING_INTERPRETATION"
    out = config.path("data", "labels", "gold", grid.id); out.mkdir(parents=True, exist_ok=True)
    g.to_parquet(out / "gold_sample.parquet"); g.drop(columns="geometry").to_csv(out / "gold_form.csv", index=False)
    # 30 m cell squares for Google Earth Pro
    cells = g.copy(); cells["geometry"] = [box(x - 15, y - 15, x + 15, y + 15) for x, y in zip(g.x_utm, g.y_utm)]
    cells[["sample_id", "stratum", "geometry"]].to_crs(4326).to_file(out / "gold_cells.kml", driver="KML")
    write_json(out / "gold_design.json", {"grid": grid.to_dict(), "seed": seed, "n_per_stratum": n_per_stratum, "epochs": list(epochs),
               "frame": "test blocks only (splits.tif == 3)", "strata": g.stratum.value_counts().to_dict(),
               "interpretation_source": "VHR imagery (Google Earth Pro historical / Bing / field); Landsat chips = context only",
               "status": "PENDING_INTERPRETATION", "created_utc": utcnow()})
    return g

def _stretch(rgb, lo=2, hi=98):
    out = np.zeros_like(rgb, dtype=np.float32)
    for i in range(3):
        b = rgb[i]; f = np.isfinite(b)
        if f.sum() < 10: continue
        p0, p1 = np.percentile(b[f], [lo, hi]); out[i] = np.clip((b - p0) / max(p1 - p0, 1e-6), 0, 1)
    return np.nan_to_num(out).transpose(1, 2, 0)

def make_chips(grid: Grid, sample: gpd.GeoDataFrame, years=(1990, 2000, 2010, 2020, 2025), half_px: int = 25, limit: int | None = None) -> int:
    """One PNG per sample: Landsat dry-season true colour (row 1) and SWIR-NIR-red (row 2) per epoch, 30 m cell outlined.
    Context material only - see module docstring."""
    import matplotlib; matplotlib.use("Agg"); import matplotlib.pyplot as plt
    from matplotlib.patches import Rectangle
    comp = {}
    for y in years:
        p = config.path("data", "composites", grid.id, str(y), "landsat", "seasonal", "dry", "optical_composite.tif")
        if p.exists():
            with rasterio.open(p) as s:
                a = s.read().astype(np.float32); a[a == s.nodata] = np.nan
                comp[y] = (a, list(s.descriptions), (s.scales or [1])[0], (s.offsets or [0])[0])
    out = config.path("data", "labels", "gold", grid.id, "chips"); out.mkdir(parents=True, exist_ok=True); n = 0
    for _, r in (sample.head(limit) if limit else sample).iterrows():
        fig, ax = plt.subplots(2, len(years), figsize=(2.2 * len(years), 4.6))
        for j, y in enumerate(years):
            for i, bands in enumerate((["red", "green", "blue"], ["swir16", "nir08", "red"])):
                a_ = ax[i, j]; a_.set_xticks([]); a_.set_yticks([])
                if y not in comp: a_.set_title(f"{y}\nno composite", fontsize=7); continue
                a, desc, sc, of = comp[y]
                n_ = 2 * half_px + 1; rgb = np.full((3, n_, n_), np.nan, np.float32)    # fixed size, cell centred
                r0, c0 = r.row - half_px, r.col - half_px
                ys, xs = slice(max(r0, 0), min(r0 + n_, a.shape[1])), slice(max(c0, 0), min(c0 + n_, a.shape[2]))
                for k, b in enumerate(bands):
                    rgb[k, ys.start - r0:ys.stop - r0, xs.start - c0:xs.stop - c0] = a[desc.index(b), ys, xs] * sc + of
                a_.imshow(_stretch(rgb), interpolation="nearest")
                a_.add_patch(Rectangle((half_px - 0.5, half_px - 0.5), 1, 1, fill=False, ec="yellow", lw=1.2))
                if i == 0: a_.set_title(f"{y} dry", fontsize=8)
        fig.suptitle(f"{r.sample_id}  ({r.lat:.5f}, {r.lon:.5f})  stratum={r.stratum}  — Landsat context only; label from VHR", fontsize=8)
        fig.text(0.01, 0.01, "Rows: true colour | SWIR1-NIR-red. 1.5 km x 1.5 km. Contrast stretched per chip.", fontsize=6)
        fig.savefig(out / f"{r.sample_id}.png", dpi=110, bbox_inches="tight"); plt.close(fig); n += 1
    return n
