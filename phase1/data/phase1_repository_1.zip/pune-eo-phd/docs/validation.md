# Validation

Two different things are validated and must never be confused:

| | Data QA | Model / product validation |
|---|---|---|
| Question | Is this composite physically and geometrically sound? | Is this map/estimate correct, and how uncertain? |
| Reference | internal consistency + independent controls (JRC permanent water) | independent reference samples (field, high-resolution interpretation) |
| Where | `src/pune_eo/qa/` — runs on every product | `src/pune_eo/validation/` — per experiment |

## Data QA (implemented)
Automatic per product: CRS, shape, transform on the declared lattice; checksums; district valid
coverage; median clear observations; single-observation share; band medians in [0, 0.6];
SLC-off-only flag; partial period; **negative control** — JRC GSW cells with ≥95 % water occurrence
over 1984–2021 (min-resampled, so the whole cell is permanent water) must have MNDWI > 0;
**residual cloud/haze** — share of valid pixels that are *transiently* bright (blue SR > 0.15 in the product but not in the
robust annual/dry median baseline, which removes bright surfaces such as roofs and quarries and makes the test
resolution-independent). Calibrated on Pune: clean composites ≈ 0 % at 240 m and < 0.7 % at 10 m; the 1992 monsoon
composite with haze missed by CFMask 88.5 %. WARNING > 1 %, FAIL > 10 %;
**in-progress periods** with no acquisitions yet are marked `IN_PROGRESS`, never FAIL.
Output: PASS / WARNING / FAIL with reasons, in `metadata.json` and `results/qa/<family>/<grid>/QA_REPORT.md`.

## Product validation (protocol; executed per experiment)

**Reference data.** Stratified random sample per epoch (strata = mapped classes / change classes),
interpreted from independent imagery (historical high-resolution archives, field visits). Never use
another classifier's map as truth.

**Splits.** Never random pixel splits on spatially autocorrelated data. Use:
- spatially blocked K-fold (block size ≥ autocorrelation range of the residuals);
- held-out years (temporal blocking);
- held-out regions (e.g. Western Ghats talukas vs Bhima plains) for transferability.
`validation/spatial_cv.py` implements blocked folds.

**Metrics.** Classification: OA, balanced accuracy, per-class precision/recall/F1, IoU, with
bootstrap CIs. Area: error-adjusted area with 95 % CI (Olofsson et al. 2014). Continuous: MAE, RMSE,
R², bias, correlation, with CIs.

**Uncertainty must be validated too:** calibration curves / reliability diagrams for class
probabilities; empirical coverage of conformal or ensemble intervals.

## Hindcast gate (mandatory before scenarios)
Train ≤ 2010 → predict 2015 and 2020; train ≤ 2015 → predict 2020 and 2025. Compare against observed
annual products with the same metrics plus transition-specific scores (hits/misses/false alarms of
change, figure-of-merit). If skill does not beat a persistence and a Markov baseline, scenarios are not
reported.
