# PhD roadmap — from data foundation to defensible claims

| Milestone | Deliverable | Gate (must pass before next) | Status |
|---|---|---|---|
| **M1 Data foundation** | boundary, grids, manifests, harmonised annual/seasonal Landsat 1990–2026, Sentinel dense cube, QA, climate driver | negative control ≥ 90 % in dry season; every product traceable | **benchmark done** (G240 district, G30 window, S1/S2 dense); G30 district pending compute |
| M2 Production cube | G30 district all years (GEE or VM); 30 m district-wide harmonisation refit; S1 GRD→RTC for missing 2025 frames; terrain derivatives (HAND, flow accumulation) | QA PASS ≥ 90 % of dry products; harmonisation decision stable | pipeline ready |
| M3 Reference data + L1 maps | interpreted stratified sample (tool: `validation/sample_design.py`, 1,345 points, 5 epochs); hierarchical L1 LULC with calibrated probabilities; S1+S2 phenology | OA, balanced accuracy, per-class F1 with CIs on spatially blocked folds; calibration curves | sample design generated, labels empty |
| M4 Change & trajectories | annual transitions, timing, persistence, velocity, hotspots, urban expansion modes; error-adjusted areas with CIs | areas reported with 95 % CI | — |
| M5 Coupled systems & drivers | H2–H5 designs (DiD, spatial RD, mixed models); water-stress components kept separate | placebo / falsification tests pass | — |
| M6 Modelling & hindcast | H1 sequence vs Markov; train ≤ 2010 → 2015/2020, ≤ 2015 → 2020/2025 | beats persistence and Markov baselines with CI | — |
| M7 Scenarios & digital twin | conditional scenarios with intervals; decision-support interface | only after M6 gate | — |

## Candidate papers
1. **Data/methods** — a harmonised, uncertainty-tracked 1990–2026 multi-sensor cube for an Indian district, including the cross-sensor *stability* analysis (L7→L8 offset transferable; L9→L8 not) and archive-depth accounting.
2. **Coupled land–water** — floodplain occupation vs flood-line revisions (H2) and/or downstream agriculture vs municipal water draw (H3).
3. **AI** — path dependence in annual land transitions (H1) with hindcast-gated evaluation and area of applicability.

## External data to request early (critical path)
| Data | Holder | Route |
|---|---|---|
| Flood lines 2011, DP 2017, MERI 2025 | WRD Maharashtra / PMC / MERI | RTI application; DP sheets for digitising |
| Canal command areas (Khadakwasla, Nira, Bhama-Askhed) | WRD irrigation circles | RTI / university MoU |
| Dam storage & release series | WRD, Pune Irrigation Circle daily bulletins | public bulletins (archive) |
| IMD gridded rainfall | IMD Pune | imdlib / data portal |
| Groundwater levels | CGWB / GSDA | India-WRIS |
| Historical high-resolution imagery for labels | Google Earth Pro history; USGS declassified CORONA/HEXAGON (1960s–80s) | USGS EarthExplorer (account) |
