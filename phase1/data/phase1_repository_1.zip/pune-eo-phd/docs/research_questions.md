# Research questions

## Core question

> How have land, water, agriculture, vegetation and urban systems evolved across the entire
> Pune District (15,650 km²) between 1990 and 2026; how are these transformations spatially
> and temporally coupled; which measurable environmental and anthropogenic factors are
> associated with them; and how can multi-sensor Earth Observation and AI/ML reconstruct,
> explain, validate and model these dynamics — with stated uncertainty?

The Earth-observation data cube and these questions are the foundation. Models are tools for
answering them, not the contribution in themselves.

## Sub-questions by system

Each question names what is **observable** from the cube and what needs **external data**.
Questions that cannot be answered with defensible data are listed as such rather than dropped silently.

### RQ1 — Land (reconstruction)
1. What were the annual Level-1 land-cover states of every 30 m cell from 1990 to 2026, and with what per-pixel confidence?
2. Which Level-2 classes can be separated reliably in which era (Landsat-only 1990–2014 vs. Landsat+Sentinel 2015/2018–2026)?
   *Observable:* harmonised optical cube (all years), SAR (2015+). *External:* reference samples per epoch.

### RQ2 — Water
1. How have surface-water extent and persistence of rivers, reservoirs, lakes and ponds changed per year and per season?
2. How have river width and bankline position of the Mula, Mutha, Pavana, Indrayani, Bhima, Ghod and Nira changed, and where does riparian land cover convert?
3. How does reservoir surface area vary seasonally, and how does it relate to storage?
   *Observable:* water **extent** and persistence. *Not observable from imagery alone:* water **level** (needs gauges / altimetry) and **depth/volume** (needs bathymetry or area–elevation–capacity curves).

### RQ3 — Agriculture
1. How have cropping intensity (single/double/triple), irrigated vs. rainfed status and fallow frequency changed since 1990?
2. In the Sentinel era (dense S2 from 2018, S1 from 2015), which crop-type and rotation sequences can be inferred, and how stable are they?
3. How do agricultural transitions relate to surface-water availability and canal command areas?
   *Constraint:* pre-2018 crop **type** is not defensible at field scale (holding size vs 30 m pixels; 3–6 clear kharif observations/yr). Pre-2018 delivers intensity and irrigation status only.

### RQ4 — Vegetation
1. What are the trends and seasonal-cycle changes of vegetation (forest, shrub, grassland, plantation, riparian) after sensor harmonisation?
2. How do vegetation dynamics respond to rainfall variability and to land-use transitions?
   *Note:* an unharmonised Landsat-7→8 transition injects a −0.047 NDVI step (measured, see `results/harmonization/`), so trends must use the harmonised cube.

### RQ5 — Urban
1. Where, in which direction, at what rate and in which mode (edge expansion, infill, leapfrog) did built-up land expand, year by year?
2. How is expansion associated with distance to existing built-up land, roads, rivers, elevation, slope and administrative/planning boundaries?
   *Association is not causation;* causal claims need a stated identification strategy (see hypotheses).

### RQ6 — Flood
1. For selected events, what was the SAR-observable inundation extent, and how does it relate to terrain and land cover?
2. How has floodplain occupation (built-up within water-exposure zones) changed since 1990?
   *Separation:* hazard (inundation), exposure (what is there), vulnerability (needs socio-economic data). No damage claims without independent validation.

### RQ7 — Environmental and water stress
1. Can an operational, validated definition of water stress be built that **separates** water availability, water demand, ecosystem response and agricultural response?
   No composite index is formed until each component is measured and validated independently.

## Coupling questions (the core contribution)
- C1 Urban expansion → agricultural land loss → change in irrigated area → change in water demand.
- C2 Reservoir development / water reallocation → downstream agricultural and riparian change.
- C3 River-corridor modification → floodplain occupation → change in flood exposure.
- C4 Rainfall variability → vegetation and agricultural response, conditional on irrigation access.
- C5 Is land-cover transition **path-dependent** (does a pixel's multi-year trajectory carry information beyond its current state)?

## What would falsify the framework
If harmonised, uncertainty-aware annual products cannot reproduce known historical transitions in
hindcast (train ≤ year T, predict T+5/T+10), the scenario layer is not trusted, regardless of model
sophistication.
