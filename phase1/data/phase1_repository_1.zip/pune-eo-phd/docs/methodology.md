# Methodology

## 0. Why four snapshots were insufficient (diagnosis)

The preliminary figure (1990 / 2000 / 2010 / 2026 false-colour + DEM + WorldCover) had five defects:

1. **Temporal sparsity.** Four dates sample a 37-year system at 10-year intervals; transition timing,
   velocity, reversals and event responses are invisible, and any "trend" is two-point arithmetic.
2. **Single-window, mixed-sensor composites without harmonisation.** The rising district-median NDVI
   in those maps (0.17 → 0.34) was partly a sensor artefact: on held-out years the Landsat-7→8
   transition alone shifts NDVI by **−0.047** (measured on 296,267 Pune pixels, `results/harmonization/`).
3. **No observation accounting.** Nothing recorded how many clear observations supported each pixel,
   which is the difference between a measurement and a guess (e.g. in the 1990 monsoon only 17.5 % of
   the district had a single clear Landsat view).
4. **No uncertainty, no QA, no provenance.** A pixel could not be traced to scenes, dates or processing.
5. **Visual reading of false colour.** "Greener" is not a result; areas, rates and intervals are.

## 1. Pipeline order (never reversed)

```
real archive → discovery (manifests) → selection with logged reasons → QC → per-observation
masking & decoding → sensor harmonisation → fixed-grid analysis-ready cache → temporal
compositing (annual / seasonal / monthly / events) + counts + uncertainty → automated QA →
features → change & transitions → coupled-system analysis → drivers → ML → uncertainty →
hindcast gate → conditional scenarios → digital twin (interface last)
```

## 2. Temporal architecture

| Scale | Period | Products | Sensors |
|---|---|---|---|
| Long-term | every year 1990–2026 | annual, dry (Jan–May), wet (Jun–Sep), post-monsoon (Oct–Dec) composites; counts; valid mask; QA; uncertainty | Landsat 5/7/8/9 (harmonised to OLI) |
| Dense modern | 2018–2026 (S2), 2015–2026 (S1) | monthly composites; seasonal; annual; phenology features | Sentinel-2 L2A, Sentinel-1 RTC, Landsat 8/9 |
| Event | per cited event | pre / during / post SAR | Sentinel-1 |

Seasons follow IMD conventions and **partition the calendar year exactly** (annual = union of seasons).
Agricultural seasons (kharif, rabi crossing the year) are handled in the phenology module, not forced
into calendar composites. **2026 is partial**: every product records `complete=false` and the archive
cut-off when its period extends past the cut-off.

Why 1990 and not earlier: the archive contains **no dry-season scene over the district in 1989** and
nothing usable before (`data/manifests/landsat_footprint_coverage.csv`). MSS (1972–) is catalogued as
context only — no SWIR, 60 m, not surface reflectance.

## 3. Satellite history respected

Each year uses only sensors that actually observed it. Key archive facts established in this build:
- Landsat-5 has **no Tier-1 scenes over Pune in 2002–2003**; 2002–2012 is Landsat-7 heavy and 2003+
  ETM+ is SLC-off (gaps are fill, never interpolated).
- Landsat-7 is excluded after 2021 (orbit drift; L8+L9 suffice) — logged per scene in the manifest.
- Sentinel-2 L2A over Pune is sparse before 2018 (~26 dates/yr vs ~60 after) → dense S2 from 2018.
- Sentinel-1 RTC over Pune is ~12-day revisit even when S1B flew (only 25 S1B scenes); Planetary
  Computer's RTC lacks about half of the 2025 S1A frames present in GRD; no S1C over Pune; S1D from 2026.

## 4. Spatial frame

- **Boundary:** geoBoundaries IND ADM2 (full resolution, release 9469f09), valid single polygon,
  15,650.14 km² equal-area (+0.05 % vs the official 15,643 km²). Cross-check vs GADM 4.1: IoU 0.978,
  348 km² symmetric difference, Hausdorff 1.09 km → reported as **boundary uncertainty**; statistics
  near the boundary carry it.
- **Grids (verified against real files, `data/boundary/grids.json`):** all 7 Landsat path/rows are
  delivered in EPSG:32643 on one lattice with corners at 15 mod 30 m; Sentinel-2/1 lie on a 10 m
  lattice with corners at 0 mod 10 m. Therefore:
  - **G30** = native Landsat lattice → historical Landsat is never spatially resampled.
  - **G10/G20** = native Sentinel lattice for modern field-scale tasks.
  - G10 does **not** nest in G30 (5 m offset); Sentinel enters the 30 m fusion grid only by
    area-weighted aggregation, never by interpolation. Historical data are never upsampled to 10 m.
  - **G240** (8×G30) is a district-wide benchmark grid for pipeline verification and diagnostics only.

## 5. Per-observation processing

**Landsat C2 L2SP (T1 only):** QA_PIXEL bits fill/dilated cloud/cirrus/cloud/shadow/snow masked;
SR = DN×2.75e-5 − 0.2; DN above valid range (saturation) invalid; negative SR over dark targets
clipped to 0 and counted (discarding it would systematically delete water). At coarse grids:
SR overviews are **averaged** but QA overviews are **sampled** (verified), so QA is read from a finer
overview and a coarse cell is clear only if **all** samples are clear.

**Sentinel-2 L2A:** SCL masking (keep 2,4,5,6,7); BOA_ADD_OFFSET −0.1 for processing baseline ≥ 04.00;
duplicates by tile/datetime resolved to the newest baseline; 20 m bands are never sharpened.

**Sentinel-1 RTC:** gamma0 linear; averages always in **linear power** then converted to dB;
one dominant orbit direction per year for geometric consistency.

## 6. Sensor harmonisation (evidence-based)

Reference = OLI. Per-sensor, same-window dry-season composites in real overlap years
(L5/L7 2000–01, L7/L8 2014–16, L9/L8 2022–23) are compared on stable, well-observed pixels; OLS and
RMA fits are scored **leave-one-year-out**. Pre-stated rule: apply a local fit only if held-out band
RMSD falls ≥5 % and |NDVI bias| does not worsen by > 0.002.

| Pair | Held-out RMSD change | Held-out NDVI bias (none → local) | Decision |
|---|---|---|---|
| L5→L7 | −0.8 % | 0.0002 → 0.0033 | identity (TM ≈ ETM+) |
| L7→L8 | −36.0 % | 0.0467 → 0.0011 | apply local RMA |
| L9→L8 | −10.7 % | 0.0151 → 0.0001 | apply local RMA |

Roy et al. (2016) OLS coefficients also remove the L7→L8 NDVI step (held-out −0.0002) but leave larger
band errors than the local fit.

**Stability test (resolution × landscape).** The same procedure was repeated at 30 m in two contrasting
windows (`results/harmonization/harmonization_stability.csv`, `results/figures/harmonization_stability.png`):

| Pair | District 240 m | Khadakwasla–Mutha 30 m (peri-urban) | Baramati 30 m (irrigated) |
|---|---|---|---|
| L5→L7 NDVI offset / decision | +0.0023 / identity | insufficient overlap | −0.0002 / apply (bands only, RMSD −28 %) |
| L7→L8 NDVI offset / decision | +0.0465 / apply | +0.0351 / apply | +0.0513 / apply |
| L9→L8 NDVI offset / decision | +0.0143 / apply | +0.0021 / identity | +0.0116 / identity (fit worsens band RMSD 15 %) |

Conclusions: (i) the ETM+→OLI correction is necessary and transferable (offset 0.035–0.051 everywhere);
(ii) the OLI-2→OLI correction is **provisional** — adopted on the benchmark grid only, it fails the rule
at 30 m in both windows; (iii) band-level coefficients vary with landscape (e.g. blue), so production
should refit district-wide at 30 m and test landscape-stratified coefficients. This stability analysis
is itself a candidate methods contribution.

## 7. Compositing and uncertainty

Per pixel and period: median of clear harmonised observations; counts of observed and clear
observations, per sensor; median day-of-year of clear observations (temporal support); and the
standard error of the median, 1.2533·1.4826·MAD/√n (n ≥ 3), which measures how stable the sample
the composite was drawn from is. Valid-mask classes: 0 outside district, 1 no clear obs, 2 one–two
(low confidence), 3 three or more.

## 8. Downstream modules (milestones; not yet implemented — interfaces only)

- **Hierarchical LULC** (L1: built-up, agriculture, natural vegetation, water, bare, wetland/other;
  L2 only where era-specific separability is demonstrated), with calibrated class probabilities.
- **Change & trajectories:** annual transitions, timing, persistence, velocity, hotspots; area
  estimates with confidence intervals from a stratified reference sample (Olofsson et al. 2014).
- **Agriculture:** S1+S2 phenology 2018+, cropping intensity 1990+, irrigated vs rainfed.
- **Water:** persistence, river width (reproducible centreline/width method), reservoir area series;
  extent ≠ level ≠ depth.
- **Flood:** event hazard (S1), exposure overlay, no damage claims.
- **Urban:** expansion mode, rate, direction, morphology, interpretable driver models.
- **Stress:** availability / demand / ecosystem response / agricultural response kept separate.

## 9. AI/ML principles

Strong baselines first (RF, XGBoost, logistic, CA-Markov where relevant), then temporal models
(TempCNN, LSTM/GRU, temporal transformer) only where a scientific question needs them, with
ablations over modalities. Validation is spatially and temporally blocked; uncertainty via ensembles /
MC-dropout / conformal prediction / calibration and area-of-applicability (Meyer & Pebesma 2021).
Hindcasting gates every scenario.

## References
- Olofsson, P. et al. (2014) Good practices for estimating area and assessing accuracy of land change. *Remote Sensing of Environment* 148, 42–57.
- Pekel, J.-F. et al. (2016) High-resolution mapping of global surface water and its long-term changes. *Nature* 540, 418–422.
- Roy, D.P. et al. (2016) Characterization of Landsat-7 to Landsat-8 reflective wavelength and NDVI continuity. *Remote Sensing of Environment* 185, 57–70.
- Meyer, H., Pebesma, E. (2021) Predicting into unknown space? Estimating the area of applicability of spatial prediction models. *Methods in Ecology and Evolution* 12, 1620–1633.
- Roberts, D.R. et al. (2017) Cross-validation strategies for data with temporal, spatial, hierarchical, or phylogenetic structure. *Ecography* 40, 913–929.
