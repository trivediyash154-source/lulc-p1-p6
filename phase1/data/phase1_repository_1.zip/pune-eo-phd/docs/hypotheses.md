# Hypotheses (provisional — to be refined by literature review and the data)

Status of every hypothesis below: **NOT YET TESTED.** No result in this repository supports or
refutes any of them yet. They are written in advance so tests cannot be tuned after seeing the data.

| ID | Hypothesis | Null | Data needed | Test | Identification |
|---|---|---|---|---|---|
| H1 | Annual land-cover transition is path-dependent: a 30 m cell's multi-year trajectory predicts its next state better than current state + static drivers. | Transition is Markovian (memoryless). | Annual harmonised LULC 1990–2026 with confidence | Sequence model vs Markov / logistic baseline at matched capacity; spatially + temporally blocked CV | Predictive, not causal |
| H2 | Built-up expansion rate near river corridors increased relative to matched non-riparian land after the 2017 Development Plan. | No differential change. | Annual built-up, river centrelines, flood-line vectors (2011 / 2017 / MERI 2025 — **to be acquired**) | Difference-in-differences; spatial regression discontinuity at the flood line | Quasi-experimental; placebo periods required |
| H3 | Downstream cropping intensity in canal command areas changed differently from matched non-command areas as municipal water draw increased. | No differential trend. | Cropping intensity (S1+S2 2018+, Landsat intensity 1990+), command-area vectors (**to acquire**), reservoir area series | DiD with matched controls | Quasi-experimental |
| H4 | Release-normalised inundation extent for a given upstream release increased as upstream impervious area grew. | Inundation per unit release is stationary. | S1 event products, dam-release records (**to acquire**), annual built-up | Regression with event-level controls | Associational unless releases are as-good-as-random |
| H5 | Vegetation greening/browning trends differ between irrigated and rainfed agriculture after controlling for rainfall. | No difference. | Harmonised NDVI/EVI series, rainfall (CHIRPS/IMD), irrigation status | Mixed-effects trend model | Associational |
| H6 | Adding SAR to optical improves monsoon-season classification but not dry-season classification. | No modality gain. | S1+S2 2018+ | Ablation: optical / SAR / optical+SAR / +DEM / +environment | Experimental (ablation) |

## Rules
- A hypothesis may be **revised** only by adding a dated entry below; the original row stays.
- Every test reports effect size with confidence interval, not only p-values.
- Placebo / falsification tests are mandatory for H2–H4.

## Revision log
- 2026-10-01 — v0.1 drafted after archive audit. No data-driven revisions yet.
