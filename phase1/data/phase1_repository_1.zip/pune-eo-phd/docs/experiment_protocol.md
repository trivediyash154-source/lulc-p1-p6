# Experiment protocol

1. **Register before running.** `experiments/<id>/experiment.yaml` states question, hypothesis id,
   data (manifest version, product versions), splits, baselines, metrics, and the decision rule.
2. **Baselines first.** Persistence, Markov/CA-Markov (for transitions), logistic, Random Forest,
   XGBoost. Advanced models (TempCNN, LSTM/GRU, temporal transformer) only with a stated reason.
3. **Ablations for multimodality.** Optical / SAR / optical+SAR / +DEM / +environment, identical
   splits, report deltas with CIs. A modality is "useful" only if the CI excludes zero.
4. **One change at a time.** Each run logs config hash, code commit, seeds, data versions.
5. **Report failures and nulls** in `experiments/<id>/results.md`.
6. **Explain gains.** If an advanced model wins, show where (classes, seasons, regions) and why
   (feature attribution, error analysis), not only the aggregate score.

Worked example (pre-registered here, not yet run): **H6 modality ablation** — 2019–2024 monsoon and
dry-season L1 classification, S2 monthly + S1 monthly features on G10 windows, spatially blocked 5-fold,
metric = balanced accuracy & per-class F1 with bootstrap CI, decision: SAR adds value in monsoon if
ΔBA CI > 0.
