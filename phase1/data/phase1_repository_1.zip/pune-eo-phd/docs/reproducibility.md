# Reproducibility

Every output answers: which satellite, scene, date, processing version, bands, preprocessing,
composite method, harmonisation, code version, configuration.

- **Manifests are immutable** per version and carry the archive cut-off. Re-running discovery later
  produces a new manifest; old products remain traceable to the old one.
- **metadata.json** in every product directory lists every source scene (id, platform, date, tile,
  cloud, clear pixels contributed), the processing block, harmonisation transform, statistics, file
  SHA-256 checksums, the study-area version, the grid definition, and the code block (package
  version, git commit, config hash, Python/GDAL/library versions).
- **Job versions** include processing version + harmonisation + config hash: changing a config
  reprocesses exactly the affected products.
- **Environment:** `pyproject.toml` (pip) and `environment.yml` (conda-forge). Build environment used
  for the benchmark: Python 3.13, GDAL 3.12.2, rasterio 1.5.2.
- **Determinism:** compositing is deterministic given the same manifest and config. Planetary
  Computer can reprocess scenes; the manifest records the item ids actually used.

## Known limitations (as of this build)
- Benchmark products are on G240 (240 m) — diagnostic, not for area statistics. G30 production
  needs a workstation/cloud VM or GEE.
- Harmonisation fitted at 240 m (active for the benchmark). 30 m window tests confirm the L7→L8 correction but not the L9→L8 one — refit district-wide at 30 m before publication.
- Planetary Computer S1 RTC lacks ~half of 2025 S1A frames relative to GRD; no S1C over Pune.
- HLS v2 on Planetary Computer starts 2020 (HLS 2013–2019 needs NASA Earthdata).
- Climate and flood-line vectors, command areas and dam-release records are not yet acquired.
- The Copernicus DEM is a surface model (buildings/canopy included).
