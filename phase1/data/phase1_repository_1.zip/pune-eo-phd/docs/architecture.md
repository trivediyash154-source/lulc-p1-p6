# Architecture

## Layers

```
 ┌──────────────────────────── ACQUISITION ─────────────────────────────┐
 │ STAC discovery (Planetary Computer, anonymous)   GEE backend (auth)  │
 │ → immutable GeoParquet manifests, one row per scene, every exclusion │
 │   reason logged; archive cut-off recorded                            │
 └───────────────────────────────┬──────────────────────────────────────┘
                                 ↓  selected rows only
 ┌──────────────────── PER-OBSERVATION PROCESSING (stage 1) ────────────┐
 │ sign href → read onto fixed grid window (native: exact copy; coarse: │
 │ averaged SR + conservatively aggregated QA) → mask → decode →        │
 │ status {0 not observed, 1 observed-not-clear, 2 clear} → ARD cache   │
 └───────────────────────────────┬──────────────────────────────────────┘
                                 ↓
 ┌──────────────────── TEMPORAL REDUCTION (stage 2) ────────────────────┐
 │ per period (annual / dry / wet / post-monsoon / YYYY-MM / event):    │
 │ harmonise per platform → median, SE of median, counts, per-sensor    │
 │ counts, DOY support → COGs + metadata.json (provenance, checksums)   │
 └───────────────────────────────┬──────────────────────────────────────┘
                                 ↓
 ┌──────────────── QA  (automatic, every product) ──────────────────────┐
 │ CRS / shape / transform on lattice · coverage · depth · radiometry · │
 │ SLC-off · partial period · permanent-water negative control →        │
 │ PASS / WARNING / FAIL written into metadata + QA_REPORT.md           │
 └───────────────────────────────┬──────────────────────────────────────┘
                                 ↓
 features → LULC (hierarchical, probabilistic) → change/trajectories → coupled systems
 → drivers → ML (baselines → advanced, ablations) → uncertainty → HINDCAST GATE → scenarios
 → digital twin (interface last)
```

## Product layout (per grid)

```
data/composites/<grid_id>/<YEAR>/
├── landsat/
│   ├── annual/                     optical_composite.tif  uncertainty.tif  observation_count.tif
│   └── seasonal/{dry,wet,post_monsoon}/   valid_mask.tif  qa.tif  metadata.json
├── sentinel2/                      (2018+ dense; earlier years sparse)
│   ├── annual/ seasonal/<season>/ monthly/<YYYY-MM>/
├── sentinel1/                      (2015+)
│   ├── annual/ seasonal/<season>/ monthly/<YYYY-MM>/  events/<event_id>/
└── metadata/<family>_year_summary.json
```
Calibration products (per-sensor, unharmonised) live under `landsat_cal_<platform>/`.

## Files per optical product

| File | Type | Bands | Meaning |
|---|---|---|---|
| optical_composite.tif | int16, ×1e4, nodata −32768 | blue … swir22 (S2: + red-edge) | median clear harmonised SR |
| uncertainty.tif | int16, ×1e4 | `<band>_se_median` | SE of median (n ≥ 3) |
| observation_count.tif | uint16 | n_clear | clear observations used |
| valid_mask.tif | uint8 | 0/1/2/3 | outside / none / 1–2 / ≥3 clear |
| qa.tif | uint16 | n_observed, n_clear, clear_pct, n_clear_<sensor>…, doy_median_clear | per-pixel provenance |
| metadata.json | JSON | — | full traceability record (see data_dictionary.md) |

SAR products replace the first two with `backscatter_mean_db.tif`, `backscatter_median_db.tif`,
`vv_minus_vh_db.tif`, and `uncertainty.tif` = temporal std (dB).

## Robustness

- **Jobs** = (family, grid, window, year). Ledger in `data/manifests/jobs/`; per-job O_EXCL lock files;
  ledger merged under a file lock on every update; job version = processing version | transform | config hash.
  A config change invalidates exactly the affected jobs.
- **Atomic writes:** every file is written to a temp name and renamed; a crash never leaves a half file.
- **Stage-1 cache** survives crashes: a restarted job reads only the observations not yet cached
  (demonstrated: an interrupted 1995 job resumed in 8.8 s from cache).
- **Memory:** stage 2 works in row blocks sized from a 256 MB budget; independent of district size.

## Scaling path

| Scale | Where | How |
|---|---|---|
| Benchmark G240, all years | laptop / sandbox | `pune-eo composite --grid G240` (≈1–3 min/yr) |
| G30 named windows | laptop | `--grid G30 --window khadakwasla_mutha` |
| G30 full district | workstation or cloud VM near the data, or GEE | `--grid G30` tiles via windows, or `pune-eo gee-export --submit` (148 exact-grid exports) |
| G10 Sentinel-2 dense | cloud VM | per-window, per-year |

## Backends
- **Planetary Computer** (default, executable, anonymous): Landsat C2 L2, S2 L2A, S1 RTC, COP-DEM,
  JRC GSW, WorldCover, HLS v2 (2020+), MODIS, ERA5, TerraClimate.
- **Google Earth Engine** (optional, needs credentials): full-resolution exports on the exact grid.
- CDSE / USGS M2M / Earthdata: credential slots in `.env.example`; not used by default.
