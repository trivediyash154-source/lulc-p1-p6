"""Atomic, crash-safe writers. A file either exists complete or not at all."""
from __future__ import annotations
import json, os, tempfile
from pathlib import Path
import numpy as np
import rasterio
from rasterio.shutil import copy as rio_copy

def _tmp(path: Path) -> Path:
    path.parent.mkdir(parents=True, exist_ok=True)
    fd, name = tempfile.mkstemp(dir=path.parent, prefix=f".{path.name}.", suffix=".tmp")
    os.close(fd)
    return Path(name)

def write_json(path: Path, obj) -> None:
    path = Path(path); tmp = _tmp(path)
    with open(tmp, "w") as f:
        json.dump(obj, f, indent=1, default=_jsonable)
    os.replace(tmp, path)
    os.chmod(path, 0o644)

def _jsonable(o):
    if isinstance(o, (np.integer,)): return int(o)
    if isinstance(o, (np.floating,)): return None if np.isnan(o) else float(o)
    if isinstance(o, np.ndarray): return o.tolist()
    if isinstance(o, Path): return str(o)
    return str(o)

def write_cog(path: Path, array: np.ndarray, grid, *, nodata, dtype: str,
              descriptions: list[str] | None = None, overview_resampling: str = "average",
              tags: dict | None = None) -> Path:
    """Write (bands, rows, cols) array as a Cloud-Optimised GeoTIFF on `grid`, atomically."""
    path = Path(path)
    arr = array if array.ndim == 3 else array[None]
    gtiff = _tmp(path.with_suffix(".stage.tif"))
    prof = dict(driver="GTiff", width=grid.width, height=grid.height, count=arr.shape[0],
                dtype=dtype, crs=grid.crs, transform=grid.transform, nodata=nodata,
                tiled=True, blockxsize=256, blockysize=256, compress="deflate")
    with rasterio.open(gtiff, "w", **prof) as dst:
        dst.write(arr.astype(dtype))
        if descriptions:
            dst.descriptions = tuple(descriptions)
        if tags:
            dst.update_tags(**{k: str(v) for k, v in tags.items()})
    tmp = _tmp(path)
    pred = 3 if np.dtype(dtype).kind == "f" else 2
    rio_copy(gtiff, tmp, driver="COG", compress="DEFLATE", predictor=pred,
             overview_resampling=overview_resampling, blocksize=256)
    os.replace(tmp, path)
    os.chmod(path, 0o644)
    gtiff.unlink(missing_ok=True)
    return path

def write_parquet(path: Path, df) -> None:
    path = Path(path); tmp = _tmp(path)
    if hasattr(df, "geometry") and getattr(df, "_geometry_column_name", None):
        df.to_parquet(tmp, index=False)
    else:
        df.to_parquet(tmp, index=False)
    os.replace(tmp, path)
    os.chmod(path, 0o644)
