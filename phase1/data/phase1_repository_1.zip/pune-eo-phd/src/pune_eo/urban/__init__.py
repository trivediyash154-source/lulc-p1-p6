"""Module: urban — milestone scaffold (interfaces fixed, science not yet implemented).

Nothing in this package produces research results yet. Functions raise NotImplementedError with
the milestone that delivers them; see docs/methodology.md section 8 and docs/experiment_protocol.md.
"""

def expansion_modes(*_, **__):
    """Edge / infill / leapfrog classification of new built-up (M4)."""
    raise NotImplementedError("M4")
