"""Automated data QA: every product gets PASS / WARNING / FAIL with explicit reasons.

Checks: geometry/CRS/grid alignment, extent, nodata, district coverage, observation depth,
radiometric plausibility, sensor consistency (SLC-off only), completeness, metadata, and a
data-driven negative control (JRC permanent-water cells must read as water: MNDWI > 0).
"""
from __future__ import annotations
import json
from pathlib import Path
import numpy as np
import pandas as pd
import rasterio
from .. import config
from ..grid import Grid
from ..io import write_json

def _grid_from_meta(g: dict) -> Grid:
    return Grid(g["id"], g["crs"], g["res"], g["x0"], g["y1"], g["width"], g["height"], g["corner_offset"])

def check_product(meta_path: Path, perm_water: np.ndarray | None = None) -> dict:
    meta = json.loads(Path(meta_path).read_text())
    is_sar = meta["product_id"].startswith("sentinel1/")
    cfg = config.load("qa")["sar_composite" if is_sar else "optical_composite"]
    req = config.load("qa")["required_metadata"]
    fails, warns, info = [], [], {}
    st = meta["statistics"]; grid = _grid_from_meta(meta["grid"])
    if not meta["temporal"]["complete"] and st["n_items"] == 0:
        res = {"product_id": meta["product_id"], "status": "IN_PROGRESS", "fail": [], "warn": [],
               "note": f"period in progress at the archive cut-off {meta['temporal']['archive_cutoff_utc'][:16]} with no acquisitions yet - nothing to assess"}
        meta["qa"] = res; write_json(meta_path, meta); return res
    # metadata completeness
    missing = [k for k in req if k not in meta]
    if missing: fails.append(f"metadata missing {missing}")
    # files: existence, checksum, CRS, transform, shape (pixel alignment)
    for name, f in meta["files"].items():
        p = config.ROOT / f["path"]
        if not p.exists(): fails.append(f"missing file {name}"); continue
        with rasterio.open(p) as s:
            if s.crs.to_string() != grid.crs: fails.append(f"{name}: CRS {s.crs} != {grid.crs}")
            if (s.height, s.width) != grid.shape: fails.append(f"{name}: shape {s.shape} != grid {grid.shape}")
            if any(abs(a - b) > 1e-6 for a, b in zip(list(s.transform)[:6], list(grid.transform)[:6])):
                fails.append(f"{name}: transform not on grid lattice")
    vf = st["district_valid_fraction"]
    info["district_valid_fraction"] = round(vf, 4)
    if vf < cfg["fail"]["district_valid_fraction_lt"]: fails.append(f"district valid coverage {vf:.1%} < 50%")
    elif vf < cfg["warn"]["district_valid_fraction_lt"]: warns.append(f"district valid coverage {vf:.1%} < 95%")
    if st["n_clear_median"] < cfg["warn"]["median_clear_obs_lt"]:
        warns.append(f"median clear observations {st['n_clear_median']:.0f} < {cfg['warn']['median_clear_obs_lt']} (composite statistically weak)")
    if st["single_obs_fraction"] > cfg["warn"]["single_obs_fraction_gt"]:
        warns.append(f"{st['single_obs_fraction']:.0%} of district from a single observation")
    lo, hi = cfg["fail"].get("band_median_outside", (-1e9, 1e9))
    for b, v in (st.get("band_medians") or {}).items():
        if v is not None and not (lo <= v <= hi): fails.append(f"band {b} median {v:.3f} outside [{lo},{hi}]")
    sens = meta.get("sensors", {})
    slc_off = config.load("landsat")["platforms"]["landsat-7"]["slc_off_from"]
    if sens and set(sens) == {"landsat-7"} and meta["temporal"]["end"] > slc_off:
        warns.append("Landsat-7 SLC-off is the only sensor (striping gaps filled only by repeat passes)")
    if not meta["temporal"]["complete"]:
        warns.append(f"PARTIAL period: archive cut-off {meta['temporal']['archive_cutoff_utc'][:10]}")
    # negative control: permanent water must read as water
    if perm_water is not None and "optical_composite" in meta["files"]:
        with rasterio.open(config.ROOT / meta["files"]["optical_composite"]["path"]) as s:
            names = list(s.descriptions); g = s.read(names.index("green") + 1).astype(float); sw = s.read(names.index("swir16") + 1).astype(float)
        ok = perm_water & (g != -32768) & (sw != -32768)
        if ok.sum() >= 5:
            mndwi = (g[ok] - sw[ok]) / (g[ok] + sw[ok])
            frac = float((mndwi > 0).mean())
            info["permanent_water_control"] = {"cells": int(ok.sum()), "fraction_mndwi_gt0": round(frac, 3),
                                               "median_mndwi": round(float(np.median(mndwi)), 3)}
            if frac < cfg["fail"]["permanent_water_mndwi_pass_lt"]: fails.append(f"negative control: only {frac:.0%} of permanent-water cells read as water")
            elif frac < cfg["warn"]["permanent_water_mndwi_pass_lt"]: warns.append(f"negative control weak: {frac:.0%} of permanent-water cells read as water")
        else:
            info["permanent_water_control"] = {"cells": int(ok.sum()), "note": "too few observed permanent-water cells"}
    # residual cloud / haze missed by the sensor's own QA: TRANSIENT bright blue. Pixels that are bright in the
    # robust baseline (annual median; dry median for the annual product itself) are bright SURFACES (roofs,
    # roads, quarries) and are excluded, which keeps the test resolution-independent.
    if "optical_composite" in meta["files"]:
        thr = config.load("qa")["residual_cloud_blue_threshold"] * 1e4
        def _blue(path):
            with rasterio.open(path) as src:
                return src.read(list(src.descriptions).index("blue") + 1).astype(float)
        blue = _blue(config.ROOT / meta["files"]["optical_composite"]["path"])
        pdir = (config.ROOT / meta["files"]["optical_composite"]["path"]).parent
        fam_dir = pdir.parent if meta["temporal"]["kind"] == "annual" else pdir.parent.parent   # .../<year>/<family>
        base_p = fam_dir / ("seasonal/dry" if meta["temporal"]["kind"] == "annual" else "annual") / "optical_composite.tif"
        persistent = np.zeros(blue.shape, bool)
        if base_p.exists():
            bb = _blue(base_p); persistent = (bb != -32768) & (bb > thr)
        v = (blue != -32768) & ~persistent
        if v.sum() > 0:
            rc = float((blue[v] > thr).mean()); info["residual_cloud_fraction"] = round(rc, 4)
            info["persistent_bright_excluded_px"] = int(persistent.sum())
            if rc > cfg.get("fail", {}).get("residual_cloud_fraction_gt", 9): fails.append(f"residual cloud/haze: {rc:.0%} of valid pixels transiently bright (blue SR > {thr/1e4:.2f})")
            elif rc > cfg.get("warn", {}).get("residual_cloud_fraction_gt", 9): warns.append(f"possible residual cloud/haze: {rc:.1%} of valid pixels transiently bright (blue SR > {thr/1e4:.2f})")
    status = "FAIL" if fails else ("WARNING" if warns else "PASS")
    res = {"product_id": meta["product_id"], "status": status, "fail": fails, "warn": warns, **info}
    meta["qa"] = res
    write_json(meta_path, meta)
    return res

def run_qa(grid_id: str, family: str = "landsat") -> pd.DataFrame:
    from ..acquisition.reference import permanent_water
    root = config.path("data", "composites", grid_id)
    metas = sorted(root.glob(f"*/{family}/**/metadata.json"))
    pw = None
    if metas:
        g = _grid_from_meta(json.loads(metas[0].read_text())["grid"])
        try:
            pw = permanent_water(g)
        except Exception as e:
            print("negative control unavailable:", e)
    rows = []
    for m in metas:
        r = check_product(m, pw)
        meta = json.loads(m.read_text())
        st = meta["statistics"]
        rows.append({"year": meta["temporal"]["year"], "period": meta["temporal"]["period"], "status": r["status"],
                     "complete": meta["temporal"]["complete"], "sensors": ",".join(sorted(meta.get("sensors", {}))),
                     "n_items": st["n_items"], "valid_pct": round(100 * st["district_valid_fraction"], 1),
                     "reliable_pct": round(100 * st["district_reliable_fraction_ge3"], 1),
                     "n_clear_median": st["n_clear_median"], "clear_pct_mean": round(st["clear_pct_mean"], 1),
                     "water_control": (r.get("permanent_water_control") or {}).get("fraction_mndwi_gt0"),
                     "residual_cloud_pct": None if r.get("residual_cloud_fraction") is None else round(100 * r["residual_cloud_fraction"], 2),
                     "reasons": " | ".join(r["fail"] + r["warn"]) or r.get("note", "")})
    df = pd.DataFrame(rows).sort_values(["year", "period"]).reset_index(drop=True)
    out = config.path("results", "qa", family, grid_id); out.mkdir(parents=True, exist_ok=True)
    df.to_parquet(out / "qa_summary.parquet", index=False); df.to_csv(out / "qa_summary.csv", index=False)
    return df
