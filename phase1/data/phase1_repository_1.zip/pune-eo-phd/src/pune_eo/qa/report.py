"""Human-readable automated QA report (markdown) + machine-readable summary."""
from __future__ import annotations
import json
import pandas as pd
from .. import config
from .checks import run_qa

def qa_report(grid_id: str, family: str = "landsat") -> str:
    df = run_qa(grid_id, family)
    out = config.path("results", "qa", family, grid_id)
    L = [f"# Pune EO Data QA Report — {family} — grid `{grid_id}`", "",
         "Generated automatically by `pune-eo qa`. Thresholds: `configs/qa.yaml`. Every product's full QA record is",
         "also written into its own `metadata.json` (`qa` block).", "",
         "## Summary", "", df.groupby(["period", "status"]).size().unstack(fill_value=0).to_markdown(), "",
         "## Per-year records", ""]
    for y, g in df.groupby("year"):
        L.append(f"### {y}"); L.append("")
        for _, r in g.iterrows():
            L += [f"**{r['period']}** — Status: **{r['status']}**" + ("" if r["complete"] else " (PARTIAL)"),
                  f"- Sensors: {r['sensors'] or '—'} · scenes: {r['n_items']}",
                  f"- Valid district coverage: {r['valid_pct']}% · reliable (≥3 clear obs): {r['reliable_pct']}%",
                  f"- Median clear observations per pixel: {r['n_clear_median']:.0f} · mean clear fraction of observations: {r['clear_pct_mean']}%",
                  f"- Permanent-water negative control (share of JRC permanent-water cells with MNDWI>0): "
                  + (f"{r['water_control']:.0%}" if pd.notna(r["water_control"]) else "n/a"),
                  f"- Residual-cloud check (valid pixels with blue SR > 0.15): " + (f"{r['residual_cloud_pct']}%" if pd.notna(r.get("residual_cloud_pct")) else "n/a"),
                  f"- Reasons: {r['reasons'] or 'none'}", ""]
    p = out / "QA_REPORT.md"; p.write_text("\n".join(L))
    return str(p)
