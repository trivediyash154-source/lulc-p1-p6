"""Google Earth Engine backend: full-resolution (G30) Landsat exports for every year x period.

STATUS: written against the documented earthengine-api; NOT EXECUTED in the build environment
(no Earth Engine credentials there). `plan` mode runs anywhere; `--submit` needs GEE_PROJECT in
.env and `earthengine authenticate`. It fails with an explicit message otherwise.

Science is identical to the local engine: Collection-2 L2 Tier-1, QA_PIXEL bits from
configs/landsat.yaml, saturation masked, negative SR clipped to 0, the ACTIVE harmonisation
transform applied per platform, per-pixel median + clear counts + per-sensor counts, exported on
the EXACT analysis grid (crs + crsTransform + dimensions -> no implicit resampling grid).
Resumable: tasks whose description already exists (READY/RUNNING/COMPLETED) are not resubmitted.
"""
from __future__ import annotations
import os
from .. import config
from ..grid import district_grid
from ..compositing.periods import standard_periods

EE_COLL = {"landsat-5": "LANDSAT/LT05/C02/T1_L2", "landsat-7": "LANDSAT/LE07/C02/T1_L2",
           "landsat-8": "LANDSAT/LC08/C02/T1_L2", "landsat-9": "LANDSAT/LC09/C02/T1_L2"}
EE_BANDS = {"landsat-5": ["SR_B1", "SR_B2", "SR_B3", "SR_B4", "SR_B5", "SR_B7"],
            "landsat-7": ["SR_B1", "SR_B2", "SR_B3", "SR_B4", "SR_B5", "SR_B7"],
            "landsat-8": ["SR_B2", "SR_B3", "SR_B4", "SR_B5", "SR_B6", "SR_B7"],
            "landsat-9": ["SR_B2", "SR_B3", "SR_B4", "SR_B5", "SR_B6", "SR_B7"]}
NAMES = ["blue", "green", "red", "nir08", "swir16", "swir22"]

def _init():
    config.load_env()
    proj = os.getenv("GEE_PROJECT")
    if not proj:
        raise RuntimeError("GEE_PROJECT is not set. Copy .env.example to .env, set GEE_PROJECT, run `earthengine authenticate`.")
    try:
        import ee
    except ImportError as e:
        raise RuntimeError("earthengine-api not installed: pip install -e .[gee]") from e
    ee.Initialize(project=proj)
    return ee

def _coefs(platform: str):
    from ..harmonization.landsat import transform_spec
    spec = transform_spec()
    if spec["name"] == "none": return None
    if spec.get("per_platform"):
        c = spec["per_platform"].get(platform)
        return None if c is None else ([c["slope"][b] for b in NAMES], [c["intercept"][b] for b in NAMES])
    if platform in spec.get("applies_to", []):
        return [spec["slope"][b] for b in NAMES], [spec["intercept"][b] for b in NAMES]
    return None

def _collection(ee, platform, start, end, region):
    cfg = config.load("landsat"); bits = sum(1 << int(b) for b in cfg["qa_mask_bits"].values())
    lo, hi = cfg["valid_dn"]; coefs = _coefs(platform)
    def prep(img):
        clear = img.select("QA_PIXEL").bitwiseAnd(bits).eq(0)
        sr = img.select(EE_BANDS[platform], NAMES)
        unsat = sr.lte(hi).reduce(ee.Reducer.min())
        refl = sr.multiply(cfg["scale"]).add(cfg["offset"]).max(0)
        if coefs:
            refl = refl.multiply(ee.Image.constant(coefs[0]).rename(NAMES)).add(ee.Image.constant(coefs[1]).rename(NAMES))
        return refl.updateMask(clear.And(unsat)).set("platform", platform)
    end_cap = config.load("landsat")["platforms"][platform].get("end")
    if end_cap and end > end_cap: end = end_cap
    if start > end: return None
    return (ee.ImageCollection(EE_COLL[platform]).filterBounds(region).filterDate(start, end)
            .filter(ee.Filter.lte("CLOUD_COVER", cfg["selection"]["max_scene_cloud"])).map(prep))

def build_image(ee, period, region):
    cols = [c for p in EE_COLL if (c := _collection(ee, p, period.start.strftime("%Y-%m-%d"),
                                                      (period.end + __import__("pandas").Timedelta(seconds=1)).strftime("%Y-%m-%d"), region)) is not None]
    merged = cols[0]
    for c in cols[1:]: merged = merged.merge(c)
    med = merged.median()
    mad = merged.map(lambda i: i.subtract(med).abs()).median()
    n = merged.select("red").count().rename("n_clear")
    se = mad.multiply(1.2533 * 1.4826).divide(n.max(1).sqrt()).updateMask(n.gte(3)).rename([f"{b}_se" for b in NAMES])
    per = [merged.filter(ee.Filter.eq("platform", p)).select("red").count().unmask(0).rename(f"n_{p.replace('-', '_')}") for p in EE_COLL]
    return (med.multiply(10000).round().toInt16()
            .addBands(se.multiply(10000).round().toInt16())
            .addBands(n.toInt16()).addBands(ee.Image.cat(per).toInt16())
            .set({"year": period.year, "period": period.name}))

def plan_exports(years, grid_name: str = "G30", submit: bool = False) -> dict:
    g = district_grid(grid_name)
    jobs = [{"description": f"pune_landsat_{g.id}_{p.year}_{p.name}", "year": p.year, "period": p.name,
             "crs": g.crs, "crsTransform": [g.res, 0, g.x0, 0, -g.res, g.y1], "dimensions": f"{g.width}x{g.height}"}
            for y in years for p in standard_periods(y)]
    out = {"grid": g.id, "n_jobs": len(jobs), "submitted": [], "skipped_existing": [], "jobs_preview": jobs[:3]}
    if not submit:
        out["note"] = "plan only - add --submit (requires GEE credentials) to start exports"
        return out
    ee = _init()
    existing = {t.config.get("description") for t in ee.batch.Task.list() if t.state in ("READY", "RUNNING", "COMPLETED")}
    region = ee.Geometry.Rectangle(list(g.bounds), proj=g.crs, geodesic=False)
    dest = os.getenv("GEE_EXPORT_BUCKET")
    from ..compositing.periods import Period
    per = {(p.year, p.name): p for y in years for p in standard_periods(y)}
    for j in jobs:
        if j["description"] in existing:
            out["skipped_existing"].append(j["description"]); continue
        img = build_image(ee, per[(j["year"], j["period"])], region)
        kw = dict(image=img, description=j["description"], fileNamePrefix=j["description"], crs=j["crs"],
                  crsTransform=j["crsTransform"], dimensions=j["dimensions"], maxPixels=1e13,
                  fileFormat="GeoTIFF", formatOptions={"cloudOptimized": True})
        task = (ee.batch.Export.image.toCloudStorage(bucket=dest.replace("gs://", ""), **kw) if dest
                else ee.batch.Export.image.toDrive(folder=os.getenv("GEE_EXPORT_DRIVE_FOLDER", "pune_eo_exports"), **kw))
        task.start(); out["submitted"].append(j["description"])
    return out
