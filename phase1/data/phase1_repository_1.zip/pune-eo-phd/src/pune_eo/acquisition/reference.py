"""Independent reference layers on the analysis grids (QA controls, cross-checks - never silent labels)."""
from __future__ import annotations
import numpy as np
import planetary_computer as pc
import rasterio
from rasterio.enums import Resampling
from rasterio.vrt import WarpedVRT
from .. import config
from ..grid import Grid
from ..io import write_cog, write_json
from ..provenance import utcnow
from .stac import client
from .boundary import load_study_area

def jrc_occurrence(grid: Grid) -> str:
    """JRC GSW occurrence (1984-2021) on `grid`, MIN-resampled: a cell's value is the lowest
    occurrence of any 30 m sub-pixel, so >=95 means the whole cell is permanent water."""
    bbox = list(load_study_area(4326).total_bounds)
    items = list(client().search(collections=["jrc-gsw"], bbox=bbox).items())
    out = np.full(grid.shape, 255, np.uint8)
    for it in items:
        with rasterio.Env(**config.GDAL_ENV), rasterio.open(it.assets["occurrence"].href) as src:
            with WarpedVRT(src, crs=grid.crs, transform=grid.transform, width=grid.width, height=grid.height,
                           resampling=Resampling.min if grid.res > 30 else Resampling.nearest,
                           src_nodata=255, nodata=255) as v:
                a = v.read(1)
        m = a != 255; out[m] = a[m]
    path = config.path("data", "features", "reference", grid.id, "jrc_gsw_occurrence_min.tif")
    write_cog(path, out, grid, nodata=255, dtype="uint8", descriptions=["jrc_gsw_occurrence_pct_min"],
              overview_resampling="nearest")
    write_json(path.with_suffix(".json"), {"source": "JRC Global Surface Water v1.4 occurrence (1984-2021)",
               "items": [i.id for i in items], "resampling": "min" if grid.res > 30 else "nearest",
               "created_utc": utcnow(), "grid": grid.to_dict()})
    return str(path)

def permanent_water(grid: Grid, min_occ: int | None = None) -> np.ndarray:
    min_occ = min_occ or config.load("reference")["jrc_gsw"]["permanent_water_occurrence_min"]
    p = config.path("data", "features", "reference", grid.id, "jrc_gsw_occurrence_min.tif")
    if not p.exists():
        jrc_occurrence(grid)
    with rasterio.open(p) as s:
        a = s.read(1)
    return (a >= min_occ) & (a != 255)

def worldcover(grid: Grid, year: int = 2021) -> str:
    """ESA WorldCover (10 m) on `grid` by MODE resampling - cross-check/stratification only, never labels."""
    bbox = list(load_study_area(4326).total_bounds)
    items = [i for i in client().search(collections=["esa-worldcover"], bbox=bbox).items()
             if str(i.properties.get("start_datetime", ""))[:4] == str(year)]
    out = np.zeros(grid.shape, np.uint8)
    for it in items:
        with rasterio.Env(**config.GDAL_ENV), rasterio.open(it.assets["map"].href) as src:
            with WarpedVRT(src, crs=grid.crs, transform=grid.transform, width=grid.width, height=grid.height,
                           resampling=Resampling.mode, src_nodata=0, nodata=0) as v:
                a = v.read(1)
        m = a > 0; out[m] = a[m]
    path = config.path("data", "features", "reference", grid.id, f"esa_worldcover_{year}_mode.tif")
    write_cog(path, out, grid, nodata=0, dtype="uint8", descriptions=[f"esa_worldcover_{year}"], overview_resampling="nearest")
    write_json(path.with_suffix(".json"), {"source": f"ESA WorldCover {year} v2", "items": [i.id for i in items],
               "resampling": "mode", "created_utc": utcnow(), "grid": grid.to_dict()})
    return str(path)
