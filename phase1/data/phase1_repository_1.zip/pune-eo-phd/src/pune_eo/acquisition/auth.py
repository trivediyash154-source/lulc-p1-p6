"""Credential checks. Every optional backend fails CLEARLY when credentials are missing."""
from __future__ import annotations
import os
from .. import config

def check() -> dict:
    config.load_env()
    res = {}
    try:  # Planetary Computer: anonymous
        from .stac import client
        c = client(); next(c.search(collections=["landsat-c2-l2"], max_items=1).items())
        res["planetary_computer"] = "OK (anonymous; PC_SDK_SUBSCRIPTION_KEY " + ("set)" if os.getenv("PC_SDK_SUBSCRIPTION_KEY") else "not set - fine)")
    except Exception as e:
        res["planetary_computer"] = f"FAIL: {e!r}"
    proj = os.getenv("GEE_PROJECT")
    if not proj:
        res["google_earth_engine"] = "NOT CONFIGURED: set GEE_PROJECT in .env and run `earthengine authenticate`"
    else:
        try:
            import ee
            ee.Initialize(project=proj); ee.Number(1).getInfo()
            res["google_earth_engine"] = f"OK (project {proj})"
        except ImportError:
            res["google_earth_engine"] = "FAIL: pip install earthengine-api  (or: pip install -e .[gee])"
        except Exception as e:
            res["google_earth_engine"] = f"FAIL: {e!r} -> run `earthengine authenticate` and check project permissions"
    for name, keys in {"copernicus_dataspace": ["CDSE_USERNAME", "CDSE_PASSWORD"],
                       "usgs_m2m": ["USGS_USERNAME", "USGS_TOKEN"],
                       "nasa_earthdata": ["EARTHDATA_USERNAME", "EARTHDATA_PASSWORD"]}.items():
        res[name] = "credentials present (not exercised by default pipeline)" if all(os.getenv(k) for k in keys) \
            else f"NOT CONFIGURED: set {', '.join(keys)} in .env (optional backend)"
    return res
