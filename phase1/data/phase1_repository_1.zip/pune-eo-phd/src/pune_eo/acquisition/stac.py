"""STAC discovery with pagination, retries and signing (Planetary Computer)."""
from __future__ import annotations
import logging, time
import planetary_computer as pc
from pystac_client import Client
from pystac_client.stac_api_io import StacApiIO
from urllib3 import Retry

log = logging.getLogger(__name__)
PC_API = "https://planetarycomputer.microsoft.com/api/stac/v1"

def client(api: str = PC_API, sign: bool = True) -> Client:
    io = StacApiIO(max_retries=Retry(total=6, backoff_factor=2, status_forcelist=[429, 500, 502, 503, 504],
                                     allowed_methods=None))
    return Client.open(api, modifier=pc.sign_inplace if sign else None, stac_io=io)

def search_all(collection: str, bbox, start: str, end: str, query: dict | None = None,
               intersects=None, chunk_by_year: bool = True, api: str = PC_API):
    """Yield every item; searches are split per year to keep pages small and restartable."""
    cat = client(api, sign=False)
    y0, y1 = int(start[:4]), int(end[:4])
    spans = [(f"{y}-01-01" if y > y0 else start, f"{y}-12-31T23:59:59Z" if y < y1 else end)
             for y in range(y0, y1 + 1)] if chunk_by_year else [(start, end)]
    for a, b in spans:
        for attempt in range(5):
            try:
                kw = dict(collections=[collection], datetime=f"{a}/{b}", limit=500)
                if intersects is not None: kw["intersects"] = intersects
                else: kw["bbox"] = bbox
                if query: kw["query"] = query
                items = list(cat.search(**kw).items())
                log.info("%s %s..%s: %d items", collection, a[:10], b[:10], len(items))
                yield from items
                break
            except Exception as e:
                log.warning("search failed (%s), retry %d", e, attempt + 1)
                time.sleep(5 * (attempt + 1))
        else:
            raise RuntimeError(f"STAC search failed permanently for {collection} {a}..{b}")

def sign_href(href: str) -> str:
    return pc.sign(href)
