"""Machine-readable acquisition manifests (GeoParquet).

A manifest is IMMUTABLE per version: it records what the archive contained at the cut-off
time and which observations were selected (and why others were excluded). Processing state
is tracked separately in data/manifests/processing_log.parquet.
"""
from __future__ import annotations
import json, logging
from datetime import datetime, timezone
import geopandas as gpd
import numpy as np
import pandas as pd
from shapely.geometry import shape
from .. import config, SCHEMA_VERSION
from ..io import write_parquet, write_json
from .boundary import load_study_area
from .stac import search_all, PC_API

log = logging.getLogger(__name__)
MANIFEST_VERSION = "1.0.0"

# column -> (dtype, description). The data dictionary is generated from this.
SCHEMA = {
    "product_id": ("string", "STAC item id (scene/product identifier)"),
    "collection": ("string", "STAC collection id"),
    "source": ("string", "data provider / backend"),
    "stac_api": ("string", "STAC API root"),
    "stac_item_href": ("string", "unsigned STAC item URL (permanent reference)"),
    "platform": ("string", "satellite platform, e.g. landsat-5, sentinel-2b"),
    "instrument": ("string", "sensor, e.g. TM, ETM+, OLI, MSI, C-SAR"),
    "datetime_utc": ("datetime64[ns, UTC]", "acquisition time (UTC)"),
    "date": ("string", "acquisition date YYYY-MM-DD (UTC)"),
    "year": ("int16", "acquisition year"),
    "month": ("int8", "acquisition month"),
    "doy": ("int16", "day of year"),
    "season": ("string", "dry / wet / post_monsoon per configs/temporal.yaml"),
    "tile_id": ("string", "WRS-2 P###R###, MGRS tile, or S1 orbit/relative-orbit"),
    "wrs_path": ("string", "Landsat WRS-2 path"),
    "wrs_row": ("string", "Landsat WRS-2 row"),
    "mgrs_tile": ("string", "Sentinel-2 MGRS tile"),
    "relative_orbit": ("Int32", "Sentinel-1 relative orbit"),
    "orbit_state": ("string", "Sentinel-1 ascending/descending"),
    "cloud_cover": ("float32", "scene cloud cover % (provider metadata; optical only)"),
    "processing_level": ("string", "L2SP / L1 / L2A / RTC"),
    "collection_category": ("string", "Landsat tier T1/T2/RT"),
    "processing_baseline": ("string", "Sentinel-2 processing baseline"),
    "sun_elevation": ("float32", "sun elevation (deg) where available"),
    "district_overlap_km2": ("float32", "area of footprint inside the study area (equal-area CRS)"),
    "district_overlap_fraction": ("float32", "fraction of the study area covered by this footprint"),
    "quality_flags": ("string", "semicolon-separated flags, e.g. SLC_OFF;T2"),
    "role": ("string", "primary / context_only / reference"),
    "selected": ("bool", "true if the observation enters processing"),
    "exclusion_reason": ("string", "why not selected (null if selected)"),
    "asset_keys": ("string", "semicolon-separated asset keys available"),
    "asset_hrefs": ("string", "JSON {asset_key: unsigned href} for raster assets - processing never guesses file names"),
    "cloud_path": ("string", "unsigned href of the primary asset (cloud-native location)"),
    "local_path": ("string", "local cache path (null until cached)"),
    "processing_status": ("string", "discovered / selected / excluded (processing state lives in processing_log)"),
    "manifest_version": ("string", "manifest schema version"),
    "archive_cutoff_utc": ("datetime64[ns, UTC]", "time the archive was queried; later data is not in this manifest"),
}

def _search_geom(sa):
    """Simplified polygon for the STAC query only; overlap is recomputed with the exact boundary."""
    return sa.geometry.iloc[0].buffer(0.02).simplify(0.01).__geo_interface__

def _season(month: int) -> str:
    for name, spec in config.load("temporal")["periods"].items():
        if name != "annual" and month in spec["months"]:
            return name
    return "unknown"

def _base_rows(items, collection: str) -> list[dict]:
    rows = []
    for it in items:
        p = it.properties
        dt = pd.Timestamp(it.datetime or p.get("start_datetime")).tz_convert("UTC") if (it.datetime or p.get("start_datetime")) else pd.NaT
        self_href = next((l.href for l in it.links if l.rel == "self"), f"{PC_API}/collections/{collection}/items/{it.id}")
        rows.append({
            "product_id": it.id, "collection": collection, "source": "planetary_computer", "stac_api": PC_API,
            "stac_item_href": self_href, "platform": (p.get("platform") or "").lower(),
            "instrument": ",".join(p.get("instruments", []) or []).upper(),
            "datetime_utc": dt, "date": dt.strftime("%Y-%m-%d"), "year": dt.year, "month": dt.month,
            "doy": dt.dayofyear, "season": _season(dt.month),
            "wrs_path": p.get("landsat:wrs_path"), "wrs_row": p.get("landsat:wrs_row"),
            "mgrs_tile": p.get("s2:mgrs_tile"), "relative_orbit": p.get("sat:relative_orbit"),
            "orbit_state": p.get("sat:orbit_state"), "cloud_cover": p.get("eo:cloud_cover"),
            "collection_category": p.get("landsat:collection_category"),
            "processing_baseline": p.get("s2:processing_baseline"),
            "sun_elevation": p.get("view:sun_elevation"),
            "asset_keys": ";".join(sorted(it.assets.keys())),
            "asset_hrefs": json.dumps({k: a.href for k, a in it.assets.items() if a.href.lower().split("?")[0].endswith((".tif", ".tiff"))}),
            "cloud_path": next((it.assets[k].href for k in ("red", "B04", "vv", "green", "data") if k in it.assets), None),
            "geometry": shape(it.geometry),
        })
    return rows

def _overlap(gdf: gpd.GeoDataFrame) -> gpd.GeoDataFrame:
    eq = config.load("study_area")["equal_area_crs"]
    sa = load_study_area(eq).geometry.iloc[0]
    ge = gdf.to_crs(eq)
    inter = ge.geometry.intersection(sa).area
    gdf["district_overlap_km2"] = (inter / 1e6).astype("float32")
    gdf["district_overlap_fraction"] = (inter / sa.area).astype("float32")
    return gdf

def _finalise(rows: list[dict], cutoff) -> gpd.GeoDataFrame:
    gdf = gpd.GeoDataFrame(rows, geometry="geometry", crs=4326)
    gdf = _overlap(gdf)
    gdf["manifest_version"] = MANIFEST_VERSION
    gdf["archive_cutoff_utc"] = cutoff
    gdf["local_path"] = None
    gdf["processing_status"] = np.where(gdf["selected"], "selected", "excluded")
    for col, (dt, _) in SCHEMA.items():
        if col not in gdf:
            gdf[col] = None
        try:
            if dt.startswith("datetime"):
                gdf[col] = pd.to_datetime(gdf[col], utc=True)
            elif dt == "bool":
                gdf[col] = gdf[col].astype(bool)
            else:
                gdf[col] = gdf[col].astype(dt)
        except Exception:
            pass
    return gdf[list(SCHEMA) + ["geometry"]].sort_values("datetime_utc").reset_index(drop=True)

# ------------------------------------------------------------------ Landsat
def discover_landsat(end: str | None = None) -> gpd.GeoDataFrame:
    cfg = config.load("landsat")
    sa = load_study_area(4326)
    cutoff = pd.Timestamp.now(tz="UTC")
    end = end or cutoff.strftime("%Y-%m-%dT%H:%M:%SZ")
    rows = _base_rows(search_all(cfg["collection"], None, cfg["discovery_start"], end, intersects=_search_geom(sa)),
                      cfg["collection"])
    for r in rows:
        r["processing_level"] = "L2SP" if "_L2SP_" in r["product_id"] else ("L2SR" if "_L2SR_" in r["product_id"] else "L2")
    mss = _base_rows(search_all(cfg["context_collection"], None, "1972-01-01", "1999-12-31", intersects=_search_geom(sa)),
                     cfg["context_collection"])
    for r in mss:
        r["processing_level"] = "L1"
    rows += mss
    sel = cfg["selection"]; plats = cfg["platforms"]
    for r in rows:
        flags, reason, role = [], None, "primary"
        pl = r["platform"]; d = r["date"]
        if r["collection"] == cfg["context_collection"]:
            role, reason = "context_only", "MSS/L1: no SWIR, 60 m, not surface reflectance - historical context only"
        elif pl not in plats:
            reason = f"platform {pl} not configured"
        else:
            spec = plats[pl]
            if spec.get("slc_off_from") and d >= spec["slc_off_from"]:
                flags.append("SLC_OFF")
            if r["collection_category"] not in sel["collection_category"]:
                flags.append(str(r["collection_category"]))
                reason = f"tier {r['collection_category']} (only {sel['collection_category']} used)"
            elif r["processing_level"] != "L2SP":
                reason = f"processing level {r['processing_level']} (L2SP required for surface reflectance)"
            elif spec.get("end") and d > spec["end"]:
                reason = f"{pl} excluded after {spec['end']}: " + " ".join(str(spec.get("exclude_after_reason", "")).split())
            elif r["cloud_cover"] is not None and r["cloud_cover"] > sel["max_scene_cloud"]:
                reason = f"scene cloud {r['cloud_cover']:.0f}% > {sel['max_scene_cloud']}%"
        r.update(role=role, quality_flags=";".join(flags) or None, exclusion_reason=reason,
                 tile_id=f"P{r['wrs_path']}R{r['wrs_row']}" if r["wrs_path"] else None)
    gdf = _prelim(rows)
    gdf = _finalise(gdf, cutoff)
    small = gdf["district_overlap_fraction"] < sel["min_district_overlap"]
    gdf.loc[small & gdf["selected"], "exclusion_reason"] = "footprint covers <1% of district"
    gdf.loc[small, "selected"] = False
    gdf["processing_status"] = np.where(gdf["selected"], "selected", "excluded")
    return gdf

def _prelim(rows):
    for r in rows:
        r["selected"] = r.get("exclusion_reason") is None and r.get("role") == "primary"
    return rows

# ------------------------------------------------------------------ Sentinel-2
def discover_sentinel2(end: str | None = None) -> gpd.GeoDataFrame:
    cfg = config.load("sentinel2")
    sa = load_study_area(4326); cutoff = pd.Timestamp.now(tz="UTC")
    end = end or cutoff.strftime("%Y-%m-%dT%H:%M:%SZ")
    rows = _base_rows(search_all(cfg["collection"], None, "2015-06-01", end,
                                 intersects=_search_geom(sa)), cfg["collection"])
    sel = cfg["selection"]
    # de-duplicate: same tile & same datetime -> keep highest processing baseline
    df = pd.DataFrame(rows)
    df["_pb"] = pd.to_numeric(df["processing_baseline"], errors="coerce").fillna(0)
    df["_key"] = df["mgrs_tile"].astype(str) + "_" + df["datetime_utc"].astype(str)
    keep = df.sort_values("_pb").groupby("_key").tail(1).index
    for i, r in enumerate(rows):
        flags, reason = [], None
        pb = df.loc[i, "_pb"]
        if pb >= 4.0: flags.append("PB>=04.00_OFFSET_-1000")
        if i not in keep: reason = "duplicate tile/datetime; newer processing baseline kept"
        elif r["cloud_cover"] is not None and r["cloud_cover"] > sel["max_scene_cloud"]:
            reason = f"scene cloud {r['cloud_cover']:.0f}% > {sel['max_scene_cloud']}%"
        r.update(role="primary", processing_level="L2A", tile_id=r["mgrs_tile"], quality_flags=";".join(flags) or None,
                 exclusion_reason=reason, selected=reason is None)
    gdf = _finalise(rows, cutoff)
    small = gdf["district_overlap_fraction"] < sel["min_district_overlap"]
    gdf.loc[small & gdf["selected"], "exclusion_reason"] = "footprint covers <1% of district"
    gdf.loc[small, "selected"] = False
    gdf["processing_status"] = np.where(gdf["selected"], "selected", "excluded")
    return gdf

# ------------------------------------------------------------------ Sentinel-1
def discover_sentinel1(end: str | None = None) -> gpd.GeoDataFrame:
    cfg = config.load("sentinel1")
    sa = load_study_area(4326); cutoff = pd.Timestamp.now(tz="UTC")
    end = end or cutoff.strftime("%Y-%m-%dT%H:%M:%SZ")
    items = list(search_all(cfg["collection"], None, "2014-10-01", end,
                            intersects=_search_geom(sa)))
    rows = _base_rows(items, cfg["collection"])
    for it, r in zip(items, rows):
        p = it.properties
        r.update(instrument="C-SAR", processing_level="RTC",
                 tile_id=f"{(r['orbit_state'] or '?')[:3]}_R{r['relative_orbit']}",
                 quality_flags=None, role="primary",
                 _mode=p.get("sar:instrument_mode"), _pol=";".join(p.get("sar:polarizations", [])))
    df = pd.DataFrame(rows)
    # dominant orbit state per year (geometry consistency for time series)
    dom = df.groupby(["year", "orbit_state"]).size().reset_index(name="n").sort_values("n").groupby("year").tail(1)
    dom = dict(zip(dom["year"], dom["orbit_state"]))
    for r in rows:
        reason = None
        if r.pop("_mode") != cfg["selection"]["instrument_mode"]:
            reason = "not IW mode"
        elif "VH" not in (r.pop("_pol") or ""):
            reason = "single polarisation (VV+VH required)"
        elif r["orbit_state"] != dom.get(r["year"]):
            reason = f"orbit state {r['orbit_state']} (dominant {dom.get(r['year'])} kept for geometric consistency)"
        r.pop("_pol", None)
        r.update(exclusion_reason=reason, selected=reason is None)
    gdf = _finalise(rows, cutoff)
    small = gdf["district_overlap_fraction"] < cfg["selection"]["min_district_overlap"]
    gdf.loc[small & gdf["selected"], "exclusion_reason"] = "footprint covers <1% of district"
    gdf.loc[small, "selected"] = False
    gdf["processing_status"] = np.where(gdf["selected"], "selected", "excluded")
    return gdf

def write_manifest(gdf: gpd.GeoDataFrame, name: str) -> dict:
    out = config.path("data", "manifests", f"{name}_manifest.parquet")
    write_parquet(out, gdf)
    summ = {
        "manifest": out.name, "manifest_version": MANIFEST_VERSION, "schema_version": SCHEMA_VERSION,
        "archive_cutoff_utc": str(gdf["archive_cutoff_utc"].iloc[0]) if len(gdf) else None,
        "n_items": int(len(gdf)), "n_selected": int(gdf["selected"].sum()),
        "first": str(gdf["date"].min()), "last": str(gdf["date"].max()),
        "by_platform": gdf.groupby("platform")["selected"].agg(["size", "sum"]).rename(
            columns={"size": "discovered", "sum": "selected"}).astype(int).to_dict("index"),
        "exclusion_reasons": gdf.loc[~gdf["selected"], "exclusion_reason"].fillna("n/a").str.slice(0, 60)
                                .value_counts().head(12).to_dict(),
    }
    write_json(config.path("data", "manifests", f"{name}_manifest.summary.json"), summ)
    return summ
