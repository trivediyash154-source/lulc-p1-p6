"""Climate drivers. CHIRPS v2.0 monthly precipitation (0.05 deg, 1981-) - anonymous COG range reads.

District mean is AREA-WEIGHTED: each 0.05 deg cell is weighted by the exact fraction of its
area inside the study-area polygon (equal-area computation). Native-grid values are kept as a
multi-band COG so no information is lost to the district average.
"""
from __future__ import annotations
import re
from concurrent.futures import ThreadPoolExecutor
import numpy as np
import pandas as pd
import rasterio
import requests
from rasterio.windows import from_bounds
from shapely.geometry import box
import geopandas as gpd
from .. import config
from ..io import write_json, write_parquet
from ..provenance import utcnow
from .boundary import load_study_area

BASE = "https://data.chc.ucsb.edu/products/CHIRPS-2.0/global_monthly/cogs/"

def available_months() -> list[tuple[int, int]]:
    html = requests.get(BASE, timeout=60).text
    return sorted({(int(y), int(m)) for y, m in re.findall(r"chirps-v2\.0\.(\d{4})\.(\d{2})\.cog", html)})

def _weights(transform, shape):
    sa = load_study_area(4326); eq = config.load("study_area")["equal_area_crs"]
    h, w = shape
    cells = [box(*rasterio.transform.array_bounds(1, 1, transform * rasterio.Affine.translation(c, r)))
             for r in range(h) for c in range(w)]
    g = gpd.GeoDataFrame(geometry=cells, crs=4326).to_crs(eq)
    poly = sa.to_crs(eq).geometry.iloc[0]
    frac = (g.geometry.intersection(poly).area / g.geometry.area).values.reshape(h, w)
    return frac

def chirps_monthly(y0: int = 1989, y1: int = 2026, threads: int = 8) -> pd.DataFrame:
    months = [(y, m) for (y, m) in available_months() if y0 <= y <= y1]
    b = load_study_area(4326).total_bounds
    with rasterio.Env(**config.GDAL_ENV), rasterio.open(f"/vsicurl/{BASE}chirps-v2.0.{months[0][0]}.{months[0][1]:02d}.cog") as s:
        win = from_bounds(b[0] - 0.05, b[1] - 0.05, b[2] + 0.05, b[3] + 0.05, s.transform).round_offsets().round_lengths()
        tr = s.window_transform(win); shape = (int(win.height), int(win.width)); crs = s.crs
    wts = _weights(tr, shape)

    def read(ym):
        y, m = ym
        url = f"{BASE}chirps-v2.0.{y}.{m:02d}.cog"
        for k in range(4):
            try:
                with rasterio.Env(**config.GDAL_ENV), rasterio.open(f"/vsicurl/{url}") as s:
                    a = s.read(1, window=win).astype(np.float32)
                a[a < 0] = np.nan
                return ym, a, url
            except Exception:
                import time; time.sleep(3 * (k + 1))
        return ym, None, url

    with ThreadPoolExecutor(threads) as ex:
        res = list(ex.map(read, months))
    rows, stack = [], []
    for (y, m), a, url in res:
        if a is None:
            rows.append({"year": y, "month": m, "status": "failed", "source": url}); continue
        ok = np.isfinite(a) & (wts > 0)
        rows.append({"year": y, "month": m, "precip_mm_district_mean": float(np.sum(a[ok] * wts[ok]) / np.sum(wts[ok])),
                     "precip_mm_cell_min": float(np.nanmin(a[wts > 0])), "precip_mm_cell_max": float(np.nanmax(a[wts > 0])),
                     "n_cells_weighted": int(ok.sum()), "status": "ok", "source": url})
        stack.append(a)
    df = pd.DataFrame(rows)
    out = config.path("data", "processed", "climate"); out.mkdir(parents=True, exist_ok=True)
    write_parquet(out / "chirps_v2_monthly_pune.parquet", df); df.to_csv(out / "chirps_v2_monthly_pune.csv", index=False)
    prof = dict(driver="GTiff", width=shape[1], height=shape[0], count=len(stack), dtype="float32", crs=crs, transform=tr,
                nodata=np.nan, compress="deflate", tiled=False)
    with rasterio.open(out / "chirps_v2_monthly_stack.tif", "w", **prof) as d:
        d.write(np.stack(stack)); d.descriptions = tuple(f"{y}-{m:02d}" for (y, m), a, _ in res if a is not None)
    with rasterio.open(out / "chirps_v2_district_weights.tif", "w", **{**prof, "count": 1}) as d:
        d.write(wts.astype(np.float32)[None])
    write_json(out / "chirps_v2_monthly_pune.json", {"source": "CHIRPS v2.0 monthly (Funk et al. 2015, Scientific Data 2:150066)",
               "base_url": BASE, "months": len(stack), "first": f"{months[0][0]}-{months[0][1]:02d}", "last": f"{months[-1][0]}-{months[-1][1]:02d}",
               "district_mean": "area-weighted by exact cell fraction inside study area (equal-area)",
               "note": "recent months may be revised by CHC (preliminary -> final)", "created_utc": utcnow()})
    return df
