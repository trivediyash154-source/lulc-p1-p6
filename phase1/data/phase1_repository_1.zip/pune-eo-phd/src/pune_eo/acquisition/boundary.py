"""Authoritative, validated, versioned study-area boundary.

Primary: geoBoundaries gbOpen IND ADM2 (full resolution, pinned release commit).
Cross-checks: the simplified geoBoundaries release and GADM 4.1 -> boundary agreement is
reported as a quantified boundary uncertainty, not assumed away.
"""
from __future__ import annotations
import hashlib, io, json, logging, zipfile
from pathlib import Path
import geopandas as gpd
import numpy as np
import requests
from shapely import make_valid, wkb
from shapely.geometry import MultiPolygon, Polygon
from shapely.validation import explain_validity
from .. import config
from ..io import write_json
from ..provenance import utcnow, code_block

log = logging.getLogger(__name__)
RAW = config.path("data", "raw", "boundary")

def _download(url: str, dest: Path) -> Path:
    dest.parent.mkdir(parents=True, exist_ok=True)
    if dest.exists() and dest.stat().st_size > 0:
        return dest
    with requests.get(url, stream=True, timeout=300) as r:
        r.raise_for_status()
        tmp = dest.with_suffix(dest.suffix + ".part")
        with open(tmp, "wb") as f:
            for chunk in r.iter_content(1 << 20):
                f.write(chunk)
        tmp.replace(dest)
    return dest

def _extract(src: Path | gpd.GeoDataFrame, field: str, value: str) -> gpd.GeoDataFrame:
    g = gpd.read_file(src) if not isinstance(src, gpd.GeoDataFrame) else src
    m = g[g[field].astype(str).str.strip().str.lower() == value.lower()]
    if len(m) != 1:
        raise ValueError(f"expected exactly 1 feature with {field}=={value!r}, found {len(m)}")
    return m.to_crs(4326)

def _repair(geom):
    report = {"valid_before": bool(geom.is_valid), "validity_reason_before": explain_validity(geom)}
    if not geom.is_valid:
        geom = make_valid(geom)
        if geom.geom_type == "GeometryCollection":
            geom = MultiPolygon([g for g in geom.geoms if isinstance(g, Polygon)] +
                                [p for g in geom.geoms if isinstance(g, MultiPolygon) for p in g.geoms])
    report["valid_after"] = bool(geom.is_valid)
    report["geom_type"] = geom.geom_type
    parts = list(geom.geoms) if hasattr(geom, "geoms") else [geom]
    report["n_parts"] = len(parts)
    report["n_holes"] = int(sum(len(p.interiors) for p in parts))
    report["n_vertices"] = int(sum(len(p.exterior.coords) + sum(len(i.coords) for i in p.interiors) for p in parts))
    report["part_areas_km2_utm"] = sorted([round(gpd.GeoSeries([p], crs=4326).to_crs(32643).area.iloc[0] / 1e6, 4)
                                           for p in parts], reverse=True)
    return geom, report

def _fingerprint(geom) -> str:
    rounded = wkb.loads(wkb.dumps(geom, rounding_precision=7) if False else wkb.dumps(geom))
    coords = np.round(np.asarray(_all_coords(rounded)), 7)
    return hashlib.sha256(coords.tobytes()).hexdigest()

def _all_coords(geom):
    parts = list(geom.geoms) if hasattr(geom, "geoms") else [geom]
    out = []
    for p in parts:
        out.extend(p.exterior.coords)
        for i in p.interiors:
            out.extend(i.coords)
    return out

def _compare(a: gpd.GeoDataFrame, b: gpd.GeoDataFrame, eq_crs: str) -> dict:
    A, B = a.to_crs(eq_crs).geometry.iloc[0], b.to_crs(eq_crs).geometry.iloc[0]
    inter, union = A.intersection(B).area, A.union(B).area
    au = a.to_crs(32643).geometry.iloc[0]; bu = b.to_crs(32643).geometry.iloc[0]
    return {"area_a_km2": A.area / 1e6, "area_b_km2": B.area / 1e6,
            "area_diff_pct": 100 * (B.area - A.area) / A.area,
            "iou": inter / union, "symmetric_difference_km2": (union - inter) / 1e6,
            "hausdorff_m": au.hausdorff_distance(bu)}

def build_study_area() -> dict:
    cfg = config.load("study_area")
    out = config.path(cfg["outputs"]["dir"]); out.mkdir(parents=True, exist_ok=True)
    stem = cfg["outputs"]["stem"]
    p = cfg["primary_source"]

    full = _download(p["url"], RAW / "geoBoundaries-IND-ADM2.geojson")
    simp = _download(p["url_simplified"], RAW / "geoBoundaries-IND-ADM2_simplified.geojson")
    prim = _extract(full, p["match_field"], p["match_value"])
    geom, repair = _repair(prim.geometry.iloc[0])
    sa = gpd.GeoDataFrame({"id": [cfg["id"]], "name": [cfg["name"]], "source": [p["name"]],
                           "release": [p["release_commit"]]}, geometry=[geom], crs=4326)

    eq = cfg["equal_area_crs"]
    area_eq = sa.to_crs(eq).area.iloc[0] / 1e6
    area_utm = sa.to_crs(cfg["analysis_crs"]).area.iloc[0] / 1e6
    perim = sa.to_crs(eq).length.iloc[0] / 1e3

    checks = {"vs_simplified_release": _compare(sa, _extract(simp, p["match_field"], p["match_value"]), eq)}
    for c in cfg.get("cross_check_sources", []):
        try:
            z = _download(c["url"], RAW / Path(c["url"]).name)
            with zipfile.ZipFile(z) as zf:
                name = [n for n in zf.namelist() if n.endswith(".json")][0]
                g = gpd.read_file(io.BytesIO(zf.read(name)))
            checks[c["name"]] = _compare(sa, _extract(g, c["match_field"], c["match_value"]), eq)
        except Exception as e:
            checks[c["name"]] = {"error": repr(e)}

    version = _fingerprint(geom)[:12]
    # ---- write all formats from the SAME geometry ----
    sa.to_file(out / f"{stem}.geojson", driver="GeoJSON")
    utm = sa.to_crs(cfg["analysis_crs"])
    ext = gpd.GeoDataFrame({"id": [f"{cfg['id']}_processing_extent"]},
                           geometry=[utm.geometry.iloc[0].buffer(cfg["processing_buffer_m"]).envelope],
                           crs=cfg["analysis_crs"])
    gpkg = out / f"{stem}.gpkg"
    gpkg.unlink(missing_ok=True)
    sa.to_file(gpkg, layer="study_area_wgs84", driver="GPKG")
    utm.to_file(gpkg, layer="study_area_utm43n", driver="GPKG")
    ext.to_file(gpkg, layer="processing_extent_utm43n", driver="GPKG")
    sa.to_file(out / f"{stem}.shp")

    meta = {
        "id": cfg["id"], "name": cfg["name"], "version": version, "created_utc": utcnow(),
        "source": {**p, "downloaded_file": str(full.relative_to(config.ROOT))},
        "geometry_repair": repair,
        "area_km2_equal_area": round(area_eq, 2), "equal_area_crs": eq,
        "area_km2_utm43n": round(area_utm, 2),
        "utm_area_distortion_pct": round(100 * (area_utm - area_eq) / area_eq, 4),
        "perimeter_km": round(perim, 2),
        "official_area_km2": cfg["official_area_km2"],
        "diff_vs_official_pct": round(100 * (area_eq - cfg["official_area_km2"]) / cfg["official_area_km2"], 3),
        "bounds_wgs84": [round(v, 6) for v in sa.total_bounds],
        "bounds_utm43n": [round(v, 2) for v in utm.total_bounds],
        "processing_extent_utm43n": [round(v, 2) for v in ext.total_bounds],
        "processing_buffer_m": cfg["processing_buffer_m"],
        "cross_checks": checks,
        "files": [f"{stem}.geojson", f"{stem}.gpkg", f"{stem}.shp"],
        "rule": "This exact geometry is used for every year and every sensor. Changing it requires a new version.",
        "code": code_block(config.config_hash("study_area")),
    }
    write_json(out / f"{stem}.metadata.json", meta)
    return meta

def load_study_area(crs: str | int = 4326) -> gpd.GeoDataFrame:
    return gpd.read_file(config.path("data", "boundary", "study_area.geojson")).to_crs(crs)

def processing_extent():
    meta = json.loads(config.path("data", "boundary", "study_area.metadata.json").read_text())
    return tuple(meta["processing_extent_utm43n"])

def study_area_version() -> dict:
    meta = json.loads(config.path("data", "boundary", "study_area.metadata.json").read_text())
    return {"id": meta["id"], "version": meta["version"], "area_km2": meta["area_km2_equal_area"]}
