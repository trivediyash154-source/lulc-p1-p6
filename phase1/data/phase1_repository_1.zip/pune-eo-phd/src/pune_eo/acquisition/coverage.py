"""Footprint coverage of the study area per year/season (before pixel-level cloud masking)."""
from __future__ import annotations
import geopandas as gpd
import pandas as pd
from shapely.ops import unary_union
from .. import config
from .boundary import load_study_area

def landsat_footprint_coverage(y0: int = 1984, y1: int = 2026) -> pd.DataFrame:
    eq = config.load("study_area")["equal_area_crs"]
    sa = load_study_area(eq).geometry.iloc[0]; A = sa.area
    g = gpd.read_parquet(config.path("data", "manifests", "landsat_manifest.parquet")).to_crs(eq)
    g = g[g.selected]
    per = {k: v["months"] for k, v in config.load("temporal")["periods"].items()}
    rows = []
    for y in range(y0, y1 + 1):
        r = {"year": y, "n_annual": int((g.year == y).sum())}
        for name, months in per.items():
            s = g[(g.year == y) & g.month.isin(months)]
            key = "post" if name == "post_monsoon" else name
            r[key] = round(unary_union(list(s.geometry)).intersection(sa).area / A * 100, 1) if len(s) else 0.0
            if name == "dry": r["n_dry"] = len(s)
        r["sensors"] = ",".join(sorted(g[g.year == y].platform.str.replace("landsat-", "L").unique()))
        rows.append(r)
    df = pd.DataFrame(rows)
    df.to_csv(config.path("data", "manifests", "landsat_footprint_coverage.csv"), index=False)
    return df
