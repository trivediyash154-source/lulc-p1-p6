"""Traceability: code version, package versions, file checksums."""
from __future__ import annotations
import hashlib, platform, subprocess, sys
from datetime import datetime, timezone
from pathlib import Path
from . import __version__, SCHEMA_VERSION
from .config import ROOT

def utcnow() -> str:
    return datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ")

def git_commit() -> str:
    try:
        out = subprocess.run(["git", "-C", str(ROOT), "rev-parse", "--short", "HEAD"],
                             capture_output=True, text=True, timeout=5)
        dirty = subprocess.run(["git", "-C", str(ROOT), "status", "--porcelain"],
                               capture_output=True, text=True, timeout=5).stdout.strip()
        return (out.stdout.strip() or "no-git") + ("-dirty" if dirty else "")
    except Exception:
        return "no-git"

def sha256(path: Path, chunk: int = 1 << 20) -> str:
    h = hashlib.sha256()
    with open(path, "rb") as f:
        for b in iter(lambda: f.read(chunk), b""):
            h.update(b)
    return h.hexdigest()

def environment() -> dict:
    vers = {}
    for m in ["numpy", "rasterio", "geopandas", "pyproj", "shapely", "pystac_client", "planetary_computer", "pyarrow"]:
        try:
            vers[m] = __import__(m).__version__
        except Exception:
            pass
    try:
        import rasterio
        vers["gdal"] = rasterio.__gdal_version__
    except Exception:
        pass
    return {"python": sys.version.split()[0], "platform": platform.platform(), "packages": vers}

def code_block(config_hash: str) -> dict:
    return {"package_version": __version__, "schema_version": SCHEMA_VERSION,
            "git_commit": git_commit(), "config_hash": config_hash, **environment()}
