from pune_eo.cli import main
raise SystemExit(main())
