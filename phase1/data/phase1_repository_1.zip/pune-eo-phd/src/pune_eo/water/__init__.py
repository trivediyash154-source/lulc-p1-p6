"""Module: water — milestone scaffold (interfaces fixed, science not yet implemented).

Nothing in this package produces research results yet. Functions raise NotImplementedError with
the milestone that delivers them; see docs/methodology.md section 8 and docs/experiment_protocol.md.
"""

def river_width(*_, **__):
    """Reproducible river width along centrelines (M3: needs centreline vectors + water masks)."""
    raise NotImplementedError("M3 - water EXTENT only; level and depth need gauges/bathymetry")
