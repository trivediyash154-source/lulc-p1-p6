"""Spectral indices WITH a stated research purpose. An index without a purpose is not computed."""
from __future__ import annotations
import numpy as np

def _nd(a, b):
    with np.errstate(divide="ignore", invalid="ignore"):
        return (a - b) / (a + b)

REGISTRY = {
    "NDVI":  {"f": lambda d: _nd(d["nir08"] if "nir" not in d else d["nir"], d["red"]),
              "purpose": "vegetation vigour; phenology; greening/browning trends", "sensors": "all optical"},
    "EVI":   {"f": lambda d: 2.5 * (d.get("nir", d["nir08"]) - d["red"]) / (d.get("nir", d["nir08"]) + 6 * d["red"] - 7.5 * d["blue"] + 1),
              "purpose": "dense canopy (less saturation than NDVI): forest, sugarcane", "sensors": "all optical"},
    "SAVI":  {"f": lambda d: 1.5 * (d.get("nir", d["nir08"]) - d["red"]) / (d.get("nir", d["nir08"]) + d["red"] + 0.5),
              "purpose": "sparse vegetation on bright soils (Bhima plains, fallow)", "sensors": "all optical"},
    "MNDWI": {"f": lambda d: _nd(d["green"], d["swir16"]),
              "purpose": "open-water extent; built-up/water separation better than NDWI", "sensors": "all optical"},
    "NDWI":  {"f": lambda d: _nd(d["green"], d.get("nir", d["nir08"])),
              "purpose": "water in vegetated settings; turbid water comparison with MNDWI", "sensors": "all optical"},
    "NDMI":  {"f": lambda d: _nd(d.get("nir", d["nir08"]), d["swir16"]),
              "purpose": "canopy/soil moisture; irrigated vs rainfed contrast in dry season", "sensors": "all optical"},
    "NBR":   {"f": lambda d: _nd(d.get("nir", d["nir08"]), d["swir22"]),
              "purpose": "burn/disturbance detection (crop-residue burning, forest fire)", "sensors": "all optical"},
    "NDBI":  {"f": lambda d: _nd(d["swir16"], d.get("nir", d["nir08"])),
              "purpose": "built-up/bare signal (known confusion with bare soil - never used alone)", "sensors": "all optical"},
    "BSI":   {"f": lambda d: ((d["swir16"] + d["red"]) - (d.get("nir", d["nir08"]) + d["blue"])) / ((d["swir16"] + d["red"]) + (d.get("nir", d["nir08"]) + d["blue"])),
              "purpose": "bare soil vs built-up separation (fallow, quarries, construction sites)", "sensors": "all optical"},
    "NDRE":  {"f": lambda d: _nd(d["nir08"], d["re1"]),
              "purpose": "crop chlorophyll / growth stage (red-edge) - crop-type discrimination", "sensors": "Sentinel-2 only"},
    "CIre":  {"f": lambda d: d["re3"] / d["re1"] - 1,
              "purpose": "canopy chlorophyll content for phenology metrics", "sensors": "Sentinel-2 only"},
}

def compute(name: str, bands: dict[str, np.ndarray]) -> np.ndarray:
    return REGISTRY[name]["f"](bands).astype(np.float32)
