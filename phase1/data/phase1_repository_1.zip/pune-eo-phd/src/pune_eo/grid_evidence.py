"""Write all grid definitions and the empirical native-lattice evidence they rest on."""
from __future__ import annotations
import json
import geopandas as gpd
import planetary_computer as pc
import rasterio
from . import config
from .grid import district_grid
from .io import write_json
from .provenance import utcnow

def _probe(href):
    with rasterio.Env(**config.GDAL_ENV), rasterio.open(pc.sign(href)) as s:
        t = s.transform
        return {"epsg": s.crs.to_epsg(), "res": t.a, "ul_x": t.c, "ul_y": t.f, "ul_mod_30": [t.c % 30, t.f % 30],
                "ul_mod_10": [t.c % 10, t.f % 10], "overviews": s.overviews(1)}

def write_grids() -> dict:
    ev = {"landsat": {}, "sentinel2": {}, "sentinel1": {}}
    L = gpd.read_parquet(config.path("data", "manifests", "landsat_manifest.parquet"))
    L = L[L.selected & (L.year >= 2024)]
    for tid, r in L.groupby("tile_id").head(1).set_index("tile_id").iterrows():
        ev["landsat"][tid] = _probe(json.loads(r.asset_hrefs)["red"])
    S2 = gpd.read_parquet(config.path("data", "manifests", "sentinel2_manifest.parquet"))
    for tid, r in S2[S2.selected & (S2.year == 2024)].groupby("tile_id").head(1).set_index("tile_id").iterrows():
        ev["sentinel2"][tid] = _probe(json.loads(r.asset_hrefs)["B04"])
    S1 = gpd.read_parquet(config.path("data", "manifests", "sentinel1_manifest.parquet"))
    r = S1[S1.selected & (S1.year == 2024)].iloc[0]; ev["sentinel1"][r.tile_id] = _probe(json.loads(r.asset_hrefs)["vv"])
    grids = {n: district_grid(n).to_dict() for n in config.load("grid")["grids"]}
    land_off = {tuple(round(v) for v in e["ul_mod_30"]) for e in ev["landsat"].values()}
    s2_off = {tuple(round(v) for v in e["ul_mod_10"]) for e in ev["sentinel2"].values()}
    findings = {
        "landsat_all_path_rows_same_crs": len({e["epsg"] for e in ev["landsat"].values()}) == 1,
        "landsat_lattice_offset_mod30": sorted(land_off),
        "sentinel2_lattice_offset_mod10": sorted(s2_off),
        "G30_matches_landsat_native": land_off == {(15, 15)},
        "G10_matches_sentinel2_native": s2_off == {(0, 0)},
        "G10_nests_in_G30": False,
        "consequence": "Landsat is never resampled on G30; Sentinel enters G30 by area-weighted aggregation only.",
    }
    out = {"created_utc": utcnow(), "crs": config.load("grid")["crs"], "grids": grids, "native_lattice_evidence": ev, "findings": findings}
    write_json(config.path("data", "boundary", "grids.json"), out)
    return findings
