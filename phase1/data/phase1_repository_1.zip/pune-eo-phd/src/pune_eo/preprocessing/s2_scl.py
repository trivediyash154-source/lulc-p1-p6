"""Sentinel-2 L2A radiometry (processing-baseline offset) and SCL cloud masking."""
from __future__ import annotations
import numpy as np
from .. import config

def boa_offset(processing_baseline: str | None) -> float:
    """BOA_ADD_OFFSET: -0.1 reflectance (-1000 DN) for processing baseline >= 04.00 (from 2022-01-25)."""
    try:
        pb = float(processing_baseline)
    except (TypeError, ValueError):
        return 0.0
    return -0.1 if pb >= 4.0 else 0.0

def decode(dn: np.ndarray, processing_baseline: str | None) -> np.ndarray:
    cfg = config.load("sentinel2")["radiometry"]
    out = dn.astype(np.float32) * cfg["scale"] + boa_offset(processing_baseline)
    out[dn == cfg["nodata_dn"]] = np.nan
    return np.clip(out, 0.0, None, where=np.isfinite(out), out=out)

def clear_mask(scl: np.ndarray) -> np.ndarray:
    keep = config.load("sentinel2")["scl_clear_classes"]
    return np.isin(scl, keep)

def observed_mask(scl: np.ndarray) -> np.ndarray:
    return scl != 0
