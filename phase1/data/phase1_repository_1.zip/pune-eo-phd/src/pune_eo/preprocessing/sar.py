"""Sentinel-1 gamma0 handling. Averages are ALWAYS taken in linear power, then converted to dB."""
from __future__ import annotations
import numpy as np

def to_db(lin: np.ndarray) -> np.ndarray:
    with np.errstate(divide="ignore", invalid="ignore"):
        out = 10.0 * np.log10(lin)
    out[~np.isfinite(out)] = np.nan
    return out

def clean_linear(a: np.ndarray, nodata: float = -32768.0) -> np.ndarray:
    a = a.astype(np.float32)
    a[(a == nodata) | (a <= 0) | ~np.isfinite(a)] = np.nan
    return a
