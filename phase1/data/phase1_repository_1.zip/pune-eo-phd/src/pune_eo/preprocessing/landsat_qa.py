"""Landsat Collection-2 Level-2 decoding and QA_PIXEL masking (TM, ETM+, OLI, OLI-2)."""
from __future__ import annotations
import numpy as np
from .. import config

def mask_bits() -> int:
    bits = config.load("landsat")["qa_mask_bits"]
    m = 0
    for b in bits.values():
        m |= 1 << int(b)
    return m

def clear_mask(qa: np.ndarray) -> np.ndarray:
    """True where the observation is clear (not fill, cloud, dilated cloud, cirrus, shadow, snow)."""
    return (qa.astype(np.uint32) & mask_bits()) == 0

def observed_mask(qa: np.ndarray) -> np.ndarray:
    """True where the sensor recorded data (fill bit 0 not set). SLC-off gaps are fill -> not observed."""
    return (qa.astype(np.uint32) & 1) == 0

def decode_sr(dn: np.ndarray) -> tuple[np.ndarray, int]:
    """DN -> surface reflectance (float32, NaN invalid).

    Values below the valid range (negative reflectance from atmospheric over-correction over
    dark targets, mostly water) are CLIPPED to 0 rather than discarded, so water observations
    are not systematically removed. Values above the valid range (saturation) are invalid.
    Returns (reflectance, n_clipped).
    """
    cfg = config.load("landsat")
    lo, hi = cfg["valid_dn"]
    dn = dn.astype(np.float32)
    refl = dn * cfg["scale"] + cfg["offset"]
    refl[(dn == 0) | (dn > hi)] = np.nan
    neg = (dn > 0) & (dn < lo)
    refl[neg] = 0.0
    return refl, int(neg.sum())

def block_all(mask: np.ndarray, f: int) -> np.ndarray:
    """Conservative aggregation: a coarse cell is True only if ALL f x f fine samples are True."""
    h, w = mask.shape[0] // f, mask.shape[1] // f
    return mask[: h * f, : w * f].reshape(h, f, w, f).all(axis=(1, 3))
