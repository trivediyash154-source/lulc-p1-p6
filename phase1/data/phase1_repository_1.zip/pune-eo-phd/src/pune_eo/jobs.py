"""Resumable, concurrency-safe job ledger.

* If job 37 fails, jobs 1-36 stay DONE and are skipped on restart.
* A per-job lock file (O_EXCL) prevents two processes from running the same job.
* The ledger is re-read and merged under a ledger lock on every update, so concurrent
  processes never overwrite each other's records.
"""
from __future__ import annotations
import contextlib, errno, fcntl, json, os, socket, traceback
from pathlib import Path
from .io import write_json
from .provenance import utcnow

class JobLocked(RuntimeError):
    pass

class JobLedger:
    def __init__(self, path: Path):
        self.path = Path(path); self.path.parent.mkdir(parents=True, exist_ok=True)
        self.lockdir = self.path.parent / "locks"; self.lockdir.mkdir(exist_ok=True)

    @contextlib.contextmanager
    def _ledger_lock(self):
        with open(self.path.with_suffix(".lock"), "w") as fh:
            fcntl.flock(fh, fcntl.LOCK_EX)
            try:
                yield
            finally:
                fcntl.flock(fh, fcntl.LOCK_UN)

    @property
    def jobs(self) -> dict:
        return json.loads(self.path.read_text()) if self.path.exists() else {}

    def _update(self, job_id: str, **fields):
        with self._ledger_lock():
            j = self.jobs
            j[job_id] = {**j.get(job_id, {}), **fields}
            write_json(self.path, j)

    def is_done(self, job_id: str, version: str) -> bool:
        j = self.jobs.get(job_id)
        if not j or j.get("status") != "done" or j.get("version") != version:
            return False
        from .config import ROOT
        return all((ROOT / p).exists() for p in j.get("outputs", []))

    def _lockfile(self, job_id):
        return self.lockdir / (job_id.replace("/", "__") + ".lock")

    def acquire(self, job_id: str):
        lf = self._lockfile(job_id)
        try:
            fd = os.open(lf, os.O_CREAT | os.O_EXCL | os.O_WRONLY)
        except OSError as e:
            if e.errno != errno.EEXIST: raise
            info = lf.read_text() if lf.exists() else ""
            pid = int(info.split(":")[1]) if info.count(":") >= 1 and info.split(":")[1].isdigit() else None
            if pid and _alive(pid) and info.startswith(socket.gethostname()):
                raise JobLocked(f"{job_id} is being processed by pid {pid}")
            lf.unlink(missing_ok=True)          # stale lock from a dead process
            fd = os.open(lf, os.O_CREAT | os.O_EXCL | os.O_WRONLY)
        os.write(fd, f"{socket.gethostname()}:{os.getpid()}:{utcnow()}".encode()); os.close(fd)

    def release(self, job_id: str):
        self._lockfile(job_id).unlink(missing_ok=True)

    def start(self, job_id: str, version: str, **meta):
        self.acquire(job_id)
        prev = self.jobs.get(job_id, {})
        self._update(job_id, status="running", version=version, started=utcnow(), pid=os.getpid(),
                     attempts=prev.get("attempts", 0) + 1, **meta)

    def done(self, job_id: str, outputs: list, **meta):
        from .config import ROOT
        rel = [str(Path(o).resolve().relative_to(ROOT)) if str(Path(o).resolve()).startswith(str(ROOT)) else str(o) for o in outputs]
        self._update(job_id, status="done", finished=utcnow(), outputs=rel, error=None, **meta)
        self.release(job_id)

    def fail(self, job_id: str, exc: BaseException):
        self._update(job_id, status="failed", finished=utcnow(),
                     error="".join(traceback.format_exception_only(type(exc), exc)).strip())
        self.release(job_id)

    def summary(self) -> dict:
        out = {}
        for j in self.jobs.values():
            out[j["status"]] = out.get(j["status"], 0) + 1
        return out

def _alive(pid: int) -> bool:
    try:
        os.kill(pid, 0); return True
    except OSError:
        return False
