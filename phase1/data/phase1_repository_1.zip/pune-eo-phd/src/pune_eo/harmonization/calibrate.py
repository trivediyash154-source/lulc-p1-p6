"""Empirical cross-sensor calibration on Pune District sensor-overlap composites.

For each configured pair (src -> ref) we compare per-sensor, UNharmonised, same-window
dry-season median composites on the fixed grid. Pixels must be inside the district with
>=3 clear observations in BOTH sensors and a low composite standard error.
Fits: OLS and reduced-major-axis (RMA, symmetric in noise). Evaluation is leave-one-year-out:
coefficients fitted on the other years are scored on the held-out year, so the decision
between 'none', the literature transform and the local fit is never judged on training data.
"""
from __future__ import annotations
import json
import numpy as np
import pandas as pd
import rasterio
import yaml
from .. import config
from ..io import write_json
from ..provenance import utcnow
from .landsat import BANDS, transform_spec

MAX_SE = 0.01   # reflectance: exclude pixels whose composite is itself uncertain (phenology/cloud)

def _load(plat: str, grid_id: str, year: int, period: str = "dry"):
    d = config.path("data", "composites", grid_id, str(year), f"landsat_cal_{plat}", "seasonal", period)
    if not (d / "optical_composite.tif").exists():
        return None
    with rasterio.open(d / "optical_composite.tif") as s: c = s.read().astype(np.float32)
    with rasterio.open(d / "uncertainty.tif") as s: u = s.read().astype(np.float32)
    with rasterio.open(d / "observation_count.tif") as s: n = s.read(1)
    c[c == -32768] = np.nan; u[u == -32768] = np.nan
    return c / 1e4, u / 1e4, n

def _pairs(src, ref, grid_id, years):
    out = {}
    for y in years:
        a, b = _load(src, grid_id, y), _load(ref, grid_id, y)
        if a is None or b is None:
            continue
        ok = (a[2] >= 3) & (b[2] >= 3) & np.all(np.isfinite(a[0]) & np.isfinite(b[0]), 0) \
             & np.all((a[1] < MAX_SE) & (b[1] < MAX_SE), 0)
        if ok.sum() < 200:
            continue
        out[y] = (a[0][:, ok], b[0][:, ok])
    return out

def _fit(x, y):
    r = np.corrcoef(x, y)[0, 1]
    ols_s = r * y.std() / x.std(); ols_i = y.mean() - ols_s * x.mean()
    rma_s = np.sign(r) * y.std() / x.std(); rma_i = y.mean() - rma_s * x.mean()
    return {"n": int(x.size), "r": float(r), "ols": [float(ols_s), float(ols_i)], "rma": [float(rma_s), float(rma_i)]}

def _ndvi(a):  # a: (6, n)
    return (a[3] - a[2]) / (a[3] + a[2])

def calibrate(grid_id: str = "pune_G240", out_name: str | None = None) -> dict:
    """out_name None -> the ACTIVE transform file local_pune_v1 (district fit). Window fits get their own name."""
    out_name = out_name or "local_pune_v1"
    h = config.load("landsat")["harmonization"]
    lit = transform_spec("roy2016_ols")
    report = {"created_utc": utcnow(), "grid": grid_id, "max_composite_se": MAX_SE, "pairs": {}}
    coefs = {}
    for pair in h["calibration_pairs"]:
        src, ref = pair["src"], pair["ref"]
        data = _pairs(src, ref, grid_id, pair["years"])
        key = f"{src}->{ref}"
        if not data:
            report["pairs"][key] = {"status": "insufficient overlap data"}; continue
        X = np.concatenate([d[0] for d in data.values()], 1); Y = np.concatenate([d[1] for d in data.values()], 1)
        full = {b: _fit(X[i], Y[i]) for i, b in enumerate(BANDS)}
        # leave-one-year-out scoring of candidate transforms
        loyo = []
        for hold in data:
            tr = [y for y in data if y != hold]
            if not tr: continue
            Xt = np.concatenate([data[y][0] for y in tr], 1); Yt = np.concatenate([data[y][1] for y in tr], 1)
            xs, ys = data[hold]
            cand = {"none": xs}
            if src in lit["applies_to"] and ref in ("landsat-8",):
                cand["roy2016_ols"] = np.stack([xs[i] * lit["slope"][b] + lit["intercept"][b] for i, b in enumerate(BANDS)])
            for m in ("ols", "rma"):
                f = [_fit(Xt[i], Yt[i])[m] for i in range(len(BANDS))]
                cand[f"local_{m}"] = np.stack([xs[i] * f[i][0] + f[i][1] for i in range(len(BANDS))])
            for name, xx in cand.items():
                for i, b in enumerate(BANDS):
                    d = xx[i] - ys[i]
                    loyo.append({"held_out_year": hold, "transform": name, "band": b, "bias": float(d.mean()),
                                 "rmsd": float(np.sqrt((d ** 2).mean()))})
                dn = _ndvi(xx) - _ndvi(ys)
                loyo.append({"held_out_year": hold, "transform": name, "band": "NDVI", "bias": float(np.nanmean(dn)),
                             "rmsd": float(np.sqrt(np.nanmean(dn ** 2)))})
        L = pd.DataFrame(loyo)
        score = (L.groupby(["transform", "band"])[["bias", "rmsd"]].mean().reset_index() if len(L) else pd.DataFrame())
        raw_bias = {b: float((Y[i] - X[i]).mean()) for i, b in enumerate(BANDS)}
        report["pairs"][key] = {"years_used": sorted(data), "n_pixels": int(X.shape[1]),
                                "mean_difference_ref_minus_src": raw_bias,
                                "ndvi_mean_difference_ref_minus_src": float(np.nanmean(_ndvi(Y) - _ndvi(X))),
                                "fit_all_years": full,
                                "loyo_mean": score.to_dict("records")}
        coefs[key] = {b: full[b]["rma"] for b in BANDS}
        np.savez_compressed(config.path("results", "harmonization", f"pairs_{grid_id}_{src}_{ref}.npz"), X=X, Y=Y)
    # ---- decision rule (pre-registered here, recorded in the report) ----
    # Apply a local fit for a pair only if, on HELD-OUT years, it reduces mean band RMSD by >= 5 %
    # AND does not worsen |NDVI bias| by more than 0.002. Otherwise the pair is treated as identity.
    decisions = {}
    for key, v in report["pairs"].items():
        if "loyo_mean" not in v or not v["loyo_mean"]:
            decisions[key] = {"apply_local": False, "why": "no held-out evaluation possible"}; continue
        L = pd.DataFrame(v["loyo_mean"])
        rm = L[L.band != "NDVI"].groupby("transform")["rmsd"].mean()
        nd = L[L.band == "NDVI"].set_index("transform")["bias"].abs()
        gain = 1 - rm["local_rma"] / rm["none"]
        worse = nd["local_rma"] - nd["none"]
        ok = bool(gain >= 0.05 and worse <= 0.002)
        decisions[key] = {"apply_local": ok, "held_out_rmsd_reduction": round(float(gain), 4),
                          "held_out_ndvi_absbias_none": round(float(nd["none"]), 4),
                          "held_out_ndvi_absbias_local": round(float(nd["local_rma"]), 4),
                          "why": "meets rule" if ok else "fails rule (gain < 5 % or NDVI worsens) -> identity"}
    report["decision_rule"] = "apply local RMA fit iff held-out band-RMSD reduction >= 5% and |NDVI bias| not worse by > 0.002"
    report["decisions"] = decisions
    ident = {b: [1.0, 0.0] for b in BANDS}
    def use(key): return coefs[key] if decisions.get(key, {}).get("apply_local") else ident
    def chain(a, b):  # apply a then b
        return {k: [b[k][0] * a[k][0], b[k][0] * a[k][1] + b[k][1]] for k in BANDS}
    per = {}
    if "landsat-7->landsat-8" in coefs:
        per["landsat-7"] = use("landsat-7->landsat-8")
        if "landsat-5->landsat-7" in coefs:
            per["landsat-5"] = chain(use("landsat-5->landsat-7"), per["landsat-7"])
            per["landsat-4"] = per["landsat-5"]
    if "landsat-9->landsat-8" in coefs:
        per["landsat-9"] = use("landsat-9->landsat-8")
    local = {"description": "Pune District local RMA cross-calibration to OLI (Landsat-8) - fitted by pune-eo harmonize",
             "method": "reduced major axis on same-window dry-season median composites, chained L5->L7->L8",
             "decisions": decisions,
             "grid": grid_id, "created_utc": utcnow(),
             "per_platform": {p: {"slope": {b: v[b][0] for b in BANDS}, "intercept": {b: v[b][1] for b in BANDS}}
                              for p, v in per.items()}}
    out = config.path("results", "harmonization"); out.mkdir(parents=True, exist_ok=True)
    (out / f"{out_name}.yaml").write_text(yaml.safe_dump(local, sort_keys=False))
    write_json(out / ("harmonization_report.json" if out_name == "local_pune_v1" else f"harmonization_report_{grid_id}.json"), report)
    return report
