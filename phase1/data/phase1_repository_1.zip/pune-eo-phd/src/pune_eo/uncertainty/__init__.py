"""Module: uncertainty — milestone scaffold (interfaces fixed, science not yet implemented).

Nothing in this package produces research results yet. Functions raise NotImplementedError with
the milestone that delivers them; see docs/methodology.md section 8 and docs/experiment_protocol.md.
"""
"""Implemented now: composite uncertainty (SE of median) lives in pune_eo.compositing.stats.
Planned: ensembles, MC-dropout, conformal prediction, calibration, area of applicability (M3+)."""
