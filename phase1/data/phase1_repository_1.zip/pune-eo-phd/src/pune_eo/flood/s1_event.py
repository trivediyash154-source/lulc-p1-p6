"""Sentinel-1 flood-event products for a configured event.

Honesty rules built into the code:
* 'during' must be an acquisition inside the configured window around the cited peak date.
  If none exists, NO inundation map is produced - only the timing gap is reported.
* Candidate inundation = strong VV backscatter decrease (pre -> during) AND low during-VV
  (Otsu threshold, recorded) AND not JRC permanent water AND slope < 5 deg. It is labelled
  UNVALIDATED CANDIDATE: urban double-bounce hides water in built-up areas, and wet soil /
  smooth surfaces can mimic it.
"""
from __future__ import annotations
import json
import numpy as np
import pandas as pd
from .. import config
from ..io import write_cog, write_json
from ..provenance import utcnow, code_block
from ..compositing.engine import load_manifest
from ..compositing import observations as obs
from ..compositing.windows import aoi_window
from ..grid import district_grid, build
from ..preprocessing.sar import to_db
from ..acquisition.boundary import study_area_version

def _otsu(x: np.ndarray, bins: int = 256) -> float:
    x = x[np.isfinite(x)]
    h, e = np.histogram(x, bins=bins); c = (e[:-1] + e[1:]) / 2
    w0 = np.cumsum(h); w1 = w0[-1] - w0
    m0 = np.cumsum(h * c) / np.maximum(w0, 1); m1 = (np.sum(h * c) - np.cumsum(h * c)) / np.maximum(w1, 1)
    return float(c[np.argmax(w0 * w1 * (m0 - m1) ** 2)])

def _date_mean(rows, grid, win):
    """Mean linear backscatter over all frames of one acquisition date (frames tile the AOI)."""
    acc = np.zeros((2, int(win.height), int(win.width)), np.float64); n = np.zeros((int(win.height), int(win.width)))
    for _, r in rows.iterrows():
        o = obs.sentinel1(r, grid, win)
        if o is None: continue
        c0, r0, w, h = int(o["win"].col_off - win.col_off), int(o["win"].row_off - win.row_off), int(o["win"].width), int(o["win"].height)
        v = o["values"]; ok = np.isfinite(v[0])
        acc[:, r0:r0 + h, c0:c0 + w][:, ok] += v[:, ok]; n[r0:r0 + h, c0:c0 + w][ok] += 1
    with np.errstate(invalid="ignore", divide="ignore"):
        return (acc / n).astype(np.float32)

def run_event(event_id: str, grid_name: str = "G20") -> dict:
    ev = config.load("events")["events"][event_id]; srch = config.load("events")["search"]
    peak = pd.Timestamp(ev["peak_date"], tz="UTC")
    g = district_grid(grid_name)
    # AOI window from the event bbox
    from pyproj import Transformer
    t = Transformer.from_crs(4326, g.crs, always_xy=True)
    x0, y0, x1, y1 = ev["aoi_bbox_wgs84"]
    xs, ys = zip(*[t.transform(x, y) for x, y in [(x0, y0), (x0, y1), (x1, y0), (x1, y1)]])
    win = g.window((min(xs), min(ys), max(xs), max(ys))); sub = g.subgrid(win, f"_{event_id}")
    man = load_manifest("sentinel1")
    from shapely.geometry import box
    aoi = box(*ev["aoi_bbox_wgs84"])
    m = man[man.intersects(aoi)].copy()
    m["dt"] = pd.to_datetime(m["datetime_utc"]); m["delta_days"] = (m["dt"] - peak).dt.total_seconds() / 86400
    near = m[(m.delta_days > -srch["pre_window_days"]) & (m.delta_days < srch["post_window_days"])]
    dates = near.groupby("date").agg(delta=("delta_days", "min"), orbit=("relative_orbit", "first"),
                                     n_frames=("product_id", "size")).reset_index().sort_values("delta")
    lo, hi = srch["during_window_days"]
    during = dates[(dates.delta >= lo) & (dates.delta <= hi)]
    out = config.path("data", "composites", sub.id, str(peak.year), "sentinel1", "events", event_id)
    out.mkdir(parents=True, exist_ok=True)
    report = {"event_id": event_id, **{k: ev[k] for k in ("peak_date", "description", "source", "source_status")},
              "grid": sub.to_dict(), "study_area": study_area_version(), "created_utc": utcnow(),
              "acquisitions_within_window": dates.round(2).to_dict("records")}
    if during.empty:
        before = dates[dates.delta < lo]; after = dates[dates.delta > hi]
        report["status"] = "NO_DURING_ACQUISITION"
        report["timing_gap"] = {"nearest_before_days": float(before.delta.max()) if len(before) else None,
                                "nearest_after_days": float(after.delta.min()) if len(after) else None}
        report["claim"] = "No inundation map produced: Sentinel-1 did not image the AOI within the event window."
        pick = {"nearest_before": before.iloc[-1] if len(before) else None, "nearest_after": after.iloc[0] if len(after) else None}
    else:
        d = during.iloc[0]
        pre = dates[(dates.delta < lo) & ((dates.orbit == d.orbit) | (not srch["require_same_relative_orbit"]))]
        post = dates[(dates.delta > hi) & (dates.orbit == d.orbit)]
        pick = {"pre": pre.iloc[-1] if len(pre) else None, "during": d, "post": post.iloc[0] if len(post) else None}
        report["status"] = "DURING_ACQUISITION_FOUND" if len(pre) else "NO_PRE_REFERENCE"
    files = {}; arrays = {}
    for role, d in pick.items():
        if d is None: continue
        lin = _date_mean(near[near.date == d["date"]], g, win)
        db = to_db(lin); arrays[role] = db
        files[role] = str(write_cog(out / f"{role}_{d['date']}_db.tif", np.nan_to_num(db, nan=-9999), sub, nodata=-9999,
                                    dtype="float32", descriptions=["vv_db", "vh_db"]).relative_to(config.ROOT))
    if report["status"] == "DURING_ACQUISITION_FOUND":
        from ..acquisition.reference import permanent_water
        dvv = arrays["during"][0] - arrays["pre"][0]
        thr = _otsu(arrays["during"][0])
        files["change_vv_db"] = str(write_cog(out / "change_vv_during_minus_pre_db.tif", np.nan_to_num(dvv, nan=-9999)[None], sub,
                                              nodata=-9999, dtype="float32", descriptions=["dVV_db"]).relative_to(config.ROOT))
        perm = permanent_water(sub)   # JRC occurrence resampled onto this event sub-grid
        cand = (arrays["during"][0] < thr) & (dvv < -3.0) & ~perm
        files["candidate"] = str(write_cog(out / "candidate_inundation_UNVALIDATED.tif", cand.astype(np.uint8)[None], sub, nodata=None,
                                           dtype="uint8", descriptions=["candidate_inundation_unvalidated"], overview_resampling="nearest").relative_to(config.ROOT))
        report["method"] = {"otsu_threshold_vv_db": thr, "min_decrease_db": -3.0, "excluded": ["JRC permanent water"],
                            "label": "UNVALIDATED CANDIDATE inundation (hazard only)"}
        report["candidate_area_km2"] = float(cand.sum() * sub.res ** 2 / 1e6)
    report["files"] = files
    report["code"] = code_block(config.config_hash("sentinel1", "events", "grid"))
    write_json(out / "event_report.json", report)
    return report
