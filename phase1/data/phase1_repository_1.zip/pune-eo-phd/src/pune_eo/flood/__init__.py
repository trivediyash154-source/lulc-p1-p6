"""Flood module: Sentinel-1 event analysis (pre / during / post). Hazard only - exposure and
vulnerability are separate layers; no damage claims without independent validation data."""
