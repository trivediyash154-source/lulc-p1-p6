"""Module: agriculture — milestone scaffold (interfaces fixed, science not yet implemented).

Nothing in this package produces research results yet. Functions raise NotImplementedError with
the milestone that delivers them; see docs/methodology.md section 8 and docs/experiment_protocol.md.
"""

def phenology_features(*_, **__):
    """S1+S2 phenology metrics per pixel/parcel (M3: monthly S2/S1 products exist; parcel layer pending)."""
    raise NotImplementedError("M3")
