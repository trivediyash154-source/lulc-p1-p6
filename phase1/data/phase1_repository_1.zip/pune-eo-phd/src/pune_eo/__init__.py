"""Pune District multi-decadal Earth Observation research infrastructure."""
__version__ = "0.1.0"
SCHEMA_VERSION = "1.0.0"
