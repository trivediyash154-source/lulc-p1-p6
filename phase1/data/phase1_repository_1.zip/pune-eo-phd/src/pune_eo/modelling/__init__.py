"""Module: modelling — milestone scaffold (interfaces fixed, science not yet implemented).

Nothing in this package produces research results yet. Functions raise NotImplementedError with
the milestone that delivers them; see docs/methodology.md section 8 and docs/experiment_protocol.md.
"""

def hindcast(*_, **__):
    """Train <= T, predict T+5/T+10, compare with observed (M6 - gate for any scenario)."""
    raise NotImplementedError("M6")
