"""Spatially and temporally blocked cross-validation splits (prevents leakage from autocorrelation)."""
from __future__ import annotations
import numpy as np

def spatial_block_folds(x: np.ndarray, y: np.ndarray, block_m: float, k: int = 5, seed: int = 0) -> np.ndarray:
    """Assign each sample (projected coords in m) to one of k folds by square blocks of side block_m.
    All samples in a block share a fold, so no training sample sits in the same block as a test sample."""
    bx = np.floor(x / block_m).astype(np.int64); by = np.floor(y / block_m).astype(np.int64)
    blocks, inv = np.unique(np.stack([bx, by], 1), axis=0, return_inverse=True)
    rng = np.random.default_rng(seed)
    fold_of_block = rng.permutation(np.arange(len(blocks)) % k)
    return fold_of_block[inv.ravel()]

def temporal_holdout(years: np.ndarray, test_years) -> tuple[np.ndarray, np.ndarray]:
    test = np.isin(years, list(test_years))
    return ~test, test

def buffered_test_mask(x, y, test, buffer_m: float):
    """Drop training samples within buffer_m of any test sample (spatial buffer CV)."""
    from scipy.spatial import cKDTree
    t = cKDTree(np.c_[x[test], y[test]])
    d, _ = t.query(np.c_[x[~test], y[~test]], k=1)
    keep = np.ones(len(x), bool); idx = np.where(~test)[0]; keep[idx[d < buffer_m]] = False
    return keep & ~test
