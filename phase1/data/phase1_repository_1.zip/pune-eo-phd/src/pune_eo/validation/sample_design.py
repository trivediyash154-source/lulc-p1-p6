"""Stratified random reference-sample design (Olofsson et al. 2014 good practice).

Produces sample LOCATIONS only - labels are empty and must be filled by independent visual
interpretation (e.g. Google Earth Pro historical imagery, field visits). Strata (ESA WorldCover
2021) are used for ALLOCATION only; they are never copied into the label columns.

Allocation: proportional to stratum area, with a floor of `min_per_stratum` so rare classes
(water, built-up, bare) can be assessed - the standard compromise for area-estimation designs.
Each point is the centre of a random G30 (native Landsat) cell, so a label refers to exactly one
30 m analysis pixel. Epoch label columns are created for every requested year.
"""
from __future__ import annotations
import numpy as np
import pandas as pd
import geopandas as gpd
import rasterio
from shapely.geometry import Point
from .. import config
from ..grid import district_grid
from ..io import write_json
from ..provenance import utcnow
from ..compositing.engine import district_mask

WC_NAMES = {10: "tree_cover", 20: "shrubland", 30: "grassland", 40: "cropland", 50: "built_up",
            60: "bare_sparse", 80: "water", 90: "wetland"}
L1_CLASSES = ["built_up", "agriculture", "natural_vegetation", "water", "bare_sparse", "wetland_other"]

def design(n_total: int = 1200, min_per_stratum: int = 60, epochs=(1990, 2000, 2010, 2020, 2025), seed: int = 20261001,
           strata_grid: str = "G240") -> gpd.GeoDataFrame:
    g = district_grid(strata_grid)
    with rasterio.open(config.path("data", "features", "reference", g.id, "esa_worldcover_2021_mode.tif")) as s:
        wc = s.read(1)
    inside = district_mask(g) & np.isin(wc, list(WC_NAMES))
    codes, counts = np.unique(wc[inside], return_counts=True)
    W = counts / counts.sum()
    alloc = np.maximum(np.round(W * n_total).astype(int), min_per_stratum)
    alloc = np.minimum(alloc, counts * 16)            # cannot exceed available G30 cells (8x8 per G240 cell / 4 safety)
    rng = np.random.default_rng(seed)
    f = int(round(g.res / 30))
    rows = []
    for code, n in zip(codes, alloc):
        rr, cc = np.nonzero(inside & (wc == code))
        pick = rng.choice(len(rr), size=int(n), replace=len(rr) < n)
        sub_r = rng.integers(0, f, size=int(n)); sub_c = rng.integers(0, f, size=int(n))
        for k, (i, si, sj) in enumerate(zip(pick, sub_r, sub_c)):
            x = g.x0 + (cc[i] * f + sj + 0.5) * 30.0
            y = g.y1 - (rr[i] * f + si + 0.5) * 30.0
            rows.append({"stratum_code": int(code), "stratum": WC_NAMES[int(code)], "x_utm": x, "y_utm": y,
                         "stratum_weight": float(W[list(codes).index(code)])})
    gdf = gpd.GeoDataFrame(rows, geometry=[Point(r["x_utm"], r["y_utm"]) for r in rows], crs=g.crs)
    gdf = gdf.sample(frac=1, random_state=seed).reset_index(drop=True)     # shuffle so interpreters see no stratum order
    gdf.insert(0, "sample_id", [f"PUNE-{i:05d}" for i in range(len(gdf))])
    ll = gdf.to_crs(4326); gdf["lon"] = ll.geometry.x.round(6); gdf["lat"] = ll.geometry.y.round(6)
    for e in epochs:
        gdf[f"label_L1_{e}"] = None; gdf[f"confidence_{e}"] = None; gdf[f"imagery_date_{e}"] = None
    gdf["interpreter"] = None; gdf["notes"] = None
    out = config.path("data", "labels"); out.mkdir(parents=True, exist_ok=True)
    stem = f"reference_sample_design_v1_seed{seed}"
    gdf.to_parquet(out / f"{stem}.parquet", index=False)
    gdf.drop(columns="geometry").to_csv(out / f"{stem}.csv", index=False)
    kml = ll[["sample_id", "geometry"]].rename(columns={"sample_id": "Name"})
    try:
        kml.to_file(out / f"{stem}.kml", driver="KML")
    except Exception:
        kml.to_file(out / f"{stem}.geojson", driver="GeoJSON")
    summary = pd.DataFrame({"stratum": [WC_NAMES[int(c)] for c in codes], "area_share": W.round(4), "n": alloc})
    write_json(out / f"{stem}.json", {
        "design": "stratified random, proportional allocation with minimum per stratum", "n_total": int(alloc.sum()),
        "min_per_stratum": min_per_stratum, "seed": seed, "strata_source": "ESA WorldCover 2021 (mode on G240) - allocation only",
        "sampling_unit": "one G30 (30 m native Landsat) cell; point = cell centre", "epochs": list(epochs),
        "label_scheme_L1": L1_CLASSES, "allocation": summary.to_dict("records"),
        "estimator_note": "use stratified estimators with stratum_weight (Olofsson et al. 2014); points are NOT equal-probability",
        "created_utc": utcnow()})
    return gdf, summary
