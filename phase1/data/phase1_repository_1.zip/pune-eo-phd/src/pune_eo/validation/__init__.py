"""Model/product validation (distinct from data QA in pune_eo.qa)."""
