"""pune-eo command line. Run `python -m pune_eo --help`."""
from __future__ import annotations
import argparse, json, logging, sys

def _years(s: str):
    a, _, b = s.partition("-"); return range(int(a), int(b or a) + 1)

def main(argv=None) -> int:
    ap = argparse.ArgumentParser(prog="pune-eo", description="Pune District multi-decadal EO research infrastructure")
    sp = ap.add_subparsers(dest="cmd", required=True)
    sp.add_parser("auth-check", help="test credentials for every backend")
    sp.add_parser("boundary", help="download, validate, version and save the study area")
    sp.add_parser("grid", help="write grid definitions + native-lattice evidence")
    d = sp.add_parser("discover", help="build acquisition manifests"); d.add_argument("which", nargs="*", default=["landsat", "sentinel2", "sentinel1"])
    sp.add_parser("coverage", help="footprint coverage of the district per year/season")
    sp.add_parser("timeline", help="satellite availability table + figure")
    c = sp.add_parser("composite", help="run (resumable) compositing jobs")
    c.add_argument("--family", choices=["landsat", "sentinel2", "sentinel1"], required=True)
    c.add_argument("--grid", default="G240"); c.add_argument("--window", default="district")
    c.add_argument("--years", default="1990-2026"); c.add_argument("--threads", type=int, default=12)
    c.add_argument("--keep-cache", action="store_true")
    h = sp.add_parser("harmonize", help="sensor-overlap composites + held-out calibration fit"); h.add_argument("--grid", default="G240")
    h.add_argument("--fit-only", action="store_true")
    r = sp.add_parser("reference", help="JRC permanent-water reference on a grid"); r.add_argument("--grid", default="G240"); r.add_argument("--window", default="district")
    q = sp.add_parser("qa", help="automated QA + report"); q.add_argument("--grid-id", default="pune_G240"); q.add_argument("--family", default="landsat")
    e = sp.add_parser("event", help="Sentinel-1 flood event products"); e.add_argument("event_id"); e.add_argument("--grid", default="G20")
    s = sp.add_parser("status", help="job ledger summary and pending years"); s.add_argument("--years", default="1990-2026")
    f = sp.add_parser("figures", help="publication figures from finished products"); f.add_argument("--grid-id", default="pune_G240")
    sp.add_parser("climate", help="CHIRPS v2.0 monthly rainfall 1990-present (area-weighted district mean)")
    sd = sp.add_parser("sample-design", help="stratified reference-sample locations (labels empty)")
    sd.add_argument("--n", type=int, default=1200); sd.add_argument("--min-per-stratum", type=int, default=60)
    g = sp.add_parser("gee-export", help="plan/submit Google Earth Engine exports (needs credentials)")
    g.add_argument("--years", default="1990-2026"); g.add_argument("--grid", default="G30"); g.add_argument("--submit", action="store_true")
    a = ap.parse_args(argv)
    logging.basicConfig(level=logging.INFO, format="%(asctime)s %(levelname)s %(message)s")
    for n in ("rasterio", "urllib3", "azure"): logging.getLogger(n).setLevel(logging.WARNING)

    if a.cmd == "auth-check":
        from .acquisition.auth import check
        res = check(); print(json.dumps(res, indent=1)); return 0 if res["planetary_computer"].startswith("OK") else 1
    if a.cmd == "boundary":
        from .acquisition.boundary import build_study_area
        m = build_study_area(); print(json.dumps({k: m[k] for k in ("version", "area_km2_equal_area", "diff_vs_official_pct")}, indent=1)); return 0
    if a.cmd == "grid":
        from .grid_evidence import write_grids
        print(json.dumps(write_grids(), indent=1)); return 0
    if a.cmd == "discover":
        from .acquisition import manifest as M
        for w in a.which:
            gdf = {"landsat": M.discover_landsat, "sentinel2": M.discover_sentinel2, "sentinel1": M.discover_sentinel1}[w]()
            print(json.dumps(M.write_manifest(gdf, w), indent=1))
        return 0
    if a.cmd == "coverage":
        from .acquisition.coverage import landsat_footprint_coverage
        print(landsat_footprint_coverage().to_string(index=False)); return 0
    if a.cmd == "timeline":
        from .visualization import timeline
        df = timeline.build(); print(timeline.figure(df)); return 0
    if a.cmd == "composite":
        from .compositing.engine import run_year
        from .compositing.windows import resolve
        grid, win, wname = resolve(a.grid, a.window); rc = 0
        for y in _years(a.years):
            try:
                r = run_year(a.family, y, grid, window=win, window_name=wname, threads=a.threads, keep_cache=a.keep_cache)
                print(json.dumps({k: r.get(k) for k in ("job_id", "status", "seconds", "n_items", "n_failed")}), flush=True)
            except Exception as ex:
                rc = 1; print(json.dumps({"year": y, "status": "failed", "error": repr(ex)}), flush=True)
        return rc
    if a.cmd == "harmonize":
        if not a.fit_only:
            import runpy; sys.argv = ["run_calibration", a.grid]
            from . import config; runpy.run_path(str(config.path("scripts", "run_calibration.py")), run_name="__main__")
        from .harmonization.calibrate import calibrate
        print(json.dumps(calibrate(f"pune_{a.grid}")["decisions"], indent=1)); return 0
    if a.cmd == "reference":
        from .acquisition.reference import jrc_occurrence
        from .compositing.windows import resolve
        grid, win, wname = resolve(a.grid, a.window)
        print(jrc_occurrence(grid if win is None else grid.subgrid(win, f"_{wname}"))); return 0
    if a.cmd == "qa":
        from .qa.report import qa_report
        print(qa_report(a.grid_id, a.family)); return 0
    if a.cmd == "event":
        from .flood.s1_event import run_event
        r = run_event(a.event_id, a.grid); print(json.dumps({k: r.get(k) for k in ("event_id", "status", "timing_gap", "candidate_area_km2", "files")}, indent=1, default=str)); return 0
    if a.cmd == "status":
        from .status import status
        print(status(_years(a.years))); return 0
    if a.cmd == "figures":
        from .visualization.figures import all_figures
        for p in all_figures(a.grid_id): print(p)
        return 0
    if a.cmd == "climate":
        from .acquisition.climate import chirps_monthly
        df = chirps_monthly(); print(f"{(df.status == 'ok').sum()} months written to data/processed/climate/"); return 0
    if a.cmd == "sample-design":
        from .validation.sample_design import design
        g_, s_ = design(a.n, a.min_per_stratum); print(s_.to_string(index=False)); print("points:", len(g_)); return 0
    if a.cmd == "gee-export":
        from .acquisition.gee_backend import plan_exports
        print(json.dumps(plan_exports(_years(a.years), a.grid, submit=a.submit), indent=1, default=str)); return 0
    return 1

if __name__ == "__main__":
    raise SystemExit(main())
