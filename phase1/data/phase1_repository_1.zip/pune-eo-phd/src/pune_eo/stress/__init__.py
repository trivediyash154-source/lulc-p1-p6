"""Module: stress — milestone scaffold (interfaces fixed, science not yet implemented).

Nothing in this package produces research results yet. Functions raise NotImplementedError with
the milestone that delivers them; see docs/methodology.md section 8 and docs/experiment_protocol.md.
"""

COMPONENTS = ("water_availability", "water_demand", "ecosystem_response", "agricultural_response")

def stress_components(*_, **__):
    """Each component measured and validated separately; no composite index before that (M5)."""
    raise NotImplementedError("M5")
