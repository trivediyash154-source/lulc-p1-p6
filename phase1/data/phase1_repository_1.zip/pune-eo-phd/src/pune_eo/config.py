"""Configuration and path resolution. Every path is resolved relative to the repository root."""
from __future__ import annotations
import os, hashlib, json
from functools import lru_cache
from pathlib import Path
import yaml

def repo_root() -> Path:
    env = os.environ.get("PUNE_EO_ROOT")
    if env:
        return Path(env).resolve()
    p = Path(__file__).resolve()
    for parent in p.parents:
        if (parent / "configs").is_dir() and (parent / "pyproject.toml").exists():
            return parent
    return Path.cwd()

ROOT = repo_root()

def path(*parts: str) -> Path:
    return ROOT.joinpath(*parts)

@lru_cache(maxsize=None)
def load(name: str) -> dict:
    """Load configs/<name>.yaml."""
    with open(path("configs", f"{name}.yaml")) as f:
        return yaml.safe_load(f)

def config_hash(*names: str) -> str:
    blob = json.dumps({n: load(n) for n in names}, sort_keys=True, default=str).encode()
    return hashlib.sha256(blob).hexdigest()[:16]

def load_env() -> None:
    try:
        from dotenv import load_dotenv
        load_dotenv(path(".env"))
    except ImportError:
        pass

GDAL_ENV = dict(
    GDAL_DISABLE_READDIR_ON_OPEN="EMPTY_DIR",
    CPL_VSIL_CURL_ALLOWED_EXTENSIONS=".tif,.TIF,.tiff,.cog",
    GDAL_HTTP_MERGE_CONSECUTIVE_RANGES="YES",
    GDAL_HTTP_MULTIPLEX="YES",
    GDAL_HTTP_MAX_RETRY="6",
    GDAL_HTTP_RETRY_DELAY="3",
    VSI_CACHE="TRUE",
    VSI_CACHE_SIZE=str(256 * 1024 * 1024),
    GDAL_CACHEMAX=512,
)
