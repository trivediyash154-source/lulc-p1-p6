"""Real satellite-availability timeline for Pune District, built only from the manifests."""
from __future__ import annotations
import geopandas as gpd
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
from matplotlib.patches import Patch
from .. import config
from . import style

def build() -> pd.DataFrame:
    L = gpd.read_parquet(config.path("data", "manifests", "landsat_manifest.parquet"))
    S2 = gpd.read_parquet(config.path("data", "manifests", "sentinel2_manifest.parquet"))
    S1 = gpd.read_parquet(config.path("data", "manifests", "sentinel1_manifest.parquet"))
    rows = []
    for y in range(1972, 2027):
        r = {"year": y}
        for nm, df in [("landsat", L[L.role == "primary"]), ("mss_context", L[L.role == "context_only"]),
                       ("sentinel2", S2), ("sentinel1", S1)]:
            d = df[df.year == y]
            r[f"{nm}_discovered"] = len(d); r[f"{nm}_selected"] = int(d.selected.sum())
        for p in ["landsat-5", "landsat-7", "landsat-8", "landsat-9"]:
            r[f"{p}_selected"] = int(L[(L.year == y) & (L.platform == p) & L.selected].shape[0])
        r["s2_dates_selected"] = S2[(S2.year == y) & S2.selected].date.nunique()
        r["s1_dates_selected"] = S1[(S1.year == y) & S1.selected].date.nunique()
        rows.append(r)
    df = pd.DataFrame(rows)
    cov = config.path("data", "manifests", "landsat_footprint_coverage.csv")
    if cov.exists():
        c = pd.read_csv(cov).rename(columns={"dry": "landsat_dry_footprint_pct", "wet": "landsat_wet_footprint_pct",
                                              "post": "landsat_post_footprint_pct", "annual": "landsat_annual_footprint_pct"})
        df = df.merge(c[["year", "landsat_annual_footprint_pct", "landsat_dry_footprint_pct", "landsat_wet_footprint_pct",
                         "landsat_post_footprint_pct"]], on="year", how="left")
    out = config.path("results", "timeline"); out.mkdir(parents=True, exist_ok=True)
    df.to_csv(out / "satellite_availability_by_year.csv", index=False)
    return df

MISSIONS = [  # label, start, end, family, note  (dates: operational periods; archive coverage over Pune is in the bars below)
    ("Landsat 1-3 MSS (context only)", 1972.6, 1983.0, "ctx", ""),
    ("Landsat 5 TM", 1984.2, 2011.9, "L", ""),
    ("Landsat 7 ETM+ (SLC-on)", 1999.4, 2003.42, "L", ""),
    ("Landsat 7 ETM+ (SLC-off, used to 2021)", 2003.42, 2022.0, "Loff", ""),
    ("Landsat 8 OLI", 2013.3, 2026.8, "L", ""),
    ("Landsat 9 OLI-2", 2021.83, 2026.8, "L", ""),
    ("Sentinel-1A C-SAR", 2014.8, 2026.8, "S1", ""),
    ("Sentinel-1B C-SAR", 2016.3, 2021.98, "S1", ""),
    ("Sentinel-1D C-SAR", 2025.85, 2026.8, "S1", ""),
    ("Sentinel-2A MSI", 2015.5, 2026.8, "S2", ""),
    ("Sentinel-2B MSI", 2017.2, 2026.8, "S2", ""),
    ("Sentinel-2C MSI", 2025.0, 2026.8, "S2", ""),
]

def figure(df: pd.DataFrame) -> str:
    style.apply()
    col = {"L": style.CAT[0], "Loff": style.SEQ[2], "S1": style.CAT[1], "S2": style.CAT[2], "ctx": "#c9c8c3"}
    fig, (a1, a2, a3) = plt.subplots(3, 1, figsize=(13, 11), gridspec_kw={"height_ratios": [1.25, 1, 1]})
    for i, (lab, s, e, fam, _) in enumerate(MISSIONS):
        a1.barh(i, e - s, left=s, height=0.62, color=col[fam], edgecolor=style.SURF, linewidth=1.5)
        a1.text(s - 0.3, i, lab, ha="right", va="center", fontsize=9, color=style.INK)
    a1.axvspan(1990, 2026.75, color="#eef4fc", zorder=0); a1.text(1990.3, len(MISSIONS) - 0.3, "quantitative window 1990-2026", fontsize=9, color=style.INK2, va="top")
    a1.set_yticks([]); a1.set_xlim(1958, 2027.5); a1.invert_yaxis(); a1.grid(axis="y", visible=False)
    a1.set_title("Mission history (operational periods) - what can exist in the archive")
    d = df[df.year >= 1984]
    bottom = np.zeros(len(d))
    for i, p in enumerate(["landsat-5", "landsat-7", "landsat-8", "landsat-9"]):
        a2.bar(d.year, d[f"{p}_selected"], bottom=bottom, color=style.CAT[i], width=0.8, edgecolor=style.SURF,
               linewidth=1, label=p.replace("landsat-", "Landsat "))
        bottom += d[f"{p}_selected"].values
    a2.set_ylabel("selected scenes"); a2.legend(ncol=4, loc="upper left", fontsize=9)
    a2.set_title("Landsat scenes over Pune District that pass selection (T1, L2SP, <=70% cloud, >=1% overlap)")
    a2.set_xlim(1983.3, 2026.8)
    a3.bar(d.year - 0.2, d["s2_dates_selected"], width=0.4, color=style.CAT[2], label="Sentinel-2 acquisition dates")
    a3.bar(d.year + 0.2, d["s1_dates_selected"], width=0.4, color=style.CAT[1], label="Sentinel-1 acquisition dates (RTC, dominant orbit)")
    a3.set_xlim(1983.3, 2026.8); a3.set_ylabel("distinct dates"); a3.legend(loc="upper left", fontsize=9)
    a3.set_title("Sentinel era: dense time series become possible (2026 partial year)")
    for a in (a2, a3):
        a.axvline(2026, color=style.MUTED, lw=0.8, ls=":")
    fig.text(0.01, 0.005, "Source: Planetary Computer STAC manifests (data/manifests/*_manifest.parquet), archive cut-off "
             + str(gpd.read_parquet(config.path("data", "manifests", "landsat_manifest.parquet")).archive_cutoff_utc.iloc[0])[:10],
             fontsize=8, color=style.INK2)
    fig.suptitle("Pune District - real Earth-observation archive, 1972-2026", fontsize=15, fontweight="bold", x=0.01, ha="left")
    fig.tight_layout(rect=[0, 0.015, 1, 0.97])
    p = config.path("results", "figures", "satellite_availability_timeline.png"); p.parent.mkdir(parents=True, exist_ok=True)
    fig.savefig(p, dpi=130); plt.close(fig)
    return str(p)
