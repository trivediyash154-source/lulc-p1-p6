"""Shared figure style (validated reference palette; recessive axes; text in ink, not series colour)."""
import matplotlib as mpl
INK, INK2, MUTED, GRID, SURF = "#0b0b0b", "#52514e", "#8a8984", "#e6e5e1", "#fcfcfb"
CAT = ["#2a78d6", "#eb6834", "#1baf7a", "#eda100", "#e87ba4", "#008300", "#4a3aa7", "#e34948"]
SEQ = ["#cde2fb", "#9ec5f4", "#6da7ec", "#3987e5", "#256abf", "#184f95", "#0d366b"]
STATUS = {"PASS": "#0ca30c", "WARNING": "#fab219", "FAIL": "#d03b3b", "IN_PROGRESS": "#d9d8d4", "N/A": "#d9d8d4"}
def apply():
    mpl.rcParams.update({"figure.facecolor": SURF, "axes.facecolor": SURF, "savefig.facecolor": SURF,
        "axes.edgecolor": MUTED, "axes.labelcolor": INK2, "xtick.color": INK2, "ytick.color": INK2,
        "text.color": INK, "axes.spines.top": False, "axes.spines.right": False, "axes.grid": True,
        "grid.color": GRID, "grid.linewidth": 0.6, "font.size": 10, "axes.titleweight": "bold",
        "axes.titlesize": 12, "legend.frameon": False})
