"""Map furniture: boundary, scale bar, north arrow, graticule labels, source/method footer."""
from __future__ import annotations
import numpy as np
from matplotlib.patches import Rectangle, FancyArrow
from pyproj import Transformer
from . import style

def extent(grid) -> list:
    x0, y0, x1, y1 = grid.bounds
    return [x0, x1, y0, y1]

def boundary(ax, crs="EPSG:32643", lw=0.8, color=None):
    from ..acquisition.boundary import load_study_area
    load_study_area(crs).boundary.plot(ax=ax, color=color or style.INK, linewidth=lw)

def scalebar(ax, km: float = 50, loc=(0.05, 0.05), compact=False):
    x0, x1 = ax.get_xlim(); y0, y1 = ax.get_ylim()
    bx = x0 + loc[0] * (x1 - x0); by = y0 + loc[1] * (y1 - y0); L = km * 1000; h = (y1 - y0) * 0.012
    for i in range(2):
        ax.add_patch(Rectangle((bx + i * L / 2, by), L / 2, h, facecolor=style.INK if i == 0 else "white",
                               edgecolor=style.INK, lw=0.6, zorder=5))
    ax.text(bx, by + 2.2 * h, "0", ha="center", fontsize=7 if compact else 8)
    ax.text(bx + L, by + 2.2 * h, f"{km:g} km", ha="center", fontsize=7 if compact else 8)

def north_arrow(ax, loc=(0.93, 0.86), size=0.07):
    x0, x1 = ax.get_xlim(); y0, y1 = ax.get_ylim()
    x = x0 + loc[0] * (x1 - x0); y = y0 + loc[1] * (y1 - y0); L = size * (y1 - y0)
    ax.add_patch(FancyArrow(x, y, 0, L, width=L * 0.18, head_width=L * 0.45, head_length=L * 0.45,
                            length_includes_head=True, color=style.INK, zorder=6))
    ax.text(x, y - L * 0.35, "N", ha="center", va="top", fontsize=10, fontweight="bold")

def graticule(ax, crs="EPSG:32643", step=0.5):
    """Lon/lat tick labels on the frame edges of a UTM map (grid north ~ true north here)."""
    to_utm = Transformer.from_crs(4326, crs, always_xy=True); to_ll = Transformer.from_crs(crs, 4326, always_xy=True)
    x0, x1 = ax.get_xlim(); y0, y1 = ax.get_ylim()
    lon0, lat0 = to_ll.transform(x0, y0); lon1, lat1 = to_ll.transform(x1, y1)
    lons = np.arange(np.ceil(lon0 / step) * step, lon1, step); lats = np.arange(np.ceil(lat0 / step) * step, lat1, step)
    dec = 1 if step >= 0.1 else 2
    ax.set_xticks([to_utm.transform(l, lat0)[0] for l in lons]); ax.set_xticklabels([f"{l:.{dec}f}°E" for l in lons], fontsize=7)
    ax.set_yticks([to_utm.transform(lon0, l)[1] for l in lats]); ax.set_yticklabels([f"{l:.{dec}f}°N" for l in lats], fontsize=7)
    ax.tick_params(length=2); ax.grid(False); ax.set_xlabel(""); ax.set_ylabel("")
    for s in ax.spines.values(): s.set_visible(True); s.set_color(style.MUTED); s.set_linewidth(0.6)

def footer(fig, text: str, y=0.006):
    fig.text(0.01, y, text, fontsize=7.5, color=style.INK2, ha="left", va="bottom", wrap=True)
