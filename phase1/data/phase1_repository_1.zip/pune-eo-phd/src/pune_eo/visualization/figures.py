"""Publication-quality figures computed from finished products (never from appearance alone)."""
from __future__ import annotations
import json
from pathlib import Path
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
import rasterio
from matplotlib.colors import ListedColormap, BoundaryNorm, TwoSlopeNorm
from matplotlib.patches import Patch
from .. import config
from . import style, cartography as carto

FIG = config.path("results", "figures")
SRC = "Data: USGS Landsat C2 L2 / ESA Sentinel-1 RTC & Sentinel-2 L2A via Microsoft Planetary Computer; boundary geoBoundaries IND ADM2 (9469f09); UTM 43N (EPSG:32643)."

def _read(path, bands=None):
    with rasterio.open(path) as s:
        a = s.read().astype(np.float32); desc = list(s.descriptions); nod = s.nodata
    if nod is not None: a[a == nod] = np.nan
    return a, desc

def _comp(grid_id, year, fam, rel):
    d = config.path("data", "composites", grid_id, str(year), fam, rel)
    if not (d / "metadata.json").exists(): return None
    a, desc = _read(d / "optical_composite.tif"); n, _ = _read(d / "observation_count.tif")
    meta = json.loads((d / "metadata.json").read_text())
    return {b: a[i] / 1e4 for i, b in enumerate(desc)}, n[0], meta

def _grid_extent(meta):
    g = meta["grid"]; x0, y0, x1, y1 = g["bounds"]; return [x0, x1, y0, y1]

NODATA_RGB = (0.80, 0.80, 0.80)     # inside district, no clear observation
def _fcc(c, n, lim=((0.05, 0.42), (0.06, 0.42), (0.02, 0.26)), meta=None):
    """Fixed-stretch SWIR1/NIR/Red false colour - identical limits for every year (comparable).
    Outside the study area -> transparent; inside with no clear observation -> mid grey."""
    rgb = np.dstack([np.clip((c[b] - lo) / (hi - lo), 0, 1) for b, (lo, hi) in zip(["swir16", "nir08" if "nir08" in c else "nir", "red"], lim)])
    rgba = np.dstack([rgb, np.ones(rgb.shape[:2])])
    rgba[(n < 1) | ~np.isfinite(rgb).all(-1)] = (*NODATA_RGB, 1.0)
    if meta is not None:
        from ..compositing.engine import district_mask
        from ..qa.checks import _grid_from_meta
        rgba[~district_mask(_grid_from_meta(meta["grid"]))] = (1, 1, 1, 0)
    return rgba

# ------------------------------------------------------------------ F1 contact sheet (every year)
def contact_sheet(grid_id="pune_G240", period="seasonal/dry", fam="landsat"):
    style.apply()
    qa = _qa(grid_id)
    years = [y for y in range(1990, 2027) if _comp(grid_id, y, fam, period)]
    cols = 7; rows = int(np.ceil(len(years) / cols))
    fig, axs = plt.subplots(rows, cols, figsize=(cols * 2.3, rows * 2.2 + 0.9), gridspec_kw={"wspace": 0.04, "hspace": 0.06})
    for ax in axs.ravel(): ax.axis("off")
    for ax, y in zip(axs.ravel(), years):
        c, n, meta = _comp(grid_id, y, fam, period)
        ax.imshow(_fcc(c, n, meta=meta), extent=_grid_extent(meta), interpolation="nearest")
        carto.boundary(ax, lw=0.4)
        st = meta.get("qa", {}).get("status", "N/A")
        rel = meta["statistics"]["district_reliable_fraction_ge3"] * 100
        sens = "+".join(sorted(s.replace("landsat-", "L") for s in meta["sensors"]))
        ax.text(0.02, 0.98, f"{y}", transform=ax.transAxes, fontsize=10, fontweight="bold", va="top", color=style.INK)
        ax.text(0.98, 0.98, sens, transform=ax.transAxes, fontsize=7.5, va="top", ha="right", color=style.INK2)
        ax.text(0.02, 0.02, f"{st} · ≥3 obs {rel:.0f}%", transform=ax.transAxes, fontsize=6.5,
                color=style.INK, bbox=dict(boxstyle="round,pad=0.2", fc="white", ec=style.STATUS.get(st, "#ccc"), lw=1.2))
    fig.suptitle(f"Every year, 1990-2026: Landsat {period.split('/')[-1]}-season median composites (harmonised to OLI), Pune District",
                 fontsize=12, fontweight="bold", x=0.01, ha="left")
    carto.footer(fig, "Fixed-stretch false colour (R=SWIR1 0.05-0.42, G=NIR 0.06-0.42, B=red 0.02-0.26 reflectance) - VISUAL QA ONLY, not a result. "
                 "Grey inside the boundary = no clear observation (never filled). Box = automated QA status. Grid G240 (240 m benchmark). " + SRC)
    fig.subplots_adjust(left=0.01, right=0.99, top=0.95, bottom=0.03)
    p = FIG / f"contact_sheet_{fam}_{grid_id}_{period.split('/')[-1]}.png"; fig.savefig(p, dpi=110); plt.close(fig); return p

def _qa(grid_id, fam="landsat"):
    p = config.path("results", "qa", fam, grid_id, "qa_summary.csv")
    return pd.read_csv(p) if p.exists() else None

# ------------------------------------------------------------------ F2 observation depth heat-map
def observation_depth(grid_id="pune_G240"):
    style.apply(); q = _qa(grid_id)
    if q is None: return None
    per = ["dry", "wet", "post_monsoon", "annual"]
    stp = q.pivot(index="period", columns="year", values="status").reindex(per)
    piv = q.pivot(index="period", columns="year", values="reliable_pct").reindex(per).where(stp != "IN_PROGRESS")
    fig, (a, b) = plt.subplots(2, 1, figsize=(15, 4.6), gridspec_kw={"height_ratios": [4, 4]}, sharex=True)
    cmap = ListedColormap(style.SEQ); norm = BoundaryNorm([0, 5, 20, 40, 60, 80, 95, 100.1], cmap.N)
    im = a.imshow(piv.values, aspect="auto", cmap=cmap, norm=norm)
    for i in range(piv.shape[0]):
        for j in range(piv.shape[1]):
            v = piv.values[i, j]
            if np.isfinite(v): a.text(j, i, f"{v:.0f}", ha="center", va="center", fontsize=6.5, color="white" if v >= 60 else style.INK)
    a.set_yticks(range(len(per))); a.set_yticklabels(per); a.grid(False)
    a.set_title("Share of district with ≥3 clear Landsat observations (%) - the statistical support behind each composite", loc="left")
    cb = fig.colorbar(im, ax=a, fraction=0.015, pad=0.01); cb.set_label("%", fontsize=8)
    smap = {"PASS": 0, "WARNING": 1, "FAIL": 2, "IN_PROGRESS": 3}
    sv = stp.apply(lambda c: c.map(smap)).astype(float).values
    b.imshow(sv, aspect="auto", cmap=ListedColormap([style.STATUS["PASS"], style.STATUS["WARNING"], style.STATUS["FAIL"], style.STATUS["IN_PROGRESS"]]), vmin=0, vmax=3)
    for i in range(sv.shape[0]):
        for j in range(sv.shape[1]):
            if np.isfinite(sv[i, j]): b.text(j, i, ["P", "W", "F", "–"][int(sv[i, j])], ha="center", va="center", fontsize=7, color=style.INK)
    b.set_yticks(range(len(per))); b.set_yticklabels(per); b.grid(False)
    b.set_xticks(range(piv.shape[1])); b.set_xticklabels(piv.columns, rotation=90, fontsize=8)
    b.set_title("Automated QA status (P = PASS, W = WARNING, F = FAIL, – = period in progress, no data yet; reasons in QA_REPORT.md)", loc="left")
    carto.footer(fig, "Source: results/qa/landsat/" + grid_id + "/qa_summary.csv (computed from per-pixel clear-observation counts). 2026 post-monsoon/annual are partial.")
    fig.tight_layout(rect=[0, 0.04, 1, 1]); p = FIG / f"observation_depth_{grid_id}.png"; fig.savefig(p, dpi=130); plt.close(fig); return p

# ------------------------------------------------------------------ F3 district time series
def district_trends(grid_id="pune_G240"):
    style.apply()
    from ..compositing.engine import district_mask
    from ..qa.checks import _grid_from_meta
    rows = []
    for y in range(1990, 2027):
        r = _comp(grid_id, y, "landsat", "seasonal/dry")
        if not r: continue
        c, n, meta = r
        ins = district_mask(_grid_from_meta(meta["grid"])) & (n >= 3)
        ndvi = (c["nir08"] - c["red"]) / (c["nir08"] + c["red"]); mndwi = (c["green"] - c["swir16"]) / (c["green"] + c["swir16"])
        v = ndvi[ins]
        rows.append({"year": y, "ndvi_median": float(np.nanmedian(v)), "ndvi_p25": float(np.nanpercentile(v, 25)),
                     "ndvi_p75": float(np.nanpercentile(v, 75)), "water_km2": float((mndwi[ins] > 0).sum() * meta["grid"]["res"] ** 2 / 1e6),
                     "support_pct": float(ins.sum() / district_mask(_grid_from_meta(meta["grid"])).sum() * 100),
                     "sensors": "+".join(sorted(s.replace("landsat-", "L") for s in meta["sensors"]))})
    df = pd.DataFrame(rows); df.to_csv(config.path("results", "timeline", f"district_dry_season_series_{grid_id}.csv"), index=False)
    rain = pd.read_csv(config.path("data", "processed", "climate", "chirps_v2_monthly_pune.csv"))
    jjas = rain[rain.month.isin([6, 7, 8, 9])].groupby("year").precip_mm_district_mean.agg(["sum", "size"])
    jjas = jjas[jjas["size"] == 4]["sum"]
    df["prev_monsoon_mm"] = df.year.map(lambda y: jjas.get(y - 1, np.nan))
    df.to_csv(config.path("results", "timeline", f"district_dry_season_series_{grid_id}.csv"), index=False)
    ok = df.support_pct >= 50
    fig, (a, b, c3) = plt.subplots(3, 1, figsize=(13, 10), sharex=True, gridspec_kw={"height_ratios": [1.2, 1, 0.8]})
    eras = [(1989.5, 1999.5, "L5"), (1999.5, 2013.5, "L5/L7 (L7 SLC-off from mid-2003)"), (2013.5, 2021.5, "L7/L8"), (2021.5, 2026.5, "L8/L9 (L9 term provisional)")]
    for ax in (a, b, c3):
        for i, (s0, e0, lab) in enumerate(eras):
            ax.axvspan(s0, e0, color="#f3f2ef" if i % 2 == 0 else style.SURF, zorder=0)
    a.fill_between(df.year[ok], df.ndvi_p25[ok], df.ndvi_p75[ok], color=style.SEQ[1], alpha=0.6, lw=0, label="interquartile range of pixels")
    a.plot(df.year[ok], df.ndvi_median[ok], color=style.CAT[0], lw=2, marker="o", ms=4, label="district median (≥50% of district supported)")
    a.scatter(df.year[~ok], df.ndvi_median[~ok], s=45, facecolor=style.SURF, edgecolor=style.CAT[0], lw=1.6, zorder=5, label="low support (<50% of district) - not representative")
    for _, r in df[~ok].iterrows(): a.annotate(f"{r.support_pct:.0f}% support", (r.year, r.ndvi_median), xytext=(4, 6), textcoords="offset points", fontsize=7, color=style.INK2)
    bot = df.ndvi_p25.min() * 0.86
    for s0, e0, lab in eras: a.text((s0 + e0) / 2, bot * 1.015, lab, ha="center", va="bottom", fontsize=8, color=style.INK2)
    a.set_ylim(bot, df.ndvi_p75.max() * 1.18); a.set_ylabel("dry-season NDVI"); a.legend(loc="upper left", fontsize=8, ncol=3)
    a.set_title("Dry-season (Jan-May) NDVI, harmonised to OLI - pixels with ≥3 clear observations", loc="left")
    b.bar(df.year[ok], df.water_km2[ok], color=style.CAT[0], width=0.7)
    b.bar(df.year[~ok], df.water_km2[~ok], color="none", edgecolor=style.CAT[0], hatch="////", width=0.7, lw=1)
    b.set_ylabel("km²"); b.set_title("Dry-season open water (MNDWI > 0 on median composite; hatched = low support) - 240 m DIAGNOSTIC, narrow rivers under-counted", loc="left")
    c3.bar(df.year, df.prev_monsoon_mm, color=style.SEQ[3], width=0.7)
    c3.set_ylabel("mm"); c3.set_title("Preceding monsoon rainfall (Jun-Sep of year-1), CHIRPS v2.0 area-weighted district mean", loc="left")
    from scipy.stats import spearmanr
    m = ok & df.prev_monsoon_mm.notna()
    rho, pv = spearmanr(df.prev_monsoon_mm[m], df.water_km2[m])
    carto.footer(fig, f"Exploratory association (supported years only, n={int(m.sum())}): Spearman rho(preceding monsoon, dry-season water) = {rho:.2f} ({'p<0.001' if pv < 0.001 else f'p={pv:.3f}'}) - association, not causation; "
                 "storage and releases (reservoir operations) are not yet in the data. Table: results/timeline/district_dry_season_series_" + grid_id + ".csv. " + SRC)
    fig.tight_layout(rect=[0, 0.04, 1, 1]); p = FIG / f"district_dry_season_series_{grid_id}.png"; fig.savefig(p, dpi=130); plt.close(fig); return p

# ------------------------------------------------------------------ F4 Sentinel-2 monthly
WC = {40: "Cropland", 10: "Tree cover", 30: "Grassland", 50: "Built-up"}

def s2_monthly(grid_id="pune_G240", year=2024):
    style.apply()
    wc, _ = _read(config.path("data", "features", "reference", grid_id, "esa_worldcover_2021_mode.tif"))
    fig = plt.figure(figsize=(15, 9.6)); gs = fig.add_gridspec(5, 6, height_ratios=[1, 1, 0.06, 0.12, 1.15], hspace=0.22, top=0.95, bottom=0.07)
    rows = []; ext = None
    for m in range(1, 13):
        ax = fig.add_subplot(gs[(m - 1) // 6, (m - 1) % 6]); ax.axis("off")
        r = _comp(grid_id, year, "sentinel2", f"monthly/{year}-{m:02d}")
        c, n, meta = r; ext = _grid_extent(meta)
        ndvi = (c["nir"] - c["red"]) / (c["nir"] + c["red"]); ndvi[n < 1] = np.nan
        im = ax.imshow(ndvi, extent=ext, cmap="Greens", vmin=0, vmax=0.8, interpolation="nearest")
        carto.boundary(ax, lw=0.35)
        valid = meta["statistics"]["district_valid_fraction"] * 100
        ax.set_title(f"{year}-{m:02d} · {meta['statistics']['n_items']} scenes · {valid:.0f}% clear", fontsize=8, loc="left")
        for k, lab in WC.items():
            v = ndvi[(wc[0] == k)]
            rows.append({"month": m, "class": lab, "ndvi": float(np.nanmedian(v)) if np.isfinite(v).any() else np.nan,
                         "clear_frac": float(np.isfinite(v).mean()), "district_cov": valid})
    cax = fig.add_subplot(gs[2, 1:5]); cb = fig.colorbar(im, cax=cax, orientation="horizontal"); cb.set_label("NDVI (monthly median of clear Sentinel-2 L2A observations)", fontsize=8, labelpad=2)
    a = fig.add_subplot(gs[4, :]); df = pd.DataFrame(rows)
    for i, lab in enumerate(WC.values()):
        d = df[df["class"] == lab]
        a.plot(d.month, d.ndvi, color=style.CAT[i], lw=2, marker="o", ms=5, label=lab)
        lo = d[d.district_cov < 50]
        a.scatter(lo.month, lo.ndvi, s=60, facecolor=style.SURF, edgecolor=style.CAT[i], lw=2, zorder=5)
        last = d.dropna().iloc[-1]; a.text(12.15, last.ndvi, lab, color=style.INK, fontsize=8, va="center")
    a.axvspan(5.5, 9.5, color="#eef4fc", zorder=0); a.text(7.5, 0.05, "SW monsoon: optical blackout (July: 0 usable scenes; hollow = <50% of district clear)", ha="center", fontsize=8, color=style.INK2)
    a.set_xticks(range(1, 13)); a.set_xlim(0.7, 13.2); a.set_ylim(0, 0.8); a.set_ylabel("median NDVI"); a.legend(loc="upper left", fontsize=8, ncol=4)
    a.set_title(f"Monthly NDVI by land-cover stratum (ESA WorldCover 2021 used for stratification only), {year}", loc="left")
    df.to_csv(config.path("results", "timeline", f"s2_monthly_ndvi_by_class_{grid_id}_{year}.csv"), index=False)
    fig.suptitle(f"Sentinel-2 dense time series - Pune District {year} (every month, real observations)", fontsize=13, fontweight="bold", x=0.01, ha="left")
    carto.footer(fig, "Grid G240 benchmark (SR from COG overviews averaged; SCL cloud mask aggregated conservatively). Missing months/areas = no clear observation, never filled. " + SRC)
    p = FIG / f"s2_monthly_{grid_id}_{year}.png"; fig.savefig(p, dpi=115); plt.close(fig); return p

# ------------------------------------------------------------------ F5 Sentinel-1 monthly
def s1_monthly(grid_id="pune_G240", year=2024):
    style.apply()
    wc, _ = _read(config.path("data", "features", "reference", grid_id, "esa_worldcover_2021_mode.tif"))
    fig = plt.figure(figsize=(15, 9.6)); gs = fig.add_gridspec(5, 6, height_ratios=[1, 1, 0.06, 0.12, 1.15], hspace=0.22, top=0.95, bottom=0.07)
    rows = []
    for m in range(1, 13):
        ax = fig.add_subplot(gs[(m - 1) // 6, (m - 1) % 6]); ax.axis("off")
        d = config.path("data", "composites", grid_id, str(year), "sentinel1", "monthly", f"{year}-{m:02d}")
        a_, _ = _read(d / "backscatter_mean_db.tif"); n, _ = _read(d / "observation_count.tif"); meta = json.loads((d / "metadata.json").read_text())
        vv = a_[0]; vv[n[0] < 1] = np.nan
        im = ax.imshow(vv, extent=_grid_extent(meta), cmap="Greys_r", vmin=-20, vmax=-2, interpolation="nearest")
        carto.boundary(ax, lw=0.35)
        ax.set_title(f"{year}-{m:02d} · {meta['statistics']['n_items']} frames · {meta['statistics']['district_valid_fraction']*100:.0f}% covered", fontsize=8, loc="left")
        cov = meta['statistics']['district_valid_fraction'] * 100
        for k, lab in WC.items():
            v = vv[wc[0] == k]; rows.append({"month": m, "class": lab, "vv_db": float(np.nanmedian(v)) if np.isfinite(v).any() else np.nan, "district_cov": cov})
    cax = fig.add_subplot(gs[2, 1:5]); cb = fig.colorbar(im, cax=cax, orientation="horizontal"); cb.set_label("VV gamma0 (dB), monthly mean in linear power", fontsize=8, labelpad=2)
    a = fig.add_subplot(gs[4, :]); df = pd.DataFrame(rows)
    for i, lab in enumerate(WC.values()):
        dd = df[df["class"] == lab]; a.plot(dd.month, dd.vv_db, color=style.CAT[i], lw=2, marker="o", ms=5, label=lab)
        lo = dd[dd.district_cov < 50]; a.scatter(lo.month, lo.vv_db, s=60, facecolor=style.SURF, edgecolor=style.CAT[i], lw=2, zorder=5)
        a.text(12.15, dd.dropna().iloc[-1].vv_db, lab, fontsize=8, va="center")
    a.axvspan(5.5, 9.5, color="#eef4fc", zorder=0); a.text(7.5, df.vv_db.min() - 0.3, "Jun-Jul: only an 18% western strip was imaged (hollow points are NOT district-representative)", ha="center", fontsize=8, color=style.INK2)
    a.set_xticks(range(1, 13)); a.set_xlim(0.7, 13.2); a.set_ylabel("median VV (dB)"); a.legend(loc="upper left", fontsize=8, ncol=4)
    a.set_title(f"Monthly VV backscatter by land-cover stratum, {year}", loc="left")
    df.to_csv(config.path("results", "timeline", f"s1_monthly_vv_by_class_{grid_id}_{year}.csv"), index=False)
    fig.suptitle(f"Sentinel-1 RTC dense time series - Pune District {year} (cloud-independent, but acquisition-limited)", fontsize=13, fontweight="bold", x=0.01, ha="left")
    carto.footer(fig, "Dominant orbit (descending). Most of the district incl. Pune city is imaged only by relative orbit 136 (18 dates in 2024) and had NO acquisition "
                 "31 May - 23 Aug 2024 (verified in both RTC and GRD: an acquisition-plan gap, not processing); Jun-Jul coverage is a western strip from orbit 34. " + SRC)
    p = FIG / f"s1_monthly_{grid_id}_{year}.png"; fig.savefig(p, dpi=115); plt.close(fig); return p

# ------------------------------------------------------------------ F6 harmonisation evidence
def harmonization_figure():
    style.apply()
    r = json.loads(config.path("results", "harmonization", "harmonization_report.json").read_text())
    fig, (a, b) = plt.subplots(1, 2, figsize=(13, 4.6))
    order = ["none", "roy2016_ols", "local_ols", "local_rma"]; lab = {"none": "no harmonisation", "roy2016_ols": "Roy et al. 2016 (OLS)", "local_ols": "local OLS", "local_rma": "local RMA (adopted rule)"}
    pairs = [k for k in r["pairs"] if "loyo_mean" in r["pairs"][k]]
    w = 0.2
    for i, t in enumerate(order):
        nd, rm = [], []
        for k in pairs:
            L = pd.DataFrame(r["pairs"][k]["loyo_mean"])
            s = L[(L["transform"] == t) & (L["band"] == "NDVI")]
            nd.append(abs(s.bias.iloc[0]) if len(s) else np.nan)
            s2 = L[(L["transform"] == t) & (L["band"] != "NDVI")]
            rm.append(s2.rmsd.mean() if len(s2) else np.nan)
        x = np.arange(len(pairs)) + (i - 1.5) * w
        a.bar(x, nd, w * 0.92, color=style.CAT[i], label=lab[t]); b.bar(x, rm, w * 0.92, color=style.CAT[i], label=lab[t])
    for ax, t in [(a, "|NDVI bias| on held-out years"), (b, "mean band RMSD on held-out years (reflectance)")]:
        ax.set_xticks(range(len(pairs))); ax.set_xticklabels([p.replace("landsat-", "L") for p in pairs]); ax.set_title(t, loc="left")
    a.legend(fontsize=8, loc="upper right")
    for i, k in enumerate(pairs):
        d = r["decisions"][k]; a.text(i, -0.004, "applied" if d["apply_local"] else "identity", ha="center", va="top", fontsize=8, color=style.INK2)
    fig.suptitle("Sensor harmonisation evidence - Pune District sensor-overlap composites, leave-one-year-out", fontsize=12, fontweight="bold", x=0.01, ha="left")
    carto.footer(fig, f"Pixels: L5-L7 {r['pairs']['landsat-5->landsat-7']['n_pixels']:,} (2000-01), L7-L8 {r['pairs']['landsat-7->landsat-8']['n_pixels']:,} (2014-16), "
                 f"L9-L8 {r['pairs']['landsat-9->landsat-8']['n_pixels']:,} (2022-23); dry-season composites, ≥3 clear obs, SE<0.01. Fitted at 240 m: refit at 30 m before publication.")
    fig.tight_layout(rect=[0, 0.05, 1, 0.94]); p = FIG / "harmonization_evidence.png"; fig.savefig(p, dpi=130); plt.close(fig); return p

# ------------------------------------------------------------------ F7 publication map template
def publication_map(grid_id="pune_G240", year=2025, period="seasonal/dry"):
    style.apply(); c, n, meta = _comp(grid_id, year, "landsat", period)
    fig = plt.figure(figsize=(10, 9.4)); ax = fig.add_axes([0.08, 0.13, 0.84, 0.78])
    ax.imshow(_fcc(c, n, meta=meta), extent=_grid_extent(meta), interpolation="nearest"); carto.boundary(ax, lw=1.0)
    carto.graticule(ax); carto.scalebar(ax, 50); carto.north_arrow(ax)
    st = meta["statistics"]; t = meta["temporal"]
    ax.set_title(f"Pune District - Landsat {', '.join(s.replace('landsat-', 'L') for s in sorted(meta['sensors']))} "
                 f"{period.split('/')[-1]}-season composite, {t['start']} to {t['end']}", loc="left", fontsize=11)
    ax.legend(handles=[Patch(fc=NODATA_RGB, ec=style.MUTED, label="no clear observation (inside district)")], loc="upper left", fontsize=8)
    carto.footer(fig, f"Method: per-pixel median of {st['n_items']} QA-masked scenes (median {st['n_clear_median']:.0f} clear obs/pixel; {st['district_reliable_fraction_ge3']*100:.1f}% of district with ≥3), "
                 f"harmonised to OLI ({meta['processing']['harmonization']}). Display: fixed-stretch SWIR1/NIR/red false colour. Uncertainty: per-pixel SE of median in uncertainty.tif "
                 f"(district median red SE {st['uncertainty_medians']['red']:.4f}). QA: {meta.get('qa', {}).get('status', 'n/a')}. Grid G240 (240 m). Product id {meta['product_id']}. " + SRC, y=0.01)
    p = FIG / f"map_{grid_id}_{year}_{period.split('/')[-1]}.png"; fig.savefig(p, dpi=150); plt.close(fig); return p

# ------------------------------------------------------------------ F8 30 m AOI water persistence
def aoi_water(grid_id="pune_G30_khadakwasla_mutha"):
    style.apply(); stack, years, ext, sup = [], [], None, []
    for y in range(1990, 2027):
        r = _comp(grid_id, y, "landsat", "seasonal/dry")
        if not r: continue
        c, n, meta = r; ext = _grid_extent(meta)
        w = ((c["green"] - c["swir16"]) / (c["green"] + c["swir16"]) > 0).astype(np.float32); w[n < 3] = np.nan
        stack.append(w); years.append(y)
    S = np.stack(stack); freq = np.nanmean(S, 0); nyr = np.isfinite(S).sum(0); freq[nyr < 10] = np.nan
    freq_disp = np.where(freq > 0, freq, np.nan)   # never-water cells left blank, not tinted
    area = np.nansum(S, axis=(1, 2)) * 900 / 1e6; cov = np.isfinite(S).mean(axis=(1, 2)) * 100
    fig = plt.figure(figsize=(13, 9)); gs = fig.add_gridspec(2, 2, height_ratios=[1.6, 1], width_ratios=[1.25, 1])
    a = fig.add_subplot(gs[0, 0]); a.set_facecolor("white")
    im = a.imshow(freq_disp, extent=ext, cmap=ListedColormap(style.SEQ), vmin=0, vmax=1, interpolation="nearest")
    a.set_title(f"Dry-season water frequency {years[0]}-{years[-1]} (share of years with MNDWI > 0)", loc="left", fontsize=10)
    carto.graticule(a, step=0.05); carto.scalebar(a, 5, compact=True); carto.north_arrow(a, size=0.09)
    fig.colorbar(im, ax=a, fraction=0.035, label="fraction of valid years")
    b = fig.add_subplot(gs[0, 1]); last = _comp(grid_id, years[-1], "landsat", "seasonal/dry")
    b.imshow(_fcc(last[0], last[1]), extent=ext, interpolation="nearest"); b.set_title(f"{years[-1]} dry composite (30 m, visual reference)", loc="left", fontsize=10)
    carto.graticule(b, step=0.05); a.set_xlim(ext[0], ext[1]); a.set_ylim(ext[2], ext[3])
    cax = fig.add_subplot(gs[1, :])
    yrs = np.array(years); good = cov >= 90; part = (cov >= 50) & ~good; bad = cov < 50
    cax.bar(yrs[good], area[good], color=style.CAT[0], width=0.7, label="≥90% of window with ≥3 clear obs")
    cax.bar(yrs[part], area[part], color=style.SEQ[1], width=0.7, label="50-90% support (partial)")
    for y in yrs[bad]: cax.text(y, 0.15, "n/a", ha="center", rotation=90, fontsize=7, color=style.INK2)
    cax.set_ylabel("km²"); cax.set_ylim(0, np.nanmax(area) * 1.3); cax.legend(loc="upper left", ncol=2, fontsize=8, frameon=True, framealpha=0.95, edgecolor="none")
    cax.set_title("Dry-season open-water area in the window (n/a = <50% of window had ≥3 clear observations - not measured)", loc="left")
    fig.suptitle("Khadakwasla reservoir to the Mutha corridor - full-resolution (30 m, native Landsat lattice), every year", fontsize=12, fontweight="bold", x=0.01, ha="left")
    carto.footer(fig, "Water = MNDWI>0 on the harmonised dry-season median composite; reservoir drawdown and the narrow river are both "
                 "visible; extent is NOT level or volume. " + SRC)
    pd.DataFrame({"year": years, "water_km2": area, "support_pct": cov}).to_csv(config.path("results", "timeline", f"aoi_water_{grid_id}.csv"), index=False)
    fig.tight_layout(rect=[0, 0.04, 1, 0.95]); p = FIG / f"aoi_water_{grid_id}.png"; fig.savefig(p, dpi=130); plt.close(fig); return p

def all_figures(grid_id="pune_G240"):
    out = []
    for f in (lambda: contact_sheet(grid_id), lambda: contact_sheet(grid_id, "seasonal/wet"), lambda: observation_depth(grid_id),
              lambda: district_trends(grid_id), lambda: s2_monthly(grid_id), lambda: s1_monthly(grid_id),
              harmonization_figure, lambda: publication_map(grid_id), lambda: aoi_water()):
        try:
            p = f()
            if p: out.append(p)
        except Exception as e:
            out.append(f"skipped: {e!r}")
    return out

# ------------------------------------------------------------------ F9 data depth across 37 years
def data_depth(grid_id="pune_G240", period="seasonal/dry"):
    style.apply()
    from ..compositing.engine import district_mask
    from ..qa.checks import _grid_from_meta
    cnt, years, ext, ins = None, [], None, None
    for y in range(1990, 2027):
        d = config.path("data", "composites", grid_id, str(y), "landsat", period)
        if not (d / "observation_count.tif").exists(): continue
        n, _ = _read(d / "observation_count.tif"); meta = json.loads((d / "metadata.json").read_text())
        if cnt is None:
            cnt = np.zeros(n[0].shape, np.int16); ext = _grid_extent(meta); ins = district_mask(_grid_from_meta(meta["grid"]))
        cnt += (n[0] >= 3); years.append(y)
    disp = np.where(ins, cnt, np.nan).astype(float)
    fig, ax = plt.subplots(figsize=(9.5, 8.6))
    cmap = ListedColormap(style.SEQ); bnds = [0, 20, 25, 30, 33, 35, 36, 37.5]
    im = ax.imshow(disp, extent=ext, cmap=cmap, norm=BoundaryNorm(bnds, cmap.N), interpolation="nearest")
    carto.boundary(ax, lw=0.8); carto.graticule(ax); carto.scalebar(ax, 50); carto.north_arrow(ax)
    cb = fig.colorbar(im, ax=ax, fraction=0.035, pad=0.02, ticks=[0, 20, 25, 30, 33, 35, 36, 37]); cb.set_label(f"years (of {len(years)}) with ≥3 clear observations")
    v = disp[np.isfinite(disp)]
    ax.set_title(f"Data depth: in how many years is each pixel's {period.split('/')[-1]}-season Landsat composite statistically supported?", loc="left", fontsize=10)
    carto.footer(fig, f"District median {np.median(v):.0f} of {len(years)} years; 5th percentile {np.percentile(v, 5):.0f}. Gaps follow WRS-2 path/row footprints "
                 "(e.g. thin archive years 1997, 2003). Computed from observation_count.tif of every yearly product. " + SRC)
    fig.tight_layout(rect=[0, 0.05, 1, 1]); p = FIG / f"data_depth_{grid_id}_{period.split('/')[-1]}.png"; fig.savefig(p, dpi=130); plt.close(fig); return p

# ------------------------------------------------------------------ F10 Sentinel-2 10 m field-scale phenology
def s2_field_phenology(grid_id="pune_G10_baramati_agri", year=2024):
    style.apply()
    S, ext, cov, labs = [], None, [], []
    for m in range(1, 13):
        r = _comp(grid_id, year, "sentinel2", f"monthly/{year}-{m:02d}")
        if not r: continue
        c, n, meta = r; ext = _grid_extent(meta)
        nd = (c["nir"] - c["red"]) / (c["nir"] + c["red"]); nd[n < 1] = np.nan
        S.append(nd); cov.append(np.isfinite(nd).mean() * 100); labs.append(m)
    S = np.stack(S)
    fig = plt.figure(figsize=(15, 10.8))
    gs = fig.add_gridspec(5, 6, height_ratios=[1, 1, 0.06, 0.16, 1.55], hspace=0.22, wspace=0.06, top=0.93, bottom=0.08, left=0.04, right=0.98)
    for i, m in enumerate(labs):
        ax = fig.add_subplot(gs[i // 6, i % 6]); ax.set_xticks([]); ax.set_yticks([]); ax.grid(False)
        for sp in ax.spines.values(): sp.set_visible(True); sp.set_color(style.GRID)
        ax.set_facecolor(NODATA_RGB)
        im = ax.imshow(S[i], extent=ext, cmap="Greens", vmin=0, vmax=0.85, interpolation="nearest")
        ax.set_title(f"{year}-{m:02d} · {cov[i]:.0f}% clear", fontsize=8, loc="left", pad=3)
    cax = fig.add_subplot(gs[2, 1:5]); fig.colorbar(im, cax=cax, orientation="horizontal").set_label("NDVI, Sentinel-2 L2A monthly median, 10 m native grid (grey = no clear observation)", fontsize=8, labelpad=2)
    dry = [i for i, m in enumerate(labs) if m in (1, 2, 3, 4, 5, 10, 11, 12) and cov[i] > 80]
    amp = np.nanmax(S[dry], 0) - np.nanmin(S[dry], 0)
    sub = gs[4, :].subgridspec(1, 4, width_ratios=[1.0, 0.035, 0.16, 1.35], wspace=0.05)
    a = fig.add_subplot(sub[0, 0]); im2 = a.imshow(amp, extent=ext, cmap=ListedColormap(style.SEQ), vmin=0, vmax=0.6, interpolation="nearest")
    carto.graticule(a, step=0.05); carto.scalebar(a, 2, compact=True)
    fig.colorbar(im2, cax=fig.add_subplot(sub[0, 1])).set_label("max - min monthly NDVI", fontsize=8)
    a.set_title("EXPLORATORY: seasonal NDVI amplitude (not a crop map)", loc="left", fontsize=10)
    b = fig.add_subplot(sub[0, 3])
    q = np.nanpercentile(S.reshape(len(labs), -1), [10, 25, 50, 75, 90], axis=1)
    b.fill_between(labs, q[0], q[4], color=style.SEQ[0], label="10-90th percentile of pixels")
    b.fill_between(labs, q[1], q[3], color=style.SEQ[2], label="25-75th percentile")
    b.plot(labs, q[2], color=style.CAT[0], lw=2, marker="o", label="median")
    for m, cv in zip(labs, cov):
        if cv < 50: b.text(m, 0.03, f"{cv:.0f}%\nclear", ha="center", fontsize=7, color=style.INK2)
    b.set_xticks(range(1, 13)); b.set_ylim(0, 0.9); b.set_ylabel("NDVI"); b.set_xlabel("month"); b.legend(fontsize=8, loc="upper left")
    b.set_title("Monthly NDVI distribution across all 10 m pixels in the window", loc="left", fontsize=10)
    fig.suptitle(f"Field-scale Sentinel-2 time series - Nira canal agriculture around Baramati, {year} (10 m, native Sentinel lattice)",
                 fontsize=12, fontweight="bold", x=0.01, ha="left")
    carto.footer(fig, "Amplitude highlights multi-season / irrigated fields versus single-season or fallow land, but crop type and rotation require reference data and S1+S2 "
                 "phenology models (milestone M3). 20 m bands are duplicated, never sharpened, onto the 10 m grid. " + SRC)
    p = FIG / f"s2_field_phenology_{grid_id}_{year}.png"; fig.savefig(p, dpi=120); plt.close(fig); return p

# ------------------------------------------------------------------ F11 Sentinel availability matrix
def sentinel_matrix(grid_id="pune_G240", fam="sentinel1", y0=2015, y1=2026):
    style.apply(); rows = []
    for y in range(y0, y1 + 1):
        for m in range(1, 13):
            p = config.path("data", "composites", grid_id, str(y), fam, "monthly", f"{y}-{m:02d}", "metadata.json")
            if not p.exists(): continue
            d = json.loads(p.read_text()); s = d["statistics"]
            not_started = d["temporal"]["start"] > d["temporal"]["archive_cutoff_utc"][:10]
            in_progress = (not d["temporal"]["complete"]) and s["n_items"] == 0 and not not_started
            future = not_started or in_progress
            state = "future" if not_started else ("in progress" if in_progress else "")
            rows.append({"year": y, "month": m, "valid_pct": np.nan if future else 100 * s["district_valid_fraction"],
                         "reliable_pct": np.nan if future else 100 * s["district_reliable_fraction_ge3"], "n_items": s["n_items"],
                         "complete": d["temporal"]["complete"], "future": future, "state": state})
    df = pd.DataFrame(rows)
    if df.empty: return None
    df.to_csv(config.path("results", "timeline", f"{fam}_monthly_availability_{grid_id}.csv"), index=False)
    piv = df.pivot(index="year", columns="month", values="valid_pct").reindex(range(y0, y1 + 1))
    stt = df.pivot(index="year", columns="month", values="state").reindex(range(y0, y1 + 1))
    fig, ax = plt.subplots(figsize=(10, 0.42 * len(piv) + 1.8))
    cmap = ListedColormap(style.SEQ); norm = BoundaryNorm([0, 5, 25, 50, 75, 90, 99, 100.1], cmap.N)
    im = ax.imshow(piv.values, aspect="auto", cmap=cmap, norm=norm)
    for i in range(piv.shape[0]):
        for j in range(piv.shape[1]):
            v = piv.values[i, j]
            if np.isfinite(v): ax.text(j, i, f"{v:.0f}", ha="center", va="center", fontsize=7, color="white" if v >= 75 else style.INK)
            elif isinstance(stt.values[i, j], str) and stt.values[i, j]: ax.text(j, i, stt.values[i, j], ha="center", va="center", fontsize=6.5, color=style.MUTED)
    ax.set_xticks(range(12)); ax.set_xticklabels(["J", "F", "M", "A", "M", "J", "J", "A", "S", "O", "N", "D"])
    ax.set_yticks(range(len(piv))); ax.set_yticklabels(piv.index); ax.grid(False)
    what = "imaged by Sentinel-1 (dominant orbit)" if fam == "sentinel1" else "with ≥1 clear Sentinel-2 observation"
    ax.set_title(f"Share of Pune District {what}, per month (%)", loc="left", fontsize=10)
    fig.colorbar(im, ax=ax, fraction=0.03, pad=0.01).set_label("%")
    carto.footer(fig, f"Computed from monthly product metadata (results/timeline/{fam}_monthly_availability_{grid_id}.csv). 'future'/'in progress' = not yet observable at the archive cut-off (2026-10-01); 0 = month passed with no usable data.")
    fig.tight_layout(rect=[0, 0.04, 1, 1]); p = FIG / f"{fam}_monthly_availability_{grid_id}.png"; fig.savefig(p, dpi=130); plt.close(fig); return p
