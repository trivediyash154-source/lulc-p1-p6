"""Job ledger summary: what is done, failed, pending - so a run can always be resumed."""
from __future__ import annotations
import json
from . import config

def status(years) -> str:
    years = list(years); lines = []
    for f in sorted(config.path("data", "manifests", "jobs").glob("*.json")):
        jobs = json.loads(f.read_text())
        from pathlib import Path
        done_all = [k for k, v in jobs.items() if v["status"] == "done"]
        done = sorted(int(k.rsplit("/", 1)[1]) for k in done_all if all((config.ROOT / o).exists() for o in jobs[k].get("outputs", [])))
        absent = len(done_all) - len(done)
        failed = {k: v.get("error", "")[:80] for k, v in jobs.items() if v["status"] == "failed"}
        running = [k for k, v in jobs.items() if v["status"] == "running"]
        fam = f.stem
        start = {"sentinel2": 2018, "sentinel1": 2015}.get(fam.split("_pune")[0], min(years))
        is_window = fam.count("_") > 2 or "_G" in fam and len(fam.split("_pune_")[-1].split("_")) > 1
        pend = [y for y in years if y >= start and y not in done] if not (fam.startswith("landsat_cal") or is_window) else []
        lines.append(f"{fam:<44} done {len(done):>3}  failed {len(failed):>2}  running {len(running):>2}"
                     + (f"  done-elsewhere(rasters absent here) {absent}" if absent else "")
                     + (f"  pending {pend[0]}..{pend[-1]} ({len(pend)})" if pend else ""))
        for k, e in failed.items(): lines.append(f"    FAILED {k}: {e}")
    return "\n".join(lines) or "no jobs yet"
