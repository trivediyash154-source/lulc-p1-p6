"""Named windows (configs/aois.yaml) on any grid."""
from __future__ import annotations
from pyproj import Transformer
from .. import config
from ..grid import Grid, district_grid

def aoi_window(name: str, grid: Grid):
    a = config.load("aois")[name]
    x0, y0, x1, y1 = a["bbox_wgs84"]
    t = Transformer.from_crs(4326, grid.crs, always_xy=True)
    xs, ys = zip(*[t.transform(x, y) for x, y in [(x0, y0), (x0, y1), (x1, y0), (x1, y1)]])
    return grid.window((min(xs), min(ys), max(xs), max(ys)))

def resolve(grid_name: str, window_name: str):
    g = district_grid(grid_name)
    if window_name in (None, "district"):
        return g, None, "district"
    return g, aoi_window(window_name, g), window_name
