"""Temporal periods: annual, seasons, months. Partial-period detection against the archive cut-off."""
from __future__ import annotations
import calendar
from dataclasses import dataclass
import pandas as pd
from .. import config

@dataclass(frozen=True)
class Period:
    year: int
    kind: str          # annual | season | month
    name: str          # annual | dry | wet | post_monsoon | YYYY-MM
    months: tuple

    @property
    def start(self) -> pd.Timestamp:
        return pd.Timestamp(self.year, min(self.months), 1, tz="UTC")

    @property
    def end(self) -> pd.Timestamp:
        m = max(self.months)
        return pd.Timestamp(self.year, m, calendar.monthrange(self.year, m)[1], 23, 59, 59, tz="UTC")

    def complete(self, cutoff: pd.Timestamp) -> bool:
        return self.end <= cutoff

    @property
    def relpath(self) -> str:
        if self.kind == "annual": return "annual"
        if self.kind == "season": return f"seasonal/{self.name}"
        return f"monthly/{self.name}"

def standard_periods(year: int, include_months: bool = False) -> list[Period]:
    per = config.load("temporal")["periods"]
    out = [Period(year, "annual", "annual", tuple(per["annual"]["months"]))]
    out += [Period(year, "season", k, tuple(v["months"])) for k, v in per.items() if k != "annual"]
    if include_months:
        out += [Period(year, "month", f"{year}-{m:02d}", (m,)) for m in range(1, 13)]
    return out

def items_in(df: pd.DataFrame, p: Period) -> pd.DataFrame:
    return df[(df["year"] == p.year) & (df["month"].isin(p.months))]
