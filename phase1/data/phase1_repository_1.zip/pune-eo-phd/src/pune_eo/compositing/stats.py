"""Per-pixel temporal reducers. Pure numpy - unit-tested with SYNTHETIC TEST DATA."""
from __future__ import annotations
import warnings
import numpy as np

def nanmedian0(a: np.ndarray):
    """Median along axis 0 ignoring NaN, via one C-level sort (NaN sorts last).
    Equivalent to np.nanmedian(a, axis=0) but avoids numpy's slow masked-array path for short axes."""
    s = np.sort(a, axis=0)
    n = np.isfinite(a).sum(axis=0)
    lo = np.maximum((n - 1) // 2, 0)[None]; hi = np.maximum(n // 2, 0)[None]
    med = (np.take_along_axis(s, lo, 0)[0] + np.take_along_axis(s, hi, 0)[0]) * 0.5
    med = med.astype(np.float32)
    med[n == 0] = np.nan
    return med, n

MAD_TO_SIGMA = 1.4826        # consistency constant for normal data
SE_MEDIAN = 1.2533           # sqrt(pi/2): asymptotic SE of the median relative to sigma/sqrt(n)

def robust_composite(values: np.ndarray, min_n_unc: int = 3):
    """values: (n_obs, rows, cols) float32, NaN = not a clear observation.

    Returns median, se_of_median (NaN where n < min_n_unc), n_clear.
    Uncertainty is the standard error of the median estimated from the scaled MAD, i.e. it
    captures within-period variability (phenology, residual contamination, noise) of the sample
    the composite was drawn from.
    """
    med, n = nanmedian0(values)
    mad, _ = nanmedian0(np.abs(values - med[None]))
    n = n.astype(np.uint16)
    se = SE_MEDIAN * MAD_TO_SIGMA * mad / np.sqrt(np.maximum(n, 1))
    se[n < min_n_unc] = np.nan
    return med.astype(np.float32), se.astype(np.float32), n

def linear_power_stats(lin: np.ndarray):
    """SAR: mean in linear power -> dB; median & std computed in dB."""
    n = np.isfinite(lin).sum(axis=0).astype(np.uint16)
    with warnings.catch_warnings():
        warnings.simplefilter("ignore", RuntimeWarning)
        mean_lin = np.nanmean(lin, axis=0)
        db = 10 * np.log10(lin)
        med_db, _ = nanmedian0(db)
        std_db = np.nanstd(db, axis=0)
    mean_db = 10 * np.log10(mean_lin)
    std_db[n < 2] = np.nan
    return mean_db.astype(np.float32), med_db.astype(np.float32), std_db.astype(np.float32), n
