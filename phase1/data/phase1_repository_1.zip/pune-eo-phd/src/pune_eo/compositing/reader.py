"""Read one observation's assets onto (a window of) a fixed analysis grid.

* Native resolution: nearest-neighbour on the native lattice -> an exact copy, no interpolation.
* Coarser grids: reflectance from a COG overview no coarser than half the target cell, then
  area-AVERAGED; categorical QA (bit flags / SCL) from a finer overview, sampled, then
  aggregated CONSERVATIVELY (cell clear only if every sample inside is clear).
"""
from __future__ import annotations
import math
import numpy as np
import planetary_computer as pc
import rasterio
from rasterio.enums import Resampling
from rasterio.vrt import WarpedVRT
from rasterio.warp import transform_bounds
from .. import config
from ..grid import Grid

def _ovr_level(overviews: list[int], factor_max: float):
    """Largest overview factor <= factor_max -> (OVERVIEW_LEVEL index, factor) or (None, 1)."""
    best = (None, 1)
    for i, f in enumerate(overviews):
        if f <= factor_max + 1e-9:
            best = (i, f)
    return best

def read_to_grid(href: str, grid: Grid, *, native_res: float, resampling: Resampling,
                 max_overview_factor: float | None = None, src_nodata=None, dst_nodata=np.nan,
                 dtype="float32", restrict=None):
    """Return (window_on_grid, array) or (None, None) if the source does not touch the grid.

    `restrict`: optional rasterio Window on `grid` to limit the read (e.g. a tile)."""
    href = pc.sign(href)
    with rasterio.Env(**config.GDAL_ENV):
        with rasterio.open(href) as probe:
            ovrs = probe.overviews(1)
            bnds = transform_bounds(probe.crs, grid.crs, *probe.bounds) if probe.crs != grid.crs else probe.bounds
        win = grid.window(bnds)
        if restrict is not None:
            win = win.intersection(restrict) if _intersects(win, restrict) else None
        if win is None or win.width == 0 or win.height == 0:
            return None, None
        lvl, _ = _ovr_level(ovrs, max_overview_factor) if max_overview_factor else (None, 1)
        kw = {"overview_level": lvl} if lvl is not None else {}
        sub = grid.subgrid(win)
        with rasterio.open(href, **kw) as src:
            with WarpedVRT(src, crs=grid.crs, transform=sub.transform, width=sub.width, height=sub.height,
                           resampling=resampling, src_nodata=src_nodata if src_nodata is not None else src.nodata,
                           nodata=dst_nodata, dtype=dtype) as vrt:
                arr = vrt.read(1)
    return win, arr

def _intersects(a, b) -> bool:
    return not (a.col_off >= b.col_off + b.width or b.col_off >= a.col_off + a.width or
                a.row_off >= b.row_off + b.height or b.row_off >= a.row_off + a.height)

def factor(grid: Grid, native_res: float) -> int:
    f = grid.res / native_res
    if abs(f - round(f)) > 1e-6:
        raise ValueError(f"grid {grid.res} m is not an integer multiple of native {native_res} m")
    return int(round(f))

def source_window(href: str, grid: Grid, restrict=None):
    """Window of `grid` touched by the source raster (header read only; no pixels)."""
    with rasterio.Env(**config.GDAL_ENV):
        with rasterio.open(pc.sign(href)) as src:
            bnds = transform_bounds(src.crs, grid.crs, *src.bounds) if src.crs != grid.crs else src.bounds
    win = grid.window(bnds)
    if restrict is not None:
        if not _intersects(win, restrict):
            return None
        win = win.intersection(restrict)
    if win.width == 0 or win.height == 0:
        return None
    from rasterio.windows import Window
    return Window(int(win.col_off), int(win.row_off), int(win.width), int(win.height))
