"""Module: classification — milestone scaffold (interfaces fixed, science not yet implemented).

Nothing in this package produces research results yet. Functions raise NotImplementedError with
the milestone that delivers them; see docs/methodology.md section 8 and docs/experiment_protocol.md.
"""

def train_level1(*_, **__):
    """Hierarchical L1 LULC with calibrated probabilities (M3: needs per-epoch reference samples)."""
    raise NotImplementedError("M3 - requires reference samples in data/labels/")
