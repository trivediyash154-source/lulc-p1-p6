"""Fixed analysis grids.

All grids derive from the study-area bounds plus a buffer and a declared lattice
(resolution + corner offset). Two grids with the same offset and resolutions that divide
each other nest exactly; G30 and G10 do NOT nest (verified 5 m lattice offset).
"""
from __future__ import annotations
import math
from dataclasses import dataclass, asdict
from affine import Affine
from rasterio.windows import Window, from_bounds
from . import config

@dataclass(frozen=True)
class Grid:
    id: str
    crs: str
    res: float
    x0: float          # west edge (pixel corner)
    y1: float          # north edge (pixel corner)
    width: int
    height: int
    corner_offset: float

    @property
    def transform(self) -> Affine:
        return Affine(self.res, 0.0, self.x0, 0.0, -self.res, self.y1)

    @property
    def bounds(self):
        return (self.x0, self.y1 - self.height * self.res, self.x0 + self.width * self.res, self.y1)

    @property
    def shape(self):
        return (self.height, self.width)

    def to_dict(self) -> dict:
        d = asdict(self); d["transform"] = list(self.transform)[:6]; d["bounds"] = list(self.bounds)
        return d

    def window(self, bounds) -> Window:
        """Pixel window covering `bounds`, snapped outward to whole pixels and clipped to grid."""
        w = from_bounds(*bounds, transform=self.transform)
        c0, r0 = max(0, math.floor(w.col_off)), max(0, math.floor(w.row_off))
        c1 = min(self.width, math.ceil(w.col_off + w.width))
        r1 = min(self.height, math.ceil(w.row_off + w.height))
        return Window(c0, r0, max(0, c1 - c0), max(0, r1 - r0))

    def subgrid(self, win: Window, suffix: str = "") -> "Grid":
        x0 = self.x0 + int(win.col_off) * self.res
        y1 = self.y1 - int(win.row_off) * self.res
        return Grid(self.id + suffix, self.crs, self.res, x0, y1, int(win.width), int(win.height), self.corner_offset)

    def refine(self, factor: int, gid: str) -> "Grid":
        """Same extent, finer resolution res/factor (nests exactly)."""
        r = self.res / factor
        return Grid(gid, self.crs, r, self.x0, self.y1, self.width * factor, self.height * factor, self.corner_offset)

    def on_lattice(self, x: float, y: float, res: float | None = None) -> bool:
        r = res or self.res
        return abs(((x - self.corner_offset) / r) - round((x - self.corner_offset) / r)) < 1e-6 and \
               abs(((y - self.corner_offset) / r) - round((y - self.corner_offset) / r)) < 1e-6

def build(grid_name: str, extent_bounds, crs: str | None = None) -> Grid:
    gcfg = config.load("grid")
    spec = gcfg["grids"][grid_name]
    res, off = float(spec["resolution"]), float(spec["corner_offset_m"])
    minx, miny, maxx, maxy = extent_bounds
    x0 = math.floor((minx - off) / res) * res + off
    y0 = math.floor((miny - off) / res) * res + off
    x1 = math.ceil((maxx - off) / res) * res + off
    y1 = math.ceil((maxy - off) / res) * res + off
    return Grid(f"pune_{grid_name}", crs or gcfg["crs"], res, x0, y1,
                int(round((x1 - x0) / res)), int(round((y1 - y0) / res)), off)

def district_grid(grid_name: str) -> Grid:
    """Grid covering the buffered study area (requires `pune-eo boundary` to have run)."""
    from .acquisition.boundary import processing_extent
    return build(grid_name, processing_extent())
