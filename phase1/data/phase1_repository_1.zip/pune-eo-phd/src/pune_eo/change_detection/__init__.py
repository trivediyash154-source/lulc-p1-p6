"""Module: change_detection — milestone scaffold (interfaces fixed, science not yet implemented).

Nothing in this package produces research results yet. Functions raise NotImplementedError with
the milestone that delivers them; see docs/methodology.md section 8 and docs/experiment_protocol.md.
"""

def annual_transitions(*_, **__):
    """Annual transition matrices, timing, persistence, velocity, hotspots (M4: needs annual LULC)."""
    raise NotImplementedError("M4 - requires annual LULC from classification")
