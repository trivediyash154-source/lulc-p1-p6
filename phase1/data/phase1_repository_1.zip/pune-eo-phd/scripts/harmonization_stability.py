"""Is the harmonisation stable across resolution (240 vs 30 m) and landscape (district / peri-urban / irrigated)?"""
import json
import matplotlib; matplotlib.use("Agg")
import matplotlib.pyplot as plt, numpy as np, pandas as pd
from pune_eo import config
from pune_eo.visualization import style, cartography as carto
R = config.path("results", "harmonization")
ctx = {"District, 240 m": R / "harmonization_report.json",
       "Khadakwasla-Mutha (peri-urban), 30 m": R / "harmonization_report_pune_G30_khadakwasla_mutha.json",
       "Baramati (canal-irrigated), 30 m": R / "harmonization_report_pune_G30_baramati_agri.json"}
rows = []
for c, p in ctx.items():
    r = json.loads(p.read_text())
    for k, v in r["pairs"].items():
        d = r["decisions"].get(k, {})
        rows.append({"context": c, "pair": k.replace("landsat-", "L"), "n_pixels": v.get("n_pixels"),
                     "ndvi_step_ref_minus_src": v.get("ndvi_mean_difference_ref_minus_src"),
                     "heldout_ndvi_absbias_none": d.get("held_out_ndvi_absbias_none"),
                     "heldout_ndvi_absbias_local": d.get("held_out_ndvi_absbias_local"),
                     "heldout_rmsd_reduction_pct": None if d.get("held_out_rmsd_reduction") is None else 100 * d["held_out_rmsd_reduction"],
                     "decision": "insufficient data" if v.get("n_pixels") is None else ("apply" if d.get("apply_local") else "identity")})
df = pd.DataFrame(rows); df.to_csv(R / "harmonization_stability.csv", index=False)
style.apply()
pairs = ["L5->L7", "L7->L8", "L9->L8"]; cs = list(ctx)
fig, ax = plt.subplots(figsize=(11, 4.8)); w = 0.26
for i, c in enumerate(cs):
    vals = [df[(df.context == c) & (df.pair == p)].ndvi_step_ref_minus_src.squeeze() if len(df[(df.context == c) & (df.pair == p)]) else np.nan for p in pairs]
    vals = [np.nan if v is None or (isinstance(v, float) and np.isnan(v)) else float(v) for v in vals]
    x = np.arange(3) + (i - 1) * w
    ax.bar(x, vals, w * 0.92, color=style.CAT[i], label=c)
    for xx, p, v in zip(x, pairs, vals):
        dd = df[(df.context == c) & (df.pair == p)]
        lab = dd.decision.squeeze() if len(dd) else "n/a"
        ax.text(xx, (0 if np.isnan(v) else max(v, 0)) + 0.0015, "n/a" if np.isnan(v) else lab, ha="center", fontsize=7.5, color=style.INK2, rotation=90 if np.isnan(v) else 0)
ax.axhline(0, color=style.MUTED, lw=0.8); ax.set_ylim(-0.004, 0.06); ax.set_xticks(range(3)); ax.set_xticklabels(pairs)
ax.set_ylabel("NDVI(reference) - NDVI(source)"); ax.legend(fontsize=8, loc="upper left")
ax.set_title("Unharmonised NDVI offset between sensors, by resolution and landscape (label = held-out decision)", loc="left")
fig.suptitle("Harmonisation stability test - is the correction transferable?", fontsize=12, fontweight="bold", x=0.01, ha="left")
carto.footer(fig, "Same-window dry-season median composites in real overlap years; decision rule: apply local RMA iff held-out band RMSD falls >=5% and |NDVI bias| worsens <=0.002. "
             "L7->L8 offset is robust (0.035-0.051); the L9->L8 correction fails the rule at 30 m in both windows -> provisional.")
fig.tight_layout(rect=[0, 0.05, 1, 0.93]); p = config.path("results", "figures", "harmonization_stability.png"); fig.savefig(p, dpi=130); plt.close(fig)
print(df.round(4).to_string(index=False)); print(p)
