"""One table listing every product in the cube: what, when, which sensors, QA status, files, checksums."""
import json
import pandas as pd
from pune_eo import config
rows = []
for m in sorted(config.path("data", "composites").glob("**/metadata.json")):
    d = json.loads(m.read_text())
    if "product_id" not in d: continue
    st = d.get("statistics", {}); t = d.get("temporal", {})
    rows.append({"product_id": d["product_id"], "family": m.relative_to(config.path("data", "composites")).parts[2], "grid": d["grid"]["id"],
                 "res_m": d["grid"]["res"], "year": t.get("year"), "period": t.get("period"), "complete": t.get("complete"),
                 "first_obs": t.get("first_observation"), "last_obs": t.get("last_observation"),
                 "sensors": ",".join(sorted(d.get("sensors", {}))), "n_scenes": st.get("n_items"),
                 "valid_pct": round(100 * st.get("district_valid_fraction", 0), 2),
                 "reliable_pct": round(100 * st.get("district_reliable_fraction_ge3", 0), 2),
                 "n_clear_median": st.get("n_clear_median"), "harmonization": d.get("processing", {}).get("harmonization"),
                 "qa_status": d.get("qa", {}).get("status", "not_run"), "processing_version": d.get("processing_version"),
                 "git_commit": d.get("code", {}).get("git_commit"), "files": len(d.get("files", {})),
                 "metadata": str(m.relative_to(config.ROOT))})
df = pd.DataFrame(rows).sort_values(["family", "grid", "year", "period"])
assert df.product_id.is_unique, "duplicate product_id in cube"
out = config.path("results", "cube_inventory"); out.mkdir(parents=True, exist_ok=True)
df.to_csv(out / "cube_inventory.csv", index=False); df.to_parquet(out / "cube_inventory.parquet", index=False)
print(df.groupby(["family", "grid"]).agg(products=("product_id", "size"), years=("year", "nunique"),
      first=("year", "min"), last=("year", "max")).to_string())
