"""Deliverable archives, each small enough to upload:
  core      code, configs, docs, manifests, boundary, every product's metadata, QA, inventory, climate, labels, git history
  figures   results/figures
  landsat   real Landsat GeoTIFF samples (district 240 m + 30 m window)
  sentinel  real Sentinel-1/2 GeoTIFF samples (district 240 m, monthly)
Intermediate harmonisation pixel pairs (results/harmonization/*.npz) are regenerable and excluded."""
import os, zipfile
from pathlib import Path
from pune_eo import config
R = config.ROOT; OUT = Path(os.environ.get("PKG_OUT", "/mnt/user-data/outputs")); OUT.mkdir(parents=True, exist_ok=True)
SKIP = {".git", "__pycache__", ".pytest_cache", "ard_cache", "pune_eo.egg-info", "locks", ".venv"}
def core_files():
    for p in R.rglob("*"):
        if p.is_dir() or any(s in p.parts for s in SKIP): continue
        rel = p.relative_to(R)
        if rel.parts[0] == "data" and rel.parts[1] in ("composites", "raw"):
            if p.name == "metadata.json" or p.name.endswith("_year_summary.json") or p.name == "event_report.json": yield rel
            continue
        if rel.parts[0] == "data" and rel.parts[1] == "boundary" and rel.parts[-1].startswith("geoBoundaries"): continue
        if rel.parts[0] == "results" and (rel.parts[1] == "figures" or p.suffix == ".npz"): continue
        yield rel
def zipdirs(name, dirs, extra=()):
    z = OUT / name
    with zipfile.ZipFile(z, "w", zipfile.ZIP_STORED) as zf:
        for d in dirs:
            for f in sorted(d.glob("*")): zf.write(f, Path("pune-eo-phd") / f.relative_to(R))
        for f in extra: zf.write(f, Path("pune-eo-phd") / f.relative_to(R))
    return z
outs = []
z = OUT / "pune-eo-phd_core.zip"
with zipfile.ZipFile(z, "w", zipfile.ZIP_DEFLATED, compresslevel=9) as zf:
    for rel in core_files(): zf.write(R / rel, Path("pune-eo-phd") / rel)
outs.append(z)
outs.append(zipdirs("pune-eo-phd_figures.zip", [R / "results" / "figures"]))
C = R / "data" / "composites"
outs.append(zipdirs("pune-eo-phd_samples_landsat_district240m.zip",
    [C / "pune_G240" / str(y) / "landsat" / "seasonal" / "dry" for y in (1990, 2005, 2025)],
    extra=list((R / "data" / "boundary").glob("study_area.*"))))
outs.append(zipdirs("pune-eo-phd_samples_landsat_corridor30m.zip",
    [C / "pune_G30_khadakwasla_mutha" / str(y) / "landsat" / "seasonal" / "dry" for y in (1990, 2026)]))
outs.append(zipdirs("pune-eo-phd_samples_sentinel.zip",
    [C / "pune_G240" / "2024" / "sentinel2" / "monthly" / f"2024-{m:02d}" for m in (4, 8)] +
    [C / "pune_G240" / "2024" / "sentinel1" / "monthly" / f"2024-{m:02d}" for m in (1, 8)]))
for z in outs: print(z.name, f"{z.stat().st_size/2**20:.1f} MiB")
