"""Fill README results from computed artefacts (never hand-typed numbers)."""
import json
import pandas as pd
from scipy.stats import spearmanr
from pune_eo import config
R = config.ROOT
q = pd.read_csv(R / "results/qa/landsat/pune_G240/qa_summary.csv")
inv = pd.read_csv(R / "results/cube_inventory/cube_inventory.csv")
bm = json.loads((R / "data/boundary/study_area.metadata.json").read_text())
hr = json.loads((R / "results/harmonization/harmonization_report.json").read_text())
stab = pd.read_csv(R / "results/harmonization/harmonization_stability.csv")
L = ["**Archive and frame**", ""]
L.append(f"- Study area: **{bm['area_km2_equal_area']:,} km²** (equal-area), version `{bm['version']}`, {bm['diff_vs_official_pct']:+.3f} % vs official; "
         f"GADM 4.1 cross-check IoU {bm['cross_checks']['GADM 4.1 IND level 2']['iou']:.3f}.")
for fam in ["landsat", "sentinel2", "sentinel1"]:
    m = json.loads((R / f"data/manifests/{fam}_manifest.summary.json").read_text())
    L.append(f"- {fam} manifest: {m['n_items']:,} scenes discovered, **{m['n_selected']:,} selected** ({m['first']} → {m['last']}; archive cut-off {m['archive_cutoff_utc'][:10]}).")
L += ["", "**Products built** (each with composite, uncertainty, observation count, valid mask, per-pixel QA, metadata and checksums):", ""]
inv["group"] = inv.family.where(~inv.family.str.startswith("landsat_cal"), "landsat calibration (per-sensor, unharmonised)")
g = inv.groupby(["group", "grid"]).agg(products=("product_id", "size"), years=("year", "nunique"), first=("year", "min"), last=("year", "max")).reset_index()
g["res_m"] = g.grid.map(lambda x: {"G240": 240, "G30": 30, "G10": 10}[x.split("_")[1]])
L.append(g[["group", "grid", "res_m", "products", "years", "first", "last"]].to_markdown(index=False))
L += ["", f"Total: **{len(inv):,} products**.", "", "**Landsat district cube (G240) — automated QA**", ""]
L.append(q.groupby(["period", "status"]).size().unstack(fill_value=0).to_markdown())
d = q[q.period == "dry"]; w = q[q.period == "wet"]
L += ["",
      f"- Dry season: share of district with ≥3 clear observations — median {d.reliable_pct.median():.0f} %, minimum {d.reliable_pct.min():.1f} % ({int(d.loc[d.reliable_pct.idxmin(),'year'])}).",
      f"- Monsoon: same metric median {w.reliable_pct.median():.1f} %; in {int((w.valid_pct < 50).sum())} of {len(w)} years under half the district had even one clear view.",
      f"- Permanent-water negative control (dry): at least {d.water_control.min():.1%} of JRC permanent-water cells read as water in every year.",
      f"- Residual-cloud check: flags the 1992 monsoon composite ({q.residual_cloud_pct.max():.1f} % of pixels haze-bright); no dry-season product affected.", ""]
s1 = pd.read_csv(R / "results/qa/sentinel1/pune_G240/qa_summary.csv"); s1m = s1[s1.period.str.match(r"\d{4}-\d{2}")]
L.append(f"**Sentinel-1 monthly QA (2015–2026):** {(s1m.status=='PASS').sum()} PASS, {(s1m.status=='WARNING').sum()} WARNING, "
         f"{(s1m.status=='FAIL').sum()} FAIL (real acquisition gaps), {(s1m.status=='IN_PROGRESS').sum()} in progress.")
s2q = R / "results/qa/sentinel2/pune_G240/qa_summary.csv"
if s2q.exists():
    s2 = pd.read_csv(s2q); s2m = s2[s2.period.str.match(r"\d{4}-\d{2}")]
    L.append(f"**Sentinel-2 monthly QA ({s2.year.min()}–{s2.year.max()}):** {(s2m.status=='PASS').sum()} PASS, {(s2m.status=='WARNING').sum()} WARNING, "
             f"{(s2m.status=='FAIL').sum()} FAIL (monsoon cloud), {(s2m.status=='IN_PROGRESS').sum()} in progress.")
L += ["", "**Sensor harmonisation (held-out years, district 240 m)**", "",
      "| pair | NDVI bias, none | NDVI bias, local fit | band RMSD change | decision |", "|---|---|---|---|---|"]
for k, v in hr["decisions"].items():
    L.append(f"| {k.replace('landsat-','L').replace('->','→')} | {v['held_out_ndvi_absbias_none']:.4f} | {v['held_out_ndvi_absbias_local']:.4f} | "
             f"−{100*v['held_out_rmsd_reduction']:.1f} % | {'apply' if v['apply_local'] else 'identity'} |")
l7 = stab[stab.pair == "L7->L8"].ndvi_step_ref_minus_src
L += ["", f"Stability at 30 m (peri-urban and irrigated windows): the L7→L8 NDVI offset is {l7.min():.3f}–{l7.max():.3f} in every context and its correction "
      "is always adopted; the L9→L8 correction is **not** reproduced at 30 m and is marked provisional.", ""]
c = pd.read_csv(R / "data/processed/climate/chirps_v2_monthly_pune.csv"); ok = c[c.status == "ok"]
full = ok.groupby("year").size() == 12; ann = ok.groupby("year").precip_mm_district_mean.sum()[full]
ser = pd.read_csv(R / "results/timeline/district_dry_season_series_pune_G240.csv"); m = (ser.support_pct >= 50) & ser.prev_monsoon_mm.notna()
rho, p = spearmanr(ser.prev_monsoon_mm[m], ser.water_km2[m])
L += [f"**Rainfall driver (CHIRPS v2.0, area-weighted district mean):** {len(ok)} months; annual mean {ann.mean():.0f} mm "
      f"(min {ann.min():.0f} mm in {ann.idxmin()}, max {ann.max():.0f} mm in {ann.idxmax()}).",
      "",
      f"**First exploratory coupling signal:** dry-season open water vs preceding-monsoon rainfall, Spearman ρ = {rho:.2f} (p < 0.001, n = {int(m.sum())} supported years). "
      "This is an association at 240 m. It is not a causal claim: reservoir operations are not yet in the data.",
      "",
      "**Reference sample design:** 1,345 stratified points (8 strata, ≥60 per stratum) with empty label columns for 5 epochs. KML file for Google Earth Pro: "
      "`data/labels/reference_sample_design_v1_seed20261001.kml`.",
      "",
      "Figures: `results/figures/INDEX.md`. QA reports: `results/qa/<family>/<grid>/QA_REPORT.md`. Product inventory: `results/cube_inventory/cube_inventory.csv`."]
pend = []
for f in sorted(config.path("data", "manifests", "jobs").glob("*.json")):
    if "cal_" in f.stem: continue
    jobs = json.loads(f.read_text()); done = {int(k.rsplit("/", 1)[1]) for k, v in jobs.items() if v["status"] == "done"}
    start = {"sentinel2": 2018, "sentinel1": 2015}.get(f.stem.split("_pune")[0], 1990)
    if "baramati" in f.stem: continue
    missing = [y for y in range(start, 2027) if y not in done]
    if missing: pend.append(f"- `{f.stem}`: years {', '.join(map(str, missing))} pending → `python -m pune_eo composite --family {f.stem.split('_pune')[0]} --grid G240 --years {missing[0]}-{missing[-1]}`")
L += ["", "**Pending jobs at packaging time** (resumable; finished years are skipped):", ""] + (pend or ["- none"])
t = (R / "README.template.md").read_text().replace("{{RESULTS}}", "\n".join(L))
(R / "README.md").write_text(t); print("README.md written")
