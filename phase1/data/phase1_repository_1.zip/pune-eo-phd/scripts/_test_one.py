import logging, sys, json, time
logging.basicConfig(level=logging.INFO, format="%(asctime)s %(message)s")
from pune_eo.grid import district_grid
from pune_eo.compositing.engine import run_year
g = district_grid(sys.argv[2]); print("grid", g.id, g.shape, g.res, g.x0, g.y1)
r = run_year(sys.argv[1], int(sys.argv[3]), g, threads=int(sys.argv[4]) if len(sys.argv) > 4 else 12, transform_name="none")
print(json.dumps(r, indent=1))
