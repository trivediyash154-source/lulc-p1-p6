"""Sentinel-era dense products: monthly + seasonal + annual for given years/grid/window."""
import argparse, json, logging, sys
logging.basicConfig(level=logging.INFO, format="%(asctime)s %(message)s", stream=sys.stdout)
for n in ("rasterio", "urllib3", "azure"): logging.getLogger(n).setLevel(logging.WARNING)
from pune_eo.compositing.engine import run_year
from pune_eo.compositing.windows import resolve
ap = argparse.ArgumentParser()
ap.add_argument("family", choices=["sentinel2", "sentinel1"]); ap.add_argument("--grid", default="G240")
ap.add_argument("--window", default="district"); ap.add_argument("--years", default="2024")
ap.add_argument("--threads", type=int, default=12)
a = ap.parse_args()
g, win, wname = resolve(a.grid, a.window)
y0, _, y1 = a.years.partition("-"); years = range(int(y0), int(y1 or y0) + 1)
for y in years:
    r = run_year(a.family, y, g, window=win, window_name=wname, threads=a.threads)
    print(json.dumps({k: r.get(k) for k in ("job_id", "status", "seconds", "n_items", "n_failed")}), flush=True)
