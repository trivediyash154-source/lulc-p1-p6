"""Build all acquisition manifests (Landsat 1984-, Sentinel-2 2015-, Sentinel-1 2014-)."""
import json, logging, sys, time
from pune_eo.acquisition import manifest as M
logging.basicConfig(level=logging.INFO, format="%(asctime)s %(levelname)s %(message)s", stream=sys.stdout)
which = sys.argv[1:] or ["landsat", "sentinel2", "sentinel1"]
for name in which:
    t = time.time()
    gdf = {"landsat": M.discover_landsat, "sentinel2": M.discover_sentinel2, "sentinel1": M.discover_sentinel1}[name]()
    s = M.write_manifest(gdf, name)
    print(f"== {name}: {s['n_items']} items, {s['n_selected']} selected, {s['first']}..{s['last']} ({time.time()-t:.0f}s)")
    print(json.dumps(s["by_platform"]), flush=True)
