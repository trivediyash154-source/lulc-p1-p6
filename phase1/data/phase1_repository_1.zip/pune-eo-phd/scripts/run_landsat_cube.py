"""Landsat annual + seasonal cube for every year. Resumable: completed years are skipped."""
import argparse, json, logging, sys
logging.basicConfig(level=logging.INFO, format="%(asctime)s %(message)s", stream=sys.stdout)
for n in ("rasterio", "urllib3", "azure"): logging.getLogger(n).setLevel(logging.WARNING)
from pune_eo.compositing.engine import run_year
from pune_eo.compositing.windows import resolve
ap = argparse.ArgumentParser(); ap.add_argument("--grid", default="G240"); ap.add_argument("--window", default="district")
ap.add_argument("--years", default="1990-2026"); ap.add_argument("--threads", type=int, default=12)
a = ap.parse_args()
g, win, wname = resolve(a.grid, a.window)
y0, _, y1 = a.years.partition("-")
for y in range(int(y0), int(y1 or y0) + 1):
    try:
        r = run_year("landsat", y, g, window=win, window_name=wname, threads=a.threads)
        print(json.dumps({k: r.get(k) for k in ("job_id", "status", "seconds", "n_items", "n_failed")}), flush=True)
    except Exception as e:   # one failed year never stops the others; ledger records it
        print(json.dumps({"year": y, "status": "failed", "error": repr(e)}), flush=True)
