"""Per-sensor, UNharmonised dry-season composites in sensor-overlap years (input to `pune-eo harmonize`).
Usage: run_calibration.py <GRID> [<window name>|district]"""
import logging, sys, json
logging.basicConfig(level=logging.INFO, format="%(asctime)s %(message)s", stream=sys.stdout)
for n in ("rasterio", "urllib3", "azure"): logging.getLogger(n).setLevel(logging.WARNING)
from pune_eo import config
from pune_eo.compositing.engine import run_year
from pune_eo.compositing.periods import standard_periods
from pune_eo.compositing.windows import resolve
grid, win, wname = resolve(sys.argv[1] if len(sys.argv) > 1 else "G240", sys.argv[2] if len(sys.argv) > 2 else "district")
for pair in config.load("landsat")["harmonization"]["calibration_pairs"]:
    for y in pair["years"]:
        dry = [p for p in standard_periods(y) if p.name == pair["period"]]
        for plat in (pair["src"], pair["ref"]):
            r = run_year("landsat", y, grid, window=win, window_name=wname, periods=dry, platforms=[plat],
                         transform_name="none", out_family=f"landsat_cal_{plat}", threads=8)
            print(json.dumps({k: r.get(k) for k in ("job_id", "status", "seconds", "n_items", "n_failed")}), flush=True)
