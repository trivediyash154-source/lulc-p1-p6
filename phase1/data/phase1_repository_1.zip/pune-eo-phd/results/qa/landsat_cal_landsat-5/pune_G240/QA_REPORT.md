# Pune EO Data QA Report — landsat_cal_landsat-5 — grid `pune_G240`

Generated automatically by `pune-eo qa`. Thresholds: `configs/qa.yaml`. Every product's full QA record is
also written into its own `metadata.json` (`qa` block).

## Summary

| period   |   FAIL |   WARNING |
|:---------|-------:|----------:|
| dry      |      2 |         2 |

## Per-year records

### 2000

**dry** — Status: **WARNING**
- Sensors: landsat-5 · scenes: 9
- Valid district coverage: 100.0% · reliable (≥3 clear obs): 20.6%
- Median clear observations per pixel: 2 · mean clear fraction of observations: 92.4%
- Permanent-water negative control (share of JRC permanent-water cells with MNDWI>0): 100%
- Residual-cloud check (valid pixels with blue SR > 0.15): 0.0%
- Reasons: median clear observations 2 < 3 (composite statistically weak)

### 2001

**dry** — Status: **WARNING**
- Sensors: landsat-5 · scenes: 9
- Valid district coverage: 100.0% · reliable (≥3 clear obs): 16.2%
- Median clear observations per pixel: 2 · mean clear fraction of observations: 99.5%
- Permanent-water negative control (share of JRC permanent-water cells with MNDWI>0): 95%
- Residual-cloud check (valid pixels with blue SR > 0.15): 0.0%
- Reasons: median clear observations 2 < 3 (composite statistically weak)

### 2002

**dry** — Status: **FAIL**
- Sensors: — · scenes: 0
- Valid district coverage: 0.0% · reliable (≥3 clear obs): 0.0%
- Median clear observations per pixel: 0 · mean clear fraction of observations: 0.0%
- Permanent-water negative control (share of JRC permanent-water cells with MNDWI>0): n/a
- Residual-cloud check (valid pixels with blue SR > 0.15): n/a
- Reasons: district valid coverage 0.0% < 50% | median clear observations 0 < 3 (composite statistically weak)

### 2003

**dry** — Status: **FAIL**
- Sensors: — · scenes: 0
- Valid district coverage: 0.0% · reliable (≥3 clear obs): 0.0%
- Median clear observations per pixel: 0 · mean clear fraction of observations: 0.0%
- Permanent-water negative control (share of JRC permanent-water cells with MNDWI>0): n/a
- Residual-cloud check (valid pixels with blue SR > 0.15): n/a
- Reasons: district valid coverage 0.0% < 50% | median clear observations 0 < 3 (composite statistically weak)
