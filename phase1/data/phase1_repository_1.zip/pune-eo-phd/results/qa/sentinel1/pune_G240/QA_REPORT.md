# Pune EO Data QA Report — sentinel1 — grid `pune_G240`

Generated automatically by `pune-eo qa`. Thresholds: `configs/qa.yaml`. Every product's full QA record is
also written into its own `metadata.json` (`qa` block).

## Summary

| period       |   FAIL |   IN_PROGRESS |   PASS |   WARNING |
|:-------------|-------:|--------------:|-------:|----------:|
| 2015-01      |      1 |             0 |      0 |         0 |
| 2015-02      |      0 |             0 |      0 |         1 |
| 2015-03      |      1 |             0 |      0 |         0 |
| 2015-04      |      1 |             0 |      0 |         0 |
| 2015-05      |      1 |             0 |      0 |         0 |
| 2015-06      |      1 |             0 |      0 |         0 |
| 2015-07      |      1 |             0 |      0 |         0 |
| 2015-08      |      1 |             0 |      0 |         0 |
| 2015-09      |      1 |             0 |      0 |         0 |
| 2015-10      |      1 |             0 |      0 |         0 |
| 2015-11      |      1 |             0 |      0 |         0 |
| 2015-12      |      1 |             0 |      0 |         0 |
| 2016-01      |      1 |             0 |      0 |         0 |
| 2016-02      |      1 |             0 |      0 |         0 |
| 2016-03      |      0 |             0 |      0 |         1 |
| 2016-04      |      1 |             0 |      0 |         0 |
| 2016-05      |      1 |             0 |      0 |         0 |
| 2016-06      |      1 |             0 |      0 |         0 |
| 2016-07      |      1 |             0 |      0 |         0 |
| 2016-08      |      1 |             0 |      0 |         0 |
| 2016-09      |      1 |             0 |      0 |         0 |
| 2016-10      |      0 |             0 |      1 |         0 |
| 2016-11      |      0 |             0 |      0 |         1 |
| 2016-12      |      0 |             0 |      1 |         0 |
| 2017-01      |      0 |             0 |      1 |         0 |
| 2017-02      |      0 |             0 |      1 |         0 |
| 2017-03      |      0 |             0 |      1 |         0 |
| 2017-04      |      0 |             0 |      1 |         0 |
| 2017-05      |      0 |             0 |      1 |         0 |
| 2017-06      |      0 |             0 |      1 |         0 |
| 2017-07      |      0 |             0 |      1 |         0 |
| 2017-08      |      0 |             0 |      1 |         0 |
| 2017-09      |      0 |             0 |      1 |         0 |
| 2017-10      |      0 |             0 |      0 |         1 |
| 2017-11      |      0 |             0 |      0 |         1 |
| 2017-12      |      0 |             0 |      0 |         1 |
| 2018-01      |      0 |             0 |      1 |         0 |
| 2018-02      |      0 |             0 |      1 |         0 |
| 2018-03      |      0 |             0 |      0 |         1 |
| 2018-04      |      0 |             0 |      0 |         1 |
| 2018-05      |      0 |             0 |      1 |         0 |
| 2018-06      |      0 |             0 |      1 |         0 |
| 2018-07      |      0 |             0 |      1 |         0 |
| 2018-08      |      0 |             0 |      1 |         0 |
| 2018-09      |      0 |             0 |      1 |         0 |
| 2018-10      |      0 |             0 |      1 |         0 |
| 2018-11      |      0 |             0 |      1 |         0 |
| 2018-12      |      0 |             0 |      1 |         0 |
| 2019-01      |      0 |             0 |      1 |         0 |
| 2019-02      |      0 |             0 |      0 |         1 |
| 2019-03      |      0 |             0 |      1 |         0 |
| 2019-04      |      0 |             0 |      0 |         1 |
| 2019-05      |      1 |             0 |      0 |         0 |
| 2019-06      |      0 |             0 |      0 |         1 |
| 2019-07      |      1 |             0 |      0 |         0 |
| 2019-08      |      0 |             0 |      1 |         0 |
| 2019-09      |      0 |             0 |      1 |         0 |
| 2019-10      |      0 |             0 |      1 |         0 |
| 2019-11      |      0 |             0 |      1 |         0 |
| 2019-12      |      0 |             0 |      1 |         0 |
| 2020-01      |      0 |             0 |      1 |         0 |
| 2020-02      |      0 |             0 |      1 |         0 |
| 2020-03      |      0 |             0 |      1 |         0 |
| 2020-04      |      0 |             0 |      1 |         0 |
| 2020-05      |      0 |             0 |      1 |         0 |
| 2020-06      |      0 |             0 |      1 |         0 |
| 2020-07      |      0 |             0 |      1 |         0 |
| 2020-08      |      0 |             0 |      1 |         0 |
| 2020-09      |      0 |             0 |      1 |         0 |
| 2020-10      |      0 |             0 |      1 |         0 |
| 2020-11      |      0 |             0 |      1 |         0 |
| 2020-12      |      0 |             0 |      1 |         0 |
| 2021-01      |      0 |             0 |      1 |         0 |
| 2021-02      |      0 |             0 |      1 |         0 |
| 2021-03      |      0 |             0 |      1 |         0 |
| 2021-04      |      0 |             0 |      1 |         0 |
| 2021-05      |      0 |             0 |      1 |         0 |
| 2021-06      |      0 |             0 |      1 |         0 |
| 2021-07      |      0 |             0 |      1 |         0 |
| 2021-08      |      0 |             0 |      1 |         0 |
| 2021-09      |      0 |             0 |      1 |         0 |
| 2021-10      |      0 |             0 |      1 |         0 |
| 2021-11      |      0 |             0 |      1 |         0 |
| 2021-12      |      0 |             0 |      1 |         0 |
| 2022-01      |      0 |             0 |      1 |         0 |
| 2022-02      |      0 |             0 |      1 |         0 |
| 2022-03      |      0 |             0 |      1 |         0 |
| 2022-04      |      0 |             0 |      0 |         1 |
| 2022-05      |      0 |             0 |      1 |         0 |
| 2022-06      |      0 |             0 |      1 |         0 |
| 2022-07      |      0 |             0 |      1 |         0 |
| 2022-08      |      0 |             0 |      0 |         1 |
| 2022-09      |      1 |             0 |      0 |         0 |
| 2022-10      |      1 |             0 |      0 |         0 |
| 2022-11      |      0 |             0 |      0 |         1 |
| 2022-12      |      0 |             0 |      0 |         1 |
| 2023-01      |      0 |             0 |      1 |         0 |
| 2023-02      |      0 |             0 |      0 |         1 |
| 2023-03      |      0 |             0 |      0 |         1 |
| 2023-04      |      0 |             0 |      0 |         1 |
| 2023-05      |      0 |             0 |      1 |         0 |
| 2023-06      |      0 |             0 |      1 |         0 |
| 2023-07      |      0 |             0 |      0 |         1 |
| 2023-08      |      0 |             0 |      1 |         0 |
| 2023-09      |      0 |             0 |      0 |         1 |
| 2023-10      |      0 |             0 |      0 |         1 |
| 2023-11      |      0 |             0 |      0 |         1 |
| 2023-12      |      0 |             0 |      1 |         0 |
| 2024-01      |      0 |             0 |      1 |         0 |
| 2024-02      |      0 |             0 |      0 |         1 |
| 2024-03      |      0 |             0 |      0 |         1 |
| 2024-04      |      0 |             0 |      1 |         0 |
| 2024-05      |      0 |             0 |      1 |         0 |
| 2024-06      |      1 |             0 |      0 |         0 |
| 2024-07      |      1 |             0 |      0 |         0 |
| 2024-08      |      0 |             0 |      0 |         1 |
| 2024-09      |      0 |             0 |      0 |         1 |
| 2024-10      |      0 |             0 |      1 |         0 |
| 2024-11      |      0 |             0 |      1 |         0 |
| 2024-12      |      0 |             0 |      1 |         0 |
| 2025-01      |      0 |             0 |      1 |         0 |
| 2025-02      |      0 |             0 |      1 |         0 |
| 2025-03      |      0 |             0 |      1 |         0 |
| 2025-04      |      0 |             0 |      1 |         0 |
| 2025-05      |      0 |             0 |      1 |         0 |
| 2025-06      |      0 |             0 |      1 |         0 |
| 2025-07      |      0 |             0 |      1 |         0 |
| 2025-08      |      0 |             0 |      1 |         0 |
| 2025-09      |      0 |             0 |      1 |         0 |
| 2025-10      |      0 |             0 |      1 |         0 |
| 2025-11      |      0 |             0 |      1 |         0 |
| 2025-12      |      0 |             0 |      1 |         0 |
| 2026-01      |      0 |             0 |      1 |         0 |
| 2026-02      |      0 |             0 |      1 |         0 |
| 2026-03      |      0 |             0 |      1 |         0 |
| 2026-04      |      0 |             0 |      1 |         0 |
| 2026-05      |      0 |             0 |      1 |         0 |
| 2026-06      |      0 |             0 |      1 |         0 |
| 2026-07      |      0 |             0 |      1 |         0 |
| 2026-08      |      0 |             0 |      1 |         0 |
| 2026-09      |      0 |             0 |      1 |         0 |
| 2026-10      |      0 |             1 |      0 |         0 |
| 2026-11      |      0 |             1 |      0 |         0 |
| 2026-12      |      0 |             1 |      0 |         0 |
| annual       |      0 |             0 |     10 |         2 |
| dry          |      0 |             0 |     10 |         2 |
| post_monsoon |      1 |             1 |     10 |         0 |
| wet          |      2 |             0 |     10 |         0 |

## Per-year records

### 2015

**2015-01** — Status: **FAIL**
- Sensors: — · scenes: 0
- Valid district coverage: 0.0% · reliable (≥3 clear obs): 0.0%
- Median clear observations per pixel: 0 · mean clear fraction of observations: 0.0%
- Permanent-water negative control (share of JRC permanent-water cells with MNDWI>0): n/a
- Residual-cloud check (valid pixels with blue SR > 0.15): n/a
- Reasons: district valid coverage 0.0% < 50% | median clear observations 0 < 2 (composite statistically weak)

**2015-02** — Status: **WARNING**
- Sensors: sentinel-1a · scenes: 2
- Valid district coverage: 100.0% · reliable (≥3 clear obs): 0.0%
- Median clear observations per pixel: 1 · mean clear fraction of observations: 100.0%
- Permanent-water negative control (share of JRC permanent-water cells with MNDWI>0): n/a
- Residual-cloud check (valid pixels with blue SR > 0.15): n/a
- Reasons: median clear observations 1 < 2 (composite statistically weak) | 100% of district from a single observation

**2015-03** — Status: **FAIL**
- Sensors: sentinel-1a · scenes: 2
- Valid district coverage: 18.5% · reliable (≥3 clear obs): 0.0%
- Median clear observations per pixel: 0 · mean clear fraction of observations: 100.0%
- Permanent-water negative control (share of JRC permanent-water cells with MNDWI>0): n/a
- Residual-cloud check (valid pixels with blue SR > 0.15): n/a
- Reasons: district valid coverage 18.5% < 50% | median clear observations 0 < 2 (composite statistically weak)

**2015-04** — Status: **FAIL**
- Sensors: — · scenes: 0
- Valid district coverage: 0.0% · reliable (≥3 clear obs): 0.0%
- Median clear observations per pixel: 0 · mean clear fraction of observations: 0.0%
- Permanent-water negative control (share of JRC permanent-water cells with MNDWI>0): n/a
- Residual-cloud check (valid pixels with blue SR > 0.15): n/a
- Reasons: district valid coverage 0.0% < 50% | median clear observations 0 < 2 (composite statistically weak)

**2015-05** — Status: **FAIL**
- Sensors: — · scenes: 0
- Valid district coverage: 0.0% · reliable (≥3 clear obs): 0.0%
- Median clear observations per pixel: 0 · mean clear fraction of observations: 0.0%
- Permanent-water negative control (share of JRC permanent-water cells with MNDWI>0): n/a
- Residual-cloud check (valid pixels with blue SR > 0.15): n/a
- Reasons: district valid coverage 0.0% < 50% | median clear observations 0 < 2 (composite statistically weak)

**2015-06** — Status: **FAIL**
- Sensors: — · scenes: 0
- Valid district coverage: 0.0% · reliable (≥3 clear obs): 0.0%
- Median clear observations per pixel: 0 · mean clear fraction of observations: 0.0%
- Permanent-water negative control (share of JRC permanent-water cells with MNDWI>0): n/a
- Residual-cloud check (valid pixels with blue SR > 0.15): n/a
- Reasons: district valid coverage 0.0% < 50% | median clear observations 0 < 2 (composite statistically weak)

**2015-07** — Status: **FAIL**
- Sensors: — · scenes: 0
- Valid district coverage: 0.0% · reliable (≥3 clear obs): 0.0%
- Median clear observations per pixel: 0 · mean clear fraction of observations: 0.0%
- Permanent-water negative control (share of JRC permanent-water cells with MNDWI>0): n/a
- Residual-cloud check (valid pixels with blue SR > 0.15): n/a
- Reasons: district valid coverage 0.0% < 50% | median clear observations 0 < 2 (composite statistically weak)

**2015-08** — Status: **FAIL**
- Sensors: — · scenes: 0
- Valid district coverage: 0.0% · reliable (≥3 clear obs): 0.0%
- Median clear observations per pixel: 0 · mean clear fraction of observations: 0.0%
- Permanent-water negative control (share of JRC permanent-water cells with MNDWI>0): n/a
- Residual-cloud check (valid pixels with blue SR > 0.15): n/a
- Reasons: district valid coverage 0.0% < 50% | median clear observations 0 < 2 (composite statistically weak)

**2015-09** — Status: **FAIL**
- Sensors: — · scenes: 0
- Valid district coverage: 0.0% · reliable (≥3 clear obs): 0.0%
- Median clear observations per pixel: 0 · mean clear fraction of observations: 0.0%
- Permanent-water negative control (share of JRC permanent-water cells with MNDWI>0): n/a
- Residual-cloud check (valid pixels with blue SR > 0.15): n/a
- Reasons: district valid coverage 0.0% < 50% | median clear observations 0 < 2 (composite statistically weak)

**2015-10** — Status: **FAIL**
- Sensors: — · scenes: 0
- Valid district coverage: 0.0% · reliable (≥3 clear obs): 0.0%
- Median clear observations per pixel: 0 · mean clear fraction of observations: 0.0%
- Permanent-water negative control (share of JRC permanent-water cells with MNDWI>0): n/a
- Residual-cloud check (valid pixels with blue SR > 0.15): n/a
- Reasons: district valid coverage 0.0% < 50% | median clear observations 0 < 2 (composite statistically weak)

**2015-11** — Status: **FAIL**
- Sensors: — · scenes: 0
- Valid district coverage: 0.0% · reliable (≥3 clear obs): 0.0%
- Median clear observations per pixel: 0 · mean clear fraction of observations: 0.0%
- Permanent-water negative control (share of JRC permanent-water cells with MNDWI>0): n/a
- Residual-cloud check (valid pixels with blue SR > 0.15): n/a
- Reasons: district valid coverage 0.0% < 50% | median clear observations 0 < 2 (composite statistically weak)

**2015-12** — Status: **FAIL**
- Sensors: — · scenes: 0
- Valid district coverage: 0.0% · reliable (≥3 clear obs): 0.0%
- Median clear observations per pixel: 0 · mean clear fraction of observations: 0.0%
- Permanent-water negative control (share of JRC permanent-water cells with MNDWI>0): n/a
- Residual-cloud check (valid pixels with blue SR > 0.15): n/a
- Reasons: district valid coverage 0.0% < 50% | median clear observations 0 < 2 (composite statistically weak)

**annual** — Status: **WARNING**
- Sensors: sentinel-1a · scenes: 4
- Valid district coverage: 100.0% · reliable (≥3 clear obs): 0.1%
- Median clear observations per pixel: 1 · mean clear fraction of observations: 100.0%
- Permanent-water negative control (share of JRC permanent-water cells with MNDWI>0): n/a
- Residual-cloud check (valid pixels with blue SR > 0.15): n/a
- Reasons: median clear observations 1 < 2 (composite statistically weak) | 81% of district from a single observation

**dry** — Status: **WARNING**
- Sensors: sentinel-1a · scenes: 4
- Valid district coverage: 100.0% · reliable (≥3 clear obs): 0.1%
- Median clear observations per pixel: 1 · mean clear fraction of observations: 100.0%
- Permanent-water negative control (share of JRC permanent-water cells with MNDWI>0): n/a
- Residual-cloud check (valid pixels with blue SR > 0.15): n/a
- Reasons: median clear observations 1 < 2 (composite statistically weak) | 81% of district from a single observation

**post_monsoon** — Status: **FAIL**
- Sensors: — · scenes: 0
- Valid district coverage: 0.0% · reliable (≥3 clear obs): 0.0%
- Median clear observations per pixel: 0 · mean clear fraction of observations: 0.0%
- Permanent-water negative control (share of JRC permanent-water cells with MNDWI>0): n/a
- Residual-cloud check (valid pixels with blue SR > 0.15): n/a
- Reasons: district valid coverage 0.0% < 50% | median clear observations 0 < 2 (composite statistically weak)

**wet** — Status: **FAIL**
- Sensors: — · scenes: 0
- Valid district coverage: 0.0% · reliable (≥3 clear obs): 0.0%
- Median clear observations per pixel: 0 · mean clear fraction of observations: 0.0%
- Permanent-water negative control (share of JRC permanent-water cells with MNDWI>0): n/a
- Residual-cloud check (valid pixels with blue SR > 0.15): n/a
- Reasons: district valid coverage 0.0% < 50% | median clear observations 0 < 2 (composite statistically weak)

### 2016

**2016-01** — Status: **FAIL**
- Sensors: — · scenes: 0
- Valid district coverage: 0.0% · reliable (≥3 clear obs): 0.0%
- Median clear observations per pixel: 0 · mean clear fraction of observations: 0.0%
- Permanent-water negative control (share of JRC permanent-water cells with MNDWI>0): n/a
- Residual-cloud check (valid pixels with blue SR > 0.15): n/a
- Reasons: district valid coverage 0.0% < 50% | median clear observations 0 < 2 (composite statistically weak)

**2016-02** — Status: **FAIL**
- Sensors: sentinel-1a · scenes: 1
- Valid district coverage: 17.8% · reliable (≥3 clear obs): 0.0%
- Median clear observations per pixel: 0 · mean clear fraction of observations: 100.0%
- Permanent-water negative control (share of JRC permanent-water cells with MNDWI>0): n/a
- Residual-cloud check (valid pixels with blue SR > 0.15): n/a
- Reasons: district valid coverage 17.8% < 50% | median clear observations 0 < 2 (composite statistically weak)

**2016-03** — Status: **WARNING**
- Sensors: sentinel-1a · scenes: 2
- Valid district coverage: 100.0% · reliable (≥3 clear obs): 0.0%
- Median clear observations per pixel: 1 · mean clear fraction of observations: 100.0%
- Permanent-water negative control (share of JRC permanent-water cells with MNDWI>0): n/a
- Residual-cloud check (valid pixels with blue SR > 0.15): n/a
- Reasons: median clear observations 1 < 2 (composite statistically weak) | 100% of district from a single observation

**2016-04** — Status: **FAIL**
- Sensors: — · scenes: 0
- Valid district coverage: 0.0% · reliable (≥3 clear obs): 0.0%
- Median clear observations per pixel: 0 · mean clear fraction of observations: 0.0%
- Permanent-water negative control (share of JRC permanent-water cells with MNDWI>0): n/a
- Residual-cloud check (valid pixels with blue SR > 0.15): n/a
- Reasons: district valid coverage 0.0% < 50% | median clear observations 0 < 2 (composite statistically weak)

**2016-05** — Status: **FAIL**
- Sensors: — · scenes: 0
- Valid district coverage: 0.0% · reliable (≥3 clear obs): 0.0%
- Median clear observations per pixel: 0 · mean clear fraction of observations: 0.0%
- Permanent-water negative control (share of JRC permanent-water cells with MNDWI>0): n/a
- Residual-cloud check (valid pixels with blue SR > 0.15): n/a
- Reasons: district valid coverage 0.0% < 50% | median clear observations 0 < 2 (composite statistically weak)

**2016-06** — Status: **FAIL**
- Sensors: — · scenes: 0
- Valid district coverage: 0.0% · reliable (≥3 clear obs): 0.0%
- Median clear observations per pixel: 0 · mean clear fraction of observations: 0.0%
- Permanent-water negative control (share of JRC permanent-water cells with MNDWI>0): n/a
- Residual-cloud check (valid pixels with blue SR > 0.15): n/a
- Reasons: district valid coverage 0.0% < 50% | median clear observations 0 < 2 (composite statistically weak)

**2016-07** — Status: **FAIL**
- Sensors: — · scenes: 0
- Valid district coverage: 0.0% · reliable (≥3 clear obs): 0.0%
- Median clear observations per pixel: 0 · mean clear fraction of observations: 0.0%
- Permanent-water negative control (share of JRC permanent-water cells with MNDWI>0): n/a
- Residual-cloud check (valid pixels with blue SR > 0.15): n/a
- Reasons: district valid coverage 0.0% < 50% | median clear observations 0 < 2 (composite statistically weak)

**2016-08** — Status: **FAIL**
- Sensors: — · scenes: 0
- Valid district coverage: 0.0% · reliable (≥3 clear obs): 0.0%
- Median clear observations per pixel: 0 · mean clear fraction of observations: 0.0%
- Permanent-water negative control (share of JRC permanent-water cells with MNDWI>0): n/a
- Residual-cloud check (valid pixels with blue SR > 0.15): n/a
- Reasons: district valid coverage 0.0% < 50% | median clear observations 0 < 2 (composite statistically weak)

**2016-09** — Status: **FAIL**
- Sensors: sentinel-1a · scenes: 1
- Valid district coverage: 18.4% · reliable (≥3 clear obs): 0.0%
- Median clear observations per pixel: 0 · mean clear fraction of observations: 100.0%
- Permanent-water negative control (share of JRC permanent-water cells with MNDWI>0): n/a
- Residual-cloud check (valid pixels with blue SR > 0.15): n/a
- Reasons: district valid coverage 18.4% < 50% | median clear observations 0 < 2 (composite statistically weak)

**2016-10** — Status: **PASS**
- Sensors: sentinel-1a · scenes: 8
- Valid district coverage: 100.0% · reliable (≥3 clear obs): 100.0%
- Median clear observations per pixel: 3 · mean clear fraction of observations: 100.0%
- Permanent-water negative control (share of JRC permanent-water cells with MNDWI>0): n/a
- Residual-cloud check (valid pixels with blue SR > 0.15): n/a
- Reasons: none

**2016-11** — Status: **WARNING**
- Sensors: sentinel-1a · scenes: 5
- Valid district coverage: 100.0% · reliable (≥3 clear obs): 18.5%
- Median clear observations per pixel: 1 · mean clear fraction of observations: 100.0%
- Permanent-water negative control (share of JRC permanent-water cells with MNDWI>0): n/a
- Residual-cloud check (valid pixels with blue SR > 0.15): n/a
- Reasons: median clear observations 1 < 2 (composite statistically weak) | 81% of district from a single observation

**2016-12** — Status: **PASS**
- Sensors: sentinel-1a · scenes: 8
- Valid district coverage: 100.0% · reliable (≥3 clear obs): 100.0%
- Median clear observations per pixel: 3 · mean clear fraction of observations: 100.0%
- Permanent-water negative control (share of JRC permanent-water cells with MNDWI>0): n/a
- Residual-cloud check (valid pixels with blue SR > 0.15): n/a
- Reasons: none

**annual** — Status: **PASS**
- Sensors: sentinel-1a · scenes: 25
- Valid district coverage: 100.0% · reliable (≥3 clear obs): 100.0%
- Median clear observations per pixel: 8 · mean clear fraction of observations: 100.0%
- Permanent-water negative control (share of JRC permanent-water cells with MNDWI>0): n/a
- Residual-cloud check (valid pixels with blue SR > 0.15): n/a
- Reasons: none

**dry** — Status: **WARNING**
- Sensors: sentinel-1a · scenes: 3
- Valid district coverage: 100.0% · reliable (≥3 clear obs): 0.1%
- Median clear observations per pixel: 1 · mean clear fraction of observations: 100.0%
- Permanent-water negative control (share of JRC permanent-water cells with MNDWI>0): n/a
- Residual-cloud check (valid pixels with blue SR > 0.15): n/a
- Reasons: median clear observations 1 < 2 (composite statistically weak) | 82% of district from a single observation

**post_monsoon** — Status: **PASS**
- Sensors: sentinel-1a · scenes: 21
- Valid district coverage: 100.0% · reliable (≥3 clear obs): 100.0%
- Median clear observations per pixel: 7 · mean clear fraction of observations: 100.0%
- Permanent-water negative control (share of JRC permanent-water cells with MNDWI>0): n/a
- Residual-cloud check (valid pixels with blue SR > 0.15): n/a
- Reasons: none

**wet** — Status: **FAIL**
- Sensors: sentinel-1a · scenes: 1
- Valid district coverage: 18.4% · reliable (≥3 clear obs): 0.0%
- Median clear observations per pixel: 0 · mean clear fraction of observations: 100.0%
- Permanent-water negative control (share of JRC permanent-water cells with MNDWI>0): n/a
- Residual-cloud check (valid pixels with blue SR > 0.15): n/a
- Reasons: district valid coverage 18.4% < 50% | median clear observations 0 < 2 (composite statistically weak)

### 2017

**2017-01** — Status: **PASS**
- Sensors: sentinel-1a · scenes: 7
- Valid district coverage: 100.0% · reliable (≥3 clear obs): 18.6%
- Median clear observations per pixel: 2 · mean clear fraction of observations: 100.0%
- Permanent-water negative control (share of JRC permanent-water cells with MNDWI>0): n/a
- Residual-cloud check (valid pixels with blue SR > 0.15): n/a
- Reasons: none

**2017-02** — Status: **PASS**
- Sensors: sentinel-1a · scenes: 7
- Valid district coverage: 100.0% · reliable (≥3 clear obs): 18.6%
- Median clear observations per pixel: 2 · mean clear fraction of observations: 100.0%
- Permanent-water negative control (share of JRC permanent-water cells with MNDWI>0): n/a
- Residual-cloud check (valid pixels with blue SR > 0.15): n/a
- Reasons: none

**2017-03** — Status: **PASS**
- Sensors: sentinel-1a · scenes: 10
- Valid district coverage: 100.0% · reliable (≥3 clear obs): 18.6%
- Median clear observations per pixel: 2 · mean clear fraction of observations: 100.0%
- Permanent-water negative control (share of JRC permanent-water cells with MNDWI>0): n/a
- Residual-cloud check (valid pixels with blue SR > 0.15): n/a
- Reasons: none

**2017-04** — Status: **PASS**
- Sensors: sentinel-1a · scenes: 9
- Valid district coverage: 100.0% · reliable (≥3 clear obs): 100.0%
- Median clear observations per pixel: 3 · mean clear fraction of observations: 100.0%
- Permanent-water negative control (share of JRC permanent-water cells with MNDWI>0): n/a
- Residual-cloud check (valid pixels with blue SR > 0.15): n/a
- Reasons: none

**2017-05** — Status: **PASS**
- Sensors: sentinel-1a · scenes: 10
- Valid district coverage: 100.0% · reliable (≥3 clear obs): 18.6%
- Median clear observations per pixel: 2 · mean clear fraction of observations: 100.0%
- Permanent-water negative control (share of JRC permanent-water cells with MNDWI>0): n/a
- Residual-cloud check (valid pixels with blue SR > 0.15): n/a
- Reasons: none

**2017-06** — Status: **PASS**
- Sensors: sentinel-1a · scenes: 10
- Valid district coverage: 100.0% · reliable (≥3 clear obs): 100.0%
- Median clear observations per pixel: 3 · mean clear fraction of observations: 100.0%
- Permanent-water negative control (share of JRC permanent-water cells with MNDWI>0): n/a
- Residual-cloud check (valid pixels with blue SR > 0.15): n/a
- Reasons: none

**2017-07** — Status: **PASS**
- Sensors: sentinel-1a · scenes: 7
- Valid district coverage: 100.0% · reliable (≥3 clear obs): 18.6%
- Median clear observations per pixel: 2 · mean clear fraction of observations: 100.0%
- Permanent-water negative control (share of JRC permanent-water cells with MNDWI>0): n/a
- Residual-cloud check (valid pixels with blue SR > 0.15): n/a
- Reasons: none

**2017-08** — Status: **PASS**
- Sensors: sentinel-1a · scenes: 10
- Valid district coverage: 100.0% · reliable (≥3 clear obs): 18.6%
- Median clear observations per pixel: 2 · mean clear fraction of observations: 100.0%
- Permanent-water negative control (share of JRC permanent-water cells with MNDWI>0): n/a
- Residual-cloud check (valid pixels with blue SR > 0.15): n/a
- Reasons: none

**2017-09** — Status: **PASS**
- Sensors: sentinel-1a · scenes: 10
- Valid district coverage: 100.0% · reliable (≥3 clear obs): 100.0%
- Median clear observations per pixel: 3 · mean clear fraction of observations: 100.0%
- Permanent-water negative control (share of JRC permanent-water cells with MNDWI>0): n/a
- Residual-cloud check (valid pixels with blue SR > 0.15): n/a
- Reasons: none

**2017-10** — Status: **WARNING**
- Sensors: sentinel-1a · scenes: 8
- Valid district coverage: 100.0% · reliable (≥3 clear obs): 18.4%
- Median clear observations per pixel: 1 · mean clear fraction of observations: 100.0%
- Permanent-water negative control (share of JRC permanent-water cells with MNDWI>0): n/a
- Residual-cloud check (valid pixels with blue SR > 0.15): n/a
- Reasons: median clear observations 1 < 2 (composite statistically weak) | 81% of district from a single observation

**2017-11** — Status: **WARNING**
- Sensors: sentinel-1a · scenes: 6
- Valid district coverage: 100.0% · reliable (≥3 clear obs): 18.5%
- Median clear observations per pixel: 1 · mean clear fraction of observations: 100.0%
- Permanent-water negative control (share of JRC permanent-water cells with MNDWI>0): n/a
- Residual-cloud check (valid pixels with blue SR > 0.15): n/a
- Reasons: median clear observations 1 < 2 (composite statistically weak) | 81% of district from a single observation

**2017-12** — Status: **WARNING**
- Sensors: sentinel-1a · scenes: 8
- Valid district coverage: 100.0% · reliable (≥3 clear obs): 18.5%
- Median clear observations per pixel: 1 · mean clear fraction of observations: 100.0%
- Permanent-water negative control (share of JRC permanent-water cells with MNDWI>0): n/a
- Residual-cloud check (valid pixels with blue SR > 0.15): n/a
- Reasons: median clear observations 1 < 2 (composite statistically weak) | 81% of district from a single observation

**annual** — Status: **PASS**
- Sensors: sentinel-1a · scenes: 102
- Valid district coverage: 100.0% · reliable (≥3 clear obs): 100.0%
- Median clear observations per pixel: 24 · mean clear fraction of observations: 100.0%
- Permanent-water negative control (share of JRC permanent-water cells with MNDWI>0): n/a
- Residual-cloud check (valid pixels with blue SR > 0.15): n/a
- Reasons: none

**dry** — Status: **PASS**
- Sensors: sentinel-1a · scenes: 43
- Valid district coverage: 100.0% · reliable (≥3 clear obs): 100.0%
- Median clear observations per pixel: 11 · mean clear fraction of observations: 100.0%
- Permanent-water negative control (share of JRC permanent-water cells with MNDWI>0): n/a
- Residual-cloud check (valid pixels with blue SR > 0.15): n/a
- Reasons: none

**post_monsoon** — Status: **PASS**
- Sensors: sentinel-1a · scenes: 22
- Valid district coverage: 100.0% · reliable (≥3 clear obs): 100.0%
- Median clear observations per pixel: 3 · mean clear fraction of observations: 100.0%
- Permanent-water negative control (share of JRC permanent-water cells with MNDWI>0): n/a
- Residual-cloud check (valid pixels with blue SR > 0.15): n/a
- Reasons: none

**wet** — Status: **PASS**
- Sensors: sentinel-1a · scenes: 37
- Valid district coverage: 100.0% · reliable (≥3 clear obs): 100.0%
- Median clear observations per pixel: 10 · mean clear fraction of observations: 100.0%
- Permanent-water negative control (share of JRC permanent-water cells with MNDWI>0): n/a
- Residual-cloud check (valid pixels with blue SR > 0.15): n/a
- Reasons: none

### 2018

**2018-01** — Status: **PASS**
- Sensors: sentinel-1a · scenes: 10
- Valid district coverage: 100.0% · reliable (≥3 clear obs): 100.0%
- Median clear observations per pixel: 3 · mean clear fraction of observations: 100.0%
- Permanent-water negative control (share of JRC permanent-water cells with MNDWI>0): n/a
- Residual-cloud check (valid pixels with blue SR > 0.15): n/a
- Reasons: none

**2018-02** — Status: **PASS**
- Sensors: sentinel-1a · scenes: 10
- Valid district coverage: 100.0% · reliable (≥3 clear obs): 18.6%
- Median clear observations per pixel: 2 · mean clear fraction of observations: 100.0%
- Permanent-water negative control (share of JRC permanent-water cells with MNDWI>0): n/a
- Residual-cloud check (valid pixels with blue SR > 0.15): n/a
- Reasons: none

**2018-03** — Status: **WARNING**
- Sensors: sentinel-1a · scenes: 6
- Valid district coverage: 100.0% · reliable (≥3 clear obs): 18.4%
- Median clear observations per pixel: 1 · mean clear fraction of observations: 100.0%
- Permanent-water negative control (share of JRC permanent-water cells with MNDWI>0): n/a
- Residual-cloud check (valid pixels with blue SR > 0.15): n/a
- Reasons: median clear observations 1 < 2 (composite statistically weak) | 81% of district from a single observation

**2018-04** — Status: **WARNING**
- Sensors: sentinel-1a · scenes: 8
- Valid district coverage: 100.0% · reliable (≥3 clear obs): 18.4%
- Median clear observations per pixel: 1 · mean clear fraction of observations: 100.0%
- Permanent-water negative control (share of JRC permanent-water cells with MNDWI>0): n/a
- Residual-cloud check (valid pixels with blue SR > 0.15): n/a
- Reasons: median clear observations 1 < 2 (composite statistically weak) | 81% of district from a single observation

**2018-05** — Status: **PASS**
- Sensors: sentinel-1a · scenes: 8
- Valid district coverage: 100.0% · reliable (≥3 clear obs): 18.6%
- Median clear observations per pixel: 2 · mean clear fraction of observations: 100.0%
- Permanent-water negative control (share of JRC permanent-water cells with MNDWI>0): n/a
- Residual-cloud check (valid pixels with blue SR > 0.15): n/a
- Reasons: none

**2018-06** — Status: **PASS**
- Sensors: sentinel-1a · scenes: 8
- Valid district coverage: 100.0% · reliable (≥3 clear obs): 18.6%
- Median clear observations per pixel: 2 · mean clear fraction of observations: 100.0%
- Permanent-water negative control (share of JRC permanent-water cells with MNDWI>0): n/a
- Residual-cloud check (valid pixels with blue SR > 0.15): n/a
- Reasons: none

**2018-07** — Status: **PASS**
- Sensors: sentinel-1a · scenes: 10
- Valid district coverage: 100.0% · reliable (≥3 clear obs): 100.0%
- Median clear observations per pixel: 3 · mean clear fraction of observations: 100.0%
- Permanent-water negative control (share of JRC permanent-water cells with MNDWI>0): n/a
- Residual-cloud check (valid pixels with blue SR > 0.15): n/a
- Reasons: none

**2018-08** — Status: **PASS**
- Sensors: sentinel-1a · scenes: 10
- Valid district coverage: 100.0% · reliable (≥3 clear obs): 100.0%
- Median clear observations per pixel: 3 · mean clear fraction of observations: 100.0%
- Permanent-water negative control (share of JRC permanent-water cells with MNDWI>0): n/a
- Residual-cloud check (valid pixels with blue SR > 0.15): n/a
- Reasons: none

**2018-09** — Status: **PASS**
- Sensors: sentinel-1a · scenes: 10
- Valid district coverage: 100.0% · reliable (≥3 clear obs): 18.6%
- Median clear observations per pixel: 2 · mean clear fraction of observations: 100.0%
- Permanent-water negative control (share of JRC permanent-water cells with MNDWI>0): n/a
- Residual-cloud check (valid pixels with blue SR > 0.15): n/a
- Reasons: none

**2018-10** — Status: **PASS**
- Sensors: sentinel-1a · scenes: 10
- Valid district coverage: 100.0% · reliable (≥3 clear obs): 100.0%
- Median clear observations per pixel: 3 · mean clear fraction of observations: 100.0%
- Permanent-water negative control (share of JRC permanent-water cells with MNDWI>0): n/a
- Residual-cloud check (valid pixels with blue SR > 0.15): n/a
- Reasons: none

**2018-11** — Status: **PASS**
- Sensors: sentinel-1a · scenes: 7
- Valid district coverage: 100.0% · reliable (≥3 clear obs): 18.6%
- Median clear observations per pixel: 2 · mean clear fraction of observations: 100.0%
- Permanent-water negative control (share of JRC permanent-water cells with MNDWI>0): n/a
- Residual-cloud check (valid pixels with blue SR > 0.15): n/a
- Reasons: none

**2018-12** — Status: **PASS**
- Sensors: sentinel-1a · scenes: 8
- Valid district coverage: 100.0% · reliable (≥3 clear obs): 100.0%
- Median clear observations per pixel: 3 · mean clear fraction of observations: 100.0%
- Permanent-water negative control (share of JRC permanent-water cells with MNDWI>0): n/a
- Residual-cloud check (valid pixels with blue SR > 0.15): n/a
- Reasons: none

**annual** — Status: **PASS**
- Sensors: sentinel-1a · scenes: 105
- Valid district coverage: 100.0% · reliable (≥3 clear obs): 100.0%
- Median clear observations per pixel: 27 · mean clear fraction of observations: 100.0%
- Permanent-water negative control (share of JRC permanent-water cells with MNDWI>0): n/a
- Residual-cloud check (valid pixels with blue SR > 0.15): n/a
- Reasons: none

**dry** — Status: **PASS**
- Sensors: sentinel-1a · scenes: 42
- Valid district coverage: 100.0% · reliable (≥3 clear obs): 100.0%
- Median clear observations per pixel: 9 · mean clear fraction of observations: 100.0%
- Permanent-water negative control (share of JRC permanent-water cells with MNDWI>0): n/a
- Residual-cloud check (valid pixels with blue SR > 0.15): n/a
- Reasons: none

**post_monsoon** — Status: **PASS**
- Sensors: sentinel-1a · scenes: 25
- Valid district coverage: 100.0% · reliable (≥3 clear obs): 100.0%
- Median clear observations per pixel: 8 · mean clear fraction of observations: 100.0%
- Permanent-water negative control (share of JRC permanent-water cells with MNDWI>0): n/a
- Residual-cloud check (valid pixels with blue SR > 0.15): n/a
- Reasons: none

**wet** — Status: **PASS**
- Sensors: sentinel-1a · scenes: 38
- Valid district coverage: 100.0% · reliable (≥3 clear obs): 100.0%
- Median clear observations per pixel: 10 · mean clear fraction of observations: 100.0%
- Permanent-water negative control (share of JRC permanent-water cells with MNDWI>0): n/a
- Residual-cloud check (valid pixels with blue SR > 0.15): n/a
- Reasons: none

### 2019

**2019-01** — Status: **PASS**
- Sensors: sentinel-1a · scenes: 8
- Valid district coverage: 100.0% · reliable (≥3 clear obs): 18.5%
- Median clear observations per pixel: 2 · mean clear fraction of observations: 100.0%
- Permanent-water negative control (share of JRC permanent-water cells with MNDWI>0): n/a
- Residual-cloud check (valid pixels with blue SR > 0.15): n/a
- Reasons: none

**2019-02** — Status: **WARNING**
- Sensors: sentinel-1a · scenes: 2
- Valid district coverage: 100.0% · reliable (≥3 clear obs): 0.0%
- Median clear observations per pixel: 1 · mean clear fraction of observations: 100.0%
- Permanent-water negative control (share of JRC permanent-water cells with MNDWI>0): n/a
- Residual-cloud check (valid pixels with blue SR > 0.15): n/a
- Reasons: median clear observations 1 < 2 (composite statistically weak) | 100% of district from a single observation

**2019-03** — Status: **PASS**
- Sensors: sentinel-1a · scenes: 4
- Valid district coverage: 100.0% · reliable (≥3 clear obs): 0.2%
- Median clear observations per pixel: 2 · mean clear fraction of observations: 100.0%
- Permanent-water negative control (share of JRC permanent-water cells with MNDWI>0): n/a
- Residual-cloud check (valid pixels with blue SR > 0.15): n/a
- Reasons: none

**2019-04** — Status: **WARNING**
- Sensors: sentinel-1a · scenes: 2
- Valid district coverage: 100.0% · reliable (≥3 clear obs): 0.0%
- Median clear observations per pixel: 1 · mean clear fraction of observations: 100.0%
- Permanent-water negative control (share of JRC permanent-water cells with MNDWI>0): n/a
- Residual-cloud check (valid pixels with blue SR > 0.15): n/a
- Reasons: median clear observations 1 < 2 (composite statistically weak) | 100% of district from a single observation

**2019-05** — Status: **FAIL**
- Sensors: sentinel-1a · scenes: 6
- Valid district coverage: 18.4% · reliable (≥3 clear obs): 18.3%
- Median clear observations per pixel: 0 · mean clear fraction of observations: 100.0%
- Permanent-water negative control (share of JRC permanent-water cells with MNDWI>0): n/a
- Residual-cloud check (valid pixels with blue SR > 0.15): n/a
- Reasons: district valid coverage 18.4% < 50% | median clear observations 0 < 2 (composite statistically weak)

**2019-06** — Status: **WARNING**
- Sensors: sentinel-1a · scenes: 4
- Valid district coverage: 100.0% · reliable (≥3 clear obs): 0.1%
- Median clear observations per pixel: 1 · mean clear fraction of observations: 100.0%
- Permanent-water negative control (share of JRC permanent-water cells with MNDWI>0): n/a
- Residual-cloud check (valid pixels with blue SR > 0.15): n/a
- Reasons: median clear observations 1 < 2 (composite statistically weak) | 81% of district from a single observation

**2019-07** — Status: **FAIL**
- Sensors: sentinel-1a · scenes: 6
- Valid district coverage: 18.4% · reliable (≥3 clear obs): 18.3%
- Median clear observations per pixel: 0 · mean clear fraction of observations: 100.0%
- Permanent-water negative control (share of JRC permanent-water cells with MNDWI>0): n/a
- Residual-cloud check (valid pixels with blue SR > 0.15): n/a
- Reasons: district valid coverage 18.4% < 50% | median clear observations 0 < 2 (composite statistically weak)

**2019-08** — Status: **PASS**
- Sensors: sentinel-1a · scenes: 6
- Valid district coverage: 100.0% · reliable (≥3 clear obs): 18.5%
- Median clear observations per pixel: 2 · mean clear fraction of observations: 100.0%
- Permanent-water negative control (share of JRC permanent-water cells with MNDWI>0): n/a
- Residual-cloud check (valid pixels with blue SR > 0.15): n/a
- Reasons: none

**2019-09** — Status: **PASS**
- Sensors: sentinel-1a · scenes: 8
- Valid district coverage: 100.0% · reliable (≥3 clear obs): 18.5%
- Median clear observations per pixel: 2 · mean clear fraction of observations: 100.0%
- Permanent-water negative control (share of JRC permanent-water cells with MNDWI>0): n/a
- Residual-cloud check (valid pixels with blue SR > 0.15): n/a
- Reasons: none

**2019-10** — Status: **PASS**
- Sensors: sentinel-1a,sentinel-1b · scenes: 14
- Valid district coverage: 100.0% · reliable (≥3 clear obs): 100.0%
- Median clear observations per pixel: 5 · mean clear fraction of observations: 100.0%
- Permanent-water negative control (share of JRC permanent-water cells with MNDWI>0): n/a
- Residual-cloud check (valid pixels with blue SR > 0.15): n/a
- Reasons: none

**2019-11** — Status: **PASS**
- Sensors: sentinel-1a,sentinel-1b · scenes: 14
- Valid district coverage: 100.0% · reliable (≥3 clear obs): 100.0%
- Median clear observations per pixel: 5 · mean clear fraction of observations: 100.0%
- Permanent-water negative control (share of JRC permanent-water cells with MNDWI>0): n/a
- Residual-cloud check (valid pixels with blue SR > 0.15): n/a
- Reasons: none

**2019-12** — Status: **PASS**
- Sensors: sentinel-1a,sentinel-1b · scenes: 12
- Valid district coverage: 100.0% · reliable (≥3 clear obs): 100.0%
- Median clear observations per pixel: 4 · mean clear fraction of observations: 100.0%
- Permanent-water negative control (share of JRC permanent-water cells with MNDWI>0): n/a
- Residual-cloud check (valid pixels with blue SR > 0.15): n/a
- Reasons: none

**annual** — Status: **PASS**
- Sensors: sentinel-1a,sentinel-1b · scenes: 86
- Valid district coverage: 100.0% · reliable (≥3 clear obs): 100.0%
- Median clear observations per pixel: 25 · mean clear fraction of observations: 100.0%
- Permanent-water negative control (share of JRC permanent-water cells with MNDWI>0): n/a
- Residual-cloud check (valid pixels with blue SR > 0.15): n/a
- Reasons: none

**dry** — Status: **PASS**
- Sensors: sentinel-1a · scenes: 22
- Valid district coverage: 100.0% · reliable (≥3 clear obs): 100.0%
- Median clear observations per pixel: 6 · mean clear fraction of observations: 100.0%
- Permanent-water negative control (share of JRC permanent-water cells with MNDWI>0): n/a
- Residual-cloud check (valid pixels with blue SR > 0.15): n/a
- Reasons: none

**post_monsoon** — Status: **PASS**
- Sensors: sentinel-1a,sentinel-1b · scenes: 40
- Valid district coverage: 100.0% · reliable (≥3 clear obs): 100.0%
- Median clear observations per pixel: 14 · mean clear fraction of observations: 100.0%
- Permanent-water negative control (share of JRC permanent-water cells with MNDWI>0): n/a
- Residual-cloud check (valid pixels with blue SR > 0.15): n/a
- Reasons: none

**wet** — Status: **PASS**
- Sensors: sentinel-1a · scenes: 24
- Valid district coverage: 100.0% · reliable (≥3 clear obs): 100.0%
- Median clear observations per pixel: 5 · mean clear fraction of observations: 100.0%
- Permanent-water negative control (share of JRC permanent-water cells with MNDWI>0): n/a
- Residual-cloud check (valid pixels with blue SR > 0.15): n/a
- Reasons: none

### 2020

**2020-01** — Status: **PASS**
- Sensors: sentinel-1a,sentinel-1b · scenes: 14
- Valid district coverage: 100.0% · reliable (≥3 clear obs): 100.0%
- Median clear observations per pixel: 5 · mean clear fraction of observations: 100.0%
- Permanent-water negative control (share of JRC permanent-water cells with MNDWI>0): n/a
- Residual-cloud check (valid pixels with blue SR > 0.15): n/a
- Reasons: none

**2020-02** — Status: **PASS**
- Sensors: sentinel-1a · scenes: 6
- Valid district coverage: 100.0% · reliable (≥3 clear obs): 18.6%
- Median clear observations per pixel: 2 · mean clear fraction of observations: 100.0%
- Permanent-water negative control (share of JRC permanent-water cells with MNDWI>0): n/a
- Residual-cloud check (valid pixels with blue SR > 0.15): n/a
- Reasons: none

**2020-03** — Status: **PASS**
- Sensors: sentinel-1a · scenes: 8
- Valid district coverage: 100.0% · reliable (≥3 clear obs): 100.0%
- Median clear observations per pixel: 3 · mean clear fraction of observations: 100.0%
- Permanent-water negative control (share of JRC permanent-water cells with MNDWI>0): n/a
- Residual-cloud check (valid pixels with blue SR > 0.15): n/a
- Reasons: none

**2020-04** — Status: **PASS**
- Sensors: sentinel-1a · scenes: 8
- Valid district coverage: 100.0% · reliable (≥3 clear obs): 18.6%
- Median clear observations per pixel: 2 · mean clear fraction of observations: 100.0%
- Permanent-water negative control (share of JRC permanent-water cells with MNDWI>0): n/a
- Residual-cloud check (valid pixels with blue SR > 0.15): n/a
- Reasons: none

**2020-05** — Status: **PASS**
- Sensors: sentinel-1a · scenes: 8
- Valid district coverage: 100.0% · reliable (≥3 clear obs): 100.0%
- Median clear observations per pixel: 3 · mean clear fraction of observations: 100.0%
- Permanent-water negative control (share of JRC permanent-water cells with MNDWI>0): n/a
- Residual-cloud check (valid pixels with blue SR > 0.15): n/a
- Reasons: none

**2020-06** — Status: **PASS**
- Sensors: sentinel-1a · scenes: 10
- Valid district coverage: 100.0% · reliable (≥3 clear obs): 19.0%
- Median clear observations per pixel: 2 · mean clear fraction of observations: 100.0%
- Permanent-water negative control (share of JRC permanent-water cells with MNDWI>0): n/a
- Residual-cloud check (valid pixels with blue SR > 0.15): n/a
- Reasons: none

**2020-07** — Status: **PASS**
- Sensors: sentinel-1a · scenes: 10
- Valid district coverage: 100.0% · reliable (≥3 clear obs): 100.0%
- Median clear observations per pixel: 3 · mean clear fraction of observations: 100.0%
- Permanent-water negative control (share of JRC permanent-water cells with MNDWI>0): n/a
- Residual-cloud check (valid pixels with blue SR > 0.15): n/a
- Reasons: none

**2020-08** — Status: **PASS**
- Sensors: sentinel-1a · scenes: 10
- Valid district coverage: 100.0% · reliable (≥3 clear obs): 18.5%
- Median clear observations per pixel: 2 · mean clear fraction of observations: 100.0%
- Permanent-water negative control (share of JRC permanent-water cells with MNDWI>0): n/a
- Residual-cloud check (valid pixels with blue SR > 0.15): n/a
- Reasons: none

**2020-09** — Status: **PASS**
- Sensors: sentinel-1a · scenes: 10
- Valid district coverage: 100.0% · reliable (≥3 clear obs): 100.0%
- Median clear observations per pixel: 3 · mean clear fraction of observations: 100.0%
- Permanent-water negative control (share of JRC permanent-water cells with MNDWI>0): n/a
- Residual-cloud check (valid pixels with blue SR > 0.15): n/a
- Reasons: none

**2020-10** — Status: **PASS**
- Sensors: sentinel-1a · scenes: 8
- Valid district coverage: 100.0% · reliable (≥3 clear obs): 100.0%
- Median clear observations per pixel: 3 · mean clear fraction of observations: 100.0%
- Permanent-water negative control (share of JRC permanent-water cells with MNDWI>0): n/a
- Residual-cloud check (valid pixels with blue SR > 0.15): n/a
- Reasons: none

**2020-11** — Status: **PASS**
- Sensors: sentinel-1a · scenes: 7
- Valid district coverage: 100.0% · reliable (≥3 clear obs): 18.2%
- Median clear observations per pixel: 2 · mean clear fraction of observations: 100.0%
- Permanent-water negative control (share of JRC permanent-water cells with MNDWI>0): n/a
- Residual-cloud check (valid pixels with blue SR > 0.15): n/a
- Reasons: none

**2020-12** — Status: **PASS**
- Sensors: sentinel-1a · scenes: 8
- Valid district coverage: 100.0% · reliable (≥3 clear obs): 100.0%
- Median clear observations per pixel: 3 · mean clear fraction of observations: 100.0%
- Permanent-water negative control (share of JRC permanent-water cells with MNDWI>0): n/a
- Residual-cloud check (valid pixels with blue SR > 0.15): n/a
- Reasons: none

**annual** — Status: **PASS**
- Sensors: sentinel-1a,sentinel-1b · scenes: 107
- Valid district coverage: 100.0% · reliable (≥3 clear obs): 100.0%
- Median clear observations per pixel: 33 · mean clear fraction of observations: 100.0%
- Permanent-water negative control (share of JRC permanent-water cells with MNDWI>0): n/a
- Residual-cloud check (valid pixels with blue SR > 0.15): n/a
- Reasons: none

**dry** — Status: **PASS**
- Sensors: sentinel-1a,sentinel-1b · scenes: 44
- Valid district coverage: 100.0% · reliable (≥3 clear obs): 100.0%
- Median clear observations per pixel: 15 · mean clear fraction of observations: 100.0%
- Permanent-water negative control (share of JRC permanent-water cells with MNDWI>0): n/a
- Residual-cloud check (valid pixels with blue SR > 0.15): n/a
- Reasons: none

**post_monsoon** — Status: **PASS**
- Sensors: sentinel-1a · scenes: 23
- Valid district coverage: 100.0% · reliable (≥3 clear obs): 100.0%
- Median clear observations per pixel: 8 · mean clear fraction of observations: 100.0%
- Permanent-water negative control (share of JRC permanent-water cells with MNDWI>0): n/a
- Residual-cloud check (valid pixels with blue SR > 0.15): n/a
- Reasons: none

**wet** — Status: **PASS**
- Sensors: sentinel-1a · scenes: 40
- Valid district coverage: 100.0% · reliable (≥3 clear obs): 100.0%
- Median clear observations per pixel: 10 · mean clear fraction of observations: 100.0%
- Permanent-water negative control (share of JRC permanent-water cells with MNDWI>0): n/a
- Residual-cloud check (valid pixels with blue SR > 0.15): n/a
- Reasons: none

### 2021

**2021-01** — Status: **PASS**
- Sensors: sentinel-1a · scenes: 7
- Valid district coverage: 100.0% · reliable (≥3 clear obs): 18.2%
- Median clear observations per pixel: 2 · mean clear fraction of observations: 100.0%
- Permanent-water negative control (share of JRC permanent-water cells with MNDWI>0): n/a
- Residual-cloud check (valid pixels with blue SR > 0.15): n/a
- Reasons: none

**2021-02** — Status: **PASS**
- Sensors: sentinel-1a · scenes: 8
- Valid district coverage: 100.0% · reliable (≥3 clear obs): 100.0%
- Median clear observations per pixel: 3 · mean clear fraction of observations: 100.0%
- Permanent-water negative control (share of JRC permanent-water cells with MNDWI>0): n/a
- Residual-cloud check (valid pixels with blue SR > 0.15): n/a
- Reasons: none

**2021-03** — Status: **PASS**
- Sensors: sentinel-1a · scenes: 7
- Valid district coverage: 100.0% · reliable (≥3 clear obs): 18.2%
- Median clear observations per pixel: 2 · mean clear fraction of observations: 100.0%
- Permanent-water negative control (share of JRC permanent-water cells with MNDWI>0): n/a
- Residual-cloud check (valid pixels with blue SR > 0.15): n/a
- Reasons: none

**2021-04** — Status: **PASS**
- Sensors: sentinel-1a · scenes: 6
- Valid district coverage: 100.0% · reliable (≥3 clear obs): 18.1%
- Median clear observations per pixel: 2 · mean clear fraction of observations: 100.0%
- Permanent-water negative control (share of JRC permanent-water cells with MNDWI>0): n/a
- Residual-cloud check (valid pixels with blue SR > 0.15): n/a
- Reasons: none

**2021-05** — Status: **PASS**
- Sensors: sentinel-1a · scenes: 7
- Valid district coverage: 100.0% · reliable (≥3 clear obs): 18.2%
- Median clear observations per pixel: 2 · mean clear fraction of observations: 100.0%
- Permanent-water negative control (share of JRC permanent-water cells with MNDWI>0): n/a
- Residual-cloud check (valid pixels with blue SR > 0.15): n/a
- Reasons: none

**2021-06** — Status: **PASS**
- Sensors: sentinel-1a · scenes: 8
- Valid district coverage: 100.0% · reliable (≥3 clear obs): 100.0%
- Median clear observations per pixel: 3 · mean clear fraction of observations: 100.0%
- Permanent-water negative control (share of JRC permanent-water cells with MNDWI>0): n/a
- Residual-cloud check (valid pixels with blue SR > 0.15): n/a
- Reasons: none

**2021-07** — Status: **PASS**
- Sensors: sentinel-1a · scenes: 7
- Valid district coverage: 100.0% · reliable (≥3 clear obs): 18.3%
- Median clear observations per pixel: 2 · mean clear fraction of observations: 100.0%
- Permanent-water negative control (share of JRC permanent-water cells with MNDWI>0): n/a
- Residual-cloud check (valid pixels with blue SR > 0.15): n/a
- Reasons: none

**2021-08** — Status: **PASS**
- Sensors: sentinel-1a,sentinel-1b · scenes: 9
- Valid district coverage: 100.0% · reliable (≥3 clear obs): 100.0%
- Median clear observations per pixel: 3 · mean clear fraction of observations: 100.0%
- Permanent-water negative control (share of JRC permanent-water cells with MNDWI>0): n/a
- Residual-cloud check (valid pixels with blue SR > 0.15): n/a
- Reasons: none

**2021-09** — Status: **PASS**
- Sensors: sentinel-1a · scenes: 7
- Valid district coverage: 100.0% · reliable (≥3 clear obs): 18.2%
- Median clear observations per pixel: 2 · mean clear fraction of observations: 100.0%
- Permanent-water negative control (share of JRC permanent-water cells with MNDWI>0): n/a
- Residual-cloud check (valid pixels with blue SR > 0.15): n/a
- Reasons: none

**2021-10** — Status: **PASS**
- Sensors: sentinel-1a · scenes: 9
- Valid district coverage: 100.0% · reliable (≥3 clear obs): 100.0%
- Median clear observations per pixel: 3 · mean clear fraction of observations: 100.0%
- Permanent-water negative control (share of JRC permanent-water cells with MNDWI>0): n/a
- Residual-cloud check (valid pixels with blue SR > 0.15): n/a
- Reasons: none

**2021-11** — Status: **PASS**
- Sensors: sentinel-1a · scenes: 6
- Valid district coverage: 100.0% · reliable (≥3 clear obs): 18.2%
- Median clear observations per pixel: 2 · mean clear fraction of observations: 100.0%
- Permanent-water negative control (share of JRC permanent-water cells with MNDWI>0): n/a
- Residual-cloud check (valid pixels with blue SR > 0.15): n/a
- Reasons: none

**2021-12** — Status: **PASS**
- Sensors: sentinel-1a · scenes: 7
- Valid district coverage: 100.0% · reliable (≥3 clear obs): 18.2%
- Median clear observations per pixel: 2 · mean clear fraction of observations: 100.0%
- Permanent-water negative control (share of JRC permanent-water cells with MNDWI>0): n/a
- Residual-cloud check (valid pixels with blue SR > 0.15): n/a
- Reasons: none

**annual** — Status: **PASS**
- Sensors: sentinel-1a,sentinel-1b · scenes: 88
- Valid district coverage: 100.0% · reliable (≥3 clear obs): 100.0%
- Median clear observations per pixel: 28 · mean clear fraction of observations: 100.0%
- Permanent-water negative control (share of JRC permanent-water cells with MNDWI>0): n/a
- Residual-cloud check (valid pixels with blue SR > 0.15): n/a
- Reasons: none

**dry** — Status: **PASS**
- Sensors: sentinel-1a · scenes: 35
- Valid district coverage: 100.0% · reliable (≥3 clear obs): 100.0%
- Median clear observations per pixel: 11 · mean clear fraction of observations: 100.0%
- Permanent-water negative control (share of JRC permanent-water cells with MNDWI>0): n/a
- Residual-cloud check (valid pixels with blue SR > 0.15): n/a
- Reasons: none

**post_monsoon** — Status: **PASS**
- Sensors: sentinel-1a · scenes: 22
- Valid district coverage: 100.0% · reliable (≥3 clear obs): 100.0%
- Median clear observations per pixel: 7 · mean clear fraction of observations: 100.0%
- Permanent-water negative control (share of JRC permanent-water cells with MNDWI>0): n/a
- Residual-cloud check (valid pixels with blue SR > 0.15): n/a
- Reasons: none

**wet** — Status: **PASS**
- Sensors: sentinel-1a,sentinel-1b · scenes: 31
- Valid district coverage: 100.0% · reliable (≥3 clear obs): 100.0%
- Median clear observations per pixel: 10 · mean clear fraction of observations: 100.0%
- Permanent-water negative control (share of JRC permanent-water cells with MNDWI>0): n/a
- Residual-cloud check (valid pixels with blue SR > 0.15): n/a
- Reasons: none

### 2022

**2022-01** — Status: **PASS**
- Sensors: sentinel-1a · scenes: 8
- Valid district coverage: 100.0% · reliable (≥3 clear obs): 100.0%
- Median clear observations per pixel: 3 · mean clear fraction of observations: 100.0%
- Permanent-water negative control (share of JRC permanent-water cells with MNDWI>0): n/a
- Residual-cloud check (valid pixels with blue SR > 0.15): n/a
- Reasons: none

**2022-02** — Status: **PASS**
- Sensors: sentinel-1a · scenes: 6
- Valid district coverage: 100.0% · reliable (≥3 clear obs): 18.2%
- Median clear observations per pixel: 2 · mean clear fraction of observations: 100.0%
- Permanent-water negative control (share of JRC permanent-water cells with MNDWI>0): n/a
- Residual-cloud check (valid pixels with blue SR > 0.15): n/a
- Reasons: none

**2022-03** — Status: **PASS**
- Sensors: sentinel-1a · scenes: 8
- Valid district coverage: 100.0% · reliable (≥3 clear obs): 100.0%
- Median clear observations per pixel: 3 · mean clear fraction of observations: 100.0%
- Permanent-water negative control (share of JRC permanent-water cells with MNDWI>0): n/a
- Residual-cloud check (valid pixels with blue SR > 0.15): n/a
- Reasons: none

**2022-04** — Status: **WARNING**
- Sensors: sentinel-1a · scenes: 5
- Valid district coverage: 100.0% · reliable (≥3 clear obs): 18.0%
- Median clear observations per pixel: 1 · mean clear fraction of observations: 100.0%
- Permanent-water negative control (share of JRC permanent-water cells with MNDWI>0): n/a
- Residual-cloud check (valid pixels with blue SR > 0.15): n/a
- Reasons: median clear observations 1 < 2 (composite statistically weak) | 82% of district from a single observation

**2022-05** — Status: **PASS**
- Sensors: sentinel-1a · scenes: 6
- Valid district coverage: 100.0% · reliable (≥3 clear obs): 18.2%
- Median clear observations per pixel: 2 · mean clear fraction of observations: 100.0%
- Permanent-water negative control (share of JRC permanent-water cells with MNDWI>0): n/a
- Residual-cloud check (valid pixels with blue SR > 0.15): n/a
- Reasons: none

**2022-06** — Status: **PASS**
- Sensors: sentinel-1a · scenes: 7
- Valid district coverage: 100.0% · reliable (≥3 clear obs): 18.2%
- Median clear observations per pixel: 2 · mean clear fraction of observations: 100.0%
- Permanent-water negative control (share of JRC permanent-water cells with MNDWI>0): n/a
- Residual-cloud check (valid pixels with blue SR > 0.15): n/a
- Reasons: none

**2022-07** — Status: **PASS**
- Sensors: sentinel-1a · scenes: 8
- Valid district coverage: 100.0% · reliable (≥3 clear obs): 100.0%
- Median clear observations per pixel: 3 · mean clear fraction of observations: 100.0%
- Permanent-water negative control (share of JRC permanent-water cells with MNDWI>0): n/a
- Residual-cloud check (valid pixels with blue SR > 0.15): n/a
- Reasons: none

**2022-08** — Status: **WARNING**
- Sensors: sentinel-1a · scenes: 4
- Valid district coverage: 100.0% · reliable (≥3 clear obs): 18.4%
- Median clear observations per pixel: 1 · mean clear fraction of observations: 100.0%
- Permanent-water negative control (share of JRC permanent-water cells with MNDWI>0): n/a
- Residual-cloud check (valid pixels with blue SR > 0.15): n/a
- Reasons: median clear observations 1 < 2 (composite statistically weak) | 81% of district from a single observation

**2022-09** — Status: **FAIL**
- Sensors: sentinel-1a · scenes: 2
- Valid district coverage: 18.6% · reliable (≥3 clear obs): 0.0%
- Median clear observations per pixel: 0 · mean clear fraction of observations: 100.0%
- Permanent-water negative control (share of JRC permanent-water cells with MNDWI>0): n/a
- Residual-cloud check (valid pixels with blue SR > 0.15): n/a
- Reasons: district valid coverage 18.6% < 50% | median clear observations 0 < 2 (composite statistically weak)

**2022-10** — Status: **FAIL**
- Sensors: sentinel-1a · scenes: 3
- Valid district coverage: 18.5% · reliable (≥3 clear obs): 18.3%
- Median clear observations per pixel: 0 · mean clear fraction of observations: 100.0%
- Permanent-water negative control (share of JRC permanent-water cells with MNDWI>0): n/a
- Residual-cloud check (valid pixels with blue SR > 0.15): n/a
- Reasons: district valid coverage 18.5% < 50% | median clear observations 0 < 2 (composite statistically weak)

**2022-11** — Status: **WARNING**
- Sensors: sentinel-1a · scenes: 4
- Valid district coverage: 100.0% · reliable (≥3 clear obs): 18.4%
- Median clear observations per pixel: 1 · mean clear fraction of observations: 100.0%
- Permanent-water negative control (share of JRC permanent-water cells with MNDWI>0): n/a
- Residual-cloud check (valid pixels with blue SR > 0.15): n/a
- Reasons: median clear observations 1 < 2 (composite statistically weak) | 81% of district from a single observation

**2022-12** — Status: **WARNING**
- Sensors: sentinel-1a · scenes: 5
- Valid district coverage: 100.0% · reliable (≥3 clear obs): 18.3%
- Median clear observations per pixel: 1 · mean clear fraction of observations: 100.0%
- Permanent-water negative control (share of JRC permanent-water cells with MNDWI>0): n/a
- Residual-cloud check (valid pixels with blue SR > 0.15): n/a
- Reasons: median clear observations 1 < 2 (composite statistically weak) | 81% of district from a single observation

**annual** — Status: **PASS**
- Sensors: sentinel-1a · scenes: 66
- Valid district coverage: 100.0% · reliable (≥3 clear obs): 100.0%
- Median clear observations per pixel: 19 · mean clear fraction of observations: 100.0%
- Permanent-water negative control (share of JRC permanent-water cells with MNDWI>0): n/a
- Residual-cloud check (valid pixels with blue SR > 0.15): n/a
- Reasons: none

**dry** — Status: **PASS**
- Sensors: sentinel-1a · scenes: 33
- Valid district coverage: 100.0% · reliable (≥3 clear obs): 100.0%
- Median clear observations per pixel: 11 · mean clear fraction of observations: 100.0%
- Permanent-water negative control (share of JRC permanent-water cells with MNDWI>0): n/a
- Residual-cloud check (valid pixels with blue SR > 0.15): n/a
- Reasons: none

**post_monsoon** — Status: **PASS**
- Sensors: sentinel-1a · scenes: 12
- Valid district coverage: 100.0% · reliable (≥3 clear obs): 18.7%
- Median clear observations per pixel: 2 · mean clear fraction of observations: 100.0%
- Permanent-water negative control (share of JRC permanent-water cells with MNDWI>0): n/a
- Residual-cloud check (valid pixels with blue SR > 0.15): n/a
- Reasons: none

**wet** — Status: **PASS**
- Sensors: sentinel-1a · scenes: 21
- Valid district coverage: 100.0% · reliable (≥3 clear obs): 100.0%
- Median clear observations per pixel: 6 · mean clear fraction of observations: 100.0%
- Permanent-water negative control (share of JRC permanent-water cells with MNDWI>0): n/a
- Residual-cloud check (valid pixels with blue SR > 0.15): n/a
- Reasons: none

### 2023

**2023-01** — Status: **PASS**
- Sensors: sentinel-1a · scenes: 7
- Valid district coverage: 100.0% · reliable (≥3 clear obs): 18.8%
- Median clear observations per pixel: 2 · mean clear fraction of observations: 100.0%
- Permanent-water negative control (share of JRC permanent-water cells with MNDWI>0): n/a
- Residual-cloud check (valid pixels with blue SR > 0.15): n/a
- Reasons: none

**2023-02** — Status: **WARNING**
- Sensors: sentinel-1a · scenes: 4
- Valid district coverage: 100.0% · reliable (≥3 clear obs): 18.4%
- Median clear observations per pixel: 1 · mean clear fraction of observations: 100.0%
- Permanent-water negative control (share of JRC permanent-water cells with MNDWI>0): n/a
- Residual-cloud check (valid pixels with blue SR > 0.15): n/a
- Reasons: median clear observations 1 < 2 (composite statistically weak) | 81% of district from a single observation

**2023-03** — Status: **WARNING**
- Sensors: sentinel-1a · scenes: 4
- Valid district coverage: 100.0% · reliable (≥3 clear obs): 18.3%
- Median clear observations per pixel: 1 · mean clear fraction of observations: 100.0%
- Permanent-water negative control (share of JRC permanent-water cells with MNDWI>0): n/a
- Residual-cloud check (valid pixels with blue SR > 0.15): n/a
- Reasons: median clear observations 1 < 2 (composite statistically weak) | 81% of district from a single observation

**2023-04** — Status: **WARNING**
- Sensors: sentinel-1a · scenes: 4
- Valid district coverage: 100.0% · reliable (≥3 clear obs): 18.3%
- Median clear observations per pixel: 1 · mean clear fraction of observations: 100.0%
- Permanent-water negative control (share of JRC permanent-water cells with MNDWI>0): n/a
- Residual-cloud check (valid pixels with blue SR > 0.15): n/a
- Reasons: median clear observations 1 < 2 (composite statistically weak) | 81% of district from a single observation

**2023-05** — Status: **PASS**
- Sensors: sentinel-1a · scenes: 7
- Valid district coverage: 100.0% · reliable (≥3 clear obs): 18.4%
- Median clear observations per pixel: 2 · mean clear fraction of observations: 100.0%
- Permanent-water negative control (share of JRC permanent-water cells with MNDWI>0): n/a
- Residual-cloud check (valid pixels with blue SR > 0.15): n/a
- Reasons: none

**2023-06** — Status: **PASS**
- Sensors: sentinel-1a · scenes: 8
- Valid district coverage: 100.0% · reliable (≥3 clear obs): 100.0%
- Median clear observations per pixel: 3 · mean clear fraction of observations: 100.0%
- Permanent-water negative control (share of JRC permanent-water cells with MNDWI>0): n/a
- Residual-cloud check (valid pixels with blue SR > 0.15): n/a
- Reasons: none

**2023-07** — Status: **WARNING**
- Sensors: sentinel-1a · scenes: 4
- Valid district coverage: 100.0% · reliable (≥3 clear obs): 18.3%
- Median clear observations per pixel: 1 · mean clear fraction of observations: 100.0%
- Permanent-water negative control (share of JRC permanent-water cells with MNDWI>0): n/a
- Residual-cloud check (valid pixels with blue SR > 0.15): n/a
- Reasons: median clear observations 1 < 2 (composite statistically weak) | 82% of district from a single observation

**2023-08** — Status: **PASS**
- Sensors: sentinel-1a · scenes: 6
- Valid district coverage: 100.0% · reliable (≥3 clear obs): 18.9%
- Median clear observations per pixel: 2 · mean clear fraction of observations: 100.0%
- Permanent-water negative control (share of JRC permanent-water cells with MNDWI>0): n/a
- Residual-cloud check (valid pixels with blue SR > 0.15): n/a
- Reasons: none

**2023-09** — Status: **WARNING**
- Sensors: sentinel-1a · scenes: 5
- Valid district coverage: 100.0% · reliable (≥3 clear obs): 18.4%
- Median clear observations per pixel: 1 · mean clear fraction of observations: 100.0%
- Permanent-water negative control (share of JRC permanent-water cells with MNDWI>0): n/a
- Residual-cloud check (valid pixels with blue SR > 0.15): n/a
- Reasons: median clear observations 1 < 2 (composite statistically weak) | 81% of district from a single observation

**2023-10** — Status: **WARNING**
- Sensors: sentinel-1a · scenes: 4
- Valid district coverage: 100.0% · reliable (≥3 clear obs): 18.3%
- Median clear observations per pixel: 1 · mean clear fraction of observations: 100.0%
- Permanent-water negative control (share of JRC permanent-water cells with MNDWI>0): n/a
- Residual-cloud check (valid pixels with blue SR > 0.15): n/a
- Reasons: median clear observations 1 < 2 (composite statistically weak) | 81% of district from a single observation

**2023-11** — Status: **WARNING**
- Sensors: sentinel-1a · scenes: 5
- Valid district coverage: 100.0% · reliable (≥3 clear obs): 18.5%
- Median clear observations per pixel: 1 · mean clear fraction of observations: 100.0%
- Permanent-water negative control (share of JRC permanent-water cells with MNDWI>0): n/a
- Residual-cloud check (valid pixels with blue SR > 0.15): n/a
- Reasons: median clear observations 1 < 2 (composite statistically weak) | 81% of district from a single observation

**2023-12** — Status: **PASS**
- Sensors: sentinel-1a · scenes: 6
- Valid district coverage: 100.0% · reliable (≥3 clear obs): 18.7%
- Median clear observations per pixel: 2 · mean clear fraction of observations: 100.0%
- Permanent-water negative control (share of JRC permanent-water cells with MNDWI>0): n/a
- Residual-cloud check (valid pixels with blue SR > 0.15): n/a
- Reasons: none

**annual** — Status: **PASS**
- Sensors: sentinel-1a · scenes: 64
- Valid district coverage: 100.0% · reliable (≥3 clear obs): 100.0%
- Median clear observations per pixel: 18 · mean clear fraction of observations: 100.0%
- Permanent-water negative control (share of JRC permanent-water cells with MNDWI>0): n/a
- Residual-cloud check (valid pixels with blue SR > 0.15): n/a
- Reasons: none

**dry** — Status: **PASS**
- Sensors: sentinel-1a · scenes: 26
- Valid district coverage: 100.0% · reliable (≥3 clear obs): 100.0%
- Median clear observations per pixel: 7 · mean clear fraction of observations: 100.0%
- Permanent-water negative control (share of JRC permanent-water cells with MNDWI>0): n/a
- Residual-cloud check (valid pixels with blue SR > 0.15): n/a
- Reasons: none

**post_monsoon** — Status: **PASS**
- Sensors: sentinel-1a · scenes: 15
- Valid district coverage: 100.0% · reliable (≥3 clear obs): 100.0%
- Median clear observations per pixel: 4 · mean clear fraction of observations: 100.0%
- Permanent-water negative control (share of JRC permanent-water cells with MNDWI>0): n/a
- Residual-cloud check (valid pixels with blue SR > 0.15): n/a
- Reasons: none

**wet** — Status: **PASS**
- Sensors: sentinel-1a · scenes: 23
- Valid district coverage: 100.0% · reliable (≥3 clear obs): 100.0%
- Median clear observations per pixel: 7 · mean clear fraction of observations: 100.0%
- Permanent-water negative control (share of JRC permanent-water cells with MNDWI>0): n/a
- Residual-cloud check (valid pixels with blue SR > 0.15): n/a
- Reasons: none

### 2024

**2024-01** — Status: **PASS**
- Sensors: sentinel-1a · scenes: 7
- Valid district coverage: 100.0% · reliable (≥3 clear obs): 18.5%
- Median clear observations per pixel: 2 · mean clear fraction of observations: 100.0%
- Permanent-water negative control (share of JRC permanent-water cells with MNDWI>0): n/a
- Residual-cloud check (valid pixels with blue SR > 0.15): n/a
- Reasons: none

**2024-02** — Status: **WARNING**
- Sensors: sentinel-1a · scenes: 4
- Valid district coverage: 100.0% · reliable (≥3 clear obs): 18.4%
- Median clear observations per pixel: 1 · mean clear fraction of observations: 100.0%
- Permanent-water negative control (share of JRC permanent-water cells with MNDWI>0): n/a
- Residual-cloud check (valid pixels with blue SR > 0.15): n/a
- Reasons: median clear observations 1 < 2 (composite statistically weak) | 81% of district from a single observation

**2024-03** — Status: **WARNING**
- Sensors: sentinel-1a · scenes: 5
- Valid district coverage: 100.0% · reliable (≥3 clear obs): 18.4%
- Median clear observations per pixel: 1 · mean clear fraction of observations: 100.0%
- Permanent-water negative control (share of JRC permanent-water cells with MNDWI>0): n/a
- Residual-cloud check (valid pixels with blue SR > 0.15): n/a
- Reasons: median clear observations 1 < 2 (composite statistically weak) | 81% of district from a single observation

**2024-04** — Status: **PASS**
- Sensors: sentinel-1a · scenes: 9
- Valid district coverage: 100.0% · reliable (≥3 clear obs): 100.0%
- Median clear observations per pixel: 3 · mean clear fraction of observations: 100.0%
- Permanent-water negative control (share of JRC permanent-water cells with MNDWI>0): n/a
- Residual-cloud check (valid pixels with blue SR > 0.15): n/a
- Reasons: none

**2024-05** — Status: **PASS**
- Sensors: sentinel-1a · scenes: 5
- Valid district coverage: 100.0% · reliable (≥3 clear obs): 18.4%
- Median clear observations per pixel: 2 · mean clear fraction of observations: 100.0%
- Permanent-water negative control (share of JRC permanent-water cells with MNDWI>0): n/a
- Residual-cloud check (valid pixels with blue SR > 0.15): n/a
- Reasons: none

**2024-06** — Status: **FAIL**
- Sensors: sentinel-1a · scenes: 3
- Valid district coverage: 18.3% · reliable (≥3 clear obs): 18.2%
- Median clear observations per pixel: 0 · mean clear fraction of observations: 100.0%
- Permanent-water negative control (share of JRC permanent-water cells with MNDWI>0): n/a
- Residual-cloud check (valid pixels with blue SR > 0.15): n/a
- Reasons: district valid coverage 18.3% < 50% | median clear observations 0 < 2 (composite statistically weak)

**2024-07** — Status: **FAIL**
- Sensors: sentinel-1a · scenes: 2
- Valid district coverage: 18.3% · reliable (≥3 clear obs): 0.0%
- Median clear observations per pixel: 0 · mean clear fraction of observations: 100.0%
- Permanent-water negative control (share of JRC permanent-water cells with MNDWI>0): n/a
- Residual-cloud check (valid pixels with blue SR > 0.15): n/a
- Reasons: district valid coverage 18.3% < 50% | median clear observations 0 < 2 (composite statistically weak)

**2024-08** — Status: **WARNING**
- Sensors: sentinel-1a · scenes: 4
- Valid district coverage: 100.0% · reliable (≥3 clear obs): 18.3%
- Median clear observations per pixel: 1 · mean clear fraction of observations: 100.0%
- Permanent-water negative control (share of JRC permanent-water cells with MNDWI>0): n/a
- Residual-cloud check (valid pixels with blue SR > 0.15): n/a
- Reasons: median clear observations 1 < 2 (composite statistically weak) | 82% of district from a single observation

**2024-09** — Status: **WARNING**
- Sensors: sentinel-1a · scenes: 5
- Valid district coverage: 100.0% · reliable (≥3 clear obs): 18.5%
- Median clear observations per pixel: 1 · mean clear fraction of observations: 100.0%
- Permanent-water negative control (share of JRC permanent-water cells with MNDWI>0): n/a
- Residual-cloud check (valid pixels with blue SR > 0.15): n/a
- Reasons: median clear observations 1 < 2 (composite statistically weak) | 71% of district from a single observation

**2024-10** — Status: **PASS**
- Sensors: sentinel-1a · scenes: 7
- Valid district coverage: 100.0% · reliable (≥3 clear obs): 18.7%
- Median clear observations per pixel: 2 · mean clear fraction of observations: 100.0%
- Permanent-water negative control (share of JRC permanent-water cells with MNDWI>0): n/a
- Residual-cloud check (valid pixels with blue SR > 0.15): n/a
- Reasons: none

**2024-11** — Status: **PASS**
- Sensors: sentinel-1a · scenes: 7
- Valid district coverage: 100.0% · reliable (≥3 clear obs): 100.0%
- Median clear observations per pixel: 3 · mean clear fraction of observations: 100.0%
- Permanent-water negative control (share of JRC permanent-water cells with MNDWI>0): n/a
- Residual-cloud check (valid pixels with blue SR > 0.15): n/a
- Reasons: none

**2024-12** — Status: **PASS**
- Sensors: sentinel-1a · scenes: 7
- Valid district coverage: 100.0% · reliable (≥3 clear obs): 18.6%
- Median clear observations per pixel: 2 · mean clear fraction of observations: 100.0%
- Permanent-water negative control (share of JRC permanent-water cells with MNDWI>0): n/a
- Residual-cloud check (valid pixels with blue SR > 0.15): n/a
- Reasons: none

**annual** — Status: **PASS**
- Sensors: sentinel-1a · scenes: 65
- Valid district coverage: 100.0% · reliable (≥3 clear obs): 100.0%
- Median clear observations per pixel: 18 · mean clear fraction of observations: 100.0%
- Permanent-water negative control (share of JRC permanent-water cells with MNDWI>0): n/a
- Residual-cloud check (valid pixels with blue SR > 0.15): n/a
- Reasons: none

**dry** — Status: **PASS**
- Sensors: sentinel-1a · scenes: 30
- Valid district coverage: 100.0% · reliable (≥3 clear obs): 100.0%
- Median clear observations per pixel: 9 · mean clear fraction of observations: 100.0%
- Permanent-water negative control (share of JRC permanent-water cells with MNDWI>0): n/a
- Residual-cloud check (valid pixels with blue SR > 0.15): n/a
- Reasons: none

**post_monsoon** — Status: **PASS**
- Sensors: sentinel-1a · scenes: 21
- Valid district coverage: 100.0% · reliable (≥3 clear obs): 100.0%
- Median clear observations per pixel: 7 · mean clear fraction of observations: 100.0%
- Permanent-water negative control (share of JRC permanent-water cells with MNDWI>0): n/a
- Residual-cloud check (valid pixels with blue SR > 0.15): n/a
- Reasons: none

**wet** — Status: **PASS**
- Sensors: sentinel-1a · scenes: 14
- Valid district coverage: 100.0% · reliable (≥3 clear obs): 29.4%
- Median clear observations per pixel: 2 · mean clear fraction of observations: 100.0%
- Permanent-water negative control (share of JRC permanent-water cells with MNDWI>0): n/a
- Residual-cloud check (valid pixels with blue SR > 0.15): n/a
- Reasons: none

### 2025

**2025-01** — Status: **PASS**
- Sensors: sentinel-1a · scenes: 9
- Valid district coverage: 100.0% · reliable (≥3 clear obs): 100.0%
- Median clear observations per pixel: 3 · mean clear fraction of observations: 100.0%
- Permanent-water negative control (share of JRC permanent-water cells with MNDWI>0): n/a
- Residual-cloud check (valid pixels with blue SR > 0.15): n/a
- Reasons: none

**2025-02** — Status: **PASS**
- Sensors: sentinel-1a · scenes: 6
- Valid district coverage: 100.0% · reliable (≥3 clear obs): 18.6%
- Median clear observations per pixel: 2 · mean clear fraction of observations: 100.0%
- Permanent-water negative control (share of JRC permanent-water cells with MNDWI>0): n/a
- Residual-cloud check (valid pixels with blue SR > 0.15): n/a
- Reasons: none

**2025-03** — Status: **PASS**
- Sensors: sentinel-1a · scenes: 8
- Valid district coverage: 100.0% · reliable (≥3 clear obs): 100.0%
- Median clear observations per pixel: 3 · mean clear fraction of observations: 100.0%
- Permanent-water negative control (share of JRC permanent-water cells with MNDWI>0): n/a
- Residual-cloud check (valid pixels with blue SR > 0.15): n/a
- Reasons: none

**2025-04** — Status: **PASS**
- Sensors: sentinel-1a · scenes: 7
- Valid district coverage: 100.0% · reliable (≥3 clear obs): 18.5%
- Median clear observations per pixel: 2 · mean clear fraction of observations: 100.0%
- Permanent-water negative control (share of JRC permanent-water cells with MNDWI>0): n/a
- Residual-cloud check (valid pixels with blue SR > 0.15): n/a
- Reasons: none

**2025-05** — Status: **PASS**
- Sensors: sentinel-1a · scenes: 9
- Valid district coverage: 100.0% · reliable (≥3 clear obs): 100.0%
- Median clear observations per pixel: 3 · mean clear fraction of observations: 100.0%
- Permanent-water negative control (share of JRC permanent-water cells with MNDWI>0): n/a
- Residual-cloud check (valid pixels with blue SR > 0.15): n/a
- Reasons: none

**2025-06** — Status: **PASS**
- Sensors: sentinel-1a · scenes: 6
- Valid district coverage: 100.0% · reliable (≥3 clear obs): 18.3%
- Median clear observations per pixel: 2 · mean clear fraction of observations: 100.0%
- Permanent-water negative control (share of JRC permanent-water cells with MNDWI>0): n/a
- Residual-cloud check (valid pixels with blue SR > 0.15): n/a
- Reasons: none

**2025-07** — Status: **PASS**
- Sensors: sentinel-1a · scenes: 9
- Valid district coverage: 100.0% · reliable (≥3 clear obs): 100.0%
- Median clear observations per pixel: 3 · mean clear fraction of observations: 100.0%
- Permanent-water negative control (share of JRC permanent-water cells with MNDWI>0): n/a
- Residual-cloud check (valid pixels with blue SR > 0.15): n/a
- Reasons: none

**2025-08** — Status: **PASS**
- Sensors: sentinel-1a · scenes: 7
- Valid district coverage: 100.0% · reliable (≥3 clear obs): 100.0%
- Median clear observations per pixel: 3 · mean clear fraction of observations: 100.0%
- Permanent-water negative control (share of JRC permanent-water cells with MNDWI>0): n/a
- Residual-cloud check (valid pixels with blue SR > 0.15): n/a
- Reasons: none

**2025-09** — Status: **PASS**
- Sensors: sentinel-1a · scenes: 7
- Valid district coverage: 100.0% · reliable (≥3 clear obs): 18.6%
- Median clear observations per pixel: 2 · mean clear fraction of observations: 100.0%
- Permanent-water negative control (share of JRC permanent-water cells with MNDWI>0): n/a
- Residual-cloud check (valid pixels with blue SR > 0.15): n/a
- Reasons: none

**2025-10** — Status: **PASS**
- Sensors: sentinel-1a · scenes: 8
- Valid district coverage: 100.0% · reliable (≥3 clear obs): 100.0%
- Median clear observations per pixel: 3 · mean clear fraction of observations: 100.0%
- Permanent-water negative control (share of JRC permanent-water cells with MNDWI>0): n/a
- Residual-cloud check (valid pixels with blue SR > 0.15): n/a
- Reasons: none

**2025-11** — Status: **PASS**
- Sensors: sentinel-1a · scenes: 7
- Valid district coverage: 100.0% · reliable (≥3 clear obs): 18.7%
- Median clear observations per pixel: 2 · mean clear fraction of observations: 100.0%
- Permanent-water negative control (share of JRC permanent-water cells with MNDWI>0): n/a
- Residual-cloud check (valid pixels with blue SR > 0.15): n/a
- Reasons: none

**2025-12** — Status: **PASS**
- Sensors: sentinel-1a · scenes: 8
- Valid district coverage: 100.0% · reliable (≥3 clear obs): 100.0%
- Median clear observations per pixel: 3 · mean clear fraction of observations: 100.0%
- Permanent-water negative control (share of JRC permanent-water cells with MNDWI>0): n/a
- Residual-cloud check (valid pixels with blue SR > 0.15): n/a
- Reasons: none

**annual** — Status: **PASS**
- Sensors: sentinel-1a · scenes: 91
- Valid district coverage: 100.0% · reliable (≥3 clear obs): 100.0%
- Median clear observations per pixel: 31 · mean clear fraction of observations: 100.0%
- Permanent-water negative control (share of JRC permanent-water cells with MNDWI>0): n/a
- Residual-cloud check (valid pixels with blue SR > 0.15): n/a
- Reasons: none

**dry** — Status: **PASS**
- Sensors: sentinel-1a · scenes: 39
- Valid district coverage: 100.0% · reliable (≥3 clear obs): 100.0%
- Median clear observations per pixel: 13 · mean clear fraction of observations: 100.0%
- Permanent-water negative control (share of JRC permanent-water cells with MNDWI>0): n/a
- Residual-cloud check (valid pixels with blue SR > 0.15): n/a
- Reasons: none

**post_monsoon** — Status: **PASS**
- Sensors: sentinel-1a · scenes: 23
- Valid district coverage: 100.0% · reliable (≥3 clear obs): 100.0%
- Median clear observations per pixel: 8 · mean clear fraction of observations: 100.0%
- Permanent-water negative control (share of JRC permanent-water cells with MNDWI>0): n/a
- Residual-cloud check (valid pixels with blue SR > 0.15): n/a
- Reasons: none

**wet** — Status: **PASS**
- Sensors: sentinel-1a · scenes: 29
- Valid district coverage: 100.0% · reliable (≥3 clear obs): 100.0%
- Median clear observations per pixel: 10 · mean clear fraction of observations: 100.0%
- Permanent-water negative control (share of JRC permanent-water cells with MNDWI>0): n/a
- Residual-cloud check (valid pixels with blue SR > 0.15): n/a
- Reasons: none

### 2026

**2026-01** — Status: **PASS**
- Sensors: sentinel-1a · scenes: 7
- Valid district coverage: 100.0% · reliable (≥3 clear obs): 18.6%
- Median clear observations per pixel: 2 · mean clear fraction of observations: 100.0%
- Permanent-water negative control (share of JRC permanent-water cells with MNDWI>0): n/a
- Residual-cloud check (valid pixels with blue SR > 0.15): n/a
- Reasons: none

**2026-02** — Status: **PASS**
- Sensors: sentinel-1a · scenes: 5
- Valid district coverage: 100.0% · reliable (≥3 clear obs): 18.6%
- Median clear observations per pixel: 2 · mean clear fraction of observations: 100.0%
- Permanent-water negative control (share of JRC permanent-water cells with MNDWI>0): n/a
- Residual-cloud check (valid pixels with blue SR > 0.15): n/a
- Reasons: none

**2026-03** — Status: **PASS**
- Sensors: sentinel-1a · scenes: 7
- Valid district coverage: 100.0% · reliable (≥3 clear obs): 18.5%
- Median clear observations per pixel: 2 · mean clear fraction of observations: 100.0%
- Permanent-water negative control (share of JRC permanent-water cells with MNDWI>0): n/a
- Residual-cloud check (valid pixels with blue SR > 0.15): n/a
- Reasons: none

**2026-04** — Status: **PASS**
- Sensors: sentinel-1a · scenes: 8
- Valid district coverage: 100.0% · reliable (≥3 clear obs): 100.0%
- Median clear observations per pixel: 3 · mean clear fraction of observations: 100.0%
- Permanent-water negative control (share of JRC permanent-water cells with MNDWI>0): n/a
- Residual-cloud check (valid pixels with blue SR > 0.15): n/a
- Reasons: none

**2026-05** — Status: **PASS**
- Sensors: sentinel-1a · scenes: 10
- Valid district coverage: 100.0% · reliable (≥3 clear obs): 18.4%
- Median clear observations per pixel: 2 · mean clear fraction of observations: 100.0%
- Permanent-water negative control (share of JRC permanent-water cells with MNDWI>0): n/a
- Residual-cloud check (valid pixels with blue SR > 0.15): n/a
- Reasons: none

**2026-06** — Status: **PASS**
- Sensors: sentinel-1a,sentinel-1d · scenes: 12
- Valid district coverage: 100.0% · reliable (≥3 clear obs): 100.0%
- Median clear observations per pixel: 3 · mean clear fraction of observations: 100.0%
- Permanent-water negative control (share of JRC permanent-water cells with MNDWI>0): n/a
- Residual-cloud check (valid pixels with blue SR > 0.15): n/a
- Reasons: none

**2026-07** — Status: **PASS**
- Sensors: sentinel-1d · scenes: 10
- Valid district coverage: 100.0% · reliable (≥3 clear obs): 100.0%
- Median clear observations per pixel: 3 · mean clear fraction of observations: 100.0%
- Permanent-water negative control (share of JRC permanent-water cells with MNDWI>0): n/a
- Residual-cloud check (valid pixels with blue SR > 0.15): n/a
- Reasons: none

**2026-08** — Status: **PASS**
- Sensors: sentinel-1d · scenes: 10
- Valid district coverage: 100.0% · reliable (≥3 clear obs): 18.6%
- Median clear observations per pixel: 2 · mean clear fraction of observations: 100.0%
- Permanent-water negative control (share of JRC permanent-water cells with MNDWI>0): n/a
- Residual-cloud check (valid pixels with blue SR > 0.15): n/a
- Reasons: none

**2026-09** — Status: **PASS**
- Sensors: sentinel-1d · scenes: 12
- Valid district coverage: 100.0% · reliable (≥3 clear obs): 100.0%
- Median clear observations per pixel: 3 · mean clear fraction of observations: 100.0%
- Permanent-water negative control (share of JRC permanent-water cells with MNDWI>0): n/a
- Residual-cloud check (valid pixels with blue SR > 0.15): n/a
- Reasons: none

**2026-10** — Status: **IN_PROGRESS** (PARTIAL)
- Sensors: — · scenes: 0
- Valid district coverage: 0.0% · reliable (≥3 clear obs): 0.0%
- Median clear observations per pixel: 0 · mean clear fraction of observations: 0.0%
- Permanent-water negative control (share of JRC permanent-water cells with MNDWI>0): n/a
- Residual-cloud check (valid pixels with blue SR > 0.15): n/a
- Reasons: period in progress at the archive cut-off 2026-10-01 20:08 with no acquisitions yet - nothing to assess

**2026-11** — Status: **IN_PROGRESS** (PARTIAL)
- Sensors: — · scenes: 0
- Valid district coverage: 0.0% · reliable (≥3 clear obs): 0.0%
- Median clear observations per pixel: 0 · mean clear fraction of observations: 0.0%
- Permanent-water negative control (share of JRC permanent-water cells with MNDWI>0): n/a
- Residual-cloud check (valid pixels with blue SR > 0.15): n/a
- Reasons: period in progress at the archive cut-off 2026-10-01 20:08 with no acquisitions yet - nothing to assess

**2026-12** — Status: **IN_PROGRESS** (PARTIAL)
- Sensors: — · scenes: 0
- Valid district coverage: 0.0% · reliable (≥3 clear obs): 0.0%
- Median clear observations per pixel: 0 · mean clear fraction of observations: 0.0%
- Permanent-water negative control (share of JRC permanent-water cells with MNDWI>0): n/a
- Residual-cloud check (valid pixels with blue SR > 0.15): n/a
- Reasons: period in progress at the archive cut-off 2026-10-01 20:08 with no acquisitions yet - nothing to assess

**annual** — Status: **WARNING** (PARTIAL)
- Sensors: sentinel-1a,sentinel-1d · scenes: 81
- Valid district coverage: 100.0% · reliable (≥3 clear obs): 100.0%
- Median clear observations per pixel: 22 · mean clear fraction of observations: 100.0%
- Permanent-water negative control (share of JRC permanent-water cells with MNDWI>0): n/a
- Residual-cloud check (valid pixels with blue SR > 0.15): n/a
- Reasons: PARTIAL period: archive cut-off 2026-10-01

**dry** — Status: **PASS**
- Sensors: sentinel-1a · scenes: 37
- Valid district coverage: 100.0% · reliable (≥3 clear obs): 100.0%
- Median clear observations per pixel: 11 · mean clear fraction of observations: 100.0%
- Permanent-water negative control (share of JRC permanent-water cells with MNDWI>0): n/a
- Residual-cloud check (valid pixels with blue SR > 0.15): n/a
- Reasons: none

**post_monsoon** — Status: **IN_PROGRESS** (PARTIAL)
- Sensors: — · scenes: 0
- Valid district coverage: 0.0% · reliable (≥3 clear obs): 0.0%
- Median clear observations per pixel: 0 · mean clear fraction of observations: 0.0%
- Permanent-water negative control (share of JRC permanent-water cells with MNDWI>0): n/a
- Residual-cloud check (valid pixels with blue SR > 0.15): n/a
- Reasons: period in progress at the archive cut-off 2026-10-01 20:08 with no acquisitions yet - nothing to assess

**wet** — Status: **PASS**
- Sensors: sentinel-1a,sentinel-1d · scenes: 44
- Valid district coverage: 100.0% · reliable (≥3 clear obs): 100.0%
- Median clear observations per pixel: 11 · mean clear fraction of observations: 100.0%
- Permanent-water negative control (share of JRC permanent-water cells with MNDWI>0): n/a
- Residual-cloud check (valid pixels with blue SR > 0.15): n/a
- Reasons: none
