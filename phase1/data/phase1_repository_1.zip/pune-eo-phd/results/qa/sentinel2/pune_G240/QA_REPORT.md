# Pune EO Data QA Report — sentinel2 — grid `pune_G240`

Generated automatically by `pune-eo qa`. Thresholds: `configs/qa.yaml`. Every product's full QA record is
also written into its own `metadata.json` (`qa` block).

## Summary

| period       |   FAIL |   IN_PROGRESS |   PASS |   WARNING |
|:-------------|-------:|--------------:|-------:|----------:|
| 2018-01      |      0 |             0 |      1 |         0 |
| 2018-02      |      0 |             0 |      1 |         0 |
| 2018-03      |      0 |             0 |      1 |         0 |
| 2018-04      |      0 |             0 |      1 |         0 |
| 2018-05      |      0 |             0 |      1 |         0 |
| 2018-06      |      0 |             0 |      0 |         1 |
| 2018-07      |      1 |             0 |      0 |         0 |
| 2018-08      |      1 |             0 |      0 |         0 |
| 2018-09      |      0 |             0 |      0 |         1 |
| 2018-10      |      0 |             0 |      1 |         0 |
| 2018-11      |      0 |             0 |      1 |         0 |
| 2018-12      |      0 |             0 |      1 |         0 |
| 2019-01      |      0 |             0 |      1 |         0 |
| 2019-02      |      0 |             0 |      1 |         0 |
| 2019-03      |      0 |             0 |      1 |         0 |
| 2019-04      |      0 |             0 |      1 |         0 |
| 2019-05      |      0 |             0 |      1 |         0 |
| 2019-06      |      0 |             0 |      0 |         1 |
| 2019-07      |      0 |             0 |      0 |         1 |
| 2019-08      |      1 |             0 |      0 |         0 |
| 2019-09      |      1 |             0 |      0 |         0 |
| 2019-10      |      0 |             0 |      0 |         1 |
| 2019-11      |      0 |             0 |      1 |         0 |
| 2019-12      |      0 |             0 |      1 |         0 |
| 2020-01      |      0 |             0 |      1 |         0 |
| 2020-02      |      0 |             0 |      1 |         0 |
| 2020-03      |      0 |             0 |      1 |         0 |
| 2020-04      |      0 |             0 |      1 |         0 |
| 2020-05      |      0 |             0 |      1 |         0 |
| 2020-06      |      0 |             0 |      0 |         1 |
| 2020-07      |      1 |             0 |      0 |         0 |
| 2020-08      |      1 |             0 |      0 |         0 |
| 2020-09      |      0 |             0 |      0 |         1 |
| 2020-10      |      0 |             0 |      1 |         0 |
| 2020-11      |      0 |             0 |      0 |         1 |
| 2020-12      |      0 |             0 |      0 |         1 |
| 2021-01      |      0 |             0 |      1 |         0 |
| 2021-02      |      0 |             0 |      1 |         0 |
| 2021-03      |      0 |             0 |      1 |         0 |
| 2021-04      |      0 |             0 |      1 |         0 |
| 2021-05      |      0 |             0 |      1 |         0 |
| 2021-06      |      1 |             0 |      0 |         0 |
| 2021-07      |      1 |             0 |      0 |         0 |
| 2021-08      |      1 |             0 |      0 |         0 |
| 2021-09      |      1 |             0 |      0 |         0 |
| 2021-10      |      0 |             0 |      0 |         1 |
| 2021-11      |      1 |             0 |      0 |         0 |
| 2021-12      |      0 |             0 |      0 |         1 |
| 2022-01      |      0 |             0 |      1 |         0 |
| 2022-02      |      0 |             0 |      1 |         0 |
| 2022-03      |      0 |             0 |      1 |         0 |
| 2022-04      |      0 |             0 |      0 |         1 |
| 2022-05      |      0 |             0 |      0 |         1 |
| 2022-06      |      0 |             0 |      0 |         1 |
| 2022-07      |      1 |             0 |      0 |         0 |
| 2022-08      |      1 |             0 |      0 |         0 |
| 2022-09      |      1 |             0 |      0 |         0 |
| 2022-10      |      0 |             0 |      1 |         0 |
| 2022-11      |      0 |             0 |      1 |         0 |
| 2022-12      |      0 |             0 |      1 |         0 |
| 2023-01      |      0 |             0 |      1 |         0 |
| 2023-02      |      0 |             0 |      1 |         0 |
| 2023-03      |      0 |             0 |      1 |         0 |
| 2023-04      |      0 |             0 |      1 |         0 |
| 2023-05      |      0 |             0 |      1 |         0 |
| 2023-06      |      0 |             0 |      1 |         0 |
| 2023-07      |      1 |             0 |      0 |         0 |
| 2023-08      |      1 |             0 |      0 |         0 |
| 2023-09      |      0 |             0 |      0 |         1 |
| 2023-10      |      0 |             0 |      1 |         0 |
| 2023-11      |      0 |             0 |      0 |         1 |
| 2023-12      |      0 |             0 |      1 |         0 |
| 2024-01      |      0 |             0 |      1 |         0 |
| 2024-02      |      0 |             0 |      1 |         0 |
| 2024-03      |      0 |             0 |      1 |         0 |
| 2024-04      |      0 |             0 |      1 |         0 |
| 2024-05      |      0 |             0 |      1 |         0 |
| 2024-06      |      0 |             0 |      0 |         1 |
| 2024-07      |      1 |             0 |      0 |         0 |
| 2024-08      |      1 |             0 |      0 |         0 |
| 2024-09      |      0 |             0 |      0 |         1 |
| 2024-10      |      0 |             0 |      0 |         1 |
| 2024-11      |      0 |             0 |      1 |         0 |
| 2024-12      |      0 |             0 |      1 |         0 |
| 2025-01      |      0 |             0 |      1 |         0 |
| 2025-02      |      0 |             0 |      1 |         0 |
| 2025-03      |      0 |             0 |      1 |         0 |
| 2025-04      |      0 |             0 |      1 |         0 |
| 2025-05      |      0 |             0 |      1 |         0 |
| 2025-06      |      0 |             0 |      0 |         1 |
| 2025-07      |      1 |             0 |      0 |         0 |
| 2025-08      |      1 |             0 |      0 |         0 |
| 2025-09      |      1 |             0 |      0 |         0 |
| 2025-10      |      0 |             0 |      1 |         0 |
| 2025-11      |      0 |             0 |      1 |         0 |
| 2025-12      |      0 |             0 |      1 |         0 |
| 2026-01      |      0 |             0 |      1 |         0 |
| 2026-02      |      0 |             0 |      1 |         0 |
| 2026-03      |      0 |             0 |      1 |         0 |
| 2026-04      |      0 |             0 |      1 |         0 |
| 2026-05      |      0 |             0 |      1 |         0 |
| 2026-06      |      0 |             0 |      0 |         1 |
| 2026-07      |      0 |             0 |      0 |         1 |
| 2026-08      |      1 |             0 |      0 |         0 |
| 2026-09      |      0 |             0 |      0 |         1 |
| 2026-10      |      0 |             1 |      0 |         0 |
| 2026-11      |      0 |             1 |      0 |         0 |
| 2026-12      |      0 |             1 |      0 |         0 |
| annual       |      0 |             0 |      8 |         1 |
| dry          |      0 |             0 |      9 |         0 |
| post_monsoon |      0 |             1 |      7 |         1 |
| wet          |      0 |             0 |      3 |         6 |

## Per-year records

### 2018

**2018-01** — Status: **PASS**
- Sensors: sentinel-2a,sentinel-2b · scenes: 28
- Valid district coverage: 96.4% · reliable (≥3 clear obs): 85.3%
- Median clear observations per pixel: 4 · mean clear fraction of observations: 85.3%
- Permanent-water negative control (share of JRC permanent-water cells with MNDWI>0): 100%
- Residual-cloud check (valid pixels with blue SR > 0.15): 0.37%
- Reasons: none

**2018-02** — Status: **PASS**
- Sensors: sentinel-2a,sentinel-2b · scenes: 26
- Valid district coverage: 97.2% · reliable (≥3 clear obs): 82.5%
- Median clear observations per pixel: 4 · mean clear fraction of observations: 80.2%
- Permanent-water negative control (share of JRC permanent-water cells with MNDWI>0): 100%
- Residual-cloud check (valid pixels with blue SR > 0.15): 0.21%
- Reasons: none

**2018-03** — Status: **PASS**
- Sensors: sentinel-2a,sentinel-2b · scenes: 30
- Valid district coverage: 98.2% · reliable (≥3 clear obs): 92.0%
- Median clear observations per pixel: 4 · mean clear fraction of observations: 79.2%
- Permanent-water negative control (share of JRC permanent-water cells with MNDWI>0): 100%
- Residual-cloud check (valid pixels with blue SR > 0.15): 0.03%
- Reasons: none

**2018-04** — Status: **PASS**
- Sensors: sentinel-2a,sentinel-2b · scenes: 38
- Valid district coverage: 98.9% · reliable (≥3 clear obs): 96.9%
- Median clear observations per pixel: 5 · mean clear fraction of observations: 91.6%
- Permanent-water negative control (share of JRC permanent-water cells with MNDWI>0): 100%
- Residual-cloud check (valid pixels with blue SR > 0.15): 0.04%
- Reasons: none

**2018-05** — Status: **PASS**
- Sensors: sentinel-2a,sentinel-2b · scenes: 40
- Valid district coverage: 99.5% · reliable (≥3 clear obs): 95.9%
- Median clear observations per pixel: 5 · mean clear fraction of observations: 73.8%
- Permanent-water negative control (share of JRC permanent-water cells with MNDWI>0): 100%
- Residual-cloud check (valid pixels with blue SR > 0.15): 0.1%
- Reasons: none

**2018-06** — Status: **WARNING**
- Sensors: sentinel-2a,sentinel-2b · scenes: 20
- Valid district coverage: 60.6% · reliable (≥3 clear obs): 9.8%
- Median clear observations per pixel: 1 · mean clear fraction of observations: 33.0%
- Permanent-water negative control (share of JRC permanent-water cells with MNDWI>0): 98%
- Residual-cloud check (valid pixels with blue SR > 0.15): 1.91%
- Reasons: district valid coverage 60.6% < 95% | median clear observations 1 < 3 (composite statistically weak) | 35% of district from a single observation | possible residual cloud/haze: 1.9% of valid pixels transiently bright (blue SR > 0.15)

**2018-07** — Status: **FAIL**
- Sensors: — · scenes: 0
- Valid district coverage: 0.0% · reliable (≥3 clear obs): 0.0%
- Median clear observations per pixel: 0 · mean clear fraction of observations: 0.0%
- Permanent-water negative control (share of JRC permanent-water cells with MNDWI>0): n/a
- Residual-cloud check (valid pixels with blue SR > 0.15): n/a
- Reasons: district valid coverage 0.0% < 50% | median clear observations 0 < 3 (composite statistically weak)

**2018-08** — Status: **FAIL**
- Sensors: sentinel-2a · scenes: 2
- Valid district coverage: 0.1% · reliable (≥3 clear obs): 0.0%
- Median clear observations per pixel: 0 · mean clear fraction of observations: 1.6%
- Permanent-water negative control (share of JRC permanent-water cells with MNDWI>0): n/a
- Residual-cloud check (valid pixels with blue SR > 0.15): 5.6%
- Reasons: district valid coverage 0.1% < 50% | median clear observations 0 < 3 (composite statistically weak) | possible residual cloud/haze: 5.6% of valid pixels transiently bright (blue SR > 0.15)

**2018-09** — Status: **WARNING**
- Sensors: sentinel-2a,sentinel-2b · scenes: 26
- Valid district coverage: 85.0% · reliable (≥3 clear obs): 16.5%
- Median clear observations per pixel: 2 · mean clear fraction of observations: 41.1%
- Permanent-water negative control (share of JRC permanent-water cells with MNDWI>0): 100%
- Residual-cloud check (valid pixels with blue SR > 0.15): 0.25%
- Reasons: district valid coverage 85.0% < 95% | median clear observations 2 < 3 (composite statistically weak) | 32% of district from a single observation

**2018-10** — Status: **PASS**
- Sensors: sentinel-2a,sentinel-2b · scenes: 40
- Valid district coverage: 96.6% · reliable (≥3 clear obs): 91.7%
- Median clear observations per pixel: 5 · mean clear fraction of observations: 77.1%
- Permanent-water negative control (share of JRC permanent-water cells with MNDWI>0): 100%
- Residual-cloud check (valid pixels with blue SR > 0.15): 0.03%
- Reasons: none

**2018-11** — Status: **PASS**
- Sensors: sentinel-2a,sentinel-2b · scenes: 40
- Valid district coverage: 96.2% · reliable (≥3 clear obs): 88.7%
- Median clear observations per pixel: 5 · mean clear fraction of observations: 73.2%
- Permanent-water negative control (share of JRC permanent-water cells with MNDWI>0): 100%
- Residual-cloud check (valid pixels with blue SR > 0.15): 0.01%
- Reasons: none

**2018-12** — Status: **PASS**
- Sensors: sentinel-2a,sentinel-2b · scenes: 48
- Valid district coverage: 96.6% · reliable (≥3 clear obs): 87.8%
- Median clear observations per pixel: 6 · mean clear fraction of observations: 74.3%
- Permanent-water negative control (share of JRC permanent-water cells with MNDWI>0): 100%
- Residual-cloud check (valid pixels with blue SR > 0.15): 0.06%
- Reasons: none

**annual** — Status: **PASS**
- Sensors: sentinel-2a,sentinel-2b · scenes: 338
- Valid district coverage: 100.0% · reliable (≥3 clear obs): 99.8%
- Median clear observations per pixel: 39 · mean clear fraction of observations: 73.7%
- Permanent-water negative control (share of JRC permanent-water cells with MNDWI>0): 100%
- Residual-cloud check (valid pixels with blue SR > 0.15): 0.01%
- Reasons: none

**dry** — Status: **PASS**
- Sensors: sentinel-2a,sentinel-2b · scenes: 162
- Valid district coverage: 99.9% · reliable (≥3 clear obs): 99.6%
- Median clear observations per pixel: 21 · mean clear fraction of observations: 81.7%
- Permanent-water negative control (share of JRC permanent-water cells with MNDWI>0): 100%
- Residual-cloud check (valid pixels with blue SR > 0.15): 0.02%
- Reasons: none

**post_monsoon** — Status: **PASS**
- Sensors: sentinel-2a,sentinel-2b · scenes: 128
- Valid district coverage: 99.1% · reliable (≥3 clear obs): 97.4%
- Median clear observations per pixel: 16 · mean clear fraction of observations: 74.8%
- Permanent-water negative control (share of JRC permanent-water cells with MNDWI>0): 100%
- Residual-cloud check (valid pixels with blue SR > 0.15): 0.01%
- Reasons: none

**wet** — Status: **WARNING**
- Sensors: sentinel-2a,sentinel-2b · scenes: 48
- Valid district coverage: 93.2% · reliable (≥3 clear obs): 47.7%
- Median clear observations per pixel: 2 · mean clear fraction of observations: 37.9%
- Permanent-water negative control (share of JRC permanent-water cells with MNDWI>0): 100%
- Residual-cloud check (valid pixels with blue SR > 0.15): 0.42%
- Reasons: district valid coverage 93.2% < 95% | median clear observations 2 < 3 (composite statistically weak)

### 2019

**2019-01** — Status: **PASS**
- Sensors: sentinel-2a,sentinel-2b · scenes: 42
- Valid district coverage: 95.6% · reliable (≥3 clear obs): 89.5%
- Median clear observations per pixel: 6 · mean clear fraction of observations: 84.0%
- Permanent-water negative control (share of JRC permanent-water cells with MNDWI>0): 100%
- Residual-cloud check (valid pixels with blue SR > 0.15): 0.0%
- Reasons: none

**2019-02** — Status: **PASS**
- Sensors: sentinel-2a,sentinel-2b · scenes: 33
- Valid district coverage: 96.2% · reliable (≥3 clear obs): 89.4%
- Median clear observations per pixel: 5 · mean clear fraction of observations: 84.3%
- Permanent-water negative control (share of JRC permanent-water cells with MNDWI>0): 100%
- Residual-cloud check (valid pixels with blue SR > 0.15): 0.01%
- Reasons: none

**2019-03** — Status: **PASS**
- Sensors: sentinel-2a,sentinel-2b · scenes: 49
- Valid district coverage: 99.4% · reliable (≥3 clear obs): 97.1%
- Median clear observations per pixel: 7 · mean clear fraction of observations: 89.6%
- Permanent-water negative control (share of JRC permanent-water cells with MNDWI>0): 100%
- Residual-cloud check (valid pixels with blue SR > 0.15): 0.02%
- Reasons: none

**2019-04** — Status: **PASS**
- Sensors: sentinel-2a,sentinel-2b · scenes: 42
- Valid district coverage: 99.2% · reliable (≥3 clear obs): 97.3%
- Median clear observations per pixel: 5 · mean clear fraction of observations: 86.1%
- Permanent-water negative control (share of JRC permanent-water cells with MNDWI>0): 100%
- Residual-cloud check (valid pixels with blue SR > 0.15): 0.04%
- Reasons: none

**2019-05** — Status: **PASS**
- Sensors: sentinel-2a,sentinel-2b · scenes: 42
- Valid district coverage: 99.2% · reliable (≥3 clear obs): 97.7%
- Median clear observations per pixel: 6 · mean clear fraction of observations: 95.5%
- Permanent-water negative control (share of JRC permanent-water cells with MNDWI>0): 99%
- Residual-cloud check (valid pixels with blue SR > 0.15): 0.12%
- Reasons: none

**2019-06** — Status: **WARNING**
- Sensors: sentinel-2a,sentinel-2b · scenes: 20
- Valid district coverage: 76.3% · reliable (≥3 clear obs): 14.0%
- Median clear observations per pixel: 1 · mean clear fraction of observations: 35.8%
- Permanent-water negative control (share of JRC permanent-water cells with MNDWI>0): 98%
- Residual-cloud check (valid pixels with blue SR > 0.15): 3.21%
- Reasons: district valid coverage 76.3% < 95% | median clear observations 1 < 3 (composite statistically weak) | 37% of district from a single observation | possible residual cloud/haze: 3.2% of valid pixels transiently bright (blue SR > 0.15)

**2019-07** — Status: **WARNING**
- Sensors: sentinel-2a,sentinel-2b · scenes: 16
- Valid district coverage: 52.8% · reliable (≥3 clear obs): 0.6%
- Median clear observations per pixel: 1 · mean clear fraction of observations: 46.5%
- Permanent-water negative control (share of JRC permanent-water cells with MNDWI>0): 100%
- Residual-cloud check (valid pixels with blue SR > 0.15): 0.54%
- Reasons: district valid coverage 52.8% < 95% | median clear observations 1 < 3 (composite statistically weak) | 44% of district from a single observation

**2019-08** — Status: **FAIL**
- Sensors: sentinel-2a,sentinel-2b · scenes: 17
- Valid district coverage: 43.2% · reliable (≥3 clear obs): 1.9%
- Median clear observations per pixel: 0 · mean clear fraction of observations: 21.6%
- Permanent-water negative control (share of JRC permanent-water cells with MNDWI>0): 100%
- Residual-cloud check (valid pixels with blue SR > 0.15): 1.16%
- Reasons: district valid coverage 43.2% < 50% | median clear observations 0 < 3 (composite statistically weak) | 31% of district from a single observation | possible residual cloud/haze: 1.2% of valid pixels transiently bright (blue SR > 0.15)

**2019-09** — Status: **FAIL**
- Sensors: sentinel-2a,sentinel-2b · scenes: 15
- Valid district coverage: 39.0% · reliable (≥3 clear obs): 1.3%
- Median clear observations per pixel: 0 · mean clear fraction of observations: 26.2%
- Permanent-water negative control (share of JRC permanent-water cells with MNDWI>0): 100%
- Residual-cloud check (valid pixels with blue SR > 0.15): 0.43%
- Reasons: district valid coverage 39.0% < 50% | median clear observations 0 < 3 (composite statistically weak) | 31% of district from a single observation

**2019-10** — Status: **WARNING**
- Sensors: sentinel-2a,sentinel-2b · scenes: 35
- Valid district coverage: 91.6% · reliable (≥3 clear obs): 55.3%
- Median clear observations per pixel: 3 · mean clear fraction of observations: 49.0%
- Permanent-water negative control (share of JRC permanent-water cells with MNDWI>0): 100%
- Residual-cloud check (valid pixels with blue SR > 0.15): 0.33%
- Reasons: district valid coverage 91.6% < 95%

**2019-11** — Status: **PASS**
- Sensors: sentinel-2a,sentinel-2b · scenes: 36
- Valid district coverage: 96.0% · reliable (≥3 clear obs): 76.4%
- Median clear observations per pixel: 4 · mean clear fraction of observations: 62.4%
- Permanent-water negative control (share of JRC permanent-water cells with MNDWI>0): 100%
- Residual-cloud check (valid pixels with blue SR > 0.15): 0.06%
- Reasons: none

**2019-12** — Status: **PASS**
- Sensors: sentinel-2a,sentinel-2b · scenes: 45
- Valid district coverage: 96.3% · reliable (≥3 clear obs): 85.8%
- Median clear observations per pixel: 5 · mean clear fraction of observations: 62.1%
- Permanent-water negative control (share of JRC permanent-water cells with MNDWI>0): 100%
- Residual-cloud check (valid pixels with blue SR > 0.15): 0.32%
- Reasons: none

**annual** — Status: **PASS**
- Sensors: sentinel-2a,sentinel-2b · scenes: 392
- Valid district coverage: 100.0% · reliable (≥3 clear obs): 99.8%
- Median clear observations per pixel: 41 · mean clear fraction of observations: 70.0%
- Permanent-water negative control (share of JRC permanent-water cells with MNDWI>0): 100%
- Residual-cloud check (valid pixels with blue SR > 0.15): 0.01%
- Reasons: none

**dry** — Status: **PASS**
- Sensors: sentinel-2a,sentinel-2b · scenes: 208
- Valid district coverage: 99.9% · reliable (≥3 clear obs): 99.6%
- Median clear observations per pixel: 28 · mean clear fraction of observations: 88.2%
- Permanent-water negative control (share of JRC permanent-water cells with MNDWI>0): 100%
- Residual-cloud check (valid pixels with blue SR > 0.15): 0.0%
- Reasons: none

**post_monsoon** — Status: **PASS**
- Sensors: sentinel-2a,sentinel-2b · scenes: 116
- Valid district coverage: 98.8% · reliable (≥3 clear obs): 96.0%
- Median clear observations per pixel: 11 · mean clear fraction of observations: 58.1%
- Permanent-water negative control (share of JRC permanent-water cells with MNDWI>0): 100%
- Residual-cloud check (valid pixels with blue SR > 0.15): 0.07%
- Reasons: none

**wet** — Status: **WARNING**
- Sensors: sentinel-2a,sentinel-2b · scenes: 68
- Valid district coverage: 95.0% · reliable (≥3 clear obs): 56.1%
- Median clear observations per pixel: 3 · mean clear fraction of observations: 30.5%
- Permanent-water negative control (share of JRC permanent-water cells with MNDWI>0): 99%
- Residual-cloud check (valid pixels with blue SR > 0.15): 0.96%
- Reasons: district valid coverage 95.0% < 95%

### 2020

**2020-01** — Status: **PASS**
- Sensors: sentinel-2a,sentinel-2b · scenes: 40
- Valid district coverage: 95.9% · reliable (≥3 clear obs): 87.5%
- Median clear observations per pixel: 5 · mean clear fraction of observations: 70.4%
- Permanent-water negative control (share of JRC permanent-water cells with MNDWI>0): 100%
- Residual-cloud check (valid pixels with blue SR > 0.15): 0.2%
- Reasons: none

**2020-02** — Status: **PASS**
- Sensors: sentinel-2a,sentinel-2b · scenes: 40
- Valid district coverage: 97.8% · reliable (≥3 clear obs): 92.8%
- Median clear observations per pixel: 5 · mean clear fraction of observations: 80.4%
- Permanent-water negative control (share of JRC permanent-water cells with MNDWI>0): 100%
- Residual-cloud check (valid pixels with blue SR > 0.15): 0.06%
- Reasons: none

**2020-03** — Status: **PASS**
- Sensors: sentinel-2a,sentinel-2b · scenes: 42
- Valid district coverage: 98.3% · reliable (≥3 clear obs): 95.0%
- Median clear observations per pixel: 6 · mean clear fraction of observations: 85.3%
- Permanent-water negative control (share of JRC permanent-water cells with MNDWI>0): 100%
- Residual-cloud check (valid pixels with blue SR > 0.15): 0.04%
- Reasons: none

**2020-04** — Status: **PASS**
- Sensors: sentinel-2a,sentinel-2b · scenes: 42
- Valid district coverage: 98.4% · reliable (≥3 clear obs): 96.1%
- Median clear observations per pixel: 6 · mean clear fraction of observations: 92.2%
- Permanent-water negative control (share of JRC permanent-water cells with MNDWI>0): 100%
- Residual-cloud check (valid pixels with blue SR > 0.15): 0.07%
- Reasons: none

**2020-05** — Status: **PASS**
- Sensors: sentinel-2a,sentinel-2b · scenes: 35
- Valid district coverage: 98.1% · reliable (≥3 clear obs): 94.3%
- Median clear observations per pixel: 4 · mean clear fraction of observations: 81.0%
- Permanent-water negative control (share of JRC permanent-water cells with MNDWI>0): 100%
- Residual-cloud check (valid pixels with blue SR > 0.15): 0.12%
- Reasons: none

**2020-06** — Status: **WARNING**
- Sensors: sentinel-2a,sentinel-2b · scenes: 19
- Valid district coverage: 55.2% · reliable (≥3 clear obs): 5.3%
- Median clear observations per pixel: 1 · mean clear fraction of observations: 25.3%
- Permanent-water negative control (share of JRC permanent-water cells with MNDWI>0): 99%
- Residual-cloud check (valid pixels with blue SR > 0.15): 0.89%
- Reasons: district valid coverage 55.2% < 95% | median clear observations 1 < 3 (composite statistically weak) | 35% of district from a single observation

**2020-07** — Status: **FAIL**
- Sensors: sentinel-2a,sentinel-2b · scenes: 13
- Valid district coverage: 20.2% · reliable (≥3 clear obs): 0.3%
- Median clear observations per pixel: 0 · mean clear fraction of observations: 15.4%
- Permanent-water negative control (share of JRC permanent-water cells with MNDWI>0): 100%
- Residual-cloud check (valid pixels with blue SR > 0.15): 1.5%
- Reasons: district valid coverage 20.2% < 50% | median clear observations 0 < 3 (composite statistically weak) | possible residual cloud/haze: 1.5% of valid pixels transiently bright (blue SR > 0.15)

**2020-08** — Status: **FAIL**
- Sensors: sentinel-2a,sentinel-2b · scenes: 8
- Valid district coverage: 8.7% · reliable (≥3 clear obs): 0.0%
- Median clear observations per pixel: 0 · mean clear fraction of observations: 17.6%
- Permanent-water negative control (share of JRC permanent-water cells with MNDWI>0): 99%
- Residual-cloud check (valid pixels with blue SR > 0.15): 5.96%
- Reasons: district valid coverage 8.7% < 50% | median clear observations 0 < 3 (composite statistically weak) | possible residual cloud/haze: 6.0% of valid pixels transiently bright (blue SR > 0.15)

**2020-09** — Status: **WARNING**
- Sensors: sentinel-2a,sentinel-2b · scenes: 23
- Valid district coverage: 60.3% · reliable (≥3 clear obs): 6.5%
- Median clear observations per pixel: 1 · mean clear fraction of observations: 23.4%
- Permanent-water negative control (share of JRC permanent-water cells with MNDWI>0): 100%
- Residual-cloud check (valid pixels with blue SR > 0.15): 1.45%
- Reasons: district valid coverage 60.3% < 95% | median clear observations 1 < 3 (composite statistically weak) | 36% of district from a single observation | possible residual cloud/haze: 1.4% of valid pixels transiently bright (blue SR > 0.15)

**2020-10** — Status: **PASS**
- Sensors: sentinel-2a,sentinel-2b · scenes: 35
- Valid district coverage: 95.7% · reliable (≥3 clear obs): 68.9%
- Median clear observations per pixel: 3 · mean clear fraction of observations: 54.3%
- Permanent-water negative control (share of JRC permanent-water cells with MNDWI>0): 100%
- Residual-cloud check (valid pixels with blue SR > 0.15): 0.25%
- Reasons: none

**2020-11** — Status: **WARNING**
- Sensors: sentinel-2a,sentinel-2b · scenes: 42
- Valid district coverage: 94.1% · reliable (≥3 clear obs): 85.3%
- Median clear observations per pixel: 5 · mean clear fraction of observations: 72.3%
- Permanent-water negative control (share of JRC permanent-water cells with MNDWI>0): 100%
- Residual-cloud check (valid pixels with blue SR > 0.15): 0.01%
- Reasons: district valid coverage 94.1% < 95%

**2020-12** — Status: **WARNING**
- Sensors: sentinel-2a,sentinel-2b · scenes: 41
- Valid district coverage: 93.9% · reliable (≥3 clear obs): 83.0%
- Median clear observations per pixel: 5 · mean clear fraction of observations: 72.5%
- Permanent-water negative control (share of JRC permanent-water cells with MNDWI>0): 100%
- Residual-cloud check (valid pixels with blue SR > 0.15): 0.05%
- Reasons: district valid coverage 93.9% < 95%

**annual** — Status: **PASS**
- Sensors: sentinel-2a,sentinel-2b · scenes: 380
- Valid district coverage: 99.9% · reliable (≥3 clear obs): 99.5%
- Median clear observations per pixel: 41 · mean clear fraction of observations: 68.4%
- Permanent-water negative control (share of JRC permanent-water cells with MNDWI>0): 100%
- Residual-cloud check (valid pixels with blue SR > 0.15): 0.01%
- Reasons: none

**dry** — Status: **PASS**
- Sensors: sentinel-2a,sentinel-2b · scenes: 199
- Valid district coverage: 99.7% · reliable (≥3 clear obs): 99.1%
- Median clear observations per pixel: 26 · mean clear fraction of observations: 82.0%
- Permanent-water negative control (share of JRC permanent-water cells with MNDWI>0): 100%
- Residual-cloud check (valid pixels with blue SR > 0.15): 0.01%
- Reasons: none

**post_monsoon** — Status: **PASS**
- Sensors: sentinel-2a,sentinel-2b · scenes: 118
- Valid district coverage: 98.4% · reliable (≥3 clear obs): 95.6%
- Median clear observations per pixel: 13 · mean clear fraction of observations: 66.9%
- Permanent-water negative control (share of JRC permanent-water cells with MNDWI>0): 100%
- Residual-cloud check (valid pixels with blue SR > 0.15): 0.11%
- Reasons: none

**wet** — Status: **WARNING**
- Sensors: sentinel-2a,sentinel-2b · scenes: 63
- Valid district coverage: 83.9% · reliable (≥3 clear obs): 33.8%
- Median clear observations per pixel: 2 · mean clear fraction of observations: 22.5%
- Permanent-water negative control (share of JRC permanent-water cells with MNDWI>0): 100%
- Residual-cloud check (valid pixels with blue SR > 0.15): 0.9%
- Reasons: district valid coverage 83.9% < 95% | median clear observations 2 < 3 (composite statistically weak) | 26% of district from a single observation

### 2021

**2021-01** — Status: **PASS**
- Sensors: sentinel-2a,sentinel-2b · scenes: 37
- Valid district coverage: 97.2% · reliable (≥3 clear obs): 85.1%
- Median clear observations per pixel: 4 · mean clear fraction of observations: 65.3%
- Permanent-water negative control (share of JRC permanent-water cells with MNDWI>0): 100%
- Residual-cloud check (valid pixels with blue SR > 0.15): 0.68%
- Reasons: none

**2021-02** — Status: **PASS**
- Sensors: sentinel-2a,sentinel-2b · scenes: 42
- Valid district coverage: 97.1% · reliable (≥3 clear obs): 90.7%
- Median clear observations per pixel: 6 · mean clear fraction of observations: 83.7%
- Permanent-water negative control (share of JRC permanent-water cells with MNDWI>0): 100%
- Residual-cloud check (valid pixels with blue SR > 0.15): 0.19%
- Reasons: none

**2021-03** — Status: **PASS**
- Sensors: sentinel-2a,sentinel-2b · scenes: 42
- Valid district coverage: 99.0% · reliable (≥3 clear obs): 96.4%
- Median clear observations per pixel: 6 · mean clear fraction of observations: 91.4%
- Permanent-water negative control (share of JRC permanent-water cells with MNDWI>0): 100%
- Residual-cloud check (valid pixels with blue SR > 0.15): 0.03%
- Reasons: none

**2021-04** — Status: **PASS**
- Sensors: sentinel-2a,sentinel-2b · scenes: 42
- Valid district coverage: 99.0% · reliable (≥3 clear obs): 97.0%
- Median clear observations per pixel: 5 · mean clear fraction of observations: 83.9%
- Permanent-water negative control (share of JRC permanent-water cells with MNDWI>0): 84%
- Residual-cloud check (valid pixels with blue SR > 0.15): 0.06%
- Reasons: none

**2021-05** — Status: **PASS**
- Sensors: sentinel-2a,sentinel-2b · scenes: 34
- Valid district coverage: 96.9% · reliable (≥3 clear obs): 58.0%
- Median clear observations per pixel: 3 · mean clear fraction of observations: 56.6%
- Permanent-water negative control (share of JRC permanent-water cells with MNDWI>0): 93%
- Residual-cloud check (valid pixels with blue SR > 0.15): 0.29%
- Reasons: none

**2021-06** — Status: **FAIL**
- Sensors: sentinel-2a,sentinel-2b · scenes: 22
- Valid district coverage: 45.9% · reliable (≥3 clear obs): 3.9%
- Median clear observations per pixel: 0 · mean clear fraction of observations: 16.2%
- Permanent-water negative control (share of JRC permanent-water cells with MNDWI>0): 99%
- Residual-cloud check (valid pixels with blue SR > 0.15): 1.03%
- Reasons: district valid coverage 45.9% < 50% | median clear observations 0 < 3 (composite statistically weak) | 30% of district from a single observation | possible residual cloud/haze: 1.0% of valid pixels transiently bright (blue SR > 0.15)

**2021-07** — Status: **FAIL**
- Sensors: sentinel-2a,sentinel-2b · scenes: 13
- Valid district coverage: 11.4% · reliable (≥3 clear obs): 0.3%
- Median clear observations per pixel: 0 · mean clear fraction of observations: 13.4%
- Permanent-water negative control (share of JRC permanent-water cells with MNDWI>0): 100%
- Residual-cloud check (valid pixels with blue SR > 0.15): 2.52%
- Reasons: district valid coverage 11.4% < 50% | median clear observations 0 < 3 (composite statistically weak) | possible residual cloud/haze: 2.5% of valid pixels transiently bright (blue SR > 0.15)

**2021-08** — Status: **FAIL**
- Sensors: sentinel-2a,sentinel-2b · scenes: 11
- Valid district coverage: 3.2% · reliable (≥3 clear obs): 0.1%
- Median clear observations per pixel: 0 · mean clear fraction of observations: 3.3%
- Permanent-water negative control (share of JRC permanent-water cells with MNDWI>0): 100%
- Residual-cloud check (valid pixels with blue SR > 0.15): 4.31%
- Reasons: district valid coverage 3.2% < 50% | median clear observations 0 < 3 (composite statistically weak) | possible residual cloud/haze: 4.3% of valid pixels transiently bright (blue SR > 0.15)

**2021-09** — Status: **FAIL**
- Sensors: sentinel-2a,sentinel-2b · scenes: 11
- Valid district coverage: 13.3% · reliable (≥3 clear obs): 0.2%
- Median clear observations per pixel: 0 · mean clear fraction of observations: 8.1%
- Permanent-water negative control (share of JRC permanent-water cells with MNDWI>0): 99%
- Residual-cloud check (valid pixels with blue SR > 0.15): 2.72%
- Reasons: district valid coverage 13.3% < 50% | median clear observations 0 < 3 (composite statistically weak) | possible residual cloud/haze: 2.7% of valid pixels transiently bright (blue SR > 0.15)

**2021-10** — Status: **WARNING**
- Sensors: sentinel-2a,sentinel-2b · scenes: 48
- Valid district coverage: 82.8% · reliable (≥3 clear obs): 63.5%
- Median clear observations per pixel: 4 · mean clear fraction of observations: 41.5%
- Permanent-water negative control (share of JRC permanent-water cells with MNDWI>0): 100%
- Residual-cloud check (valid pixels with blue SR > 0.15): 0.14%
- Reasons: district valid coverage 82.8% < 95%

**2021-11** — Status: **FAIL**
- Sensors: sentinel-2a,sentinel-2b · scenes: 33
- Valid district coverage: 46.4% · reliable (≥3 clear obs): 9.4%
- Median clear observations per pixel: 0 · mean clear fraction of observations: 17.8%
- Permanent-water negative control (share of JRC permanent-water cells with MNDWI>0): 100%
- Residual-cloud check (valid pixels with blue SR > 0.15): 0.31%
- Reasons: district valid coverage 46.4% < 50% | median clear observations 0 < 3 (composite statistically weak)

**2021-12** — Status: **WARNING**
- Sensors: sentinel-2a,sentinel-2b · scenes: 34
- Valid district coverage: 54.3% · reliable (≥3 clear obs): 24.0%
- Median clear observations per pixel: 1 · mean clear fraction of observations: 30.1%
- Permanent-water negative control (share of JRC permanent-water cells with MNDWI>0): 100%
- Residual-cloud check (valid pixels with blue SR > 0.15): 1.51%
- Reasons: district valid coverage 54.3% < 95% | median clear observations 1 < 3 (composite statistically weak) | possible residual cloud/haze: 1.5% of valid pixels transiently bright (blue SR > 0.15)

**annual** — Status: **PASS**
- Sensors: sentinel-2a,sentinel-2b · scenes: 369
- Valid district coverage: 100.0% · reliable (≥3 clear obs): 99.7%
- Median clear observations per pixel: 29 · mean clear fraction of observations: 54.8%
- Permanent-water negative control (share of JRC permanent-water cells with MNDWI>0): 100%
- Residual-cloud check (valid pixels with blue SR > 0.15): 0.01%
- Reasons: none

**dry** — Status: **PASS**
- Sensors: sentinel-2a,sentinel-2b · scenes: 197
- Valid district coverage: 99.9% · reliable (≥3 clear obs): 99.4%
- Median clear observations per pixel: 23 · mean clear fraction of observations: 77.3%
- Permanent-water negative control (share of JRC permanent-water cells with MNDWI>0): 100%
- Residual-cloud check (valid pixels with blue SR > 0.15): 0.03%
- Reasons: none

**post_monsoon** — Status: **WARNING**
- Sensors: sentinel-2a,sentinel-2b · scenes: 115
- Valid district coverage: 88.0% · reliable (≥3 clear obs): 70.4%
- Median clear observations per pixel: 5 · mean clear fraction of observations: 31.9%
- Permanent-water negative control (share of JRC permanent-water cells with MNDWI>0): 100%
- Residual-cloud check (valid pixels with blue SR > 0.15): 0.29%
- Reasons: district valid coverage 88.0% < 95%

**wet** — Status: **WARNING**
- Sensors: sentinel-2a,sentinel-2b · scenes: 57
- Valid district coverage: 58.9% · reliable (≥3 clear obs): 9.6%
- Median clear observations per pixel: 1 · mean clear fraction of observations: 13.3%
- Permanent-water negative control (share of JRC permanent-water cells with MNDWI>0): 100%
- Residual-cloud check (valid pixels with blue SR > 0.15): 1.44%
- Reasons: district valid coverage 58.9% < 95% | median clear observations 1 < 3 (composite statistically weak) | 33% of district from a single observation | possible residual cloud/haze: 1.4% of valid pixels transiently bright (blue SR > 0.15)

### 2022

**2022-01** — Status: **PASS**
- Sensors: sentinel-2a,sentinel-2b · scenes: 33
- Valid district coverage: 97.3% · reliable (≥3 clear obs): 65.8%
- Median clear observations per pixel: 3 · mean clear fraction of observations: 54.8%
- Permanent-water negative control (share of JRC permanent-water cells with MNDWI>0): 100%
- Residual-cloud check (valid pixels with blue SR > 0.15): 0.08%
- Reasons: none

**2022-02** — Status: **PASS**
- Sensors: sentinel-2a,sentinel-2b · scenes: 42
- Valid district coverage: 97.4% · reliable (≥3 clear obs): 95.9%
- Median clear observations per pixel: 6 · mean clear fraction of observations: 94.9%
- Permanent-water negative control (share of JRC permanent-water cells with MNDWI>0): 100%
- Residual-cloud check (valid pixels with blue SR > 0.15): 0.0%
- Reasons: none

**2022-03** — Status: **PASS**
- Sensors: sentinel-2a,sentinel-2b · scenes: 34
- Valid district coverage: 99.6% · reliable (≥3 clear obs): 96.0%
- Median clear observations per pixel: 4 · mean clear fraction of observations: 72.7%
- Permanent-water negative control (share of JRC permanent-water cells with MNDWI>0): 100%
- Residual-cloud check (valid pixels with blue SR > 0.15): 0.05%
- Reasons: none

**2022-04** — Status: **WARNING**
- Sensors: sentinel-2a,sentinel-2b · scenes: 32
- Valid district coverage: 99.7% · reliable (≥3 clear obs): 94.6%
- Median clear observations per pixel: 4 · mean clear fraction of observations: 79.2%
- Permanent-water negative control (share of JRC permanent-water cells with MNDWI>0): 77%
- Residual-cloud check (valid pixels with blue SR > 0.15): 0.05%
- Reasons: negative control weak: 77% of permanent-water cells read as water

**2022-05** — Status: **WARNING**
- Sensors: sentinel-2a,sentinel-2b · scenes: 37
- Valid district coverage: 99.9% · reliable (≥3 clear obs): 92.0%
- Median clear observations per pixel: 4 · mean clear fraction of observations: 66.4%
- Permanent-water negative control (share of JRC permanent-water cells with MNDWI>0): 56%
- Residual-cloud check (valid pixels with blue SR > 0.15): 0.25%
- Reasons: negative control weak: 56% of permanent-water cells read as water

**2022-06** — Status: **WARNING**
- Sensors: sentinel-2a,sentinel-2b · scenes: 28
- Valid district coverage: 99.4% · reliable (≥3 clear obs): 33.4%
- Median clear observations per pixel: 2 · mean clear fraction of observations: 48.9%
- Permanent-water negative control (share of JRC permanent-water cells with MNDWI>0): 83%
- Residual-cloud check (valid pixels with blue SR > 0.15): 0.72%
- Reasons: median clear observations 2 < 3 (composite statistically weak) | 27% of district from a single observation

**2022-07** — Status: **FAIL**
- Sensors: sentinel-2a,sentinel-2b · scenes: 11
- Valid district coverage: 20.0% · reliable (≥3 clear obs): 0.5%
- Median clear observations per pixel: 0 · mean clear fraction of observations: 13.8%
- Permanent-water negative control (share of JRC permanent-water cells with MNDWI>0): 100%
- Residual-cloud check (valid pixels with blue SR > 0.15): 2.53%
- Reasons: district valid coverage 20.0% < 50% | median clear observations 0 < 3 (composite statistically weak) | possible residual cloud/haze: 2.5% of valid pixels transiently bright (blue SR > 0.15)

**2022-08** — Status: **FAIL**
- Sensors: sentinel-2b · scenes: 5
- Valid district coverage: 5.0% · reliable (≥3 clear obs): 0.0%
- Median clear observations per pixel: 0 · mean clear fraction of observations: 9.8%
- Permanent-water negative control (share of JRC permanent-water cells with MNDWI>0): 100%
- Residual-cloud check (valid pixels with blue SR > 0.15): 1.22%
- Reasons: district valid coverage 5.0% < 50% | median clear observations 0 < 3 (composite statistically weak) | possible residual cloud/haze: 1.2% of valid pixels transiently bright (blue SR > 0.15)

**2022-09** — Status: **FAIL**
- Sensors: sentinel-2a,sentinel-2b · scenes: 13
- Valid district coverage: 46.2% · reliable (≥3 clear obs): 1.1%
- Median clear observations per pixel: 0 · mean clear fraction of observations: 27.1%
- Permanent-water negative control (share of JRC permanent-water cells with MNDWI>0): 99%
- Residual-cloud check (valid pixels with blue SR > 0.15): 1.36%
- Reasons: district valid coverage 46.2% < 50% | median clear observations 0 < 3 (composite statistically weak) | 32% of district from a single observation | possible residual cloud/haze: 1.4% of valid pixels transiently bright (blue SR > 0.15)

**2022-10** — Status: **PASS**
- Sensors: sentinel-2a,sentinel-2b · scenes: 30
- Valid district coverage: 99.0% · reliable (≥3 clear obs): 57.7%
- Median clear observations per pixel: 3 · mean clear fraction of observations: 58.1%
- Permanent-water negative control (share of JRC permanent-water cells with MNDWI>0): 100%
- Residual-cloud check (valid pixels with blue SR > 0.15): 0.06%
- Reasons: none

**2022-11** — Status: **PASS**
- Sensors: sentinel-2a,sentinel-2b · scenes: 42
- Valid district coverage: 98.9% · reliable (≥3 clear obs): 98.0%
- Median clear observations per pixel: 5 · mean clear fraction of observations: 91.0%
- Permanent-water negative control (share of JRC permanent-water cells with MNDWI>0): 100%
- Residual-cloud check (valid pixels with blue SR > 0.15): 0.01%
- Reasons: none

**2022-12** — Status: **PASS**
- Sensors: sentinel-2a,sentinel-2b · scenes: 41
- Valid district coverage: 99.6% · reliable (≥3 clear obs): 99.1%
- Median clear observations per pixel: 5 · mean clear fraction of observations: 86.7%
- Permanent-water negative control (share of JRC permanent-water cells with MNDWI>0): 100%
- Residual-cloud check (valid pixels with blue SR > 0.15): 0.01%
- Reasons: none

**annual** — Status: **PASS**
- Sensors: sentinel-2a,sentinel-2b · scenes: 348
- Valid district coverage: 100.0% · reliable (≥3 clear obs): 100.0%
- Median clear observations per pixel: 36 · mean clear fraction of observations: 69.3%
- Permanent-water negative control (share of JRC permanent-water cells with MNDWI>0): 100%
- Residual-cloud check (valid pixels with blue SR > 0.15): 0.01%
- Reasons: none

**dry** — Status: **PASS**
- Sensors: sentinel-2a,sentinel-2b · scenes: 178
- Valid district coverage: 100.0% · reliable (≥3 clear obs): 99.9%
- Median clear observations per pixel: 21 · mean clear fraction of observations: 74.0%
- Permanent-water negative control (share of JRC permanent-water cells with MNDWI>0): 100%
- Residual-cloud check (valid pixels with blue SR > 0.15): 0.01%
- Reasons: none

**post_monsoon** — Status: **PASS**
- Sensors: sentinel-2a,sentinel-2b · scenes: 113
- Valid district coverage: 99.9% · reliable (≥3 clear obs): 99.7%
- Median clear observations per pixel: 13 · mean clear fraction of observations: 78.8%
- Permanent-water negative control (share of JRC permanent-water cells with MNDWI>0): 100%
- Residual-cloud check (valid pixels with blue SR > 0.15): 0.02%
- Reasons: none

**wet** — Status: **PASS**
- Sensors: sentinel-2a,sentinel-2b · scenes: 57
- Valid district coverage: 99.6% · reliable (≥3 clear obs): 60.5%
- Median clear observations per pixel: 3 · mean clear fraction of observations: 34.7%
- Permanent-water negative control (share of JRC permanent-water cells with MNDWI>0): 92%
- Residual-cloud check (valid pixels with blue SR > 0.15): 0.56%
- Reasons: none

### 2023

**2023-01** — Status: **PASS**
- Sensors: sentinel-2a,sentinel-2b · scenes: 39
- Valid district coverage: 99.6% · reliable (≥3 clear obs): 97.7%
- Median clear observations per pixel: 5 · mean clear fraction of observations: 95.0%
- Permanent-water negative control (share of JRC permanent-water cells with MNDWI>0): 100%
- Residual-cloud check (valid pixels with blue SR > 0.15): 0.0%
- Reasons: none

**2023-02** — Status: **PASS**
- Sensors: sentinel-2a,sentinel-2b · scenes: 36
- Valid district coverage: 98.2% · reliable (≥3 clear obs): 92.2%
- Median clear observations per pixel: 4 · mean clear fraction of observations: 89.8%
- Permanent-water negative control (share of JRC permanent-water cells with MNDWI>0): 100%
- Residual-cloud check (valid pixels with blue SR > 0.15): 0.0%
- Reasons: none

**2023-03** — Status: **PASS**
- Sensors: sentinel-2a,sentinel-2b · scenes: 37
- Valid district coverage: 99.7% · reliable (≥3 clear obs): 95.2%
- Median clear observations per pixel: 5 · mean clear fraction of observations: 85.0%
- Permanent-water negative control (share of JRC permanent-water cells with MNDWI>0): 100%
- Residual-cloud check (valid pixels with blue SR > 0.15): 0.18%
- Reasons: none

**2023-04** — Status: **PASS**
- Sensors: sentinel-2a,sentinel-2b · scenes: 40
- Valid district coverage: 99.1% · reliable (≥3 clear obs): 96.4%
- Median clear observations per pixel: 4 · mean clear fraction of observations: 73.2%
- Permanent-water negative control (share of JRC permanent-water cells with MNDWI>0): 99%
- Residual-cloud check (valid pixels with blue SR > 0.15): 0.07%
- Reasons: none

**2023-05** — Status: **PASS**
- Sensors: sentinel-2a,sentinel-2b · scenes: 33
- Valid district coverage: 99.4% · reliable (≥3 clear obs): 97.0%
- Median clear observations per pixel: 4 · mean clear fraction of observations: 86.2%
- Permanent-water negative control (share of JRC permanent-water cells with MNDWI>0): 97%
- Residual-cloud check (valid pixels with blue SR > 0.15): 0.26%
- Reasons: none

**2023-06** — Status: **PASS**
- Sensors: sentinel-2a,sentinel-2b · scenes: 35
- Valid district coverage: 97.8% · reliable (≥3 clear obs): 64.1%
- Median clear observations per pixel: 3 · mean clear fraction of observations: 54.3%
- Permanent-water negative control (share of JRC permanent-water cells with MNDWI>0): 96%
- Residual-cloud check (valid pixels with blue SR > 0.15): 0.64%
- Reasons: none

**2023-07** — Status: **FAIL**
- Sensors: sentinel-2b · scenes: 2
- Valid district coverage: 0.3% · reliable (≥3 clear obs): 0.0%
- Median clear observations per pixel: 0 · mean clear fraction of observations: 12.9%
- Permanent-water negative control (share of JRC permanent-water cells with MNDWI>0): 100%
- Residual-cloud check (valid pixels with blue SR > 0.15): 3.96%
- Reasons: district valid coverage 0.3% < 50% | median clear observations 0 < 3 (composite statistically weak) | possible residual cloud/haze: 4.0% of valid pixels transiently bright (blue SR > 0.15)

**2023-08** — Status: **FAIL**
- Sensors: sentinel-2a,sentinel-2b · scenes: 12
- Valid district coverage: 14.5% · reliable (≥3 clear obs): 0.7%
- Median clear observations per pixel: 0 · mean clear fraction of observations: 15.6%
- Permanent-water negative control (share of JRC permanent-water cells with MNDWI>0): 100%
- Residual-cloud check (valid pixels with blue SR > 0.15): 1.92%
- Reasons: district valid coverage 14.5% < 50% | median clear observations 0 < 3 (composite statistically weak) | possible residual cloud/haze: 1.9% of valid pixels transiently bright (blue SR > 0.15)

**2023-09** — Status: **WARNING**
- Sensors: sentinel-2a,sentinel-2b · scenes: 23
- Valid district coverage: 63.6% · reliable (≥3 clear obs): 8.3%
- Median clear observations per pixel: 1 · mean clear fraction of observations: 26.9%
- Permanent-water negative control (share of JRC permanent-water cells with MNDWI>0): 99%
- Residual-cloud check (valid pixels with blue SR > 0.15): 1.64%
- Reasons: district valid coverage 63.6% < 95% | median clear observations 1 < 3 (composite statistically weak) | 36% of district from a single observation | possible residual cloud/haze: 1.6% of valid pixels transiently bright (blue SR > 0.15)

**2023-10** — Status: **PASS**
- Sensors: sentinel-2a,sentinel-2b · scenes: 44
- Valid district coverage: 99.3% · reliable (≥3 clear obs): 95.4%
- Median clear observations per pixel: 5 · mean clear fraction of observations: 82.8%
- Permanent-water negative control (share of JRC permanent-water cells with MNDWI>0): 100%
- Residual-cloud check (valid pixels with blue SR > 0.15): 0.04%
- Reasons: none

**2023-11** — Status: **WARNING**
- Sensors: sentinel-2a,sentinel-2b · scenes: 35
- Valid district coverage: 97.4% · reliable (≥3 clear obs): 49.9%
- Median clear observations per pixel: 2 · mean clear fraction of observations: 49.9%
- Permanent-water negative control (share of JRC permanent-water cells with MNDWI>0): 100%
- Residual-cloud check (valid pixels with blue SR > 0.15): 0.05%
- Reasons: median clear observations 2 < 3 (composite statistically weak)

**2023-12** — Status: **PASS**
- Sensors: sentinel-2a,sentinel-2b · scenes: 36
- Valid district coverage: 99.8% · reliable (≥3 clear obs): 98.1%
- Median clear observations per pixel: 4 · mean clear fraction of observations: 82.3%
- Permanent-water negative control (share of JRC permanent-water cells with MNDWI>0): 100%
- Residual-cloud check (valid pixels with blue SR > 0.15): 0.01%
- Reasons: none

**annual** — Status: **PASS**
- Sensors: sentinel-2a,sentinel-2b · scenes: 372
- Valid district coverage: 100.0% · reliable (≥3 clear obs): 100.0%
- Median clear observations per pixel: 37 · mean clear fraction of observations: 72.8%
- Permanent-water negative control (share of JRC permanent-water cells with MNDWI>0): 100%
- Residual-cloud check (valid pixels with blue SR > 0.15): 0.03%
- Reasons: none

**dry** — Status: **PASS**
- Sensors: sentinel-2a,sentinel-2b · scenes: 185
- Valid district coverage: 100.0% · reliable (≥3 clear obs): 100.0%
- Median clear observations per pixel: 23 · mean clear fraction of observations: 85.5%
- Permanent-water negative control (share of JRC permanent-water cells with MNDWI>0): 100%
- Residual-cloud check (valid pixels with blue SR > 0.15): 0.02%
- Reasons: none

**post_monsoon** — Status: **PASS**
- Sensors: sentinel-2a,sentinel-2b · scenes: 115
- Valid district coverage: 100.0% · reliable (≥3 clear obs): 99.9%
- Median clear observations per pixel: 11 · mean clear fraction of observations: 72.3%
- Permanent-water negative control (share of JRC permanent-water cells with MNDWI>0): 100%
- Residual-cloud check (valid pixels with blue SR > 0.15): 0.02%
- Reasons: none

**wet** — Status: **PASS**
- Sensors: sentinel-2a,sentinel-2b · scenes: 72
- Valid district coverage: 98.6% · reliable (≥3 clear obs): 81.1%
- Median clear observations per pixel: 4 · mean clear fraction of observations: 39.9%
- Permanent-water negative control (share of JRC permanent-water cells with MNDWI>0): 98%
- Residual-cloud check (valid pixels with blue SR > 0.15): 0.75%
- Reasons: none

### 2024

**2024-01** — Status: **PASS**
- Sensors: sentinel-2a,sentinel-2b · scenes: 35
- Valid district coverage: 99.7% · reliable (≥3 clear obs): 93.0%
- Median clear observations per pixel: 4 · mean clear fraction of observations: 80.8%
- Permanent-water negative control (share of JRC permanent-water cells with MNDWI>0): 100%
- Residual-cloud check (valid pixels with blue SR > 0.15): 0.01%
- Reasons: none

**2024-02** — Status: **PASS**
- Sensors: sentinel-2a,sentinel-2b · scenes: 42
- Valid district coverage: 98.6% · reliable (≥3 clear obs): 93.4%
- Median clear observations per pixel: 6 · mean clear fraction of observations: 84.7%
- Permanent-water negative control (share of JRC permanent-water cells with MNDWI>0): 100%
- Residual-cloud check (valid pixels with blue SR > 0.15): 0.0%
- Reasons: none

**2024-03** — Status: **PASS**
- Sensors: sentinel-2a,sentinel-2b · scenes: 42
- Valid district coverage: 99.0% · reliable (≥3 clear obs): 96.4%
- Median clear observations per pixel: 5 · mean clear fraction of observations: 81.7%
- Permanent-water negative control (share of JRC permanent-water cells with MNDWI>0): 100%
- Residual-cloud check (valid pixels with blue SR > 0.15): 0.02%
- Reasons: none

**2024-04** — Status: **PASS**
- Sensors: sentinel-2a,sentinel-2b · scenes: 42
- Valid district coverage: 99.6% · reliable (≥3 clear obs): 98.7%
- Median clear observations per pixel: 6 · mean clear fraction of observations: 93.0%
- Permanent-water negative control (share of JRC permanent-water cells with MNDWI>0): 90%
- Residual-cloud check (valid pixels with blue SR > 0.15): 0.05%
- Reasons: none

**2024-05** — Status: **PASS**
- Sensors: sentinel-2a,sentinel-2b · scenes: 42
- Valid district coverage: 99.8% · reliable (≥3 clear obs): 98.6%
- Median clear observations per pixel: 5 · mean clear fraction of observations: 86.1%
- Permanent-water negative control (share of JRC permanent-water cells with MNDWI>0): 92%
- Residual-cloud check (valid pixels with blue SR > 0.15): 0.33%
- Reasons: none

**2024-06** — Status: **WARNING**
- Sensors: sentinel-2a,sentinel-2b · scenes: 23
- Valid district coverage: 90.7% · reliable (≥3 clear obs): 14.7%
- Median clear observations per pixel: 1 · mean clear fraction of observations: 37.8%
- Permanent-water negative control (share of JRC permanent-water cells with MNDWI>0): 94%
- Residual-cloud check (valid pixels with blue SR > 0.15): 0.95%
- Reasons: district valid coverage 90.7% < 95% | median clear observations 1 < 3 (composite statistically weak) | 45% of district from a single observation

**2024-07** — Status: **FAIL**
- Sensors: — · scenes: 0
- Valid district coverage: 0.0% · reliable (≥3 clear obs): 0.0%
- Median clear observations per pixel: 0 · mean clear fraction of observations: 0.0%
- Permanent-water negative control (share of JRC permanent-water cells with MNDWI>0): n/a
- Residual-cloud check (valid pixels with blue SR > 0.15): n/a
- Reasons: district valid coverage 0.0% < 50% | median clear observations 0 < 3 (composite statistically weak)

**2024-08** — Status: **FAIL**
- Sensors: sentinel-2a,sentinel-2b · scenes: 7
- Valid district coverage: 17.0% · reliable (≥3 clear obs): 0.4%
- Median clear observations per pixel: 0 · mean clear fraction of observations: 14.1%
- Permanent-water negative control (share of JRC permanent-water cells with MNDWI>0): 98%
- Residual-cloud check (valid pixels with blue SR > 0.15): 3.86%
- Reasons: district valid coverage 17.0% < 50% | median clear observations 0 < 3 (composite statistically weak) | possible residual cloud/haze: 3.9% of valid pixels transiently bright (blue SR > 0.15)

**2024-09** — Status: **WARNING**
- Sensors: sentinel-2a · scenes: 8
- Valid district coverage: 63.5% · reliable (≥3 clear obs): 0.6%
- Median clear observations per pixel: 1 · mean clear fraction of observations: 62.2%
- Permanent-water negative control (share of JRC permanent-water cells with MNDWI>0): 98%
- Residual-cloud check (valid pixels with blue SR > 0.15): 0.38%
- Reasons: district valid coverage 63.5% < 95% | median clear observations 1 < 3 (composite statistically weak) | 53% of district from a single observation

**2024-10** — Status: **WARNING**
- Sensors: sentinel-2a,sentinel-2b · scenes: 34
- Valid district coverage: 96.7% · reliable (≥3 clear obs): 39.7%
- Median clear observations per pixel: 2 · mean clear fraction of observations: 51.8%
- Permanent-water negative control (share of JRC permanent-water cells with MNDWI>0): 100%
- Residual-cloud check (valid pixels with blue SR > 0.15): 0.04%
- Reasons: median clear observations 2 < 3 (composite statistically weak)

**2024-11** — Status: **PASS**
- Sensors: sentinel-2a,sentinel-2b · scenes: 41
- Valid district coverage: 99.0% · reliable (≥3 clear obs): 95.1%
- Median clear observations per pixel: 5 · mean clear fraction of observations: 81.8%
- Permanent-water negative control (share of JRC permanent-water cells with MNDWI>0): 100%
- Residual-cloud check (valid pixels with blue SR > 0.15): 0.03%
- Reasons: none

**2024-12** — Status: **PASS**
- Sensors: sentinel-2a,sentinel-2b · scenes: 38
- Valid district coverage: 99.7% · reliable (≥3 clear obs): 97.1%
- Median clear observations per pixel: 4 · mean clear fraction of observations: 72.5%
- Permanent-water negative control (share of JRC permanent-water cells with MNDWI>0): 100%
- Residual-cloud check (valid pixels with blue SR > 0.15): 0.13%
- Reasons: none

**annual** — Status: **PASS**
- Sensors: sentinel-2a,sentinel-2b · scenes: 354
- Valid district coverage: 100.0% · reliable (≥3 clear obs): 100.0%
- Median clear observations per pixel: 39 · mean clear fraction of observations: 74.9%
- Permanent-water negative control (share of JRC permanent-water cells with MNDWI>0): 100%
- Residual-cloud check (valid pixels with blue SR > 0.15): 0.01%
- Reasons: none

**dry** — Status: **PASS**
- Sensors: sentinel-2a,sentinel-2b · scenes: 203
- Valid district coverage: 100.0% · reliable (≥3 clear obs): 100.0%
- Median clear observations per pixel: 26 · mean clear fraction of observations: 85.4%
- Permanent-water negative control (share of JRC permanent-water cells with MNDWI>0): 100%
- Residual-cloud check (valid pixels with blue SR > 0.15): 0.02%
- Reasons: none

**post_monsoon** — Status: **PASS**
- Sensors: sentinel-2a,sentinel-2b · scenes: 113
- Valid district coverage: 100.0% · reliable (≥3 clear obs): 99.9%
- Median clear observations per pixel: 11 · mean clear fraction of observations: 70.3%
- Permanent-water negative control (share of JRC permanent-water cells with MNDWI>0): 100%
- Residual-cloud check (valid pixels with blue SR > 0.15): 0.02%
- Reasons: none

**wet** — Status: **WARNING**
- Sensors: sentinel-2a,sentinel-2b · scenes: 38
- Valid district coverage: 96.1% · reliable (≥3 clear obs): 42.7%
- Median clear observations per pixel: 2 · mean clear fraction of observations: 36.3%
- Permanent-water negative control (share of JRC permanent-water cells with MNDWI>0): 96%
- Residual-cloud check (valid pixels with blue SR > 0.15): 0.64%
- Reasons: median clear observations 2 < 3 (composite statistically weak)

### 2025

**2025-01** — Status: **PASS**
- Sensors: sentinel-2a,sentinel-2b,sentinel-2c · scenes: 35
- Valid district coverage: 99.7% · reliable (≥3 clear obs): 98.1%
- Median clear observations per pixel: 4 · mean clear fraction of observations: 81.4%
- Permanent-water negative control (share of JRC permanent-water cells with MNDWI>0): 100%
- Residual-cloud check (valid pixels with blue SR > 0.15): 0.03%
- Reasons: none

**2025-02** — Status: **PASS**
- Sensors: sentinel-2b,sentinel-2c · scenes: 33
- Valid district coverage: 96.8% · reliable (≥3 clear obs): 90.7%
- Median clear observations per pixel: 5 · mean clear fraction of observations: 84.7%
- Permanent-water negative control (share of JRC permanent-water cells with MNDWI>0): 100%
- Residual-cloud check (valid pixels with blue SR > 0.15): 0.0%
- Reasons: none

**2025-03** — Status: **PASS**
- Sensors: sentinel-2a,sentinel-2b,sentinel-2c · scenes: 49
- Valid district coverage: 99.8% · reliable (≥3 clear obs): 96.4%
- Median clear observations per pixel: 6 · mean clear fraction of observations: 82.3%
- Permanent-water negative control (share of JRC permanent-water cells with MNDWI>0): 100%
- Residual-cloud check (valid pixels with blue SR > 0.15): 0.05%
- Reasons: none

**2025-04** — Status: **PASS**
- Sensors: sentinel-2a,sentinel-2b,sentinel-2c · scenes: 48
- Valid district coverage: 99.7% · reliable (≥3 clear obs): 98.7%
- Median clear observations per pixel: 6 · mean clear fraction of observations: 88.7%
- Permanent-water negative control (share of JRC permanent-water cells with MNDWI>0): 98%
- Residual-cloud check (valid pixels with blue SR > 0.15): 0.23%
- Reasons: none

**2025-05** — Status: **PASS**
- Sensors: sentinel-2a,sentinel-2b,sentinel-2c · scenes: 37
- Valid district coverage: 98.5% · reliable (≥3 clear obs): 57.0%
- Median clear observations per pixel: 3 · mean clear fraction of observations: 54.5%
- Permanent-water negative control (share of JRC permanent-water cells with MNDWI>0): 95%
- Residual-cloud check (valid pixels with blue SR > 0.15): 0.5%
- Reasons: none

**2025-06** — Status: **WARNING**
- Sensors: sentinel-2b,sentinel-2c · scenes: 22
- Valid district coverage: 51.9% · reliable (≥3 clear obs): 6.1%
- Median clear observations per pixel: 1 · mean clear fraction of observations: 22.2%
- Permanent-water negative control (share of JRC permanent-water cells with MNDWI>0): 94%
- Residual-cloud check (valid pixels with blue SR > 0.15): 3.31%
- Reasons: district valid coverage 51.9% < 95% | median clear observations 1 < 3 (composite statistically weak) | 30% of district from a single observation | possible residual cloud/haze: 3.3% of valid pixels transiently bright (blue SR > 0.15)

**2025-07** — Status: **FAIL**
- Sensors: sentinel-2b · scenes: 4
- Valid district coverage: 7.3% · reliable (≥3 clear obs): 0.0%
- Median clear observations per pixel: 0 · mean clear fraction of observations: 8.5%
- Permanent-water negative control (share of JRC permanent-water cells with MNDWI>0): 100%
- Residual-cloud check (valid pixels with blue SR > 0.15): 5.25%
- Reasons: district valid coverage 7.3% < 50% | median clear observations 0 < 3 (composite statistically weak) | possible residual cloud/haze: 5.2% of valid pixels transiently bright (blue SR > 0.15)

**2025-08** — Status: **FAIL**
- Sensors: sentinel-2b · scenes: 8
- Valid district coverage: 15.3% · reliable (≥3 clear obs): 0.1%
- Median clear observations per pixel: 0 · mean clear fraction of observations: 14.6%
- Permanent-water negative control (share of JRC permanent-water cells with MNDWI>0): 99%
- Residual-cloud check (valid pixels with blue SR > 0.15): 2.2%
- Reasons: district valid coverage 15.3% < 50% | median clear observations 0 < 3 (composite statistically weak) | possible residual cloud/haze: 2.2% of valid pixels transiently bright (blue SR > 0.15)

**2025-09** — Status: **FAIL**
- Sensors: sentinel-2a,sentinel-2b,sentinel-2c · scenes: 19
- Valid district coverage: 34.2% · reliable (≥3 clear obs): 1.7%
- Median clear observations per pixel: 0 · mean clear fraction of observations: 16.9%
- Permanent-water negative control (share of JRC permanent-water cells with MNDWI>0): 100%
- Residual-cloud check (valid pixels with blue SR > 0.15): 1.13%
- Reasons: district valid coverage 34.2% < 50% | median clear observations 0 < 3 (composite statistically weak) | possible residual cloud/haze: 1.1% of valid pixels transiently bright (blue SR > 0.15)

**2025-10** — Status: **PASS**
- Sensors: sentinel-2a,sentinel-2b,sentinel-2c · scenes: 32
- Valid district coverage: 95.5% · reliable (≥3 clear obs): 64.9%
- Median clear observations per pixel: 3 · mean clear fraction of observations: 55.0%
- Permanent-water negative control (share of JRC permanent-water cells with MNDWI>0): 100%
- Residual-cloud check (valid pixels with blue SR > 0.15): 0.14%
- Reasons: none

**2025-11** — Status: **PASS**
- Sensors: sentinel-2a,sentinel-2b,sentinel-2c · scenes: 52
- Valid district coverage: 97.0% · reliable (≥3 clear obs): 90.7%
- Median clear observations per pixel: 6 · mean clear fraction of observations: 69.0%
- Permanent-water negative control (share of JRC permanent-water cells with MNDWI>0): 100%
- Residual-cloud check (valid pixels with blue SR > 0.15): 0.04%
- Reasons: none

**2025-12** — Status: **PASS**
- Sensors: sentinel-2a,sentinel-2b,sentinel-2c · scenes: 48
- Valid district coverage: 99.8% · reliable (≥3 clear obs): 99.4%
- Median clear observations per pixel: 7 · mean clear fraction of observations: 90.1%
- Permanent-water negative control (share of JRC permanent-water cells with MNDWI>0): 100%
- Residual-cloud check (valid pixels with blue SR > 0.15): 0.01%
- Reasons: none

**annual** — Status: **PASS**
- Sensors: sentinel-2a,sentinel-2b,sentinel-2c · scenes: 387
- Valid district coverage: 100.0% · reliable (≥3 clear obs): 100.0%
- Median clear observations per pixel: 39 · mean clear fraction of observations: 69.4%
- Permanent-water negative control (share of JRC permanent-water cells with MNDWI>0): 100%
- Residual-cloud check (valid pixels with blue SR > 0.15): 0.03%
- Reasons: none

**dry** — Status: **PASS**
- Sensors: sentinel-2a,sentinel-2b,sentinel-2c · scenes: 202
- Valid district coverage: 100.0% · reliable (≥3 clear obs): 100.0%
- Median clear observations per pixel: 24 · mean clear fraction of observations: 79.4%
- Permanent-water negative control (share of JRC permanent-water cells with MNDWI>0): 100%
- Residual-cloud check (valid pixels with blue SR > 0.15): 0.01%
- Reasons: none

**post_monsoon** — Status: **PASS**
- Sensors: sentinel-2a,sentinel-2b,sentinel-2c · scenes: 132
- Valid district coverage: 100.0% · reliable (≥3 clear obs): 99.9%
- Median clear observations per pixel: 15 · mean clear fraction of observations: 73.2%
- Permanent-water negative control (share of JRC permanent-water cells with MNDWI>0): 100%
- Residual-cloud check (valid pixels with blue SR > 0.15): 0.03%
- Reasons: none

**wet** — Status: **WARNING**
- Sensors: sentinel-2a,sentinel-2b,sentinel-2c · scenes: 53
- Valid district coverage: 72.9% · reliable (≥3 clear obs): 20.7%
- Median clear observations per pixel: 1 · mean clear fraction of observations: 18.3%
- Permanent-water negative control (share of JRC permanent-water cells with MNDWI>0): 98%
- Residual-cloud check (valid pixels with blue SR > 0.15): 2.39%
- Reasons: district valid coverage 72.9% < 95% | median clear observations 1 < 3 (composite statistically weak) | 29% of district from a single observation | possible residual cloud/haze: 2.4% of valid pixels transiently bright (blue SR > 0.15)

### 2026

**2026-01** — Status: **PASS**
- Sensors: sentinel-2a,sentinel-2b,sentinel-2c · scenes: 49
- Valid district coverage: 99.9% · reliable (≥3 clear obs): 99.6%
- Median clear observations per pixel: 7 · mean clear fraction of observations: 94.7%
- Permanent-water negative control (share of JRC permanent-water cells with MNDWI>0): 100%
- Residual-cloud check (valid pixels with blue SR > 0.15): 0.08%
- Reasons: none

**2026-02** — Status: **PASS**
- Sensors: sentinel-2b,sentinel-2c · scenes: 42
- Valid district coverage: 99.4% · reliable (≥3 clear obs): 96.6%
- Median clear observations per pixel: 6 · mean clear fraction of observations: 87.1%
- Permanent-water negative control (share of JRC permanent-water cells with MNDWI>0): 100%
- Residual-cloud check (valid pixels with blue SR > 0.15): 0.01%
- Reasons: none

**2026-03** — Status: **PASS**
- Sensors: sentinel-2a,sentinel-2b,sentinel-2c · scenes: 49
- Valid district coverage: 99.0% · reliable (≥3 clear obs): 95.9%
- Median clear observations per pixel: 7 · mean clear fraction of observations: 90.0%
- Permanent-water negative control (share of JRC permanent-water cells with MNDWI>0): 100%
- Residual-cloud check (valid pixels with blue SR > 0.15): 0.0%
- Reasons: none

**2026-04** — Status: **PASS**
- Sensors: sentinel-2a,sentinel-2b,sentinel-2c · scenes: 54
- Valid district coverage: 99.6% · reliable (≥3 clear obs): 98.8%
- Median clear observations per pixel: 7 · mean clear fraction of observations: 82.4%
- Permanent-water negative control (share of JRC permanent-water cells with MNDWI>0): 99%
- Residual-cloud check (valid pixels with blue SR > 0.15): 0.24%
- Reasons: none

**2026-05** — Status: **PASS**
- Sensors: sentinel-2a,sentinel-2b,sentinel-2c · scenes: 29
- Valid district coverage: 99.3% · reliable (≥3 clear obs): 66.8%
- Median clear observations per pixel: 3 · mean clear fraction of observations: 74.3%
- Permanent-water negative control (share of JRC permanent-water cells with MNDWI>0): 86%
- Residual-cloud check (valid pixels with blue SR > 0.15): 0.53%
- Reasons: none

**2026-06** — Status: **WARNING**
- Sensors: sentinel-2a,sentinel-2b,sentinel-2c · scenes: 42
- Valid district coverage: 99.1% · reliable (≥3 clear obs): 78.4%
- Median clear observations per pixel: 3 · mean clear fraction of observations: 53.7%
- Permanent-water negative control (share of JRC permanent-water cells with MNDWI>0): 96%
- Residual-cloud check (valid pixels with blue SR > 0.15): 1.02%
- Reasons: possible residual cloud/haze: 1.0% of valid pixels transiently bright (blue SR > 0.15)

**2026-07** — Status: **WARNING**
- Sensors: sentinel-2a,sentinel-2c · scenes: 13
- Valid district coverage: 72.2% · reliable (≥3 clear obs): 4.4%
- Median clear observations per pixel: 1 · mean clear fraction of observations: 44.7%
- Permanent-water negative control (share of JRC permanent-water cells with MNDWI>0): 100%
- Residual-cloud check (valid pixels with blue SR > 0.15): 1.21%
- Reasons: district valid coverage 72.2% < 95% | median clear observations 1 < 3 (composite statistically weak) | 46% of district from a single observation | possible residual cloud/haze: 1.2% of valid pixels transiently bright (blue SR > 0.15)

**2026-08** — Status: **FAIL**
- Sensors: sentinel-2b,sentinel-2c · scenes: 18
- Valid district coverage: 46.1% · reliable (≥3 clear obs): 3.4%
- Median clear observations per pixel: 0 · mean clear fraction of observations: 18.5%
- Permanent-water negative control (share of JRC permanent-water cells with MNDWI>0): 100%
- Residual-cloud check (valid pixels with blue SR > 0.15): 1.67%
- Reasons: district valid coverage 46.1% < 50% | median clear observations 0 < 3 (composite statistically weak) | 30% of district from a single observation | possible residual cloud/haze: 1.7% of valid pixels transiently bright (blue SR > 0.15)

**2026-09** — Status: **WARNING**
- Sensors: sentinel-2a,sentinel-2b,sentinel-2c · scenes: 29
- Valid district coverage: 78.0% · reliable (≥3 clear obs): 26.7%
- Median clear observations per pixel: 2 · mean clear fraction of observations: 34.0%
- Permanent-water negative control (share of JRC permanent-water cells with MNDWI>0): 99%
- Residual-cloud check (valid pixels with blue SR > 0.15): 1.17%
- Reasons: district valid coverage 78.0% < 95% | median clear observations 2 < 3 (composite statistically weak) | 27% of district from a single observation | possible residual cloud/haze: 1.2% of valid pixels transiently bright (blue SR > 0.15)

**2026-10** — Status: **IN_PROGRESS** (PARTIAL)
- Sensors: — · scenes: 0
- Valid district coverage: 0.0% · reliable (≥3 clear obs): 0.0%
- Median clear observations per pixel: 0 · mean clear fraction of observations: 0.0%
- Permanent-water negative control (share of JRC permanent-water cells with MNDWI>0): n/a
- Residual-cloud check (valid pixels with blue SR > 0.15): n/a
- Reasons: period in progress at the archive cut-off 2026-10-01 20:08 with no acquisitions yet - nothing to assess

**2026-11** — Status: **IN_PROGRESS** (PARTIAL)
- Sensors: — · scenes: 0
- Valid district coverage: 0.0% · reliable (≥3 clear obs): 0.0%
- Median clear observations per pixel: 0 · mean clear fraction of observations: 0.0%
- Permanent-water negative control (share of JRC permanent-water cells with MNDWI>0): n/a
- Residual-cloud check (valid pixels with blue SR > 0.15): n/a
- Reasons: period in progress at the archive cut-off 2026-10-01 20:08 with no acquisitions yet - nothing to assess

**2026-12** — Status: **IN_PROGRESS** (PARTIAL)
- Sensors: — · scenes: 0
- Valid district coverage: 0.0% · reliable (≥3 clear obs): 0.0%
- Median clear observations per pixel: 0 · mean clear fraction of observations: 0.0%
- Permanent-water negative control (share of JRC permanent-water cells with MNDWI>0): n/a
- Residual-cloud check (valid pixels with blue SR > 0.15): n/a
- Reasons: period in progress at the archive cut-off 2026-10-01 20:08 with no acquisitions yet - nothing to assess

**annual** — Status: **WARNING** (PARTIAL)
- Sensors: sentinel-2a,sentinel-2b,sentinel-2c · scenes: 325
- Valid district coverage: 100.0% · reliable (≥3 clear obs): 100.0%
- Median clear observations per pixel: 35 · mean clear fraction of observations: 70.9%
- Permanent-water negative control (share of JRC permanent-water cells with MNDWI>0): 100%
- Residual-cloud check (valid pixels with blue SR > 0.15): 0.03%
- Reasons: PARTIAL period: archive cut-off 2026-10-01

**dry** — Status: **PASS**
- Sensors: sentinel-2a,sentinel-2b,sentinel-2c · scenes: 223
- Valid district coverage: 100.0% · reliable (≥3 clear obs): 100.0%
- Median clear observations per pixel: 29 · mean clear fraction of observations: 86.7%
- Permanent-water negative control (share of JRC permanent-water cells with MNDWI>0): 100%
- Residual-cloud check (valid pixels with blue SR > 0.15): 0.0%
- Reasons: none

**post_monsoon** — Status: **IN_PROGRESS** (PARTIAL)
- Sensors: — · scenes: 0
- Valid district coverage: 0.0% · reliable (≥3 clear obs): 0.0%
- Median clear observations per pixel: 0 · mean clear fraction of observations: 0.0%
- Permanent-water negative control (share of JRC permanent-water cells with MNDWI>0): n/a
- Residual-cloud check (valid pixels with blue SR > 0.15): n/a
- Reasons: period in progress at the archive cut-off 2026-10-01 20:08 with no acquisitions yet - nothing to assess

**wet** — Status: **PASS**
- Sensors: sentinel-2a,sentinel-2b,sentinel-2c · scenes: 102
- Valid district coverage: 99.6% · reliable (≥3 clear obs): 94.7%
- Median clear observations per pixel: 7 · mean clear fraction of observations: 39.4%
- Permanent-water negative control (share of JRC permanent-water cells with MNDWI>0): 99%
- Residual-cloud check (valid pixels with blue SR > 0.15): 0.94%
- Reasons: none
