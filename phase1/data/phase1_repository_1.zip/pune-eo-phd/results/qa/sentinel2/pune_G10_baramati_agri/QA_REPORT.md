# Pune EO Data QA Report — sentinel2 — grid `pune_G10_baramati_agri`

Generated automatically by `pune-eo qa`. Thresholds: `configs/qa.yaml`. Every product's full QA record is
also written into its own `metadata.json` (`qa` block).

## Summary

| period       |   FAIL |   PASS |   WARNING |
|:-------------|-------:|-------:|----------:|
| 2024-01      |      0 |      1 |         0 |
| 2024-02      |      0 |      1 |         0 |
| 2024-03      |      0 |      1 |         0 |
| 2024-04      |      0 |      1 |         0 |
| 2024-05      |      0 |      0 |         1 |
| 2024-06      |      0 |      0 |         1 |
| 2024-07      |      1 |      0 |         0 |
| 2024-08      |      1 |      0 |         0 |
| 2024-09      |      0 |      0 |         1 |
| 2024-10      |      0 |      1 |         0 |
| 2024-11      |      0 |      1 |         0 |
| 2024-12      |      0 |      1 |         0 |
| annual       |      0 |      1 |         0 |
| dry          |      0 |      1 |         0 |
| post_monsoon |      0 |      1 |         0 |
| wet          |      0 |      0 |         1 |

## Per-year records

### 2024

**2024-01** — Status: **PASS**
- Sensors: sentinel-2a,sentinel-2b · scenes: 5
- Valid district coverage: 100.0% · reliable (≥3 clear obs): 100.0%
- Median clear observations per pixel: 5 · mean clear fraction of observations: 96.5%
- Permanent-water negative control (share of JRC permanent-water cells with MNDWI>0): n/a
- Residual-cloud check (valid pixels with blue SR > 0.15): 0.08%
- Reasons: none

**2024-02** — Status: **PASS**
- Sensors: sentinel-2a,sentinel-2b · scenes: 6
- Valid district coverage: 100.0% · reliable (≥3 clear obs): 100.0%
- Median clear observations per pixel: 6 · mean clear fraction of observations: 95.6%
- Permanent-water negative control (share of JRC permanent-water cells with MNDWI>0): n/a
- Residual-cloud check (valid pixels with blue SR > 0.15): 0.04%
- Reasons: none

**2024-03** — Status: **PASS**
- Sensors: sentinel-2a,sentinel-2b · scenes: 6
- Valid district coverage: 100.0% · reliable (≥3 clear obs): 100.0%
- Median clear observations per pixel: 6 · mean clear fraction of observations: 93.7%
- Permanent-water negative control (share of JRC permanent-water cells with MNDWI>0): n/a
- Residual-cloud check (valid pixels with blue SR > 0.15): 0.05%
- Reasons: none

**2024-04** — Status: **PASS**
- Sensors: sentinel-2a,sentinel-2b · scenes: 6
- Valid district coverage: 100.0% · reliable (≥3 clear obs): 100.0%
- Median clear observations per pixel: 6 · mean clear fraction of observations: 99.3%
- Permanent-water negative control (share of JRC permanent-water cells with MNDWI>0): n/a
- Residual-cloud check (valid pixels with blue SR > 0.15): 0.28%
- Reasons: none

**2024-05** — Status: **WARNING**
- Sensors: sentinel-2a,sentinel-2b · scenes: 6
- Valid district coverage: 100.0% · reliable (≥3 clear obs): 100.0%
- Median clear observations per pixel: 5 · mean clear fraction of observations: 85.1%
- Permanent-water negative control (share of JRC permanent-water cells with MNDWI>0): n/a
- Residual-cloud check (valid pixels with blue SR > 0.15): 1.4%
- Reasons: possible residual cloud/haze: 1.4% of valid pixels transiently bright (blue SR > 0.15)

**2024-06** — Status: **WARNING**
- Sensors: sentinel-2a,sentinel-2b · scenes: 3
- Valid district coverage: 100.0% · reliable (≥3 clear obs): 32.7%
- Median clear observations per pixel: 2 · mean clear fraction of observations: 74.7%
- Permanent-water negative control (share of JRC permanent-water cells with MNDWI>0): n/a
- Residual-cloud check (valid pixels with blue SR > 0.15): 2.29%
- Reasons: median clear observations 2 < 3 (composite statistically weak) | possible residual cloud/haze: 2.3% of valid pixels transiently bright (blue SR > 0.15)

**2024-07** — Status: **FAIL**
- Sensors: — · scenes: 0
- Valid district coverage: 0.0% · reliable (≥3 clear obs): 0.0%
- Median clear observations per pixel: 0 · mean clear fraction of observations: 0.0%
- Permanent-water negative control (share of JRC permanent-water cells with MNDWI>0): n/a
- Residual-cloud check (valid pixels with blue SR > 0.15): n/a
- Reasons: district valid coverage 0.0% < 50% | median clear observations 0 < 3 (composite statistically weak)

**2024-08** — Status: **FAIL**
- Sensors: sentinel-2a,sentinel-2b · scenes: 2
- Valid district coverage: 18.2% · reliable (≥3 clear obs): 0.0%
- Median clear observations per pixel: 0 · mean clear fraction of observations: 9.1%
- Permanent-water negative control (share of JRC permanent-water cells with MNDWI>0): n/a
- Residual-cloud check (valid pixels with blue SR > 0.15): 10.44%
- Reasons: district valid coverage 18.2% < 50% | residual cloud/haze: 10% of valid pixels transiently bright (blue SR > 0.15) | median clear observations 0 < 3 (composite statistically weak)

**2024-09** — Status: **WARNING**
- Sensors: sentinel-2a · scenes: 1
- Valid district coverage: 81.9% · reliable (≥3 clear obs): 0.0%
- Median clear observations per pixel: 1 · mean clear fraction of observations: 81.9%
- Permanent-water negative control (share of JRC permanent-water cells with MNDWI>0): n/a
- Residual-cloud check (valid pixels with blue SR > 0.15): 1.71%
- Reasons: district valid coverage 81.9% < 95% | median clear observations 1 < 3 (composite statistically weak) | 82% of district from a single observation | possible residual cloud/haze: 1.7% of valid pixels transiently bright (blue SR > 0.15)

**2024-10** — Status: **PASS**
- Sensors: sentinel-2a,sentinel-2b · scenes: 5
- Valid district coverage: 100.0% · reliable (≥3 clear obs): 53.0%
- Median clear observations per pixel: 3 · mean clear fraction of observations: 65.6%
- Permanent-water negative control (share of JRC permanent-water cells with MNDWI>0): n/a
- Residual-cloud check (valid pixels with blue SR > 0.15): 0.61%
- Reasons: none

**2024-11** — Status: **PASS**
- Sensors: sentinel-2a,sentinel-2b · scenes: 6
- Valid district coverage: 100.0% · reliable (≥3 clear obs): 100.0%
- Median clear observations per pixel: 5 · mean clear fraction of observations: 90.7%
- Permanent-water negative control (share of JRC permanent-water cells with MNDWI>0): n/a
- Residual-cloud check (valid pixels with blue SR > 0.15): 0.42%
- Reasons: none

**2024-12** — Status: **PASS**
- Sensors: sentinel-2a,sentinel-2b · scenes: 6
- Valid district coverage: 100.0% · reliable (≥3 clear obs): 99.8%
- Median clear observations per pixel: 5 · mean clear fraction of observations: 80.6%
- Permanent-water negative control (share of JRC permanent-water cells with MNDWI>0): n/a
- Residual-cloud check (valid pixels with blue SR > 0.15): 0.26%
- Reasons: none

**annual** — Status: **PASS**
- Sensors: sentinel-2a,sentinel-2b · scenes: 52
- Valid district coverage: 100.0% · reliable (≥3 clear obs): 100.0%
- Median clear observations per pixel: 43 · mean clear fraction of observations: 85.0%
- Permanent-water negative control (share of JRC permanent-water cells with MNDWI>0): n/a
- Residual-cloud check (valid pixels with blue SR > 0.15): 0.11%
- Reasons: none

**dry** — Status: **PASS**
- Sensors: sentinel-2a,sentinel-2b · scenes: 29
- Valid district coverage: 100.0% · reliable (≥3 clear obs): 100.0%
- Median clear observations per pixel: 27 · mean clear fraction of observations: 94.2%
- Permanent-water negative control (share of JRC permanent-water cells with MNDWI>0): n/a
- Residual-cloud check (valid pixels with blue SR > 0.15): 0.04%
- Reasons: none

**post_monsoon** — Status: **PASS**
- Sensors: sentinel-2a,sentinel-2b · scenes: 17
- Valid district coverage: 100.0% · reliable (≥3 clear obs): 100.0%
- Median clear observations per pixel: 12 · mean clear fraction of observations: 80.1%
- Permanent-water negative control (share of JRC permanent-water cells with MNDWI>0): n/a
- Residual-cloud check (valid pixels with blue SR > 0.15): 0.28%
- Reasons: none

**wet** — Status: **WARNING**
- Sensors: sentinel-2a,sentinel-2b · scenes: 6
- Valid district coverage: 100.0% · reliable (≥3 clear obs): 83.6%
- Median clear observations per pixel: 3 · mean clear fraction of observations: 54.0%
- Permanent-water negative control (share of JRC permanent-water cells with MNDWI>0): n/a
- Residual-cloud check (valid pixels with blue SR > 0.15): 2.02%
- Reasons: possible residual cloud/haze: 2.0% of valid pixels transiently bright (blue SR > 0.15)
