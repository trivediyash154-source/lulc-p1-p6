# Pune EO Data QA Report — landsat — grid `pune_G240`

Generated automatically by `pune-eo qa`. Thresholds: `configs/qa.yaml`. Every product's full QA record is
also written into its own `metadata.json` (`qa` block).

## Summary

| period       |   FAIL |   IN_PROGRESS |   PASS |   WARNING |
|:-------------|-------:|--------------:|-------:|----------:|
| annual       |      0 |             0 |     30 |         7 |
| dry          |      0 |             0 |     30 |         7 |
| post_monsoon |      0 |             1 |     18 |        18 |
| wet          |     16 |             0 |      4 |        17 |

## Per-year records

### 1990

**annual** — Status: **PASS**
- Sensors: landsat-5 · scenes: 22
- Valid district coverage: 100.0% · reliable (≥3 clear obs): 96.0%
- Median clear observations per pixel: 8 · mean clear fraction of observations: 82.2%
- Permanent-water negative control (share of JRC permanent-water cells with MNDWI>0): 100%
- Residual-cloud check (valid pixels with blue SR > 0.15): 0.0%
- Reasons: none

**dry** — Status: **PASS**
- Sensors: landsat-5 · scenes: 16
- Valid district coverage: 100.0% · reliable (≥3 clear obs): 95.7%
- Median clear observations per pixel: 6 · mean clear fraction of observations: 93.2%
- Permanent-water negative control (share of JRC permanent-water cells with MNDWI>0): 100%
- Residual-cloud check (valid pixels with blue SR > 0.15): 0.0%
- Reasons: none

**post_monsoon** — Status: **WARNING**
- Sensors: landsat-5 · scenes: 2
- Valid district coverage: 88.5% · reliable (≥3 clear obs): 0.0%
- Median clear observations per pixel: 1 · mean clear fraction of observations: 98.8%
- Permanent-water negative control (share of JRC permanent-water cells with MNDWI>0): 99%
- Residual-cloud check (valid pixels with blue SR > 0.15): 0.0%
- Reasons: district valid coverage 88.5% < 95% | median clear observations 1 < 3 (composite statistically weak) | 86% of district from a single observation

**wet** — Status: **FAIL**
- Sensors: landsat-5 · scenes: 4
- Valid district coverage: 17.3% · reliable (≥3 clear obs): 0.0%
- Median clear observations per pixel: 0 · mean clear fraction of observations: 16.6%
- Permanent-water negative control (share of JRC permanent-water cells with MNDWI>0): 99%
- Residual-cloud check (valid pixels with blue SR > 0.15): 0.33%
- Reasons: district valid coverage 17.3% < 50% | median clear observations 0 < 3 (composite statistically weak)

### 1991

**annual** — Status: **PASS**
- Sensors: landsat-5 · scenes: 30
- Valid district coverage: 100.0% · reliable (≥3 clear obs): 100.0%
- Median clear observations per pixel: 6 · mean clear fraction of observations: 86.2%
- Permanent-water negative control (share of JRC permanent-water cells with MNDWI>0): 100%
- Residual-cloud check (valid pixels with blue SR > 0.15): 0.0%
- Reasons: none

**dry** — Status: **PASS**
- Sensors: landsat-5 · scenes: 20
- Valid district coverage: 100.0% · reliable (≥3 clear obs): 100.0%
- Median clear observations per pixel: 4 · mean clear fraction of observations: 94.3%
- Permanent-water negative control (share of JRC permanent-water cells with MNDWI>0): 100%
- Residual-cloud check (valid pixels with blue SR > 0.15): 0.0%
- Reasons: none

**post_monsoon** — Status: **WARNING**
- Sensors: landsat-5 · scenes: 10
- Valid district coverage: 100.0% · reliable (≥3 clear obs): 30.3%
- Median clear observations per pixel: 2 · mean clear fraction of observations: 75.4%
- Permanent-water negative control (share of JRC permanent-water cells with MNDWI>0): 100%
- Residual-cloud check (valid pixels with blue SR > 0.15): 0.0%
- Reasons: median clear observations 2 < 3 (composite statistically weak)

**wet** — Status: **FAIL**
- Sensors: — · scenes: 0
- Valid district coverage: 0.0% · reliable (≥3 clear obs): 0.0%
- Median clear observations per pixel: 0 · mean clear fraction of observations: 0.0%
- Permanent-water negative control (share of JRC permanent-water cells with MNDWI>0): n/a
- Residual-cloud check (valid pixels with blue SR > 0.15): n/a
- Reasons: district valid coverage 0.0% < 50% | median clear observations 0 < 3 (composite statistically weak)

### 1992

**annual** — Status: **PASS**
- Sensors: landsat-5 · scenes: 41
- Valid district coverage: 100.0% · reliable (≥3 clear obs): 100.0%
- Median clear observations per pixel: 7 · mean clear fraction of observations: 81.5%
- Permanent-water negative control (share of JRC permanent-water cells with MNDWI>0): 100%
- Residual-cloud check (valid pixels with blue SR > 0.15): 0.0%
- Reasons: none

**dry** — Status: **PASS**
- Sensors: landsat-5 · scenes: 24
- Valid district coverage: 100.0% · reliable (≥3 clear obs): 100.0%
- Median clear observations per pixel: 5 · mean clear fraction of observations: 98.0%
- Permanent-water negative control (share of JRC permanent-water cells with MNDWI>0): 100%
- Residual-cloud check (valid pixels with blue SR > 0.15): 0.0%
- Reasons: none

**post_monsoon** — Status: **WARNING**
- Sensors: landsat-5 · scenes: 12
- Valid district coverage: 100.0% · reliable (≥3 clear obs): 24.3%
- Median clear observations per pixel: 2 · mean clear fraction of observations: 72.7%
- Permanent-water negative control (share of JRC permanent-water cells with MNDWI>0): 100%
- Residual-cloud check (valid pixels with blue SR > 0.15): 0.0%
- Reasons: median clear observations 2 < 3 (composite statistically weak)

**wet** — Status: **FAIL**
- Sensors: landsat-5 · scenes: 5
- Valid district coverage: 25.2% · reliable (≥3 clear obs): 0.0%
- Median clear observations per pixel: 0 · mean clear fraction of observations: 23.1%
- Permanent-water negative control (share of JRC permanent-water cells with MNDWI>0): 80%
- Residual-cloud check (valid pixels with blue SR > 0.15): 88.53%
- Reasons: district valid coverage 25.2% < 50% | residual cloud/haze: 89% of valid pixels transiently bright (blue SR > 0.15) | median clear observations 0 < 3 (composite statistically weak)

### 1993

**annual** — Status: **PASS**
- Sensors: landsat-5 · scenes: 45
- Valid district coverage: 100.0% · reliable (≥3 clear obs): 100.0%
- Median clear observations per pixel: 8 · mean clear fraction of observations: 77.8%
- Permanent-water negative control (share of JRC permanent-water cells with MNDWI>0): 100%
- Residual-cloud check (valid pixels with blue SR > 0.15): 0.0%
- Reasons: none

**dry** — Status: **PASS**
- Sensors: landsat-5 · scenes: 25
- Valid district coverage: 100.0% · reliable (≥3 clear obs): 100.0%
- Median clear observations per pixel: 6 · mean clear fraction of observations: 91.0%
- Permanent-water negative control (share of JRC permanent-water cells with MNDWI>0): 100%
- Residual-cloud check (valid pixels with blue SR > 0.15): 0.0%
- Reasons: none

**post_monsoon** — Status: **WARNING**
- Sensors: landsat-5 · scenes: 14
- Valid district coverage: 100.0% · reliable (≥3 clear obs): 35.4%
- Median clear observations per pixel: 2 · mean clear fraction of observations: 67.3%
- Permanent-water negative control (share of JRC permanent-water cells with MNDWI>0): 100%
- Residual-cloud check (valid pixels with blue SR > 0.15): 0.0%
- Reasons: median clear observations 2 < 3 (composite statistically weak)

**wet** — Status: **FAIL**
- Sensors: landsat-5 · scenes: 6
- Valid district coverage: 42.9% · reliable (≥3 clear obs): 5.4%
- Median clear observations per pixel: 0 · mean clear fraction of observations: 35.0%
- Permanent-water negative control (share of JRC permanent-water cells with MNDWI>0): 100%
- Residual-cloud check (valid pixels with blue SR > 0.15): 0.01%
- Reasons: district valid coverage 42.9% < 50% | median clear observations 0 < 3 (composite statistically weak) | 29% of district from a single observation

### 1994

**annual** — Status: **PASS**
- Sensors: landsat-5 · scenes: 45
- Valid district coverage: 100.0% · reliable (≥3 clear obs): 100.0%
- Median clear observations per pixel: 8 · mean clear fraction of observations: 83.8%
- Permanent-water negative control (share of JRC permanent-water cells with MNDWI>0): 100%
- Residual-cloud check (valid pixels with blue SR > 0.15): 0.0%
- Reasons: none

**dry** — Status: **PASS**
- Sensors: landsat-5 · scenes: 21
- Valid district coverage: 100.0% · reliable (≥3 clear obs): 100.0%
- Median clear observations per pixel: 5 · mean clear fraction of observations: 96.2%
- Permanent-water negative control (share of JRC permanent-water cells with MNDWI>0): 100%
- Residual-cloud check (valid pixels with blue SR > 0.15): 0.0%
- Reasons: none

**post_monsoon** — Status: **WARNING**
- Sensors: landsat-5 · scenes: 14
- Valid district coverage: 100.0% · reliable (≥3 clear obs): 28.2%
- Median clear observations per pixel: 2 · mean clear fraction of observations: 61.6%
- Permanent-water negative control (share of JRC permanent-water cells with MNDWI>0): 100%
- Residual-cloud check (valid pixels with blue SR > 0.15): 0.0%
- Reasons: median clear observations 2 < 3 (composite statistically weak) | 26% of district from a single observation

**wet** — Status: **WARNING**
- Sensors: landsat-5 · scenes: 10
- Valid district coverage: 99.6% · reliable (≥3 clear obs): 15.9%
- Median clear observations per pixel: 1 · mean clear fraction of observations: 92.7%
- Permanent-water negative control (share of JRC permanent-water cells with MNDWI>0): 100%
- Residual-cloud check (valid pixels with blue SR > 0.15): 0.0%
- Reasons: median clear observations 1 < 3 (composite statistically weak) | 78% of district from a single observation

### 1995

**annual** — Status: **PASS**
- Sensors: landsat-5 · scenes: 26
- Valid district coverage: 100.0% · reliable (≥3 clear obs): 98.9%
- Median clear observations per pixel: 5 · mean clear fraction of observations: 84.5%
- Permanent-water negative control (share of JRC permanent-water cells with MNDWI>0): 100%
- Residual-cloud check (valid pixels with blue SR > 0.15): 0.0%
- Reasons: none

**dry** — Status: **PASS**
- Sensors: landsat-5 · scenes: 17
- Valid district coverage: 98.9% · reliable (≥3 clear obs): 50.7%
- Median clear observations per pixel: 3 · mean clear fraction of observations: 75.3%
- Permanent-water negative control (share of JRC permanent-water cells with MNDWI>0): 100%
- Residual-cloud check (valid pixels with blue SR > 0.15): 0.0%
- Reasons: none

**post_monsoon** — Status: **WARNING**
- Sensors: landsat-5 · scenes: 9
- Valid district coverage: 100.0% · reliable (≥3 clear obs): 18.8%
- Median clear observations per pixel: 2 · mean clear fraction of observations: 98.8%
- Permanent-water negative control (share of JRC permanent-water cells with MNDWI>0): 100%
- Residual-cloud check (valid pixels with blue SR > 0.15): 0.0%
- Reasons: median clear observations 2 < 3 (composite statistically weak)

**wet** — Status: **FAIL**
- Sensors: — · scenes: 0
- Valid district coverage: 0.0% · reliable (≥3 clear obs): 0.0%
- Median clear observations per pixel: 0 · mean clear fraction of observations: 0.0%
- Permanent-water negative control (share of JRC permanent-water cells with MNDWI>0): n/a
- Residual-cloud check (valid pixels with blue SR > 0.15): n/a
- Reasons: district valid coverage 0.0% < 50% | median clear observations 0 < 3 (composite statistically weak)

### 1996

**annual** — Status: **PASS**
- Sensors: landsat-5 · scenes: 42
- Valid district coverage: 100.0% · reliable (≥3 clear obs): 100.0%
- Median clear observations per pixel: 9 · mean clear fraction of observations: 83.2%
- Permanent-water negative control (share of JRC permanent-water cells with MNDWI>0): 100%
- Residual-cloud check (valid pixels with blue SR > 0.15): 0.0%
- Reasons: none

**dry** — Status: **PASS**
- Sensors: landsat-5 · scenes: 23
- Valid district coverage: 100.0% · reliable (≥3 clear obs): 100.0%
- Median clear observations per pixel: 5 · mean clear fraction of observations: 93.7%
- Permanent-water negative control (share of JRC permanent-water cells with MNDWI>0): 100%
- Residual-cloud check (valid pixels with blue SR > 0.15): 0.0%
- Reasons: none

**post_monsoon** — Status: **PASS**
- Sensors: landsat-5 · scenes: 11
- Valid district coverage: 100.0% · reliable (≥3 clear obs): 91.9%
- Median clear observations per pixel: 4 · mean clear fraction of observations: 96.3%
- Permanent-water negative control (share of JRC permanent-water cells with MNDWI>0): 100%
- Residual-cloud check (valid pixels with blue SR > 0.15): 0.0%
- Reasons: none

**wet** — Status: **FAIL**
- Sensors: landsat-5 · scenes: 8
- Valid district coverage: 48.8% · reliable (≥3 clear obs): 1.6%
- Median clear observations per pixel: 0 · mean clear fraction of observations: 27.5%
- Permanent-water negative control (share of JRC permanent-water cells with MNDWI>0): 100%
- Residual-cloud check (valid pixels with blue SR > 0.15): 0.23%
- Reasons: district valid coverage 48.8% < 50% | median clear observations 0 < 3 (composite statistically weak) | 36% of district from a single observation

### 1997

**annual** — Status: **PASS**
- Sensors: landsat-5 · scenes: 21
- Valid district coverage: 100.0% · reliable (≥3 clear obs): 99.9%
- Median clear observations per pixel: 5 · mean clear fraction of observations: 75.7%
- Permanent-water negative control (share of JRC permanent-water cells with MNDWI>0): 100%
- Residual-cloud check (valid pixels with blue SR > 0.15): 0.0%
- Reasons: none

**dry** — Status: **WARNING**
- Sensors: landsat-5 · scenes: 8
- Valid district coverage: 100.0% · reliable (≥3 clear obs): 15.3%
- Median clear observations per pixel: 2 · mean clear fraction of observations: 99.8%
- Permanent-water negative control (share of JRC permanent-water cells with MNDWI>0): 100%
- Residual-cloud check (valid pixels with blue SR > 0.15): 0.0%
- Reasons: median clear observations 2 < 3 (composite statistically weak)

**post_monsoon** — Status: **WARNING**
- Sensors: landsat-5 · scenes: 5
- Valid district coverage: 99.5% · reliable (≥3 clear obs): 8.8%
- Median clear observations per pixel: 2 · mean clear fraction of observations: 92.9%
- Permanent-water negative control (share of JRC permanent-water cells with MNDWI>0): 100%
- Residual-cloud check (valid pixels with blue SR > 0.15): 0.0%
- Reasons: median clear observations 2 < 3 (composite statistically weak)

**wet** — Status: **WARNING**
- Sensors: landsat-5 · scenes: 8
- Valid district coverage: 84.1% · reliable (≥3 clear obs): 16.9%
- Median clear observations per pixel: 1 · mean clear fraction of observations: 46.4%
- Permanent-water negative control (share of JRC permanent-water cells with MNDWI>0): 100%
- Residual-cloud check (valid pixels with blue SR > 0.15): 0.0%
- Reasons: district valid coverage 84.1% < 95% | median clear observations 1 < 3 (composite statistically weak) | 37% of district from a single observation

### 1998

**annual** — Status: **PASS**
- Sensors: landsat-5 · scenes: 43
- Valid district coverage: 100.0% · reliable (≥3 clear obs): 100.0%
- Median clear observations per pixel: 9 · mean clear fraction of observations: 76.0%
- Permanent-water negative control (share of JRC permanent-water cells with MNDWI>0): 100%
- Residual-cloud check (valid pixels with blue SR > 0.15): 0.0%
- Reasons: none

**dry** — Status: **PASS**
- Sensors: landsat-5 · scenes: 23
- Valid district coverage: 100.0% · reliable (≥3 clear obs): 100.0%
- Median clear observations per pixel: 6 · mean clear fraction of observations: 95.2%
- Permanent-water negative control (share of JRC permanent-water cells with MNDWI>0): 100%
- Residual-cloud check (valid pixels with blue SR > 0.15): 0.0%
- Reasons: none

**post_monsoon** — Status: **PASS**
- Sensors: landsat-5 · scenes: 15
- Valid district coverage: 99.6% · reliable (≥3 clear obs): 69.3%
- Median clear observations per pixel: 3 · mean clear fraction of observations: 58.7%
- Permanent-water negative control (share of JRC permanent-water cells with MNDWI>0): 100%
- Residual-cloud check (valid pixels with blue SR > 0.15): 0.01%
- Reasons: none

**wet** — Status: **FAIL**
- Sensors: landsat-5 · scenes: 5
- Valid district coverage: 48.3% · reliable (≥3 clear obs): 1.8%
- Median clear observations per pixel: 0 · mean clear fraction of observations: 46.8%
- Permanent-water negative control (share of JRC permanent-water cells with MNDWI>0): 99%
- Residual-cloud check (valid pixels with blue SR > 0.15): 0.0%
- Reasons: district valid coverage 48.3% < 50% | median clear observations 0 < 3 (composite statistically weak) | 36% of district from a single observation

### 1999

**annual** — Status: **PASS**
- Sensors: landsat-5,landsat-7 · scenes: 39
- Valid district coverage: 100.0% · reliable (≥3 clear obs): 100.0%
- Median clear observations per pixel: 10 · mean clear fraction of observations: 96.5%
- Permanent-water negative control (share of JRC permanent-water cells with MNDWI>0): 100%
- Residual-cloud check (valid pixels with blue SR > 0.15): 0.0%
- Reasons: none

**dry** — Status: **PASS**
- Sensors: landsat-5 · scenes: 29
- Valid district coverage: 100.0% · reliable (≥3 clear obs): 100.0%
- Median clear observations per pixel: 8 · mean clear fraction of observations: 97.8%
- Permanent-water negative control (share of JRC permanent-water cells with MNDWI>0): 100%
- Residual-cloud check (valid pixels with blue SR > 0.15): 0.0%
- Reasons: none

**post_monsoon** — Status: **WARNING**
- Sensors: landsat-7 · scenes: 8
- Valid district coverage: 100.0% · reliable (≥3 clear obs): 17.0%
- Median clear observations per pixel: 2 · mean clear fraction of observations: 92.8%
- Permanent-water negative control (share of JRC permanent-water cells with MNDWI>0): 100%
- Residual-cloud check (valid pixels with blue SR > 0.15): 0.0%
- Reasons: median clear observations 2 < 3 (composite statistically weak)

**wet** — Status: **FAIL**
- Sensors: landsat-7 · scenes: 2
- Valid district coverage: 13.6% · reliable (≥3 clear obs): 0.0%
- Median clear observations per pixel: 0 · mean clear fraction of observations: 77.2%
- Permanent-water negative control (share of JRC permanent-water cells with MNDWI>0): 100%
- Residual-cloud check (valid pixels with blue SR > 0.15): 0.01%
- Reasons: district valid coverage 13.6% < 50% | median clear observations 0 < 3 (composite statistically weak)

### 2000

**annual** — Status: **PASS**
- Sensors: landsat-5,landsat-7 · scenes: 34
- Valid district coverage: 100.0% · reliable (≥3 clear obs): 99.9%
- Median clear observations per pixel: 7 · mean clear fraction of observations: 77.7%
- Permanent-water negative control (share of JRC permanent-water cells with MNDWI>0): 100%
- Residual-cloud check (valid pixels with blue SR > 0.15): 0.0%
- Reasons: none

**dry** — Status: **PASS**
- Sensors: landsat-5,landsat-7 · scenes: 17
- Valid district coverage: 100.0% · reliable (≥3 clear obs): 97.9%
- Median clear observations per pixel: 4 · mean clear fraction of observations: 84.8%
- Permanent-water negative control (share of JRC permanent-water cells with MNDWI>0): 100%
- Residual-cloud check (valid pixels with blue SR > 0.15): 0.0%
- Reasons: none

**post_monsoon** — Status: **WARNING**
- Sensors: landsat-7 · scenes: 8
- Valid district coverage: 100.0% · reliable (≥3 clear obs): 18.7%
- Median clear observations per pixel: 2 · mean clear fraction of observations: 96.6%
- Permanent-water negative control (share of JRC permanent-water cells with MNDWI>0): 100%
- Residual-cloud check (valid pixels with blue SR > 0.15): 0.0%
- Reasons: median clear observations 2 < 3 (composite statistically weak)

**wet** — Status: **WARNING**
- Sensors: landsat-7 · scenes: 9
- Valid district coverage: 74.6% · reliable (≥3 clear obs): 6.5%
- Median clear observations per pixel: 1 · mean clear fraction of observations: 44.6%
- Permanent-water negative control (share of JRC permanent-water cells with MNDWI>0): 100%
- Residual-cloud check (valid pixels with blue SR > 0.15): 0.0%
- Reasons: district valid coverage 74.6% < 95% | median clear observations 1 < 3 (composite statistically weak) | 49% of district from a single observation

### 2001

**annual** — Status: **PASS**
- Sensors: landsat-5,landsat-7 · scenes: 38
- Valid district coverage: 100.0% · reliable (≥3 clear obs): 100.0%
- Median clear observations per pixel: 8 · mean clear fraction of observations: 85.3%
- Permanent-water negative control (share of JRC permanent-water cells with MNDWI>0): 100%
- Residual-cloud check (valid pixels with blue SR > 0.15): 0.0%
- Reasons: none

**dry** — Status: **PASS**
- Sensors: landsat-5,landsat-7 · scenes: 24
- Valid district coverage: 100.0% · reliable (≥3 clear obs): 100.0%
- Median clear observations per pixel: 6 · mean clear fraction of observations: 98.9%
- Permanent-water negative control (share of JRC permanent-water cells with MNDWI>0): 99%
- Residual-cloud check (valid pixels with blue SR > 0.15): 0.0%
- Reasons: none

**post_monsoon** — Status: **WARNING**
- Sensors: landsat-5,landsat-7 · scenes: 7
- Valid district coverage: 100.0% · reliable (≥3 clear obs): 5.9%
- Median clear observations per pixel: 1 · mean clear fraction of observations: 66.4%
- Permanent-water negative control (share of JRC permanent-water cells with MNDWI>0): 100%
- Residual-cloud check (valid pixels with blue SR > 0.15): 0.0%
- Reasons: median clear observations 1 < 3 (composite statistically weak) | 65% of district from a single observation

**wet** — Status: **WARNING**
- Sensors: landsat-5,landsat-7 · scenes: 7
- Valid district coverage: 51.3% · reliable (≥3 clear obs): 7.9%
- Median clear observations per pixel: 1 · mean clear fraction of observations: 45.4%
- Permanent-water negative control (share of JRC permanent-water cells with MNDWI>0): 100%
- Residual-cloud check (valid pixels with blue SR > 0.15): 0.02%
- Reasons: district valid coverage 51.3% < 95% | median clear observations 1 < 3 (composite statistically weak) | 35% of district from a single observation

### 2002

**annual** — Status: **PASS**
- Sensors: landsat-7 · scenes: 24
- Valid district coverage: 100.0% · reliable (≥3 clear obs): 100.0%
- Median clear observations per pixel: 6 · mean clear fraction of observations: 89.2%
- Permanent-water negative control (share of JRC permanent-water cells with MNDWI>0): 100%
- Residual-cloud check (valid pixels with blue SR > 0.15): 0.0%
- Reasons: none

**dry** — Status: **PASS**
- Sensors: landsat-7 · scenes: 11
- Valid district coverage: 100.0% · reliable (≥3 clear obs): 81.5%
- Median clear observations per pixel: 3 · mean clear fraction of observations: 91.3%
- Permanent-water negative control (share of JRC permanent-water cells with MNDWI>0): 100%
- Residual-cloud check (valid pixels with blue SR > 0.15): 0.0%
- Reasons: none

**post_monsoon** — Status: **PASS**
- Sensors: landsat-7 · scenes: 7
- Valid district coverage: 100.0% · reliable (≥3 clear obs): 79.2%
- Median clear observations per pixel: 3 · mean clear fraction of observations: 96.3%
- Permanent-water negative control (share of JRC permanent-water cells with MNDWI>0): 100%
- Residual-cloud check (valid pixels with blue SR > 0.15): 0.0%
- Reasons: none

**wet** — Status: **WARNING**
- Sensors: landsat-7 · scenes: 6
- Valid district coverage: 65.6% · reliable (≥3 clear obs): 13.8%
- Median clear observations per pixel: 1 · mean clear fraction of observations: 64.2%
- Permanent-water negative control (share of JRC permanent-water cells with MNDWI>0): 100%
- Residual-cloud check (valid pixels with blue SR > 0.15): 0.0%
- Reasons: district valid coverage 65.6% < 95% | median clear observations 1 < 3 (composite statistically weak) | 45% of district from a single observation

### 2003

**annual** — Status: **WARNING**
- Sensors: landsat-7 · scenes: 29
- Valid district coverage: 100.0% · reliable (≥3 clear obs): 99.9%
- Median clear observations per pixel: 4 · mean clear fraction of observations: 89.6%
- Permanent-water negative control (share of JRC permanent-water cells with MNDWI>0): 100%
- Residual-cloud check (valid pixels with blue SR > 0.15): 0.0%
- Reasons: Landsat-7 SLC-off is the only sensor (striping gaps filled only by repeat passes)

**dry** — Status: **WARNING**
- Sensors: landsat-7 · scenes: 14
- Valid district coverage: 100.0% · reliable (≥3 clear obs): 21.9%
- Median clear observations per pixel: 2 · mean clear fraction of observations: 98.2%
- Permanent-water negative control (share of JRC permanent-water cells with MNDWI>0): 100%
- Residual-cloud check (valid pixels with blue SR > 0.15): 0.0%
- Reasons: median clear observations 2 < 3 (composite statistically weak)

**post_monsoon** — Status: **WARNING**
- Sensors: landsat-7 · scenes: 13
- Valid district coverage: 99.7% · reliable (≥3 clear obs): 31.5%
- Median clear observations per pixel: 2 · mean clear fraction of observations: 96.5%
- Permanent-water negative control (share of JRC permanent-water cells with MNDWI>0): 100%
- Residual-cloud check (valid pixels with blue SR > 0.15): 0.01%
- Reasons: median clear observations 2 < 3 (composite statistically weak) | Landsat-7 SLC-off is the only sensor (striping gaps filled only by repeat passes)

**wet** — Status: **FAIL**
- Sensors: landsat-7 · scenes: 2
- Valid district coverage: 19.2% · reliable (≥3 clear obs): 0.0%
- Median clear observations per pixel: 0 · mean clear fraction of observations: 32.6%
- Permanent-water negative control (share of JRC permanent-water cells with MNDWI>0): 100%
- Residual-cloud check (valid pixels with blue SR > 0.15): 0.0%
- Reasons: district valid coverage 19.2% < 50% | median clear observations 0 < 3 (composite statistically weak) | Landsat-7 SLC-off is the only sensor (striping gaps filled only by repeat passes)

### 2004

**annual** — Status: **WARNING**
- Sensors: landsat-7 · scenes: 45
- Valid district coverage: 100.0% · reliable (≥3 clear obs): 96.1%
- Median clear observations per pixel: 7 · mean clear fraction of observations: 90.5%
- Permanent-water negative control (share of JRC permanent-water cells with MNDWI>0): 100%
- Residual-cloud check (valid pixels with blue SR > 0.15): 0.0%
- Reasons: Landsat-7 SLC-off is the only sensor (striping gaps filled only by repeat passes)

**dry** — Status: **WARNING**
- Sensors: landsat-7 · scenes: 18
- Valid district coverage: 92.0% · reliable (≥3 clear obs): 54.8%
- Median clear observations per pixel: 3 · mean clear fraction of observations: 98.4%
- Permanent-water negative control (share of JRC permanent-water cells with MNDWI>0): 100%
- Residual-cloud check (valid pixels with blue SR > 0.15): 0.0%
- Reasons: district valid coverage 92.0% < 95% | Landsat-7 SLC-off is the only sensor (striping gaps filled only by repeat passes)

**post_monsoon** — Status: **WARNING**
- Sensors: landsat-7 · scenes: 21
- Valid district coverage: 100.0% · reliable (≥3 clear obs): 89.0%
- Median clear observations per pixel: 4 · mean clear fraction of observations: 95.0%
- Permanent-water negative control (share of JRC permanent-water cells with MNDWI>0): 100%
- Residual-cloud check (valid pixels with blue SR > 0.15): 0.0%
- Reasons: Landsat-7 SLC-off is the only sensor (striping gaps filled only by repeat passes)

**wet** — Status: **FAIL**
- Sensors: landsat-7 · scenes: 6
- Valid district coverage: 26.6% · reliable (≥3 clear obs): 1.7%
- Median clear observations per pixel: 0 · mean clear fraction of observations: 35.4%
- Permanent-water negative control (share of JRC permanent-water cells with MNDWI>0): 100%
- Residual-cloud check (valid pixels with blue SR > 0.15): 0.05%
- Reasons: district valid coverage 26.6% < 50% | median clear observations 0 < 3 (composite statistically weak) | Landsat-7 SLC-off is the only sensor (striping gaps filled only by repeat passes)

### 2005

**annual** — Status: **WARNING**
- Sensors: landsat-7 · scenes: 45
- Valid district coverage: 100.0% · reliable (≥3 clear obs): 96.1%
- Median clear observations per pixel: 5 · mean clear fraction of observations: 79.9%
- Permanent-water negative control (share of JRC permanent-water cells with MNDWI>0): 100%
- Residual-cloud check (valid pixels with blue SR > 0.15): 0.0%
- Reasons: Landsat-7 SLC-off is the only sensor (striping gaps filled only by repeat passes)

**dry** — Status: **WARNING**
- Sensors: landsat-7 · scenes: 26
- Valid district coverage: 100.0% · reliable (≥3 clear obs): 68.4%
- Median clear observations per pixel: 3 · mean clear fraction of observations: 90.5%
- Permanent-water negative control (share of JRC permanent-water cells with MNDWI>0): 100%
- Residual-cloud check (valid pixels with blue SR > 0.15): 0.0%
- Reasons: Landsat-7 SLC-off is the only sensor (striping gaps filled only by repeat passes)

**post_monsoon** — Status: **WARNING**
- Sensors: landsat-7 · scenes: 13
- Valid district coverage: 73.7% · reliable (≥3 clear obs): 13.5%
- Median clear observations per pixel: 1 · mean clear fraction of observations: 99.2%
- Permanent-water negative control (share of JRC permanent-water cells with MNDWI>0): 100%
- Residual-cloud check (valid pixels with blue SR > 0.15): 0.0%
- Reasons: district valid coverage 73.7% < 95% | median clear observations 1 < 3 (composite statistically weak) | 55% of district from a single observation | Landsat-7 SLC-off is the only sensor (striping gaps filled only by repeat passes)

**wet** — Status: **WARNING**
- Sensors: landsat-7 · scenes: 6
- Valid district coverage: 60.1% · reliable (≥3 clear obs): 4.6%
- Median clear observations per pixel: 1 · mean clear fraction of observations: 49.1%
- Permanent-water negative control (share of JRC permanent-water cells with MNDWI>0): 99%
- Residual-cloud check (valid pixels with blue SR > 0.15): 0.0%
- Reasons: district valid coverage 60.1% < 95% | median clear observations 1 < 3 (composite statistically weak) | 35% of district from a single observation | Landsat-7 SLC-off is the only sensor (striping gaps filled only by repeat passes)

### 2006

**annual** — Status: **WARNING**
- Sensors: landsat-7 · scenes: 53
- Valid district coverage: 100.0% · reliable (≥3 clear obs): 99.6%
- Median clear observations per pixel: 8 · mean clear fraction of observations: 85.1%
- Permanent-water negative control (share of JRC permanent-water cells with MNDWI>0): 100%
- Residual-cloud check (valid pixels with blue SR > 0.15): 0.0%
- Reasons: Landsat-7 SLC-off is the only sensor (striping gaps filled only by repeat passes)

**dry** — Status: **WARNING**
- Sensors: landsat-7 · scenes: 30
- Valid district coverage: 100.0% · reliable (≥3 clear obs): 87.2%
- Median clear observations per pixel: 5 · mean clear fraction of observations: 92.9%
- Permanent-water negative control (share of JRC permanent-water cells with MNDWI>0): 100%
- Residual-cloud check (valid pixels with blue SR > 0.15): 0.0%
- Reasons: Landsat-7 SLC-off is the only sensor (striping gaps filled only by repeat passes)

**post_monsoon** — Status: **WARNING**
- Sensors: landsat-7 · scenes: 18
- Valid district coverage: 98.8% · reliable (≥3 clear obs): 54.2%
- Median clear observations per pixel: 3 · mean clear fraction of observations: 87.5%
- Permanent-water negative control (share of JRC permanent-water cells with MNDWI>0): 100%
- Residual-cloud check (valid pixels with blue SR > 0.15): 0.0%
- Reasons: Landsat-7 SLC-off is the only sensor (striping gaps filled only by repeat passes)

**wet** — Status: **WARNING**
- Sensors: landsat-7 · scenes: 5
- Valid district coverage: 55.9% · reliable (≥3 clear obs): 0.2%
- Median clear observations per pixel: 1 · mean clear fraction of observations: 53.1%
- Permanent-water negative control (share of JRC permanent-water cells with MNDWI>0): 100%
- Residual-cloud check (valid pixels with blue SR > 0.15): 0.01%
- Reasons: district valid coverage 55.9% < 95% | median clear observations 1 < 3 (composite statistically weak) | 42% of district from a single observation | Landsat-7 SLC-off is the only sensor (striping gaps filled only by repeat passes)

### 2007

**annual** — Status: **WARNING**
- Sensors: landsat-7 · scenes: 53
- Valid district coverage: 100.0% · reliable (≥3 clear obs): 100.0%
- Median clear observations per pixel: 9 · mean clear fraction of observations: 92.5%
- Permanent-water negative control (share of JRC permanent-water cells with MNDWI>0): 100%
- Residual-cloud check (valid pixels with blue SR > 0.15): 0.0%
- Reasons: Landsat-7 SLC-off is the only sensor (striping gaps filled only by repeat passes)

**dry** — Status: **WARNING**
- Sensors: landsat-7 · scenes: 31
- Valid district coverage: 99.9% · reliable (≥3 clear obs): 97.4%
- Median clear observations per pixel: 6 · mean clear fraction of observations: 98.5%
- Permanent-water negative control (share of JRC permanent-water cells with MNDWI>0): 100%
- Residual-cloud check (valid pixels with blue SR > 0.15): 0.0%
- Reasons: Landsat-7 SLC-off is the only sensor (striping gaps filled only by repeat passes)

**post_monsoon** — Status: **WARNING**
- Sensors: landsat-7 · scenes: 17
- Valid district coverage: 98.9% · reliable (≥3 clear obs): 58.8%
- Median clear observations per pixel: 3 · mean clear fraction of observations: 94.5%
- Permanent-water negative control (share of JRC permanent-water cells with MNDWI>0): 100%
- Residual-cloud check (valid pixels with blue SR > 0.15): 0.0%
- Reasons: Landsat-7 SLC-off is the only sensor (striping gaps filled only by repeat passes)

**wet** — Status: **FAIL**
- Sensors: landsat-7 · scenes: 5
- Valid district coverage: 29.7% · reliable (≥3 clear obs): 0.2%
- Median clear observations per pixel: 0 · mean clear fraction of observations: 39.0%
- Permanent-water negative control (share of JRC permanent-water cells with MNDWI>0): 100%
- Residual-cloud check (valid pixels with blue SR > 0.15): 0.15%
- Reasons: district valid coverage 29.7% < 50% | median clear observations 0 < 3 (composite statistically weak) | 27% of district from a single observation | Landsat-7 SLC-off is the only sensor (striping gaps filled only by repeat passes)

### 2008

**annual** — Status: **PASS**
- Sensors: landsat-5,landsat-7 · scenes: 76
- Valid district coverage: 100.0% · reliable (≥3 clear obs): 100.0%
- Median clear observations per pixel: 15 · mean clear fraction of observations: 89.2%
- Permanent-water negative control (share of JRC permanent-water cells with MNDWI>0): 100%
- Residual-cloud check (valid pixels with blue SR > 0.15): 0.0%
- Reasons: none

**dry** — Status: **PASS**
- Sensors: landsat-5,landsat-7 · scenes: 44
- Valid district coverage: 100.0% · reliable (≥3 clear obs): 99.8%
- Median clear observations per pixel: 8 · mean clear fraction of observations: 97.5%
- Permanent-water negative control (share of JRC permanent-water cells with MNDWI>0): 100%
- Residual-cloud check (valid pixels with blue SR > 0.15): 0.0%
- Reasons: none

**post_monsoon** — Status: **PASS**
- Sensors: landsat-5,landsat-7 · scenes: 26
- Valid district coverage: 100.0% · reliable (≥3 clear obs): 99.5%
- Median clear observations per pixel: 7 · mean clear fraction of observations: 93.6%
- Permanent-water negative control (share of JRC permanent-water cells with MNDWI>0): 100%
- Residual-cloud check (valid pixels with blue SR > 0.15): 0.0%
- Reasons: none

**wet** — Status: **WARNING**
- Sensors: landsat-5,landsat-7 · scenes: 6
- Valid district coverage: 92.0% · reliable (≥3 clear obs): 4.3%
- Median clear observations per pixel: 1 · mean clear fraction of observations: 50.3%
- Permanent-water negative control (share of JRC permanent-water cells with MNDWI>0): 100%
- Residual-cloud check (valid pixels with blue SR > 0.15): 0.07%
- Reasons: district valid coverage 92.0% < 95% | median clear observations 1 < 3 (composite statistically weak) | 51% of district from a single observation

### 2009

**annual** — Status: **PASS**
- Sensors: landsat-5,landsat-7 · scenes: 67
- Valid district coverage: 100.0% · reliable (≥3 clear obs): 100.0%
- Median clear observations per pixel: 17 · mean clear fraction of observations: 90.3%
- Permanent-water negative control (share of JRC permanent-water cells with MNDWI>0): 100%
- Residual-cloud check (valid pixels with blue SR > 0.15): 0.0%
- Reasons: none

**dry** — Status: **PASS**
- Sensors: landsat-5,landsat-7 · scenes: 42
- Valid district coverage: 100.0% · reliable (≥3 clear obs): 100.0%
- Median clear observations per pixel: 11 · mean clear fraction of observations: 94.9%
- Permanent-water negative control (share of JRC permanent-water cells with MNDWI>0): 100%
- Residual-cloud check (valid pixels with blue SR > 0.15): 0.0%
- Reasons: none

**post_monsoon** — Status: **PASS**
- Sensors: landsat-5,landsat-7 · scenes: 18
- Valid district coverage: 99.2% · reliable (≥3 clear obs): 96.1%
- Median clear observations per pixel: 5 · mean clear fraction of observations: 87.7%
- Permanent-water negative control (share of JRC permanent-water cells with MNDWI>0): 100%
- Residual-cloud check (valid pixels with blue SR > 0.15): 0.0%
- Reasons: none

**wet** — Status: **WARNING**
- Sensors: landsat-5,landsat-7 · scenes: 7
- Valid district coverage: 75.4% · reliable (≥3 clear obs): 6.9%
- Median clear observations per pixel: 1 · mean clear fraction of observations: 67.1%
- Permanent-water negative control (share of JRC permanent-water cells with MNDWI>0): 100%
- Residual-cloud check (valid pixels with blue SR > 0.15): 0.03%
- Reasons: district valid coverage 75.4% < 95% | median clear observations 1 < 3 (composite statistically weak) | 62% of district from a single observation

### 2010

**annual** — Status: **PASS**
- Sensors: landsat-5,landsat-7 · scenes: 47
- Valid district coverage: 100.0% · reliable (≥3 clear obs): 99.6%
- Median clear observations per pixel: 12 · mean clear fraction of observations: 92.3%
- Permanent-water negative control (share of JRC permanent-water cells with MNDWI>0): 100%
- Residual-cloud check (valid pixels with blue SR > 0.15): 0.0%
- Reasons: none

**dry** — Status: **PASS**
- Sensors: landsat-5,landsat-7 · scenes: 34
- Valid district coverage: 100.0% · reliable (≥3 clear obs): 99.6%
- Median clear observations per pixel: 9 · mean clear fraction of observations: 95.2%
- Permanent-water negative control (share of JRC permanent-water cells with MNDWI>0): 100%
- Residual-cloud check (valid pixels with blue SR > 0.15): 0.0%
- Reasons: none

**post_monsoon** — Status: **WARNING**
- Sensors: landsat-5,landsat-7 · scenes: 8
- Valid district coverage: 92.1% · reliable (≥3 clear obs): 21.3%
- Median clear observations per pixel: 2 · mean clear fraction of observations: 87.3%
- Permanent-water negative control (share of JRC permanent-water cells with MNDWI>0): 100%
- Residual-cloud check (valid pixels with blue SR > 0.15): 0.03%
- Reasons: district valid coverage 92.1% < 95% | median clear observations 2 < 3 (composite statistically weak)

**wet** — Status: **WARNING**
- Sensors: landsat-5,landsat-7 · scenes: 5
- Valid district coverage: 57.2% · reliable (≥3 clear obs): 5.5%
- Median clear observations per pixel: 1 · mean clear fraction of observations: 70.4%
- Permanent-water negative control (share of JRC permanent-water cells with MNDWI>0): 100%
- Residual-cloud check (valid pixels with blue SR > 0.15): 0.01%
- Reasons: district valid coverage 57.2% < 95% | median clear observations 1 < 3 (composite statistically weak) | 42% of district from a single observation

### 2011

**annual** — Status: **PASS**
- Sensors: landsat-5,landsat-7 · scenes: 40
- Valid district coverage: 100.0% · reliable (≥3 clear obs): 99.5%
- Median clear observations per pixel: 8 · mean clear fraction of observations: 85.4%
- Permanent-water negative control (share of JRC permanent-water cells with MNDWI>0): 100%
- Residual-cloud check (valid pixels with blue SR > 0.15): 0.0%
- Reasons: none

**dry** — Status: **PASS**
- Sensors: landsat-5,landsat-7 · scenes: 17
- Valid district coverage: 100.0% · reliable (≥3 clear obs): 98.0%
- Median clear observations per pixel: 6 · mean clear fraction of observations: 93.9%
- Permanent-water negative control (share of JRC permanent-water cells with MNDWI>0): 100%
- Residual-cloud check (valid pixels with blue SR > 0.15): 0.0%
- Reasons: none

**post_monsoon** — Status: **WARNING**
- Sensors: landsat-7 · scenes: 16
- Valid district coverage: 95.8% · reliable (≥3 clear obs): 31.1%
- Median clear observations per pixel: 2 · mean clear fraction of observations: 86.9%
- Permanent-water negative control (share of JRC permanent-water cells with MNDWI>0): 100%
- Residual-cloud check (valid pixels with blue SR > 0.15): 0.0%
- Reasons: median clear observations 2 < 3 (composite statistically weak) | 31% of district from a single observation | Landsat-7 SLC-off is the only sensor (striping gaps filled only by repeat passes)

**wet** — Status: **FAIL**
- Sensors: landsat-5,landsat-7 · scenes: 7
- Valid district coverage: 24.9% · reliable (≥3 clear obs): 0.2%
- Median clear observations per pixel: 0 · mean clear fraction of observations: 29.4%
- Permanent-water negative control (share of JRC permanent-water cells with MNDWI>0): 100%
- Residual-cloud check (valid pixels with blue SR > 0.15): 0.08%
- Reasons: district valid coverage 24.9% < 50% | median clear observations 0 < 3 (composite statistically weak)

### 2012

**annual** — Status: **WARNING**
- Sensors: landsat-7 · scenes: 62
- Valid district coverage: 100.0% · reliable (≥3 clear obs): 100.0%
- Median clear observations per pixel: 9 · mean clear fraction of observations: 88.8%
- Permanent-water negative control (share of JRC permanent-water cells with MNDWI>0): 100%
- Residual-cloud check (valid pixels with blue SR > 0.15): 0.0%
- Reasons: Landsat-7 SLC-off is the only sensor (striping gaps filled only by repeat passes)

**dry** — Status: **WARNING**
- Sensors: landsat-7 · scenes: 35
- Valid district coverage: 100.0% · reliable (≥3 clear obs): 100.0%
- Median clear observations per pixel: 6 · mean clear fraction of observations: 97.9%
- Permanent-water negative control (share of JRC permanent-water cells with MNDWI>0): 100%
- Residual-cloud check (valid pixels with blue SR > 0.15): 0.0%
- Reasons: Landsat-7 SLC-off is the only sensor (striping gaps filled only by repeat passes)

**post_monsoon** — Status: **WARNING**
- Sensors: landsat-7 · scenes: 18
- Valid district coverage: 98.5% · reliable (≥3 clear obs): 43.5%
- Median clear observations per pixel: 2 · mean clear fraction of observations: 96.3%
- Permanent-water negative control (share of JRC permanent-water cells with MNDWI>0): 100%
- Residual-cloud check (valid pixels with blue SR > 0.15): 0.0%
- Reasons: median clear observations 2 < 3 (composite statistically weak) | Landsat-7 SLC-off is the only sensor (striping gaps filled only by repeat passes)

**wet** — Status: **FAIL**
- Sensors: landsat-7 · scenes: 9
- Valid district coverage: 47.8% · reliable (≥3 clear obs): 2.0%
- Median clear observations per pixel: 0 · mean clear fraction of observations: 38.3%
- Permanent-water negative control (share of JRC permanent-water cells with MNDWI>0): 100%
- Residual-cloud check (valid pixels with blue SR > 0.15): 0.01%
- Reasons: district valid coverage 47.8% < 50% | median clear observations 0 < 3 (composite statistically weak) | 36% of district from a single observation | Landsat-7 SLC-off is the only sensor (striping gaps filled only by repeat passes)

### 2013

**annual** — Status: **PASS**
- Sensors: landsat-7,landsat-8 · scenes: 90
- Valid district coverage: 100.0% · reliable (≥3 clear obs): 100.0%
- Median clear observations per pixel: 18 · mean clear fraction of observations: 85.6%
- Permanent-water negative control (share of JRC permanent-water cells with MNDWI>0): 100%
- Residual-cloud check (valid pixels with blue SR > 0.15): 0.0%
- Reasons: none

**dry** — Status: **PASS**
- Sensors: landsat-7,landsat-8 · scenes: 43
- Valid district coverage: 100.0% · reliable (≥3 clear obs): 99.8%
- Median clear observations per pixel: 10 · mean clear fraction of observations: 88.7%
- Permanent-water negative control (share of JRC permanent-water cells with MNDWI>0): 100%
- Residual-cloud check (valid pixels with blue SR > 0.15): 0.0%
- Reasons: none

**post_monsoon** — Status: **PASS**
- Sensors: landsat-7,landsat-8 · scenes: 38
- Valid district coverage: 100.0% · reliable (≥3 clear obs): 100.0%
- Median clear observations per pixel: 8 · mean clear fraction of observations: 85.1%
- Permanent-water negative control (share of JRC permanent-water cells with MNDWI>0): 100%
- Residual-cloud check (valid pixels with blue SR > 0.15): 0.0%
- Reasons: none

**wet** — Status: **FAIL**
- Sensors: landsat-7,landsat-8 · scenes: 9
- Valid district coverage: 49.0% · reliable (≥3 clear obs): 1.0%
- Median clear observations per pixel: 0 · mean clear fraction of observations: 57.9%
- Permanent-water negative control (share of JRC permanent-water cells with MNDWI>0): 100%
- Residual-cloud check (valid pixels with blue SR > 0.15): 0.02%
- Reasons: district valid coverage 49.0% < 50% | median clear observations 0 < 3 (composite statistically weak) | 44% of district from a single observation

### 2014

**annual** — Status: **PASS**
- Sensors: landsat-7,landsat-8 · scenes: 127
- Valid district coverage: 100.0% · reliable (≥3 clear obs): 100.0%
- Median clear observations per pixel: 23 · mean clear fraction of observations: 80.3%
- Permanent-water negative control (share of JRC permanent-water cells with MNDWI>0): 100%
- Residual-cloud check (valid pixels with blue SR > 0.15): 0.0%
- Reasons: none

**dry** — Status: **PASS**
- Sensors: landsat-7,landsat-8 · scenes: 63
- Valid district coverage: 100.0% · reliable (≥3 clear obs): 100.0%
- Median clear observations per pixel: 14 · mean clear fraction of observations: 90.5%
- Permanent-water negative control (share of JRC permanent-water cells with MNDWI>0): 100%
- Residual-cloud check (valid pixels with blue SR > 0.15): 0.0%
- Reasons: none

**post_monsoon** — Status: **PASS**
- Sensors: landsat-7,landsat-8 · scenes: 39
- Valid district coverage: 100.0% · reliable (≥3 clear obs): 99.6%
- Median clear observations per pixel: 6 · mean clear fraction of observations: 85.5%
- Permanent-water negative control (share of JRC permanent-water cells with MNDWI>0): 100%
- Residual-cloud check (valid pixels with blue SR > 0.15): 0.0%
- Reasons: none

**wet** — Status: **PASS**
- Sensors: landsat-7,landsat-8 · scenes: 25
- Valid district coverage: 100.0% · reliable (≥3 clear obs): 62.5%
- Median clear observations per pixel: 3 · mean clear fraction of observations: 49.2%
- Permanent-water negative control (share of JRC permanent-water cells with MNDWI>0): 100%
- Residual-cloud check (valid pixels with blue SR > 0.15): 0.0%
- Reasons: none

### 2015

**annual** — Status: **PASS**
- Sensors: landsat-7,landsat-8 · scenes: 145
- Valid district coverage: 100.0% · reliable (≥3 clear obs): 100.0%
- Median clear observations per pixel: 25 · mean clear fraction of observations: 80.9%
- Permanent-water negative control (share of JRC permanent-water cells with MNDWI>0): 100%
- Residual-cloud check (valid pixels with blue SR > 0.15): 0.0%
- Reasons: none

**dry** — Status: **PASS**
- Sensors: landsat-7,landsat-8 · scenes: 70
- Valid district coverage: 100.0% · reliable (≥3 clear obs): 100.0%
- Median clear observations per pixel: 14 · mean clear fraction of observations: 89.0%
- Permanent-water negative control (share of JRC permanent-water cells with MNDWI>0): 100%
- Residual-cloud check (valid pixels with blue SR > 0.15): 0.0%
- Reasons: none

**post_monsoon** — Status: **PASS**
- Sensors: landsat-7,landsat-8 · scenes: 46
- Valid district coverage: 100.0% · reliable (≥3 clear obs): 100.0%
- Median clear observations per pixel: 9 · mean clear fraction of observations: 86.8%
- Permanent-water negative control (share of JRC permanent-water cells with MNDWI>0): 100%
- Residual-cloud check (valid pixels with blue SR > 0.15): 0.0%
- Reasons: none

**wet** — Status: **PASS**
- Sensors: landsat-7,landsat-8 · scenes: 29
- Valid district coverage: 95.6% · reliable (≥3 clear obs): 50.3%
- Median clear observations per pixel: 3 · mean clear fraction of observations: 46.4%
- Permanent-water negative control (share of JRC permanent-water cells with MNDWI>0): 99%
- Residual-cloud check (valid pixels with blue SR > 0.15): 0.03%
- Reasons: none

### 2016

**annual** — Status: **PASS**
- Sensors: landsat-7,landsat-8 · scenes: 125
- Valid district coverage: 100.0% · reliable (≥3 clear obs): 100.0%
- Median clear observations per pixel: 24 · mean clear fraction of observations: 84.6%
- Permanent-water negative control (share of JRC permanent-water cells with MNDWI>0): 100%
- Residual-cloud check (valid pixels with blue SR > 0.15): 0.0%
- Reasons: none

**dry** — Status: **PASS**
- Sensors: landsat-7,landsat-8 · scenes: 76
- Valid district coverage: 100.0% · reliable (≥3 clear obs): 100.0%
- Median clear observations per pixel: 15 · mean clear fraction of observations: 87.8%
- Permanent-water negative control (share of JRC permanent-water cells with MNDWI>0): 100%
- Residual-cloud check (valid pixels with blue SR > 0.15): 0.0%
- Reasons: none

**post_monsoon** — Status: **PASS**
- Sensors: landsat-7,landsat-8 · scenes: 42
- Valid district coverage: 100.0% · reliable (≥3 clear obs): 100.0%
- Median clear observations per pixel: 8 · mean clear fraction of observations: 92.7%
- Permanent-water negative control (share of JRC permanent-water cells with MNDWI>0): 100%
- Residual-cloud check (valid pixels with blue SR > 0.15): 0.0%
- Reasons: none

**wet** — Status: **WARNING**
- Sensors: landsat-7,landsat-8 · scenes: 7
- Valid district coverage: 52.1% · reliable (≥3 clear obs): 2.0%
- Median clear observations per pixel: 1 · mean clear fraction of observations: 27.5%
- Permanent-water negative control (share of JRC permanent-water cells with MNDWI>0): 85%
- Residual-cloud check (valid pixels with blue SR > 0.15): 0.02%
- Reasons: district valid coverage 52.1% < 95% | median clear observations 1 < 3 (composite statistically weak) | 37% of district from a single observation

### 2017

**annual** — Status: **PASS**
- Sensors: landsat-7,landsat-8 · scenes: 130
- Valid district coverage: 100.0% · reliable (≥3 clear obs): 100.0%
- Median clear observations per pixel: 23 · mean clear fraction of observations: 79.2%
- Permanent-water negative control (share of JRC permanent-water cells with MNDWI>0): 100%
- Residual-cloud check (valid pixels with blue SR > 0.15): 0.0%
- Reasons: none

**dry** — Status: **PASS**
- Sensors: landsat-7,landsat-8 · scenes: 70
- Valid district coverage: 100.0% · reliable (≥3 clear obs): 100.0%
- Median clear observations per pixel: 16 · mean clear fraction of observations: 93.4%
- Permanent-water negative control (share of JRC permanent-water cells with MNDWI>0): 100%
- Residual-cloud check (valid pixels with blue SR > 0.15): 0.0%
- Reasons: none

**post_monsoon** — Status: **PASS**
- Sensors: landsat-7,landsat-8 · scenes: 42
- Valid district coverage: 100.0% · reliable (≥3 clear obs): 99.9%
- Median clear observations per pixel: 7 · mean clear fraction of observations: 73.3%
- Permanent-water negative control (share of JRC permanent-water cells with MNDWI>0): 100%
- Residual-cloud check (valid pixels with blue SR > 0.15): 0.0%
- Reasons: none

**wet** — Status: **WARNING**
- Sensors: landsat-7,landsat-8 · scenes: 18
- Valid district coverage: 73.1% · reliable (≥3 clear obs): 14.0%
- Median clear observations per pixel: 1 · mean clear fraction of observations: 28.9%
- Permanent-water negative control (share of JRC permanent-water cells with MNDWI>0): 99%
- Residual-cloud check (valid pixels with blue SR > 0.15): 0.02%
- Reasons: district valid coverage 73.1% < 95% | median clear observations 1 < 3 (composite statistically weak) | 37% of district from a single observation

### 2018

**annual** — Status: **PASS**
- Sensors: landsat-7,landsat-8 · scenes: 136
- Valid district coverage: 100.0% · reliable (≥3 clear obs): 100.0%
- Median clear observations per pixel: 26 · mean clear fraction of observations: 83.1%
- Permanent-water negative control (share of JRC permanent-water cells with MNDWI>0): 100%
- Residual-cloud check (valid pixels with blue SR > 0.15): 0.0%
- Reasons: none

**dry** — Status: **PASS**
- Sensors: landsat-7,landsat-8 · scenes: 72
- Valid district coverage: 100.0% · reliable (≥3 clear obs): 100.0%
- Median clear observations per pixel: 16 · mean clear fraction of observations: 96.3%
- Permanent-water negative control (share of JRC permanent-water cells with MNDWI>0): 100%
- Residual-cloud check (valid pixels with blue SR > 0.15): 0.0%
- Reasons: none

**post_monsoon** — Status: **PASS**
- Sensors: landsat-7,landsat-8 · scenes: 44
- Valid district coverage: 100.0% · reliable (≥3 clear obs): 100.0%
- Median clear observations per pixel: 9 · mean clear fraction of observations: 82.1%
- Permanent-water negative control (share of JRC permanent-water cells with MNDWI>0): 100%
- Residual-cloud check (valid pixels with blue SR > 0.15): 0.0%
- Reasons: none

**wet** — Status: **WARNING**
- Sensors: landsat-7,landsat-8 · scenes: 20
- Valid district coverage: 92.3% · reliable (≥3 clear obs): 29.8%
- Median clear observations per pixel: 2 · mean clear fraction of observations: 39.9%
- Permanent-water negative control (share of JRC permanent-water cells with MNDWI>0): 97%
- Residual-cloud check (valid pixels with blue SR > 0.15): 0.0%
- Reasons: district valid coverage 92.3% < 95% | median clear observations 2 < 3 (composite statistically weak) | 31% of district from a single observation

### 2019

**annual** — Status: **PASS**
- Sensors: landsat-7,landsat-8 · scenes: 133
- Valid district coverage: 100.0% · reliable (≥3 clear obs): 100.0%
- Median clear observations per pixel: 25 · mean clear fraction of observations: 81.4%
- Permanent-water negative control (share of JRC permanent-water cells with MNDWI>0): 100%
- Residual-cloud check (valid pixels with blue SR > 0.15): 0.0%
- Reasons: none

**dry** — Status: **PASS**
- Sensors: landsat-7,landsat-8 · scenes: 76
- Valid district coverage: 100.0% · reliable (≥3 clear obs): 100.0%
- Median clear observations per pixel: 16 · mean clear fraction of observations: 97.1%
- Permanent-water negative control (share of JRC permanent-water cells with MNDWI>0): 100%
- Residual-cloud check (valid pixels with blue SR > 0.15): 0.0%
- Reasons: none

**post_monsoon** — Status: **PASS**
- Sensors: landsat-7,landsat-8 · scenes: 39
- Valid district coverage: 100.0% · reliable (≥3 clear obs): 99.9%
- Median clear observations per pixel: 8 · mean clear fraction of observations: 76.5%
- Permanent-water negative control (share of JRC permanent-water cells with MNDWI>0): 100%
- Residual-cloud check (valid pixels with blue SR > 0.15): 0.0%
- Reasons: none

**wet** — Status: **WARNING**
- Sensors: landsat-7,landsat-8 · scenes: 18
- Valid district coverage: 60.0% · reliable (≥3 clear obs): 9.5%
- Median clear observations per pixel: 1 · mean clear fraction of observations: 22.3%
- Permanent-water negative control (share of JRC permanent-water cells with MNDWI>0): 95%
- Residual-cloud check (valid pixels with blue SR > 0.15): 0.12%
- Reasons: district valid coverage 60.0% < 95% | median clear observations 1 < 3 (composite statistically weak) | 33% of district from a single observation

### 2020

**annual** — Status: **PASS**
- Sensors: landsat-7,landsat-8 · scenes: 129
- Valid district coverage: 100.0% · reliable (≥3 clear obs): 100.0%
- Median clear observations per pixel: 25 · mean clear fraction of observations: 78.1%
- Permanent-water negative control (share of JRC permanent-water cells with MNDWI>0): 100%
- Residual-cloud check (valid pixels with blue SR > 0.15): 0.0%
- Reasons: none

**dry** — Status: **PASS**
- Sensors: landsat-7,landsat-8 · scenes: 71
- Valid district coverage: 100.0% · reliable (≥3 clear obs): 100.0%
- Median clear observations per pixel: 15 · mean clear fraction of observations: 91.9%
- Permanent-water negative control (share of JRC permanent-water cells with MNDWI>0): 100%
- Residual-cloud check (valid pixels with blue SR > 0.15): 0.0%
- Reasons: none

**post_monsoon** — Status: **PASS**
- Sensors: landsat-7,landsat-8 · scenes: 38
- Valid district coverage: 100.0% · reliable (≥3 clear obs): 100.0%
- Median clear observations per pixel: 8 · mean clear fraction of observations: 87.2%
- Permanent-water negative control (share of JRC permanent-water cells with MNDWI>0): 100%
- Residual-cloud check (valid pixels with blue SR > 0.15): 0.0%
- Reasons: none

**wet** — Status: **WARNING**
- Sensors: landsat-7,landsat-8 · scenes: 20
- Valid district coverage: 94.3% · reliable (≥3 clear obs): 49.2%
- Median clear observations per pixel: 2 · mean clear fraction of observations: 35.2%
- Permanent-water negative control (share of JRC permanent-water cells with MNDWI>0): 100%
- Residual-cloud check (valid pixels with blue SR > 0.15): 0.2%
- Reasons: district valid coverage 94.3% < 95% | median clear observations 2 < 3 (composite statistically weak)

### 2021

**annual** — Status: **PASS**
- Sensors: landsat-7,landsat-8,landsat-9 · scenes: 127
- Valid district coverage: 100.0% · reliable (≥3 clear obs): 100.0%
- Median clear observations per pixel: 19 · mean clear fraction of observations: 70.3%
- Permanent-water negative control (share of JRC permanent-water cells with MNDWI>0): 100%
- Residual-cloud check (valid pixels with blue SR > 0.15): 0.0%
- Reasons: none

**dry** — Status: **PASS**
- Sensors: landsat-7,landsat-8 · scenes: 72
- Valid district coverage: 100.0% · reliable (≥3 clear obs): 100.0%
- Median clear observations per pixel: 13 · mean clear fraction of observations: 84.2%
- Permanent-water negative control (share of JRC permanent-water cells with MNDWI>0): 100%
- Residual-cloud check (valid pixels with blue SR > 0.15): 0.0%
- Reasons: none

**post_monsoon** — Status: **PASS**
- Sensors: landsat-7,landsat-8,landsat-9 · scenes: 37
- Valid district coverage: 100.0% · reliable (≥3 clear obs): 94.9%
- Median clear observations per pixel: 5 · mean clear fraction of observations: 56.3%
- Permanent-water negative control (share of JRC permanent-water cells with MNDWI>0): 100%
- Residual-cloud check (valid pixels with blue SR > 0.15): 0.0%
- Reasons: none

**wet** — Status: **WARNING**
- Sensors: landsat-7,landsat-8 · scenes: 18
- Valid district coverage: 62.5% · reliable (≥3 clear obs): 13.2%
- Median clear observations per pixel: 1 · mean clear fraction of observations: 31.2%
- Permanent-water negative control (share of JRC permanent-water cells with MNDWI>0): 100%
- Residual-cloud check (valid pixels with blue SR > 0.15): 0.15%
- Reasons: district valid coverage 62.5% < 95% | median clear observations 1 < 3 (composite statistically weak) | 38% of district from a single observation

### 2022

**annual** — Status: **PASS**
- Sensors: landsat-8,landsat-9 · scenes: 114
- Valid district coverage: 100.0% · reliable (≥3 clear obs): 100.0%
- Median clear observations per pixel: 22 · mean clear fraction of observations: 77.6%
- Permanent-water negative control (share of JRC permanent-water cells with MNDWI>0): 100%
- Residual-cloud check (valid pixels with blue SR > 0.15): 0.0%
- Reasons: none

**dry** — Status: **PASS**
- Sensors: landsat-8,landsat-9 · scenes: 65
- Valid district coverage: 100.0% · reliable (≥3 clear obs): 100.0%
- Median clear observations per pixel: 14 · mean clear fraction of observations: 84.8%
- Permanent-water negative control (share of JRC permanent-water cells with MNDWI>0): 100%
- Residual-cloud check (valid pixels with blue SR > 0.15): 0.0%
- Reasons: none

**post_monsoon** — Status: **PASS**
- Sensors: landsat-8,landsat-9 · scenes: 36
- Valid district coverage: 100.0% · reliable (≥3 clear obs): 99.9%
- Median clear observations per pixel: 7 · mean clear fraction of observations: 79.9%
- Permanent-water negative control (share of JRC permanent-water cells with MNDWI>0): 100%
- Residual-cloud check (valid pixels with blue SR > 0.15): 0.0%
- Reasons: none

**wet** — Status: **FAIL**
- Sensors: landsat-8,landsat-9 · scenes: 13
- Valid district coverage: 43.7% · reliable (≥3 clear obs): 10.7%
- Median clear observations per pixel: 0 · mean clear fraction of observations: 20.4%
- Permanent-water negative control (share of JRC permanent-water cells with MNDWI>0): 86%
- Residual-cloud check (valid pixels with blue SR > 0.15): 0.02%
- Reasons: district valid coverage 43.7% < 50% | median clear observations 0 < 3 (composite statistically weak) | 25% of district from a single observation

### 2023

**annual** — Status: **PASS**
- Sensors: landsat-8,landsat-9 · scenes: 130
- Valid district coverage: 100.0% · reliable (≥3 clear obs): 100.0%
- Median clear observations per pixel: 26 · mean clear fraction of observations: 72.2%
- Permanent-water negative control (share of JRC permanent-water cells with MNDWI>0): 100%
- Residual-cloud check (valid pixels with blue SR > 0.15): 0.0%
- Reasons: none

**dry** — Status: **PASS**
- Sensors: landsat-8,landsat-9 · scenes: 65
- Valid district coverage: 100.0% · reliable (≥3 clear obs): 100.0%
- Median clear observations per pixel: 14 · mean clear fraction of observations: 79.5%
- Permanent-water negative control (share of JRC permanent-water cells with MNDWI>0): 100%
- Residual-cloud check (valid pixels with blue SR > 0.15): 0.0%
- Reasons: none

**post_monsoon** — Status: **PASS**
- Sensors: landsat-8,landsat-9 · scenes: 39
- Valid district coverage: 100.0% · reliable (≥3 clear obs): 100.0%
- Median clear observations per pixel: 8 · mean clear fraction of observations: 76.0%
- Permanent-water negative control (share of JRC permanent-water cells with MNDWI>0): 100%
- Residual-cloud check (valid pixels with blue SR > 0.15): 0.0%
- Reasons: none

**wet** — Status: **PASS**
- Sensors: landsat-8,landsat-9 · scenes: 26
- Valid district coverage: 100.0% · reliable (≥3 clear obs): 82.5%
- Median clear observations per pixel: 4 · mean clear fraction of observations: 48.7%
- Permanent-water negative control (share of JRC permanent-water cells with MNDWI>0): 99%
- Residual-cloud check (valid pixels with blue SR > 0.15): 0.01%
- Reasons: none

### 2024

**annual** — Status: **PASS**
- Sensors: landsat-8,landsat-9 · scenes: 120
- Valid district coverage: 100.0% · reliable (≥3 clear obs): 100.0%
- Median clear observations per pixel: 24 · mean clear fraction of observations: 79.4%
- Permanent-water negative control (share of JRC permanent-water cells with MNDWI>0): 100%
- Residual-cloud check (valid pixels with blue SR > 0.15): 0.0%
- Reasons: none

**dry** — Status: **PASS**
- Sensors: landsat-8,landsat-9 · scenes: 74
- Valid district coverage: 100.0% · reliable (≥3 clear obs): 100.0%
- Median clear observations per pixel: 17 · mean clear fraction of observations: 88.1%
- Permanent-water negative control (share of JRC permanent-water cells with MNDWI>0): 100%
- Residual-cloud check (valid pixels with blue SR > 0.15): 0.0%
- Reasons: none

**post_monsoon** — Status: **PASS**
- Sensors: landsat-8,landsat-9 · scenes: 35
- Valid district coverage: 100.0% · reliable (≥3 clear obs): 99.8%
- Median clear observations per pixel: 7 · mean clear fraction of observations: 68.6%
- Permanent-water negative control (share of JRC permanent-water cells with MNDWI>0): 100%
- Residual-cloud check (valid pixels with blue SR > 0.15): 0.0%
- Reasons: none

**wet** — Status: **FAIL**
- Sensors: landsat-8,landsat-9 · scenes: 11
- Valid district coverage: 33.9% · reliable (≥3 clear obs): 14.3%
- Median clear observations per pixel: 0 · mean clear fraction of observations: 25.3%
- Permanent-water negative control (share of JRC permanent-water cells with MNDWI>0): 90%
- Residual-cloud check (valid pixels with blue SR > 0.15): 0.0%
- Reasons: district valid coverage 33.9% < 50% | median clear observations 0 < 3 (composite statistically weak)

### 2025

**annual** — Status: **PASS**
- Sensors: landsat-8,landsat-9 · scenes: 110
- Valid district coverage: 100.0% · reliable (≥3 clear obs): 100.0%
- Median clear observations per pixel: 24 · mean clear fraction of observations: 80.1%
- Permanent-water negative control (share of JRC permanent-water cells with MNDWI>0): 100%
- Residual-cloud check (valid pixels with blue SR > 0.15): 0.0%
- Reasons: none

**dry** — Status: **PASS**
- Sensors: landsat-8,landsat-9 · scenes: 69
- Valid district coverage: 100.0% · reliable (≥3 clear obs): 100.0%
- Median clear observations per pixel: 16 · mean clear fraction of observations: 88.2%
- Permanent-water negative control (share of JRC permanent-water cells with MNDWI>0): 100%
- Residual-cloud check (valid pixels with blue SR > 0.15): 0.0%
- Reasons: none

**post_monsoon** — Status: **PASS**
- Sensors: landsat-8,landsat-9 · scenes: 36
- Valid district coverage: 100.0% · reliable (≥3 clear obs): 99.9%
- Median clear observations per pixel: 7 · mean clear fraction of observations: 73.2%
- Permanent-water negative control (share of JRC permanent-water cells with MNDWI>0): 100%
- Residual-cloud check (valid pixels with blue SR > 0.15): 0.0%
- Reasons: none

**wet** — Status: **WARNING**
- Sensors: landsat-8,landsat-9 · scenes: 5
- Valid district coverage: 52.4% · reliable (≥3 clear obs): 0.3%
- Median clear observations per pixel: 1 · mean clear fraction of observations: 31.8%
- Permanent-water negative control (share of JRC permanent-water cells with MNDWI>0): 98%
- Residual-cloud check (valid pixels with blue SR > 0.15): 0.0%
- Reasons: district valid coverage 52.4% < 95% | median clear observations 1 < 3 (composite statistically weak) | 38% of district from a single observation

### 2026

**annual** — Status: **WARNING** (PARTIAL)
- Sensors: landsat-8,landsat-9 · scenes: 95
- Valid district coverage: 100.0% · reliable (≥3 clear obs): 100.0%
- Median clear observations per pixel: 20 · mean clear fraction of observations: 84.0%
- Permanent-water negative control (share of JRC permanent-water cells with MNDWI>0): 100%
- Residual-cloud check (valid pixels with blue SR > 0.15): 0.0%
- Reasons: PARTIAL period: archive cut-off 2026-10-01

**dry** — Status: **PASS**
- Sensors: landsat-8,landsat-9 · scenes: 73
- Valid district coverage: 100.0% · reliable (≥3 clear obs): 100.0%
- Median clear observations per pixel: 17 · mean clear fraction of observations: 92.7%
- Permanent-water negative control (share of JRC permanent-water cells with MNDWI>0): 100%
- Residual-cloud check (valid pixels with blue SR > 0.15): 0.0%
- Reasons: none

**post_monsoon** — Status: **IN_PROGRESS** (PARTIAL)
- Sensors: — · scenes: 0
- Valid district coverage: 0.0% · reliable (≥3 clear obs): 0.0%
- Median clear observations per pixel: 0 · mean clear fraction of observations: 0.0%
- Permanent-water negative control (share of JRC permanent-water cells with MNDWI>0): n/a
- Residual-cloud check (valid pixels with blue SR > 0.15): n/a
- Reasons: period in progress at the archive cut-off 2026-10-01 20:07 with no acquisitions yet - nothing to assess

**wet** — Status: **PASS**
- Sensors: landsat-8,landsat-9 · scenes: 22
- Valid district coverage: 97.4% · reliable (≥3 clear obs): 65.1%
- Median clear observations per pixel: 3 · mean clear fraction of observations: 52.2%
- Permanent-water negative control (share of JRC permanent-water cells with MNDWI>0): 100%
- Residual-cloud check (valid pixels with blue SR > 0.15): 0.01%
- Reasons: none
