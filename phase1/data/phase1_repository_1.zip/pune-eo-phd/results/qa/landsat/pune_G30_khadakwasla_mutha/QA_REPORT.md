# Pune EO Data QA Report — landsat — grid `pune_G30_khadakwasla_mutha`

Generated automatically by `pune-eo qa`. Thresholds: `configs/qa.yaml`. Every product's full QA record is
also written into its own `metadata.json` (`qa` block).

## Summary

| period       |   FAIL |   IN_PROGRESS |   PASS |   WARNING |
|:-------------|-------:|--------------:|-------:|----------:|
| annual       |      0 |             0 |     30 |         7 |
| dry          |      0 |             0 |     29 |         8 |
| post_monsoon |      0 |             1 |     18 |        18 |
| wet          |     16 |             0 |      5 |        16 |

## Per-year records

### 1990

**annual** — Status: **PASS**
- Sensors: landsat-5 · scenes: 9
- Valid district coverage: 100.0% · reliable (≥3 clear obs): 100.0%
- Median clear observations per pixel: 8 · mean clear fraction of observations: 84.7%
- Permanent-water negative control (share of JRC permanent-water cells with MNDWI>0): 99%
- Residual-cloud check (valid pixels with blue SR > 0.15): 0.0%
- Reasons: none

**dry** — Status: **PASS**
- Sensors: landsat-5 · scenes: 7
- Valid district coverage: 100.0% · reliable (≥3 clear obs): 100.0%
- Median clear observations per pixel: 7 · mean clear fraction of observations: 92.3%
- Permanent-water negative control (share of JRC permanent-water cells with MNDWI>0): 99%
- Residual-cloud check (valid pixels with blue SR > 0.15): 0.0%
- Reasons: none

**post_monsoon** — Status: **WARNING**
- Sensors: landsat-5 · scenes: 1
- Valid district coverage: 96.5% · reliable (≥3 clear obs): 0.0%
- Median clear observations per pixel: 1 · mean clear fraction of observations: 96.5%
- Permanent-water negative control (share of JRC permanent-water cells with MNDWI>0): 99%
- Residual-cloud check (valid pixels with blue SR > 0.15): 0.03%
- Reasons: median clear observations 1 < 3 (composite statistically weak) | 96% of district from a single observation

**wet** — Status: **FAIL**
- Sensors: landsat-5 · scenes: 1
- Valid district coverage: 18.8% · reliable (≥3 clear obs): 0.0%
- Median clear observations per pixel: 0 · mean clear fraction of observations: 18.8%
- Permanent-water negative control (share of JRC permanent-water cells with MNDWI>0): 96%
- Residual-cloud check (valid pixels with blue SR > 0.15): 1.53%
- Reasons: district valid coverage 18.8% < 50% | median clear observations 0 < 3 (composite statistically weak) | possible residual cloud/haze: 1.5% of valid pixels transiently bright (blue SR > 0.15)

### 1991

**annual** — Status: **PASS**
- Sensors: landsat-5 · scenes: 7
- Valid district coverage: 100.0% · reliable (≥3 clear obs): 100.0%
- Median clear observations per pixel: 5 · mean clear fraction of observations: 77.2%
- Permanent-water negative control (share of JRC permanent-water cells with MNDWI>0): 99%
- Residual-cloud check (valid pixels with blue SR > 0.15): 0.0%
- Reasons: none

**dry** — Status: **PASS**
- Sensors: landsat-5 · scenes: 4
- Valid district coverage: 100.0% · reliable (≥3 clear obs): 100.0%
- Median clear observations per pixel: 3 · mean clear fraction of observations: 85.9%
- Permanent-water negative control (share of JRC permanent-water cells with MNDWI>0): 98%
- Residual-cloud check (valid pixels with blue SR > 0.15): 0.0%
- Reasons: none

**post_monsoon** — Status: **WARNING**
- Sensors: landsat-5 · scenes: 3
- Valid district coverage: 99.8% · reliable (≥3 clear obs): 0.4%
- Median clear observations per pixel: 2 · mean clear fraction of observations: 66.2%
- Permanent-water negative control (share of JRC permanent-water cells with MNDWI>0): 99%
- Residual-cloud check (valid pixels with blue SR > 0.15): 0.0%
- Reasons: median clear observations 2 < 3 (composite statistically weak)

**wet** — Status: **FAIL**
- Sensors: — · scenes: 0
- Valid district coverage: 0.0% · reliable (≥3 clear obs): 0.0%
- Median clear observations per pixel: 0 · mean clear fraction of observations: 0.0%
- Permanent-water negative control (share of JRC permanent-water cells with MNDWI>0): n/a
- Residual-cloud check (valid pixels with blue SR > 0.15): n/a
- Reasons: district valid coverage 0.0% < 50% | median clear observations 0 < 3 (composite statistically weak)

### 1992

**annual** — Status: **PASS**
- Sensors: landsat-5 · scenes: 9
- Valid district coverage: 100.0% · reliable (≥3 clear obs): 100.0%
- Median clear observations per pixel: 8 · mean clear fraction of observations: 88.0%
- Permanent-water negative control (share of JRC permanent-water cells with MNDWI>0): 99%
- Residual-cloud check (valid pixels with blue SR > 0.15): 0.0%
- Reasons: none

**dry** — Status: **PASS**
- Sensors: landsat-5 · scenes: 5
- Valid district coverage: 100.0% · reliable (≥3 clear obs): 100.0%
- Median clear observations per pixel: 5 · mean clear fraction of observations: 99.9%
- Permanent-water negative control (share of JRC permanent-water cells with MNDWI>0): 99%
- Residual-cloud check (valid pixels with blue SR > 0.15): 0.0%
- Reasons: none

**post_monsoon** — Status: **WARNING**
- Sensors: landsat-5 · scenes: 3
- Valid district coverage: 100.0% · reliable (≥3 clear obs): 0.0%
- Median clear observations per pixel: 2 · mean clear fraction of observations: 67.0%
- Permanent-water negative control (share of JRC permanent-water cells with MNDWI>0): 100%
- Residual-cloud check (valid pixels with blue SR > 0.15): 0.0%
- Reasons: median clear observations 2 < 3 (composite statistically weak)

**wet** — Status: **FAIL**
- Sensors: landsat-5 · scenes: 1
- Valid district coverage: 91.6% · reliable (≥3 clear obs): 0.0%
- Median clear observations per pixel: 1 · mean clear fraction of observations: 91.6%
- Permanent-water negative control (share of JRC permanent-water cells with MNDWI>0): 100%
- Residual-cloud check (valid pixels with blue SR > 0.15): 100.0%
- Reasons: residual cloud/haze: 100% of valid pixels transiently bright (blue SR > 0.15) | district valid coverage 91.6% < 95% | median clear observations 1 < 3 (composite statistically weak) | 92% of district from a single observation

### 1993

**annual** — Status: **PASS**
- Sensors: landsat-5 · scenes: 10
- Valid district coverage: 100.0% · reliable (≥3 clear obs): 100.0%
- Median clear observations per pixel: 8 · mean clear fraction of observations: 74.8%
- Permanent-water negative control (share of JRC permanent-water cells with MNDWI>0): 99%
- Residual-cloud check (valid pixels with blue SR > 0.15): 0.0%
- Reasons: none

**dry** — Status: **PASS**
- Sensors: landsat-5 · scenes: 6
- Valid district coverage: 100.0% · reliable (≥3 clear obs): 100.0%
- Median clear observations per pixel: 6 · mean clear fraction of observations: 91.1%
- Permanent-water negative control (share of JRC permanent-water cells with MNDWI>0): 99%
- Residual-cloud check (valid pixels with blue SR > 0.15): 0.0%
- Reasons: none

**post_monsoon** — Status: **WARNING**
- Sensors: landsat-5 · scenes: 3
- Valid district coverage: 100.0% · reliable (≥3 clear obs): 0.0%
- Median clear observations per pixel: 2 · mean clear fraction of observations: 59.7%
- Permanent-water negative control (share of JRC permanent-water cells with MNDWI>0): 100%
- Residual-cloud check (valid pixels with blue SR > 0.15): 0.12%
- Reasons: median clear observations 2 < 3 (composite statistically weak)

**wet** — Status: **FAIL**
- Sensors: landsat-5 · scenes: 1
- Valid district coverage: 22.1% · reliable (≥3 clear obs): 0.0%
- Median clear observations per pixel: 0 · mean clear fraction of observations: 22.1%
- Permanent-water negative control (share of JRC permanent-water cells with MNDWI>0): n/a
- Residual-cloud check (valid pixels with blue SR > 0.15): 0.34%
- Reasons: district valid coverage 22.1% < 50% | median clear observations 0 < 3 (composite statistically weak)

### 1994

**annual** — Status: **PASS**
- Sensors: landsat-5 · scenes: 9
- Valid district coverage: 100.0% · reliable (≥3 clear obs): 100.0%
- Median clear observations per pixel: 8 · mean clear fraction of observations: 86.6%
- Permanent-water negative control (share of JRC permanent-water cells with MNDWI>0): 99%
- Residual-cloud check (valid pixels with blue SR > 0.15): 0.0%
- Reasons: none

**dry** — Status: **PASS**
- Sensors: landsat-5 · scenes: 5
- Valid district coverage: 100.0% · reliable (≥3 clear obs): 100.0%
- Median clear observations per pixel: 5 · mean clear fraction of observations: 92.4%
- Permanent-water negative control (share of JRC permanent-water cells with MNDWI>0): 99%
- Residual-cloud check (valid pixels with blue SR > 0.15): 0.0%
- Reasons: none

**post_monsoon** — Status: **WARNING**
- Sensors: landsat-5 · scenes: 3
- Valid district coverage: 100.0% · reliable (≥3 clear obs): 30.7%
- Median clear observations per pixel: 2 · mean clear fraction of observations: 72.1%
- Permanent-water negative control (share of JRC permanent-water cells with MNDWI>0): 99%
- Residual-cloud check (valid pixels with blue SR > 0.15): 0.0%
- Reasons: median clear observations 2 < 3 (composite statistically weak)

**wet** — Status: **WARNING**
- Sensors: landsat-5 · scenes: 1
- Valid district coverage: 100.0% · reliable (≥3 clear obs): 0.0%
- Median clear observations per pixel: 1 · mean clear fraction of observations: 100.0%
- Permanent-water negative control (share of JRC permanent-water cells with MNDWI>0): 100%
- Residual-cloud check (valid pixels with blue SR > 0.15): 0.01%
- Reasons: median clear observations 1 < 3 (composite statistically weak) | 100% of district from a single observation

### 1995

**annual** — Status: **PASS**
- Sensors: landsat-5 · scenes: 5
- Valid district coverage: 100.0% · reliable (≥3 clear obs): 99.5%
- Median clear observations per pixel: 4 · mean clear fraction of observations: 77.5%
- Permanent-water negative control (share of JRC permanent-water cells with MNDWI>0): 99%
- Residual-cloud check (valid pixels with blue SR > 0.15): 0.0%
- Reasons: none

**dry** — Status: **WARNING**
- Sensors: landsat-5 · scenes: 3
- Valid district coverage: 99.9% · reliable (≥3 clear obs): 8.1%
- Median clear observations per pixel: 2 · mean clear fraction of observations: 63.3%
- Permanent-water negative control (share of JRC permanent-water cells with MNDWI>0): 99%
- Residual-cloud check (valid pixels with blue SR > 0.15): 0.0%
- Reasons: median clear observations 2 < 3 (composite statistically weak)

**post_monsoon** — Status: **WARNING**
- Sensors: landsat-5 · scenes: 2
- Valid district coverage: 100.0% · reliable (≥3 clear obs): 0.0%
- Median clear observations per pixel: 2 · mean clear fraction of observations: 99.2%
- Permanent-water negative control (share of JRC permanent-water cells with MNDWI>0): 100%
- Residual-cloud check (valid pixels with blue SR > 0.15): 0.0%
- Reasons: median clear observations 2 < 3 (composite statistically weak)

**wet** — Status: **FAIL**
- Sensors: — · scenes: 0
- Valid district coverage: 0.0% · reliable (≥3 clear obs): 0.0%
- Median clear observations per pixel: 0 · mean clear fraction of observations: 0.0%
- Permanent-water negative control (share of JRC permanent-water cells with MNDWI>0): n/a
- Residual-cloud check (valid pixels with blue SR > 0.15): n/a
- Reasons: district valid coverage 0.0% < 50% | median clear observations 0 < 3 (composite statistically weak)

### 1996

**annual** — Status: **PASS**
- Sensors: landsat-5 · scenes: 11
- Valid district coverage: 100.0% · reliable (≥3 clear obs): 100.0%
- Median clear observations per pixel: 10 · mean clear fraction of observations: 88.2%
- Permanent-water negative control (share of JRC permanent-water cells with MNDWI>0): 100%
- Residual-cloud check (valid pixels with blue SR > 0.15): 0.0%
- Reasons: none

**dry** — Status: **PASS**
- Sensors: landsat-5 · scenes: 5
- Valid district coverage: 100.0% · reliable (≥3 clear obs): 100.0%
- Median clear observations per pixel: 5 · mean clear fraction of observations: 98.1%
- Permanent-water negative control (share of JRC permanent-water cells with MNDWI>0): 99%
- Residual-cloud check (valid pixels with blue SR > 0.15): 0.0%
- Reasons: none

**post_monsoon** — Status: **PASS**
- Sensors: landsat-5 · scenes: 4
- Valid district coverage: 100.0% · reliable (≥3 clear obs): 99.8%
- Median clear observations per pixel: 4 · mean clear fraction of observations: 99.0%
- Permanent-water negative control (share of JRC permanent-water cells with MNDWI>0): 100%
- Residual-cloud check (valid pixels with blue SR > 0.15): 0.0%
- Reasons: none

**wet** — Status: **WARNING**
- Sensors: landsat-5 · scenes: 2
- Valid district coverage: 64.5% · reliable (≥3 clear obs): 0.0%
- Median clear observations per pixel: 1 · mean clear fraction of observations: 41.5%
- Permanent-water negative control (share of JRC permanent-water cells with MNDWI>0): 100%
- Residual-cloud check (valid pixels with blue SR > 0.15): 0.54%
- Reasons: district valid coverage 64.5% < 95% | median clear observations 1 < 3 (composite statistically weak) | 46% of district from a single observation

### 1997

**annual** — Status: **PASS**
- Sensors: landsat-5 · scenes: 7
- Valid district coverage: 100.0% · reliable (≥3 clear obs): 100.0%
- Median clear observations per pixel: 6 · mean clear fraction of observations: 79.8%
- Permanent-water negative control (share of JRC permanent-water cells with MNDWI>0): 99%
- Residual-cloud check (valid pixels with blue SR > 0.15): 0.0%
- Reasons: none

**dry** — Status: **WARNING**
- Sensors: landsat-5 · scenes: 2
- Valid district coverage: 100.0% · reliable (≥3 clear obs): 0.0%
- Median clear observations per pixel: 2 · mean clear fraction of observations: 99.7%
- Permanent-water negative control (share of JRC permanent-water cells with MNDWI>0): 99%
- Residual-cloud check (valid pixels with blue SR > 0.15): 0.0%
- Reasons: median clear observations 2 < 3 (composite statistically weak)

**post_monsoon** — Status: **WARNING**
- Sensors: landsat-5 · scenes: 2
- Valid district coverage: 100.0% · reliable (≥3 clear obs): 0.0%
- Median clear observations per pixel: 2 · mean clear fraction of observations: 99.1%
- Permanent-water negative control (share of JRC permanent-water cells with MNDWI>0): 100%
- Residual-cloud check (valid pixels with blue SR > 0.15): 0.0%
- Reasons: median clear observations 2 < 3 (composite statistically weak)

**wet** — Status: **WARNING**
- Sensors: landsat-5 · scenes: 3
- Valid district coverage: 90.0% · reliable (≥3 clear obs): 15.3%
- Median clear observations per pixel: 2 · mean clear fraction of observations: 53.8%
- Permanent-water negative control (share of JRC permanent-water cells with MNDWI>0): 99%
- Residual-cloud check (valid pixels with blue SR > 0.15): 0.13%
- Reasons: district valid coverage 90.0% < 95% | median clear observations 2 < 3 (composite statistically weak) | 34% of district from a single observation

### 1998

**annual** — Status: **PASS**
- Sensors: landsat-5 · scenes: 12
- Valid district coverage: 100.0% · reliable (≥3 clear obs): 100.0%
- Median clear observations per pixel: 10 · mean clear fraction of observations: 82.5%
- Permanent-water negative control (share of JRC permanent-water cells with MNDWI>0): 99%
- Residual-cloud check (valid pixels with blue SR > 0.15): 0.0%
- Reasons: none

**dry** — Status: **PASS**
- Sensors: landsat-5 · scenes: 6
- Valid district coverage: 100.0% · reliable (≥3 clear obs): 100.0%
- Median clear observations per pixel: 6 · mean clear fraction of observations: 100.0%
- Permanent-water negative control (share of JRC permanent-water cells with MNDWI>0): 99%
- Residual-cloud check (valid pixels with blue SR > 0.15): 0.0%
- Reasons: none

**post_monsoon** — Status: **PASS**
- Sensors: landsat-5 · scenes: 5
- Valid district coverage: 100.0% · reliable (≥3 clear obs): 90.0%
- Median clear observations per pixel: 4 · mean clear fraction of observations: 69.9%
- Permanent-water negative control (share of JRC permanent-water cells with MNDWI>0): 100%
- Residual-cloud check (valid pixels with blue SR > 0.15): 0.0%
- Reasons: none

**wet** — Status: **FAIL**
- Sensors: landsat-5 · scenes: 1
- Valid district coverage: 40.9% · reliable (≥3 clear obs): 0.0%
- Median clear observations per pixel: 0 · mean clear fraction of observations: 40.9%
- Permanent-water negative control (share of JRC permanent-water cells with MNDWI>0): 98%
- Residual-cloud check (valid pixels with blue SR > 0.15): 0.43%
- Reasons: district valid coverage 40.9% < 50% | median clear observations 0 < 3 (composite statistically weak) | 41% of district from a single observation

### 1999

**annual** — Status: **PASS**
- Sensors: landsat-5,landsat-7 · scenes: 10
- Valid district coverage: 100.0% · reliable (≥3 clear obs): 100.0%
- Median clear observations per pixel: 10 · mean clear fraction of observations: 99.2%
- Permanent-water negative control (share of JRC permanent-water cells with MNDWI>0): 100%
- Residual-cloud check (valid pixels with blue SR > 0.15): 0.0%
- Reasons: none

**dry** — Status: **PASS**
- Sensors: landsat-5 · scenes: 8
- Valid district coverage: 100.0% · reliable (≥3 clear obs): 100.0%
- Median clear observations per pixel: 8 · mean clear fraction of observations: 99.4%
- Permanent-water negative control (share of JRC permanent-water cells with MNDWI>0): 99%
- Residual-cloud check (valid pixels with blue SR > 0.15): 0.0%
- Reasons: none

**post_monsoon** — Status: **WARNING**
- Sensors: landsat-7 · scenes: 2
- Valid district coverage: 100.0% · reliable (≥3 clear obs): 0.0%
- Median clear observations per pixel: 2 · mean clear fraction of observations: 98.5%
- Permanent-water negative control (share of JRC permanent-water cells with MNDWI>0): 100%
- Residual-cloud check (valid pixels with blue SR > 0.15): 0.0%
- Reasons: median clear observations 2 < 3 (composite statistically weak)

**wet** — Status: **FAIL**
- Sensors: — · scenes: 0
- Valid district coverage: 0.0% · reliable (≥3 clear obs): 0.0%
- Median clear observations per pixel: 0 · mean clear fraction of observations: 0.0%
- Permanent-water negative control (share of JRC permanent-water cells with MNDWI>0): n/a
- Residual-cloud check (valid pixels with blue SR > 0.15): n/a
- Reasons: district valid coverage 0.0% < 50% | median clear observations 0 < 3 (composite statistically weak)

### 2000

**annual** — Status: **PASS**
- Sensors: landsat-5,landsat-7 · scenes: 8
- Valid district coverage: 100.0% · reliable (≥3 clear obs): 100.0%
- Median clear observations per pixel: 8 · mean clear fraction of observations: 93.0%
- Permanent-water negative control (share of JRC permanent-water cells with MNDWI>0): 99%
- Residual-cloud check (valid pixels with blue SR > 0.15): 0.0%
- Reasons: none

**dry** — Status: **PASS**
- Sensors: landsat-5,landsat-7 · scenes: 4
- Valid district coverage: 100.0% · reliable (≥3 clear obs): 100.0%
- Median clear observations per pixel: 4 · mean clear fraction of observations: 96.1%
- Permanent-water negative control (share of JRC permanent-water cells with MNDWI>0): 99%
- Residual-cloud check (valid pixels with blue SR > 0.15): 0.0%
- Reasons: none

**post_monsoon** — Status: **WARNING**
- Sensors: landsat-7 · scenes: 2
- Valid district coverage: 100.0% · reliable (≥3 clear obs): 0.0%
- Median clear observations per pixel: 2 · mean clear fraction of observations: 99.8%
- Permanent-water negative control (share of JRC permanent-water cells with MNDWI>0): 99%
- Residual-cloud check (valid pixels with blue SR > 0.15): 0.0%
- Reasons: median clear observations 2 < 3 (composite statistically weak)

**wet** — Status: **WARNING**
- Sensors: landsat-7 · scenes: 2
- Valid district coverage: 99.9% · reliable (≥3 clear obs): 0.0%
- Median clear observations per pixel: 2 · mean clear fraction of observations: 79.3%
- Permanent-water negative control (share of JRC permanent-water cells with MNDWI>0): 100%
- Residual-cloud check (valid pixels with blue SR > 0.15): 0.01%
- Reasons: median clear observations 2 < 3 (composite statistically weak) | 41% of district from a single observation

### 2001

**annual** — Status: **PASS**
- Sensors: landsat-5,landsat-7 · scenes: 9
- Valid district coverage: 100.0% · reliable (≥3 clear obs): 100.0%
- Median clear observations per pixel: 7 · mean clear fraction of observations: 78.1%
- Permanent-water negative control (share of JRC permanent-water cells with MNDWI>0): 99%
- Residual-cloud check (valid pixels with blue SR > 0.15): 0.0%
- Reasons: none

**dry** — Status: **PASS**
- Sensors: landsat-5,landsat-7 · scenes: 6
- Valid district coverage: 100.0% · reliable (≥3 clear obs): 100.0%
- Median clear observations per pixel: 6 · mean clear fraction of observations: 99.6%
- Permanent-water negative control (share of JRC permanent-water cells with MNDWI>0): 99%
- Residual-cloud check (valid pixels with blue SR > 0.15): 0.0%
- Reasons: none

**post_monsoon** — Status: **WARNING**
- Sensors: landsat-7 · scenes: 2
- Valid district coverage: 100.0% · reliable (≥3 clear obs): 0.0%
- Median clear observations per pixel: 1 · mean clear fraction of observations: 50.2%
- Permanent-water negative control (share of JRC permanent-water cells with MNDWI>0): 100%
- Residual-cloud check (valid pixels with blue SR > 0.15): 0.0%
- Reasons: median clear observations 1 < 3 (composite statistically weak) | 100% of district from a single observation

**wet** — Status: **FAIL**
- Sensors: landsat-7 · scenes: 1
- Valid district coverage: 2.9% · reliable (≥3 clear obs): 0.0%
- Median clear observations per pixel: 0 · mean clear fraction of observations: 2.9%
- Permanent-water negative control (share of JRC permanent-water cells with MNDWI>0): n/a
- Residual-cloud check (valid pixels with blue SR > 0.15): 0.0%
- Reasons: district valid coverage 2.9% < 50% | median clear observations 0 < 3 (composite statistically weak)

### 2002

**annual** — Status: **PASS**
- Sensors: landsat-7 · scenes: 7
- Valid district coverage: 100.0% · reliable (≥3 clear obs): 100.0%
- Median clear observations per pixel: 6 · mean clear fraction of observations: 87.2%
- Permanent-water negative control (share of JRC permanent-water cells with MNDWI>0): 99%
- Residual-cloud check (valid pixels with blue SR > 0.15): 0.0%
- Reasons: none

**dry** — Status: **PASS**
- Sensors: landsat-7 · scenes: 3
- Valid district coverage: 100.0% · reliable (≥3 clear obs): 98.3%
- Median clear observations per pixel: 3 · mean clear fraction of observations: 99.4%
- Permanent-water negative control (share of JRC permanent-water cells with MNDWI>0): 99%
- Residual-cloud check (valid pixels with blue SR > 0.15): 0.0%
- Reasons: none

**post_monsoon** — Status: **PASS**
- Sensors: landsat-7 · scenes: 3
- Valid district coverage: 100.0% · reliable (≥3 clear obs): 76.7%
- Median clear observations per pixel: 3 · mean clear fraction of observations: 92.3%
- Permanent-water negative control (share of JRC permanent-water cells with MNDWI>0): 99%
- Residual-cloud check (valid pixels with blue SR > 0.15): 0.0%
- Reasons: none

**wet** — Status: **FAIL**
- Sensors: landsat-7 · scenes: 1
- Valid district coverage: 34.3% · reliable (≥3 clear obs): 0.0%
- Median clear observations per pixel: 0 · mean clear fraction of observations: 34.3%
- Permanent-water negative control (share of JRC permanent-water cells with MNDWI>0): 97%
- Residual-cloud check (valid pixels with blue SR > 0.15): 0.13%
- Reasons: district valid coverage 34.3% < 50% | median clear observations 0 < 3 (composite statistically weak) | 34% of district from a single observation

### 2003

**annual** — Status: **WARNING**
- Sensors: landsat-7 · scenes: 6
- Valid district coverage: 100.0% · reliable (≥3 clear obs): 100.0%
- Median clear observations per pixel: 5 · mean clear fraction of observations: 81.8%
- Permanent-water negative control (share of JRC permanent-water cells with MNDWI>0): 98%
- Residual-cloud check (valid pixels with blue SR > 0.15): 0.0%
- Reasons: Landsat-7 SLC-off is the only sensor (striping gaps filled only by repeat passes)

**dry** — Status: **WARNING**
- Sensors: landsat-7 · scenes: 2
- Valid district coverage: 100.0% · reliable (≥3 clear obs): 0.0%
- Median clear observations per pixel: 2 · mean clear fraction of observations: 100.0%
- Permanent-water negative control (share of JRC permanent-water cells with MNDWI>0): 98%
- Residual-cloud check (valid pixels with blue SR > 0.15): 0.0%
- Reasons: median clear observations 2 < 3 (composite statistically weak)

**post_monsoon** — Status: **WARNING**
- Sensors: landsat-7 · scenes: 3
- Valid district coverage: 100.0% · reliable (≥3 clear obs): 83.4%
- Median clear observations per pixel: 3 · mean clear fraction of observations: 96.1%
- Permanent-water negative control (share of JRC permanent-water cells with MNDWI>0): 98%
- Residual-cloud check (valid pixels with blue SR > 0.15): 0.0%
- Reasons: Landsat-7 SLC-off is the only sensor (striping gaps filled only by repeat passes)

**wet** — Status: **FAIL**
- Sensors: landsat-7 · scenes: 1
- Valid district coverage: 2.7% · reliable (≥3 clear obs): 0.0%
- Median clear observations per pixel: 0 · mean clear fraction of observations: 2.8%
- Permanent-water negative control (share of JRC permanent-water cells with MNDWI>0): n/a
- Residual-cloud check (valid pixels with blue SR > 0.15): 0.46%
- Reasons: district valid coverage 2.7% < 50% | median clear observations 0 < 3 (composite statistically weak) | Landsat-7 SLC-off is the only sensor (striping gaps filled only by repeat passes)

### 2004

**annual** — Status: **WARNING**
- Sensors: landsat-7 · scenes: 10
- Valid district coverage: 100.0% · reliable (≥3 clear obs): 100.0%
- Median clear observations per pixel: 9 · mean clear fraction of observations: 91.4%
- Permanent-water negative control (share of JRC permanent-water cells with MNDWI>0): 100%
- Residual-cloud check (valid pixels with blue SR > 0.15): 0.0%
- Reasons: Landsat-7 SLC-off is the only sensor (striping gaps filled only by repeat passes)

**dry** — Status: **WARNING**
- Sensors: landsat-7 · scenes: 3
- Valid district coverage: 100.0% · reliable (≥3 clear obs): 92.9%
- Median clear observations per pixel: 3 · mean clear fraction of observations: 99.9%
- Permanent-water negative control (share of JRC permanent-water cells with MNDWI>0): 96%
- Residual-cloud check (valid pixels with blue SR > 0.15): 0.0%
- Reasons: Landsat-7 SLC-off is the only sensor (striping gaps filled only by repeat passes)

**post_monsoon** — Status: **WARNING**
- Sensors: landsat-7 · scenes: 6
- Valid district coverage: 100.0% · reliable (≥3 clear obs): 100.0%
- Median clear observations per pixel: 6 · mean clear fraction of observations: 96.4%
- Permanent-water negative control (share of JRC permanent-water cells with MNDWI>0): 100%
- Residual-cloud check (valid pixels with blue SR > 0.15): 0.0%
- Reasons: Landsat-7 SLC-off is the only sensor (striping gaps filled only by repeat passes)

**wet** — Status: **FAIL**
- Sensors: landsat-7 · scenes: 1
- Valid district coverage: 34.6% · reliable (≥3 clear obs): 0.0%
- Median clear observations per pixel: 0 · mean clear fraction of observations: 35.3%
- Permanent-water negative control (share of JRC permanent-water cells with MNDWI>0): 100%
- Residual-cloud check (valid pixels with blue SR > 0.15): 0.56%
- Reasons: district valid coverage 34.6% < 50% | median clear observations 0 < 3 (composite statistically weak) | 35% of district from a single observation | Landsat-7 SLC-off is the only sensor (striping gaps filled only by repeat passes)

### 2005

**annual** — Status: **WARNING**
- Sensors: landsat-7 · scenes: 9
- Valid district coverage: 100.0% · reliable (≥3 clear obs): 100.0%
- Median clear observations per pixel: 8 · mean clear fraction of observations: 87.1%
- Permanent-water negative control (share of JRC permanent-water cells with MNDWI>0): 99%
- Residual-cloud check (valid pixels with blue SR > 0.15): 0.0%
- Reasons: Landsat-7 SLC-off is the only sensor (striping gaps filled only by repeat passes)

**dry** — Status: **WARNING**
- Sensors: landsat-7 · scenes: 5
- Valid district coverage: 100.0% · reliable (≥3 clear obs): 99.7%
- Median clear observations per pixel: 5 · mean clear fraction of observations: 94.5%
- Permanent-water negative control (share of JRC permanent-water cells with MNDWI>0): 99%
- Residual-cloud check (valid pixels with blue SR > 0.15): 0.0%
- Reasons: Landsat-7 SLC-off is the only sensor (striping gaps filled only by repeat passes)

**post_monsoon** — Status: **WARNING**
- Sensors: landsat-7 · scenes: 1
- Valid district coverage: 97.6% · reliable (≥3 clear obs): 0.0%
- Median clear observations per pixel: 1 · mean clear fraction of observations: 99.9%
- Permanent-water negative control (share of JRC permanent-water cells with MNDWI>0): 100%
- Residual-cloud check (valid pixels with blue SR > 0.15): 0.0%
- Reasons: median clear observations 1 < 3 (composite statistically weak) | 98% of district from a single observation | Landsat-7 SLC-off is the only sensor (striping gaps filled only by repeat passes)

**wet** — Status: **WARNING**
- Sensors: landsat-7 · scenes: 3
- Valid district coverage: 99.0% · reliable (≥3 clear obs): 29.9%
- Median clear observations per pixel: 2 · mean clear fraction of observations: 70.2%
- Permanent-water negative control (share of JRC permanent-water cells with MNDWI>0): 99%
- Residual-cloud check (valid pixels with blue SR > 0.15): 0.03%
- Reasons: median clear observations 2 < 3 (composite statistically weak) | Landsat-7 SLC-off is the only sensor (striping gaps filled only by repeat passes)

### 2006

**annual** — Status: **WARNING**
- Sensors: landsat-7 · scenes: 13
- Valid district coverage: 100.0% · reliable (≥3 clear obs): 100.0%
- Median clear observations per pixel: 11 · mean clear fraction of observations: 87.9%
- Permanent-water negative control (share of JRC permanent-water cells with MNDWI>0): 99%
- Residual-cloud check (valid pixels with blue SR > 0.15): 0.0%
- Reasons: Landsat-7 SLC-off is the only sensor (striping gaps filled only by repeat passes)

**dry** — Status: **WARNING**
- Sensors: landsat-7 · scenes: 7
- Valid district coverage: 100.0% · reliable (≥3 clear obs): 100.0%
- Median clear observations per pixel: 7 · mean clear fraction of observations: 95.9%
- Permanent-water negative control (share of JRC permanent-water cells with MNDWI>0): 99%
- Residual-cloud check (valid pixels with blue SR > 0.15): 0.0%
- Reasons: Landsat-7 SLC-off is the only sensor (striping gaps filled only by repeat passes)

**post_monsoon** — Status: **WARNING**
- Sensors: landsat-7 · scenes: 4
- Valid district coverage: 100.0% · reliable (≥3 clear obs): 99.3%
- Median clear observations per pixel: 4 · mean clear fraction of observations: 96.7%
- Permanent-water negative control (share of JRC permanent-water cells with MNDWI>0): 99%
- Residual-cloud check (valid pixels with blue SR > 0.15): 0.01%
- Reasons: Landsat-7 SLC-off is the only sensor (striping gaps filled only by repeat passes)

**wet** — Status: **WARNING**
- Sensors: landsat-7 · scenes: 2
- Valid district coverage: 82.8% · reliable (≥3 clear obs): 0.0%
- Median clear observations per pixel: 1 · mean clear fraction of observations: 42.4%
- Permanent-water negative control (share of JRC permanent-water cells with MNDWI>0): 98%
- Residual-cloud check (valid pixels with blue SR > 0.15): 0.07%
- Reasons: district valid coverage 82.8% < 95% | median clear observations 1 < 3 (composite statistically weak) | 83% of district from a single observation | Landsat-7 SLC-off is the only sensor (striping gaps filled only by repeat passes)

### 2007

**annual** — Status: **WARNING**
- Sensors: landsat-7 · scenes: 14
- Valid district coverage: 100.0% · reliable (≥3 clear obs): 100.0%
- Median clear observations per pixel: 14 · mean clear fraction of observations: 98.3%
- Permanent-water negative control (share of JRC permanent-water cells with MNDWI>0): 99%
- Residual-cloud check (valid pixels with blue SR > 0.15): 0.0%
- Reasons: Landsat-7 SLC-off is the only sensor (striping gaps filled only by repeat passes)

**dry** — Status: **WARNING**
- Sensors: landsat-7 · scenes: 9
- Valid district coverage: 100.0% · reliable (≥3 clear obs): 100.0%
- Median clear observations per pixel: 9 · mean clear fraction of observations: 99.4%
- Permanent-water negative control (share of JRC permanent-water cells with MNDWI>0): 99%
- Residual-cloud check (valid pixels with blue SR > 0.15): 0.0%
- Reasons: Landsat-7 SLC-off is the only sensor (striping gaps filled only by repeat passes)

**post_monsoon** — Status: **WARNING**
- Sensors: landsat-7 · scenes: 4
- Valid district coverage: 100.0% · reliable (≥3 clear obs): 99.3%
- Median clear observations per pixel: 4 · mean clear fraction of observations: 98.5%
- Permanent-water negative control (share of JRC permanent-water cells with MNDWI>0): 100%
- Residual-cloud check (valid pixels with blue SR > 0.15): 0.01%
- Reasons: Landsat-7 SLC-off is the only sensor (striping gaps filled only by repeat passes)

**wet** — Status: **WARNING**
- Sensors: landsat-7 · scenes: 1
- Valid district coverage: 85.7% · reliable (≥3 clear obs): 0.0%
- Median clear observations per pixel: 1 · mean clear fraction of observations: 86.7%
- Permanent-water negative control (share of JRC permanent-water cells with MNDWI>0): 95%
- Residual-cloud check (valid pixels with blue SR > 0.15): 0.03%
- Reasons: district valid coverage 85.7% < 95% | median clear observations 1 < 3 (composite statistically weak) | 86% of district from a single observation | Landsat-7 SLC-off is the only sensor (striping gaps filled only by repeat passes)

### 2008

**annual** — Status: **PASS**
- Sensors: landsat-5,landsat-7 · scenes: 22
- Valid district coverage: 100.0% · reliable (≥3 clear obs): 100.0%
- Median clear observations per pixel: 20 · mean clear fraction of observations: 89.7%
- Permanent-water negative control (share of JRC permanent-water cells with MNDWI>0): 100%
- Residual-cloud check (valid pixels with blue SR > 0.15): 0.0%
- Reasons: none

**dry** — Status: **PASS**
- Sensors: landsat-5,landsat-7 · scenes: 10
- Valid district coverage: 100.0% · reliable (≥3 clear obs): 100.0%
- Median clear observations per pixel: 10 · mean clear fraction of observations: 96.1%
- Permanent-water negative control (share of JRC permanent-water cells with MNDWI>0): 98%
- Residual-cloud check (valid pixels with blue SR > 0.15): 0.0%
- Reasons: none

**post_monsoon** — Status: **PASS**
- Sensors: landsat-5,landsat-7 · scenes: 9
- Valid district coverage: 100.0% · reliable (≥3 clear obs): 100.0%
- Median clear observations per pixel: 8 · mean clear fraction of observations: 93.7%
- Permanent-water negative control (share of JRC permanent-water cells with MNDWI>0): 100%
- Residual-cloud check (valid pixels with blue SR > 0.15): 0.0%
- Reasons: none

**wet** — Status: **WARNING**
- Sensors: landsat-5,landsat-7 · scenes: 3
- Valid district coverage: 100.0% · reliable (≥3 clear obs): 8.2%
- Median clear observations per pixel: 2 · mean clear fraction of observations: 57.7%
- Permanent-water negative control (share of JRC permanent-water cells with MNDWI>0): 100%
- Residual-cloud check (valid pixels with blue SR > 0.15): 0.04%
- Reasons: median clear observations 2 < 3 (composite statistically weak) | 36% of district from a single observation

### 2009

**annual** — Status: **PASS**
- Sensors: landsat-5,landsat-7 · scenes: 20
- Valid district coverage: 100.0% · reliable (≥3 clear obs): 100.0%
- Median clear observations per pixel: 19 · mean clear fraction of observations: 94.4%
- Permanent-water negative control (share of JRC permanent-water cells with MNDWI>0): 99%
- Residual-cloud check (valid pixels with blue SR > 0.15): 0.0%
- Reasons: none

**dry** — Status: **PASS**
- Sensors: landsat-5,landsat-7 · scenes: 13
- Valid district coverage: 100.0% · reliable (≥3 clear obs): 100.0%
- Median clear observations per pixel: 13 · mean clear fraction of observations: 99.0%
- Permanent-water negative control (share of JRC permanent-water cells with MNDWI>0): 98%
- Residual-cloud check (valid pixels with blue SR > 0.15): 0.0%
- Reasons: none

**post_monsoon** — Status: **PASS**
- Sensors: landsat-5,landsat-7 · scenes: 6
- Valid district coverage: 100.0% · reliable (≥3 clear obs): 100.0%
- Median clear observations per pixel: 5 · mean clear fraction of observations: 83.1%
- Permanent-water negative control (share of JRC permanent-water cells with MNDWI>0): 100%
- Residual-cloud check (valid pixels with blue SR > 0.15): 0.01%
- Reasons: none

**wet** — Status: **WARNING**
- Sensors: landsat-5 · scenes: 1
- Valid district coverage: 99.2% · reliable (≥3 clear obs): 0.0%
- Median clear observations per pixel: 1 · mean clear fraction of observations: 99.2%
- Permanent-water negative control (share of JRC permanent-water cells with MNDWI>0): 97%
- Residual-cloud check (valid pixels with blue SR > 0.15): 0.33%
- Reasons: median clear observations 1 < 3 (composite statistically weak) | 99% of district from a single observation

### 2010

**annual** — Status: **PASS**
- Sensors: landsat-5,landsat-7 · scenes: 15
- Valid district coverage: 100.0% · reliable (≥3 clear obs): 100.0%
- Median clear observations per pixel: 14 · mean clear fraction of observations: 95.1%
- Permanent-water negative control (share of JRC permanent-water cells with MNDWI>0): 100%
- Residual-cloud check (valid pixels with blue SR > 0.15): 0.0%
- Reasons: none

**dry** — Status: **PASS**
- Sensors: landsat-5,landsat-7 · scenes: 11
- Valid district coverage: 100.0% · reliable (≥3 clear obs): 100.0%
- Median clear observations per pixel: 11 · mean clear fraction of observations: 99.9%
- Permanent-water negative control (share of JRC permanent-water cells with MNDWI>0): 100%
- Residual-cloud check (valid pixels with blue SR > 0.15): 0.0%
- Reasons: none

**post_monsoon** — Status: **WARNING**
- Sensors: landsat-7 · scenes: 3
- Valid district coverage: 99.9% · reliable (≥3 clear obs): 32.4%
- Median clear observations per pixel: 2 · mean clear fraction of observations: 79.1%
- Permanent-water negative control (share of JRC permanent-water cells with MNDWI>0): 100%
- Residual-cloud check (valid pixels with blue SR > 0.15): 0.01%
- Reasons: median clear observations 2 < 3 (composite statistically weak) | Landsat-7 SLC-off is the only sensor (striping gaps filled only by repeat passes)

**wet** — Status: **WARNING**
- Sensors: landsat-7 · scenes: 1
- Valid district coverage: 91.7% · reliable (≥3 clear obs): 0.0%
- Median clear observations per pixel: 1 · mean clear fraction of observations: 92.4%
- Permanent-water negative control (share of JRC permanent-water cells with MNDWI>0): 100%
- Residual-cloud check (valid pixels with blue SR > 0.15): 0.04%
- Reasons: district valid coverage 91.7% < 95% | median clear observations 1 < 3 (composite statistically weak) | 92% of district from a single observation | Landsat-7 SLC-off is the only sensor (striping gaps filled only by repeat passes)

### 2011

**annual** — Status: **PASS**
- Sensors: landsat-5,landsat-7 · scenes: 12
- Valid district coverage: 100.0% · reliable (≥3 clear obs): 100.0%
- Median clear observations per pixel: 10 · mean clear fraction of observations: 84.4%
- Permanent-water negative control (share of JRC permanent-water cells with MNDWI>0): 100%
- Residual-cloud check (valid pixels with blue SR > 0.15): 0.0%
- Reasons: none

**dry** — Status: **PASS**
- Sensors: landsat-5,landsat-7 · scenes: 8
- Valid district coverage: 100.0% · reliable (≥3 clear obs): 100.0%
- Median clear observations per pixel: 7 · mean clear fraction of observations: 94.3%
- Permanent-water negative control (share of JRC permanent-water cells with MNDWI>0): 99%
- Residual-cloud check (valid pixels with blue SR > 0.15): 0.0%
- Reasons: none

**post_monsoon** — Status: **WARNING**
- Sensors: landsat-7 · scenes: 3
- Valid district coverage: 99.6% · reliable (≥3 clear obs): 30.6%
- Median clear observations per pixel: 2 · mean clear fraction of observations: 75.9%
- Permanent-water negative control (share of JRC permanent-water cells with MNDWI>0): 100%
- Residual-cloud check (valid pixels with blue SR > 0.15): 0.01%
- Reasons: median clear observations 2 < 3 (composite statistically weak) | Landsat-7 SLC-off is the only sensor (striping gaps filled only by repeat passes)

**wet** — Status: **FAIL**
- Sensors: landsat-7 · scenes: 1
- Valid district coverage: 33.6% · reliable (≥3 clear obs): 0.0%
- Median clear observations per pixel: 0 · mean clear fraction of observations: 34.0%
- Permanent-water negative control (share of JRC permanent-water cells with MNDWI>0): 100%
- Residual-cloud check (valid pixels with blue SR > 0.15): 0.04%
- Reasons: district valid coverage 33.6% < 50% | median clear observations 0 < 3 (composite statistically weak) | 34% of district from a single observation | Landsat-7 SLC-off is the only sensor (striping gaps filled only by repeat passes)

### 2012

**annual** — Status: **WARNING**
- Sensors: landsat-7 · scenes: 14
- Valid district coverage: 100.0% · reliable (≥3 clear obs): 100.0%
- Median clear observations per pixel: 11 · mean clear fraction of observations: 82.9%
- Permanent-water negative control (share of JRC permanent-water cells with MNDWI>0): 100%
- Residual-cloud check (valid pixels with blue SR > 0.15): 0.0%
- Reasons: Landsat-7 SLC-off is the only sensor (striping gaps filled only by repeat passes)

**dry** — Status: **WARNING**
- Sensors: landsat-7 · scenes: 9
- Valid district coverage: 100.0% · reliable (≥3 clear obs): 100.0%
- Median clear observations per pixel: 8 · mean clear fraction of observations: 94.0%
- Permanent-water negative control (share of JRC permanent-water cells with MNDWI>0): 100%
- Residual-cloud check (valid pixels with blue SR > 0.15): 0.0%
- Reasons: Landsat-7 SLC-off is the only sensor (striping gaps filled only by repeat passes)

**post_monsoon** — Status: **WARNING**
- Sensors: landsat-7 · scenes: 3
- Valid district coverage: 100.0% · reliable (≥3 clear obs): 93.9%
- Median clear observations per pixel: 3 · mean clear fraction of observations: 99.6%
- Permanent-water negative control (share of JRC permanent-water cells with MNDWI>0): 100%
- Residual-cloud check (valid pixels with blue SR > 0.15): 0.01%
- Reasons: Landsat-7 SLC-off is the only sensor (striping gaps filled only by repeat passes)

**wet** — Status: **FAIL**
- Sensors: landsat-7 · scenes: 2
- Valid district coverage: 11.8% · reliable (≥3 clear obs): 0.0%
- Median clear observations per pixel: 0 · mean clear fraction of observations: 6.5%
- Permanent-water negative control (share of JRC permanent-water cells with MNDWI>0): 100%
- Residual-cloud check (valid pixels with blue SR > 0.15): 0.02%
- Reasons: district valid coverage 11.8% < 50% | median clear observations 0 < 3 (composite statistically weak) | Landsat-7 SLC-off is the only sensor (striping gaps filled only by repeat passes)

### 2013

**annual** — Status: **PASS**
- Sensors: landsat-7,landsat-8 · scenes: 24
- Valid district coverage: 100.0% · reliable (≥3 clear obs): 100.0%
- Median clear observations per pixel: 21 · mean clear fraction of observations: 89.7%
- Permanent-water negative control (share of JRC permanent-water cells with MNDWI>0): 100%
- Residual-cloud check (valid pixels with blue SR > 0.15): 0.0%
- Reasons: none

**dry** — Status: **PASS**
- Sensors: landsat-7,landsat-8 · scenes: 13
- Valid district coverage: 100.0% · reliable (≥3 clear obs): 100.0%
- Median clear observations per pixel: 12 · mean clear fraction of observations: 94.3%
- Permanent-water negative control (share of JRC permanent-water cells with MNDWI>0): 100%
- Residual-cloud check (valid pixels with blue SR > 0.15): 0.0%
- Reasons: none

**post_monsoon** — Status: **PASS**
- Sensors: landsat-7,landsat-8 · scenes: 10
- Valid district coverage: 100.0% · reliable (≥3 clear obs): 100.0%
- Median clear observations per pixel: 8 · mean clear fraction of observations: 83.9%
- Permanent-water negative control (share of JRC permanent-water cells with MNDWI>0): 100%
- Residual-cloud check (valid pixels with blue SR > 0.15): 0.01%
- Reasons: none

**wet** — Status: **WARNING**
- Sensors: landsat-7 · scenes: 1
- Valid district coverage: 81.4% · reliable (≥3 clear obs): 0.0%
- Median clear observations per pixel: 1 · mean clear fraction of observations: 84.2%
- Permanent-water negative control (share of JRC permanent-water cells with MNDWI>0): 100%
- Residual-cloud check (valid pixels with blue SR > 0.15): 0.12%
- Reasons: district valid coverage 81.4% < 95% | median clear observations 1 < 3 (composite statistically weak) | 81% of district from a single observation | Landsat-7 SLC-off is the only sensor (striping gaps filled only by repeat passes)

### 2014

**annual** — Status: **PASS**
- Sensors: landsat-7,landsat-8 · scenes: 32
- Valid district coverage: 100.0% · reliable (≥3 clear obs): 100.0%
- Median clear observations per pixel: 26 · mean clear fraction of observations: 82.1%
- Permanent-water negative control (share of JRC permanent-water cells with MNDWI>0): 100%
- Residual-cloud check (valid pixels with blue SR > 0.15): 0.0%
- Reasons: none

**dry** — Status: **PASS**
- Sensors: landsat-7,landsat-8 · scenes: 18
- Valid district coverage: 100.0% · reliable (≥3 clear obs): 100.0%
- Median clear observations per pixel: 17 · mean clear fraction of observations: 91.9%
- Permanent-water negative control (share of JRC permanent-water cells with MNDWI>0): 100%
- Residual-cloud check (valid pixels with blue SR > 0.15): 0.0%
- Reasons: none

**post_monsoon** — Status: **PASS**
- Sensors: landsat-7,landsat-8 · scenes: 8
- Valid district coverage: 100.0% · reliable (≥3 clear obs): 99.9%
- Median clear observations per pixel: 7 · mean clear fraction of observations: 81.7%
- Permanent-water negative control (share of JRC permanent-water cells with MNDWI>0): 100%
- Residual-cloud check (valid pixels with blue SR > 0.15): 0.0%
- Reasons: none

**wet** — Status: **PASS**
- Sensors: landsat-7,landsat-8 · scenes: 6
- Valid district coverage: 99.9% · reliable (≥3 clear obs): 73.8%
- Median clear observations per pixel: 3 · mean clear fraction of observations: 53.1%
- Permanent-water negative control (share of JRC permanent-water cells with MNDWI>0): 99%
- Residual-cloud check (valid pixels with blue SR > 0.15): 0.12%
- Reasons: none

### 2015

**annual** — Status: **PASS**
- Sensors: landsat-7,landsat-8 · scenes: 34
- Valid district coverage: 100.0% · reliable (≥3 clear obs): 100.0%
- Median clear observations per pixel: 28 · mean clear fraction of observations: 83.6%
- Permanent-water negative control (share of JRC permanent-water cells with MNDWI>0): 100%
- Residual-cloud check (valid pixels with blue SR > 0.15): 0.0%
- Reasons: none

**dry** — Status: **PASS**
- Sensors: landsat-7,landsat-8 · scenes: 17
- Valid district coverage: 100.0% · reliable (≥3 clear obs): 100.0%
- Median clear observations per pixel: 16 · mean clear fraction of observations: 92.4%
- Permanent-water negative control (share of JRC permanent-water cells with MNDWI>0): 100%
- Residual-cloud check (valid pixels with blue SR > 0.15): 0.0%
- Reasons: none

**post_monsoon** — Status: **PASS**
- Sensors: landsat-7,landsat-8 · scenes: 11
- Valid district coverage: 100.0% · reliable (≥3 clear obs): 100.0%
- Median clear observations per pixel: 9 · mean clear fraction of observations: 84.3%
- Permanent-water negative control (share of JRC permanent-water cells with MNDWI>0): 100%
- Residual-cloud check (valid pixels with blue SR > 0.15): 0.0%
- Reasons: none

**wet** — Status: **PASS**
- Sensors: landsat-7,landsat-8 · scenes: 6
- Valid district coverage: 99.9% · reliable (≥3 clear obs): 79.5%
- Median clear observations per pixel: 3 · mean clear fraction of observations: 57.9%
- Permanent-water negative control (share of JRC permanent-water cells with MNDWI>0): 98%
- Residual-cloud check (valid pixels with blue SR > 0.15): 0.14%
- Reasons: none

### 2016

**annual** — Status: **PASS**
- Sensors: landsat-7,landsat-8 · scenes: 32
- Valid district coverage: 100.0% · reliable (≥3 clear obs): 100.0%
- Median clear observations per pixel: 28 · mean clear fraction of observations: 87.0%
- Permanent-water negative control (share of JRC permanent-water cells with MNDWI>0): 100%
- Residual-cloud check (valid pixels with blue SR > 0.15): 0.0%
- Reasons: none

**dry** — Status: **PASS**
- Sensors: landsat-7,landsat-8 · scenes: 19
- Valid district coverage: 100.0% · reliable (≥3 clear obs): 100.0%
- Median clear observations per pixel: 17 · mean clear fraction of observations: 89.5%
- Permanent-water negative control (share of JRC permanent-water cells with MNDWI>0): 100%
- Residual-cloud check (valid pixels with blue SR > 0.15): 0.0%
- Reasons: none

**post_monsoon** — Status: **PASS**
- Sensors: landsat-7,landsat-8 · scenes: 10
- Valid district coverage: 100.0% · reliable (≥3 clear obs): 100.0%
- Median clear observations per pixel: 10 · mean clear fraction of observations: 95.4%
- Permanent-water negative control (share of JRC permanent-water cells with MNDWI>0): 100%
- Residual-cloud check (valid pixels with blue SR > 0.15): 0.0%
- Reasons: none

**wet** — Status: **WARNING**
- Sensors: landsat-7,landsat-8 · scenes: 3
- Valid district coverage: 82.8% · reliable (≥3 clear obs): 4.2%
- Median clear observations per pixel: 1 · mean clear fraction of observations: 41.4%
- Permanent-water negative control (share of JRC permanent-water cells with MNDWI>0): 100%
- Residual-cloud check (valid pixels with blue SR > 0.15): 0.46%
- Reasons: district valid coverage 82.8% < 95% | median clear observations 1 < 3 (composite statistically weak) | 47% of district from a single observation

### 2017

**annual** — Status: **PASS**
- Sensors: landsat-7,landsat-8 · scenes: 33
- Valid district coverage: 100.0% · reliable (≥3 clear obs): 100.0%
- Median clear observations per pixel: 26 · mean clear fraction of observations: 79.9%
- Permanent-water negative control (share of JRC permanent-water cells with MNDWI>0): 100%
- Residual-cloud check (valid pixels with blue SR > 0.15): 0.0%
- Reasons: none

**dry** — Status: **PASS**
- Sensors: landsat-7,landsat-8 · scenes: 19
- Valid district coverage: 100.0% · reliable (≥3 clear obs): 100.0%
- Median clear observations per pixel: 18 · mean clear fraction of observations: 96.7%
- Permanent-water negative control (share of JRC permanent-water cells with MNDWI>0): 100%
- Residual-cloud check (valid pixels with blue SR > 0.15): 0.0%
- Reasons: none

**post_monsoon** — Status: **PASS**
- Sensors: landsat-7,landsat-8 · scenes: 10
- Valid district coverage: 100.0% · reliable (≥3 clear obs): 100.0%
- Median clear observations per pixel: 7 · mean clear fraction of observations: 69.4%
- Permanent-water negative control (share of JRC permanent-water cells with MNDWI>0): 100%
- Residual-cloud check (valid pixels with blue SR > 0.15): 0.02%
- Reasons: none

**wet** — Status: **WARNING**
- Sensors: landsat-7,landsat-8 · scenes: 4
- Valid district coverage: 70.4% · reliable (≥3 clear obs): 5.0%
- Median clear observations per pixel: 1 · mean clear fraction of observations: 26.0%
- Permanent-water negative control (share of JRC permanent-water cells with MNDWI>0): 92%
- Residual-cloud check (valid pixels with blue SR > 0.15): 0.28%
- Reasons: district valid coverage 70.4% < 95% | median clear observations 1 < 3 (composite statistically weak) | 43% of district from a single observation

### 2018

**annual** — Status: **PASS**
- Sensors: landsat-7,landsat-8 · scenes: 35
- Valid district coverage: 100.0% · reliable (≥3 clear obs): 100.0%
- Median clear observations per pixel: 30 · mean clear fraction of observations: 85.7%
- Permanent-water negative control (share of JRC permanent-water cells with MNDWI>0): 100%
- Residual-cloud check (valid pixels with blue SR > 0.15): 0.01%
- Reasons: none

**dry** — Status: **PASS**
- Sensors: landsat-7,landsat-8 · scenes: 18
- Valid district coverage: 100.0% · reliable (≥3 clear obs): 100.0%
- Median clear observations per pixel: 18 · mean clear fraction of observations: 99.7%
- Permanent-water negative control (share of JRC permanent-water cells with MNDWI>0): 100%
- Residual-cloud check (valid pixels with blue SR > 0.15): 0.0%
- Reasons: none

**post_monsoon** — Status: **PASS**
- Sensors: landsat-7,landsat-8 · scenes: 12
- Valid district coverage: 100.0% · reliable (≥3 clear obs): 100.0%
- Median clear observations per pixel: 10 · mean clear fraction of observations: 82.1%
- Permanent-water negative control (share of JRC permanent-water cells with MNDWI>0): 100%
- Residual-cloud check (valid pixels with blue SR > 0.15): 0.01%
- Reasons: none

**wet** — Status: **WARNING**
- Sensors: landsat-7,landsat-8 · scenes: 5
- Valid district coverage: 98.5% · reliable (≥3 clear obs): 33.9%
- Median clear observations per pixel: 2 · mean clear fraction of observations: 43.1%
- Permanent-water negative control (share of JRC permanent-water cells with MNDWI>0): 100%
- Residual-cloud check (valid pixels with blue SR > 0.15): 0.25%
- Reasons: median clear observations 2 < 3 (composite statistically weak)

### 2019

**annual** — Status: **PASS**
- Sensors: landsat-7,landsat-8 · scenes: 34
- Valid district coverage: 100.0% · reliable (≥3 clear obs): 100.0%
- Median clear observations per pixel: 28 · mean clear fraction of observations: 81.5%
- Permanent-water negative control (share of JRC permanent-water cells with MNDWI>0): 100%
- Residual-cloud check (valid pixels with blue SR > 0.15): 0.0%
- Reasons: none

**dry** — Status: **PASS**
- Sensors: landsat-7,landsat-8 · scenes: 19
- Valid district coverage: 100.0% · reliable (≥3 clear obs): 100.0%
- Median clear observations per pixel: 18 · mean clear fraction of observations: 94.4%
- Permanent-water negative control (share of JRC permanent-water cells with MNDWI>0): 100%
- Residual-cloud check (valid pixels with blue SR > 0.15): 0.0%
- Reasons: none

**post_monsoon** — Status: **PASS**
- Sensors: landsat-7,landsat-8 · scenes: 11
- Valid district coverage: 100.0% · reliable (≥3 clear obs): 100.0%
- Median clear observations per pixel: 9 · mean clear fraction of observations: 80.6%
- Permanent-water negative control (share of JRC permanent-water cells with MNDWI>0): 100%
- Residual-cloud check (valid pixels with blue SR > 0.15): 0.02%
- Reasons: none

**wet** — Status: **WARNING**
- Sensors: landsat-7,landsat-8 · scenes: 4
- Valid district coverage: 81.3% · reliable (≥3 clear obs): 1.1%
- Median clear observations per pixel: 1 · mean clear fraction of observations: 26.1%
- Permanent-water negative control (share of JRC permanent-water cells with MNDWI>0): 97%
- Residual-cloud check (valid pixels with blue SR > 0.15): 0.52%
- Reasons: district valid coverage 81.3% < 95% | median clear observations 1 < 3 (composite statistically weak) | 60% of district from a single observation

### 2020

**annual** — Status: **PASS**
- Sensors: landsat-7,landsat-8 · scenes: 36
- Valid district coverage: 100.0% · reliable (≥3 clear obs): 100.0%
- Median clear observations per pixel: 29 · mean clear fraction of observations: 81.5%
- Permanent-water negative control (share of JRC permanent-water cells with MNDWI>0): 100%
- Residual-cloud check (valid pixels with blue SR > 0.15): 0.01%
- Reasons: none

**dry** — Status: **PASS**
- Sensors: landsat-7,landsat-8 · scenes: 18
- Valid district coverage: 100.0% · reliable (≥3 clear obs): 100.0%
- Median clear observations per pixel: 16 · mean clear fraction of observations: 88.5%
- Permanent-water negative control (share of JRC permanent-water cells with MNDWI>0): 100%
- Residual-cloud check (valid pixels with blue SR > 0.15): 0.01%
- Reasons: none

**post_monsoon** — Status: **PASS**
- Sensors: landsat-7,landsat-8 · scenes: 10
- Valid district coverage: 100.0% · reliable (≥3 clear obs): 100.0%
- Median clear observations per pixel: 10 · mean clear fraction of observations: 97.3%
- Permanent-water negative control (share of JRC permanent-water cells with MNDWI>0): 100%
- Residual-cloud check (valid pixels with blue SR > 0.15): 0.01%
- Reasons: none

**wet** — Status: **PASS**
- Sensors: landsat-7,landsat-8 · scenes: 8
- Valid district coverage: 99.9% · reliable (≥3 clear obs): 86.5%
- Median clear observations per pixel: 4 · mean clear fraction of observations: 45.7%
- Permanent-water negative control (share of JRC permanent-water cells with MNDWI>0): 100%
- Residual-cloud check (valid pixels with blue SR > 0.15): 0.29%
- Reasons: none

### 2021

**annual** — Status: **PASS**
- Sensors: landsat-7,landsat-8,landsat-9 · scenes: 29
- Valid district coverage: 100.0% · reliable (≥3 clear obs): 100.0%
- Median clear observations per pixel: 19 · mean clear fraction of observations: 66.3%
- Permanent-water negative control (share of JRC permanent-water cells with MNDWI>0): 100%
- Residual-cloud check (valid pixels with blue SR > 0.15): 0.0%
- Reasons: none

**dry** — Status: **PASS**
- Sensors: landsat-7,landsat-8 · scenes: 17
- Valid district coverage: 100.0% · reliable (≥3 clear obs): 100.0%
- Median clear observations per pixel: 14 · mean clear fraction of observations: 83.3%
- Permanent-water negative control (share of JRC permanent-water cells with MNDWI>0): 100%
- Residual-cloud check (valid pixels with blue SR > 0.15): 0.0%
- Reasons: none

**post_monsoon** — Status: **PASS**
- Sensors: landsat-7,landsat-8,landsat-9 · scenes: 9
- Valid district coverage: 100.0% · reliable (≥3 clear obs): 99.4%
- Median clear observations per pixel: 4 · mean clear fraction of observations: 48.3%
- Permanent-water negative control (share of JRC permanent-water cells with MNDWI>0): 100%
- Residual-cloud check (valid pixels with blue SR > 0.15): 0.01%
- Reasons: none

**wet** — Status: **WARNING**
- Sensors: landsat-7 · scenes: 3
- Valid district coverage: 58.8% · reliable (≥3 clear obs): 0.0%
- Median clear observations per pixel: 1 · mean clear fraction of observations: 21.0%
- Permanent-water negative control (share of JRC permanent-water cells with MNDWI>0): 99%
- Residual-cloud check (valid pixels with blue SR > 0.15): 3.93%
- Reasons: district valid coverage 58.8% < 95% | median clear observations 1 < 3 (composite statistically weak) | 55% of district from a single observation | Landsat-7 SLC-off is the only sensor (striping gaps filled only by repeat passes) | possible residual cloud/haze: 3.9% of valid pixels transiently bright (blue SR > 0.15)

### 2022

**annual** — Status: **PASS**
- Sensors: landsat-8,landsat-9 · scenes: 27
- Valid district coverage: 100.0% · reliable (≥3 clear obs): 100.0%
- Median clear observations per pixel: 21 · mean clear fraction of observations: 77.9%
- Permanent-water negative control (share of JRC permanent-water cells with MNDWI>0): 100%
- Residual-cloud check (valid pixels with blue SR > 0.15): 0.0%
- Reasons: none

**dry** — Status: **PASS**
- Sensors: landsat-8,landsat-9 · scenes: 16
- Valid district coverage: 100.0% · reliable (≥3 clear obs): 100.0%
- Median clear observations per pixel: 13 · mean clear fraction of observations: 83.0%
- Permanent-water negative control (share of JRC permanent-water cells with MNDWI>0): 100%
- Residual-cloud check (valid pixels with blue SR > 0.15): 0.0%
- Reasons: none

**post_monsoon** — Status: **PASS**
- Sensors: landsat-8,landsat-9 · scenes: 9
- Valid district coverage: 100.0% · reliable (≥3 clear obs): 99.9%
- Median clear observations per pixel: 8 · mean clear fraction of observations: 83.7%
- Permanent-water negative control (share of JRC permanent-water cells with MNDWI>0): 100%
- Residual-cloud check (valid pixels with blue SR > 0.15): 0.01%
- Reasons: none

**wet** — Status: **FAIL**
- Sensors: landsat-8 · scenes: 2
- Valid district coverage: 26.9% · reliable (≥3 clear obs): 0.0%
- Median clear observations per pixel: 0 · mean clear fraction of observations: 13.7%
- Permanent-water negative control (share of JRC permanent-water cells with MNDWI>0): 64%
- Residual-cloud check (valid pixels with blue SR > 0.15): 0.4%
- Reasons: district valid coverage 26.9% < 50% | median clear observations 0 < 3 (composite statistically weak) | 26% of district from a single observation | negative control weak: 64% of permanent-water cells read as water

### 2023

**annual** — Status: **PASS**
- Sensors: landsat-8,landsat-9 · scenes: 35
- Valid district coverage: 100.0% · reliable (≥3 clear obs): 100.0%
- Median clear observations per pixel: 26 · mean clear fraction of observations: 73.2%
- Permanent-water negative control (share of JRC permanent-water cells with MNDWI>0): 100%
- Residual-cloud check (valid pixels with blue SR > 0.15): 0.01%
- Reasons: none

**dry** — Status: **PASS**
- Sensors: landsat-8,landsat-9 · scenes: 18
- Valid district coverage: 100.0% · reliable (≥3 clear obs): 100.0%
- Median clear observations per pixel: 14 · mean clear fraction of observations: 77.6%
- Permanent-water negative control (share of JRC permanent-water cells with MNDWI>0): 100%
- Residual-cloud check (valid pixels with blue SR > 0.15): 0.01%
- Reasons: none

**post_monsoon** — Status: **PASS**
- Sensors: landsat-8,landsat-9 · scenes: 10
- Valid district coverage: 100.0% · reliable (≥3 clear obs): 100.0%
- Median clear observations per pixel: 8 · mean clear fraction of observations: 81.4%
- Permanent-water negative control (share of JRC permanent-water cells with MNDWI>0): 100%
- Residual-cloud check (valid pixels with blue SR > 0.15): 0.0%
- Reasons: none

**wet** — Status: **PASS**
- Sensors: landsat-8,landsat-9 · scenes: 7
- Valid district coverage: 100.0% · reliable (≥3 clear obs): 84.9%
- Median clear observations per pixel: 3 · mean clear fraction of observations: 50.8%
- Permanent-water negative control (share of JRC permanent-water cells with MNDWI>0): 100%
- Residual-cloud check (valid pixels with blue SR > 0.15): 0.35%
- Reasons: none

### 2024

**annual** — Status: **PASS**
- Sensors: landsat-8,landsat-9 · scenes: 29
- Valid district coverage: 100.0% · reliable (≥3 clear obs): 100.0%
- Median clear observations per pixel: 23 · mean clear fraction of observations: 77.4%
- Permanent-water negative control (share of JRC permanent-water cells with MNDWI>0): 100%
- Residual-cloud check (valid pixels with blue SR > 0.15): 0.0%
- Reasons: none

**dry** — Status: **PASS**
- Sensors: landsat-8,landsat-9 · scenes: 19
- Valid district coverage: 100.0% · reliable (≥3 clear obs): 100.0%
- Median clear observations per pixel: 17 · mean clear fraction of observations: 89.5%
- Permanent-water negative control (share of JRC permanent-water cells with MNDWI>0): 100%
- Residual-cloud check (valid pixels with blue SR > 0.15): 0.01%
- Reasons: none

**post_monsoon** — Status: **PASS**
- Sensors: landsat-8,landsat-9 · scenes: 9
- Valid district coverage: 100.0% · reliable (≥3 clear obs): 99.9%
- Median clear observations per pixel: 5 · mean clear fraction of observations: 59.1%
- Permanent-water negative control (share of JRC permanent-water cells with MNDWI>0): 100%
- Residual-cloud check (valid pixels with blue SR > 0.15): 0.01%
- Reasons: none

**wet** — Status: **FAIL**
- Sensors: landsat-9 · scenes: 1
- Valid district coverage: 14.9% · reliable (≥3 clear obs): 0.0%
- Median clear observations per pixel: 0 · mean clear fraction of observations: 14.9%
- Permanent-water negative control (share of JRC permanent-water cells with MNDWI>0): 98%
- Residual-cloud check (valid pixels with blue SR > 0.15): 0.21%
- Reasons: district valid coverage 14.9% < 50% | median clear observations 0 < 3 (composite statistically weak)

### 2025

**annual** — Status: **PASS**
- Sensors: landsat-8,landsat-9 · scenes: 30
- Valid district coverage: 100.0% · reliable (≥3 clear obs): 100.0%
- Median clear observations per pixel: 22 · mean clear fraction of observations: 74.4%
- Permanent-water negative control (share of JRC permanent-water cells with MNDWI>0): 100%
- Residual-cloud check (valid pixels with blue SR > 0.15): 0.01%
- Reasons: none

**dry** — Status: **PASS**
- Sensors: landsat-8,landsat-9 · scenes: 18
- Valid district coverage: 100.0% · reliable (≥3 clear obs): 100.0%
- Median clear observations per pixel: 15 · mean clear fraction of observations: 85.5%
- Permanent-water negative control (share of JRC permanent-water cells with MNDWI>0): 100%
- Residual-cloud check (valid pixels with blue SR > 0.15): 0.0%
- Reasons: none

**post_monsoon** — Status: **PASS**
- Sensors: landsat-8,landsat-9 · scenes: 10
- Valid district coverage: 100.0% · reliable (≥3 clear obs): 99.8%
- Median clear observations per pixel: 7 · mean clear fraction of observations: 65.4%
- Permanent-water negative control (share of JRC permanent-water cells with MNDWI>0): 100%
- Residual-cloud check (valid pixels with blue SR > 0.15): 0.03%
- Reasons: none

**wet** — Status: **FAIL**
- Sensors: landsat-8 · scenes: 2
- Valid district coverage: 35.8% · reliable (≥3 clear obs): 0.0%
- Median clear observations per pixel: 0 · mean clear fraction of observations: 19.1%
- Permanent-water negative control (share of JRC permanent-water cells with MNDWI>0): 100%
- Residual-cloud check (valid pixels with blue SR > 0.15): 0.16%
- Reasons: district valid coverage 35.8% < 50% | median clear observations 0 < 3 (composite statistically weak) | 33% of district from a single observation

### 2026

**annual** — Status: **WARNING** (PARTIAL)
- Sensors: landsat-8,landsat-9 · scenes: 23
- Valid district coverage: 100.0% · reliable (≥3 clear obs): 100.0%
- Median clear observations per pixel: 20 · mean clear fraction of observations: 86.9%
- Permanent-water negative control (share of JRC permanent-water cells with MNDWI>0): 100%
- Residual-cloud check (valid pixels with blue SR > 0.15): 0.02%
- Reasons: PARTIAL period: archive cut-off 2026-10-01

**dry** — Status: **PASS**
- Sensors: landsat-8,landsat-9 · scenes: 18
- Valid district coverage: 100.0% · reliable (≥3 clear obs): 100.0%
- Median clear observations per pixel: 17 · mean clear fraction of observations: 94.0%
- Permanent-water negative control (share of JRC permanent-water cells with MNDWI>0): 100%
- Residual-cloud check (valid pixels with blue SR > 0.15): 0.0%
- Reasons: none

**post_monsoon** — Status: **IN_PROGRESS** (PARTIAL)
- Sensors: — · scenes: 0
- Valid district coverage: 0.0% · reliable (≥3 clear obs): 0.0%
- Median clear observations per pixel: 0 · mean clear fraction of observations: 0.0%
- Permanent-water negative control (share of JRC permanent-water cells with MNDWI>0): n/a
- Residual-cloud check (valid pixels with blue SR > 0.15): n/a
- Reasons: period in progress at the archive cut-off 2026-10-01 20:07 with no acquisitions yet - nothing to assess

**wet** — Status: **PASS**
- Sensors: landsat-8,landsat-9 · scenes: 5
- Valid district coverage: 100.0% · reliable (≥3 clear obs): 69.0%
- Median clear observations per pixel: 3 · mean clear fraction of observations: 60.2%
- Permanent-water negative control (share of JRC permanent-water cells with MNDWI>0): 99%
- Residual-cloud check (valid pixels with blue SR > 0.15): 0.48%
- Reasons: none
