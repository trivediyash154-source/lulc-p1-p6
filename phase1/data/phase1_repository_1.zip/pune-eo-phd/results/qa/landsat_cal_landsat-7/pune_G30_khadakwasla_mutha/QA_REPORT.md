# Pune EO Data QA Report — landsat_cal_landsat-7 — grid `pune_G30_khadakwasla_mutha`

Generated automatically by `pune-eo qa`. Thresholds: `configs/qa.yaml`. Every product's full QA record is
also written into its own `metadata.json` (`qa` block).

## Summary

| period   |   PASS |   WARNING |
|:---------|-------:|----------:|
| dry      |      2 |         5 |

## Per-year records

### 2000

**dry** — Status: **WARNING**
- Sensors: landsat-7 · scenes: 2
- Valid district coverage: 100.0% · reliable (≥3 clear obs): 0.0%
- Median clear observations per pixel: 2 · mean clear fraction of observations: 92.2%
- Permanent-water negative control (share of JRC permanent-water cells with MNDWI>0): 99%
- Residual-cloud check (valid pixels with blue SR > 0.15): 0.02%
- Reasons: median clear observations 2 < 3 (composite statistically weak)

### 2001

**dry** — Status: **PASS**
- Sensors: landsat-7 · scenes: 4
- Valid district coverage: 100.0% · reliable (≥3 clear obs): 100.0%
- Median clear observations per pixel: 4 · mean clear fraction of observations: 99.9%
- Permanent-water negative control (share of JRC permanent-water cells with MNDWI>0): 99%
- Residual-cloud check (valid pixels with blue SR > 0.15): 0.02%
- Reasons: none

### 2002

**dry** — Status: **PASS**
- Sensors: landsat-7 · scenes: 3
- Valid district coverage: 100.0% · reliable (≥3 clear obs): 98.3%
- Median clear observations per pixel: 3 · mean clear fraction of observations: 99.4%
- Permanent-water negative control (share of JRC permanent-water cells with MNDWI>0): 99%
- Residual-cloud check (valid pixels with blue SR > 0.15): 0.01%
- Reasons: none

### 2003

**dry** — Status: **WARNING**
- Sensors: landsat-7 · scenes: 2
- Valid district coverage: 100.0% · reliable (≥3 clear obs): 0.0%
- Median clear observations per pixel: 2 · mean clear fraction of observations: 100.0%
- Permanent-water negative control (share of JRC permanent-water cells with MNDWI>0): 98%
- Residual-cloud check (valid pixels with blue SR > 0.15): 0.01%
- Reasons: median clear observations 2 < 3 (composite statistically weak)

### 2014

**dry** — Status: **WARNING**
- Sensors: landsat-7 · scenes: 10
- Valid district coverage: 100.0% · reliable (≥3 clear obs): 100.0%
- Median clear observations per pixel: 10 · mean clear fraction of observations: 97.5%
- Permanent-water negative control (share of JRC permanent-water cells with MNDWI>0): 100%
- Residual-cloud check (valid pixels with blue SR > 0.15): 0.05%
- Reasons: Landsat-7 SLC-off is the only sensor (striping gaps filled only by repeat passes)

### 2015

**dry** — Status: **WARNING**
- Sensors: landsat-7 · scenes: 7
- Valid district coverage: 100.0% · reliable (≥3 clear obs): 100.0%
- Median clear observations per pixel: 6 · mean clear fraction of observations: 89.8%
- Permanent-water negative control (share of JRC permanent-water cells with MNDWI>0): 100%
- Residual-cloud check (valid pixels with blue SR > 0.15): 0.07%
- Reasons: Landsat-7 SLC-off is the only sensor (striping gaps filled only by repeat passes)

### 2016

**dry** — Status: **WARNING**
- Sensors: landsat-7 · scenes: 9
- Valid district coverage: 100.0% · reliable (≥3 clear obs): 100.0%
- Median clear observations per pixel: 8 · mean clear fraction of observations: 94.1%
- Permanent-water negative control (share of JRC permanent-water cells with MNDWI>0): 100%
- Residual-cloud check (valid pixels with blue SR > 0.15): 0.03%
- Reasons: Landsat-7 SLC-off is the only sensor (striping gaps filled only by repeat passes)
