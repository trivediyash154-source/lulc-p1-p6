# Pune EO Data QA Report — landsat_cal_landsat-7 — grid `pune_G30_baramati_agri`

Generated automatically by `pune-eo qa`. Thresholds: `configs/qa.yaml`. Every product's full QA record is
also written into its own `metadata.json` (`qa` block).

## Summary

| period   |   PASS |   WARNING |
|:---------|-------:|----------:|
| dry      |      4 |         3 |

## Per-year records

### 2000

**dry** — Status: **PASS**
- Sensors: landsat-7 · scenes: 8
- Valid district coverage: 100.0% · reliable (≥3 clear obs): 100.0%
- Median clear observations per pixel: 6 · mean clear fraction of observations: 95.0%
- Permanent-water negative control (share of JRC permanent-water cells with MNDWI>0): n/a
- Residual-cloud check (valid pixels with blue SR > 0.15): 0.06%
- Reasons: none

### 2001

**dry** — Status: **PASS**
- Sensors: landsat-7 · scenes: 15
- Valid district coverage: 100.0% · reliable (≥3 clear obs): 100.0%
- Median clear observations per pixel: 12 · mean clear fraction of observations: 99.4%
- Permanent-water negative control (share of JRC permanent-water cells with MNDWI>0): n/a
- Residual-cloud check (valid pixels with blue SR > 0.15): 0.04%
- Reasons: none

### 2002

**dry** — Status: **PASS**
- Sensors: landsat-7 · scenes: 11
- Valid district coverage: 100.0% · reliable (≥3 clear obs): 100.0%
- Median clear observations per pixel: 7 · mean clear fraction of observations: 88.2%
- Permanent-water negative control (share of JRC permanent-water cells with MNDWI>0): n/a
- Residual-cloud check (valid pixels with blue SR > 0.15): 0.02%
- Reasons: none

### 2003

**dry** — Status: **PASS**
- Sensors: landsat-7 · scenes: 14
- Valid district coverage: 100.0% · reliable (≥3 clear obs): 100.0%
- Median clear observations per pixel: 9 · mean clear fraction of observations: 88.1%
- Permanent-water negative control (share of JRC permanent-water cells with MNDWI>0): n/a
- Residual-cloud check (valid pixels with blue SR > 0.15): 0.02%
- Reasons: none

### 2014

**dry** — Status: **WARNING**
- Sensors: landsat-7 · scenes: 33
- Valid district coverage: 100.0% · reliable (≥3 clear obs): 100.0%
- Median clear observations per pixel: 12 · mean clear fraction of observations: 81.0%
- Permanent-water negative control (share of JRC permanent-water cells with MNDWI>0): n/a
- Residual-cloud check (valid pixels with blue SR > 0.15): 0.13%
- Reasons: Landsat-7 SLC-off is the only sensor (striping gaps filled only by repeat passes)

### 2015

**dry** — Status: **WARNING**
- Sensors: landsat-7 · scenes: 34
- Valid district coverage: 100.0% · reliable (≥3 clear obs): 100.0%
- Median clear observations per pixel: 16 · mean clear fraction of observations: 92.2%
- Permanent-water negative control (share of JRC permanent-water cells with MNDWI>0): n/a
- Residual-cloud check (valid pixels with blue SR > 0.15): 0.16%
- Reasons: Landsat-7 SLC-off is the only sensor (striping gaps filled only by repeat passes)

### 2016

**dry** — Status: **WARNING**
- Sensors: landsat-7 · scenes: 38
- Valid district coverage: 100.0% · reliable (≥3 clear obs): 100.0%
- Median clear observations per pixel: 16 · mean clear fraction of observations: 91.7%
- Permanent-water negative control (share of JRC permanent-water cells with MNDWI>0): n/a
- Residual-cloud check (valid pixels with blue SR > 0.15): 0.15%
- Reasons: Landsat-7 SLC-off is the only sensor (striping gaps filled only by repeat passes)
