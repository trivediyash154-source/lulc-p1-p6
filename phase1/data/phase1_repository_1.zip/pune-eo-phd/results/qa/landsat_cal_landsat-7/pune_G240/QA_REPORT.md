# Pune EO Data QA Report — landsat_cal_landsat-7 — grid `pune_G240`

Generated automatically by `pune-eo qa`. Thresholds: `configs/qa.yaml`. Every product's full QA record is
also written into its own `metadata.json` (`qa` block).

## Summary

| period   |   PASS |   WARNING |
|:---------|-------:|----------:|
| dry      |      2 |         5 |

## Per-year records

### 2000

**dry** — Status: **WARNING**
- Sensors: landsat-7 · scenes: 8
- Valid district coverage: 99.1% · reliable (≥3 clear obs): 16.7%
- Median clear observations per pixel: 2 · mean clear fraction of observations: 78.1%
- Permanent-water negative control (share of JRC permanent-water cells with MNDWI>0): 100%
- Residual-cloud check (valid pixels with blue SR > 0.15): 0.0%
- Reasons: median clear observations 2 < 3 (composite statistically weak) | 39% of district from a single observation

### 2001

**dry** — Status: **PASS**
- Sensors: landsat-7 · scenes: 15
- Valid district coverage: 100.0% · reliable (≥3 clear obs): 100.0%
- Median clear observations per pixel: 4 · mean clear fraction of observations: 98.7%
- Permanent-water negative control (share of JRC permanent-water cells with MNDWI>0): 99%
- Residual-cloud check (valid pixels with blue SR > 0.15): 0.0%
- Reasons: none

### 2002

**dry** — Status: **PASS**
- Sensors: landsat-7 · scenes: 11
- Valid district coverage: 100.0% · reliable (≥3 clear obs): 81.5%
- Median clear observations per pixel: 3 · mean clear fraction of observations: 91.3%
- Permanent-water negative control (share of JRC permanent-water cells with MNDWI>0): 100%
- Residual-cloud check (valid pixels with blue SR > 0.15): 0.0%
- Reasons: none

### 2003

**dry** — Status: **WARNING**
- Sensors: landsat-7 · scenes: 14
- Valid district coverage: 100.0% · reliable (≥3 clear obs): 21.9%
- Median clear observations per pixel: 2 · mean clear fraction of observations: 98.2%
- Permanent-water negative control (share of JRC permanent-water cells with MNDWI>0): 100%
- Residual-cloud check (valid pixels with blue SR > 0.15): 0.0%
- Reasons: median clear observations 2 < 3 (composite statistically weak)

### 2014

**dry** — Status: **WARNING**
- Sensors: landsat-7 · scenes: 33
- Valid district coverage: 100.0% · reliable (≥3 clear obs): 95.7%
- Median clear observations per pixel: 6 · mean clear fraction of observations: 90.6%
- Permanent-water negative control (share of JRC permanent-water cells with MNDWI>0): 100%
- Residual-cloud check (valid pixels with blue SR > 0.15): 0.0%
- Reasons: Landsat-7 SLC-off is the only sensor (striping gaps filled only by repeat passes)

### 2015

**dry** — Status: **WARNING**
- Sensors: landsat-7 · scenes: 34
- Valid district coverage: 100.0% · reliable (≥3 clear obs): 94.8%
- Median clear observations per pixel: 4 · mean clear fraction of observations: 88.4%
- Permanent-water negative control (share of JRC permanent-water cells with MNDWI>0): 100%
- Residual-cloud check (valid pixels with blue SR > 0.15): 0.01%
- Reasons: Landsat-7 SLC-off is the only sensor (striping gaps filled only by repeat passes)

### 2016

**dry** — Status: **WARNING**
- Sensors: landsat-7 · scenes: 38
- Valid district coverage: 100.0% · reliable (≥3 clear obs): 95.3%
- Median clear observations per pixel: 6 · mean clear fraction of observations: 89.5%
- Permanent-water negative control (share of JRC permanent-water cells with MNDWI>0): 100%
- Residual-cloud check (valid pixels with blue SR > 0.15): 0.0%
- Reasons: Landsat-7 SLC-off is the only sensor (striping gaps filled only by repeat passes)
