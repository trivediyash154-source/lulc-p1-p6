# Pune EO Data QA Report — landsat_cal_landsat-9 — grid `pune_G30_baramati_agri`

Generated automatically by `pune-eo qa`. Thresholds: `configs/qa.yaml`. Every product's full QA record is
also written into its own `metadata.json` (`qa` block).

## Summary

| period   |   PASS |
|:---------|-------:|
| dry      |      2 |

## Per-year records

### 2022

**dry** — Status: **PASS**
- Sensors: landsat-9 · scenes: 33
- Valid district coverage: 100.0% · reliable (≥3 clear obs): 100.0%
- Median clear observations per pixel: 23 · mean clear fraction of observations: 90.4%
- Permanent-water negative control (share of JRC permanent-water cells with MNDWI>0): n/a
- Residual-cloud check (valid pixels with blue SR > 0.15): 0.03%
- Reasons: none

### 2023

**dry** — Status: **PASS**
- Sensors: landsat-9 · scenes: 31
- Valid district coverage: 100.0% · reliable (≥3 clear obs): 100.0%
- Median clear observations per pixel: 20 · mean clear fraction of observations: 88.8%
- Permanent-water negative control (share of JRC permanent-water cells with MNDWI>0): n/a
- Residual-cloud check (valid pixels with blue SR > 0.15): 0.1%
- Reasons: none
