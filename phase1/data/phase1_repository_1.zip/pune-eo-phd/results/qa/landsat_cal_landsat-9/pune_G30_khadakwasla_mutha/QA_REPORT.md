# Pune EO Data QA Report — landsat_cal_landsat-9 — grid `pune_G30_khadakwasla_mutha`

Generated automatically by `pune-eo qa`. Thresholds: `configs/qa.yaml`. Every product's full QA record is
also written into its own `metadata.json` (`qa` block).

## Summary

| period   |   PASS |
|:---------|-------:|
| dry      |      2 |

## Per-year records

### 2022

**dry** — Status: **PASS**
- Sensors: landsat-9 · scenes: 8
- Valid district coverage: 100.0% · reliable (≥3 clear obs): 100.0%
- Median clear observations per pixel: 6 · mean clear fraction of observations: 80.1%
- Permanent-water negative control (share of JRC permanent-water cells with MNDWI>0): 100%
- Residual-cloud check (valid pixels with blue SR > 0.15): 0.02%
- Reasons: none

### 2023

**dry** — Status: **PASS**
- Sensors: landsat-9 · scenes: 9
- Valid district coverage: 100.0% · reliable (≥3 clear obs): 100.0%
- Median clear observations per pixel: 7 · mean clear fraction of observations: 76.2%
- Permanent-water negative control (share of JRC permanent-water cells with MNDWI>0): 100%
- Residual-cloud check (valid pixels with blue SR > 0.15): 0.06%
- Reasons: none
