# Pune EO Data QA Report — landsat_cal_landsat-8 — grid `pune_G30_baramati_agri`

Generated automatically by `pune-eo qa`. Thresholds: `configs/qa.yaml`. Every product's full QA record is
also written into its own `metadata.json` (`qa` block).

## Summary

| period   |   PASS |
|:---------|-------:|
| dry      |      5 |

## Per-year records

### 2014

**dry** — Status: **PASS**
- Sensors: landsat-8 · scenes: 30
- Valid district coverage: 100.0% · reliable (≥3 clear obs): 100.0%
- Median clear observations per pixel: 21 · mean clear fraction of observations: 94.5%
- Permanent-water negative control (share of JRC permanent-water cells with MNDWI>0): n/a
- Residual-cloud check (valid pixels with blue SR > 0.15): 0.09%
- Reasons: none

### 2015

**dry** — Status: **PASS**
- Sensors: landsat-8 · scenes: 36
- Valid district coverage: 100.0% · reliable (≥3 clear obs): 100.0%
- Median clear observations per pixel: 23 · mean clear fraction of observations: 88.4%
- Permanent-water negative control (share of JRC permanent-water cells with MNDWI>0): n/a
- Residual-cloud check (valid pixels with blue SR > 0.15): 0.1%
- Reasons: none

### 2016

**dry** — Status: **PASS**
- Sensors: landsat-8 · scenes: 38
- Valid district coverage: 100.0% · reliable (≥3 clear obs): 100.0%
- Median clear observations per pixel: 23 · mean clear fraction of observations: 81.8%
- Permanent-water negative control (share of JRC permanent-water cells with MNDWI>0): n/a
- Residual-cloud check (valid pixels with blue SR > 0.15): 0.06%
- Reasons: none

### 2022

**dry** — Status: **PASS**
- Sensors: landsat-8 · scenes: 32
- Valid district coverage: 100.0% · reliable (≥3 clear obs): 100.0%
- Median clear observations per pixel: 19 · mean clear fraction of observations: 79.6%
- Permanent-water negative control (share of JRC permanent-water cells with MNDWI>0): n/a
- Residual-cloud check (valid pixels with blue SR > 0.15): 0.04%
- Reasons: none

### 2023

**dry** — Status: **PASS**
- Sensors: landsat-8 · scenes: 34
- Valid district coverage: 100.0% · reliable (≥3 clear obs): 100.0%
- Median clear observations per pixel: 22 · mean clear fraction of observations: 85.3%
- Permanent-water negative control (share of JRC permanent-water cells with MNDWI>0): n/a
- Residual-cloud check (valid pixels with blue SR > 0.15): 0.05%
- Reasons: none
