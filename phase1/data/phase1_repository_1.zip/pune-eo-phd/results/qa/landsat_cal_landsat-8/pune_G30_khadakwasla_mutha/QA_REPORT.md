# Pune EO Data QA Report — landsat_cal_landsat-8 — grid `pune_G30_khadakwasla_mutha`

Generated automatically by `pune-eo qa`. Thresholds: `configs/qa.yaml`. Every product's full QA record is
also written into its own `metadata.json` (`qa` block).

## Summary

| period   |   PASS |
|:---------|-------:|
| dry      |      5 |

## Per-year records

### 2014

**dry** — Status: **PASS**
- Sensors: landsat-8 · scenes: 8
- Valid district coverage: 100.0% · reliable (≥3 clear obs): 100.0%
- Median clear observations per pixel: 7 · mean clear fraction of observations: 86.0%
- Permanent-water negative control (share of JRC permanent-water cells with MNDWI>0): 100%
- Residual-cloud check (valid pixels with blue SR > 0.15): 0.03%
- Reasons: none

### 2015

**dry** — Status: **PASS**
- Sensors: landsat-8 · scenes: 10
- Valid district coverage: 100.0% · reliable (≥3 clear obs): 100.0%
- Median clear observations per pixel: 10 · mean clear fraction of observations: 94.3%
- Permanent-water negative control (share of JRC permanent-water cells with MNDWI>0): 100%
- Residual-cloud check (valid pixels with blue SR > 0.15): 0.03%
- Reasons: none

### 2016

**dry** — Status: **PASS**
- Sensors: landsat-8 · scenes: 10
- Valid district coverage: 100.0% · reliable (≥3 clear obs): 100.0%
- Median clear observations per pixel: 9 · mean clear fraction of observations: 85.7%
- Permanent-water negative control (share of JRC permanent-water cells with MNDWI>0): 100%
- Residual-cloud check (valid pixels with blue SR > 0.15): 0.01%
- Reasons: none

### 2022

**dry** — Status: **PASS**
- Sensors: landsat-8 · scenes: 8
- Valid district coverage: 100.0% · reliable (≥3 clear obs): 100.0%
- Median clear observations per pixel: 7 · mean clear fraction of observations: 86.3%
- Permanent-water negative control (share of JRC permanent-water cells with MNDWI>0): 100%
- Residual-cloud check (valid pixels with blue SR > 0.15): 0.02%
- Reasons: none

### 2023

**dry** — Status: **PASS**
- Sensors: landsat-8 · scenes: 9
- Valid district coverage: 100.0% · reliable (≥3 clear obs): 100.0%
- Median clear observations per pixel: 7 · mean clear fraction of observations: 79.3%
- Permanent-water negative control (share of JRC permanent-water cells with MNDWI>0): 100%
- Residual-cloud check (valid pixels with blue SR > 0.15): 0.03%
- Reasons: none
