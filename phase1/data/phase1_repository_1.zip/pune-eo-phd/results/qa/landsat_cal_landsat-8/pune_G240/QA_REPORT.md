# Pune EO Data QA Report — landsat_cal_landsat-8 — grid `pune_G240`

Generated automatically by `pune-eo qa`. Thresholds: `configs/qa.yaml`. Every product's full QA record is
also written into its own `metadata.json` (`qa` block).

## Summary

| period   |   PASS |
|:---------|-------:|
| dry      |      5 |

## Per-year records

### 2014

**dry** — Status: **PASS**
- Sensors: landsat-8 · scenes: 30
- Valid district coverage: 100.0% · reliable (≥3 clear obs): 100.0%
- Median clear observations per pixel: 8 · mean clear fraction of observations: 90.4%
- Permanent-water negative control (share of JRC permanent-water cells with MNDWI>0): 100%
- Residual-cloud check (valid pixels with blue SR > 0.15): 0.0%
- Reasons: none

### 2015

**dry** — Status: **PASS**
- Sensors: landsat-8 · scenes: 36
- Valid district coverage: 100.0% · reliable (≥3 clear obs): 100.0%
- Median clear observations per pixel: 9 · mean clear fraction of observations: 89.2%
- Permanent-water negative control (share of JRC permanent-water cells with MNDWI>0): 100%
- Residual-cloud check (valid pixels with blue SR > 0.15): 0.0%
- Reasons: none

### 2016

**dry** — Status: **PASS**
- Sensors: landsat-8 · scenes: 38
- Valid district coverage: 100.0% · reliable (≥3 clear obs): 100.0%
- Median clear observations per pixel: 9 · mean clear fraction of observations: 86.5%
- Permanent-water negative control (share of JRC permanent-water cells with MNDWI>0): 100%
- Residual-cloud check (valid pixels with blue SR > 0.15): 0.0%
- Reasons: none

### 2022

**dry** — Status: **PASS**
- Sensors: landsat-8 · scenes: 32
- Valid district coverage: 100.0% · reliable (≥3 clear obs): 100.0%
- Median clear observations per pixel: 7 · mean clear fraction of observations: 85.0%
- Permanent-water negative control (share of JRC permanent-water cells with MNDWI>0): 100%
- Residual-cloud check (valid pixels with blue SR > 0.15): 0.0%
- Reasons: none

### 2023

**dry** — Status: **PASS**
- Sensors: landsat-8 · scenes: 34
- Valid district coverage: 100.0% · reliable (≥3 clear obs): 100.0%
- Median clear observations per pixel: 8 · mean clear fraction of observations: 83.9%
- Permanent-water negative control (share of JRC permanent-water cells with MNDWI>0): 100%
- Residual-cloud check (valid pixels with blue SR > 0.15): 0.0%
- Reasons: none
