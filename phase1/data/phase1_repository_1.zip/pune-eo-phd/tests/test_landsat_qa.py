# SYNTHETIC TEST DATA — NOT RESEARCH DATA
import numpy as np
from pune_eo.preprocessing import landsat_qa as q

def test_clear_and_observed_bits():
    qa = np.array([21824, 1, 1 << 3, 1 << 4, 1 << 1, 1 << 2, 1 << 5, 1 << 7], np.uint16)  # 21824 = typical clear land
    clear = q.clear_mask(qa); obs = q.observed_mask(qa)
    assert clear.tolist() == [True, False, False, False, False, False, False, True]   # water bit 7 is not masked
    assert obs.tolist() == [True, False, True, True, True, True, True, True]

def test_decode_clips_negative_and_drops_saturation():
    dn = np.array([0, 7000, 7273, 43636, 43637], np.float32)
    r, nclip = q.decode_sr(dn)
    assert np.isnan(r[0]) and r[1] == 0.0 and nclip == 1
    assert abs(r[2] - 0.0) < 1e-4 and abs(r[3] - 1.0) < 1e-3 and np.isnan(r[4])

def test_block_all_conservative():
    m = np.ones((4, 4), bool); m[0, 0] = False
    out = q.block_all(m, 2)
    assert out.tolist() == [[False, True], [True, True]]
