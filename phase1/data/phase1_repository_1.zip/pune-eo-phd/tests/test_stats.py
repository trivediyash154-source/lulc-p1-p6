# SYNTHETIC TEST DATA — NOT RESEARCH DATA
import numpy as np
from pune_eo.compositing.stats import nanmedian0, robust_composite, linear_power_stats

def test_nanmedian_matches_numpy():
    rng = np.random.default_rng(1)
    a = rng.normal(size=(37, 20, 30)).astype(np.float32); a[rng.random(a.shape) < 0.5] = np.nan; a[:, 0, 0] = np.nan
    m, n = nanmedian0(a)
    with np.errstate(all="ignore"):
        import warnings; warnings.simplefilter("ignore")
        ref = np.nanmedian(a, axis=0)
    assert np.array_equal(np.isnan(m), np.isnan(ref))
    assert np.nanmax(np.abs(m - ref)) == 0
    assert n[0, 0] == 0

def test_robust_composite_counts_and_se():
    v = np.full((5, 1, 3), np.nan, np.float32)
    v[:, 0, 0] = [0.1, 0.2, 0.3, 0.4, 0.5]      # n=5
    v[:2, 0, 1] = [0.2, 0.4]                     # n=2 -> no SE
    med, se, n = robust_composite(v)
    assert np.isclose(med[0, 0], 0.3) and n[0, 0] == 5
    assert np.isclose(se[0, 0], 1.2533 * 1.4826 * 0.1 / np.sqrt(5), rtol=1e-5)
    assert np.isclose(med[0, 1], 0.3) and np.isnan(se[0, 1])
    assert np.isnan(med[0, 2]) and n[0, 2] == 0

def test_sar_mean_in_linear_domain():
    lin = np.array([[[0.01]], [[0.1]]], np.float32)   # -20 dB and -10 dB
    mean_db, med_db, std_db, n = linear_power_stats(lin)
    assert np.isclose(mean_db[0, 0], 10 * np.log10(0.055), atol=1e-4)   # NOT the dB average (-15)
    assert n[0, 0] == 2
