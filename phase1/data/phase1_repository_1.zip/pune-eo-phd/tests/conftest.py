"""All arrays generated in tests are SYNTHETIC TEST DATA — NOT RESEARCH DATA."""
