# SYNTHETIC TEST DATA — NOT RESEARCH DATA
import numpy as np
from pune_eo.validation.spatial_cv import spatial_block_folds, temporal_holdout, buffered_test_mask
from pune_eo.feature_engineering.indices import REGISTRY, compute

def test_spatial_blocks_never_split():
    rng = np.random.default_rng(3); x = rng.uniform(0, 10000, 2000); y = rng.uniform(0, 10000, 2000)
    f = spatial_block_folds(x, y, block_m=1000, k=5)
    blk = np.floor(x / 1000).astype(int) * 100 + np.floor(y / 1000).astype(int)
    for b in np.unique(blk):
        assert len(np.unique(f[blk == b])) == 1          # a block is entirely in one fold
    assert set(np.unique(f)) == set(range(5))

def test_temporal_and_buffer():
    tr, te = temporal_holdout(np.array([2010, 2015, 2020]), [2020])
    assert tr.tolist() == [True, True, False] and te.tolist() == [False, False, True]
    x = np.array([0., 50., 5000.]); y = np.zeros(3); test = np.array([True, False, False])
    keep = buffered_test_mask(x, y, test, buffer_m=100)
    assert keep.tolist() == [False, False, True]          # near neighbour of test sample dropped

def test_every_index_has_a_purpose_and_computes():
    d = {k: np.array([0.1, 0.3], np.float32) for k in ["blue", "green", "red", "nir08", "nir", "swir16", "swir22", "re1", "re3"]}
    d["nir"] = np.array([0.4, 0.5], np.float32); d["nir08"] = d["nir"]
    for name, spec in REGISTRY.items():
        assert spec["purpose"] and spec["sensors"]
        assert np.all(np.isfinite(compute(name, d)))
    assert np.isclose(compute("NDVI", d)[0], (0.4 - 0.1) / (0.4 + 0.1))
