# SYNTHETIC TEST DATA — NOT RESEARCH DATA
import tempfile, pathlib
import numpy as np, pandas as pd, pytest
from pune_eo.harmonization import landsat as h
from pune_eo.jobs import JobLedger, JobLocked
from pune_eo.compositing.periods import standard_periods

def test_identity_and_literature_transform():
    x = {"red": np.array([0.1], np.float32)}
    assert h.apply(x, "landsat-7", "none")["red"][0] == np.float32(0.1)
    y = h.apply(x, "landsat-7", "roy2016_ols")["red"][0]
    assert np.isclose(y, 0.1 * 0.9047 + 0.0061)
    assert h.apply(x, "landsat-8", "roy2016_ols")["red"][0] == np.float32(0.1)   # OLI is the reference

def test_ledger_resume_and_lock():
    d = pathlib.Path(tempfile.mkdtemp()); out = d / "o.tif"; out.write_text("x")
    L = JobLedger(d / "l.json"); L.start("a/1", "v1"); L.done("a/1", [out])
    assert JobLedger(d / "l.json").is_done("a/1", "v1")
    assert not JobLedger(d / "l.json").is_done("a/1", "v2")          # config change -> reprocess
    out.unlink(); assert not JobLedger(d / "l.json").is_done("a/1", "v1")   # missing output -> reprocess
    L.start("a/2", "v1")
    with pytest.raises(JobLocked):
        JobLedger(d / "l.json").start("a/2", "v1")

def test_seasons_partition_year_and_partial():
    ps = standard_periods(2026)
    seasons = [p for p in ps if p.kind == "season"]
    months = sorted(m for p in seasons for m in p.months)
    assert months == list(range(1, 13))
    cutoff = pd.Timestamp("2026-10-01", tz="UTC")
    st = {p.name: p.complete(cutoff) for p in ps}
    assert st["dry"] and st["wet"] and not st["post_monsoon"] and not st["annual"]
