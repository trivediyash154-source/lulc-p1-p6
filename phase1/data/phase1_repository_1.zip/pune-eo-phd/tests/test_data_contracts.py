"""Contract tests on REAL manifests/products (skipped if the data have not been built)."""
import json, pathlib
import pytest
from pune_eo import config
from pune_eo.acquisition.manifest import SCHEMA

MAN = config.path("data", "manifests")

@pytest.mark.parametrize("name", ["landsat", "sentinel2", "sentinel1"])
def test_manifest_schema(name):
    p = MAN / f"{name}_manifest.parquet"
    if not p.exists(): pytest.skip("manifest not built")
    import geopandas as gpd
    g = gpd.read_parquet(p)
    assert set(SCHEMA) <= set(g.columns)
    assert g.loc[g.selected, "exclusion_reason"].isna().all()
    assert g.loc[~g.selected, "exclusion_reason"].notna().all()
    assert g.product_id.is_unique
    assert (g.district_overlap_fraction.between(0, 1.0001)).all()

def test_study_area_contract():
    m = config.path("data", "boundary", "study_area.metadata.json")
    if not m.exists(): pytest.skip("boundary not built")
    d = json.loads(m.read_text())
    assert d["geometry_repair"]["valid_after"] and abs(d["diff_vs_official_pct"]) < 1.0

def test_products_on_grid():
    metas = sorted(config.path("data", "composites").glob("pune_G240/*/landsat/annual/metadata.json"))
    if not metas: pytest.skip("no products yet")
    import rasterio
    checked = 0
    for m in metas[:5]:
        d = json.loads(m.read_text())
        for f in d["files"].values():
            if not (config.ROOT / f["path"]).exists():
                continue                      # metadata-only checkout (rasters regenerated via the CLI)
            checked += 1
            with rasterio.open(config.ROOT / f["path"]) as s:
                assert (s.height, s.width) == (d["grid"]["height"], d["grid"]["width"])
                assert list(s.transform)[:6] == pytest.approx(d["grid"]["transform"])
    if checked == 0: pytest.skip("rasters not present (metadata-only package)")


def test_product_ids_unique():
    metas = list(config.path("data", "composites").glob("**/metadata.json"))
    if not metas: pytest.skip("no products yet")
    ids = [json.loads(m.read_text()).get("product_id") for m in metas]
    ids = [i for i in ids if i]
    assert len(ids) == len(set(ids))
