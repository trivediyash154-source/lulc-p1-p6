# SYNTHETIC TEST DATA — NOT RESEARCH DATA
import numpy as np
from pune_eo.preprocessing import s2_scl
from pune_eo.grid import Grid

def test_processing_baseline_offset():
    dn = np.array([0, 1000, 2000], np.uint16)
    old = s2_scl.decode(dn, "03.01"); new = s2_scl.decode(dn, "05.10")
    assert np.isnan(old[0]) and np.isclose(old[2], 0.2)
    assert np.isnan(new[0]) and np.isclose(new[1], 0.0) and np.isclose(new[2], 0.1)

def test_scl_mask():
    scl = np.array([0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11], np.uint8)
    assert s2_scl.clear_mask(scl).tolist() == [False, False, True, False, True, True, True, True, False, False, False, False]

def test_grid_lattice_and_nesting():
    g30 = Grid("g30", "EPSG:32643", 30, 322065.0, 2146035.0, 100, 80, 15)
    assert g30.on_lattice(322065.0 + 30 * 7, 2146035.0 - 30 * 3)
    g240 = Grid("g240", "EPSG:32643", 240, 322065.0, 2146035.0, 10, 10, 15)
    f = g240.refine(8, "f")
    assert f.res == 30 and f.width == 80 and f.x0 == g240.x0
    w = g30.window((322065.0 + 31, 2146035.0 - 95, 322065.0 + 89, 2146035.0 - 1))
    assert (w.col_off, w.row_off, w.width, w.height) == (1, 0, 2, 4)   # snapped outward
    # G10 corners (0 mod 10) are NOT on the G30 lattice (15 mod 30): verified offset 5 m
    assert not g30.on_lattice(300000.0, 2000000.0)
