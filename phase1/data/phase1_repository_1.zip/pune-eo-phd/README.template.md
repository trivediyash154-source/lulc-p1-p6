# pune-eo-phd — Multi-decadal Earth Observation infrastructure for Pune District

A reproducible research data system for the **entire Pune District, Maharashtra (15,650 km²)**,
1990–2026: real satellite archive → manifests → QA → harmonisation → fixed-grid temporal cube →
(next) features, change, coupled systems, ML, uncertainty, hindcast, scenarios, digital twin.

> **Status (first milestone — data foundation).** Built and executed on real data in this repo:
> boundary, grids, complete acquisition manifests, evidence-based sensor harmonisation, a resumable
> compositing engine, every-year Landsat products 1990–2026 (district benchmark grid), full-resolution
> 30 m products for a named window (all 37 years), Sentinel-1 monthly products 2015–2026, Sentinel-2
> monthly products 2018–2026, 10 m field-scale Sentinel-2 (2024) for an irrigated window, a CHIRPS rainfall driver 1990–2026, a harmonisation stability test, flood-event
> checks, a stratified reference-sample design, automated QA, figures and tests. **No model, map classification, accuracy value or
> scenario exists yet — none is claimed.**

## 1. Why not four snapshots
See `docs/methodology.md §0`. In short: 10-year gaps hide transition timing; unharmonised sensors
fake trends (the L7→L8 switch alone moves NDVI by −0.047 here); and without per-pixel observation
counts, uncertainty and provenance, a composite is a picture, not a measurement.

## 2. Temporal architecture
| Scale | Years | Products |
|---|---|---|
| Long-term | **every year 1990–2026** | annual, dry (Jan–May), wet (Jun–Sep), post-monsoon (Oct–Dec): composite, uncertainty, observation count, valid mask, per-pixel QA (incl. per-sensor counts, temporal support), metadata |
| Dense modern | S2 2018+, S1 2015+ | monthly + seasonal + annual |
| Events | per cited event | Sentinel-1 pre / during / post (only if the satellite actually imaged the event) |

2026 is a **partial year**: products whose period extends past the archive cut-off carry `complete=false`.
Real satellite history: `results/figures/satellite_availability_timeline.png`, `docs/archive_findings.md`.

## 3. Product layout
```
data/composites/<grid_id>/<YEAR>/
  landsat/annual/  landsat/seasonal/{dry,wet,post_monsoon}/
  sentinel2/{annual,seasonal/*,monthly/YYYY-MM}/      sentinel1/{…, events/<id>/}
  metadata/<family>_year_summary.json
each period dir: optical_composite.tif  uncertainty.tif  observation_count.tif  valid_mask.tif  qa.tif  metadata.json
```
Grids: **G30** = native Landsat lattice (no resampling) · **G10/G20** = native Sentinel lattice ·
**G240** = 8×G30 district benchmark (diagnostic only). Details: `docs/architecture.md`, `docs/data_dictionary.md`.

## 4. Run it in VS Code (macOS / Linux)
1. **Install** (conda-forge is the most reliable way to get GDAL on a Mac):
   ```bash
   conda env create -f environment.yml && conda activate pune-eo
   # or: python3.12 -m venv .venv && source .venv/bin/activate && pip install -e ".[dev]"
   ```
2. **Open the folder** in VS Code → `Python: Select Interpreter` → the `pune-eo` env (or `.venv`).
3. **Credentials:** `cp .env.example .env`. Nothing is required for the default backend
   (Planetary Computer is anonymous). Check: `python -m pune_eo auth-check`.
4. **Run the pipeline** — Terminal ▸ Run Task (`.vscode/tasks.json`) in order, or the debugger configs in
   `.vscode/launch.json`, or the CLI:
   ```bash
   python -m pune_eo boundary          # study area: download, validate, version, save geojson/gpkg/shp
   python -m pune_eo grid              # grids + native-lattice evidence
   python -m pune_eo discover          # Landsat / Sentinel-2 / Sentinel-1 manifests (GeoParquet)
   python -m pune_eo coverage && python -m pune_eo timeline
   python -m pune_eo harmonize --grid G240       # overlap composites + held-out calibration
   python -m pune_eo composite --family landsat --grid G240 --years 1990-2026     # resumable
   python -m pune_eo composite --family landsat --grid G30 --window khadakwasla_mutha --years 1990-2026
   python -m pune_eo composite --family sentinel2 --grid G240 --years 2018-2026
   python -m pune_eo composite --family sentinel1 --grid G240 --years 2015-2026
   python -m pune_eo event pune_2024_07_25
   python -m pune_eo climate                     # CHIRPS monthly rainfall, area-weighted district mean
   python -m pune_eo sample-design               # stratified reference points (labels empty) -> KML for Google Earth Pro
   python -m pune_eo qa --grid-id pune_G240 && python -m pune_eo figures
   python -m pune_eo status            # done / failed / pending jobs
   python -m pytest -q
   ```
5. **Interrupt any time.** Re-running the same command skips finished years, reuses cached
   observations of an interrupted year, and refuses to run a job another process holds.
6. **Full 30 m district:** `python -m pune_eo gee-export --years 1990-2026 --grid G30` (plan) and
   `--submit` once `GEE_PROJECT` is set and `earthengine authenticate` has been run; or run
   `composite --grid G30` on a workstation/cloud VM.

Typical runtimes (2-core sandbox): G240 Landsat 45–150 s/year; G30 window 20–40 s/year; S2 G240 one year ≈ 4 min.

## 5. Benchmark executed in this build (real data)
{{RESULTS}}

## 6. Repository map
```
configs/   study_area, grid, temporal, landsat, sentinel1, sentinel2, dem, climate, reference, events, qa, aois
docs/      research_questions, hypotheses, methodology, architecture, data_dictionary, validation,
           experiment_protocol, reproducibility, archive_findings, roadmap
src/pune_eo/
  acquisition/     boundary, stac, manifest, coverage, reference, climate, auth, gee_backend
  preprocessing/   landsat_qa, s2_scl, sar
  harmonization/   landsat (transforms), calibrate (held-out fitting + decision rule)
  compositing/     reader, observations, engine, stats, periods, windows
  qa/              checks, report          flood/  s1_event
  feature_engineering/ indices (each with a stated purpose)   validation/ spatial_cv, sample_design
  visualization/   style, cartography, timeline, figures
  classification/ change_detection/ agriculture/ water/ urban/ stress/ modelling/ uncertainty/  ← milestone scaffolds
scripts/   discover_all, run_calibration, run_landsat_cube, run_sentinel, harmonization_stability,
           build_inventory, make_data_dictionary, fill_readme
notebooks/ 01_explore_cube.ipynb (opens real products, traces a pixel to its scenes)
tests/     unit tests (SYNTHETIC TEST DATA — NOT RESEARCH DATA) + data-contract tests on real manifests
```

## 7. Not done yet (explicitly)
- Full-resolution (30 m) district cube for all years — pipeline ready; needs workstation/cloud/GEE.
- Sentinel dense products at 10/20 m district-wide (built at 240 m benchmark); S1 GRD→RTC for missing 2025 frames.
- Reference samples, LULC classification, change trajectories, agriculture/water/urban/stress
  modules, ML, hindcast, scenarios, digital twin.
- External data: flood-line vectors (2011/2017/MERI 2025), command areas, dam releases, IMD rainfall, groundwater (see `docs/roadmap.md`).
- Labels: the reference sample is designed (1,345 points) but **not interpreted** — no accuracy can be reported until it is.
