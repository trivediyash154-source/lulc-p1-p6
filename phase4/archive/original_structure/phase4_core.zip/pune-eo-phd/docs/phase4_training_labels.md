# Phase 4 — training-label and validation-label audit

_From `scripts/phase4_label_audit.py` -> `data/inventory/label_audit.json`._

## 1. Training labels (silver L1)

Definition: a 30 m cell is labelled only if ESA WorldCover 2020, 2021 and Esri 2020, 2021 agree unanimously with purity >= 0.78. Valid for 2020-2021 only.

| window | labelled share of cells | built | agriculture | natural veg. | water | share of WorldCover-class cells that get a silver label (built/agri/natveg/water) |
|---|---|---|---|---|---|---|
| khadakwasla_mutha | 0.39 | 64695 | 2069 | 73244 | 5569 | 0.49 / 0.08 / 0.36 / 0.89 |
| baramati_agri | 0.41 | 11244 | 85821 | 98 | 174 | 0.49 / 0.55 / 0.00 / 0.41 |
| mulshi_ghats | 0.80 | 393 | 6759 | 272536 | 38850 | 0.22 / 0.19 / 0.87 / 0.83 |

## 2. Easy-cell bias

| window | edge-cell share silver / unlabelled | local SD of dry NDVI silver / unlabelled | WorldCover purity silver / unlabelled |
|---|---|---|---|
| khadakwasla_mutha | 0.22 / 0.72 | 0.033 / 0.046 | 1.00 / 0.89 |
| baramati_agri | 0.25 / 0.65 | 0.043 / 0.042 | 1.00 / 1.00 |
| mulshi_ghats | 0.07 / 0.68 | 0.044 / 0.043 | 1.00 / 1.00 |

Silver cells are interior cells: only 7-25 % sit on a class boundary versus 65-72 % of unlabelled cells. The model is trained and (in Phases 2-3) tested on the cells that are easiest by construction; boundary, mixed and transitional cells — where land-cover change actually happens — are almost absent. Class support is lopsided: corridor agriculture gets a silver label in only 8 % of its WorldCover cells (2 069 cells), Baramati natural vegetation has 98 cells, Mulshi built-up 393.

## 3. Spatial autocorrelation vs the 3 km blocks

| window | lag (m) where indicator correlation first drops below 0.1: built / agri / natveg / water |
|---|---|
| khadakwasla_mutha | 4000 / 600 / 3000 / 1500 |
| baramati_agri | 2000 / 3000 / 1500 / 300 |
| mulshi_ghats | 300 / 1000 / 2000 / 3000 |

Class patterns stay correlated beyond 3 km for several class-window pairs (built-up in the corridor up to ~4 km). Train and test blocks are therefore not fully independent for those classes; within-window scores are optimistic. Leave-one-region-out and district-wide independent validation are required for generalisation claims.

## 4. Temporal mismatch

* silver valid for 2020-2021 only; models trained on 2021 (C group 2020+2021); Tier-D multi-year extension along PELT change-free segments (training only)
* applying 2021 labels to 1990-2019 features assumes no change and no sensor shift - a candidate cause of the historical failure (associated with it in Phase 3, not tested confirmatorily)
* silver cells capped per class and split (train 2500 / val 1500 / test 3000 per window) - balanced sample, NOT the population

## 5. Is the model learning the reference products?

| evidence (Tier C, provisional AI 2021) | value |
|---|---|
| model vs AI agreement on silver points | 0.918 |
| model vs AI agreement on no silver points | 0.758 |
| silver l1 vs AI macro f1 | 0.944 |
| worldcover vs AI on no silver points | 0.443 |
| esri vs AI on no silver points | 0.871 |
| AI abstention by stratum | {'agriculture': 0.358, 'built_up': 0.108, 'natural_vegetation': 0.238, 'no_silver_label': 0.375, 'water': 0.008} |

Agreement with an independent visual reading falls from 0.92 on cells where the four products agree to 0.76 where they do not, and WorldCover itself agrees with the visual reading on only 0.44 of the no-consensus points. This is consistent with a model that has learned the products' consensus on easy cells; it does not show it has learned land cover where the products disagree. (Tier C; to be re-tested against human gold.)

## 6. Validation labels

| tier | what exists | what it can validate |
|---|---|---|
| A (human) | 0 points | nothing yet |
| B (independent products) | WSF-Evolution 1985-2015 (30 m), GHSL BUILT-S 1990-2020 5-yearly (90/100 m), JRC GSW 1984-2021 — in the 3 windows only | built-up and water history; NOT agriculture or natural vegetation |
| C (silver / provisional AI) | silver 2020-21 (easy cells); 437 AI-labelled 2021 points (S2-based, shares evidence with WorldCover/Esri) | 2020-21 agreement only |

No epoch other than 2020-2021 has any reference for agriculture or natural vegetation. Historical reconstruction of those classes is currently unvalidatable.

## 7. Consequences for Phase 4 labels

1. Separate training labels from validation labels physically (different points, different blocks, different people where possible).
2. Every training label carries provenance (source, epoch, purity, interpreter) — no blind merging.
3. Training must include boundary/mixed/transitional cells (human or VHR-interpreted), not only consensus interiors.
4. Label-quality experiment (A single-year silver, B multi-year silver, C independently validated, D human gold, E gold + filtered silver) needs human labels for C-E; A-B can run now as exploratory.
