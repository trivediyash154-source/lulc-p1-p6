# Phase 4 — coupled land-water-agriculture-urban analysis

**Not started, by design.** The coupled analysis needs reliable individual products (G5-G7) at district scale (G9). None of these gates is passed.

Planned design once prerequisites exist: taluka-level panel 1990-2026 of built-up, agriculture, natural vegetation, surface water, rainfall (CHIRPS/IMD), population (census/GHS-POP, noting GHS-POP is modelled from built-up); panel regressions with fixed effects and spatial autocorrelation diagnostics; all results reported as associations. Missing inputs: taluka boundaries, census tables, roads (OSM), reservoir storage.
