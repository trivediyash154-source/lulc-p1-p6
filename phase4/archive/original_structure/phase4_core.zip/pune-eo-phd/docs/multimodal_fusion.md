# Multimodal fusion (Phase 3, groups C, E5, I1, M2)

All C models: XGBoost with identical hyperparameters and seed, trained on silver TRAIN-block cells x {2020, 2021}, early stopping on VAL blocks; 'unseen' = leave-one-window-out on all HET silver cells (class-capped sample) of the held-out window (2021). Agreement with silver (Tier C) — not accuracy.

## C1-C5 ablation (S1 era)

| id | features | within 2021 | within 2020 | unseen khadakwasla_mutha | unseen baramati_agri | unseen mulshi_ghats | vs C1 (unseen, paired block bootstrap) | status |
|---|---|---|---|---|---|---|---|---|
| P3-C1 | optical (B3) | 0.959 | 0.967 | 0.776 | 0.755 | 0.680 | reference | PASS / NA |
| P3-C2 | SAR only | 0.844 | 0.833 | 0.727 | 0.541 | 0.613 | khada -0.050 [-0.079, -0.029]; baram -0.213 [-0.265, -0.178]; mulsh -0.067 [-0.098, -0.048] | PASS / NOT_SUPPORTED |
| P3-C3 | optical + SAR | 0.973 | 0.978 | 0.839 | 0.806 | 0.712 | khada +0.062 [+0.050, +0.078]; baram +0.052 [+0.033, +0.066]; mulsh +0.032 [+0.018, +0.053] | PASS / SUPPORTED |
| P3-C4 | + terrain | 0.986 | 0.988 | 0.902 | 0.893 | 0.731 | khada +0.126 [+0.087, +0.160]; baram +0.138 [+0.073, +0.159]; mulsh +0.051 [+0.035, +0.074] | PASS / SUPPORTED |
| P3-C5 | + SPI-12, CHIRPS mean | 0.988 | 0.990 | 0.920 | 0.891 | 0.758 | khada +0.144 [+0.108, +0.175]; baram +0.136 [+0.068, +0.161]; mulsh +0.077 [+0.060, +0.101] | PASS / SUPPORTED |

**Gate 3 (S1 raises unseen macro-F1 >= 0.02, CI excluding 0, in >= 2 of 3 windows): PASSED.** SAR alone (C2) is clearly worse than optical; SAR added to optical (C3) helps in every held-out window; terrain (C4) adds more than SAR in Baramati, about as much in the corridor and less in Mulshi. These are S1-era (2017-2025) results only — SAR cannot help before 2015.

Per-class unseen F1 (C1 -> C3 -> C4): khadakwasla_mutha: built_up 0.96->0.98->0.98, agriculture 0.47->0.58->0.73, natural_vegetation 0.68->0.79->0.90; baramati_agri: built_up 0.96->0.99->0.99, agriculture 0.91->0.97->0.99, natural_vegetation 0.15->0.27->0.60; mulshi_ghats: built_up 0.17->0.24->0.23, agriculture 0.76->0.80->0.87, natural_vegetation 0.81->0.82->0.85. Mulshi built-up (small rural settlements, few silver cells) and Baramati natural vegetation (94 silver cells) stay poor in every configuration: the macro-F1 of a held-out window is driven by its rarest classes.

## Drought in the S1 era

Only ONE SPI-dry year exists in the S1 era (2019, khadakwasla_mutha). The C-model dry/normal contrasts in `results/phase3/climate/climate_summary.json` are descriptive; no SAR drought-robustness claim is made.

## Multimodal-temporal model (Gate 4)

a multimodal-temporal model (B4 5-year Landsat sequence + S1 annual features + terrain, 2021) beats the Landsat single-date baseline (B1) on held-out-window macro-F1 in all 3 windows (Gate 4)

| held-out window | B4 + S1 + terrain | B1 single-date | difference (paired block bootstrap) |
|---|---|---|---|
| khadakwasla_mutha | 0.922 | 0.789 | +0.134 [+0.096, +0.166] |
| baramati_agri | 0.872 | 0.703 | +0.169 [+0.100, +0.203] |
| mulshi_ghats | 0.776 | 0.622 | +0.154 [+0.123, +0.199] |

**Gate 4: PASSED** (2021, S1 era only; registered as P3-E5 before the transfer run).

## Sensor harmonisation generalisation (P3-I1)

Same-day Landsat-8/9 + S2 pairs per window: {'baramati_agri': 10, 'khadakwasla_mutha': 9, 'mulshi_ghats': 4} (corridor pairs partly overlap the 19 fitting pairs). Median residual of s2_to_oli_v1(S2) - Landsat:

| window | blue | green | red | nir08 | swir16 | swir22 | ndvi |
|---|---|---|---|---|---|---|---|
| baramati_agri | -0.0076 | -0.0082 | -0.0096 | -0.0249 | -0.0239 | -0.0210 | -0.0036 |
| khadakwasla_mutha | +0.0017 | +0.0019 | +0.0011 | -0.0022 | -0.0018 | -0.0010 | -0.0090 |
| mulshi_ghats | +0.0052 | +0.0054 | +0.0040 | -0.0031 | -0.0003 | -0.0007 | -0.0347 |

Share of window x stratum residuals with |bias| < 0.01 (n >= 1000 px): {'silver_class': 0.8333333333333334, 'month': 0.7111111111111111, 'year': 0.8125}. Leave-one-window-out refit does not remove the Baramati bias (NIR/SWIR about -0.02), so it is landscape-specific, not a corridor-fit artefact. Outcome PASS / NOT_SUPPORTED: **the corridor transform must not be assumed sufficient**; Landsat+S2 fusion outside the corridor carries a reflectance bias of up to ~0.025 (NIR/SWIR) and an NDVI bias down to -0.035 (Mulshi, 4 pairs only).

## 10 m vs 30 m separability of cropping regimes (P3-M2)

Baramati agriculture silver cells, monthly S2 NDVI 2021 (months [1, 2, 3, 4, 5, 9, 10, 11, 12]), n = 3000. Silhouette (k = 2..6):

| features | k=2 | k=3 | k=4 | k=5 | k=6 |
|---|---|---|---|---|---|
| 30m_ndvi | 0.216 | 0.176 | 0.177 | 0.176 | 0.173 |
| 10m_ndvi | 0.224 | 0.183 | 0.186 | 0.186 | 0.181 |
| 30m_ndvi+s1vh | 0.174 | 0.130 | 0.130 | 0.118 | 0.111 |
| 10m_ndvi+s1vh | 0.181 | 0.138 | 0.140 | 0.131 | 0.122 |

All silhouettes are low (< 0.25: no well-separated regimes); 10 m is higher than 30 m by < 0.01 and adding S1 VH lowers separability. Outcome PASS / NOT_SUPPORTED — a negative result. Clusters are not crop types.

