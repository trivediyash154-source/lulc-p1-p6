# Phase 4 — thesis paper structure (retained only where evidence supports it)

| paper | focus | evidence now | missing | status |
|---|---|---|---|---|
| 1 Reliable multi-decadal land-cover reconstruction under sensor and landscape shift | multi-year labels, temporal context, harmonisation, independent validation | Phase 3: multi-year labels -39 to -41 % early false built-up; temporal context -49 %; P4-E1 sensor residuals; product benchmark shows a wide historical envelope | Tier-A historical gold; district cube; P4-C1..C3 | RETAINED (core); confirmatory evidence pending |
| 2 Uncertainty-aware spatial transfer of multimodal EO models | SAR, optical, terrain, domain shift, calibration, third-landscape calibration, abstention | Phase 3 (3 windows): SAR/terrain gains on unseen windows; source-calibrated conformal fails; third-landscape calibration restores coverage | district regions, gold-based calibration (P4-C4..C6) | RETAINED (strong candidate) |
| 3 Coupled land-water-agriculture-urban transformation of Pune District | district-scale evidence | existing-product benchmark only | reliable products (G5-G9), water/agri data, admin and census layers | ON HOLD - not supported yet |

A possible methods note independent of our models: 'How much do global products disagree on historical built-up in a fast-growing Indian district?' (P4-X1: up to 4x in area; F1 0.32-0.43 in 1990) — publishable as a short benchmark once gold quantifies which product is closest.
