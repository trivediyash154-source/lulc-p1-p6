# Phase 4 — gold results

## Status: no human interpretation has been done (0 Tier-A labels). Gate G2 FAIL.

This environment has no human interpreter and no Google Earth Pro historical imagery. No AI or product-derived labels were created as gold.

## What is ready (design v2, protocol v2)

* District design: 641 points in 125 independent 6 km validation blocks; frame = validation blocks minus the three Phase-3 windows + 2 km (25% of the district; validation blocks are 29.0% of blocks, 26.7% of district area); at most 4 points per stratum per block; seed 20261111.
* Allocation drawn: product disagreement 2020 134, rainfed dry agriculture 107, reservoir margin le1km 65, irrigated agriculture 55, forest natveg hilly slope ge8 54, peri urban transforming 2001 2021 53, river corridor le300m 51, urban core settled by 2000 30, built consensus other 30, natveg open plateau 30, water permanent 30, bare sparse other 1, residual 1.
* Regions (leave-one-region-out): {'transition_700_1200mm': 260, 'wet_west_ge1200mm': 191, 'dry_east_lt700mm': 190}.
* Double-interpretation subset: 160 points (25%).
* Training eligibility: only cells >= 2 km from any validation block may be used for training/tuning (`sampling_design/training_eligible_30m.tif`); every gold point is >= 2 km from training-eligible cells.
* Blind forms `blind/form_interpreter_A.csv` (all points) and `form_interpreter_B.csv` (double subset, re-shuffled), KML with 30 m cell squares; key in `_key/` (evaluator only; it is tracked in git, so blindness depends on process: interpreters must receive only the `blind/` folder).
* Design v1 (672 points) was superseded before any interpretation (`v1_superseded/README.txt`): no buffer from training areas, 38 points inside the Phase-3 windows (24 in Phase-3 train blocks), up to 20 points per block, tiny strata over-allocated.
* Stratum caveats: 'river_corridor_le300m' also captures ponds and tanks; the bare/sparse and residual strata are tiny (<= 5 points each, reported, not padded).

## Next

Interpreter A: 2020 for all points, then 2000; interpreter B: the same epochs for the double subset; then adjudication. About 3204 interpretations for 4 epochs, roughly 53-106 interpreter-hours at 1-2 minutes each (`docs/phase4_gold_protocol.md`).
