# Temporal AI (Phase 3: B, F, G)

Order followed: single-date RF -> multi-date RF -> temporal features (B group) -> deep temporal models only because P3-B4 beat P3-B1 (pre-declared condition) -> self-supervision.

## Tree models on temporal features

See `docs/historical_reconstruction.md`: B4 (5-year window) lowers pooled dry-year false built-up by 49 % vs B1 with a small built-recall drop (-0.011, CI excluding 0); multi-year (Tier D) training labels lower it further.

## Deep temporal classifiers on the B4 sequence (P3-F1..F3)

| id | model | silver 2021 | dry FBR model vs RF-B4 (paired) | unseen macro-F1 (model / RF-B4) | status |
|---|---|---|---|---|---|
| P3-F1 | TempCNN | 0.977 | 0.118 vs 0.140: -0.022 [-0.045, -0.002] | khada 0.899/0.800; baram 0.770/0.787; mulsh 0.766/0.723 | PASS / SUPPORTED |
| P3-F2 | GRU | 0.976 | 0.105 vs 0.140: -0.034 [-0.069, -0.010] | khada 0.907/0.800; baram 0.815/0.787; mulsh 0.745/0.723 | PASS / SUPPORTED |
| P3-F3 | Transformer | 0.982 | 0.046 vs 0.140: -0.094 [-0.160, -0.041] | khada 0.939/0.800; baram 0.806/0.787; mulsh 0.759/0.723 | PASS / SUPPORTED |

## Self-supervised pretraining (P3-G1..G3)

Masked autoencoder (40 % of observed years hidden) over 37-year annual sequences; probe/fine-tune on the year-2021 token. Pretraining never sees TEST blocks; LOWO pretraining never sees the target window.

| labels | n | G1 scratch | G2 linear probe | G3 fine-tune | XGBoost B3T | G3 - G1 (paired) |
|---|---|---|---|---|---|---|
| 10% | 2722 | 0.968 | 0.862 | 0.978 | 0.963 | +0.010 [+0.005, +0.016] |
| 25% | 6804 | 0.977 | 0.933 | 0.979 | 0.968 | +0.002 [-0.001, +0.005] |
| 50% | 13608 | 0.979 | 0.948 | 0.982 | 0.971 | +0.004 [+0.002, +0.006] |
| 100% | 27216 | 0.983 | 0.957 | 0.985 | 0.978 | +0.002 [+0.001, +0.004] |

| held-out window | labels | G1 | G2 | G3 | XGBoost | G3 - G1 (paired) |
|---|---|---|---|---|---|---|
| khadakwasla_mutha | 10% | 0.767 | 0.766 | 0.801 | 0.826 | +0.035 [+0.021, +0.051] |
| khadakwasla_mutha | 25% | 0.824 | 0.734 | 0.876 | 0.843 | +0.052 [+0.042, +0.064] |
| khadakwasla_mutha | 100% | 0.953 | 0.781 | 0.956 | 0.864 | +0.002 [-0.007, +0.012] |
| baramati_agri | 10% | 0.702 | 0.686 | 0.700 | 0.796 | -0.003 [-0.028, +0.020] |
| baramati_agri | 25% | 0.762 | 0.684 | 0.803 | 0.806 | +0.041 [+0.000, +0.088] |
| baramati_agri | 100% | 0.736 | 0.743 | 0.752 | 0.780 | +0.016 [+0.009, +0.027] |
| mulshi_ghats | 10% | 0.642 | 0.549 | 0.652 | 0.631 | +0.009 [-0.002, +0.027] |
| mulshi_ghats | 25% | 0.679 | 0.614 | 0.718 | 0.668 | +0.039 [+0.027, +0.057] |
| mulshi_ghats | 100% | 0.671 | 0.663 | 0.737 | 0.693 | +0.066 [+0.049, +0.094] |

Outcomes: P3-G1 PASS / NA, P3-G2 PASS / NOT_SUPPORTED, P3-G3 PASS / INCONCLUSIVE. One seed per setting.

