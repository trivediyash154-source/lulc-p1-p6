# Phase 4 — agriculture

* Crop type: **not produced** — no crop-type labels exist; none will be manufactured.
* Established so far (Phase 3, Baramati/3 windows): agricultural state layers tagged OBSERVED / INFERRED / PROXY; 10 m vs 30 m cropping-regime separability NOT supported (silhouette < 0.25); official statistics exist only as district totals (c. 2005).
* District-scale agricultural land, crop presence, seasonality and cropping-intensity proxies require the district cube (S2/S1 seasonal stacks).
* Irrigation: only proxies (dry-season greenness on cropland; GLC_FCS30D irrigated vs rainfed cropland is a product label, not truth).
* If independent crop labels are obtained (field surveys, state crop-cutting locations), S1+S2 temporal fusion becomes testable.
