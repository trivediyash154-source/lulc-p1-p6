# Phase 4 — data inventory

_Generated from the repository files by `scripts/phase4_inventory.py` (machine-readable: `data/inventory/`). Inventory date 2026-10-02T12:13:30Z._

## 1. Scale of what exists

| item | value |
|---|---|
| Pune District area | 15650 km² |
| 30 m analysis-ready area (3 benchmark windows) | 903 km² = **5.8 % of the district** |
| district-wide 30 m cube | **not built** |
| district-wide data | 240 m benchmark grid (G240) composites — metadata for all products, rasters for only a minority (section 4) |
| Landsat scenes (selected / discovered) | 2685 / 4291 (1989-2026) |
| Sentinel-2 scenes | 3526 / 7953 (2015-2026; dense from 2018) |
| Sentinel-1 scenes | 884 / 1049 (2015-2026) |
| composite products (metadata) | 1543 (520 metadata-only: rasters deleted) |
| human-labelled (Tier A) points | **0** |
| provisional AI labels (Tier C, 2021) | 437 |

## 2. Landsat temporal coverage (district)

Scenes = selected Landsat scenes intersecting the district. Clear obs = median number of clear observations per pixel in the district G240 seasonal composite (dry Jan-May / post-monsoon Oct-Dec / wet Jun-Sep). ≥3-obs = share of the district with at least three clear observations.

| year | platform:scenes | dry | post | wet | clear obs dry/post/wet | ≥3-obs share dry/post/wet |
|---|---|---|---|---|---|---|
| 1989 | 5:6 | 0 | 6 | 0 | — | — |
| 1990 | 5:22 | 16 | 2 | 4 | 6 / 1 / 0 | 0.96 / 0.00 / 0.00 |
| 1991 | 5:30 | 20 | 10 | 0 | 4 / 2 / 0 | 1.00 / 0.30 / 0.00 |
| 1992 | 5:41 | 24 | 12 | 5 | 5 / 2 / 0 | 1.00 / 0.24 / 0.00 |
| 1993 | 5:45 | 25 | 14 | 6 | 6 / 2 / 0 | 1.00 / 0.35 / 0.05 |
| 1994 | 5:45 | 21 | 14 | 10 | 5 / 2 / 1 | 1.00 / 0.28 / 0.16 |
| 1995 | 5:26 | 17 | 9 | 0 | 3 / 2 / 0 | 0.51 / 0.19 / 0.00 |
| 1996 | 5:42 | 23 | 11 | 8 | 5 / 4 / 0 | 1.00 / 0.92 / 0.02 |
| 1997 | 5:21 | 8 | 5 | 8 | 2 / 2 / 1 | 0.15 / 0.09 / 0.17 |
| 1998 | 5:43 | 23 | 15 | 5 | 6 / 3 / 0 | 1.00 / 0.69 / 0.02 |
| 1999 | 5:29 / 7:10 | 29 | 8 | 2 | 8 / 2 / 0 | 1.00 / 0.17 / 0.00 |
| 2000 | 5:9 / 7:25 | 17 | 8 | 9 | 4 / 2 / 1 | 0.98 / 0.19 / 0.06 |
| 2001 | 5:11 / 7:27 | 24 | 7 | 7 | 6 / 1 / 1 | 1.00 / 0.06 / 0.08 |
| 2002 | 7:24 | 11 | 7 | 6 | 3 / 3 / 1 | 0.82 / 0.79 / 0.14 |
| 2003 | 7:29 | 14 | 13 | 2 | 2 / 2 / 0 | 0.22 / 0.32 / 0.00 |
| 2004 | 7:45 | 18 | 21 | 6 | 3 / 4 / 0 | 0.55 / 0.89 / 0.02 |
| 2005 | 7:45 | 26 | 13 | 6 | 3 / 1 / 1 | 0.68 / 0.13 / 0.05 |
| 2006 | 7:53 | 30 | 18 | 5 | 5 / 3 / 1 | 0.87 / 0.54 / 0.00 |
| 2007 | 7:53 | 31 | 17 | 5 | 6 / 3 / 0 | 0.97 / 0.59 / 0.00 |
| 2008 | 5:21 / 7:55 | 44 | 26 | 6 | 8 / 7 / 1 | 1.00 / 1.00 / 0.04 |
| 2009 | 5:32 / 7:35 | 42 | 18 | 7 | 11 / 5 / 1 | 1.00 / 0.96 / 0.07 |
| 2010 | 5:16 / 7:31 | 34 | 8 | 5 | 9 / 2 / 1 | 1.00 / 0.21 / 0.05 |
| 2011 | 5:9 / 7:31 | 17 | 16 | 7 | 6 / 2 / 0 | 0.98 / 0.31 / 0.00 |
| 2012 | 7:62 | 35 | 18 | 9 | 6 / 2 / 0 | 1.00 / 0.44 / 0.02 |
| 2013 | 7:52 / 8:38 | 43 | 38 | 9 | 10 / 8 / 0 | 1.00 / 1.00 / 0.01 |
| 2014 | 7:62 / 8:65 | 63 | 39 | 25 | 14 / 6 / 3 | 1.00 / 1.00 / 0.63 |
| 2015 | 7:70 / 8:75 | 70 | 46 | 29 | 14 / 9 / 3 | 1.00 / 1.00 / 0.50 |
| 2016 | 7:63 / 8:62 | 76 | 42 | 7 | 15 / 8 / 1 | 1.00 / 1.00 / 0.02 |
| 2017 | 7:65 / 8:65 | 70 | 42 | 18 | 16 / 7 / 1 | 1.00 / 1.00 / 0.14 |
| 2018 | 7:70 / 8:66 | 72 | 44 | 20 | 16 / 9 / 2 | 1.00 / 1.00 / 0.30 |
| 2019 | 7:64 / 8:69 | 76 | 39 | 18 | 16 / 8 / 1 | 1.00 / 1.00 / 0.09 |
| 2020 | 7:67 / 8:62 | 71 | 38 | 20 | 15 / 8 / 2 | 1.00 / 1.00 / 0.49 |
| 2021 | 7:53 / 8:64 / 9:10 | 72 | 37 | 18 | 13 / 5 / 1 | 1.00 / 0.95 / 0.13 |
| 2022 | 8:60 / 9:55 | 65 | 37 | 13 | 14 / 7 / 0 | 1.00 / 1.00 / 0.11 |
| 2023 | 8:64 / 9:66 | 65 | 39 | 26 | 14 / 8 / 4 | 1.00 / 1.00 / 0.83 |
| 2024 | 8:58 / 9:62 | 74 | 35 | 11 | 17 / 7 / 0 | 1.00 / 1.00 / 0.14 |
| 2025 | 8:55 / 9:55 | 69 | 36 | 5 | 16 / 7 / 1 | 1.00 / 1.00 / 0.00 |
| 2026 | 8:44 / 9:51 | 73 | 0 | 22 | 17 / 0 / 3 | 1.00 / 0.00 / 0.65 |

Reading: 1990-2012 rests on 2-11 clear dry-season observations and typically 1-4 post-monsoon observations; the wet season is almost never observed optically. 1997 and 2003 are the weakest dry seasons (≥3-obs share 0.15 and 0.22). From 2013 (Landsat 8) observation density roughly triples. 1985-1988 has no selected scene; 1989 has six. Landsat-7 alone (SLC-off) carries 2003-2007 and 2012.

## 3. Sentinel coverage (district, selected scenes)

Sentinel-2:

| season | 2015 | 2016 | 2017 | 2018 | 2019 | 2020 | 2021 | 2022 | 2023 | 2024 | 2025 | 2026 |
|---|---|---|---|---|---|---|---|---|---|---|---|---|
| dry | 0 | 49 | 43 | 162 | 208 | 199 | 197 | 178 | 185 | 203 | 202 | 224 |
| post_monsoon | 7 | 49 | 82 | 128 | 116 | 118 | 115 | 114 | 115 | 113 | 132 | 0 |
| wet | 0 | 13 | 16 | 48 | 68 | 63 | 57 | 57 | 72 | 38 | 53 | 102 |

Sentinel-1:

| season | 2015 | 2016 | 2017 | 2018 | 2019 | 2020 | 2021 | 2022 | 2023 | 2024 | 2025 | 2026 |
|---|---|---|---|---|---|---|---|---|---|---|---|---|
| dry | 4 | 3 | 43 | 42 | 22 | 44 | 35 | 33 | 26 | 30 | 39 | 37 |
| post_monsoon | 0 | 21 | 22 | 25 | 40 | 23 | 22 | 12 | 15 | 21 | 23 | 0 |
| wet | 0 | 1 | 37 | 38 | 24 | 40 | 31 | 21 | 23 | 14 | 29 | 44 |

## 4. Composite products on disk

| grid | family | products | rasters present |
|---|---|---|---|
| pune_G10_baramati_agri | sentinel2 | 32 | 16 |
| pune_G240 | landsat | 148 | 16 |
| pune_G240 | landsat_cal_landsat-5 | 4 | 0 |
| pune_G240 | landsat_cal_landsat-7 | 7 | 0 |
| pune_G240 | landsat_cal_landsat-8 | 5 | 0 |
| pune_G240 | landsat_cal_landsat-9 | 2 | 0 |
| pune_G240 | sentinel1 | 192 | 2 |
| pune_G240 | sentinel2 | 144 | 16 |
| pune_G30_baramati_agri | landsat | 148 | 148 |
| pune_G30_baramati_agri | landsat_cal_landsat-5 | 4 | 0 |
| pune_G30_baramati_agri | landsat_cal_landsat-7 | 7 | 0 |
| pune_G30_baramati_agri | landsat_cal_landsat-8 | 5 | 0 |
| pune_G30_baramati_agri | landsat_cal_landsat-9 | 2 | 0 |
| pune_G30_baramati_agri | sentinel1 | 144 | 144 |
| pune_G30_baramati_agri | sentinel2 | 32 | 32 |
| pune_G30_khadakwasla_mutha | landsat | 148 | 148 |
| pune_G30_khadakwasla_mutha | landsat_cal_landsat-5 | 4 | 0 |
| pune_G30_khadakwasla_mutha | landsat_cal_landsat-7 | 7 | 0 |
| pune_G30_khadakwasla_mutha | landsat_cal_landsat-8 | 5 | 0 |
| pune_G30_khadakwasla_mutha | landsat_cal_landsat-9 | 2 | 0 |
| pune_G30_khadakwasla_mutha | sentinel1 | 144 | 144 |
| pune_G30_khadakwasla_mutha | sentinel2 | 32 | 32 |
| pune_G30_khadakwasla_mutha | sentinel2_on_G30 | 1 | 1 |
| pune_G30_mulshi_ghats | landsat | 148 | 148 |
| pune_G30_mulshi_ghats | sentinel1 | 144 | 144 |
| pune_G30_mulshi_ghats | sentinel2 | 32 | 32 |

District (G240) rasters were mostly removed in earlier phases to save disk; their metadata (statistics, QA) remain. At 240 m they are a district overview, not a 30 m land-cover basis. Sentinel-2 at 30 m exists only for 2021 and 2024; at 10 m only for Baramati 2021.

## 5. Datasets (all fields required by the brief)

| dataset | sensor_source | date_year | spatial_coverage | resolution | bands | quality | cloud_fraction | nodata_fraction | processing_level | source | license | preprocessing_version | validation_role |
|---|---|---|---|---|---|---|---|---|---|---|---|---|---|
| Landsat C2 L2 surface reflectance scenes | Landsat 5 TM / 7 ETM+ / 8 OLI / 9 OLI-2 (Planetary Computer STAC) | 1989-2026 | district (WRS-2 146/047, 146/048, 147/047, 147/048) | 30 m | blue, green, red, nir08, swir16, swir22 + QA_PIXEL | 2685 selected of 4291 discovered; L1-L3 MSS excluded | scene cloud <= manifest threshold; per-pixel QA_PIXEL mask | per composite (composites.csv) | L2SP (LaSRC/LEDAPS) | USGS via Microsoft Planetary Computer | public domain (USGS) | local_pune_g30_v2 harmonisation | model input |
| Sentinel-2 L2A scenes | Sentinel-2A/B(/C) MSI | 2015-2026 | district (MGRS tiles) | 10/20 m | B02-B12 + SCL | 3526 selected; dense only from 2018 | SCL mask (reader v2 since Phase 2 fix) | per composite | L2A Sen2Cor | ESA Copernicus via Planetary Computer | Copernicus open | SCL reader v2 (job hash 1ec2a5a4fb52fb1e); s2_to_oli_v1 for fusion (corridor-fitted, NOT transferable: P3-I1) | model input; gold-chip context (2021) |
| Sentinel-1 GRD scenes | Sentinel-1A/B IW GRD (RTC on PC) | 2015-2026 | district | 10 m native, composited to 30/240 m | VV, VH (dB) | 884 selected; S1B gap after Dec 2021; 2025 archive incomplete | n/a (SAR) | per composite | RTC gamma0 | ESA via Planetary Computer | Copernicus open | S1 cube reader fixed in Phase 2 | model input |
| Landsat composites, district G240 | Landsat | 1990-2026 | district | 240 m (benchmark grid) | 6 SR + indices | 148 products; median clear obs per season in metadata | see composites.csv | valid fraction median 1.000 | seasonal/annual medoid composites | this repo | derived | cube-0.1.0 | district overview only (240 m too coarse for 30 m LULC) |
| Landsat/S1/S2 composites, 30 m windows | Landsat, S1, S2 | 1990-2026 (S1 2017-2025, S2 2021/2024) | 3 windows, 903 km2 = 5.8 % of district | 30 m | SR, indices, VV/VH | 1009 products | composites.csv | valid median 1.000 | composites | this repo | derived | cube-0.1.0, local_pune_g30_v2 | model input (benchmark windows) |
| 30 m feature cubes | derived | 1990-2026 | 3 windows | 30 m | 23 Landsat feats, 3 quality, 12 terrain, 7 Sentinel (2017-2025) | dry-NDVI valid fraction min 0.8941 | - | min valid 0.8941 | analysis-ready features | this repo | derived | rebuilt 2026-10-02 with S1 2017-2025 | model input |
| DEM | Copernicus GLO-30 (DSM, primary), NASADEM (secondary) | 2011-2015 / 2000 | 3 windows (terrain cubes) | 30 m | elevation, slope, aspect, TPI, HAND, ... | DSM includes buildings/canopy | - | - | derived terrain | Planetary Computer | Copernicus DEM licence / NASA | configs/dem.yaml | covariate |
| CHIRPS v2 monthly rainfall | CHIRPS | 1981-present (local series) | district | 0.05 deg (~5.5 km) | precipitation mm/month | satellite-gauge blend, coarse | - | - | monthly | UCSB CHC | public domain-like (CHC) | data/processed/climate | covariate; SPI drought classes (proxy) |
| ESA WorldCover 2020/2021 | S1+S2 (ESA) | 2020, 2021 | 3 windows (fractions); district G240 mode 2021 | 10 m -> 30 m fractions | 11 classes | global OA ~75-77 % (producer-reported) | - | - | product | ESA | CC-BY 4.0 | - | silver label source (Tier C) |
| Esri/Impact Observatory LULC 2017-2023 | S2 (Esri) | 2017-2023 | 3 windows | 10 m -> 30 m fractions | 9 classes | producer-reported ~75-85 % | - | - | product | Esri / Impact Observatory (PC io-lulc-annual-v02) | CC-BY 4.0 | - | silver label source (Tier C) |
| GHSL BUILT-S R2023A | JRC (Landsat/S2) | 1990-2020 (5-yearly epochs) | 3 windows | 90 m (built fraction) | built surface fraction | multitemporal modelled | - | - | product | JRC | CC-BY 4.0 | - | independent reference (Tier B) |
| WSF-Evolution | DLR (Landsat) | 1985-2015 (first settled year) | 3 windows | 30 m | first year settled | GDAL nodata bug fixed in Phase 2 | - | - | product | DLR | CC-BY 4.0 | rebuilt 2026-10-02 | independent reference (Tier B) |
| JRC Global Surface Water v1.3 | JRC (Landsat) | 1984-2021 | 3 windows + district G240 | 30 m | occurrence etc. | - | - | - | product | JRC | CC-BY 4.0 | - | independent reference (Tier B) |
| GHS-POP R2023A | JRC | 2000, 2010, 2020 | tile R7_C26 (covers district) | 100 m (Mollweide) | population | modelled from census + built-up (NOT independent of GHSL built-up) | - | - | product | JRC | CC-BY 4.0 | raw, not reprojected | context (not independent of GHSL) |
| Gold sample (blind kit) | design: stratified random in TEST blocks | epochs 1990/2000/2010/2020/2025 | 3 windows only | 30 m cell | - | 558 points; HUMAN Tier-A labels: 0; provisional AI (Tier C, 2021) labelled: 437 | - | - | - | this repo | - | blind kit v1 (Phase 3) | would be Tier A once human-labelled |
| Agriculture data (crop type, irrigation, official stats) | - | - | - | - | - | NO crop-type labels; NO irrigation maps; district NSA/GCA totals c. 2005 only (P3-M3) | - | - | - | - | - | - | none available |
| Water: gauges, reservoir levels/storage, groundwater | - | - | - | - | - | NONE in repo (only JRC occurrence and our MNDWI-based masks) | - | - | - | - | - | - | none available |
| Flood events | configs/events.yaml (news/Wikipedia-cited) | 2019-09-25, 2024-07-25, 2025-05-25 | event bboxes | - | - | only 2025 Baramati has S1 within window; no independent extent | - | - | - | news/Wikipedia | - | - | inventory only |
| Roads / accessibility, population census, admin (taluka) boundaries | - | - | - | - | - | NOT in repo (district boundary only) | - | - | - | - | - | - | none |

## 6. Label and reference rasters

58 rasters (`data/inventory/labels_reference.csv`); 19 have a provenance JSON sidecar, 39 do not (their provenance is only in the generating code and git history).

