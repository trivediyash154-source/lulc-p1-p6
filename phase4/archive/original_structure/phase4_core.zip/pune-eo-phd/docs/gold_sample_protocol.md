# Gold-sample protocol (Phase 3)

Written **before** any chip was interpreted. Applies to the 558-point stratified sample drawn in Phase 2 from TEST blocks only
(`data/labels/gold/<window>/gold_sample.parquet`; design in `docs/label_protocol.md` §7).

## 1. Blindness

The Phase-2 kit was **not blind**: `gold_form.csv` contains the `stratum` column (the silver class) and chip titles printed it.
The Phase-3 kit (`scripts/gold_blind_kit.py`, `data/labels/gold/blind/`) fixes this:

- 558 points pooled across windows, seeded random order, anonymous IDs `G-0001 … G-0558`;
- no stratum, window name, grid row/col, silver class or any model output in the forms, KML or chips;
- the key (`data/labels/gold/_key/gold_key.csv`) is opened only by the evaluation code, never by an interpreter;
- model predictions at gold points are computed only after a pass is frozen (`scripts/eval_gold.py` refuses to run if the pass file is missing a freeze stamp).

## 2. Tiers — what each interpretation may be used for

| tier | interpreter | evidence | epochs | may be called | used for |
|---|---|---|---|---|---|
| A | human analyst(s) | VHR imagery (Google Earth Pro historical, Bing, field visits) + Landsat/S2 context | 1990, 2000, 2010, 2020, 2025 | **gold / ground truth** | accuracy, Olofsson area estimates, Gate 1 |
| C (provisional) | AI visual interpretation (Claude), recorded as such | Sentinel-2 L2A 10 m chips, 2021 dry + post-monsoon | 2021 only | **provisional reference — never gold** | an independent-of-pipeline check of the 2021 map while Tier A is pending |

No AI interpretation is made for 1990–2010: the only imagery available here for those epochs is the Landsat archive the models
themselves use, which would make the reference circular. Historical Tier-A labels need human VHR interpretation; for 1990 even
VHR may be unavailable (Google Earth historical coverage over Pune typically starts in the 2000s), in which case the point is recorded
`uncertain` with reason `no VHR for epoch`.

## 3. Interpretation unit and classes

- Unit: the **30 m cell** (yellow square; 3 × 3 Sentinel-2 pixels). Label the class covering the largest share of the cell.
  The cyan 330 m square and the 1.2 km chip are context only.
- Classes: `built_up`, `agriculture`, `natural_vegetation`, `water`, `bare_sparse`, `other`, plus abstentions `uncertain`
  (evidence insufficient) and `ambiguous` (evidence shows a genuine mix / boundary / class-definition problem). **No forced class.**
- Confidence: 3 = unambiguous; 2 = likely; 1 = weak.

## 4. Decision rules (fixed in advance)

| class | evidence that supports it | typical confusion |
|---|---|---|
| built_up | roofs, roads, compounds, regular dense geometry; bright/grey in true colour; no red (vegetation) in either season's NIR-R-G | bare soil, dry fallow fields, quarries |
| agriculture | field-parcel geometry; strong seasonal contrast (red in post-monsoon NIR-R-G, brown/bare or green-irrigated in dry season); bunds, canals | grassland/scrub; orchards look like woody vegetation |
| natural_vegetation | irregular texture without parcels; forest = dark red in both seasons; scrub/grass on slopes and hill-tops, brown in the dry season | rainfed fields on slopes; fallow land |
| water | dark blue/black in both seasons; reservoir/river | reservoir drawdown margins (seasonal) → label the 2021 dry-season state, flag ambiguity |
| bare_sparse | bright soil or rock in both seasons, no vegetation response, no buildings (quarries, exposed rock, construction sites) | built-up, fallow |

## 5. Quality control

- **Human (Tier A):** a seeded 20 % subset (112 points, `double_interpretation = True`) is interpreted independently by a second analyst
  who does not see the first form (`gold_blind_form_interpreter2.csv`). Agreement: Cohen's κ (two analysts), Fleiss' κ and Krippendorff's α
  (more analysts / missing ratings) — `src/pune_eo/labels/gold_qa.py`. Disagreements are adjudicated and logged, never silently overwritten.
- **Provisional AI (Tier C):** a seeded 15 % repeat pass on re-shuffled sheets measures **self-consistency** (intra-interpreter κ). This is
  NOT inter-annotator agreement and cannot satisfy Gate 1.
- Confidence tiers: `high_confidence` (3), `medium_confidence` (2), `low_confidence` (1), `ambiguous_or_uncertain`. The main accuracy is
  computed on non-abstaining labels; results for high-confidence-only and the abstention rate are always reported alongside.

## 6. Gate 1

Passed only if, for the evaluated epoch, Tier-A labels exist for ≥ 80 % of points **and** Cohen's κ ≥ 0.6 on ≥ 20 % double-interpreted points
(`configs/phase3.yaml`). Provisional Tier-C labels can never pass Gate 1.

## 7. Files

`data/labels/gold/blind/`: `gold_blind_form_interpreter1.csv`, `gold_blind_form_interpreter2.csv`, `gold_blind_cells.kml`, `chips_landsat/`,
`chips_s2_2021/`, `sheets_s2_2021/`, `kit.json`. Provisional AI passes: `results/gold/provisional_ai_pass1.csv`, `results/gold/provisional_ai_pass2.csv`.

## 8. Execution record (appended after interpretation; sections 1-7 unchanged)

- **Tier A:** not executed — no human interpreter with VHR access in this environment. `P3-A2` stays PENDING; **Gate 1 NOT passed**.
- **Provisional AI pass (Tier C).** All 558 points interpreted from the S2 10 m sheets by Claude model instances working only from this protocol and
  `results/gold/_parts/INTERPRETER_INSTRUCTIONS.md` (blindness rules: no key, no model output). G-0001…G-0095 by the main instance; G-0096…G-0558 in four
  contiguous blocks of the randomly ordered IDs by four separate instances (column `interpreter`). Repeat pass: 84 IDs on re-shuffled sheets by a fifth instance
  that saw neither pass-1 sheets nor pass-1 labels.
- Frozen 2026-10-02T08:50:38Z (`results/gold/provisional_ai_FROZEN.json`, SHA-256 of both pass files). The key was first joined by `scripts/eval_gold.py`, which
  refuses to run on a missing stamp or a changed file.
- **Observed interpreter heterogeneity:** abstention rates differ between instances (0.16-0.38; chi-square p ≈ 4e-5) although each block is a random subset —
  the abstention threshold is interpreter-dependent. Evaluation therefore reports the abstention rate, the high-confidence subset and per-stratum abstention.
- **Repeat-pass consistency:** 75 % exact agreement over all categories (κ 0.69); on the 50 points both passes labelled, agreement was complete — all
  disagreement concerns whether to abstain. This is intra-protocol consistency, not inter-annotator agreement.
- **Dependence caveat:** the AI used the same Sentinel-2 imagery family as WorldCover/Esri (the silver sources); agreement between the AI labels and those
  products is therefore not fully independent. The Landsat-based models are independent of the S2 evidence.
- Results: `results/phase3/gold/gold_provisional_eval.json`, registry `P3-A2p`.
