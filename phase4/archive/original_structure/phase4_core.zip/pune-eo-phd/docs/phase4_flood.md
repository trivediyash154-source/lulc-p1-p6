# Phase 4 — flood

Event inventory (Phase 3, P3-N1): of three cited events only Baramati 2025-05-25 has a Sentinel-1 acquisition within -1..+3 days; its candidate extent (1.1-3.6 km² depending on threshold) is UNVALIDATED.

For each event the inventory requires: pre-event S1, post-event S1, rainfall, candidate inundation, independent evidence, validation. With one observable event and no independent extent, **no flood ML is built**.

Next: extend the event list from official sources (district disaster management reports, IMD extreme-rainfall records), check S1 timing for each, and collect independent extents (news imagery, Sentinel-2 when cloud-free, field reports).
