# Phase 4 — sensor-era validation

## 1. Sensor eras in the archive

Landsat-5 TM only 1990-1998; Landsat-5/7 1999-2002; Landsat-7 alone (SLC-off) 2003-2007 and 2012; L5+L7 2008-2011; L7+L8 2013-2021; L8+L9 2022-2026 (`docs/phase4_data_inventory.md`). Harmonisation in the cube (local_pune_g30_v2): L7 -> OLI pooled RMA; **L5 and L9 identity** (correction rejected by the held-out rule; evidence for L5 was mixed).

## 2. P4-E1 (exploratory): pseudo-invariant targets

PIF cells from independent products only: water (JRC >= 95 and GLC_FCS30D water every epoch), impervious (GLC_FCS30D impervious every epoch and WSF 1985), forest (GLC_FCS30D forest every epoch). PIF cells per window: {'pune_G30_khadakwasla_mutha': {'water_pif': 3336, 'impervious_pif': 28312, 'forest_pif': 35569}, 'pune_G30_baramati_agri': {'water_pif': 0, 'impervious_pif': 2576, 'forest_pif': 2}, 'pune_G30_mulshi_ghats': {'water_pif': 27616, 'impervious_pif': 47, 'forest_pif': 310641}}. Years are grouped by the dominant sensor (>= 80 % of clear pixels) and compared in SPI-normal years.

| window | PIF | band | L5 minus L8/9 (95 % CI) | L7 minus L8/9 |
|---|---|---|---|---|
| khadakwasla_mutha | water | red | +0.0129 [+0.0062, +0.0197] | -0.0149 |
| khadakwasla_mutha | water | nir | +0.0081 [+0.0002, +0.0168] | -0.0175 |
| khadakwasla_mutha | water | swir1 | -0.0015 [-0.0060, +0.0031] | -0.0102 |
| khadakwasla_mutha | water | ndvi | -0.0341 [-0.1130, +0.0393] | -0.2182 |
| khadakwasla_mutha | impervious | red | +0.0196 [+0.0130, +0.0265] | +0.0049 |
| khadakwasla_mutha | impervious | nir | -0.0013 [-0.0122, +0.0105] | -0.0033 |
| khadakwasla_mutha | impervious | swir1 | +0.0124 [+0.0039, +0.0220] | +0.0040 |
| khadakwasla_mutha | impervious | ndvi | -0.0912 [-0.1059, -0.0754] | -0.0363 |
| khadakwasla_mutha | forest | red | +0.0249 [+0.0174, +0.0324] | +0.0079 |
| khadakwasla_mutha | forest | nir | +0.0125 [+0.0056, +0.0192] | +0.0047 |
| khadakwasla_mutha | forest | swir1 | +0.0234 [+0.0132, +0.0318] | +0.0083 |
| khadakwasla_mutha | forest | ndvi | -0.0908 [-0.1261, -0.0575] | -0.0431 |
| baramati_agri | impervious | red | +0.0125 [+0.0044, +0.0201] | +0.0045 |
| baramati_agri | impervious | nir | -0.0000 [-0.0072, +0.0072] | -0.0005 |
| baramati_agri | impervious | swir1 | +0.0101 [+0.0025, +0.0171] | +0.0048 |
| baramati_agri | impervious | ndvi | -0.0509 [-0.0662, -0.0357] | -0.0234 |
| mulshi_ghats | water | red | +0.0115 [+0.0047, +0.0191] | — |
| mulshi_ghats | water | nir | +0.0082 [+0.0015, +0.0163] | — |
| mulshi_ghats | water | swir1 | -0.0010 [-0.0046, +0.0030] | — |
| mulshi_ghats | water | ndvi | -0.0550 [-0.0839, -0.0271] | — |
| mulshi_ghats | impervious | red | +0.0233 [+0.0171, +0.0291] | — |
| mulshi_ghats | impervious | nir | +0.0085 [+0.0023, +0.0151] | — |
| mulshi_ghats | impervious | swir1 | +0.0274 [+0.0197, +0.0358] | — |
| mulshi_ghats | impervious | ndvi | -0.0663 [-0.0882, -0.0434] | — |
| mulshi_ghats | forest | red | +0.0329 [+0.0272, +0.0390] | — |
| mulshi_ghats | forest | nir | +0.0059 [+0.0008, +0.0104] | — |
| mulshi_ghats | forest | swir1 | +0.0381 [+0.0292, +0.0471] | — |
| mulshi_ghats | forest | ndvi | -0.1485 [-0.1778, -0.1225] | — |

60 of 77 contrasts have a percentile-bootstrap interval excluding zero, but each regime contains only 3-8 years, so these intervals under-cover and overstate precision. Point estimates: Landsat-5-dominated years have higher red (+0.01 to +0.03) and lower NDVI (-0.03 to -0.15) than Landsat-8/9-dominated years for every PIF class AVAILABLE in each window (Baramati has only the impervious PIF; Mulshi's impervious PIF has 47 cells; the corridor water NDVI interval includes zero). L7-minus-L8/9 contrasts are mixed (water red/NIR have the opposite sign). Sensor regime is fully confounded with time (L5 = 1990s, pure L8/9 = 2022-2026): a residual TM-vs-OLI difference is one explanation consistent with the pattern; real change of the targets (turbidity, roofing, canopy) and climate are others. The direction matches the historical failure, but this is an association, not an attribution.

Note: `regime_differences.csv` and the script were re-written after the run only to add the CI columns already stored in `sensor_era_pif.json` (values unchanged).

**Status:** exploratory. It motivated the confirmatory, pre-registered test P4-C2 (cross-sensor TM/ETM+ -> OLI transform vs identity), which will be decided on Tier-A gold, not on these PIF statistics.

## 3. Still to do (needs the district cube and gold)

* Spectral/feature distributions per era district-wide; class confusion, calibration, spatial and temporal transfer per era on gold (P4-C3).
* Era-aware vs unified model (P4-C3).
