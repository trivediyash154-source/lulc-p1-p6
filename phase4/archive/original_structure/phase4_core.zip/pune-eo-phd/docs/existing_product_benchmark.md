# Existing-product benchmark (Phase 4, P4-X1 / P4-X2, exploratory)

District area 15642 km² (30 m cells inside the boundary). Products on the district 30 m Landsat lattice, except GHSL (nested 90 m grid, bilinear) and ESA CCI (300 m). Esri and WorldCover are GDAL 'mode' aggregates from 10 m, which under-represents fragmented built-up. No product is treated as truth; WorldCover and Esri are silver-label sources (Tier C).

## 1. Built-up area trajectories (km²)

| product | 1985 | 1990 | 1995 | 2000 | 2005 | 2010 | 2015 | 2020 | 2021 | 2023 | monotone (no >10 % decline) |
|---|---|---|---|---|---|---|---|---|---|---|---|
| WSF Evolution settlement | 268 | 268 | 343 | 455 | 565 | 713 | 820 | — | — | — | yes |
| GISA2 impervious | 126 | 173 | 250 | 327 | 390 | 494 | 624 | 745 | 751 | — | yes |
| GLC FCS30D impervious | 182 | 182 | 214 | 385 | 597 | 746 | 871 | 915 | 912 | — | yes |
| GHSL BUILT S surface | — | 117 | 150 | 191 | 233 | 286 | 350 | 424 | — | — | yes |
| ESA CCI urban 300m | — | — | 94 | 107 | 189 | 304 | 364 | 470 | — | — | yes |
| Esri built | — | — | — | — | — | — | — | 1676 | 1725 | 2006 | yes |
| WorldCover built | — | — | — | — | — | — | — | 722 | 827 | — | yes |

* In 2020 the products span 424-1676 km² (GHSL built surface ... Esri built area): definitions differ — built SURFACE fraction (GHSL), impervious surface (GISA, GLC_FCS30D), settlement extent (WSF), built-area land cover (Esri, WorldCover), coarse urban class (CCI).
* No product shows a district built-up decline > 10 % between epochs (GLC_FCS30D has small declines 2018->19, 2020->22); all show growth of roughly 3-5.5x between 1990 (CCI: 1992) and their last epoch.
* 'Built-up' in our legend has no single external equivalent: every comparison must state which definition it uses.

## 2. Pairwise built-up agreement at 30 m

| year / pair | F1 | Jaccard | area ratio |
|---|---|---|---|
| 1990/GISA~WSF | 0.43 | 0.28 | 0.65 |
| 1990/GISA~GLC | 0.32 | 0.19 | 0.95 |
| 1990/GLC~WSF | 0.36 | 0.22 | 0.68 |
| 2000/GISA~WSF | 0.61 | 0.44 | 0.72 |
| 2000/GISA~GLC | 0.58 | 0.41 | 0.85 |
| 2000/GLC~WSF | 0.52 | 0.35 | 0.85 |
| 2010/GISA~WSF | 0.66 | 0.49 | 0.69 |
| 2010/GISA~GLC | 0.66 | 0.49 | 0.66 |
| 2010/GLC~WSF | 0.63 | 0.46 | 1.05 |
| 2015/GISA~WSF | 0.70 | 0.54 | 0.76 |
| 2015/GISA~GLC | 0.70 | 0.54 | 0.72 |
| 2015/GLC~WSF | 0.64 | 0.47 | 1.06 |

Agreement between independent built products rises from F1 0.32-0.43 (1990) to 0.64-0.70 (2015). Of all cells any of WSF/GISA/GLC_FCS30D calls built in 2015, 37% are called built by all three and 42% by only one. Historical built-up is genuinely uncertain, not just uncertain for our model.

## 3. Land-cover agreement 2020 (L1)

| pair | agreement |
|---|---|
| GLC~Esri | 0.790 |
| GLC~WorldCover | 0.670 |
| Esri~WorldCover | 0.696 |
| all_three | 0.600 |

Per-class overlap (intersection/union) GLC_FCS30D vs Esri: built_up 0.43, agriculture 0.74, natural_vegetation 0.59, water 0.44, bare_sparse 0.00.

All three products agree on 60% of the district; two agree on 36%; none on 4%.

Where products disagree (P4-X3, descriptors NOT derived from the consensus; the earlier by-stratum summary in P4-X1 was circular because strata were built from the same consensus): rainfall zone: wet_west_ge1200 31%, transition_700_1200 46%, dry_east_lt700 40%; slope: lt3deg 36%, 3_8deg 61%, ge8deg 34%; distance to water: le300m 47%, 300m_1km 41%, gt1km 39%; settlement wsf: settled_by_2000 43%, settled_2001_2015 51%, never_settled 40% (district 40%).

Disagreement is highest on gentle 3-8° slopes (foothills/transitional terrain), in the transition rainfall zone, within 300 m of water and in areas settled 2001-2015; lowest in the wet west and on flat or steep terrain.

## 4. Temporal consistency

Year-to-year share of district cells changing L1 class: GLC_FCS30D 2000-2001 0.9%, 2001-2002 0.7%, 2002-2003 0.7%, 2003-2004 0.6% …; Esri 2017-2018 5.8%, 2018-2019 5.8%, 2019-2020 7.0%, 2020-2021 4.6%, 2021-2022 5.9%, 2022-2023 5.2%. GLC_FCS30D is temporally smoothed by construction (continuous change detection); Esri's annual maps flicker (4.6-7 % of the district per year), far more than plausible land change — Esri year-to-year differences must not be read as change. WorldCover 2020 -> 2021 is a version change (v100 -> v200), not change.

## 5. Our Phase-3 reconstruction (P3-F3) vs the products, inside the 3 windows (P4-X2)

| window | epoch | ours built | GLC built | WSF | GISA | ours agri / natveg | GLC agri / natveg | 4-class agreement vs GLC |
|---|---|---|---|---|---|---|---|---|
| khadakwasla_mutha | 1990 | 0.50 | 0.13 | 0.21 | 0.10 | 0.24 / 0.24 | 0.68 / 0.17 | 0.44 |
| khadakwasla_mutha | 2000 | 0.21 | 0.19 | 0.33 | 0.23 | 0.08 / 0.69 | 0.63 / 0.16 | 0.40 |
| khadakwasla_mutha | 2010 | 0.30 | 0.32 | 0.46 | 0.31 | 0.05 / 0.63 | 0.52 / 0.15 | 0.46 |
| khadakwasla_mutha | 2020 | 0.43 | 0.36 | — | 0.42 | 0.16 / 0.39 | 0.49 / 0.13 | 0.62 |
| baramati_agri | 1990 | 0.63 | 0.03 | 0.02 | 0.01 | 0.36 / 0.01 | 0.97 / 0.00 | 0.39 |
| baramati_agri | 2000 | 0.18 | 0.05 | 0.05 | 0.03 | 0.59 / 0.23 | 0.95 / 0.00 | 0.61 |
| baramati_agri | 2010 | 0.13 | 0.09 | 0.08 | 0.05 | 0.63 / 0.24 | 0.90 / 0.00 | 0.68 |
| baramati_agri | 2020 | 0.13 | 0.11 | — | 0.08 | 0.83 / 0.03 | 0.89 / 0.00 | 0.90 |
| mulshi_ghats | 1990 | 0.07 | 0.00 | 0.00 | 0.00 | 0.34 / 0.46 | 0.07 / 0.83 | 0.56 |
| mulshi_ghats | 2000 | 0.00 | 0.00 | 0.00 | 0.00 | 0.07 / 0.83 | 0.07 / 0.82 | 0.91 |
| mulshi_ghats | 2010 | 0.00 | 0.00 | 0.00 | 0.00 | 0.07 / 0.82 | 0.07 / 0.82 | 0.90 |
| mulshi_ghats | 2020 | 0.00 | 0.00 | — | 0.00 | 0.09 / 0.79 | 0.07 / 0.81 | 0.90 |

* 1990: our model maps 50 % (corridor) and 63 % (Baramati) as built against 1-21 % in every independent product — the historical failure, seen against three independent references (GLC_FCS30D, WSF, GISA).
* Corridor composition: after 1990 our model calls 39%-69% of the corridor natural vegetation and 5%-23% agriculture where GLC_FCS30D has 13%-17% and 49%-67%. This is consistent with the label audit (corridor agriculture received silver labels in only 8 % of its cells) — an association, not a demonstrated cause.
* Mulshi (forest/reservoir) agrees with GLC_FCS30D on ~0.9 of pixels after 1990.

## 6. Products that could not be used here

* Dynamic World, GAIA — Earth Engine only (needs the user's project; export script ready: `scripts/gee/export_district_cube.py --what dw,gaia`).
* India decadal LULC 1985/1995/2005 (ORNL DAAC) — NASA Earthdata login needed.
* NRSC LULC 50K — view-only.

Figures: `figures/phase4/P4F2_built_trajectories_products.png`, `P4F3_class_shares_2020.png`, `P4F4_consensus_maps.png`, `P4F7_p3f3_vs_products.png`.
