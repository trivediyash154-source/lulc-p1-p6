# Phase 3 — methodology

Phase 3 continues the Phase-1/2 system (same grids, harmonisation `local_pune_g30_v2`, cubes, splits, registry). It does not redesign Phase 1
or repeat Phase 2: the Phase-2 limitations are the research problems.

## 1. Research question and falsifiable hypothesis

**Question.** Can multi-temporal and multi-sensor Earth-observation models reconstruct land-cover transitions more reliably across time and
space than single-year optical models — particularly under sensor shift, seasonal variability, drought and landscape transfer?

**Hypothesis (H3).** Relative to a single-date Landsat optical classifier, models that use (a) multi-year temporal context and/or (b) Sentinel-1 SAR
reduce historical false built-up in dry years, improve agreement on unseen landscapes, and remain calibrated on unseen landscapes.

**What would refute it (stated before running):** no reduction of dry-year false built-up on the Tier-B never-settled frame with a block-bootstrap
CI excluding 0; no gain (or a loss) on held-out windows; calibration/coverage failing on held-out windows. Each component has its own
pre-registered hypothesis and comparator (`configs/phase3_experiments.yaml`, `experiments/registry3/`), and each gate its own criterion
(`configs/phase3.yaml`). A NOT_SUPPORTED outcome is a result, not a failure of the programme.

## 2. Order of work (as required)

1. Audit Phase 2 (`docs/phase3_start_audit.md`, `results/audit/phase2_audit.json`).
2. Gold sample: blind kit, protocol written before interpretation (`docs/gold_sample_protocol.md`), provisional AI pass (Tier C) frozen before the key was opened.
3. True baseline: the 2021 result re-assessed against silver, independent products, the provisional reference, unseen windows and history (P3-A*).
4. Historical failure: temporal feature ablations and multi-year training labels (P3-B*), climate strata (P3-D*).
5. Multimodal fusion in the S1 era (P3-C*), identical splits/seed/hyperparameters.
6. Transferability: transfer matrix, domain-shift characterisation, then adaptation (P3-E*, J1, J2).
7. Calibration on unseen landscapes (P3-H*).
8. Advanced AI only after the gates: deep temporal (P3-F*, run because P3-B4 beat P3-B1), self-supervised (P3-G*), label efficiency / active learning (P3-L*).
9. Change diagnosis and probabilistic timing (P3-K*), harmonisation generalisation (P3-I1), agriculture state (P3-M*), flood inventory (P3-N1).
10. Model selection by pre-declared multi-criteria rule, era-aware probabilistic product, error taxonomy, Gate 6, scaling decision (P3-O*).

## 3. Reference data and validation tiers

| tier | content | may be called | used for |
|---|---|---|---|
| A | human VHR interpretation of the 558-point gold sample (blind) | ground truth | accuracy, area estimation, Gate 1 — **not available (0/558)** |
| B | WSF-Evolution, GHSL BUILT-S R2023A, JRC GSW v1.3 (never used for training or selection) | independent reference products | historical false built-up, built recall, water recall, built-vs-WSF error |
| C | silver consensus (WorldCover + Esri 2020-21), provisional AI interpretation of S2 10 m chips (2021) | agreement only | training labels (silver), agreement metrics |
| D | model/imagery-derived pseudo-labels (stable-segment label extension) | never ground truth | training only |

Language: "agreement with reference products"; never "accuracy" for Tier B/C. The 0.979 of Phase 2 is silver agreement.

## 4. Historical evaluation table (HET)

`src/pune_eo/historical_reconstruction/het.py` samples 73 066 cells from the three G30 benchmark windows: silver cells capped per class and split, and
Tier-B strata (stable-built: WSF 1985 & GHSL 1990 ≥ 0.3; never-settled: WSF never & GHSL 2020 < 0.02 & JRC 0; deep water: JRC ≥ 95; urbanised: WSF 1995-2012 &
GHSL gain ≥ 0.2). For every cell: 37 years × 23 Landsat features, quality, terrain, S1/S2 2017-2025, SPI climate, CHIRPS mean, block, fold, split.
All historical metrics use **TEST-block** cells only.

## 5. Splits, spatial leakage

3 km hashed spatial blocks (train/val/test, 2-pixel buffer) from Phase 2; no random pixel splits. Unseen-landscape tests are leave-one-window-out
(LOWO) or single-source transfer to a different window (all HET silver cells of that window, i.e. the class-capped sample). Few-shot / active-learning labels come only from the target window's TRAIN blocks.

## 6. Metrics and statistics

Macro-F1, per-class F1 and IoU, confusion (agri↔natveg, agri↔built), ECE (15 bins), classwise ECE, Brier, NLL, conformal coverage and set size;
historical: false built-up rate (FBR) on never-settled cells, stable-built recall, deep-water recall, by year, era and SPI class.
Uncertainty: paired **spatial block bootstrap** (1000 resamples of 3 km blocks, seed 20261020) for model differences on the same cells; independent block
bootstraps for differences between different cell sets; stratified bootstrap for the gold sample; McNemar as secondary (assumes independence).
Mean accuracy is never reported alone.

## 7. Climate strata (independent indicator)

SPI-12 at September of year t−1 (gamma fit per window, CHIRPS 1991-2020) classifies year t (dry ≤ −1, wet ≥ +1; ±0.5 sensitivity). Two thirds of window dry-years fall in
1993-2004 (Landsat-5/7, SLC-off), so dry-vs-normal contrasts are also reported **era-matched**. Climate class is a proxy for surface condition;
no causal claim is made.

## 8. Eras

early_historical 1990-1998 (TM only), landsat_dominant 1999-2014, sentinel_dense 2015-2021, current 2022-2026. Every product layer carries its era;
S1-based models are never applied before the S1 era.

## 9. Registry rules

Every experiment is registered **before** execution (`registry3.register`) with hypothesis, data, features, labels, tier, model, splits, seed, metrics.
Statuses PASS / FAIL / PENDING / INVALID / SUPERSEDED; outcomes SUPPORTED / NOT_SUPPORTED / INCONCLUSIVE / NA. A completed record is immutable; a
correction is a new version (`@v2`) and the old record is kept (example: P3-B5m FAILED on a feature-routing bug → P3-B5m@v2, itself re-scored as @v3; the m-variant outcomes were
computed against the wrong comparator → records marked INVALID and re-evaluated as @v2 with the registered comparator, re-using the saved predictions).

## 10. Locked

No future scenarios; no crop-type maps or accuracies (no crop labels); no flood AI (one observable event, no reference); no district-wide scaling unless Gate 6 passes.
