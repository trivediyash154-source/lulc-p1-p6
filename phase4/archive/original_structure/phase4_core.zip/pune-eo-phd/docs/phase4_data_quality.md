# Phase 4 — data quality

## 1. Composite QA status (all grids)

| family / kind | FAIL | IN_PROGRESS | PASS | WARNING |
|---|---|---|---|---|
| landsat / annual | 0 | 0 | 120 | 28 |
| landsat / season | 57 | 4 | 231 | 152 |
| landsat_cal_landsat-5 / season | 6 | 0 | 2 | 4 |
| landsat_cal_landsat-7 / season | 0 | 0 | 8 | 13 |
| landsat_cal_landsat-8 / season | 0 | 0 | 15 | 0 |
| landsat_cal_landsat-9 / season | 0 | 0 | 6 | 0 |
| sentinel1 / annual | 0 | 0 | 37 | 2 |
| sentinel1 / month | 37 | 3 | 354 | 74 |
| sentinel1 / season | 3 | 1 | 111 | 2 |
| sentinel2 / annual | 0 | 0 | 15 | 1 |
| sentinel2 / month | 45 | 3 | 104 | 40 |
| sentinel2 / season | 3 | 1 | 33 | 11 |
| sentinel2_on_G30 / season | 0 | 0 | 0 | 1 |

Wet-season Landsat composites: 57 of 148 FAIL and 62 WARN (cloud); S2/S1 monthly FAILs are monsoon months. 115 products carry 'Landsat-7 SLC-off is the only sensor'; 260 carry 'median clear observations < 3' (377 including '< 2').

## 2. Observation density in the 30 m windows (Landsat seasonal composites, median clear obs)

| window | dry min / median / max | post min / median / max | wet min / median / max |
|---|---|---|---|
| khadakwasla_mutha | 2 / 8 / 18 | 0 / 4 / 10 | 0 / 1 / 4 |
| baramati_agri | 6 / 18 / 51 | 0 / 9 / 24 | 0 / 3 / 11 |
| mulshi_ghats | 2 / 7 / 17 | 0 / 3 / 9 | 0 / 1 / 3 |

Baramati sits in a WRS-2 path overlap (about twice the observations of the other windows) — a density advantage that does not hold for the district.

## 3. Known processing issues and their status

| issue | found | status | residual risk |
|---|---|---|---|
| WSF GDAL nodata bump | Phase 2 | fixed; no experiment used the pre-fix product (Phase-3 audit) | low |
| S2 SCL reader v1 counted no-data as observed | Phase 2 | fixed (v2); old products quarantined | low |
| S1 cube reader filename | Phase 2 | fixed | low |
| S2 -> OLI transform fitted on corridor only | Phase 3 (P3-I1) | NOT fixed: window-specific residuals up to ~0.025 (NIR/SWIR Baramati), NDVI -0.035 (Mulshi) | high for Landsat+S2 fusion |
| Landsat cross-sensor harmonisation (local_pune_g30_v2) | Phase 1-2 | fitted on overlaps; not validated on pseudo-invariant targets across eras | medium-high for 1990s |
| sparse early-era observations (1990-98: 2-6 clear dry obs; post-monsoon 1-4) | Phase 4 audit | inherent | high: annual maps before 2013 weakly constrained |
| L7 SLC-off-only years (2003-2007, 2012) | Phase 1 | gap-filled by compositing | medium (striping residue) |
| DEM is a DSM (Copernicus) | Phase 1 | documented | medium for HAND/flood |
| 2025 S1 archive incomplete; 2026 partial | Phase 2 | documented | low |

## 4. What the quality allows

* 2013-2026: dense optical record; S1 from 2017 (S1B gap after Dec 2021); S2 dense from 2018 — annual 30 m maps are observationally supported.
* 1999-2012: dry-season composites supported in most years; post-monsoon weak in about half the years; annual change detection at ±1 y precision is not supported everywhere.
* 1990-1998: TM only, 2-6 clear dry observations, post-monsoon often 1-2; epoch-level (multi-year) reconstruction is defensible to attempt, annual reconstruction must carry explicit temporal uncertainty.
* Wet season: no optical basis in any year before 2014 and weak after; SAR only from 2015.
