# Phase 4 — harmonisation

## 1. What is applied now

* Landsat: local_pune_g30_v2 — L7 -> OLI pooled RMA from two windows (2014-2016 dry composites); L5/L4 and L9 identity. Recorded landscape slope spread between windows up to 0.08 (NIR) = an irreducible landscape-dependent uncertainty for pre-2013 L7.
* Sentinel-2 -> OLI (s2_to_oli_v1): fitted on 19 corridor same-day pairs; **fails outside the corridor** (P3-I1: Baramati NIR/SWIR about -0.02, Mulshi NDVI -0.035; refitting on other windows does not remove the Baramati bias).

## 2. New evidence (P4-E1, exploratory)

Pseudo-invariant targets differ between Landsat-5- and Landsat-8/9-dominated years after harmonisation (higher red, lower NDVI in L5 years; regime confounded with time; few years per regime) — `docs/phase4_sensor_era.md`.

## 3. Alternatives to evaluate (pre-registered P4-C2; not tuned on validation areas)

1. Current (identity for TM). 2. Published cross-sensor TM/ETM+ -> OLI transformation (applied uniformly). 3. PIF-fitted per-sensor linear normalisation, fitted only on PIF cells in TRAINING blocks, evaluated on validation-block PIFs and on gold.
Criteria: residual PIF differences per band (NIR, SWIR, red, NDVI, NDMI), early-era false built-up vs the envelope of independent products, and gold accuracy for 1990/2000.

## 4. Status

Gate-relevant harmonisation evidence requires the district cube (raw, unharmonised per-sensor composites must be exported so alternatives can be applied). The Earth Engine export applies the current harmonisation; for P4-C2 a raw-per-sensor export option must be added before running (documented, not yet executed).
