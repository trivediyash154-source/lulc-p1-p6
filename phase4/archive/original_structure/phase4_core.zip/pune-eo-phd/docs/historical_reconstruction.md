# Historical reconstruction (Phase 3: A4, B, D, K, O)

Tier-B frames on TEST blocks only: never-settled (WSF never settled, GHSL 2020 < 0.02, JRC 0), stable-built (WSF 1985, GHSL 1990 >= 0.3), deep water (JRC >= 95). False built-up rate (FBR) = share of never-settled cell-years predicted built. These are agreement measures with independent products, not accuracy.

## The failure (P3-A4): Phase-3 re-fit of the 2021 configuration applied to every year

| window | n never-settled | 1990 | 1995 | 2000 | 2005 | 2010 | 2015 | 2021 | 2025 |
|---|---|---|---|---|---|---|---|---|---|
| khadakwasla_mutha | 4077 | 0.43 | 0.27 | 0.07 | 0.05 | 0.05 | 0.04 | 0.03 | 0.11 |
| baramati_agri | 3269 | 0.77 | 0.79 | 0.54 | 0.16 | 0.30 | 0.28 | 0.04 | 0.15 |
| mulshi_ghats | 6467 | 0.29 | 0.23 | 0.02 | 0.01 | 0.03 | 0.00 | 0.00 | 0.01 |

The 2021 model agrees with silver in 2020 (macro-F1 0.975) yet calls 29-77 % of never-settled land 'built' in 1990. The failure is concentrated in the TM-only era (1990-1998) and in the agricultural Baramati window (a plausible but untested explanation: bare dry fields look like built surfaces in Landsat seasonal composites). The Phase-2 headline '75 % of the corridor mapped built-up in 1990' is re-measured the same way at the end of this document (window-wide share).

## Temporal information and multi-year labels (group B)

| id | features / training | dry-year FBR khadakwasla_mutha / baramati_agri / mulshi_ghats | silver 2021 | comparison (pre-registered comparator) | status |
|---|---|---|---|---|---|
| P3-B1 | single-date dry (11), 2021 labels | 0.178 / 0.785 / 0.080 | 0.941 | reference | PASS / NA |
| P3-B2 | t-1,t,t+1 (33) | 0.102 / 0.660 / 0.037 | 0.963 | vs P3-B1: -0.072 (rel -26%, CI -0.092..-0.050) | PASS / SUPPORTED |
| P3-B3 | seasonal (16) | 0.137 / 0.632 / 0.071 | 0.950 | vs P3-B1: -0.052 (rel -19%, CI -0.083..-0.027) | PASS / INCONCLUSIVE |
| P3-B4 | 5-year window + stats (89) | 0.037 / 0.513 / 0.016 | 0.974 | vs P3-B1: -0.136 (rel -49%, CI -0.176..-0.093) | PASS / SUPPORTED |
| P3-B1m -> P3-B1m@v2 | B1, multi-year stable-segment labels (Tier D) | 0.060 / 0.570 / 0.024 | 0.924 | dry-year FBR vs P3-B1: -0.1118 (rel -41%, CI -0.1429..-0.0809) | PASS / SUPPORTED |
| P3-B2m -> P3-B2m@v2 | B2, multi-year labels | 0.038 / 0.462 / 0.007 | 0.954 | dry-year FBR vs P3-B2: -0.0797 (rel -39%, CI -0.1139..-0.0495) | PASS / SUPPORTED |
| P3-B3m -> P3-B3m@v2 | B3, multi-year labels | 0.056 / 0.418 / 0.033 | 0.944 | dry-year FBR vs P3-B3: -0.0924 (rel -41%, CI -0.1266..-0.0595) | PASS / SUPPORTED |
| P3-B4m -> P3-B4m@v2 | B4, multi-year labels | 0.031 / 0.423 / 0.010 | 0.968 | dry-year FBR vs P3-B4: -0.0258 (rel -19%, CI -0.0447..-0.0105) | PASS / SUPPORTED |
| P3-B5m@v2 -> P3-B5m@v3 | B4m + SPI-12(t-1) | 0.031 / 0.427 / 0.010 | 0.968 | dry-year FBR vs P3-B4m: +0.0009 (rel +1%, CI +0.0001..+0.0018) | PASS / NOT_SUPPORTED |
| P3-B4t -> P3-B4t@v2 | B4m + terrain | 0.032 / 0.418 / 0.009 | 0.978 | dry-year FBR vs P3-B4m: -0.0010 (rel -1%, CI -0.0034..+0.0014) | PASS / NOT_SUPPORTED |

Two things reduce historical false built-up: temporal context (B4 vs B1: -49 % pooled dry-year FBR) and training labels that span many years (B1m-B3m vs B1-B3: -39 % to -41 %; on top of the 5-year window, B4m vs B4: -19 %). Drought context (SPI) and terrain add nothing on top of B4m. **Gate 2 (>= 25 % relative reduction, CI excluding 0, built recall drop <= 0.05) is PASSED by P3-B4** — but Baramati still shows dry-year FBR > 0.4 with every tree model (the Transformer P3-F3 reaches 0.18, still > 0.10), so the reconstruction there is not defensible. Rule inconsistency to note: B2-B4 were scored with the Gate-2 threshold (>= 25 % relative), so P3-B3 (-19 %, CI excluding 0) is INCONCLUSIVE, whereas the @v2 re-scoring of the m-variants used 'lower with CI excluding 0', so P3-B4m@v2 (-19 %) is SUPPORTED.

The id column shows the original record -> the corrected record whose status/outcome is shown. Records P3-B1m...B4m, P3-B5m@v2 and P3-B4t were first scored against P3-B1m instead of their registered comparators; they are marked INVALID and re-scored as @v2/@v3 from the saved predictions (the original P3-B5m FAILED on a feature-routing bug).

## Drought, normal and wet years (group D)

Pooled over windows, B1 dry - normal FBR is +0.031 [-0.018, +0.089] raw and +0.004 [-0.012, +0.025] era-matched; wet - normal -0.125 [-0.146, -0.100] raw, -0.047 [-0.066, -0.028] era-matched. Outcomes P3-D2 PASS / NOT_SUPPORTED, P3-D3 PASS / NOT_SUPPORTED. Pooled over windows there is no detectable dry-year degradation; two thirds of the window dry-years fall in 1993-2004, so raw dry-normal contrasts mix drought with sensor era and with distance from the 2021 label epoch.

Post-hoc (exploratory, not registered) per-window era-matched contrasts for B1: khadakwasla_mutha dry era_matched -0.007 [-0.029, +0.030]; baramati_agri dry era_matched +0.066 [+0.040, +0.099]; mulshi_ghats dry era_matched -0.019 [-0.027, -0.010]; khadakwasla_mutha wet era_matched -0.061 [-0.106, -0.041]; baramati_agri wet era_matched -0.024 [-0.049, -0.007]; mulshi_ghats wet era_matched -0.049 [-0.075, -0.009]. Baramati (agricultural, semi-arid) is the only window with a positive dry-year effect: its raw excess (+0.246 [+0.197, +0.271]) shrinks to about a quarter when era-matched, i.e. most of the apparent 'drought' false built-up coincides with era (sensor and distance from the label year) rather than with dryness. Wet years lower FBR in every window. Association with the SPI proxy only — no causal claim.

## Why change timing fails (P3-K1)

Phase-2 best detector (post-monsoon NDVI, PELT) on the same 3 076 urbanised cells: recall within +-2 y of WSF 0.390. Attribution of misses (priority order fixed in advance): no_signal 41%, reference_disagreement 20%, sensor_transition 19%, detector_missed 10%, detector_mistimed 7%, noisy_series 1%, gradual 0%, insufficient_obs 0%. Non-detector share 82% -> PASS / SUPPORTED. Recall by flag (with / without): insufficient_obs 0.00/0.39 (n=1); no_signal 0.17/0.49 (n=932); short_pre_period 0.00/0.39 (n=1); reference_disagreement 0.39/0.39 (n=1109); gradual 0.60/0.39 (n=10); sensor_transition 0.00/0.55 (n=887); noisy_series 0.35/0.39 (n=164).

## Multi-criteria selection and era-aware product (P3-O1)

Selected (configs/phase3.yaml rule): **P3-F3**. Product: `results/phase3/product/<window>/recon_<year>.tif` (8 bands: four calibrated class probabilities, most likely class, normalised entropy, clear-observation count, P(class differs from previous year); era tag per file).

| window | FBR / built recall early_historical | FBR / built recall landsat_dominant | FBR / built recall sentinel_dense | FBR / built recall current | block MAE vs WSF by era |
|---|---|---|---|---|---|
| khadakwasla_mutha | 0.034 / 0.964 | 0.003 / 0.949 | 0.007 / 0.974 | 0.033 / 0.976 | early 0.115, lands 0.114, senti 0.103, curre — |
| baramati_agri | 0.403 / 0.942 | 0.069 / 0.861 | 0.017 / 0.943 | 0.040 / 0.955 | early 0.433, lands 0.076, senti 0.100, curre — |
| mulshi_ghats | 0.045 / 0.808 | 0.001 / 0.825 | 0.002 / 0.925 | 0.004 / 0.910 | early 0.022, lands 0.003, senti 0.004, curre — |

Mean normalised entropy by era: baramati_agri: early 0.177, lands 0.165, senti 0.097, curre 0.111; khadakwasla_mutha: early 0.173, lands 0.119, senti 0.119, curre 0.103; mulshi_ghats: early 0.118, lands 0.058, senti 0.058, curre 0.060.

**Gate 6 NOT PASSED** (G1 not passed; dry-year FBR <= 0.10 everywhere: False; block MAE <= 0.10 everywhere: False). The product is a research artefact with agreement metrics, not a validated land-cover history; district-wide scaling (P3-O3) is not run.

## Error taxonomy (P3-O2)

| error type | n cell-years | label_conflict | sensor_qa | drought | seasonal | ambiguity | temporal_transfer | model |
|---|---|---|---|---|---|---|---|---|
| false_built_never_settled | 21787 | 1% | 1% | 12% | 2% | 13% | 66% | 5% |
| missed_built_stable_built | 1566 | 0% | 4% | 16% | 2% | 51% | 24% | 3% |
| missed_water_deep_water | 3663 | 0% | 19% | 24% | 2% | 0% | 53% | 1% |

Rule-based, priority order fixed before counting; an error is attributed to the first applicable category, so shares depend on the order.

## Window-wide built share (descriptive; the Phase-2 '75 %' measured the same way)

| window | 2021-config XGB 1990 | P3-F3 product 1990 | WSF settled by 1990 | GHSL 1990 mean built fraction |
|---|---|---|---|---|
| khadakwasla_mutha | 0.74 | 0.50 | 0.206 | 0.067 |
| baramati_agri | 0.66 | 0.63 | 0.024 | 0.011 |
| mulshi_ghats | 0.14 | 0.07 | 0.001 | 0.001 |

| window | 1990 | 1993 | 1995 | 2000 | 2005 | 2010 | 2015 | 2021 | 2025 |
|---|---|---|---|---|---|---|---|---|---|
| khadakwasla_mutha product / WSF | 0.50 / 0.21 | 0.31 / 0.23 | 0.24 / 0.26 | 0.21 / 0.33 | 0.30 / 0.39 | 0.30 / 0.46 | 0.41 / 0.52 | 0.43 | 0.47 |
| baramati_agri product / WSF | 0.63 / 0.02 | 0.36 / 0.03 | 0.27 / 0.04 | 0.18 / 0.05 | 0.08 / 0.07 | 0.13 / 0.08 | 0.18 / 0.10 | 0.14 | 0.19 |
| mulshi_ghats product / WSF | 0.07 / 0.00 | 0.01 / 0.00 | 0.00 / 0.00 | 0.00 / 0.00 | 0.00 / 0.00 | 0.00 / 0.00 | 0.00 / 0.00 | 0.00 | 0.01 |

The Phase-2 '75 % of the corridor built-up in 1990' is reproduced by the re-fitted 2021 configuration (0.74). The selected product model halves the never-settled false built-up rate but still maps half the corridor and 63 % of Baramati as built in 1990, and its window-wide built share FALLS from 1990 to 2000 while WSF rises — an implausible history. The never-settled frame is therefore a lower bound on false built-up: it excludes the mixed and peri-urban cells where confusion is most likely. 1990-1991 are also edge years for 5-year windows (two missing neighbours).

## Urban history

No historical urban map is produced as a finding. The only urban-history statement supported is agreement with WSF-Evolution (Tier B) on TEST blocks (built recall, block MAE above); Phase-2 WSF outputs built before the GDAL nodata fix were never reused (audit: 0 contaminated experiments).
