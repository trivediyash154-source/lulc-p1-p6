# Phase 4 — existing land-cover / built-up / water products

_Availability probed live on 2026-10-02T12:18:47Z (`scripts/phase4_product_availability.py`). Method/limitation notes come from the producers' documentation and are re-checked against the user guides when acquired._

## 1. Availability and suitability

| product | resolution | period | classes | status here | role | main limitation for Pune |
|---|---|---|---|---|---|---|
| GLC FCS30D | 30 | 1985, 1990, 1995 (5-yearly) + annual 2000-2022 | 35 fine classes (LCCS-based) / 10 basic | ACQUIRABLE | benchmark (independent) | class definitions differ from ours (impervious vs built-up; cropland subclasses); temporal consistency enforced by change detection; producer accuracy is global, not Pune-specific |
| GISA 2.0 | 30 | first year of impervious surface 1972-2021 | impervious (first-year), non-impervious | ACQUIRABLE | benchmark (independent) | impervious != built-up land cover; irreversible by construction; early years sparse |
| GAIA | 30 | annual impervious 1985-2018 | impervious first-year | NEEDS_USER_GEE | benchmark (independent) | impervious only; irreversible |
| Dynamic World | 10 | 2015-06 onwards, per Sentinel-2 image | 9 class probabilities | NEEDS_USER_GEE | benchmark (independent) | per-scene probabilities need temporal compositing; S2-based (shares evidence with WorldCover/Esri/our gold chips); no pre-2015 history |
| GHSL BUILT S R2023A | 100 | 1975-2030 5-yearly (2025/2030 projected) | built-up surface fraction | IN_REPO_WINDOWS; ACQUIRABLE_DISTRICT | benchmark (independent) | fractional, 100 m (Mollweide); epochs are modelled |
| WSF Evolution | 30 | settlement extent 1985-2015 (first year) | settled / not | IN_REPO_WINDOWS; ACQUIRABLE_DISTRICT | benchmark (independent) | settlement extent (includes mixed settled cells); ends 2015 |
| ESA CCI LC | 300 | [['1992-01-01T00:00:00Z', '2020-12-31T23:59:59Z']] | 22 LCCS classes | ACQUIRABLE | benchmark (independent) | 300 m: too coarse for 30 m pixel comparison; area trends only |
| ESA WorldCover | 10 | [['2020-01-01T00:00:00Z', '2021-12-31T23:59:59Z']] | 11 | IN_REPO (windows + G240 district mode) | NOT independent (silver source) | silver-label source (used for training) -> NOT independent of our models |
| Esri IO LULC | 10 | [['2017-01-01T00:00:00Z', '2024-01-01T00:00:00Z']] | 9 | IN_REPO (windows) | NOT independent (silver source) | silver-label source (2020-21) -> NOT independent; other years usable as Tier C |
| JRC GSW | 30 | [['1984-03-01T00:00:00Z', '2020-12-31T11:59:59Z']] | water occurrence | IN_REPO (windows + G240) | benchmark (independent) | surface water only |
| ALOS FNF | 25 | [['2015-01-01T00:00:00Z', '2020-12-31T23:59:59Z']] | forest / non-forest | ACQUIRABLE | benchmark (independent) | L-band SAR forest definition |
| MS Building Footprints | vector | [['2014-01-01T00:00:00Z', None]] | — | ACQUIRABLE (modern built-up check) | benchmark (independent) | undated per building; modern only |
| India Decadal LULC 1985 1995 2005 | 100 | 1985, 1995, 2005 | national classification | NEEDS_USER_EARTHDATA | benchmark (independent) | 100 m; Landsat/IRS visual-digital interpretation; class scheme differs |
| NRSC LULC 50K | 1:50,000 | 2005-06, 2011-12, 2015-16 | — | VIEW_ONLY (useful for human interpreters as context, not as data) | context | licence restricts redistribution |

## 2. Decisions

* GLC_FCS30D (1985-2022, 30 m) is the main independent historical benchmark: its own validation is global, so it is a reference product, not truth.
* GISA 2.0 (impervious first-year 1972-2021) stands in for GAIA until Earth Engine access exists; both describe impervious surface, not our 'built-up' land-cover class — definitions are mapped explicitly before comparison.
* WorldCover and Esri 2020-21 trained our silver labels: they are NOT independent of our models and are reported only as Tier C.
* Dynamic World and GAIA need the user's Earth Engine project; India decadal LULC (1985/1995/2005) needs a NASA Earthdata login.
* NRSC LULC 50K is view-only — useful as context for human interpreters, not as data.

## 3. Benchmark results

See `docs/existing_product_benchmark.md` (district trajectories, pairwise agreement, consensus/disagreement, temporal consistency, our model vs products). Gate G3 status is in `docs/phase4_readiness_gate.md`.
