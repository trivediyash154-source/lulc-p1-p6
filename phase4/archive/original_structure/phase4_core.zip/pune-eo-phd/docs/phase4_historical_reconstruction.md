# Phase 4 — historical reconstruction

## 1. Benchmark for every epoch (built-up)

| product | 1990 | 2000 | 2010 | 2015 | 2020 |
|---|---|---|---|---|---|
| WSF Evolution settlement | 268 | 455 | 713 | 820 | — |
| GISA2 impervious | 173 | 327 | 494 | 624 | 745 |
| GLC FCS30D impervious | 182 | 385 | 746 | 871 | 915 |
| GHSL BUILT S surface | 117 | 191 | 286 | 350 | 424 |
| ESA CCI urban 300m | — | 107 | 304 | 364 | 470 |
| Esri built | — | — | — | — | 1676 |
| WorldCover built | — | — | — | — | 722 |

No product agrees with another better than F1 0.43 on 1990 built-up cells (`docs/existing_product_benchmark.md`). Historical built-up has a wide external envelope; Gate G5 uses this envelope (± 0.02 of district share), not a single product.

## 2. Whole-area test of the Phase-3 reconstruction

Selected Phase-3 model (P3-F3): 1990 built share 0.50 (corridor) and 0.63 (Baramati) vs 0.01-0.21 in WSF, GISA, GLC_FCS30D; built share falls from 1990 to 2000 while all products rise. It fails the whole-area test and is **not accepted**, whatever its sampled-pixel scores.

## 3. Causes — evidence so far

| candidate cause | evidence | status |
|---|---|---|
| sensor differences (TM vs OLI) | PIF: higher red, lower NDVI in L5-dominated years (P4-E1; confounded with time, 3-8 years per regime) | associated (exploratory) -> confirmatory P4-C2@v2 |
| sparse early observations | 1990-1998 dry 2-6 clear obs; post-monsoon 1-2 in many years | documented; 1990-1991 are also edge years for 5-year windows |
| training-label mismatch (2020-21 labels applied to 1990) | historical failure grows with distance from label epoch (P3-O2: 66 % of false built-up attributed to 'temporal transfer' by a rule-based priority order) | associated (Phase 3) -> confirmatory P4-C1@v2 |
| easy-cell / class-support bias | corridor agriculture 8 % labelled; our corridor agri share far below GLC_FCS30D (P4-X2) | associated (audit + P4-X2) -> P4-C1@v2 |
| dry agriculture / soil brightness | Baramati raw dry-year excess +0.25, era-matched +0.07 (post-hoc) | partly; confounded with era |
| seasonality | post-monsoon composites weak before 2013 | open |
| mixed pixels / resolution | silver excludes boundary cells (edge share 7-25 % vs 65-72 %) | open - needs gold with dominant-share field |
| class-definition differences | products differ up to 4x for 'built-up' | documented; mapping explicit |
| historical reference limitations | products agree F1 <= 0.43 in 1990 | documented |
| model shortcut learning | agreement with AI 0.92 on consensus cells vs 0.76 off-consensus (Tier C) | suspected -> gold |
| temporal domain shift | Phase-3 transfer and era results | -> P4-C3 |

## 4. Whole-area test protocol (frozen)

Per epoch: class shares, transition matrices, change, spatial distribution; compared with the independent-product envelope, built plausibility (no district decline > 10 %), and gold. Code: `src/pune_eo/evaluation4/history.py` (unit-tested). Gate G5: `configs/phase4_evaluation_protocol.yaml`.

## 5. Status

G5 FAIL: no gold for any historical epoch; the only reconstruction available fails the whole-area test.
