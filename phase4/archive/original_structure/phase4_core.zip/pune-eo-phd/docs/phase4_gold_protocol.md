# Phase 4 — human gold protocol (Tier A)

Written before any interpretation. Supersedes nothing: the Phase-3 window sample (558 points) remains a separate benchmark-window sample.
**No AI model, product, or synthetic process may generate Tier-A labels.** GHSL, WSF, GISA, GLC_FCS30D, Dynamic World, WorldCover and Esri are never converted into gold.

## 1. Sample

* Population: 30 m cells (Landsat lattice, EPSG:32643) inside the Pune District boundary.
* Frame (design v2, protocol v2): cells in **validation blocks** — 6 km blocks hashed with salt `phase4-v1` (hash threshold 30 %; realised 27.6 % of blocks, 26.7 % of district area) — **excluding the three Phase-3 benchmark windows plus 2 km**
  (their train/val blocks trained the Phase-3 models). Validation blocks are never used for training, tuning, calibration fitting or model selection, and training/tuning may only use cells >= 2 km from any validation block
  (`sampling_design/training_eligible_30m.tif`). Built-up indicator correlation can reach ~4 km in the corridor, so some residual spatial dependence remains and is disclosed.
* Strata (mutually exclusive, fixed priority order; defined from district layers that are independent of OUR models — note Esri/WorldCover are silver-label sources and GLC_FCS30D a benchmark product, used only to stratify, never as labels): permanent water; reservoir margin (≤ 1 km); urban core settled by 2000;
  peri-urban transforming 2001-2021; river corridor (≤ 300 m); product disagreement 2020 (GLC_FCS30D vs Esri vs WorldCover); forest/natural vegetation on slopes ≥ 8°; open natural vegetation on the plateau;
  irrigated agriculture; rainfed/dry agriculture; bare/sparse/other; built (consensus, remaining); residual.
* Allocation: target 600, floor 30 per stratum (strata < 0.25 % of the district: at most 5 points), √area allocation with ×1.6 oversampling of hard strata (disagreement, transforming, reservoir margin, river corridor, urban core, dry agriculture);
  at most 4 points of a stratum per block. Drawn: 641 points in 125 blocks. Area/accuracy estimates use stratum-area weights; confidence intervals use the stratified BLOCK bootstrap (blocks as primary sampling units).
  'river_corridor_le300m' also captures ponds and tanks.
* Regions for leave-one-region-out: CHIRPS 1991-2020 mean annual rainfall zones (wet west ≥ 1200 mm; transition 700-1200; dry east < 700).
* Files: `data/labels/gold/phase4/sampling_design/` (design.json, strata, validation blocks, regions), key in `_key/` (**evaluator only**).

## 2. Blindness

Interpreters receive only `blind/form_interpreter_A.csv` (all points) or `blind/form_interpreter_B.csv` (25 % subset, re-shuffled) and `blind/phase4_gold_cells.kml`. The key is tracked in the repository,
so blindness depends on process: interpreters get the `blind/` folder only, never the repository. Design v1 (672 points) was superseded before any interpretation (`v1_superseded/`).
They never see the key, strata, regions, product layers, model predictions or confidences, and A and B never see each other's forms.

## 3. What to record per point and epoch (2020, 2000, 2010, 1990 — in this order)

| field | values |
|---|---|
| dominant_class | built_up, agriculture, natural_vegetation, water, bare_sparse, other, **uncertain**, **ambiguous**, **unavailable** |
| dominant_share_3bins | `>=75`, `50-75`, `<50` (share of the 30 m cell covered by the dominant class) |
| second_class | second class present in the cell, or `none` |
| confidence_1to3 | 3 unambiguous, 2 likely, 1 weak |
| imagery_source | e.g. `GEP_historical` (Google Earth Pro historical imagery), `Landsat_context`, `field` |
| imagery_date | date of the VHR image actually used (YYYY-MM-DD) — must lie within ±2 years of the epoch, else `unavailable` |
| status | `done`, `unavailable` (no image within ±2 y), `skipped` |
| notes | free text |

* **Do not force a class.** `unavailable` when no usable image exists for the epoch (expected for many 1990 points); `uncertain` when the image exists but does not decide; `ambiguous` for genuine mixtures or definition problems.
* Unit: the 30 m cell (yellow square in the KML); the class covering the largest share of the cell.
* Decision rules (unchanged from Phase 3): built_up = roofs, paved surfaces, compounds; agriculture = field parcels, orchards, fallow fields with parcel geometry; natural_vegetation = forest,
  scrub, grassland without parcels; water = open water at the image date (reservoir drawdown: label what the image shows and note the season); bare_sparse = rock, quarries, construction sites, bare soil without parcels.

## 4. Double interpretation, agreement, adjudication

* Interpreter B independently labels the 25 % subset. Agreement per epoch: Cohen's κ (A vs B), Krippendorff's α (missing allowed) — `pune_eo.labels.gold_qa`.
* Raw forms are saved unchanged in `raw_interpreter_A/` and `raw_interpreter_B/` with the interpreter id, software, and date; they are never edited afterwards.
* Disagreements are adjudicated by a third reviewer (or joint review, recorded as such) into `adjudicated/` with columns: anon_id, epoch, label_A, label_B, adjudicated_label, rule, reviewer, date.
  Both original labels are preserved; adjudication never silently overwrites.
* Freeze: when a pass is complete, `metadata/freeze_<pass>.json` records SHA-256 of the raw files; the evaluation code refuses unfrozen files.

## 5. Gate G2 (configs/phase4_evaluation_protocol.yaml)

≥ 80 % of design points labelled (including legitimate `unavailable`) for 2020 and 2000; ≥ 20 % double interpreted with κ ≥ 0.6; adjudication logged.

## 6. Effort estimate (for planning, not a result)

641 points × 4 epochs = 2 564 interpretations + 160 double × 4 = 640, about 3 200 in total. At 1-2 minutes each (Google Earth Pro historical slider), roughly 53-107 interpreter-hours.
Recommended order: 2020 (A, then B), then 2000, then 2010, then 1990.
