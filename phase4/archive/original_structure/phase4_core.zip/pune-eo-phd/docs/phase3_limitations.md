# Phase 3 — limitations

Listed so that no Phase-3 number is read beyond what it supports.

## Reference data

1. **No Tier-A gold.** 0 of 558 points have human VHR labels; Gate 1 and therefore Gate 6 cannot pass. Every 'accuracy' in Phase 3 is agreement with Tier B (independent products) or Tier C (silver, provisional AI).
2. **Provisional AI interpretation is Tier C.** It abstained on 22% of points (concentrated in agriculture and no-silver strata), so agreement is measured on the easier cells; abstention rates differ between model instances (chi-square p ~ 4e-5); the repeat pass disagrees only about abstaining. It shares the Sentinel-2 evidence family with WorldCover/Esri.
3. **Tier-B products have their own errors** (WSF-Evolution early-year timing, GHSL 90 m mixing, JRC water occurrence). 'Never-settled' cells are defined by agreement of three products and may still contain small structures; 'false built-up' is disagreement with that frame.
4. **Silver labels are easy, pure cells** (two-product consensus). Within-window silver agreement (0.92-0.99 for optical/multimodal models) is an upper bound of little use for mixed or rare cells.
5. **Multi-year training labels are Tier D** (silver 2021 extended along change-free segments of the cell's own NDVI series) — used only for training, never evaluated against.

## Design and statistics

6. Three benchmark windows only (urban/peri-urban corridor, agricultural Baramati, forested Mulshi ghats); held-out-window results are three data points per configuration.
7. Rare classes dominate held-out macro-F1 (Baramati natural vegetation: 94 silver cells; Mulshi built-up: 367). Per-class F1 is always reported next to macro-F1.
8. Block bootstraps resample 3 km blocks within windows; spatial autocorrelation beyond 3 km and between windows is not modelled. McNemar p-values assume independence and are secondary.
9. One seed per configuration for most models (3 seeds for label fractions); seed variance of deep models is not characterised.
10. Several comparisons were run; CIs are per comparison (no multiplicity correction). Small but 'significant' effects (e.g. two-source transfer +0.006 to +0.012) are practically negligible.
11. A scripting error first scored the multi-year B variants against the wrong comparator; those records are INVALID and re-scored as @v2 from the same predictions. P3-B5m failed on a feature bug and was re-run as @v2, whose outcome was then itself scored against the wrong comparator (INVALID) and re-scored as @v3.
12. The per-window drought contrasts are post hoc (exploratory).

## Data

13. **Drought test power:** only one SPI-dry year in the S1 era (2019, one window); SAR drought robustness is untested. two thirds of window dry-years fall in 1993-2004 (confounded with TM / early ETM+ / SLC-off and with distance from the 2021 label year) — era-matching reduces, not removes, confounding.
14. **Harmonisation does not transfer:** s2_to_oli_v1 leaves window-specific residuals (Baramati NIR -0.025, SWIR1 -0.024; Mulshi NDVI -0.035, 4 pairs); Landsat+S2 fusion outside the corridor carries this bias.
15. Early era (1990-1998) is TM-only with fewer clear observations; reconstruction uncertainty there is highest and Tier-B frames (WSF from 1985) are least certain.
16. 2025 S1 archive is incomplete on Planetary Computer; 2026 is a partial year.

## What is not claimed

17. No crop types, no crop-type accuracy (no crop labels). Cropping-regime clusters at 10 m are weak (silhouette < 0.25) and are not crop types.
18. No flood detection product: one observable event (Baramati, May 2025) with an UNVALIDATED candidate extent; no flood AI.
19. No historical urban map as a finding; no future scenarios (locked).
20. No causal statements: SPI, rainfall and terrain associations are associations.
21. The era-aware reconstruction product is NOT validated (Gate 6 not passed) and is not scaled district-wide.
22. Outcome-logic caveats found by the independent verification are listed in docs/phase3_results.md section 15 (gap vs cross scoring in E, inconsistent B thresholds, K1 category scope, E5 registered after the C results).
23. The never-settled frame is a lower bound on false built-up (it excludes mixed and peri-urban cells); window-wide built shares of the selected product are implausible before 2000 (docs/historical_reconstruction.md).
24. The exact wording of the Phase-3 brief's figure list (section 34), question list (section 42) and checklist (section 43) was not available verbatim when the documents were written; figures, answers and checklist are organised by the brief's required components.
