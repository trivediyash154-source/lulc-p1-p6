# Uncertainty calibration on unseen landscapes (Phase 3, group H; K2)

Phase 2 found split-conformal (LAC, alpha 0.1) coverage of 0.508 / 0.423 / 0.742 on held-out windows (the '42-74 %' calibration failure). Phase 3 re-tests calibration where it matters: leave-one-window-out, XGBoost on Landsat seasonal + terrain (B3T) and the S1 variant (C4), every calibration map and conformal threshold fitted on SOURCE validation blocks; the map used for Gate 5 is selected on source data only (half A of the source validation blocks).

## B3T

| held-out window | agreement with silver | ECE raw | temperature | isotonic | Platt | ensemble (5) | source-selected map | Brier raw | NLL raw |
|---|---|---|---|---|---|---|---|---|---|
| khadakwasla_mutha | 0.908 | 0.064 | 0.030 | 0.027 | 0.006 | 0.062 | none | 0.151 | 0.352 |
| baramati_agri | 0.913 | 0.046 | 0.023 | 0.346 | 0.215 | 0.032 | none | 0.137 | 0.283 |
| mulshi_ghats | 0.845 | 0.122 | 0.090 | 0.187 | 0.173 | 0.097 | platt | 0.269 | 0.609 |

| held-out window | Phase-2 LAC | LAC coverage (set size, empty) | APS coverage (set size) | class-conditional LAC | LAC on source half A | third-landscape calibration: coverage (set size) |
|---|---|---|---|---|---|---|
| khadakwasla_mutha | 0.508 | 0.645 (0.65, 0.35) | 0.933 (1.06) | 0.648 | 0.925 | train baramati_agri: own 0.30 vs third 0.92 (1.49); train mulshi_ghats: own 0.34 vs third 0.88 (0.99) |
| baramati_agri | 0.423 | 0.630 (0.64, 0.36) | 0.944 (1.08) | 0.405 | 0.950 | train khadakwasla_mutha: own 0.61 vs third 0.94 (1.09); train mulshi_ghats: own 0.14 vs third 0.94 (1.07) |
| mulshi_ghats | 0.742 | 0.628 (0.69, 0.31) | 0.826 (1.10) | 0.503 | 0.879 | train khadakwasla_mutha: own 0.65 vs third 0.85 (1.00); train baramati_agri: own 0.14 vs third 0.89 (1.32) |

## C4

| held-out window | agreement with silver | ECE raw | temperature | isotonic | Platt | ensemble (5) | source-selected map | Brier raw | NLL raw |
|---|---|---|---|---|---|---|---|---|---|
| khadakwasla_mutha | 0.946 | 0.034 | 0.012 | 0.006 | 0.005 | 0.032 | none | 0.088 | 0.197 |
| baramati_agri | 0.974 | 0.007 | 0.008 | 0.182 | 0.083 | 0.004 | none | 0.039 | 0.072 |
| mulshi_ghats | 0.879 | 0.100 | 0.080 | 0.161 | 0.148 | 0.088 | temperature | 0.220 | 0.600 |

| held-out window | Phase-2 LAC | LAC coverage (set size, empty) | APS coverage (set size) | class-conditional LAC | LAC on source half A | third-landscape calibration: coverage (set size) |
|---|---|---|---|---|---|---|
| khadakwasla_mutha | — | 0.655 (0.66, 0.34) | 0.961 (1.04) | 0.692 | 0.913 | train baramati_agri: own 0.33 vs third 0.95 (1.43); train mulshi_ghats: own 0.36 vs third 0.87 (0.92) |
| baramati_agri | — | 0.692 (0.69, 0.31) | 0.986 (1.04) | 0.392 | 0.931 | train khadakwasla_mutha: own 0.74 vs third 0.99 (1.02); train mulshi_ghats: own 0.18 vs third 0.95 (0.96) |
| mulshi_ghats | — | 0.661 (0.66, 0.34) | 0.903 (1.07) | 0.664 | 0.892 | train khadakwasla_mutha: own 0.66 vs third 0.80 (0.82); train baramati_agri: own 0.09 vs third 0.86 (1.16) |

## What fails and why

* **Coverage collapses, ECE does not.** Source models are almost always right on source validation cells, so the LAC threshold is tiny (q < 0.025): a class enters the set only above p >= 0.975. On a new landscape a third of the cells have no class above that threshold -> EMPTY sets (31-36 %) and coverage 0.63-0.69. Top-label ECE degrades less because agreement and confidence fall together, but source-selected maps still miss ECE <= 0.05 in some windows (B3T Mulshi 0.17 after a source-chosen Platt map, worse than raw). Calibration on the source therefore does not transfer: **Gate 5 NOT passed** (the gate pair source-selected map + LAC was fixed in the docstring of scripts/run_phase3_calibration.py, committed 2026-10-02 09:16 UTC in 1d1e746, before the calibration run; configs/phase3.yaml itself only says '90 % conformal sets'). Registry outcomes: P3-H2 PASS / NOT_SUPPORTED, P3-H3 PASS / NOT_SUPPORTED, P3-H4 PASS / NOT_SUPPORTED. Note: the P3-H2 registry result string lists the minimum ECE over maps, i.e. a map chosen on the TARGET — optimistic; the source-selected values are in the tables above.
* **APS** (randomised, cumulative-mass sets) reaches 0.83-0.99 coverage with sets of ~1.1 classes; it was not the pre-declared gate method and is reported as a secondary result.
* **Third-landscape calibration** — model trained on one source window, threshold fitted on the other source window — restores coverage to 0.80-0.99 (>= 0.85 in most cases) where source-calibrated thresholds give 0.09-0.74. The calibration set must contain landscape shift, not just held-out pixels of the training landscape. This is the most useful positive finding of group H.
* Isotonic and Platt maps fitted on the source can make held-out calibration WORSE (Baramati isotonic ECE 0.35); temperature scaling is the most stable map.

Against the provisional AI interpretation (Tier C, 2021, non-abstained points) the Phase-3 2021 model has ECE 0.085, Brier 0.186, mean confidence 0.973 vs agreement 0.892 — over-confident.

## Probabilistic change timing (P3-K2)

Posterior over the transition year (absorbing not-built -> built model on temperature-calibrated annual P(built)): 80 % credible sets contain the WSF year for 5.2% of urbanised TEST cells (9.4% within +-1 y; mean set 1.2 years). P(transition 1991-2026): ECE 0.159, Brier 0.152, AUC 0.627; mean P(change) urbanised 0.16, never-settled 0.05, stable-built 0.00. Outcome PASS / NOT_SUPPORTED. The independence assumption between annual errors makes these posteriors over-confident by construction.

