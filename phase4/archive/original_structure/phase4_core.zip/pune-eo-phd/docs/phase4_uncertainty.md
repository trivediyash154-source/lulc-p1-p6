# Phase 4 — uncertainty and abstention

## Evidence so far (Phase 3, Tier C)

Held-out ECE 0.03-0.12; source-calibrated conformal sets cover only 0.63-0.69 with 31-36 % empty sets; calibration on a third landscape restores 0.80-0.99 coverage (`docs/uncertainty_calibration.md`).

## Phase-4 operational rule (to be validated on gold)

1. Calibrate with temperature scaling fitted on non-target regions (third-landscape principle). 2. Abstain where calibrated max-probability < tau, tau chosen on tuning blocks for a target coverage (e.g. 80 %). 3. Report accuracy-at-coverage (0.5/0.7/0.8/0.9/1.0), AURC, class-specific and spatial abstention maps. Code: `pune_eo.evaluation4.metrics.selective`, `abstain_by_threshold` (unit-tested).

## Pre-registered

P4-C5@v2 (Gate G7): ECE <= 0.05 and 90 % coverage >= 0.85 per region and era; abstention on the least-confident 20 % raises gold accuracy.

## Status

G7 PARTIAL: characterised in 3 windows against silver; not validated on gold.
