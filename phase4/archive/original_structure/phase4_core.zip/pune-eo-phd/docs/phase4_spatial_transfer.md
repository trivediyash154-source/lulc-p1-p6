# Phase 4 — spatial transfer

## Evidence so far (Phase 3, 3 windows, Tier C)

Within-window silver agreement 0.94-0.98; leave-one-window-out 0.69-0.86; single-source transfer gaps up to 0.29; SAR and terrain raise unseen-window agreement in the S1 era; unsupervised adaptation fails; 100-250 target labels per class close about half of the gap (`docs/domain_shift.md`). These are three windows covering 5.8 % of the district.

## Phase-4 design (protocol v2, frozen)

* Units: three CHIRPS rainfall regions (wet west, transition, dry east) for leave-one-region-out (v1 text said physiographic zones + windows; corrected in v2 before any run); 6 km hashed blocks; validation blocks never used for training; training only >= 2 km from validation blocks.
* Confirmatory tests pre-registered: P4-C4@v2 (LORO gold macro-F1 >= 0.70, gap <= 0.10 — Gate G6) and P4-C6@v2 (optical+SAR+terrain vs optical in LORO, S1 era).

## Status

G6 FAIL until the district cube and gold exist; no district-scale generalisation is claimed.
