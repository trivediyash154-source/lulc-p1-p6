# Phase 4 — water

## Separated concepts and what exists for each

| quantity | what it is | data in repo | status |
|---|---|---|---|
| surface-water extent | area covered by open water at a time | JRC GSW occurrence/recurrence/seasonality (static 1984-2021 aggregates), our MNDWI composites (3 windows) | district time series needs JRC monthly history (Earth Engine) or the district cube |
| water level | reservoir/river stage | none | needs dam authority / CWC data |
| storage | reservoir volume | none | needs WRD Maharashtra reservoir storage bulletins or level-area-volume curves |
| groundwater | aquifer levels | none | needs CGWB / GSDA well data; NOT observable by optical imagery |
| water availability / demand | hydrological balance / use | none | out of scope without official data |

## Rules

* No groundwater, storage or level claims from optical imagery.
* Water masks are validated against independent observations (JRC monthly history, gauge-linked extents) — not against our own composites.

## Status

Inventory only. A district surface-water extent series is feasible once the district cube (or JRC monthly history via Earth Engine) is available.
