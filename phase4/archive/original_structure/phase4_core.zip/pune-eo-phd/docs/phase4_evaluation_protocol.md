# Phase 4 — evaluation protocol (frozen before experimentation)

Machine-readable protocol: `configs/phase4_evaluation_protocol.yaml` (**version 2**; v1 archived unchanged in `configs/phase4/evaluation_protocol_v1_frozen.yaml`). Frozen: `src/pune_eo/evaluation4/{metrics,stats,history,protocol}.py`,
`src/pune_eo/calibration/{metrics,conformal}.py` and the protocol YAML itself (minus its `frozen:` block); both SHA-256 values are written by `pune_eo.evaluation4.protocol.freeze()` and checked by `verify_frozen()`.
Unit tests on synthetic cases: `tests/test_evaluation4.py` (15 tests; before the v1 freeze they found one real defect — default arguments bound at import time in the protocol module).

## v1 -> v2 (independent verification, before any confirmatory run)

An independent read-only verification of v1 found: (1) downstream confirmatory tests referred to a 'selected' arm with no selection rule, which would have selected on validation gold;
(2) the LORO regions in the v1 text (physiographic zones + windows) differed from the design (rainfall zones); (3) no buffer between validation and training areas, and 38 design-v1 points inside the
Phase-3 windows (24 in Phase-3 training blocks); (4) point-level bootstrap despite up to 20 points per block; (5) the YAML thresholds and the gating code were not hashed; (6) the G8 check was not automated.
v2 fixes all six; the v1 confirmatory records P4-C1..C6 were marked SUPERSEDED and re-registered as @v2 before execution. No confirmatory result existed at the time of the change.

## Why each rule exists (Phase-3 lessons)

| rule | Phase-3 failure it prevents |
|---|---|
| macro means over classes present in the reference only | Baramati 'within' macro-F1 deflated by a class with no test cells (0.736 vs 0.982) |
| every hypothesis names its comparator; decision rule fixed in the protocol | six records scored against the wrong comparator (INVALID); E-group scored on cross-window values instead of the gap |
| one threshold rule for a family | P3-B3 (-19 %) INCONCLUSIVE while P3-B4m@v2 (-19 %) SUPPORTED |
| confirmatory records pin protocol version + code hash; registered before execution | P3-E5 (Gate 4) designed after related results were seen |
| 5 seeds, t-interval over seeds, >= 4/5 sign agreement | single-seed rankings |
| Benjamini-Hochberg q = 0.05 within each confirmatory family | many comparisons without multiplicity control |
| 6 km spatial blocks for map bootstraps; 2 km training exclusion around validation blocks; block-cluster bootstrap for the gold sample | class autocorrelation up to ~4 km exceeded the 3 km blocks; clustered sample points |
| whole-area trajectories and plausibility are part of historical validity | the never-settled frame accepted a model that maps 50 % of the corridor as built in 1990 |
| Tier C never decides a gate | 0.979 silver agreement mistaken for accuracy |
| reference labels outside the model legend count as errors | silently dropping hard cells inflates agreement |

## Thresholds (a priori)

* **G5 historical validity** — gold overall-accuracy CI lower bound >= 0.75 per claimed epoch (a common minimum for thematic maps used in change analysis), district built share inside the min-max envelope of the
  independent built products (±0.02), no district built-up decline > 10 % between consecutive epochs, plausible transitions.
* **G6 spatial generalisation** — leave-one-region-out macro-F1 lower bound >= 0.70 and gap <= 0.10 in every region.
* **G7 uncertainty** — ECE <= 0.05 and 90 % conformal coverage >= 0.85 in every region and era on gold, calibration fitted on non-target data (Phase-3 values kept for continuity).
* **G2 human validation** — >= 80 % of district design points labelled for 2020 and 2000, >= 20 % double interpreted, Cohen's kappa >= 0.6.

A negative result that is complete (all arms, all seeds, frozen evaluation) passes the label-quality gate G4: the gate tests the evidence, not the direction.
