# Spatial transfer, domain shift and adaptation (Phase 3, groups E, J, L)

Labels silver 2021 (Tier C). Within = source TEST blocks; cross = all HET silver cells (class-capped sample) of the target window. Caveat: Baramati TEST blocks contain no natural-vegetation silver cell, and macro-F1 is computed over the four model classes, so Baramati 'within' values are deflated (macro over present classes in brackets in the matrix); the Baramati-source gaps (E1r, E2) are therefore understated. Phase 2 reported 0.57-0.82 for LOWO transfer; Phase-3 re-assessment of the 2021 configuration (P3-A3): khadakwasla_mutha 0.863, baramati_agri 0.784, mulshi_ghats 0.687.

## Transfer matrix (macro-F1, XGBoost)

| source -> target | B1 within/cross | B3 within/cross | B4 within/cross | C3 within/cross | C4 within/cross |
|---|---|---|---|---|---|
| baramati_agri->khadakwasla_mutha | 0.724 (0.966) / 0.728 | 0.736 (0.982) / 0.690 | 0.743 (0.991) / 0.675 | 0.744 (0.993) / 0.739 | 0.745 (0.994) / 0.723 |
| baramati_agri->mulshi_ghats | 0.724 (0.966) / 0.504 | 0.736 (0.982) / 0.612 | 0.743 (0.991) / 0.703 | 0.744 (0.993) / 0.652 | 0.745 (0.994) / 0.666 |
| khadakwasla_mutha->baramati_agri | 0.935 / 0.697 | 0.938 / 0.728 | 0.955 / 0.753 | 0.961 / 0.772 | 0.976 / 0.875 |
| khadakwasla_mutha->mulshi_ghats | 0.935 / 0.631 | 0.938 / 0.644 | 0.955 / 0.888 | 0.961 / 0.677 | 0.976 / 0.727 |
| mulshi_ghats->baramati_agri | 0.880 / 0.631 | 0.905 / 0.670 | 0.955 / 0.726 | 0.947 / 0.775 | 0.960 / 0.790 |
| mulshi_ghats->khadakwasla_mutha | 0.880 / 0.784 | 0.905 / 0.748 | 0.955 / 0.832 | 0.947 / 0.808 | 0.960 / 0.885 |

| id | pair | B3 gap (within - cross) | cross B4 - B1 | cross C3 - B3 | status |
|---|---|---|---|---|---|
| P3-E1 | khadakwasla_mutha -> baramati_agri | +0.210 [+0.155, +0.249] | +0.056 [+0.038, +0.077] | +0.044 [+0.033, +0.061] | PASS / SUPPORTED |
| P3-E1r | baramati_agri -> khadakwasla_mutha | +0.047 [-0.178, +0.079] | -0.053 [-0.068, -0.036] | +0.049 [+0.029, +0.073] | PASS / INCONCLUSIVE |
| P3-E2 | baramati_agri -> mulshi_ghats | +0.124 [-0.085, +0.187] | +0.199 [+0.167, +0.219] | +0.039 [+0.023, +0.064] | PASS / INCONCLUSIVE |
| P3-E2r | mulshi_ghats -> baramati_agri | +0.236 [+0.108, +0.304] | +0.095 [+0.044, +0.140] | +0.105 [+0.085, +0.126] | PASS / SUPPORTED |
| P3-E3 | mulshi_ghats -> khadakwasla_mutha | +0.157 [+0.024, +0.202] | +0.048 [+0.026, +0.074] | +0.059 [+0.048, +0.073] | PASS / SUPPORTED |
| P3-E3r | khadakwasla_mutha -> mulshi_ghats | +0.294 [+0.224, +0.337] | +0.257 [+0.209, +0.291] | +0.033 [+0.019, +0.054] | PASS / SUPPORTED |

Transfer gaps are large (B3 cross macro-F1 0.61-0.75 against 0.74-0.94 within). SAR helps in all six directions; the 5-year temporal window helps in five and hurts Baramati -> Khadakwasla. Training from Baramati cannot predict natural vegetation it hardly contains (label-space shift), which caps any transfer from it.

## Two-source -> held-out (P3-E4)

two-source B3 macro-F1 on held-out: khadakwasla_mutha 0.760 (vs best single +0.012), baramati_agri 0.738 (vs best single +0.010), mulshi_ghats 0.650 (vs best single +0.006) — PASS / SUPPORTED. Small (+0.006 to +0.012) and with a CI excluding 0 in 2 of 3 windows: adding a second source landscape barely helps.

## Domain shift (P3-J1)

| features | pair | MMD^2 (perm. p) | domain AUC (block CV) | top-5 KS features |
|---|---|---|---|---|
| B3T | khadakwasla_mutha~baramati_agri | 0.158 (0.005) | 0.994 | elevation, dry_nir, slope, tpi_1050, hand |
| B3T | khadakwasla_mutha~mulshi_ghats | 0.101 (0.005) | 0.989 | dry_blue, tpi_1050, dry_red, post_ndmi, dry_nbr |
| B3T | baramati_agri~mulshi_ghats | 0.233 (0.005) | 1.000 | elevation, dry_blue, tpi_1050, dry_red, dry_mndwi |
| C3 | khadakwasla_mutha~baramati_agri | 0.107 (0.005) | 0.972 | dry_nir, sd_nir_5, dry_ndmi, s1_vh_sd, s1_vh_wet |
| C3 | khadakwasla_mutha~mulshi_ghats | 0.141 (0.005) | 0.994 | dry_blue, dry_red, post_ndmi, dry_nbr, dry_ndmi |
| C3 | baramati_agri~mulshi_ghats | 0.207 (0.005) | 1.000 | dry_blue, dry_red, dry_mndwi, dry_swir2, post_mndwi |

Windows are almost perfectly separable (AUC 0.97-1.00). Shift is spread over brightness (dry blue/red/NIR), terrain and moisture indices; phenology/terrain features make up 0.53 of the top-5 KS features (chance 0.61). The cell-level domain probability is not a general predictor of transfer error — positive association in 1 of 6 directions (baramati -> khadakwasla, error rising across quintiles), none or negative in the other 5 (Spearman [-0.01, 0.33, -0.1, -0.21, -0.19, -0.09]). Outcome PASS / NOT_SUPPORTED. Association only.

## Adaptation (P3-J2), after the failure was characterised

| target | no adaptation | target-supervised reference | few-shot 25 / 50 / 100 / 250 per class | CORAL | importance weighting | self-training |
|---|---|---|---|---|---|---|
| khadakwasla_mutha | 0.878 | 0.967 | 0.886 / 0.898 / 0.908 / 0.926 | 0.805 | 0.878 | 0.887 |
| baramati_agri | 0.653 | 0.736 | 0.664 / 0.681 / 0.691 / 0.702 | 0.259 | 0.634 | 0.664 |
| mulshi_ghats | 0.678 | 0.913 | 0.882 / 0.890 / 0.909 / 0.921 | 0.313 | 0.671 | 0.669 |

Few target labels close part of the gap (median share closed with 100-250 labels/class 0.56); unsupervised alignment does not: CORAL is destructive (Baramati 0.26, Mulshi 0.31), importance weighting and self-training change little. Outcome PASS / SUPPORTED.

## Label efficiency (P3-L1) and active learning (P3-L2)

| setting | 10 % | 25 % | 50 % | 75 % | 100 % | saturation fraction |
|---|---|---|---|---|---|---|
| xgb within | 0.965 | 0.968 | 0.974 | 0.978 | 0.977 | 50% |
| rf within | 0.953 | 0.958 | 0.961 | 0.963 | 0.964 | 50% |
| xgb unseen khadakwasla_mutha | 0.841 | 0.857 | 0.860 | 0.854 | 0.861 | 25% |
| xgb unseen baramati_agri | 0.803 | 0.794 | 0.794 | 0.789 | 0.782 | 10% |
| xgb unseen mulshi_ghats | 0.673 | 0.680 | 0.683 | 0.689 | 0.686 | 50% |

saturation fraction (mean within 0.005 of 100 %): {'within_xgb': '50%', 'within_rf': '50%', 'lowo_khadakwasla_mutha': '25%', 'lowo_baramati_agri': '10%', 'lowo_mulshi_ghats': '50%'}; SSL fine-tune beats XGB at 10 % labels in all LOWO windows: False — PASS / NOT_SUPPORTED.

| target | source only | random @ final budget | labels to reach it: entropy / margin / committee / random |
|---|---|---|---|
| khadakwasla_mutha | 0.876 | 0.915 | 200 / 150 / 150 / 350 |
| baramati_agri | 0.656 | 0.699 | 150 / 150 / 100 / 350 |
| mulshi_ghats | 0.677 | 0.865 | 100 / 100 / 100 / 350 |

PASS / SUPPORTED (silver oracle simulation).

