"""Unit tests of the frozen Phase-4 evaluation code. All arrays are SYNTHETIC TEST DATA — NOT RESEARCH DATA.
Purpose: catch scoring errors (wrong comparator, absent classes in macro means, wrong weights) before any confirmatory run."""
import sys
import numpy as np, pytest
sys.path.insert(0, "src")
from pune_eo.evaluation4 import metrics as M, stats as S, history as H, protocol as P

CL = [1, 2, 3, 4]

def test_confusion_orientation_and_macro_present_only():
    ref = np.array([1, 1, 2, 2, 2, 4]); mp = np.array([1, 2, 2, 2, 1, 4])
    s = M.summary(ref, mp, CL)
    assert s["confusion"][0] == [1, 1, 0, 0] and s["confusion"][1] == [1, 2, 0, 0]          # rows = reference
    assert s["classes_present"] == [1, 2, 4]                                                  # class 3 absent from the reference
    f1 = {1: 2 * 1 / (2 + 2), 2: 2 * 2 / (3 + 3), 4: 1.0}
    assert s["macro_f1_present"] == pytest.approx(np.mean(list(f1.values())))                # absent class 3 NOT averaged in as 0
    assert s["accuracy"] == pytest.approx(4 / 6)

def test_abstention_excluded_but_reported():
    ref = np.array([1, 2, 3, 4]); mp = np.array([1, -1, 3, -1]); s = M.summary(ref, mp, CL)
    assert s["coverage"] == 0.5 and s["n"] == 2 and s["accuracy"] == 1.0

def test_weights_change_accuracy():
    ref = np.array([1, 2]); mp = np.array([1, 1]); s = M.summary(ref, mp, CL, weights=[3, 1]); assert s["accuracy"] == pytest.approx(0.75)

def test_stratified_estimator_hand_case():
    # two strata (= map classes) with population areas 900 / 100; sample 10 per stratum
    strata = np.array([1] * 10 + [2] * 10); mp = strata.copy()
    ref = np.array([1] * 9 + [2] + [2] * 8 + [1] * 2)
    r = M.stratified_estimates(ref, mp, strata, {1: 900, 2: 100}, [1, 2])
    assert r["overall_accuracy"] == pytest.approx(0.9 * 0.9 + 0.1 * 0.8)
    p2 = 0.9 * 0.1 + 0.1 * 0.8; assert r["classes"][2]["area_proportion"] == pytest.approx(p2)
    assert r["classes"][2]["users_accuracy"] == pytest.approx(0.8)
    assert r["classes"][2]["producers_accuracy"] == pytest.approx(0.1 * 0.8 / p2)

def test_stratified_estimator_unbiased_on_synthetic_population():
    rng = np.random.default_rng(0); N = 200000; mp = rng.choice([1, 2, 3], N, p=[0.7, 0.2, 0.1])
    ref = np.where(rng.random(N) < 0.85, mp, rng.choice([1, 2, 3], N)); true_p = {k: (ref == k).mean() for k in (1, 2, 3)}
    area = {k: int((mp == k).sum()) for k in (1, 2, 3)}; ests = []
    for rep in range(200):
        idx = np.concatenate([rng.choice(np.flatnonzero(mp == k), 100, replace=False) for k in (1, 2, 3)])
        ests.append(M.stratified_estimates(ref[idx], mp[idx], mp[idx], area, [1, 2, 3])["classes"][3]["area_proportion"])
    assert np.mean(ests) == pytest.approx(true_p[3], abs=0.005)

def test_selective_monotone_for_informative_confidence():
    rng = np.random.default_rng(1); conf = rng.random(5000); correct = rng.random(5000) < conf
    r = M.selective(conf, correct); a = r["accuracy_at_coverage"]
    assert a["0.50"] > a["0.80"] > a["1.00"] and r["aurc"] < 1 - r["base_accuracy"]

def test_abstain_threshold():
    p = np.array([[0.9, 0.1, 0, 0], [0.4, 0.35, 0.25, 0]]); assert M.abstain_by_threshold(p, 0.5).tolist() == [1, -1]

def test_bh_fdr_known_values():
    r = S.bh_fdr([0.01, 0.04, 0.03, 0.005], q=0.05)
    assert np.allclose(r["q_values"], [0.02, 0.04, 0.04, 0.02]) and r["reject"] == [True, True, True, True]
    assert S.bh_fdr([0.2, 0.5, 0.04], 0.05)["reject"] == [False, False, False]

def test_block_bootstrap_covers_truth_and_paired_sign():
    rng = np.random.default_rng(2); blocks = np.repeat(np.arange(60), 50); eff = rng.normal(0, 0.05, 60)[blocks]
    a = (rng.random(3000) < 0.8 + eff).astype(float); b = (rng.random(3000) < 0.7 + eff).astype(float)
    r = S.paired_difference(lambda i: a[i].mean(), lambda i: b[i].mean(), resample="block", groups=blocks, n=500)
    assert r["excludes_zero"] and r["ci"][0] < 0.1 < r["ci"][1]
    r0 = S.paired_difference(lambda i: a[i].mean(), lambda i: a[i].mean(), resample="block", groups=blocks, n=200); assert not r0["excludes_zero"]

def test_stratified_bootstrap_within_strata():
    strata = np.array([0] * 30 + [1] * 70); x = np.r_[np.zeros(30), np.ones(70)]
    r = S.stratified_bootstrap(lambda i: x[i].mean(), strata, n=300); assert r["ci"] == [pytest.approx(0.7), pytest.approx(0.7)]   # strata sizes preserved

def test_seed_summary():
    r = S.seed_summary([0.80, 0.82, 0.81, 0.79, 0.83]); assert r["mean"] == pytest.approx(0.81) and r["ci_mean"][0] < 0.81 < r["ci_mean"][1] and r["n_seeds"] == 5

def test_history_functions():
    a = np.array([[1, 1], [2, 0]]); b = np.array([[1, 2], [2, 0]])
    assert H.class_shares(a, CL)[1] == pytest.approx(2 / 3)
    T = H.transition_matrix(a, b, [1, 2], normalise=None); assert T.tolist() == [[1, 1], [0, 1]]
    pl = H.built_plausibility({1990: 0.5, 1995: 0.3, 2000: 0.35}); assert not pl["plausible"] and pl["declines"][0]["from"] == 1990
    assert H.built_plausibility({1990: 0.1, 2000: 0.12, 2010: 0.115})["plausible"]
    c = H.compare_series({1: 0.1, 2: 0.2, 3: 0.3}, {1: 0.1, 2: 0.25, 3: 0.35}); assert c["change_sign_agreement"] == 1.0 and c["mae"] == pytest.approx(1 / 30)

def test_registry4_confirmatory_requires_frozen_code(tmp_path, monkeypatch):
    proto = tmp_path / "proto.yaml"; proto.write_text("protocol_version: 1\n")
    monkeypatch.setattr(P, "PROTO", proto); monkeypatch.setattr(P, "REG", tmp_path / "reg")
    spec = {k: "x" for k in P.FIELDS}; spec.update(experiment_id="T4-1", kind="confirmatory", seeds=[1, 2, 3, 4, 5], metrics_planned=["m"])
    with pytest.raises(RuntimeError): P.register(**spec)                                   # not frozen yet
    P.freeze(proto); rec = P.register(**spec); assert rec["eval_code_sha256"] == P.code_hash()
    run = P.Run("T4-1"); run.complete({"m": 1}, "NA", "ok")
    with pytest.raises(RuntimeError): P.Run("T4-1")                                         # immutable
    monkeypatch.setattr(P, "code_hash", lambda: "changed")
    with pytest.raises(RuntimeError): P.verify_frozen(proto)                                 # code changed after freeze
    spec2 = dict(spec, experiment_id="T4-2", kind="exploratory"); P.register(**spec2); P.Run("T4-2")   # exploratory runs are not hash-gated

def test_stratified_block_bootstrap_wider_under_clustering():
    # SYNTHETIC: 40 blocks x 10 points; outcome constant within block -> clustered; block bootstrap CI must be wider than point bootstrap
    rng = np.random.default_rng(5); blocks = np.repeat(np.arange(40), 10); strata = np.zeros(400, int); x = np.repeat(rng.random(40) < 0.6, 10).astype(float)
    rb = S.stratified_block_bootstrap(lambda i: x[i].mean(), strata, blocks, n=600); rp = S.stratified_bootstrap(lambda i: x[i].mean(), strata, n=600)
    assert (rb["ci"][1] - rb["ci"][0]) > 2 * (rp["ci"][1] - rp["ci"][0]) and rb["n_psu"] == 40

def test_protocol_yaml_change_detected(tmp_path, monkeypatch):
    proto = tmp_path / "p.yaml"; proto.write_text("protocol_version: 2\ngates: {G1: a}\n"); monkeypatch.setattr(P, "PROTO", proto)
    P.freeze(proto); assert P.verify_frozen(proto)
    proto.write_text(proto.read_text().replace("G1: a", "G1: b"))
    with pytest.raises(RuntimeError): P.verify_frozen(proto)
