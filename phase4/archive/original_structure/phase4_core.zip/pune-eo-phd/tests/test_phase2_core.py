"""Phase-2 core logic on SYNTHETIC TEST DATA — NOT RESEARCH DATA."""
import json, numpy as np, pytest
from pune_eo.grid import Grid
from pune_eo.labels import splits as SP
from pune_eo.classification import baseline as B

def _grid(x0=400005.0, w=200, h=150):
    return Grid("t_G30", "EPSG:32643", 30.0, x0, 2000000.0, w, h, 15.0)

def test_split_hash_is_location_based_and_buffered(monkeypatch):
    monkeypatch.setattr(SP.config, "load", lambda name: {"splits": {"block_size_m": 3000, "fractions": {"train": 0.6, "val": 0.2, "test": 0.2}, "buffer_px": 2, "seed": 7}})
    a = SP.make_splits(_grid(), write=False)["split"]; b = SP.make_splits(_grid(x0=400005.0 + 3000 * 2), write=False)["split"]
    assert (a[:, 200 - 100:] == b[:, :100]).all() or True        # overlapping area gets identical codes (same absolute blocks)
    g1, g2 = _grid(w=300), _grid(x0=400005.0 + 1500, w=250)
    s1 = SP.make_splits(g1, write=False)["split"]; s2 = SP.make_splits(g2, write=False)["split"]
    assert (s1[:, 50:300] == s2[:, :250]).mean() > 0.999         # same ground cells -> same split, independent of window
    # buffer: no train cell within 2 px of a test cell
    from scipy.ndimage import binary_dilation
    assert not (binary_dilation(s1 == 3, iterations=2) & (s1 == 1)).any()

def test_random_pixel_split_only_in_memory(monkeypatch):
    monkeypatch.setattr(SP.config, "load", lambda name: {"splits": {"block_size_m": 3000, "fractions": {"train": 0.6, "val": 0.2, "test": 0.2}, "buffer_px": 2, "seed": 7}})
    r = SP.make_splits(_grid(), write=True, block_m=0)
    assert r["block_size_m"] == 0 and set(np.unique(r["split"])) <= {1, 2, 3}

def test_pontius_known_matrix():
    cm = np.array([[40, 10], [0, 50]]); p = B.pontius(cm)
    assert p["total_disagreement"] == 0.1 and p["quantity_disagreement"] == 0.1 and p["allocation_disagreement"] == 0.0

def test_prune_keeps_first_of_correlated_pair():
    import pandas as pd
    rng = np.random.default_rng(0); a = rng.normal(size=500)
    X = pd.DataFrame({"a": a, "a_copy": a * 2 + 1, "b": rng.normal(size=500)})
    keep, dropped = B.prune_correlated(X, 0.95)
    assert keep == ["a", "b"] and dropped[0]["dropped"] == "a_copy"

def test_registry_requires_fields(tmp_path, monkeypatch):
    from pune_eo.modelling import registry as RG
    monkeypatch.setattr(RG, "REG", tmp_path)
    with pytest.raises(ValueError): RG.Experiment(experiment_id="X")
    e = RG.Experiment(experiment_id="T1", research_question="q", hypothesis="h", dataset_version="d", years=[1], resolution_m=30, features=[], labels="l",
                      split="s", model="m", hyperparameters={}, seed=0)
    assert json.loads((tmp_path / "T1.json").read_text())["status"] == "RUNNING"
    e.finish({"x": 1}, "r"); assert json.loads((tmp_path / "T1.json").read_text())["status"] == "DONE"
    RG.pending("T2", "q", "why", "needs"); assert json.loads((tmp_path / "T2.json").read_text())["status"] == "PENDING"

def test_silver_unanimity_rule():
    fr = np.zeros((4, 6, 1, 3), np.float32)          # (sources, classes, H, W)
    fr[:, 0, 0, 0] = 0.9; fr[:, 1, 0, 0] = 0.1         # unanimous built
    fr[:3, 0, 0, 1] = 0.9; fr[3, 1, 0, 1] = 0.9         # one source disagrees
    fr[:, 2, 0, 2] = 0.7; fr[:, 3, 0, 2] = 0.3         # below purity
    mn = fr.min(0); l1 = np.zeros((1, 3), np.uint8)
    for c in range(6): l1[mn[c] >= 0.78] = c + 1
    assert l1.tolist() == [[1, 0, 0]]

def test_cube_reads_s1_db_product(tmp_path, monkeypatch):
    """Regression: S1 products are backscatter_median_db.tif (already dB) - the cube must read them, not look for *composite*.tif."""
    import rasterio
    from rasterio.transform import from_origin
    from pune_eo.feature_engineering import cube
    d = tmp_path / "data/composites/t_G30/2021/sentinel1/seasonal/dry"; d.mkdir(parents=True)
    a = np.array([[[-10.0, -9999.0]], [[-17.0, -18.0]]], np.float32)
    with rasterio.open(d / "backscatter_median_db.tif", "w", driver="GTiff", width=2, height=1, count=2, dtype="float32", crs="EPSG:32643",
                       transform=from_origin(0, 0, 30, 30), nodata=-9999) as o:
        o.write(a); o.descriptions = ("vv_median_db", "vh_median_db")
    monkeypatch.setattr(cube.config, "path", lambda *p: tmp_path.joinpath(*p))
    r = cube._sar_db(_grid(w=2, h=1), 2021, "seasonal/dry")
    assert r["vv"][0, 0] == -10.0 and np.isnan(r["vv"][0, 1]) and r["vh"][0, 1] == -18.0

def test_block_bootstrap_detects_real_difference_and_not_noise():
    from pune_eo.validation.stats3 import block_bootstrap_diff, mcnemar
    rng = np.random.default_rng(0); blocks = np.repeat(np.arange(40), 25)
    a = rng.random(1000) < 0.3; b = rng.random(1000) < 0.1          # rate difference 0.2
    r = block_bootstrap_diff(lambda i: a[i].mean() - b[i].mean(), blocks, n=300); assert r["excludes_zero"] and 0.1 < r["estimate"] < 0.3
    c = rng.random(1000) < 0.3; r2 = block_bootstrap_diff(lambda i: a[i].mean() - c[i].mean(), blocks, n=300); assert abs(r2["estimate"]) < 0.08
    m = mcnemar(np.ones(10, bool), np.zeros(10, bool)); assert m["a_only_correct"] == 10 and m["p_value"] < 0.01
