"""Urban expansion metrics on SYNTHETIC TEST DATA — NOT RESEARCH DATA."""
import numpy as np
from pune_eo.urban import expansion as U

def test_lei_types():
    t1 = np.zeros((40, 40), bool); t1[10:20, 10:20] = True
    t2 = t1.copy(); t2[12:18, 14:16] = True          # inside existing -> no new cells (already built)
    t2[20:22, 10:20] = True                           # edge growth
    t2[30:33, 30:33] = True                           # leapfrog
    hole = t1.copy(); hole[14:16, 14:16] = False; t2b = t1.copy()
    r = U.lei(hole, t2b)                              # filling a hole -> infill
    assert r["by_type"]["infill"]["n"] == 1
    r = U.lei(t1, t2); types = sorted(p["type"] for p in r["patches"])
    assert types == ["edge", "outlying"]

def test_fragmentation_compact_vs_scattered():
    a = np.zeros((50, 50), bool); a[10:30, 10:30] = True
    b = np.zeros((50, 50), bool); b[::5, ::5] = True
    fa, fb = U.fragmentation(a), U.fragmentation(b)
    assert fa["n_patches"] == 1 and fb["n_patches"] == 100
    assert fa["aggregation_index_pct"] > 90 > fb["aggregation_index_pct"]
    assert abs(fa["built_area_ha"] - 400 * 0.09) < 1e-9
