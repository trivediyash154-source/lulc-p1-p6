# SYNTHETIC TEST DATA — NOT RESEARCH DATA
import numpy as np, pytest
from scipy.ndimage import shift as ndshift, gaussian_filter
from pune_eo.validation.audit import phase_correlation

@pytest.mark.parametrize("s", [(0.0, 0.0), (0.3, -0.4), (1.5, 2.25), (-0.12, 0.07)])
def test_subpixel_shift_recovered(s):
    big = gaussian_filter(np.random.default_rng(1).normal(size=(400, 400)), 2.5)
    b = ndshift(big, s, order=3, mode="nearest")
    dy, dx, _ = phase_correlation(big[100:356, 100:356], b[100:356, 100:356])
    assert abs(dy - s[0]) < 0.03 and abs(dx - s[1]) < 0.03
