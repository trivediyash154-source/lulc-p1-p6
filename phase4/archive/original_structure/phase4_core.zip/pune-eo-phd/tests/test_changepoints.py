"""Change-point methods on SYNTHETIC TEST DATA — NOT RESEARCH DATA (step at 2005 with noise; flat series)."""
import numpy as np, pytest
from pune_eo.change_detection import changepoints as C
YRS = np.arange(1990, 2027)

@pytest.mark.parametrize("m", list(C.METHODS))
def test_detects_step(m):
    rng = np.random.default_rng(0); y = np.where(YRS >= 2005, 0.25, 0.6) + rng.normal(0, 0.03, YRS.size)
    cps = C.detect(YRS, y, m)
    assert cps and min(abs(c[0] - 2005) for c in cps) <= 1
    assert any(c[1] < -0.2 for c in cps if abs(c[0] - 2005) <= 1)

@pytest.mark.parametrize("m", list(C.METHODS))
def test_quiet_on_flat_series(m):
    rng = np.random.default_rng(1); y = 0.5 + rng.normal(0, 0.03, YRS.size)
    assert not any(abs(c[1]) > 0.1 for c in C.detect(YRS, y, m))

def test_missing_years_dropped():
    y = np.where(YRS >= 2005, 0.25, 0.6).astype(float); y[[3, 4, 20]] = np.nan
    assert C.detect(YRS, y, "pelt_mean")[0][0] == 2005
