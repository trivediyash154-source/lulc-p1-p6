"""AOA on SYNTHETIC TEST DATA — NOT RESEARCH DATA: points far from the training cloud must fall outside."""
import numpy as np
from pune_eo.uncertainty.aoa import AOA

def test_aoa_flags_extrapolation():
    rng = np.random.default_rng(0); X = rng.normal(0, 1, (3000, 5)); folds = rng.integers(0, 5, 3000)
    a = AOA(X, np.ones(5), folds)
    near = rng.normal(0, 1, (500, 5)); far = rng.normal(6, 1, (500, 5))
    assert a.inside(near).mean() > 0.9 and a.inside(far).mean() < 0.05
    assert 0 < a.threshold < 5
