"""Phase-3 unit tests. All arrays here are SYNTHETIC TEST DATA — NOT RESEARCH DATA."""
import sys, json
import numpy as np, pandas as pd, pytest
sys.path.insert(0, "src")
from pune_eo.historical_reconstruction import features as F
from pune_eo.calibration import conformal as CF
from pune_eo.change_detection.probabilistic import transition_posterior, hpd_set
from pune_eo.validation import registry3 as R3

FEATS = ["dry_blue", "dry_green", "dry_red", "dry_nir", "dry_swir1", "dry_swir2", "dry_ndvi", "dry_evi", "dry_savi", "dry_mndwi", "dry_ndwi", "dry_ndmi", "dry_ndbi", "dry_bsi",
         "dry_nbr", "post_ndvi", "post_mndwi", "post_ndmi", "d_ndvi", "d_mndwi", "ann_ndvi", "sd_ndvi_5", "sd_nir_5"]

def synthetic_het(n=20, seed=0):   # SYNTHETIC TEST DATA — NOT RESEARCH DATA
    rng = np.random.default_rng(seed); years = list(range(1990, 2027))
    return {"L": rng.random((n, len(years), len(FEATS))).astype(np.float32), "T": rng.random((n, 12)).astype(np.float32), "S": rng.random((n, 9, 7)).astype(np.float32),
            "info": {"years": years, "features": FEATS, "tfeatures": [f"t{i}" for i in range(12)], "syears": list(range(2017, 2026)),
                     "sfeatures": ["s1_vv_dry", "s1_vh_dry", "s1_vh_wet", "s1_ratio", "s1_vv_min", "s1_vh_sd", "s2_ndre_post"]},
            "meta": pd.DataFrame({"window": ["w"] * n, "chirps_mean_mm": np.full(n, 700.0)}),
            "climate": pd.DataFrame({"window": ["w"] * len(years), "year": years, "spi12_prev": np.linspace(-2, 2, len(years))})}

def test_feature_set_widths():
    H = synthetic_het()
    widths = {fs: F.build(H, fs, 2000)[0].shape[1] for fs in ("B1", "B2", "B3", "B4", "B4t", "B5")}
    assert widths == {"B1": 11, "B2": 33, "B3": 16, "B4": 89, "B4t": 101, "B5": 90}          # B5 regression: P3-B5m failed with KeyError('B5')
    assert np.isnan(F.build(H, "B2", 1990)[0][:, :11]).all()                                     # no year before 1990 -> NaN, never interpolated
    assert np.isnan(F.build(H, "C2", 2010)[0]).all() and F.build(H, "C2", 2019)[0].shape[1] == 6 # no SAR before the S1 era

def test_lac_coverage_exchangeable():
    rng = np.random.default_rng(1); n = 6000; logits = rng.normal(size=(n, 4)) * 2; p = np.exp(logits) / np.exp(logits).sum(1, keepdims=True)
    y = np.array([rng.choice(4, p=r) for r in p]) + 1
    q = CF.lac_threshold(p[:3000], y[:3000], 0.1); c = CF.coverage(CF.lac_sets(p[3000:], q), y[3000:])["coverage"]
    assert 0.87 <= c <= 0.93
    qa = CF.aps_threshold(p[:3000], y[:3000], 0.1, np.random.default_rng(2)); ca = CF.coverage(CF.aps_sets(p[3000:], qa, np.random.default_rng(3)), y[3000:])["coverage"]
    assert 0.87 <= ca <= 0.93

def test_transition_posterior_locates_jump():
    T = 37; P = np.full((3, T), 0.1); P[0, 15:] = 0.9; P[1] = 0.9; obs = np.ones((3, T), bool)
    post = transition_posterior(P, obs, pi=0.3)
    assert post[0].argmax() == 15 and post[1].argmax() == 0 and post[2].argmax() == T
    assert 15 in hpd_set(post[0], 0.8) and abs(post.sum(1) - 1).max() < 1e-9
    obs[0] = False; assert transition_posterior(P, obs, 0.3)[0][1:T].sum() == pytest.approx(1 / 3, abs=1e-6)  # no data -> prior

def test_registry_never_overwrites(tmp_path, monkeypatch):
    monkeypatch.setattr(R3, "REG", tmp_path)
    spec = {k: "x" for k in R3.FIELDS}; spec.update(experiment_id="T-1", seed=0, hyperparameters={}, metrics_planned=["m"])
    R3.register(**spec); R3.Run("T-1").complete({"m": 1}, "NA", "ok")
    with pytest.raises(RuntimeError): R3.Run("T-1")
    with pytest.raises(RuntimeError): R3.register(**spec)
    spec["experiment_id"] = "T-1@v2"; R3.register(**spec); assert R3.load("T-1@v2")["status"] == "PENDING" and R3.load("T-1")["status"] == "PASS"
