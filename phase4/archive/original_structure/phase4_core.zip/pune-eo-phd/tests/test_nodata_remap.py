"""Regression tests for GDAL's silent nodata remapping (valid value == dst nodata gets bumped by 1).
SYNTHETIC TEST DATA — NOT RESEARCH DATA."""
import numpy as np, rasterio
from rasterio.transform import from_origin
from rasterio.windows import Window
from pune_eo.grid import Grid

def _tif(path, arr, nodata=None):
    with rasterio.open(path, "w", driver="GTiff", width=arr.shape[1], height=arr.shape[0], count=1, dtype=arr.dtype,
                       crs="EPSG:32643", transform=from_origin(400000, 2000000, 10, 10), nodata=nodata) as d:
        d.write(arr, 1)

def test_scl_zero_not_bumped(tmp_path):
    from pune_eo.compositing.observations import _read_scl
    scl = np.zeros((20, 20), np.uint8); scl[5:15, 5:15] = 4              # 0 = SCL 'no data' (declared nodata: None)
    p = tmp_path / "scl.tif"; _tif(p, scl)
    g = Grid("t", "EPSG:32643", 10.0, 400000, 2000000, 20, 20, 0.0)
    out = _read_scl(str(p), g, Window(0, 0, 20, 20))
    assert (out[scl == 0] == 0).all(), "SCL 0 must stay 0 (no data), not become 1 (saturated/defective)"
    assert (out[scl == 4] == 4).all()

def test_wsf_zero_not_bumped(tmp_path):
    from rasterio.enums import Resampling
    from pune_eo.labels.sources import _warp
    a = np.zeros((20, 20), np.int32); a[:5] = 1995                       # 0 = never settled (declared nodata: None)
    p = tmp_path / "wsf.tif"; _tif(p, a)
    g = Grid("t", "EPSG:32643", 10.0, 400000, 2000000, 20, 20, 0.0)
    out = _warp(str(p), g, Resampling.nearest, src_nodata=None, dst_nodata=65535, dtype="uint16", sign=False)
    assert set(np.unique(out)) <= {0, 1995}

def test_naive_read_does_bump(tmp_path):
    """Documents the GDAL behaviour the two fixes guard against (if GDAL ever changes, this test tells us)."""
    from rasterio.enums import Resampling
    from pune_eo.labels.sources import _warp
    a = np.zeros((20, 20), np.uint8); a[:5] = 4
    p = tmp_path / "x.tif"; _tif(p, a)
    g = Grid("t", "EPSG:32643", 10.0, 400000, 2000000, 20, 20, 0.0)
    out = _warp(str(p), g, Resampling.nearest, src_nodata=None, dst_nodata=0, dtype="uint8", sign=False)
    assert (out[a == 0] == 1).all()
