"""Calibration maps on SYNTHETIC TEST DATA — NOT RESEARCH DATA: an over-confident model gets ECE reduced by each recalibrator."""
import numpy as np
from pune_eo.calibration import metrics as C

def _overconfident(n=4000, k=3, seed=0):
    rng = np.random.default_rng(seed); y = rng.integers(0, k, n); logits = rng.normal(0, 1, (n, k)); logits[np.arange(n), y] += 1.0
    z = logits * 4; p = np.exp(z - z.max(1, keepdims=True)); return p / p.sum(1, keepdims=True), y

def test_recalibrators_reduce_ece():
    p, y = _overconfident(); pc, yc = _overconfident(seed=1); e0 = C.ece(p, y)
    for M in (C.Temperature, C.Isotonic, C.Platt):
        q = M().fit(pc, yc).transform(p); assert C.ece(q, y) < e0 * 0.6, M.__name__
    assert C.Temperature().fit(pc, yc).T > 1.5          # over-confidence -> T > 1

def test_metric_ranges():
    p, y = _overconfident(); m = C.all_metrics(p, y)
    assert 0 <= m["ece"] <= 1 and 0 <= m["brier"] <= 2 and m["nll"] > 0
