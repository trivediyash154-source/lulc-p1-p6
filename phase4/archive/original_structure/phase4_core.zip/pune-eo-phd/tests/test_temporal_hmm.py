"""HMM smoothing on SYNTHETIC TEST DATA — NOT RESEARCH DATA."""
import numpy as np
from pune_eo.classification import temporal as H

def _sim(N=2000, T=30, K=3, stay=0.97, acc=0.75, seed=0):
    rng = np.random.default_rng(seed); A = np.full((K, K), (1 - stay) / (K - 1)); np.fill_diagonal(A, stay)
    z = np.empty((T, N), int); z[0] = rng.integers(0, K, N)
    for t in range(1, T): z[t] = [rng.choice(K, p=A[s]) for s in z[t - 1]]
    post = np.full((T, K, N), (1 - acc) / (K - 1))
    noisy = np.where(rng.random((T, N)) < acc, z, rng.integers(0, K, (T, N)))
    np.put_along_axis(post, noisy[:, None, :], acc, axis=1)
    return z, post, A

def test_baum_welch_recovers_persistence_and_viterbi_beats_raw():
    z, post, A_true = _sim()
    e = H.emissions(post, np.full(3, 1 / 3))
    A, p0, hist = H.baum_welch(e, 3)
    assert abs(np.diag(A).mean() - 0.97) < 0.03
    assert all(b >= a - 1e-6 for a, b in zip(hist, hist[1:]))           # EM log-likelihood non-decreasing
    raw = post.argmax(1); vit = H.viterbi(e, A, p0)
    assert (vit == z).mean() > (raw == z).mean() + 0.1
    assert H.flip_rate(vit).mean() < H.flip_rate(raw).mean()

def test_missing_years_are_uninformative():
    z, post, _ = _sim(N=500, seed=1); valid = np.ones(post.shape[::2], bool); valid[10:15] = False
    e = H.emissions(post, np.full(3, 1 / 3), valid)
    assert np.allclose(e[10:15], 1.0)
