"""Trajectory taxonomy on SYNTHETIC TEST DATA — NOT RESEARCH DATA."""
import numpy as np
from pune_eo.change_detection import trajectories as TR

def test_types_and_timing():
    yrs = np.arange(2000, 2010); T = len(yrs)
    seqs = np.array([[3] * T, [2] * 4 + [1] * 6, [2] * 3 + [3] * 3 + [1] * 4, [4] * 3 + [3] * 3 + [4] * 4]).T
    v = np.ones_like(seqs, bool); r = TR.taxonomy(seqs, v, yrs, min_valid=5)
    assert list(r["type"]) == [1, 2, 3, 4]
    assert r["first_change"][1] == 2004 and r["n_transitions"][2] == 2
    v2 = v.copy(); v2[:, 0] = False; assert TR.taxonomy(seqs, v2, yrs, min_valid=11)["type"][0] == 0

def test_gi_star_hotspot():
    x = np.zeros((20, 20)); x[8:11, 8:11] = 1.0; z = TR.getis_ord(x)
    assert z[9, 9] > 3 and abs(z[0, 0]) < 1
