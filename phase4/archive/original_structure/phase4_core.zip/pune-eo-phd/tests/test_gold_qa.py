"""Gold QA statistics on SYNTHETIC TEST DATA — NOT RESEARCH DATA (textbook values)."""
import numpy as np, pandas as pd
from pune_eo.labels import gold_qa as Q

def test_cohen_perfect_and_chance():
    assert Q.cohen_kappa(list("aabb"), list("aabb")) == 1.0
    assert abs(Q.cohen_kappa(list("abab"), list("aabb"))) < 1e-9

def test_fleiss_wikipedia_example():
    M = np.array([[0,0,0,0,14],[0,2,6,4,2],[0,0,3,5,6],[0,3,9,2,0],[2,2,8,1,1],[7,7,0,0,0],[3,2,6,3,0],[2,5,3,2,2],[6,5,2,1,0],[0,2,2,3,7]])
    assert abs(Q.fleiss_kappa(M) - 0.210) < 0.001

def test_krippendorff_matches_perfect_and_handles_missing():
    assert Q.krippendorff_alpha_nominal([["a", "a"], ["b", "b"], ["a", "a", None]]) == 1.0
    a = Q.krippendorff_alpha_nominal([["a", "b"], ["b", "a"], ["a", "b"]]); assert a < 0

def test_gate1_logic():
    f1 = pd.DataFrame({"anon_id": [f"G{i}" for i in range(10)], "reference_class_2020": ["built_up"] * 5 + ["agriculture"] * 4 + ["uncertain"]})
    f2 = f1.iloc[:3].copy()
    g = Q.gate1(f1, f2, 2020); assert g["coverage_non_abstain"] == 0.9 and g["kappa"] == 1.0 and g["passed"]
    assert not Q.gate1(f1, None, 2020)["passed"]
