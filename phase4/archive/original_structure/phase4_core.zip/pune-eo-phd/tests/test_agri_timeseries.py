"""Temporal DL models on SYNTHETIC TEST DATA — NOT RESEARCH DATA: two classes with different seasonal NDVI peaks + missing months."""
import numpy as np, pytest
from pune_eo.agriculture import timeseries as TS

def _data(n=600, seed=0):
    rng = np.random.default_rng(seed); t = np.arange(12); y = rng.integers(0, 2, n)
    peak = np.where(y == 0, 2, 9)[:, None]
    ndvi = 0.2 + 0.5 * np.exp(-0.5 * ((t[None] - peak) / 1.5) ** 2) + rng.normal(0, 0.03, (n, 12))
    X = np.repeat(ndvi[..., None], 6, -1).astype(np.float32); X[:, 6:8, :4] = np.nan          # monsoon gap in optical channels
    return X, y

@pytest.mark.parametrize("name", ["tempcnn", "lstm", "transformer"])
def test_models_learn_seasonality(name):
    X, y = _data(); Z, grp, st = TS.prepare(X)
    assert not np.isnan(Z).any() and grp[:, 6:8, 0].sum() == 0
    net, hist = TS.train(name, Z[:400], y[:400], Z[400:500], y[400:500], 2, epochs=15, patience=5)
    p = TS.predict_proba(net, Z[500:]); assert (p.argmax(1) == y[500:]).mean() > 0.9
    mc = TS.predict_proba(net, Z[500:520], mc_dropout=5); assert mc.shape == (5, 20, 2)
