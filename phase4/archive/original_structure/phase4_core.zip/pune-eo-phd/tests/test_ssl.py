"""MAE pretraining on SYNTHETIC TEST DATA — NOT RESEARCH DATA: loss decreases; probe on embeddings separates two seasonal regimes."""
import numpy as np
from pune_eo.temporal_models import ssl

def test_mae_learns_and_embeddings_are_informative():
    rng = np.random.default_rng(0); n, T, C = 800, 12, 3; y = rng.integers(0, 2, n); t = np.arange(T)
    base = np.where(y[:, None] == 0, np.sin(t / 2.0), np.cos(t / 2.0))[..., None] + rng.normal(0, 0.1, (n, T, C))
    X = base.astype(np.float32); X[rng.random((n, T)) < 0.2] = np.nan
    Z, obs, st = ssl.standardise(X); enc, hist = ssl.pretrain(Z, obs, C, epochs=4, bs=128)
    assert hist[-1] < hist[0]
    E = ssl.embed(enc, Z, obs, 5)
    from sklearn.linear_model import LogisticRegression
    acc = LogisticRegression(max_iter=500).fit(E[:600], y[:600]).score(E[600:], y[600:]); assert acc > 0.85
