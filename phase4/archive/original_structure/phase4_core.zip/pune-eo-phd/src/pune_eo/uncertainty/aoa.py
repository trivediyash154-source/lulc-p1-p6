"""Area of applicability (Meyer & Pebesma 2021, Methods Ecol. Evol. 12:1620).

Dissimilarity index DI(x) = d(x, nearest training sample) / mean pairwise training distance, in standardised feature space
weighted by feature importance. Threshold = upper whisker (Q3 + 1.5 IQR) of the training DI computed with spatial-block
cross-validation (nearest training sample from OTHER folds) - so the threshold reflects spatial extrapolation, not
memorisation. Predictions with DI > threshold are OUTSIDE the AOA: reported, mapped, never silently used."""
from __future__ import annotations
import numpy as np

class AOA:
    def __init__(self, X_train: np.ndarray, weights: np.ndarray, folds: np.ndarray, max_ref: int = 6000, seed: int = 0):
        rng = np.random.default_rng(seed)
        self.mu = np.nanmean(X_train, 0); self.sd = np.nanstd(X_train, 0) + 1e-9; self.w = weights / weights.sum() * len(weights)
        Z = self._z(X_train)
        if len(Z) > max_ref:
            k = rng.choice(len(Z), max_ref, replace=False); Z, folds = Z[k], folds[k]
        self.ref, self.folds = Z, folds
        sub = Z[rng.choice(len(Z), min(2000, len(Z)), replace=False)]
        self.dbar = float(np.mean(self._pdist(sub, sub)[np.triu_indices(len(sub), 1)]))
        di = np.empty(len(Z))
        for f in np.unique(folds):
            m = folds == f; di[m] = self._nn(Z[m], Z[~m]) / self.dbar
        q1, q3 = np.percentile(di, [25, 75]); self.threshold = float(q3 + 1.5 * (q3 - q1)); self.train_di = di

    def _z(self, X):
        Z = (X - self.mu) / self.sd * np.sqrt(self.w); return np.where(np.isfinite(Z), Z, 0.0).astype(np.float32)

    @staticmethod
    def _pdist(A, B):
        return np.sqrt(np.maximum((A * A).sum(1)[:, None] + (B * B).sum(1)[None] - 2 * A @ B.T, 0))

    def _nn(self, A, B, chunk=4000):
        out = np.empty(len(A), np.float32)
        for i in range(0, len(A), chunk): out[i:i + chunk] = self._pdist(A[i:i + chunk], B).min(1)
        return out

    def di(self, X):
        return self._nn(self._z(X), self.ref) / self.dbar

    def inside(self, X):
        return self.di(X) <= self.threshold
