"""Two-stage, resumable compositing engine (any sensor family, any grid, any window).

Stage 1  each selected observation is read ONCE onto the grid window and cached as
         analysis-ready arrays (int16 reflectance x1e4 / float32 SAR + uint8 status).
Stage 2  every period (annual, seasons, months) is reduced from that cache in row blocks,
         so memory is bounded by block size, not by district size or observation count.
A job = (family, grid, window, year). Completed jobs are recorded in a ledger and skipped;
a failure in one job never invalidates another.
"""
from __future__ import annotations
import json, logging, shutil, time
from concurrent.futures import ThreadPoolExecutor, as_completed
from pathlib import Path
import geopandas as gpd
import numpy as np
import pandas as pd
from rasterio.features import geometry_mask
from rasterio.windows import Window
from .. import config, __version__
from ..grid import Grid
from ..io import write_cog, write_json
from ..jobs import JobLedger, JobLocked
from ..provenance import utcnow, code_block, sha256
from ..acquisition.boundary import load_study_area, study_area_version
from ..harmonization import landsat as harm
from . import observations as obs
from .periods import Period, standard_periods, items_in
from .stats import robust_composite, linear_power_stats, nanmedian0

log = logging.getLogger(__name__)
PROCESSING_VERSION = f"cube-{__version__}"
PLATFORM_ORDER = {"landsat": ["landsat-4", "landsat-5", "landsat-7", "landsat-8", "landsat-9"],
                  "sentinel2": ["sentinel-2a", "sentinel-2b", "sentinel-2c"],
                  "sentinel1": ["sentinel-1a", "sentinel-1b", "sentinel-1c", "sentinel-1d"]}

def load_manifest(family: str) -> gpd.GeoDataFrame:
    m = gpd.read_parquet(config.path("data", "manifests", f"{family}_manifest.parquet"))
    return m[m["selected"]].copy()

def district_mask(grid: Grid) -> np.ndarray:
    sa = load_study_area(grid.crs)
    return geometry_mask(sa.geometry, grid.shape, grid.transform, invert=True)

# ------------------------------------------------------------------------- stage 1
def stage1(family: str, items: pd.DataFrame, grid: Grid, restrict: Window, cache: Path, threads: int, plog: list):
    cache.mkdir(parents=True, exist_ok=True)
    loader = obs.LOADERS[family]
    index = []

    def work(row):
        f_meta = cache / f"{row['product_id']}.json"
        if f_meta.exists():
            return json.loads(f_meta.read_text())
        for attempt in range(3):
            try:
                r = loader(row, grid, restrict)
                break
            except Exception as e:
                err = repr(e)
                time.sleep(2 * (attempt + 1))
        else:
            return {"item_id": row["product_id"], "status": "failed", "error": err}
        if r is None:
            m = {"item_id": row["product_id"], "status": "no_overlap"}
        else:
            w = r.pop("win"); vals = r.pop("values"); st = r.pop("status")
            if family == "sentinel1":
                np.save(cache / f"{row['product_id']}.vals.npy", vals.astype(np.float32))
            else:
                np.save(cache / f"{row['product_id']}.vals.npy",
                        np.where(np.isfinite(vals), np.round(vals * 10000), -32768).astype(np.int16))
            np.save(cache / f"{row['product_id']}.status.npy", st)
            m = {**r, "status": "ok", "win": [int(w.col_off), int(w.row_off), int(w.width), int(w.height)],
                 "n_clear_px": int((st == 2).sum()), "n_observed_px": int((st >= 1).sum())}
        tmp = f_meta.with_suffix(".tmp"); tmp.write_text(json.dumps(m)); tmp.replace(f_meta)
        return m

    rows = [r for _, r in items.iterrows()]
    with ThreadPoolExecutor(max_workers=threads) as ex:
        futs = {ex.submit(work, r): r["product_id"] for r in rows}
        for f in as_completed(futs):
            m = f.result(); index.append(m); plog.append({k: m.get(k) for k in ("item_id", "status", "n_clear_px", "error")})
    return [m for m in index if m.get("status") == "ok"]

# ------------------------------------------------------------------------- stage 2
def _block_rows(n_items: int, width: int, budget=256 * 2**20) -> int:
    return int(max(4, min(512, budget // max(1, n_items * width * 4))))

def reduce_period(family: str, metas: list[dict], cache: Path, win: Window, transform_name: str | None):
    """Reduce cached observations of one period. Returns dict of full-window arrays."""
    H, W = int(win.height), int(win.width)
    nb = len(obs.BAND_NAMES[family]); n = len(metas)
    plats = PLATFORM_ORDER[family]
    out = {"n_observed": np.zeros((H, W), np.uint16), "n_clear": np.zeros((H, W), np.uint16),
           "per_platform": np.zeros((len(plats), H, W), np.uint16), "doy_median": np.full((H, W), np.nan, np.float32)}
    if family == "sentinel1":
        out.update(mean_db=np.full((nb, H, W), np.nan, np.float32), median_db=np.full((nb, H, W), np.nan, np.float32),
                   std_db=np.full((nb, H, W), np.nan, np.float32))
    else:
        out.update(composite=np.full((nb, H, W), np.nan, np.float32), uncertainty=np.full((nb, H, W), np.nan, np.float32))
    if n == 0:
        return out
    arrs = [(m, np.load(cache / f"{m['item_id']}.vals.npy", mmap_mode="r"),
             np.load(cache / f"{m['item_id']}.status.npy", mmap_mode="r")) for m in metas]
    br = _block_rows(n, W)
    for r0 in range(0, H, br):
        r1 = min(H, r0 + br); rows = r1 - r0
        st = np.zeros((n, rows, W), np.uint8)
        place = []
        for i, (m, v, s) in enumerate(arrs):
            c0, rr0, ww, hh = m["win"]
            c0 -= int(win.col_off); rr0 -= int(win.row_off)
            a, b = max(r0, rr0), min(r1, rr0 + hh)
            if a >= b: continue
            st[i, a - r0:b - r0, c0:c0 + ww] = s[a - rr0:b - rr0]
            place.append((i, a, b, c0, ww, rr0))
        out["n_observed"][r0:r1] = (st >= 1).sum(0)
        clear = st == 2
        out["n_clear"][r0:r1] = clear.sum(0)
        for pi, p in enumerate(plats):
            idx = [i for i, (m, _, _) in enumerate(arrs) if m["platform"] == p]
            if idx: out["per_platform"][pi, r0:r1] = clear[idx].sum(0)
        doys = np.where(clear, np.array([m["doy"] for m, _, _ in arrs], np.float32)[:, None, None], np.nan)
        with np.errstate(all="ignore"):
            import warnings
            with warnings.catch_warnings():
                warnings.simplefilter("ignore", RuntimeWarning)
                out["doy_median"][r0:r1] = nanmedian0(doys)[0]
        for bi in range(nb):
            vals = np.full((n, rows, W), np.nan, np.float32)
            for i, a, b, c0, ww, rr0 in place:
                v = arrs[i][1][bi, a - rr0:b - rr0]
                if family == "sentinel1":
                    vals[i, a - r0:b - r0, c0:c0 + ww] = v
                else:
                    vv = v.astype(np.float32); vv[vv == -32768] = np.nan
                    vals[i, a - r0:b - r0, c0:c0 + ww] = vv / 10000.0
            vals[~clear] = np.nan
            if family == "landsat" and transform_name not in (None, "none"):
                band = obs.BAND_NAMES["landsat"][bi]
                for i, (m, _, _) in enumerate(arrs):
                    vals[i] = harm.apply({band: vals[i]}, m["platform"], transform_name)[band]
            if family == "sentinel1":
                mdb, meddb, sdb, _ = linear_power_stats(vals)
                out["mean_db"][bi, r0:r1], out["median_db"][bi, r0:r1], out["std_db"][bi, r0:r1] = mdb, meddb, sdb
            else:
                med, se, _ = robust_composite(vals)
                out["composite"][bi, r0:r1], out["uncertainty"][bi, r0:r1] = med, se
    return out

# ------------------------------------------------------------------------- products
def _valid_class(n_clear, inside):
    v = np.where(n_clear >= 3, 3, np.where(n_clear >= 1, 2, 1)).astype(np.uint8)
    v[~inside] = 0
    return v

def write_products(family: str, period: Period, sub: Grid, res: dict, inside: np.ndarray, metas: list[dict],
                   out_dir: Path, cutoff: pd.Timestamp, transform_name: str | None, extra: dict,
                   out_family: str | None = None) -> dict:
    out_dir.mkdir(parents=True, exist_ok=True)
    bands = obs.BAND_NAMES[family]; plats = PLATFORM_ORDER[family]
    files = {}
    n_clear = res["n_clear"]
    if family == "sentinel1":
        mdb = res["mean_db"].copy(); mdb[:, ~inside] = np.nan
        ratio = (res["mean_db"][0] - res["mean_db"][1])[None]
        files["backscatter_mean_db"] = write_cog(out_dir / "backscatter_mean_db.tif", np.nan_to_num(mdb, nan=-9999), sub,
            nodata=-9999, dtype="float32", descriptions=[f"{b}_mean_db" for b in bands])
        files["backscatter_median_db"] = write_cog(out_dir / "backscatter_median_db.tif",
            np.nan_to_num(np.where(inside, res["median_db"], np.nan), nan=-9999), sub, nodata=-9999, dtype="float32",
            descriptions=[f"{b}_median_db" for b in bands])
        files["vv_minus_vh_db"] = write_cog(out_dir / "vv_minus_vh_db.tif", np.nan_to_num(np.where(inside, ratio, np.nan), nan=-9999),
            sub, nodata=-9999, dtype="float32", descriptions=["vv_minus_vh_db"])
        files["uncertainty"] = write_cog(out_dir / "uncertainty.tif", np.nan_to_num(np.where(inside, res["std_db"], np.nan), nan=-9999),
            sub, nodata=-9999, dtype="float32", descriptions=[f"{b}_temporal_std_db" for b in bands])
    else:
        comp = np.where(np.isfinite(res["composite"]) & inside, np.round(res["composite"] * 10000), -32768).astype(np.int16)
        unc = np.where(np.isfinite(res["uncertainty"]) & inside, np.round(res["uncertainty"] * 10000), -32768).astype(np.int16)
        files["optical_composite"] = write_cog(out_dir / "optical_composite.tif", comp, sub, nodata=-32768, dtype="int16",
            descriptions=bands, tags={"units": "surface reflectance x 10000", "method": "per-pixel median of clear observations"})
        files["uncertainty"] = write_cog(out_dir / "uncertainty.tif", unc, sub, nodata=-32768, dtype="int16",
            descriptions=[f"{b}_se_median" for b in bands], tags={"units": "reflectance x 10000", "method": "1.2533*1.4826*MAD/sqrt(n), n>=3"})
    files["observation_count"] = write_cog(out_dir / "observation_count.tif", np.where(inside, n_clear, 0).astype(np.uint16),
        sub, nodata=None, dtype="uint16", descriptions=["n_clear_observations"], overview_resampling="nearest")
    files["valid_mask"] = write_cog(out_dir / "valid_mask.tif", _valid_class(n_clear, inside), sub, nodata=None, dtype="uint8",
        descriptions=["0 outside district | 1 no clear obs | 2 one-two clear obs | 3 three+ clear obs"], overview_resampling="nearest")
    clear_pct = np.where(res["n_observed"] > 0, np.round(100 * n_clear / np.maximum(res["n_observed"], 1)), 0)
    qa = np.concatenate([res["n_observed"][None], n_clear[None], clear_pct[None], res["per_platform"],
                         np.nan_to_num(res["doy_median"], nan=0)[None]]).astype(np.uint16)
    qa[:, ~inside] = 0
    files["qa"] = write_cog(out_dir / "qa.tif", qa, sub, nodata=None, dtype="uint16",
        descriptions=["n_observed", "n_clear", "clear_pct"] + [f"n_clear_{p}" for p in plats] + ["doy_median_clear"],
        overview_resampling="nearest")

    din = inside.sum()
    nc = n_clear[inside]
    stats = {
        "district_pixels": int(din),
        "district_valid_fraction": float((nc >= 1).mean()) if din else 0.0,
        "district_reliable_fraction_ge3": float((nc >= 3).mean()) if din else 0.0,
        "single_obs_fraction": float((nc == 1).mean()) if din else 0.0,
        "n_clear_median": float(np.median(nc)) if din else 0.0,
        "n_clear_p10": float(np.percentile(nc, 10)) if din else 0.0,
        "n_clear_p90": float(np.percentile(nc, 90)) if din else 0.0,
        "clear_pct_mean": float(clear_pct[inside & (res["n_observed"] > 0)].mean()) if (inside & (res["n_observed"] > 0)).any() else 0.0,
        "sensor_contribution_clear_px": {p: int(res["per_platform"][i][inside].sum()) for i, p in enumerate(plats)},
        "n_items": len(metas), "n_items_with_clear_px": int(sum(m["n_clear_px"] > 0 for m in metas)),
        "scene_cloud_mean": float(np.nanmean([m["cloud_cover"] for m in metas if m.get("cloud_cover") is not None])) if any(m.get("cloud_cover") is not None for m in metas) else None,
    }
    if family != "sentinel1":
        stats["band_medians"] = {b: (float(np.nanmedian(res["composite"][i][inside])) if np.isfinite(res["composite"][i][inside]).any() else None)
                                 for i, b in enumerate(bands)}
        stats["uncertainty_medians"] = {b: (float(np.nanmedian(res["uncertainty"][i][inside])) if np.isfinite(res["uncertainty"][i][inside]).any() else None)
                                        for i, b in enumerate(bands)}
    else:
        stats["backscatter_median_db"] = {b: (float(np.nanmedian(res["mean_db"][i][inside])) if np.isfinite(res["mean_db"][i][inside]).any() else None)
                                          for i, b in enumerate(bands)}
    stats.update(extra.get("stats", {}))
    cfgname = {"landsat": "landsat", "sentinel2": "sentinel2", "sentinel1": "sentinel1"}[family]
    meta = {
        "product_id": f"{out_family or family}/{sub.id}/{period.year}/{period.relpath}",
        "sensor_family": family,
        "schema_version": "1.0.0", "processing_version": PROCESSING_VERSION, "created_utc": utcnow(),
        "study_area": study_area_version(),
        "grid": sub.to_dict(),
        "temporal": {"year": period.year, "period": period.name, "kind": period.kind,
                     "start": period.start.strftime("%Y-%m-%d"), "end": period.end.strftime("%Y-%m-%d"),
                     "complete": bool(period.complete(cutoff)), "archive_cutoff_utc": str(cutoff),
                     "first_observation": min((m["date"] for m in metas), default=None),
                     "last_observation": max((m["date"] for m in metas), default=None)},
        "sources": [{k: m.get(k) for k in ("item_id", "platform", "date", "tile_id", "cloud_cover", "n_clear_px",
                                           "processing_baseline", "orbit_state", "relative_orbit") if k in m} for m in metas],
        "sensors": {p: sum(m["platform"] == p for m in metas) for p in plats if any(m["platform"] == p for m in metas)},
        "processing": extra.get("processing", {}) | {"harmonization": transform_name},
        "statistics": stats,
        "files": {k: {"path": str(Path(v).relative_to(config.ROOT)), "sha256": sha256(Path(v))} for k, v in files.items()},
        "code": code_block(config.config_hash(cfgname, "grid", "temporal", "study_area")),
    }
    write_json(out_dir / "metadata.json", meta)
    return meta

def processing_block(family: str, grid: Grid) -> dict:
    if family == "landsat":
        c = config.load("landsat")
        return {"collection": c["collection"], "level": "L2SP surface reflectance", "qa_mask_bits": c["qa_mask_bits"],
                "valid_dn": c["valid_dn"], "scale": c["scale"], "offset": c["offset"],
                "negative_reflectance": "clipped to 0 (dark targets), counted", "composite": "per-pixel median of clear observations",
                "uncertainty": "standard error of the median from scaled MAD (n>=3)",
                "read": "native nearest (exact copy)" if grid.res == 30 else
                        f"SR overview <= {grid.res/60:.0f}x averaged to {grid.res:.0f} m; QA overview 2x sampled, cell clear only if all {(grid.res/60)**2:.0f} samples clear"}
    if family == "sentinel2":
        c = config.load("sentinel2")
        return {"collection": c["collection"], "level": "L2A BOA reflectance", "scl_clear_classes": c["scl_clear_classes"],
                "boa_add_offset": "-0.1 for processing baseline >= 04.00", "composite": "per-pixel median of clear observations",
                "uncertainty": "standard error of the median from scaled MAD (n>=3)"}
    return {"collection": "sentinel-1-rtc", "level": "RTC gamma0 (linear) -> dB", "mean": "linear-power mean then dB",
            "uncertainty": "temporal std of dB values (n>=2)", "geometry": "dominant orbit state per year"}

# ------------------------------------------------------------------------- job runner
def run_year(family: str, year: int, grid: Grid, *, window: Window | None = None, window_name: str = "district",
             periods: list[Period] | None = None, threads: int = 12, transform_name: str | None = None,
             keep_cache: bool = False, platforms: list[str] | None = None, out_family: str | None = None,
             ledger: JobLedger | None = None) -> dict:
    window = window or Window(0, 0, grid.width, grid.height)
    sub = grid.subgrid(window, "" if window_name == "district" else f"_{window_name}")
    out_family = out_family or family
    if family == "landsat":
        transform_name = transform_name or harm.active_for_grid(grid.id)
    version = f"{PROCESSING_VERSION}|{transform_name}|{config.config_hash(family, 'grid', 'temporal', 'study_area')}"
    job_id = f"{out_family}/{sub.id}/{year}"
    ledger = ledger or JobLedger(config.path("data", "manifests", "jobs", f"{out_family}_{sub.id}.json"))
    if ledger.is_done(job_id, version):
        log.info("skip %s (done)", job_id); return {"job_id": job_id, "status": "skipped"}
    man = load_manifest(family)
    cutoff = pd.to_datetime(man["archive_cutoff_utc"].iloc[0])
    periods = periods or standard_periods(year, include_months=family != "landsat")
    months = sorted({m for p in periods for m in p.months})
    items = man[(man["year"] == year) & (man["month"].isin(months))]
    if platforms:
        items = items[items["platform"].isin(platforms)]
    try:
        ledger.start(job_id, version, n_items=int(len(items)))
    except JobLocked as e:
        log.warning("%s", e); return {"job_id": job_id, "status": "locked"}
    # cache keyed by the job version: a reader/config/transform change can never reuse stale per-observation arrays
    import hashlib
    cache = config.path("data", "raw", "ard_cache", out_family, sub.id, str(year), hashlib.sha256(version.encode()).hexdigest()[:12])
    plog: list = []
    t0 = time.time()
    try:
        metas = stage1(family, items, grid, window, cache, threads, plog)
        inside = district_mask(sub)
        outputs, summaries = [], {}
        for p in periods:
            pm = [m for m in metas if int(m["date"][5:7]) in p.months]
            res = reduce_period(family, pm, cache, window, transform_name)
            d = config.path("data", "composites", sub.id, str(year), out_family, p.relpath)
            meta = write_products(family, p, sub, res, inside, pm, d, cutoff, transform_name,
                                  {"processing": processing_block(family, grid)}, out_family=out_family)
            outputs += [config.ROOT / f["path"] for f in meta["files"].values()] + [d / "metadata.json"]
            summaries[p.relpath] = {"complete": meta["temporal"]["complete"], "n_items": len(pm),
                                    **{k: meta["statistics"][k] for k in ("district_valid_fraction", "district_reliable_fraction_ge3", "n_clear_median")}}
        # automated QA is part of production: every product leaves this function with a QA verdict
        try:
            from ..qa.checks import check_product
            from ..acquisition.reference import permanent_water
            pw = permanent_water(sub) if family != "sentinel1" else None
            for p in periods:
                mp = config.path("data", "composites", sub.id, str(year), out_family, p.relpath, "metadata.json")
                summaries[p.relpath]["qa"] = check_product(mp, pw)["status"]
        except Exception as e:                       # QA failure must be visible, never silent
            log.error("automated QA failed for %s: %r", job_id, e)
            for p in periods: summaries[p.relpath]["qa"] = f"QA_ERROR: {e!r}"
        failed = [r for r in plog if r["status"] == "failed"]
        write_json(config.path("data", "manifests", "processing_log", f"{job_id.replace('/', '__')}.json"),
                   {"job_id": job_id, "version": version, "finished_utc": utcnow(), "items": plog})
        write_json(config.path("data", "composites", sub.id, str(year), "metadata", f"{out_family}_year_summary.json"),
                   {"job_id": job_id, "year": year, "family": out_family, "grid": sub.id, "n_items_selected": int(len(items)),
                    "n_items_failed": len(failed), "seconds": round(time.time() - t0, 1), "periods": summaries,
                    "sensors": items["platform"].value_counts().to_dict()})
        ledger.done(job_id, outputs, seconds=round(time.time() - t0, 1), n_failed_items=len(failed))
        if not keep_cache:
            shutil.rmtree(cache, ignore_errors=True)
        return {"job_id": job_id, "status": "done", "seconds": round(time.time() - t0, 1), "periods": summaries,
                "n_items": int(len(items)), "n_failed": len(failed)}
    except BaseException as e:
        ledger.fail(job_id, e)
        raise
