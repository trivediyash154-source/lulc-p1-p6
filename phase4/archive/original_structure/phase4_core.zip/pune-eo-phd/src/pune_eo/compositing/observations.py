"""Stage 1: per-observation loaders -> analysis-ready arrays on the grid window.

Each loader returns {"win", "values" (bands,h,w) float32 NaN=unusable, "status" (h,w) uint8,
"platform", "date", "doy", "item_id", ...}. status: 0 not observed (outside swath / fill /
SLC-off gap), 1 observed but not clear (cloud, shadow, cirrus, snow, invalid), 2 clear.
"""
from __future__ import annotations
import json, math
import numpy as np
from rasterio.enums import Resampling
from rasterio.windows import Window
from .. import config
from ..grid import Grid
from ..preprocessing import landsat_qa, s2_scl, sar
from .reader import read_to_grid, factor, source_window

def _hrefs(row) -> dict:
    return json.loads(row["asset_hrefs"])

def _scale_window(w: Window, k: int) -> Window:
    return Window(int(w.col_off) * k, int(w.row_off) * k, int(w.width) * k, int(w.height) * k)

def _exact(href, grid, win, **kw):
    """Read exactly `win` (pixels outside the source receive dst_nodata)."""
    from .reader import pc, rasterio, WarpedVRT, _ovr_level
    href_s = pc.sign(href)
    with rasterio.Env(**config.GDAL_ENV):
        lvl = None
        if kw.get("max_overview_factor"):
            with rasterio.open(href_s) as p:
                lvl, _ = _ovr_level(p.overviews(1), kw["max_overview_factor"])
        sub = grid.subgrid(win)
        with rasterio.open(href_s, **({"overview_level": lvl} if lvl is not None else {})) as src:
            with WarpedVRT(src, crs=grid.crs, transform=sub.transform, width=sub.width, height=sub.height,
                           resampling=kw["resampling"], src_nodata=kw.get("src_nodata", src.nodata),
                           nodata=kw["dst_nodata"], dtype=kw["dtype"]) as vrt:
                return vrt.read(1)

def _meta(row):
    d = row["datetime_utc"]
    return {"item_id": row["product_id"], "platform": row["platform"], "date": str(row["date"]),
            "doy": int(row["doy"]), "cloud_cover": None if row["cloud_cover"] is None or np.isnan(row["cloud_cover"]) else float(row["cloud_cover"]),
            "tile_id": row["tile_id"]}

QA_OUTSIDE = 4294967295   # uint32 sentinel that cannot occur in uint16 QA_PIXEL

def _read_qa(href, grid, win, **kw):
    """QA is read with NO source nodata (fill=1 is a real flag value) into uint32 with an impossible
    sentinel for 'outside source'; sentinel -> fill. Prevents GDAL remapping valid flags."""
    q = _exact(href, grid, win, resampling=Resampling.nearest, src_nodata=None, dst_nodata=QA_OUTSIDE,
               dtype="uint32", **kw)
    q[q == QA_OUTSIDE] = 1
    return q.astype(np.uint16)

SCL_OUTSIDE = 255   # not an SCL class (0-11)

def _read_scl(href, grid, win, **kw):
    """SCL COGs declare NO nodata, so dst_nodata=0 made GDAL bump valid SCL 0 ('no data') to 1 ('saturated/defective'),
    counting no-data pixels as observed (Phase-2 audit finding; reader_version 2). Read with an impossible sentinel instead."""
    q = _exact(href, grid, win, resampling=Resampling.nearest, src_nodata=None, dst_nodata=SCL_OUTSIDE, dtype="uint8", **kw)
    q[q == SCL_OUTSIDE] = 0
    return q

# ------------------------------------------------------------------------------- Landsat
LANDSAT_BANDS = list(config.load("landsat")["bands"])

def landsat(row, grid: Grid, restrict: Window | None = None) -> dict | None:
    cfg = config.load("landsat"); h = _hrefs(row)
    win = source_window(h["red"], grid, restrict)
    if win is None:
        return None
    F = factor(grid, 30)
    if F == 1:
        qa = _read_qa(h["qa_pixel"], grid, win)
        observed = landsat_qa.observed_mask(qa)
        clear = observed & landsat_qa.clear_mask(qa)
    else:
        qf = int(cfg["coarse_read"]["qa_overview_factor"]); k = F // qf
        fine = grid.refine(k, grid.id + f"_qa{qf}")
        qa = _read_qa(h["qa_pixel"], fine, _scale_window(win, k), max_overview_factor=qf)
        observed = landsat_qa.block_all(landsat_qa.observed_mask(qa), k)
        clear = observed & landsat_qa.block_all(landsat_qa.clear_mask(qa), k)
    vals = np.full((len(LANDSAT_BANDS), int(win.height), int(win.width)), np.nan, np.float32)
    nclip = 0
    if clear.any():
        for i, b in enumerate(LANDSAT_BANDS):
            dn = _exact(h[cfg["bands"][b]], grid, win,
                        resampling=Resampling.nearest if F == 1 else Resampling.average,
                        max_overview_factor=None if F == 1 else F / 2, src_nodata=0, dst_nodata=0, dtype="float32")
            refl, nc = landsat_qa.decode_sr(dn); nclip += nc
            vals[i] = refl
    valid = clear & np.all(np.isfinite(vals), axis=0)
    status = np.where(valid, 2, np.where(observed, 1, 0)).astype(np.uint8)
    vals[:, status != 2] = np.nan
    return {"win": win, "values": vals, "status": status, "n_clipped_negative": nclip, **_meta(row)}

# ------------------------------------------------------------------------------- Sentinel-2
def sentinel2(row, grid: Grid, restrict: Window | None = None) -> dict | None:
    cfg = config.load("sentinel2"); h = _hrefs(row); bands = cfg["bands"]
    win = source_window(h["B04"], grid, restrict)
    if win is None:
        return None
    if grid.res <= 20:
        scl = _read_scl(h[cfg["scl_asset"]], grid, win)
        observed = s2_scl.observed_mask(scl); clear = observed & s2_scl.clear_mask(scl)
    else:
        k = int(round(grid.res / 40))
        fine = grid.refine(k, grid.id + "_scl40")
        scl = _read_scl(h[cfg["scl_asset"]], fine, _scale_window(win, k), max_overview_factor=2)
        observed = landsat_qa.block_all(s2_scl.observed_mask(scl), k)
        clear = observed & landsat_qa.block_all(s2_scl.clear_mask(scl), k)
    vals = np.full((len(bands), int(win.height), int(win.width)), np.nan, np.float32)
    if clear.any():
        for i, (b, spec) in enumerate(bands.items()):
            nat = spec["res"]
            if grid.res == nat:
                rs, ovr = Resampling.nearest, None
            elif grid.res < nat:
                rs, ovr = Resampling.nearest, None          # 20 m band on 10 m grid: duplicate, no invention
            else:
                rs, ovr = Resampling.average, (grid.res / nat) / 2 if grid.res / nat >= 4 else None
            dn = _exact(h[spec["asset"]], grid, win, resampling=rs, max_overview_factor=ovr,
                        src_nodata=0, dst_nodata=0, dtype="float32")
            vals[i] = s2_scl.decode(dn, row["processing_baseline"])
    valid = clear & np.all(np.isfinite(vals), axis=0)
    status = np.where(valid, 2, np.where(observed, 1, 0)).astype(np.uint8)
    vals[:, status != 2] = np.nan
    return {"win": win, "values": vals, "status": status, "processing_baseline": row["processing_baseline"], **_meta(row)}

# ------------------------------------------------------------------------------- Sentinel-1
def sentinel1(row, grid: Grid, restrict: Window | None = None) -> dict | None:
    h = _hrefs(row)
    win = source_window(h["vv"], grid, restrict)
    if win is None:
        return None
    rs = Resampling.nearest if grid.res == 10 else Resampling.average
    ovr = (grid.res / 10) / 2 if grid.res / 10 >= 4 else None
    vals = np.stack([sar.clean_linear(_exact(h[p], grid, win, resampling=rs, max_overview_factor=ovr,
                                              src_nodata=-32768, dst_nodata=-32768, dtype="float32"))
                     for p in ("vv", "vh")])
    ok = np.all(np.isfinite(vals), axis=0)
    status = np.where(ok, 2, 0).astype(np.uint8)
    vals[:, ~ok] = np.nan
    m = _meta(row); m.update(orbit_state=row["orbit_state"], relative_orbit=int(row["relative_orbit"]) if row["relative_orbit"] is not None else None)
    return {"win": win, "values": vals, "status": status, **m}

LOADERS = {"landsat": landsat, "sentinel2": sentinel2, "sentinel1": sentinel1}
BAND_NAMES = {"landsat": LANDSAT_BANDS, "sentinel2": list(config.load("sentinel2")["bands"]), "sentinel1": ["vv", "vh"]}
