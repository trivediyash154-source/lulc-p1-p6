"""Silver-standard labels: unanimous, high-purity consensus of EXTERNAL land-cover products (never this project's composites).

L1: a 30 m cell gets class c iff the L1 fraction of c is >= min_purity in EVERY source (WorldCover 2020, 2021, Esri 2020, 2021).
    Fractions sum to 1 within a source, so with min_purity > 0.5 at most one class can qualify -> labels are unique.
L2: only where an external product supports the split (configs/labels.yaml: level2_support):
    natural vegetation -> 31 tree cover | 32 shrub/grass  (WorldCover tree vs shrub+grass AND Esri trees vs rangeland agree)
    built-up           -> 11 dense      | 12 low density  (WorldCover built fraction in the 3x3 (90 m) neighbourhood >= 0.67)
Known bias (documented in docs/label_protocol.md): pure, unanimous cells are the EASY cells -> accuracy against silver labels
is optimistic and is reported only as 'agreement with silver reference', never as map accuracy."""
from __future__ import annotations
import numpy as np, rasterio
from rasterio.enums import Resampling
from scipy.ndimage import uniform_filter
from .. import config
from ..grid import Grid
from ..io import write_cog, write_json
from ..provenance import utcnow
from ..acquisition.stac import client
from .sources import _bbox_ll, _warp

def _read(p):
    with rasterio.open(p) as s: a = s.read().astype(np.float32)
    a[a < 0] = np.nan; return a

def native_l2_fractions(grid: Grid) -> dict:
    """Tree / shrub-grass / built fractions per 30 m cell from WorldCover and Esri native classes (2020, 2021)."""
    fine = grid.refine(3, grid.id + "_10m"); bbox = _bbox_ll(grid); cat = client(); k = 3; H, W = grid.shape
    groups = {"esa-worldcover": ("map", {"tree": [10], "shrubgrass": [20, 30], "built": [50]}),
              "io-lulc-annual-v02": ("data", {"tree": [2], "shrubgrass": [11], "built": [7]})}
    out = {}
    for coll, (asset, cls) in groups.items():
        items = {}
        for it in cat.search(collections=[coll], bbox=bbox).items():
            yr = str(it.properties.get("start_datetime", it.datetime))[:4]
            if yr in ("2020", "2021"): items.setdefault(yr, []).append(it)
        for yr, its in items.items():
            c = np.zeros(fine.shape, np.uint8)
            for it in its:
                a = _warp(it.assets[asset].href, fine, Resampling.nearest, dst_nodata=0); c = np.where(a > 0, a, c)
            blk = c[:H * k, :W * k].reshape(H, k, W, k); valid = (blk > 0).sum(axis=(1, 3))
            for name, codes in cls.items():
                n = np.isin(blk, codes).sum(axis=(1, 3))
                out[f"{'wc' if 'worldcover' in coll else 'esri'}_{yr}_{name}"] = np.where(valid > 0, n / np.maximum(valid, 1), np.nan).astype(np.float32)
    return out

def build_silver(grid: Grid) -> dict:
    c = config.load("labels"); sc = c["silver_consensus"]; P = sc["min_purity"]
    d = config.path("data", "labels", grid.id)
    fr = np.stack([_read(d / f"{s}_l1_fractions.tif") for s in sc["sources"]])          # (S, 6, H, W)
    mn = np.min(np.where(np.isnan(fr), -1, fr), axis=0)                                    # (6, H, W) min over sources
    l1 = np.zeros(grid.shape, np.uint8)
    for ci in range(6): l1[mn[ci] >= P] = ci + 1
    # L2
    n2 = native_l2_fractions(grid)
    def all_ge(keys): return np.all(np.stack([np.nan_to_num(n2[k], nan=0) >= P for k in keys]), axis=0)
    l2 = np.zeros(grid.shape, np.uint8)
    tree = all_ge(["wc_2020_tree", "wc_2021_tree", "esri_2020_tree", "esri_2021_tree"])
    shr = all_ge(["wc_2020_shrubgrass", "wc_2021_shrubgrass", "esri_2020_shrubgrass", "esri_2021_shrubgrass"])
    l2[(l1 == 3) & tree] = 31; l2[(l1 == 3) & shr] = 32
    nb = np.minimum(uniform_filter(np.nan_to_num(n2["wc_2021_built"]), 3), uniform_filter(np.nan_to_num(n2["wc_2020_built"]), 3))
    l2[(l1 == 1) & (nb >= 0.67)] = 11; l2[(l1 == 1) & (nb < 0.67)] = 12
    write_cog(d / "silver_l1.tif", l1, grid, nodata=None, dtype="uint8", descriptions=["silver_l1_0_unlabelled"], overview_resampling="nearest")
    write_cog(d / "silver_l2.tif", l2, grid, nodata=None, dtype="uint8", descriptions=["silver_l2_0_unlabelled"], overview_resampling="nearest")
    names = c["level1_classes"]
    stats = {"cells": int(l1.size), "labelled": int((l1 > 0).sum()), "labelled_fraction": round(float((l1 > 0).mean()), 4),
             "l1_counts": {names[i]: int((l1 == i).sum()) for i in range(1, 7)},
             "l2_counts": {k: int((l2 == v).sum()) for k, v in {"built_dense": 11, "built_low": 12, "tree": 31, "shrub_grass": 32}.items()}}
    write_json(d / "silver_labels.json", {"grid": grid.to_dict(), "sources": sc["sources"], "min_purity": P, "rule": "unanimous",
               "created_utc": utcnow(), "stats": stats, "role": sc["role"]})
    return stats
