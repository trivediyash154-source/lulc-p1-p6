"""Bring every reference source onto a window's G30 grid (class fractions from 10-m products, independent built-up layers)."""
from __future__ import annotations
import io, json, zipfile
from pathlib import Path
import numpy as np
import planetary_computer as pc
import rasterio, requests
from rasterio.enums import Resampling
from rasterio.vrt import WarpedVRT
from .. import config
from ..grid import Grid
from ..io import write_cog, write_json
from ..provenance import utcnow
from ..acquisition.stac import client

RAW = config.path("data", "raw", "labels")

def _bbox_ll(grid: Grid):
    from pyproj import Transformer
    t = Transformer.from_crs(grid.crs, 4326, always_xy=True)
    x0, y0, x1, y1 = grid.bounds
    xs, ys = zip(*[t.transform(x, y) for x, y in [(x0, y0), (x0, y1), (x1, y0), (x1, y1)]])
    return [min(xs), min(ys), max(xs), max(ys)]

def _warp(href, grid, resampling, src_nodata=None, dst_nodata=0, dtype="uint8", sign=True):
    with rasterio.Env(**config.GDAL_ENV), rasterio.open(pc.sign(href) if sign else href) as src:
        with WarpedVRT(src, crs=grid.crs, transform=grid.transform, width=grid.width, height=grid.height,
                       resampling=resampling, src_nodata=src_nodata if src_nodata is not None else src.nodata,
                       nodata=dst_nodata, dtype=dtype) as v:
            return v.read(1)

def l1_fractions(classes_10m: np.ndarray, crosswalk: dict, k: int = 3) -> np.ndarray:
    """(6, H, W) fraction of k*k fine cells per L1 class; unmapped/nodata fine cells excluded from the denominator."""
    l1 = np.zeros_like(classes_10m, dtype=np.uint8)
    for src, dst in crosswalk.items(): l1[classes_10m == int(src)] = dst
    H, W = l1.shape[0] // k, l1.shape[1] // k
    blk = l1[:H * k, :W * k].reshape(H, k, W, k)
    counts = np.stack([(blk == c).sum(axis=(1, 3)) for c in range(1, 7)]).astype(np.float32)
    tot = counts.sum(0); return np.where(tot > 0, counts / np.maximum(tot, 1), np.nan)

def landcover_fractions(grid: Grid) -> dict:
    """ESA WorldCover 2020/2021 and Esri annual LULC 2017-2023 -> L1 fractions on `grid` (via a nested 10 m grid)."""
    cw = config.load("labels")["crosswalks"]; fine = grid.refine(3, grid.id + "_10m")
    out = config.path("data", "labels", grid.id); out.mkdir(parents=True, exist_ok=True)
    bbox = _bbox_ll(grid); cat = client(); made = {}
    for it in cat.search(collections=["esa-worldcover"], bbox=bbox).items():
        yr = str(it.properties.get("start_datetime", ""))[:4]
        made.setdefault(f"esa_worldcover_{yr}", []).append(it)
    for it in cat.search(collections=["io-lulc-annual-v02"], bbox=bbox).items():
        yr = str(it.properties.get("start_datetime", it.datetime))[:4]
        made.setdefault(f"esri_lulc_{yr}", []).append(it)
    res = {}
    for name, items in sorted(made.items()):
        cls = np.zeros(fine.shape, np.uint8)
        for it in items:
            a = _warp(it.assets["map" if "worldcover" in name else "data"].href, fine, Resampling.nearest, dst_nodata=0)
            cls = np.where(a > 0, a, cls)
        fr = l1_fractions(cls, cw["esa_worldcover" if "worldcover" in name else "esri_lulc"])
        write_cog(out / f"{name}_l1_fractions.tif", np.nan_to_num(fr, nan=-1).astype(np.float32), grid, nodata=-1, dtype="float32",
                  descriptions=[f"frac_{v}" for v in config.load("labels")["level1_classes"].values()])
        if name == "esa_worldcover_2021":   # keep native WorldCover classes for L2 (forest vs shrub/grass)
            k = 3; H, W = grid.shape
            blk = cls[:H * k, :W * k].reshape(H, k, W, k)
            l2 = np.stack([(blk == c).sum(axis=(1, 3)) / 9.0 for c in (10, 20, 30, 50)]).astype(np.float32)
            write_cog(out / "esa_worldcover_2021_l2_fractions.tif", l2, grid, nodata=None, dtype="float32",
                      descriptions=["frac_tree", "frac_shrub", "frac_grass", "frac_built"])
        res[name] = {"items": [i.id for i in items], "valid_cells": int(np.isfinite(fr[0]).sum())}
    write_json(out / "landcover_sources.json", {"grid": grid.to_dict(), "sources": res, "created_utc": utcnow(),
               "method": "nearest onto nested 10 m grid (G30 refined x3), L1 fraction per 30 m cell"})
    return res

def _download(url: str, dest: Path) -> Path:
    dest.parent.mkdir(parents=True, exist_ok=True)
    if dest.exists() and dest.stat().st_size > 0: return dest
    with requests.get(url, stream=True, timeout=600) as r:
        r.raise_for_status(); tmp = dest.with_suffix(dest.suffix + ".part")
        with open(tmp, "wb") as f:
            for ch in r.iter_content(1 << 20): f.write(ch)
        tmp.replace(dest)
    return dest

def ghsl_built(grid: Grid) -> dict:
    """GHS-BUILT-S R2023A (100 m, built surface m² per cell) for every epoch -> built FRACTION on a 90 m grid nested in `grid`."""
    c = config.load("labels")["independent_validation"]["ghsl_built_s"]
    g90 = Grid(grid.id + "_90m", grid.crs, 90.0, grid.x0, grid.y1, grid.width // 3, grid.height // 3, grid.corner_offset)
    out = config.path("data", "labels", grid.id); out.mkdir(parents=True, exist_ok=True); stack = []
    for ep in c["epochs"]:
        z = _download(c["url"].format(epoch=ep, tile=c["tile"]), RAW / "ghsl" / f"GHS_BUILT_S_E{ep}_{c['tile']}.zip")
        with zipfile.ZipFile(z) as zf:
            tif = [n for n in zf.namelist() if n.endswith(".tif")][0]
            p = RAW / "ghsl" / Path(tif).name
            if not p.exists(): p.write_bytes(zf.read(tif))
        # average of the 100 m built-surface field onto 90 m cells, then m² -> fraction (100 m cell = 10,000 m²)
        a = _warp(str(p), g90, Resampling.bilinear, dst_nodata=-1, dtype="float32", sign=False)
        stack.append(np.where(a >= 0, np.clip(a / 10000.0, 0, 1), np.nan))
    arr = np.stack(stack).astype(np.float32)
    write_cog(out / "ghsl_built_fraction_90m.tif", np.nan_to_num(arr, nan=-1), g90, nodata=-1, dtype="float32",
              descriptions=[f"built_frac_{e}" for e in c["epochs"]])
    write_json(out / "ghsl_built_fraction_90m.json", {"source": c["citation"], "epochs": c["epochs"], "grid": g90.to_dict(),
               "method": "bilinear onto 90 m grid nested in G30 (3x3), built m² / 10,000", "created_utc": utcnow()})
    return {"epochs": c["epochs"], "mean_fraction": [float(np.nanmean(x)) for x in arr]}

def wsf_evolution(grid: Grid) -> dict:
    """WSF-Evolution (first year settled 1985-2015, 30 m) -> nearest onto `grid`."""
    c = config.load("labels")["independent_validation"]["wsf_evolution"]
    lo0, la0, lo1, la1 = _bbox_ll(grid)
    tiles = {(int(np.floor(x / 2) * 2), int(np.floor(y / 2) * 2)) for x in (lo0, lo1) for y in (la0, la1)}
    out = config.path("data", "labels", grid.id); first = np.zeros(grid.shape, np.uint16); covered = np.zeros(grid.shape, bool)
    for lon, lat in sorted(tiles):
        p = _download(c["url"].format(lon=lon, lat=lat), RAW / "wsf" / f"WSFevolution_v1_{lon}_{lat}.tif")
        # NB: dst nodata must not be a valid source value. With dst_nodata=0 GDAL's warper silently bumps valid 0
        # ("never settled") to 1, turning every cell into "settled in year 1". 65535 = outside tile coverage.
        a = _warp(str(p), grid, Resampling.nearest, src_nodata=None, dst_nodata=65535, dtype="uint16", sign=False)
        bad = (a != 65535) & (a != 0) & ((a < 1985) | (a > 2015))
        if bad.any(): raise ValueError(f"WSF-Evolution tile {p.name}: {int(bad.sum())} cells outside {{0, 1985..2015}}")
        first = np.where(a != 65535, a, first); covered |= a != 65535
    write_cog(out / "wsf_evolution_first_year.tif", first, grid, nodata=None, dtype="uint16",
              descriptions=["first_year_settled_0_never"], overview_resampling="nearest")
    write_json(out / "wsf_evolution_first_year.json", {"source": c["citation"], "tiles": sorted(tiles), "grid": grid.to_dict(),
               "method": "nearest onto G30 (native ~30 m)", "created_utc": utcnow()})
    if not covered.all(): raise ValueError(f"WSF-Evolution tiles do not cover {int((~covered).sum())} cells of {grid.id}")
    yrs = first[first > 0]
    return {"cells": int(first.size), "settled_cells_2015": int((first > 0).sum()),
            "first_year_range": [int(yrs.min()), int(yrs.max())] if yrs.size else None,
            "settled_by_year": {int(y): int((first == y).sum()) for y in np.unique(yrs)}}

def jrc_water(grid: Grid) -> dict:
    """JRC Global Surface Water (version from item id; PC serves v1.3, 1984-2020; Landsat-derived, independent of this project's composites):
    occurrence %, recurrence %, seasonality (months), transitions class, nearest onto `grid` (native 30 m).
    The YEARLY history is only on Google Earth Engine -> PENDING credentials (configs/labels.yaml)."""
    items = list(client().search(collections=["jrc-gsw"], bbox=_bbox_ll(grid)).items())
    assets = ["occurrence", "recurrence", "seasonality", "transitions"]
    out = config.path("data", "labels", grid.id); stack = []
    for a_name in assets:
        acc = np.full(grid.shape, 255, np.uint8)
        for it in items:
            a = _warp(it.assets[a_name].href, grid, Resampling.nearest, src_nodata=255, dst_nodata=255)
            m = a != 255; acc[m] = a[m]
        stack.append(acc)
    arr = np.stack(stack)
    write_cog(out / "jrc_gsw.tif", arr, grid, nodata=255, dtype="uint8", descriptions=[f"jrc_{a}" for a in assets],
              overview_resampling="nearest")
    write_json(out / "jrc_gsw.json", {"source": "Pekel et al. 2016 Nature; JRC GSW via Planetary Computer jrc-gsw (item ids record version)",
               "items": [i.id for i in items], "assets": assets, "nodata": 255, "created_utc": utcnow(),
               "method": "nearest onto G30 (same 30 m Landsat lattice family)", "grid": grid.to_dict()})
    occ = arr[0]
    return {"items": [i.id for i in items], "valid_cells": int((occ != 255).sum()),
            "occ_ge_50_cells": int(((occ >= 50) & (occ != 255)).sum()), "occ_ge_90_cells": int(((occ >= 90) & (occ != 255)).sum())}
