"""Reference / label system: silver consensus labels, independent validation layers, strict spatial splits."""
