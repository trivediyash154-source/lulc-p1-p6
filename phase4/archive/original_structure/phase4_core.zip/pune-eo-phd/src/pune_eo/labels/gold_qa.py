"""Gold-sample quality control: agreement statistics, confidence tiers, Gate 1.

Agreement: Cohen's kappa (2 raters), Fleiss' kappa (>= 2 raters, complete), Krippendorff's alpha (nominal; tolerates missing ratings).
'uncertain' / 'ambiguous' are recorded but EXCLUDED from the main accuracy set; their share and effect are reported separately.
Gate 1 (configs/phase3.yaml): Tier-A labels for >= 80 % of points of the epoch AND Cohen's kappa >= 0.6 on >= 20 % double-interpreted subset."""
from __future__ import annotations
import numpy as np, pandas as pd

ABSTAIN = {"uncertain", "ambiguous", "", "nan", "None"}

def cohen_kappa(a, b) -> float:
    a, b = np.asarray(a, object), np.asarray(b, object); cats = sorted(set(a) | set(b)); n = len(a)
    if n == 0: return float("nan")
    po = float(np.mean(a == b)); pe = sum((np.mean(a == c)) * (np.mean(b == c)) for c in cats)
    return float((po - pe) / (1 - pe)) if pe < 1 else 1.0

def fleiss_kappa(M: np.ndarray) -> float:
    """M (N items x K categories) counts of raters per category; equal raters per item."""
    M = np.asarray(M, float); N, k = M.shape; n = M[0].sum()
    p = M.sum(0) / (N * n); P = ((M ** 2).sum(1) - n) / (n * (n - 1)); Pbar, Pe = P.mean(), (p ** 2).sum()
    return float((Pbar - Pe) / (1 - Pe)) if Pe < 1 else 1.0

def krippendorff_alpha_nominal(ratings: list[list]) -> float:
    """ratings: list over items of the labels given by the raters (None = missing). Nominal metric."""
    units = [[r for r in u if r is not None] for u in ratings]; units = [u for u in units if len(u) >= 2]
    if not units: return float("nan")
    cats = sorted({r for u in units for r in u}); idx = {c: i for i, c in enumerate(cats)}; O = np.zeros((len(cats), len(cats)))
    for u in units:
        m = len(u)
        for i, a in enumerate(u):
            for j, b in enumerate(u):
                if i != j: O[idx[a], idx[b]] += 1 / (m - 1)
    n_c = O.sum(1); n = n_c.sum(); Do = (O.sum() - np.trace(O)) / n
    De = (n * n - (n_c ** 2).sum()) / (n * (n - 1))
    return float(1 - Do / De) if De > 0 else 1.0

def tiers(df: pd.DataFrame, cls_col: str, conf_col: str) -> pd.Series:
    c = df[cls_col].astype(str).str.strip().str.lower(); conf = pd.to_numeric(df[conf_col], errors="coerce")
    return pd.Series(np.select([c.isin(ABSTAIN) | df[cls_col].isna(), conf >= 3, conf == 2], ["ambiguous_or_uncertain", "high_confidence", "medium_confidence"], "low_confidence"), index=df.index)

def gate1(form1: pd.DataFrame, form2: pd.DataFrame | None, epoch: int, min_cov: float = 0.8, min_kappa: float = 0.6, min_double: float = 0.2) -> dict:
    col = f"reference_class_{epoch}"; lab = form1[col].astype(str).str.strip().str.lower()
    valid = ~(lab.isin(ABSTAIN) | form1[col].isna()); cov = float(valid.mean())
    res = {"epoch": epoch, "coverage_non_abstain": cov, "n_points": len(form1), "kappa": None, "n_double": 0}
    if form2 is not None and col in form2:
        m = form1[["anon_id", col]].merge(form2[["anon_id", col]], on="anon_id", suffixes=("_1", "_2")).dropna()
        m = m[~m[f"{col}_1"].astype(str).str.lower().isin(ABSTAIN) & ~m[f"{col}_2"].astype(str).str.lower().isin(ABSTAIN)]
        res["n_double"] = len(m)
        if len(m): res["kappa"] = cohen_kappa(m[f"{col}_1"].str.lower(), m[f"{col}_2"].str.lower())
    res["passed"] = bool(cov >= min_cov and res["kappa"] is not None and res["kappa"] >= min_kappa and res["n_double"] >= min_double * len(form1))
    res["criterion"] = f"coverage >= {min_cov}, kappa >= {min_kappa} on >= {int(100 * min_double)} % double-interpreted"
    return res
