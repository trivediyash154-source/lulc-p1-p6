"""Spatial-block train/val/test splits with a leakage buffer.

Blocks are aligned to ABSOLUTE map coordinates (multiples of block_size_m in EPSG:32643), and each block's split is a
deterministic hash of (block column, block row, seed). The same location therefore gets the same split in every window,
on every grid and in any later district-wide run - a test block can never reappear as training data elsewhere.
Cells within buffer_px of a cell from a different split are excluded (0) so neighbourhood features (texture windows)
cannot straddle a split boundary."""
from __future__ import annotations
import hashlib
import numpy as np
from scipy.ndimage import maximum_filter, minimum_filter
from .. import config
from ..grid import Grid
from ..io import write_cog, write_json
from ..provenance import utcnow

SPLIT_CODES = {0: "excluded_buffer", 1: "train", 2: "val", 3: "test"}

def _u(bx: int, by: int, seed: int) -> float:
    h = hashlib.sha256(f"{bx}:{by}:{seed}".encode()).digest()
    return int.from_bytes(h[:8], "big") / 2 ** 64

def block_index(grid: Grid, block_m: float) -> tuple[np.ndarray, np.ndarray]:
    xs = grid.x0 + (np.arange(grid.width) + 0.5) * grid.res
    ys = grid.y1 - (np.arange(grid.height) + 0.5) * grid.res
    return np.meshgrid(np.floor(xs / block_m).astype(np.int64), np.floor(ys / block_m).astype(np.int64))

def make_splits(grid: Grid, write: bool = True, block_m: float | None = None) -> dict:
    c = dict(config.load("labels")["splits"]); f = c["fractions"]
    if block_m is not None: c["block_size_m"] = block_m
    if c["block_size_m"] == 0:            # random PIXEL split - only for the leakage-sensitivity experiment, never written
        u = np.random.default_rng(c["seed"]).random(grid.shape)
        split = np.where(u < f["train"], 1, np.where(u < f["train"] + f["val"], 2, 3)).astype(np.uint8)
        return {"split": split, "cells": {SPLIT_CODES[s]: int((split == s).sum()) for s in (1, 2, 3)}, "block_size_m": 0}
    bx, by = block_index(grid, c["block_size_m"])
    ub = {(i, j): _u(i, j, c["seed"]) for i, j in set(zip(bx.ravel().tolist(), by.ravel().tolist()))}
    u = np.vectorize(lambda i, j: ub[(i, j)])(bx, by)
    split = np.where(u < f["train"], 1, np.where(u < f["train"] + f["val"], 2, 3)).astype(np.uint8)
    k = 2 * c["buffer_px"] + 1
    mixed = maximum_filter(split, size=k, mode="nearest") != minimum_filter(split, size=k, mode="nearest")
    out = np.where(mixed, 0, split).astype(np.uint8)
    blocks = {s: sum(1 for (i, j), v in ub.items() if (v < f["train"]) == (s == 1) and
                     ((f["train"] <= v < f["train"] + f["val"]) == (s == 2)) and ((v >= f["train"] + f["val"]) == (s == 3))) for s in (1, 2, 3)}
    stats = {"cells": {SPLIT_CODES[s]: int((out == s).sum()) for s in SPLIT_CODES}, "blocks": {SPLIT_CODES[s]: n for s, n in blocks.items()},
             "block_size_m": c["block_size_m"], "buffer_px": c["buffer_px"], "seed": c["seed"]}
    if write:
        d = config.path("data", "labels", grid.id)
        write_cog(d / "splits.tif", out, grid, nodata=None, dtype="uint8", descriptions=["split_0excl_1train_2val_3test"], overview_resampling="nearest")
        write_json(d / "splits.json", {"grid": grid.to_dict(), "codes": SPLIT_CODES, "created_utc": utcnow(), "stats": stats,
                   "method": "absolute-coordinate blocks; split = sha256(bx:by:seed) uniform; buffer excludes mixed neighbourhoods"})
    return {"split": out, **stats}
