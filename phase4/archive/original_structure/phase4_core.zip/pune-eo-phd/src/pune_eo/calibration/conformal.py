"""Split-conformal prediction sets for multi-class probabilities (labels are 1-based class codes).
LAC (least ambiguous set-valued classifier, Sadinle et al. 2019), APS (adaptive prediction sets, Romano et al. 2020, randomised),
class-conditional (Mondrian) LAC. Coverage guarantees hold only under exchangeability of calibration and test data -
across landscapes they are NOT guaranteed, which is exactly what Phase 3 tests."""
from __future__ import annotations
import numpy as np

def _q(scores, alpha):
    n = len(scores); return float(np.quantile(scores, min(1.0, np.ceil((n + 1) * (1 - alpha)) / n), method="higher"))

def lac_threshold(p, y, alpha=0.1): return _q(1 - p[np.arange(len(y)), y - 1], alpha)
def lac_sets(p, q): return p >= 1 - q

def aps_scores(p, y, u):
    o = np.argsort(-p, 1); ps = np.take_along_axis(p, o, 1); cs = np.cumsum(ps, 1); r = np.argmax(o == (y - 1)[:, None], 1)
    return cs[np.arange(len(y)), r] - u * ps[np.arange(len(y)), r]
def aps_threshold(p, y, alpha=0.1, rng=None): rng = rng or np.random.default_rng(0); return _q(aps_scores(p, y, rng.random(len(y))), alpha)
def aps_sets(p, q, rng=None):
    rng = rng or np.random.default_rng(0); o = np.argsort(-p, 1); ps = np.take_along_axis(p, o, 1); cs = np.cumsum(ps, 1)
    keep = (cs - rng.random(len(p))[:, None] * ps) <= q; keep[:, 0] = True; S = np.zeros_like(p, bool); np.put_along_axis(S, o, keep, 1); return S

def classcond_thresholds(p, y, alpha=0.1, min_n=20): return {k: lac_threshold(p[y == k], y[y == k], alpha) for k in range(1, p.shape[1] + 1) if (y == k).sum() >= min_n}
def classcond_sets(p, qs):
    S = np.zeros_like(p, bool)
    for k, q in qs.items(): S[:, k - 1] = p[:, k - 1] >= 1 - q
    return S

def coverage(S, y, names=None):
    names = names or [str(k) for k in range(1, S.shape[1] + 1)]
    return {"coverage": float(S[np.arange(len(y)), y - 1].mean()), "mean_set_size": float(S.sum(1).mean()), "empty_set_rate": float((S.sum(1) == 0).mean()),
            "coverage_by_class": {n: (float(S[y == k][:, k - 1].mean()) if (y == k).any() else None) for k, n in enumerate(names, 1)}}
