"""Calibration metrics and recalibration maps (multi-class).
metrics: top-label ECE (equal-width bins), classwise ECE, multi-class Brier, NLL, reliability table.
maps: temperature scaling (on log-probabilities), one-vs-rest isotonic, one-vs-rest Platt (logistic on logit of p_k)."""
from __future__ import annotations
import numpy as np
from scipy.optimize import minimize_scalar

def ece(p, y, bins=15):
    conf = p.max(1); pred = p.argmax(1); out = 0.0
    for lo in np.linspace(0, 1, bins + 1)[:-1]:
        s = (conf > lo) & (conf <= lo + 1 / bins)
        if s.any(): out += s.mean() * abs((pred[s] == y[s]).mean() - conf[s].mean())
    return float(out)

def classwise_ece(p, y, bins=15):
    return float(np.mean([ece(np.stack([1 - p[:, k], p[:, k]], 1), (y == k).astype(int), bins) for k in range(p.shape[1])]))

def brier(p, y): Y = np.eye(p.shape[1])[y]; return float(((p - Y) ** 2).sum(1).mean())
def nll(p, y): return float(-np.log(np.clip(p[np.arange(len(y)), y], 1e-12, 1)).mean())

def reliability(p, y, bins=10):
    conf = p.max(1); pred = p.argmax(1); rows = []
    for lo in np.linspace(0, 1, bins + 1)[:-1]:
        s = (conf > lo) & (conf <= lo + 1 / bins)
        rows.append({"bin_lo": float(lo), "n": int(s.sum()), "mean_conf": float(conf[s].mean()) if s.any() else None, "accuracy": float((pred[s] == y[s]).mean()) if s.any() else None})
    return rows

def all_metrics(p, y):
    return {"ece": ece(p, y), "classwise_ece": classwise_ece(p, y), "brier": brier(p, y), "nll": nll(p, y), "accuracy": float((p.argmax(1) == y).mean()),
            "mean_confidence": float(p.max(1).mean()), "reliability": reliability(p, y)}

class Temperature:
    def fit(self, p, y):
        lp = np.log(np.clip(p, 1e-12, 1)); f = lambda T: nll(self._apply(lp, T), y)
        self.T = float(minimize_scalar(f, bounds=(0.05, 20), method="bounded").x); return self
    @staticmethod
    def _apply(lp, T): z = lp / T; z -= z.max(1, keepdims=True); e = np.exp(z); return e / e.sum(1, keepdims=True)
    def transform(self, p): return self._apply(np.log(np.clip(p, 1e-12, 1)), self.T)

class Isotonic:
    def fit(self, p, y):
        from sklearn.isotonic import IsotonicRegression
        self.m = [IsotonicRegression(out_of_bounds="clip", y_min=1e-4, y_max=1 - 1e-4).fit(p[:, k], (y == k).astype(float)) for k in range(p.shape[1])]; return self
    def transform(self, p):
        q = np.stack([m.predict(p[:, k]) for k, m in enumerate(self.m)], 1); return q / q.sum(1, keepdims=True)

class Platt:
    def fit(self, p, y):
        from sklearn.linear_model import LogisticRegression
        lg = lambda v: np.log(np.clip(v, 1e-6, 1 - 1e-6) / (1 - np.clip(v, 1e-6, 1 - 1e-6)))
        self.lg = lg; self.m = [LogisticRegression().fit(lg(p[:, [k]]), (y == k).astype(int)) if len(np.unique(y == k)) == 2 else None for k in range(p.shape[1])]; return self
    def transform(self, p):
        q = np.stack([m.predict_proba(self.lg(p[:, [k]]))[:, 1] if m is not None else p[:, k] for k, m in enumerate(self.m)], 1); return q / q.sum(1, keepdims=True)
