"""Temporal models for Phase 3.
- sequences(): (N, T, C) per-cell sequences from the HET (B3 features per year) with observation masks
- TempCNN / GRU / Transformer classifiers: pune_eo.agriculture.timeseries.build/train (masked inputs, NaN never shown as data)
- ssl.MAE: masked-autoencoder pretraining over full 1990-2026 annual sequences (pune_eo.temporal_models.ssl)"""
from __future__ import annotations
import numpy as np
from ..historical_reconstruction import features as F

def window_sequence(H, year: int, idx, half: int = 2, feats=F.B3) -> np.ndarray:
    """(N, 2*half+1, C) of feats for years year-half..year+half (NaN where missing/out of range)."""
    years = H["info"]["years"]; fi = [H["info"]["features"].index(f) for f in feats]; yi = years.index(year); out = []
    for k in range(-half, half + 1):
        j = yi + k
        out.append(H["L"][idx, j][:, fi] if 0 <= j < len(years) else np.full((len(idx), len(fi)), np.nan, np.float32))
    return np.stack(out, 1).astype(np.float32)

def full_sequence(H, idx, feats=F.B3) -> np.ndarray:
    fi = [H["info"]["features"].index(f) for f in feats]; return H["L"][idx][:, :, fi].astype(np.float32)
