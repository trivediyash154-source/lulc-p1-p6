"""Self-supervised masked autoencoding (MAE) over annual EO sequences (37 years x C features + observation mask).

Pretext: randomly hide 40 % of OBSERVED years (feature values replaced by a learned mask token), reconstruct their standardised values (MSE on
hidden, observed entries only). Missing years are never reconstructed targets and are flagged to the encoder by the mask channel.
Downstream: the encoder token at year t represents the cell in year t -> linear probe (frozen) or fine-tuning (G2 / G3)."""
from __future__ import annotations
import numpy as np

def _torch():
    import torch, torch.nn as nn
    return torch, nn

def standardise(X, stats=None):
    if stats is None: stats = (np.nanmean(X, axis=(0, 1)), np.nanstd(X, axis=(0, 1)) + 1e-6)
    Z = (X - stats[0]) / stats[1]; m = np.isfinite(Z).all(-1); return np.where(np.isfinite(Z), Z, 0.0).astype(np.float32), m, stats

def build_encoder(c_in: int, T: int, d: int = 64, heads: int = 4, layers: int = 2, p: float = 0.1):
    torch, nn = _torch()
    class Enc(nn.Module):
        def __init__(s):
            super().__init__(); s.inp = nn.Linear(c_in + 1, d); s.pos = nn.Parameter(torch.randn(1, T, d) * 0.02); s.mask_tok = nn.Parameter(torch.zeros(1, 1, c_in))
            s.enc = nn.TransformerEncoder(nn.TransformerEncoderLayer(d, heads, 2 * d, p, batch_first=True), layers)
        def forward(s, z, obs, hide=None):
            if hide is not None: z = torch.where(hide.unsqueeze(-1), s.mask_tok.expand_as(z), z)
            vis = obs & (hide is None or True); vis = obs if hide is None else obs & ~hide
            h = s.inp(torch.cat([z, vis.float().unsqueeze(-1)], -1)) + s.pos
            return s.enc(h)
    return Enc()

def pretrain(Z, obs, c_in, epochs=8, bs=256, lr=1e-3, mask_ratio=0.4, seed=0, threads=2, log=None):
    torch, nn = _torch(); torch.manual_seed(seed); np.random.seed(seed); torch.set_num_threads(threads)
    T = Z.shape[1]; enc = build_encoder(c_in, T); head = nn.Linear(64, c_in); opt = torch.optim.AdamW(list(enc.parameters()) + list(head.parameters()), lr=lr, weight_decay=1e-4)
    Zt, Ot = torch.tensor(Z), torch.tensor(obs); hist = []
    for ep in range(epochs):
        perm = torch.randperm(len(Zt)); tot = 0.0; nb = 0
        for i in range(0, len(Zt), bs):
            b = perm[i:i + bs]; z, o = Zt[b], Ot[b]; hide = (torch.rand(o.shape) < mask_ratio) & o
            rec = head(enc(z, o, hide)); err = ((rec - z) ** 2).mean(-1); loss = (err * hide).sum() / hide.sum().clamp(min=1)
            opt.zero_grad(); loss.backward(); opt.step(); tot += float(loss); nb += 1
        hist.append(tot / nb)
        if log: log(f"MAE epoch {ep + 1}: {hist[-1]:.4f}")
    return enc, hist

def embed(enc, Z, obs, t_index, bs=2048):
    torch, _ = _torch(); enc.eval(); out = []
    with torch.no_grad():
        for i in range(0, len(Z), bs):
            h = enc(torch.tensor(Z[i:i + bs]), torch.tensor(obs[i:i + bs])); out.append(h[:, t_index].numpy())
    return np.concatenate(out)

def finetune(enc, Z, obs, t_index, y, n_cls, Zv=None, ov=None, yv=None, epochs=15, bs=256, lr=5e-4, seed=0, freeze=False, threads=2):
    """Train a linear head (+ encoder unless freeze) to predict class at year t_index. Returns (encoder, head)."""
    torch, nn = _torch(); torch.manual_seed(seed); torch.set_num_threads(threads); head = nn.Linear(64, n_cls)
    params = list(head.parameters()) + ([] if freeze else list(enc.parameters())); opt = torch.optim.AdamW(params, lr=lr, weight_decay=1e-4)
    w = torch.tensor(len(y) / (n_cls * np.bincount(y, minlength=n_cls).clip(1)), dtype=torch.float32); lossf = nn.CrossEntropyLoss(weight=w)
    Zt, Ot, yt = torch.tensor(Z), torch.tensor(obs), torch.tensor(y); best, best_state, bad = np.inf, None, 0
    for ep in range(epochs):
        enc.train(not freeze); perm = torch.randperm(len(yt))
        for i in range(0, len(yt), bs):
            b = perm[i:i + bs]; logits = head(enc(Zt[b], Ot[b])[:, t_index]); loss = lossf(logits, yt[b]); opt.zero_grad(); loss.backward(); opt.step()
        if Zv is not None:
            enc.eval()
            with torch.no_grad(): vl = float(lossf(head(enc(torch.tensor(Zv), torch.tensor(ov))[:, t_index]), torch.tensor(yv)))
            if vl < best - 1e-4: best, bad, best_state = vl, 0, ({k: v.clone() for k, v in enc.state_dict().items()}, {k: v.clone() for k, v in head.state_dict().items()})
            else:
                bad += 1
                if bad >= 4: break
    if best_state: enc.load_state_dict(best_state[0]); head.load_state_dict(best_state[1])
    return enc, head

def predict(enc, head, Z, obs, t_index, bs=4096):
    torch, _ = _torch(); enc.eval(); out = []
    with torch.no_grad():
        for i in range(0, len(Z), bs): out.append(torch.softmax(head(enc(torch.tensor(Z[i:i + bs]), torch.tensor(obs[i:i + bs]))[:, t_index]), -1).numpy())
    return np.concatenate(out)
