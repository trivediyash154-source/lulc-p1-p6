"""Monsoon open-water / inundation FREQUENCY from every Sentinel-1 acquisition (Jun-Oct), 2017-2025, on a 30 m window.

Per acquisition: water if VV_dB < t_VV AND VH_dB < t_VH, where t_* are Otsu thresholds of that acquisition fitted on a
bimodal calibration sample (JRC permanent water >= 90 % vs stable land), clipped to physically plausible ranges
(VV in [-22, -12] dB, VH in [-28, -18] dB). Masks: slope > 5 deg or HAND > 20 m (radar shadow/layover on Ghats slopes, no
floodplain), JRC permanent water (reported separately). Frequency = water detections / valid acquisitions per monsoon.
Limits (stated in every output): urban double-bounce hides water among buildings; wet bare soil and smooth surfaces can
mimic water; 12-day single-orbit revisit misses short floods - frequency is of OBSERVED open water, not flood hazard."""
from __future__ import annotations
import time
import numpy as np, pandas as pd, rasterio
from .. import config
from ..compositing.engine import load_manifest
from ..compositing import observations as obs
from ..compositing.windows import resolve

def _otsu(x, bins=128):
    x = x[np.isfinite(x)]
    if x.size < 100: return np.nan
    h, e = np.histogram(x, bins=bins); c = (e[:-1] + e[1:]) / 2; w0 = np.cumsum(h); w1 = w0[-1] - w0
    m0 = np.cumsum(h * c) / np.maximum(w0, 1); m1 = (np.sum(h * c) - np.cumsum(h * c)) / np.maximum(w1, 1)
    return float(c[np.argmax(w0 * w1 * (m0 - m1) ** 2)])

def run(window: str, years=range(2017, 2026), months=(6, 7, 8, 9, 10)) -> dict:
    g, win, wn = resolve("G30", window); sub = g.subgrid(win, f"_{wn}"); gid = sub.id
    with rasterio.open(config.path("data/labels", gid, "jrc_gsw.tif")) as s: jrc = s.read(1).astype(float)
    with rasterio.open(config.path("data/features/terrain", gid, "terrain.tif")) as s:
        t = s.read(); dsc = list(s.descriptions); slope, hand = t[dsc.index("slope_deg")], t[dsc.index("hand_m")]
    perm = (jrc >= 90) & (jrc != 255); land = (jrc == 0); mask = (slope <= 5) & (hand <= 20) & np.isfinite(slope)
    man = load_manifest("sentinel1"); man = man[man.year.isin(list(years)) & man.month.isin(list(months))]
    rows = []; H, W = sub.shape; count = {y: np.zeros((H, W), np.uint16) for y in years}; nval = {y: np.zeros((H, W), np.uint16) for y in years}
    t0 = time.time()
    man = man.assign(_d=man.datetime_utc.astype(str).str[:10])
    for (day, orb), grp in man.sort_values("datetime_utc").groupby(["_d", "relative_orbit"]):     # mosaic all frames of one pass
        acc = np.zeros((2, H, W)); nn = np.zeros((H, W)); item = None
        for _, r in grp.iterrows():
            try:
                o = obs.sentinel1(r.to_dict(), g, win)
            except Exception as e:
                rows.append({"item": r["product_id"], "date": day, "status": f"read_error {e!r}"[:120]}); continue
            if o is None: continue
            c0, r0 = int(o["win"].col_off - win.col_off), int(o["win"].row_off - win.row_off); h, w = o["values"].shape[1:]
            v = o["values"]; okf = np.isfinite(v).all(0); sl = (slice(r0, r0 + h), slice(c0, c0 + w))
            acc[:, sl[0], sl[1]][:, okf] += v[:, okf]; nn[sl][okf] += 1; item = o["item_id"]
        if item is None: continue
        V = np.where(nn > 0, acc / np.maximum(nn, 1), np.nan).astype(np.float32); o = {"item_id": f"{day}_orbit{orb}_{len(grp)}frames", "date": day}
        with np.errstate(all="ignore"): db = 10 * np.log10(V)
        ok = np.isfinite(db).all(0)
        if ok.mean() < 0.5: rows.append({"item": o["item_id"], "date": o["date"], "status": "low_coverage", "coverage": float(ok.mean())}); continue
        cal = ok & (perm | land)
        tv = float(np.clip(_otsu(db[0][cal]), -22, -12)) if perm.sum() >= 200 else -16.0
        th = float(np.clip(_otsu(db[1][cal]), -28, -18)) if perm.sum() >= 200 else -23.0
        wat = ok & (db[0] < tv) & (db[1] < th)
        y = int(str(o["date"])[:4]); count[y] += (wat & mask).astype(np.uint16); nval[y] += (ok & mask).astype(np.uint16)
        rows.append({"item": o["item_id"], "date": o["date"], "status": "ok", "coverage": float(ok.mean()), "t_vv": tv, "t_vh": th,
                     "perm_water_recall": float(wat[perm & ok].mean()) if (perm & ok).any() else None,
                     "land_false_rate": float(wat[land & ok & mask].mean()) if (land & ok & mask).any() else None,
                     "water_px_nonperm_masked": int((wat & mask & ~perm).sum())})
    freq = {y: np.where(nval[y] > 0, count[y] / np.maximum(nval[y], 1), np.nan).astype(np.float32) for y in years}
    return {"grid": sub, "freq": freq, "nval": nval, "perm": perm, "mask": mask, "log": pd.DataFrame(rows), "seconds": time.time() - t0}
