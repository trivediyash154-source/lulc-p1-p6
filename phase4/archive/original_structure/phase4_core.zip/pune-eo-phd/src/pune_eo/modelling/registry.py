"""Experiment registry: one immutable JSON record per experiment in experiments/registry/.

Required fields (spec): experiment id, research question, hypothesis, dataset version, years, resolution, features, labels,
split strategy, model, hyperparameters, random seed, metrics, uncertainty, result, output paths, code version.
A record is written only by `finish()` with real metrics; `start()` writes status RUNNING, failures are recorded as FAILED
with the error - nothing is ever back-filled by hand."""
from __future__ import annotations
import json, platform, subprocess, time
from pathlib import Path
from .. import config
from ..provenance import utcnow

REG = config.path("experiments", "registry")
REQUIRED = ["experiment_id", "research_question", "hypothesis", "dataset_version", "years", "resolution_m", "features", "labels",
            "split", "model", "hyperparameters", "seed"]

def _git():
    try:
        c = subprocess.run(["git", "-C", str(config.ROOT), "rev-parse", "--short", "HEAD"], capture_output=True, text=True).stdout.strip()
        d = subprocess.run(["git", "-C", str(config.ROOT), "status", "--porcelain", "src", "configs", "scripts"], capture_output=True, text=True).stdout.strip()
        return c + ("-dirty" if d else "")
    except Exception:
        return "no-git"

class Experiment:
    def __init__(self, **kw):
        missing = [k for k in REQUIRED if k not in kw]
        if missing: raise ValueError(f"experiment record missing {missing}")
        self.rec = {**kw, "status": "RUNNING", "started_utc": utcnow(), "code_version": _git(),
                    "environment": {"python": platform.python_version()}, "metrics": None, "uncertainty": None, "result": None, "outputs": {}}
        self.t0 = time.time(); REG.mkdir(parents=True, exist_ok=True); self._write()

    @property
    def path(self) -> Path: return REG / f"{self.rec['experiment_id']}.json"

    def _write(self):
        tmp = self.path.with_suffix(".tmp"); tmp.write_text(json.dumps(self.rec, indent=1, default=str)); tmp.replace(self.path)

    def finish(self, metrics: dict, result: str, outputs: dict | None = None, uncertainty=None, n_samples: dict | None = None):
        self.rec.update(status="DONE", metrics=metrics, result=result, outputs=outputs or {}, uncertainty=uncertainty,
                        n_samples=n_samples, runtime_s=round(time.time() - self.t0, 1), finished_utc=utcnow())
        self._write(); return self.rec

    def fail(self, error: str, attempted: str, remaining: str):
        self.rec.update(status="FAILED", error=error, attempted=attempted, remaining=remaining,
                        runtime_s=round(time.time() - self.t0, 1), finished_utc=utcnow())
        self._write(); return self.rec

def pending(experiment_id: str, research_question: str, reason: str, needs: str):
    """Record an experiment that is designed but cannot run yet (status PENDING) - never a result."""
    REG.mkdir(parents=True, exist_ok=True)
    rec = {"experiment_id": experiment_id, "research_question": research_question, "status": "PENDING", "reason": reason,
           "needs": needs, "recorded_utc": utcnow(), "code_version": _git()}
    (REG / f"{experiment_id}.json").write_text(json.dumps(rec, indent=1)); return rec

def table() -> list[dict]:
    return [json.loads(p.read_text()) for p in sorted(REG.glob("*.json"))]
