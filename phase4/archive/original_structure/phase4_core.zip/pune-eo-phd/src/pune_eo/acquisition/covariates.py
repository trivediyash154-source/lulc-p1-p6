"""Driver covariates (never labels): GHS-POP R2023A population (100 m, persons per cell) -> density (persons/km2) on a 90 m grid
nested in a window's G30 grid. Citation: Schiavina, Freire, Carioli, MacManus (2023) GHS-POP R2023A, European Commission JRC."""
from __future__ import annotations
import zipfile
from pathlib import Path
import numpy as np
from rasterio.enums import Resampling
from .. import config
from ..grid import Grid
from ..io import write_cog, write_json
from ..provenance import utcnow
from ..labels.sources import _download, _warp, RAW

URL = ("https://jeodpp.jrc.ec.europa.eu/ftp/jrc-opendata/GHSL/GHS_POP_GLOBE_R2023A/GHS_POP_E{ep}_GLOBE_R2023A_54009_100/V1-0/tiles/"
       "GHS_POP_E{ep}_GLOBE_R2023A_54009_100_V1_0_{tile}.zip")

def ghs_pop(grid: Grid, epochs=(2000, 2010, 2020), tile="R7_C26") -> dict:
    g90 = Grid(grid.id + "_90m", grid.crs, 90.0, grid.x0, grid.y1, grid.width // 3, grid.height // 3, grid.corner_offset); stack = []
    for ep in epochs:
        z = _download(URL.format(ep=ep, tile=tile), RAW / "ghs_pop" / f"GHS_POP_E{ep}_{tile}.zip")
        with zipfile.ZipFile(z) as zf:
            tif = [n for n in zf.namelist() if n.endswith(".tif")][0]; p = RAW / "ghs_pop" / Path(tif).name
            if not p.exists(): p.write_bytes(zf.read(tif))
        a = _warp(str(p), g90, Resampling.bilinear, dst_nodata=-1, dtype="float32", sign=False)
        stack.append(np.where(a >= 0, a / 0.01, np.nan))          # persons per 100 m cell (0.01 km2) -> persons/km2
    arr = np.stack(stack).astype(np.float32); out = config.path("data", "features", "covariates", grid.id); out.mkdir(parents=True, exist_ok=True)
    write_cog(out / "ghs_pop_density_90m.tif", np.nan_to_num(arr, nan=-1), g90, nodata=-1, dtype="float32", descriptions=[f"pop_density_{e}" for e in epochs])
    write_json(out / "ghs_pop_density_90m.json", {"source": "GHS-POP R2023A (JRC)", "epochs": list(epochs), "units": "persons/km2", "grid": g90.to_dict(), "created_utc": utcnow()})
    return {"mean_density": [float(np.nanmean(x)) for x in arr]}
