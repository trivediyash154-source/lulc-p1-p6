"""Land-cover trajectory taxonomy from annual label sequences (only years inside the AOA count as evidence).

Per pixel: n_transitions (frequency), first/last change year (timing), longest stable run / n valid years (persistence),
trajectory type: stable | single (one change, persistent) | multi_directional (changes, never returns) | cyclic (returns to an earlier class).
Period transition matrices in km2; conversion hotspots: Getis-Ord Gi* (queen contiguity incl. self) on k x k aggregated cells."""
from __future__ import annotations
import numpy as np

TYPES = {0: "insufficient_evidence", 1: "stable", 2: "single", 3: "multi_directional", 4: "cyclic"}

def taxonomy(labels: np.ndarray, valid: np.ndarray, years: np.ndarray, min_valid: int = 10):
    """labels (T, N) int (1..K), valid (T, N) bool -> dict of (N,) arrays."""
    T, N = labels.shape; L = np.where(valid, labels, 0)
    ntr = np.zeros(N, np.int16); first = np.zeros(N, np.int16); last = np.zeros(N, np.int16); cyc = np.zeros(N, bool)
    prev = np.zeros(N, np.int16); run = np.zeros(N, np.int16); best = np.zeros(N, np.int16)
    seen = np.zeros((N, int(labels.max()) + 1), bool)
    for t in range(T):
        cur = L[t]; v = cur > 0; ch = v & (prev > 0) & (cur != prev)
        cyc |= ch & seen[np.arange(N), cur]
        ntr += ch; first = np.where(ch & (first == 0), years[t], first); last = np.where(ch, years[t], last)
        run = np.where(v, np.where(ch | (prev == 0), 1, run + 1), run); best = np.maximum(best, run)
        seen[np.arange(N)[v], prev[v]] |= prev[v] > 0
        prev = np.where(v, cur, prev)
    nval = valid.sum(0)
    typ = np.where(nval < min_valid, 0, np.where(ntr == 0, 1, np.where(cyc, 4, np.where(ntr == 1, 2, 3)))).astype(np.int8)
    return {"type": typ, "n_transitions": ntr, "first_change": first, "last_change": last, "persistence": np.where(nval > 0, best / np.maximum(nval, 1), 0).astype(np.float32),
            "n_valid": nval, "final_class": prev}

def transition_matrix(a: np.ndarray, b: np.ndarray, valid: np.ndarray, K: int = 4, cell_km2: float = 0.0009):
    m = np.zeros((K, K))
    for i in range(K):
        for j in range(K): m[i, j] = ((a == i + 1) & (b == j + 1) & valid).sum() * cell_km2
    return m

def getis_ord(x: np.ndarray) -> np.ndarray:
    """Gi* z-scores on a 2-D grid (NaN = no data), binary queen weights including the focal cell."""
    from scipy.ndimage import convolve
    f = np.isfinite(x); xv = np.where(f, x, 0.0); n = f.sum(); xbar = xv.sum() / n; s = np.sqrt((xv[f] ** 2).sum() / n - xbar ** 2)
    k = np.ones((3, 3)); sw = convolve(f.astype(float), k, mode="constant"); swx = convolve(xv, k, mode="constant")
    num = swx - xbar * sw; den = s * np.sqrt((n * sw - sw ** 2) / np.maximum(n - 1, 1))
    return np.where(f & (den > 0), num / np.where(den > 0, den, 1), np.nan)
