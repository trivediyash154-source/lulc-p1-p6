"""Probabilistic timing of an absorbing transition (not-built -> built) from annual class probabilities.
State path is fully described by tau in {already built at the first year, each later year, never}; with an absorbing chain the exact posterior is
  P(tau) ~ prior(tau) * prod_{t < tau} e0(t) * prod_{t >= tau} e1(t)
where e1/e0 = [p_t / pi] / [(1 - p_t) / (1 - pi)] turns a classifier posterior p_t into a scaled likelihood ratio (pi = training prior).
Unobserved years contribute 1 (uninformative). Annual errors are treated as independent given the state - an approximation
(temporal autocorrelation of errors makes the posterior over-confident), which Phase 3 checks empirically (P3-K2)."""
from __future__ import annotations
import numpy as np

def transition_posterior(P: np.ndarray, observed: np.ndarray, pi: float, prior=(1 / 3, 1 / 3, 1 / 3)) -> np.ndarray:
    """P (N, T) = P(built) per year; observed (N, T) bool. Returns (N, T + 1): column 0 = built at first year, k = transition in year k (1..T-1),
    column T = never. prior = (built at start, transition at some year - spread uniformly, never)."""
    N, T = P.shape
    lr = np.where(observed, np.log(np.clip(P, 1e-6, 1 - 1e-6) / pi) - np.log(np.clip(1 - P, 1e-6, 1) / (1 - pi)), 0.0)
    cum = np.concatenate([np.cumsum(lr[:, ::-1], 1)[:, ::-1], np.zeros((N, 1))], 1)
    logp = cum + np.log(np.r_[prior[0], np.full(T - 1, prior[1] / (T - 1)), prior[2]])
    post = np.exp(logp - logp.max(1, keepdims=True)); return post / post.sum(1, keepdims=True)

def hpd_set(row: np.ndarray, mass: float = 0.8) -> set:
    o = np.argsort(-row); c = np.cumsum(row[o]); return set(o[:int(np.searchsorted(c, mass)) + 1].tolist())
