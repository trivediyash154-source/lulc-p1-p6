"""Change-point detection on annual (dry / post-monsoon) index series 1990-2026, four method families:
  pelt_mean     - PELT optimal partitioning, piecewise-constant mean (ruptures 'l2'), BIC-type penalty  [level shifts]
  trend_breaks  - Bai-Perron-type breaks in a piecewise-LINEAR trend by dynamic programming + BIC    [BFAST-type for annual data]
  landtrendr    - LandTrendr-like continuous piecewise-linear fit (connected vertices), vertex count by BIC   [LandTrendr-like]
  cusum         - two-sided Page CUSUM on residuals from a 5-year baseline, h = 8 sigma, k = 1 sigma (shifts >= 2 sigma) [sequential]
  bocpd         - Bayesian online change-point detection (Adams & MacKay 2007), Normal-Gamma, hazard 1/15    [Bayesian]
Missing years are DROPPED (not interpolated); each method returns change years and signed magnitudes (mean after - before,
over up to 3 observations each side). sigma = MAD of first differences / sqrt(2) (robust noise scale)."""
from __future__ import annotations
import numpy as np

def noise_sigma(y):
    d = np.diff(y); s = 1.4826 * np.median(np.abs(d - np.median(d))) / np.sqrt(2)
    return max(float(s), 1e-3)

def _mag(y, i):
    a, b = y[max(0, i - 3):i], y[i:i + 3]
    return float(np.mean(b) - np.mean(a)) if a.size and b.size else 0.0

def pelt_mean(t, y, beta=2.0, min_size=3):
    import ruptures as rpt
    s = noise_sigma(y); pen = beta * s * s * np.log(len(y))
    bk = rpt.Pelt(model="l2", min_size=min_size, jump=1).fit(y.reshape(-1, 1)).predict(pen=pen)[:-1]
    return [(int(t[i]), _mag(y, i)) for i in bk]

def _lin_sse(t, y):
    if len(y) < 3: return 0.0
    A = np.vstack([t, np.ones_like(t)]).T; c, res, *_ = np.linalg.lstsq(A, y, rcond=None)
    return float(res[0]) if res.size else float(((A @ c - y) ** 2).sum())

def trend_breaks(t, y, max_breaks=3, min_size=4):
    """Optimal segmentation of a piecewise-linear (discontinuous) trend; number of breaks by BIC."""
    n = len(y); t = t.astype(float)
    cost = np.full((n + 1, n + 1), np.inf)
    for i in range(n):
        for j in range(i + min_size, n + 1): cost[i, j] = _lin_sse(t[i:j], y[i:j])
    best = {0: (cost[0, n], [])}
    F = {(0, j): (cost[0, j], []) for j in range(min_size, n + 1)}
    for m in range(1, max_breaks + 1):
        G = {}
        for j in range((m + 1) * min_size, n + 1):
            opts = [(F[(m - 1, i)][0] + cost[i, j], F[(m - 1, i)][1] + [i]) for i in range(m * min_size, j - min_size + 1) if (m - 1, i) in F]
            if opts: G[(m, j)] = min(opts, key=lambda o: o[0])
        F.update(G)
        if (m, n) in F: best[m] = F[(m, n)]
    def bic(m, sse): return n * np.log(max(sse, 1e-12) / n) + (3 * m + 2) * np.log(n)
    m = min(best, key=lambda k: bic(k, best[k][0]))
    return [(int(t[i]), _mag(y, i)) for i in best[m][1]]

def landtrendr(t, y, max_vertices=5, despike=0.9):
    """Continuous piecewise-linear fit: greedy vertex insertion at max residual, model choice by BIC (LandTrendr-like)."""
    t = t.astype(float); y = y.copy()
    for i in range(1, len(y) - 1):                       # LandTrendr spike dampening
        nb = (y[i - 1] + y[i + 1]) / 2
        if abs(y[i] - nb) > despike * (abs(y[i - 1] - y[i + 1]) + 3 * noise_sigma(y)): y[i] = nb
    def fit(vs):
        X = np.column_stack([np.interp(t, t[vs], np.eye(len(vs))[k]) for k in range(len(vs))])
        c, *_ = np.linalg.lstsq(X, y, rcond=None); return X @ c
    vs = [0, len(y) - 1]; models = {2: (vs[:], fit(vs))}
    while len(vs) < max_vertices:
        r = np.abs(y - models[len(vs)][1]); r[vs] = -1
        for v in vs: r[max(0, v - 1):v + 2] = -1          # segments may be 1 year long (abrupt disturbance), as in LandTrendr
        if r.max() < 0: break
        vs = sorted(vs + [int(r.argmax())]); models[len(vs)] = (vs[:], fit(vs))
    n = len(y); bic = {k: n * np.log(max(((y - f) ** 2).sum(), 1e-12) / n) + 2 * k * np.log(n) for k, (_, f) in models.items()}
    k = min(bic, key=bic.get); vs, f = models[k]; s2 = 2 * noise_sigma(y); out = []
    for a, b in zip(vs[:-1], vs[1:]):                     # year of detection = first year of a changing segment
        if a > 0 and abs(f[b] - f[a]) > s2: out.append((int(t[a + 1]), float(f[b] - f[a])))
    return out

def cusum(t, y, h=8.0, k=1.0, base=5):
    s = noise_sigma(y); mu = np.median(y[:base]); z = (y - mu) / s; gp = gn = 0.0
    for i in range(base, len(y)):
        gp = max(0.0, gp + z[i] - k); gn = max(0.0, gn - z[i] - k)
        if gp > h or gn > h:
            j = i
            while j > base and z[j - 1] * np.sign(z[i]) > 3: j -= 1      # back-date over consecutive >3-sigma deviations
            return [(int(t[j]), _mag(y, j))]
    return []

def bocpd(t, y, hazard=1 / 15, p_thresh=0.5, min_gap=3):
    """Adams & MacKay (2007) with Normal-Gamma prior (mu0 = first obs, kappa0 = 1, alpha0 = 1, beta0 = sigma^2)."""
    from scipy.stats import t as student
    s2 = noise_sigma(y) ** 2; n = len(y)
    R = np.zeros((n + 1, n + 1)); R[0, 0] = 1
    mu, ka, al, be = np.array([y[0]]), np.array([1.0]), np.array([1.0]), np.array([s2])
    cps, last = [], -min_gap
    for i in range(n):
        pred = student.pdf(y[i], 2 * al, loc=mu, scale=np.sqrt(be * (ka + 1) / (al * ka)))
        g = R[i, :i + 1] * pred * (1 - hazard); cp = (R[i, :i + 1] * pred * hazard).sum()
        R[i + 1, 1:i + 2] = g; R[i + 1, 0] = cp; R[i + 1] /= R[i + 1].sum()
        mu_n = (ka * mu + y[i]) / (ka + 1); be_n = be + ka * (y[i] - mu) ** 2 / (2 * (ka + 1))
        mu = np.r_[y[i], mu_n]; ka = np.r_[1.0, ka + 1]; al = np.r_[1.0, al + 0.5]; be = np.r_[s2, be_n]
        # change at i-r if most mass sits on short run lengths (r <= 2) after a long run
        if i >= 3 and R[i + 1, 1:4].sum() > p_thresh and i - last >= min_gap and R[i - 2, 4:].sum() > 0.5:
            j = i - int(np.argmax(R[i + 1, 1:4])); cps.append(j); last = i
    return [(int(t[j]), _mag(y, j)) for j in cps]

METHODS = {"pelt_mean": pelt_mean, "trend_breaks": trend_breaks, "landtrendr": landtrendr, "cusum": cusum, "bocpd": bocpd}

def detect(years: np.ndarray, series: np.ndarray, method: str, **kw):
    f = np.isfinite(series)
    if f.sum() < 10: return None
    return METHODS[method](years[f], series[f].astype(float), **kw)
