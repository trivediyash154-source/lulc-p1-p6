"""Surface-water extent, persistence, reservoir area trajectories and river width (30 m Landsat, 1990-2026).

Water per year & season: MNDWI > 0 (Xu 2006) on the dry (Jan-May) and post-monsoon (Oct-Dec) medians in the feature cube.
Reservoirs: connected components of JRC max water extent (occurrence > 0) larger than min_km2 - geometry from an independent
product, AREA from this project's imagery. Area is surface extent only: NO depth, volume or storage is inferred.
River width: water cells counted along transects perpendicular to the main stem (flow accumulation > acc_km2), x 30 m;
resolution limits width precision to about +-30 m (S2 10 m width series PENDING)."""
from __future__ import annotations
import numpy as np, rasterio
from scipy import ndimage as ndi
from .. import config

def water_masks(ds, season: str) -> np.ndarray:
    f = "dry_mndwi" if season == "dry" else "post_mndwi"
    m = ds.landsat.sel(feature=f).values
    return np.where(np.isfinite(m), m > 0, False), np.isfinite(m)

def reservoirs(gid: str, min_km2: float = 1.0):
    with rasterio.open(config.path("data/labels", gid, "jrc_gsw.tif")) as s: occ = s.read(1).astype(float)
    ext = (occ > 0) & (occ != 255); lab, n = ndi.label(ext, structure=np.ones((3, 3)))
    sizes = ndi.sum(ext, lab, index=np.arange(1, n + 1)) * 0.0009
    keep = [i + 1 for i, a in enumerate(sizes) if a >= min_km2]
    return lab, keep, {k: float(sizes[k - 1]) for k in keep}

def sens_slope(t, y):
    from scipy.stats import theilslopes, kendalltau
    f = np.isfinite(y)
    if f.sum() < 8: return {"sen_slope_per_year": None, "kendall_tau": None, "p_value": None, "n": int(f.sum())}
    s, i, lo, hi = theilslopes(y[f], t[f]); tau, p = kendalltau(t[f], y[f])
    return {"sen_slope_per_year": float(s), "slope_95ci": [float(lo), float(hi)], "kendall_tau": float(tau), "p_value": float(p), "n": int(f.sum())}

def main_stem(gid: str, acc_km2: float):
    with rasterio.open(config.path("data/features/terrain", gid, "terrain.tif")) as s:
        t = s.read(); d = list(s.descriptions)
    return t[d.index("flow_acc_km2")] >= acc_km2

def river_width(water: np.ndarray, stem: np.ndarray, spacing_px: int = 10, half_len_px: int = 12):
    """Transects every `spacing_px` along stem cells; direction from local stem orientation (PCA of stem cells in 7x7)."""
    r, c = np.nonzero(stem); order = np.lexsort((c, r)); r, c = r[order], c[order]; out = []
    used = np.zeros_like(stem, bool)
    for rr, cc in zip(r, c):
        if used[max(rr - spacing_px // 2, 0):rr + spacing_px // 2 + 1, max(cc - spacing_px // 2, 0):cc + spacing_px // 2 + 1].any(): continue
        used[rr, cc] = True
        win = stem[max(rr - 3, 0):rr + 4, max(cc - 3, 0):cc + 4]; yy, xx = np.nonzero(win)
        if yy.size < 3: continue
        cov = np.cov(np.vstack([yy, xx])); w, v = np.linalg.eigh(cov); tang = v[:, -1]; nrm = np.array([-tang[1], tang[0]])
        ks = np.arange(-half_len_px, half_len_px + 1); py = np.round(rr + ks * nrm[0]).astype(int); px = np.round(cc + ks * nrm[1]).astype(int)
        ok = (py >= 0) & (py < water.shape[0]) & (px >= 0) & (px < water.shape[1])
        if ok.sum() < len(ks): continue
        prof = water[py, px]; ctr = half_len_px
        if not prof[ctr]:
            near = np.flatnonzero(prof)
            if near.size == 0: out.append({"row": int(rr), "col": int(cc), "width_m": 0.0}); continue
            ctr = int(near[np.argmin(np.abs(near - half_len_px))])
            if abs(ctr - half_len_px) > 2: out.append({"row": int(rr), "col": int(cc), "width_m": 0.0}); continue
        a = ctr; b = ctr
        while a - 1 >= 0 and prof[a - 1]: a -= 1
        while b + 1 < len(prof) and prof[b + 1]: b += 1
        out.append({"row": int(rr), "col": int(cc), "width_m": float((b - a + 1) * 30.0 * np.hypot(*nrm) / max(abs(nrm[0]), abs(nrm[1])))})
    return out
