"""Urban expansion analytics on a built-up time series (boolean maps per year).

  lei()            Landscape Expansion Index (Liu et al. 2010): for each NEW built patch between t1 and t2,
                   LEI = 100 * A_old / A_buffer over a 1-cell ring buffer; >50 infill, (0, 50] edge-expansion, 0 outlying (leapfrog)
  fragmentation()  class-level metrics for built-up: n patches, patch density, largest patch index, mean patch area,
                   edge density, aggregation index (He et al. 2000, like-adjacency based)
All areas in hectares (30 m cell = 0.09 ha). Descriptive only - no causal interpretation."""
from __future__ import annotations
import numpy as np
from scipy import ndimage as ndi

CELL_HA = 0.09
EIGHT = np.ones((3, 3), bool)

def lei(built_t1: np.ndarray, built_t2: np.ndarray, min_cells: int = 2) -> dict:
    new = built_t2 & ~built_t1
    lab, n = ndi.label(new, structure=EIGHT)
    if n == 0: return {"n_new_patches": 0, "patches": []}
    ring_all = ndi.binary_dilation(new, structure=EIGHT) & ~new
    out = []
    sizes = ndi.sum(np.ones_like(lab), lab, index=np.arange(1, n + 1))
    objs = ndi.find_objects(lab)
    for i, sl in enumerate(objs, start=1):
        if sizes[i - 1] < min_cells: continue
        sl2 = tuple(slice(max(s.start - 1, 0), s.stop + 1) for s in sl)
        p = lab[sl2] == i; ring = ndi.binary_dilation(p, structure=EIGHT) & ~p
        old = built_t1[sl2][ring].sum(); tot = ring.sum()
        v = 100.0 * old / tot if tot else 0.0
        cy, cx = ndi.center_of_mass(p)
        out.append({"cells": int(sizes[i - 1]), "area_ha": float(sizes[i - 1] * CELL_HA), "lei": float(v),
                    "type": "infill" if v > 50 else ("edge" if v > 0 else "outlying"), "row": float(cy + sl2[0].start), "col": float(cx + sl2[1].start)})
    a = np.array([o["area_ha"] for o in out]); t = np.array([o["type"] for o in out])
    summ = {k: {"n": int((t == k).sum()), "area_ha": float(a[t == k].sum()), "area_share": float(a[t == k].sum() / a.sum()) if a.sum() else 0.0}
            for k in ("infill", "edge", "outlying")}
    return {"n_new_patches": len(out), "new_area_ha": float(a.sum()), "by_type": summ,
            "area_weighted_mean_lei": float((a * np.array([o["lei"] for o in out])).sum() / a.sum()) if a.sum() else None, "patches": out}

def fragmentation(built: np.ndarray, valid: np.ndarray | None = None) -> dict:
    valid = np.ones_like(built, bool) if valid is None else valid
    b = built & valid; lab, n = ndi.label(b, structure=EIGHT); A_land = valid.sum() * CELL_HA
    if n == 0: return {"n_patches": 0}
    sizes = ndi.sum(np.ones_like(lab), lab, index=np.arange(1, n + 1)) * CELL_HA
    # edges: 4-neighbour boundaries between built and non-built valid cells (each 30 m)
    e = ((b[:, 1:] != b[:, :-1]) & valid[:, 1:] & valid[:, :-1]).sum() + ((b[1:] != b[:-1]) & valid[1:] & valid[:-1]).sum()
    like = (b[:, 1:] & b[:, :-1]).sum() + (b[1:] & b[:-1]).sum()
    ncell = b.sum(); side = int(np.floor(np.sqrt(ncell))); m = ncell - side * side
    max_like = 2 * side * (side - 1) + (0 if m == 0 else (2 * m - 1 if m <= side else 2 * m - 2))
    return {"n_patches": int(n), "built_area_ha": float(sizes.sum()), "built_share": float(ncell / valid.sum()),
            "patch_density_per_100ha": float(n / A_land * 100), "largest_patch_index_pct": float(sizes.max() / A_land * 100),
            "largest_patch_share_of_built": float(sizes.max() / sizes.sum()), "mean_patch_area_ha": float(sizes.mean()),
            "edge_density_m_per_ha": float(e * 30.0 / A_land), "aggregation_index_pct": float(100 * like / max_like) if max_like > 0 else None}
