"""Phase-2 figures. Every figure: title, units, data source, experiment id(s) -> PNG + JSON sidecar (results/figures/phase2/).
Each function reads only registered outputs; if an input is missing the figure is skipped and listed as PENDING (never faked)."""
from __future__ import annotations
import json
import numpy as np, pandas as pd, rasterio, xarray as xr
import matplotlib; matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib.colors import ListedColormap, BoundaryNorm
from .. import config
from ..provenance import utcnow
from . import style

OUT = config.path("results/figures/phase2")
L1_COLORS = ["#d7301f", "#f2c14e", "#2e7d32", "#1f78b4"]; L1_NAMES = ["built-up", "agriculture", "natural vegetation", "water"]
L1_CMAP = ListedColormap(["#ffffff"] + L1_COLORS); L1_NORM = BoundaryNorm(np.arange(-0.5, 5.5), 5)
W = ["pune_G30_khadakwasla_mutha", "pune_G30_baramati_agri", "pune_G30_mulshi_ghats"]
SHORT = {"pune_G30_khadakwasla_mutha": "Khadakwasla–Mutha corridor", "pune_G30_baramati_agri": "Baramati (agriculture)", "pune_G30_mulshi_ghats": "Mulshi (Ghats)"}

def _save(fig, name, meta):
    OUT.mkdir(parents=True, exist_ok=True); p = OUT / f"{name}.png"; fig.savefig(p, dpi=150, bbox_inches="tight"); plt.close(fig)
    (OUT / f"{name}.json").write_text(json.dumps({**meta, "file": str(p.relative_to(config.ROOT)), "created_utc": utcnow()}, indent=1)); return str(p)

def lulc_epochs(product="lulc_aoa", var="hmm_aoa_label", years=(1990, 2000, 2010, 2021), mask_aoa=True):
    style.apply(); fig, ax = plt.subplots(len(W), len(years), figsize=(3.1 * len(years), 3.0 * len(W)))
    for i, gid in enumerate(W):
        P = xr.open_zarr(config.path("data/products", product, f"{gid}.zarr"))
        for j, y in enumerate(years):
            a = P[var].sel(year=y).values.astype(float)
            if mask_aoa and "inside_aoa" in P: out = ~P.inside_aoa.sel(year=y).values
            else: out = np.zeros_like(a, bool)
            ax[i, j].imshow(np.where(out & (var == "raw_label"), 0, a), cmap=L1_CMAP, norm=L1_NORM, interpolation="nearest")
            if mask_aoa and "inside_aoa" in P and var == "raw_label": pass
            if "inside_aoa" in P: ax[i, j].contour(out, levels=[0.5], colors="k", linewidths=0.3)
            ax[i, j].set_xticks([]); ax[i, j].set_yticks([])
            if i == 0: ax[i, j].set_title(str(y), fontsize=10)
            if j == 0: ax[i, j].set_ylabel(SHORT[gid], fontsize=8)
    fig.legend(handles=[plt.Rectangle((0, 0), 1, 1, color=c) for c in L1_COLORS], labels=L1_NAMES, loc="lower center", ncol=4, fontsize=8, frameon=False)
    fig.suptitle("L1 land cover (30 m), AOA-gated HMM; black contour = outside area of applicability", fontsize=10)
    return _save(fig, f"lulc_epochs_{product}_{var}", {"title": "L1 land cover by epoch", "units": "class", "source": "Landsat C2 L2 (harmonised), EXP-LULC-T-002",
                                                         "note": "agreement metrics vs silver/independent references in docs/phase2_results.md; not ground-truth accuracy"})

def class_area_series(product="lulc_aoa"):
    style.apply(); fig, ax = plt.subplots(1, len(W), figsize=(5 * len(W), 3.4), sharey=False)
    for i, gid in enumerate(W):
        P = xr.open_zarr(config.path("data/products", product, f"{gid}.zarr")); yrs = P.year.values
        for var, ls in (("raw_label", ":"), ("hmm_aoa_label", "-")):
            if var not in P: continue
            a = P[var].values
            for c in range(4): ax[i].plot(yrs, (a == c + 1).mean((1, 2)) * 100, ls, color=L1_COLORS[c], lw=1.2, label=f"{L1_NAMES[c]} ({'raw' if ls == ':' else 'HMM-AOA'})" if i == 0 else None)
        if "inside_aoa" in P: ax[i].fill_between(yrs, 0, (1 - P.inside_aoa.values.mean((1, 2))) * 100, color="0.85", label="outside AOA" if i == 0 else None, zorder=0)
        ax[i].set_title(SHORT[gid], fontsize=9); ax[i].set_ylabel("share of window (%)"); ax[i].set_xlabel("year")
    fig.legend(loc="lower center", ncol=5, fontsize=7, frameon=False, bbox_to_anchor=(0.5, -0.12))
    return _save(fig, f"class_area_series_{product}", {"title": "Class shares 1990-2026, raw vs AOA-gated HMM", "units": "% of window area", "source": "EXP-LULC-T-002"})

def leakage_lowo():
    style.apply(); b = pd.read_csv(config.path("results/classification/baseline_summary.csv")); lo = pd.read_csv(config.path("results/classification/lowo_summary.csv"))
    fig, ax = plt.subplots(1, 2, figsize=(11, 3.6))
    lk = b[b.experiment_id.str.startswith("EXP-L1-LEAK")].copy(); lk["block"] = lk.experiment_id.str.extract(r"LEAK-(\d+)m").astype(int)
    ax[0].plot(lk.block / 1000, lk.test_macro_f1, "o-", color="k"); ax[0].set_xlabel("spatial block size (km; 0 = random pixels)"); ax[0].set_ylabel("test macro-F1 (vs silver)")
    ax[0].set_title("Split design vs apparent performance (RF, Landsat+terrain)", fontsize=9)
    within = b[b.experiment_id.str.match(r"EXP-L1-B-(logreg|rf|xgb)-(landsat|landsat_terrain)$")]
    for k, (m, fs) in enumerate([(m, fs) for fs in ("landsat", "landsat_terrain") for m in ("logreg", "rf", "xgb")]):
        w = within[(within.model == m) & (within.features == fs)].test_macro_f1.values; l = lo[(lo.model == m) & (lo.features == fs)].macro_f1.values
        ax[1].bar(k - 0.2, w[0] if len(w) else np.nan, 0.4, color="0.6", label="within-window 3 km blocks" if k == 0 else None)
        ax[1].bar(k + 0.2, l.mean() if len(l) else np.nan, 0.4, color="#d7301f", yerr=l.std() if len(l) else None, label="leave-one-window-out (mean ± sd)" if k == 0 else None)
    ax[1].set_xticks(range(6)); ax[1].set_xticklabels([f"{m}\n{fs.replace('landsat_terrain', 'L+terrain').replace('landsat', 'Landsat')}" for fs in ("landsat", "landsat_terrain") for m in ("logreg", "rf", "xgb")], fontsize=7)
    ax[1].set_ylabel("macro-F1 (vs silver)"); ax[1].legend(fontsize=7); ax[1].set_title("Spatial transfer to an unseen landscape", fontsize=9)
    return _save(fig, "leakage_and_lowo", {"title": "Leakage sensitivity and leave-one-window-out transfer", "units": "macro-F1 (agreement with silver labels)",
                                           "source": "EXP-L1-LEAK-*, EXP-L1-B-*, EXP-L1-LOWO-*"})

def temporal_shift():
    style.apply(); d = pd.read_csv(config.path("results/temporal/shift_diagnosis.csv"))
    fig, ax = plt.subplots(1, 3, figsize=(13, 3.4))
    for st, c in (("stable_open", "#2e7d32"), ("stable_built", "#d7301f"), ("deep_water", "#1f78b4")):
        for gid, ls in zip(W, ("-", "--", ":")):
            g = d[(d.window == gid) & (d.stratum == st)]
            if len(g) == 0: continue
            ax[0].plot(g.year, g.dry_red, ls, color=c, lw=1); ax[1].plot(g.year, g.dry_ndvi, ls, color=c, lw=1)
            if "raw_built_share" in g: ax[2].plot(g.year, g.raw_built_share * 100, ls, color=c, lw=1, label=f"{st} · {SHORT[gid].split(' ')[0]}")
    for a, t, u in zip(ax, ("dry-season red reflectance", "dry-season NDVI", "share mapped built-up by 2021 model"), ("reflectance", "NDVI", "%")):
        a.set_title(t, fontsize=9); a.set_ylabel(u); a.set_xlabel("year"); [a.axvline(x, color="0.7", lw=0.6) for x in (1999, 2013)]
    ax[2].legend(fontsize=6, ncol=1)
    return _save(fig, "temporal_domain_shift", {"title": "Temporal domain shift on cells that independent products call stable", "units": "see panels",
                                                 "source": "results/temporal/shift_diagnosis.csv; strata from WSF/GHSL/JRC", "note": "grey lines: L7 (1999) and L8 (2013) arrival"})

def reservoirs_and_rain():
    style.apply(); s = pd.read_csv(config.path("results/water/reservoir_area_series.csv")); big = s.groupby(["window", "reservoir"]).area_post_km2.max().reset_index()
    big = big.loc[big.groupby("window").area_post_km2.idxmax()]; fig, ax = plt.subplots(1, len(big), figsize=(6 * len(big), 3.4))
    ax = np.atleast_1d(ax)
    for a, (_, b) in zip(ax, big.iterrows()):
        g = s[(s.window == b.window) & (s.reservoir == b.reservoir)]
        a.plot(g.year, g.area_post_km2, "o-", ms=3, color="#1f78b4", label="post-monsoon (Oct-Dec) area"); a.plot(g.year, g.area_dry_km2, "s-", ms=3, color="#9ecae1", label="dry-season (Jan-May) area")
        a2 = a.twinx(); a2.bar(g.year, g.monsoon_rain_mm, color="0.85", zorder=0, width=0.7); a2.set_ylabel("Jun-Sep rainfall (mm, CHIRPS)"); a.set_zorder(a2.get_zorder() + 1); a.patch.set_visible(False)
        a.set_title(f"{SHORT[b.window]} · largest reservoir ({b.reservoir})", fontsize=9); a.set_ylabel("open-water surface area (km²)"); a.legend(fontsize=7)
    return _save(fig, "reservoir_area_rainfall", {"title": "Reservoir surface-area trajectories and monsoon rainfall", "units": "km² (surface extent only; no depth/volume)", "source": "EXP-WAT-001"})

def stress_lags():
    style.apply(); j = json.loads(config.path("results/stress/stress_vegetation_summary.json").read_text())["associations"]
    rows = [(SHORT[g], k, v["rho"], v["p"]) for g, d in j.items() for k, v in d.items() if v["rho"] is not None]
    df = pd.DataFrame(rows, columns=["window", "pair", "rho", "p"]); piv = df.pivot(index="pair", columns="window", values="rho"); pv = df.pivot(index="pair", columns="window", values="p")
    fig, ax = plt.subplots(figsize=(8, 0.5 * len(piv) + 1.5)); im = ax.imshow(piv.values, cmap="RdBu", vmin=-0.8, vmax=0.8)
    for (i, k), v in np.ndenumerate(piv.values):
        if np.isfinite(v): ax.text(k, i, f"{v:+.2f}{'*' if pv.values[i, k] < 0.05 else ''}", ha="center", va="center", fontsize=8)
    ax.set_xticks(range(piv.shape[1])); ax.set_xticklabels(piv.columns, fontsize=8); ax.set_yticks(range(len(piv))); ax.set_yticklabels(piv.index, fontsize=7)
    plt.colorbar(im, ax=ax, label="Spearman ρ (first differences)"); ax.set_title("Supply → response associations (* p < 0.05; NOT causal)", fontsize=9)
    return _save(fig, "stress_lag_associations", {"title": "Rainfall/storage vs agricultural and ecosystem response", "units": "Spearman rho on first-differenced annual series", "source": "EXP-STRESS-001"})

def flood_frequency():
    style.apply(); ps = sorted(config.path("results/flood").glob("monsoon_open_water_frequency_*.tif"))
    if not ps: return None
    fig, ax = plt.subplots(1, len(ps), figsize=(5 * len(ps), 4)); ax = np.atleast_1d(ax)
    for a, p in zip(ax, ps):
        with rasterio.open(p) as s: f = s.read(1).astype(float)
        f[f < 0] = np.nan; im = a.imshow(np.where(f > 0, f, np.nan), cmap="magma_r", vmin=0, vmax=1); a.set_xticks([]); a.set_yticks([])
        a.set_title(SHORT.get(p.stem.split("frequency_")[1], p.stem), fontsize=9)
    plt.colorbar(im, ax=list(ax), label="share of monsoon S1 acquisitions with open water (2017-2025)")
    return _save(fig, "flood_open_water_frequency", {"title": "Monsoon open-water frequency outside permanent water (hazard proxy)", "units": "fraction of acquisitions",
                                                     "source": "EXP-FLD-001", "note": "double bounce hides urban water; not a risk map"})

def all_available():
    done, pending = [], []
    for f in (lulc_epochs, class_area_series, leakage_lowo, temporal_shift, reservoirs_and_rain, stress_lags, flood_frequency):
        try:
            r = f(); (done if r else pending).append(f.__name__)
        except Exception as e:
            pending.append(f"{f.__name__}: {e!r}"[:160])
    return done, pending

def urban_series():
    style.apply(); u = json.loads(config.path("results/urban/urban_expansion.json").read_text()); fig, ax = plt.subplots(1, 2 * len(u), figsize=(5.5 * 2 * len(u), 3.4))
    for i, (g, r) in enumerate(u.items()):
        a = ax[2 * i]
        for src, c in (("ours", "#d7301f"), ("wsf", "k")):
            fr = r[src]["fragmentation"]; ys = sorted(int(y) for y in fr); a.plot(ys, [fr[str(y)].get("built_area_ha", 0) for y in ys], "o-", color=c, label={"ours": "this project (AOA-gated HMM)", "wsf": "WSF-Evolution (independent)"}[src])
        a.set_title(f"{SHORT[g]}: built-up area", fontsize=9); a.set_ylabel("ha"); a.legend(fontsize=7)
        b_ = ax[2 * i + 1]; le = r["wsf"]["lei"]; ks = [k for k in le if le[k].get("by_type")]; bottom = np.zeros(len(ks))
        for t, c in (("infill", "#fdae61"), ("edge", "#d7191c"), ("outlying", "#2b83ba")):
            v = np.array([le[k]["by_type"][t]["area_share"] for k in ks]); b_.bar(range(len(ks)), v, bottom=bottom, color=c, label=t); bottom += v
        b_.set_xticks(range(len(ks))); b_.set_xticklabels(ks, fontsize=7, rotation=30); b_.set_title(f"{SHORT[g]}: expansion mode (LEI, WSF)", fontsize=9); b_.set_ylabel("share of new built area"); b_.legend(fontsize=7)
    return _save(fig, "urban_expansion", {"title": "Built-up area and expansion mode", "units": "ha; area share", "source": "EXP-URB-001",
                                          "note": "this project's series is NOT defensible for expansion (drought/early-era confusion) - shown for transparency"})

def drivers_shap():
    style.apply(); d = json.loads(config.path("results/urban/conversion_drivers.json").read_text()); ks = [k for k in d if "shap_mean_abs" in d[k]]
    names = list(d[ks[0]]["shap_mean_abs"]); fig, ax = plt.subplots(figsize=(8, 4)); w = 0.8 / len(ks)
    for i, k in enumerate(ks): ax.barh(np.arange(len(names)) + i * w, [d[k]["shap_mean_abs"].get(n, 0) for n in names], w, label=f"{k.replace('pune_G30_', '')} (AUC xgb {d[k]['spatial_cv_auc']['xgb'][0]})")
    ax.set_yticks(np.arange(len(names)) + 0.4 - w / 2); ax.set_yticklabels(names, fontsize=8); ax.set_xlabel("mean |SHAP| (log-odds)"); ax.legend(fontsize=7)
    ax.set_title("Location factors associated with conversion to built-up 2000→2015 (associations, not causes)", fontsize=9)
    return _save(fig, "drivers_shap", {"title": "Conversion drivers (SHAP)", "units": "mean |SHAP| in log-odds", "source": "EXP-DRV-001"})

def hindcast_fom():
    style.apply(); h = json.loads(config.path("results/temporal/hindcast.json").read_text()); ks = [k for k in h if "xgb_potential" in h[k]]
    ms = ["random", "distance_only", "xgb_potential"]; fig, ax = plt.subplots(figsize=(8, 3.4)); w = 0.25
    for j, m in enumerate(ms): ax.bar(np.arange(len(ks)) + j * w, [h[k][m]["30m"]["fom"] for k in ks], w, label=m)
    ax.set_xticks(np.arange(len(ks)) + w); ax.set_xticklabels([k.replace("pune_G30_", "").replace("|", "\n") for k in ks], fontsize=8); ax.set_ylabel("figure of merit (30 m)")
    ax.set_title("Hindcast 2010→2020 (trained 2000→2010); persistence FoM = 0", fontsize=9); ax.legend(fontsize=7)
    return _save(fig, "hindcast_fom", {"title": "Land-change hindcast skill", "units": "figure of merit", "source": "EXP-HC-001"})

def changepoint_methods():
    style.apply(); c = pd.read_csv(config.path("results/change_detection/cp_method_comparison.csv")); fig, ax = plt.subplots(1, 2, figsize=(11, 3.4))
    for a, ix in zip(ax, ("post_ndvi", "dry_ndvi")):
        u = c[(c.stratum == "urbanised") & (c["index"] == ix)].set_index("method"); s = c[(c.stratum == "stable_open") & (c["index"] == ix)].set_index("method")
        x = np.arange(len(u)); a.bar(x - 0.2, u.recall_pm2, 0.4, color="#1a9641", label="recall ±2 y (urbanised, WSF timing)")
        a.bar(x + 0.2, s["neg_break_le_-0.1_rate"].reindex(u.index), 0.4, color="#d7191c", label="negative-break rate on stable open land")
        a.set_xticks(x); a.set_xticklabels(u.index, fontsize=8); a.set_title(ix, fontsize=9); a.set_ylim(0, 1); a.legend(fontsize=7)
    return _save(fig, "changepoint_methods", {"title": "Change-point methods vs independent urbanisation timing", "units": "share of sample cells", "source": "EXP-CP-001"})

def drought_confusion():
    style.apply(); d = json.loads(config.path("results/temporal/drought_confusion.json").read_text()); s = pd.read_csv(config.path("results/stress/annual_supply_response_series.csv"))
    fig, ax = plt.subplots(1, len(d), figsize=(5 * len(d), 3.4))
    for a, (g, r) in zip(ax, d.items()):
        rp = s[s.window == g].set_index("year").monsoon_mm.shift(1)
        for k, c, lab in (("lulc:raw_label", "#d7301f", "2021 model (T-001)"), ("lulc_aoa:hmm_aoa_label", "k", "selected R1R2 + AOA-HMM (T-002)")):
            fb = pd.Series(r[k]["false_built_rate"]); fb.index = fb.index.astype(int); x = rp.reindex(fb.index)
            a.scatter(x, fb * 100, s=12, color=c, label=f"{lab}: ρ={r[k]['rho_levels'][0]:+.2f}")
        a.set_xlabel("previous monsoon rainfall (mm, CHIRPS)"); a.set_ylabel("mapped built-up on never-settled land (%)"); a.set_title(SHORT[g], fontsize=9); a.legend(fontsize=6)
    return _save(fig, "drought_confusion", {"title": "Drought-year fallow mapped as built-up", "units": "% of never-settled cells (WSF=0, GHSL<0.02, no JRC water)", "source": "EXP-LULC-DIAG-001"})

def trajectory_map(gid="pune_G30_khadakwasla_mutha"):
    style.apply(); z = np.load(config.path("results/change_detection", f"trajectories_{gid}.npz")); fig, ax = plt.subplots(1, 3, figsize=(15, 4.4))
    cm = ListedColormap(["#bdbdbd", "#f7f7f7", "#d7191c", "#fdae61", "#2b83ba"]); ax[0].imshow(z["type"], cmap=cm, vmin=-0.5, vmax=4.5, interpolation="nearest")
    ax[0].legend(handles=[plt.Rectangle((0, 0), 1, 1, color=c) for c in cm.colors], labels=["insufficient evidence", "stable", "single", "multi-directional", "cyclic"], fontsize=6, loc="lower left")
    fc = np.where(z["first_change"] > 0, z["first_change"], np.nan).astype(float); im = ax[1].imshow(fc, cmap="viridis", vmin=1990, vmax=2026, interpolation="nearest"); plt.colorbar(im, ax=ax[1], label="first change year")
    im2 = ax[2].imshow(z["gi_star"], cmap="RdBu_r", vmin=-4, vmax=4); plt.colorbar(im2, ax=ax[2], label="Gi* z (conversion to built-up 2000-2020, 0.9 km cells)")
    for a in ax: a.set_xticks([]); a.set_yticks([])
    ax[0].set_title("trajectory type (in-AOA years)", fontsize=9); ax[1].set_title("timing", fontsize=9); ax[2].set_title("hotspots", fontsize=9)
    return _save(fig, f"trajectories_{gid}", {"title": f"Trajectory taxonomy - {SHORT[gid]}", "units": "class / year / z-score", "source": "EXP-TRJ-001",
                                               "note": "inherits the temporal-transfer limits of EXP-LULC-T-002"})

def s2_oli_transform():
    style.apply(); import pickle, yaml
    S = pickle.load(open(config.path("results/audit/same_day_pixel_samples.pkl"), "rb")); T = yaml.safe_load(open(config.path("results/harmonization/s2_to_oli_v1.yaml")))
    B_ = ["blue", "green", "red", "nir08", "swir16", "swir22"]; fig, ax = plt.subplots(1, 6, figsize=(18, 3.2))
    Lp = np.concatenate([p["L"] for p in S], 1); Sp = np.concatenate([p["S"] for p in S], 1)
    for i, b in enumerate(B_):
        x, y = Sp[i], Lp[i]; f = np.isfinite(x) & np.isfinite(y); ax[i].hexbin(x[f], y[f], gridsize=60, bins="log", extent=(0, 0.4, 0, 0.4), cmap="Greys")
        t = np.linspace(0, 0.4, 2); ax[i].plot(t, t, "k:", lw=0.8); ax[i].plot(t, T["slope"][b] * t + T["intercept"][b], color="#d7301f", lw=1.2)
        ax[i].set_title(f"{b}: L = {T['slope'][b]:.2f}·S2 {T['intercept'][b]:+.3f}", fontsize=8); ax[i].set_xlabel("S2 L2A"); ax[i].set_ylabel("Landsat C2 L2 (OLI-eq.)" if i == 0 else "")
    return _save(fig, "s2_to_oli_transform", {"title": "Same-day Sentinel-2 vs Landsat reflectance (19 pairs) and fitted s2_to_oli_v1", "units": "surface reflectance", "source": "results/harmonization/s2_to_oli_v1.yaml"})

def agri_models():
    style.apply(); a = pd.read_csv(config.path("results/agriculture/agri_model_comparison.csv")); w = a[~a.experiment_id.str.contains("LOWO")]; lo = a[a.experiment_id.str.contains("LOWO")]
    fig, ax = plt.subplots(1, 2, figsize=(11, 3.4)); ms = list(dict.fromkeys(w.model))
    for j, ch in enumerate(("s2", "s2s1")):
        v = [w[(w.model == m) & (w.channels == ch)].test_macro_f1.mean() for m in ms]; ax[0].bar(np.arange(len(ms)) + 0.4 * j, v, 0.4, label=ch)
    ax[0].set_xticks(np.arange(len(ms)) + 0.2); ax[0].set_xticklabels(ms, fontsize=8); ax[0].set_ylim(0.9, 1.0); ax[0].set_ylabel("test macro-F1 (vs silver)"); ax[0].legend(fontsize=7); ax[0].set_title("Within-window (3 km blocks)", fontsize=9)
    if len(lo):
        for j, m in enumerate(dict.fromkeys(lo.model)):
            g = lo[lo.model == m]; ax[1].bar(np.arange(len(g)) + 0.4 * j, g.test_macro_f1, 0.4, label=m)
        ax[1].set_xticks(np.arange(len(g)) + 0.2); ax[1].set_xticklabels([s.split("(")[-1].rstrip(")").replace("pune_G30_", "") for s in g.split], fontsize=8); ax[1].set_title("Leave-one-window-out (S2+S1)", fontsize=9); ax[1].legend(fontsize=7)
    return _save(fig, "agri_models", {"title": "Classical vs temporal deep models on 2021 monthly S2/S1", "units": "macro-F1 vs silver", "source": "EXP-AG-*"})

def variogram():
    style.apply(); v = json.loads(config.path("results/labels/variogram.json").read_text()); fig, ax = plt.subplots(1, 3, figsize=(13, 3.2))
    for a, k in zip(ax, ("ndvi_dry_2020", "worldcover_built_fraction", "worldcover_natveg_fraction")):
        for g, r in v.items(): a.plot(np.array(r[k]["lag_m"]) / 1000, np.array(r[k]["gamma"]) / r[k]["sill"], "o-", ms=3, label=f"{SHORT[g]} (range {r[k]['range95_m']} m)")
        a.axvline(3, color="k", ls=":"); a.set_xlabel("lag (km)"); a.set_ylabel("semivariance / sill"); a.set_title(k, fontsize=9); a.legend(fontsize=6)
    return _save(fig, "variogram_block_size", {"title": "Empirical variograms justifying 3 km CV blocks", "units": "normalised semivariance", "source": "results/labels/variogram.json"})

def confusion_matrix(eid="EXP-L1-B-xgb-landsat_terrain"):
    style.apply(); r = json.loads(config.path("experiments/registry", f"{eid}.json").read_text()); cm = np.array(r["metrics"]["test"]["confusion_matrix"]["counts"], float); labs = r["metrics"]["test"]["confusion_matrix"]["labels"]
    n = cm / cm.sum(1, keepdims=True); fig, ax = plt.subplots(figsize=(4.6, 4)); ax.imshow(n, cmap="Blues", vmin=0, vmax=1)
    for (i, j), v in np.ndenumerate(n): ax.text(j, i, f"{v:.2f}\n({int(cm[i, j])})", ha="center", va="center", fontsize=7, color="w" if v > 0.6 else "k")
    ax.set_xticks(range(len(labs))); ax.set_xticklabels(labs, rotation=30, fontsize=7); ax.set_yticks(range(len(labs))); ax.set_yticklabels(labs, fontsize=7)
    ax.set_xlabel("predicted"); ax.set_ylabel("silver reference"); ax.set_title(f"{eid}\n(row-normalised; agreement with silver, not accuracy)", fontsize=8)
    return _save(fig, f"confusion_{eid}", {"title": "Confusion matrix vs silver test blocks", "units": "row share (count)", "source": eid})

def uncertainty_maps():
    style.apply(); ps = sorted(config.path("results/uncertainty").glob("uncertainty_2021_*.tif"))
    if not ps: return None
    fig, ax = plt.subplots(len(ps), 3, figsize=(12, 3.6 * len(ps)))
    for i, p in enumerate(ps):
        with rasterio.open(p) as s: a = s.read()
        for j, (k, cm, vmax, lab) in enumerate(((0, "magma", 1.0, "ensemble entropy (nats)"), (1, "viridis", 3, "conformal set size (α=0.1)"), (3, "Greys_r", 1, "inside AOA (1) / outside (0)"))):
            im = ax[i, j].imshow(a[k], cmap=cm, vmin=0, vmax=vmax, interpolation="nearest"); ax[i, j].set_xticks([]); ax[i, j].set_yticks([]); plt.colorbar(im, ax=ax[i, j], fraction=0.04)
            if i == 0: ax[i, j].set_title(lab + (" — 0 = empty set (no class reaches the threshold)" if k == 1 else ""), fontsize=8)
        ax[i, 0].set_ylabel(SHORT.get(p.stem.replace("uncertainty_2021_", ""), p.stem), fontsize=8)
    return _save(fig, "uncertainty_maps_2021", {"title": "Uncertainty maps, 2021 L1 model", "units": "see colorbars", "source": "EXP-UNC-001"})

def all_available():   # noqa: F811 - extended list
    done, pending = [], []
    for f in (lulc_epochs, class_area_series, leakage_lowo, temporal_shift, reservoirs_and_rain, stress_lags, flood_frequency, urban_series, drivers_shap, hindcast_fom,
              changepoint_methods, drought_confusion, trajectory_map, s2_oli_transform, agri_models, variogram, confusion_matrix, uncertainty_maps):
        try:
            r = f(); (done if r else pending).append(f.__name__)
        except Exception as e:
            pending.append(f"{f.__name__}: {e!r}"[:160])
    return done, pending
