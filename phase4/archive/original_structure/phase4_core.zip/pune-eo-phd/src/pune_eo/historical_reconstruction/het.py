"""Historical Evaluation Table (HET): one shared sample of cells x years so every Phase-3 experiment uses IDENTICAL cells, splits, folds.

Cells per window (deduplicated union):
  silver   : silver L1 classes 1-4, capped per class per split (train 2500, val 1500, test 3000)            (Tier C labels, 2020-21)
  tierB    : stable_built  WSF settled by 1985 AND GHSL 1990 >= 0.3            (Tier B: built in every year)
             never_settled WSF never settled AND GHSL 2020 < 0.02 AND JRC == 0  (Tier B: NOT built in any year)
             deep_water    JRC occurrence >= 95                                  (Tier B: water)
             urbanised     WSF first year 1995-2012 AND GHSL gain 1990->2020 >= 0.2 (Tier B: built after the WSF year)
Arrays: L (cell, year 1990-2026, 23 Landsat features), Q (cell, year, 3 quality), T (cell, 12 terrain), S (cell, 2017-2025, 7 Sentinel),
climate per window-year (SPI-12 Sep of t-1, monsoon rain of t-1, class), CHIRPS 1991-2020 mean annual rain per cell, metadata."""
from __future__ import annotations
import hashlib, json
import numpy as np, pandas as pd, rasterio, xarray as xr
from .. import config
from ..grid import Grid
from ..labels.splits import block_index

W = ["pune_G30_khadakwasla_mutha", "pune_G30_baramati_agri", "pune_G30_mulshi_ghats"]
YEARS = np.arange(1990, 2027); SYEARS = np.arange(2017, 2026)
CAP = {1: 2500, 2: 1500, 3: 3000}; TIERB_N = 3000

def _r(p, b=1):
    with rasterio.open(p) as s: return s.read(b)

def _up3(a, H, W_):
    return np.pad(np.repeat(np.repeat(a, 3, 0), 3, 1), ((0, max(0, H - 3 * a.shape[0])), (0, max(0, W_ - 3 * a.shape[1]))), constant_values=np.nan)[:H, :W_]

def climate_table() -> pd.DataFrame:
    s = pd.read_csv(config.path("results/stress/annual_supply_response_series.csv"))
    out = []
    for g, d in s.groupby("window"):
        d = d.set_index("year").sort_index(); spi_prev = d.spi12_sep.shift(1); mon_prev = d.monsoon_mm.shift(1)
        cls = np.select([spi_prev <= -1, spi_prev >= 1], ["dry", "wet"], "normal"); cls5 = np.select([spi_prev <= -0.5, spi_prev >= 0.5], ["dry", "wet"], "normal")
        out.append(pd.DataFrame({"window": g, "year": d.index, "spi12_prev": spi_prev.values, "monsoon_prev_mm": mon_prev.values, "climate_class": cls, "climate_class_05": cls5}))
    c = pd.concat(out); c.loc[c.spi12_prev.isna(), ["climate_class", "climate_class_05"]] = "unknown"; return c

def chirps_mean(gid, xs, ys):
    from rasterio.warp import transform
    with rasterio.open(config.path("data/processed/climate/chirps_v2_monthly_stack.tif")) as s:
        desc = list(s.descriptions); k = [i for i, d in enumerate(desc) if 1991 <= int(d[:4]) <= 2020]
        lon, lat = transform("EPSG:32643", s.crs, list(xs), list(ys)); rc = [s.index(a, b) for a, b in zip(lon, lat)]
        rr = np.array([r for r, _ in rc]); cc = np.array([c for _, c in rc]); r0, r1, c0, c1 = rr.min(), rr.max() + 1, cc.min(), cc.max() + 1
        win = rasterio.windows.Window(c0, r0, c1 - c0, r1 - r0); a = s.read([i + 1 for i in k], window=win).astype(float); a[a < 0] = np.nan
    ann = np.nansum(a, 0) / 30.0
    return ann[rr - r0, cc - c0]

def build(seed: int = 20261023) -> dict:
    rng = np.random.default_rng(seed); metas, Ls, Qs, Ts, Ss = [], [], [], [], []
    for gid in W:
        d = config.path("data/labels", gid); sil = _r(d / "silver_l1.tif"); sp = _r(d / "splits.tif"); wsf = _r(d / "wsf_evolution_first_year.tif").astype(int)
        jrc = _r(d / "jrc_gsw.tif").astype(float); jrc[jrc == 255] = np.nan
        with rasterio.open(d / "ghsl_built_fraction_90m.tif") as s: gh = s.read().astype(float)
        gh[gh < 0] = np.nan; H, Wd = sil.shape; G = np.stack([_up3(x, H, Wd) for x in gh])
        strata = {"stable_built": (wsf == 1985) & (G[0] >= 0.3), "never_settled": (wsf == 0) & (G[6] < 0.02) & (jrc == 0),
                  "deep_water": (jrc >= 95), "urbanised": (wsf >= 1995) & (wsf <= 2012) & (G[6] - G[0] >= 0.2)}
        pick = np.zeros((H, Wd), bool)
        for s_ in (1, 2, 3):
            for c in (1, 2, 3, 4):
                r, cc = np.nonzero((sp == s_) & (sil == c))
                if r.size > CAP[s_]: k = rng.choice(r.size, CAP[s_], replace=False); r, cc = r[k], cc[k]
                pick[r, cc] = True
        for m in strata.values():
            r, cc = np.nonzero(m & (sp > 0))
            if r.size > TIERB_N: k = rng.choice(r.size, TIERB_N, replace=False); r, cc = r[k], cc[k]
            pick[r, cc] = True
        r, cc = np.nonzero(pick); ds = xr.open_zarr(config.path("data/features/cube", f"{gid}.zarr"))
        L = np.stack([ds.landsat.isel(year=i).values[:, r, cc].T for i in range(len(YEARS))], 1).astype(np.float32)
        Q = np.stack([ds.quality.isel(year=i).values[:, r, cc].T for i in range(len(YEARS))], 1).astype(np.float32)
        T = ds.terrain.values[:, r, cc].T.astype(np.float32)
        S = np.stack([ds.sentinel.isel(syear=i).values[:, r, cc].T for i in range(len(SYEARS))], 1).astype(np.float32)
        gj = json.loads(ds.attrs["grid"]); Gr = Grid(gid, gj["crs"], gj["res"], gj["x0"], gj["y1"], gj["width"], gj["height"], gj["corner_offset"])
        bx, by = block_index(Gr, 3000); x = Gr.x0 + (cc + 0.5) * Gr.res; y = Gr.y1 - (r + 0.5) * Gr.res
        meta = pd.DataFrame({"window": gid, "row": r, "col": cc, "x": x, "y": y, "split": sp[r, cc], "silver": sil[r, cc], "wsf": wsf[r, cc], "jrc": jrc[r, cc],
                             **{f"ghsl_{e}": G[i][r, cc] for i, e in enumerate((1990, 1995, 2000, 2005, 2010, 2015, 2020))},
                             **{k: v[r, cc] for k, v in strata.items()}, "block": [f"{gid}:{a}:{b}" for a, b in zip(bx[r, cc], by[r, cc])],
                             "fold": [int(hashlib.sha256(f"{a}:{b}:fold".encode()).hexdigest(), 16) % 5 for a, b in zip(bx[r, cc], by[r, cc])]})
        meta["chirps_mean_mm"] = chirps_mean(gid, x, y)
        metas.append(meta); Ls.append(L); Qs.append(Q); Ts.append(T); Ss.append(S)
    meta = pd.concat(metas, ignore_index=True); out = config.path("data/features/het_v1"); out.mkdir(parents=True, exist_ok=True)
    np.savez_compressed(out / "arrays.npz", L=np.concatenate(Ls), Q=np.concatenate(Qs), T=np.concatenate(Ts), S=np.concatenate(Ss))
    meta.to_parquet(out / "cells.parquet"); climate_table().to_csv(out / "climate.csv", index=False)
    ds = xr.open_zarr(config.path("data/features/cube", f"{W[0]}.zarr"))
    info = {"features": list(ds.feature.values), "qfeatures": list(ds.qfeature.values), "tfeatures": list(ds.tfeature.values), "sfeatures": list(ds.sfeature.values),
            "years": YEARS.tolist(), "syears": SYEARS.tolist(), "n_cells": len(meta), "by_window": meta.window.value_counts().to_dict(),
            "strata": {k: int(meta[k].sum()) for k in ("stable_built", "never_settled", "deep_water", "urbanised")}, "seed": seed}
    (out / "info.json").write_text(json.dumps(info, indent=1)); return info

def load():
    d = config.path("data/features/het_v1"); a = np.load(d / "arrays.npz")
    return {k: a[k] for k in a.files} | {"meta": pd.read_parquet(d / "cells.parquet"), "climate": pd.read_csv(d / "climate.csv"), "info": json.loads((d / "info.json").read_text())}
