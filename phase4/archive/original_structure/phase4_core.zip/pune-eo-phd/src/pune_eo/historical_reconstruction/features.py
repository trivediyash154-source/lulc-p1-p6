"""Feature sets for the Phase-3 temporal (B) and fusion (C) experiments, built from the HET for any target year t.

B1 single-date : dry-season composite of year t (11)
B2 multi-date  : B1 at t-1, t, t+1 (33)
B3 seasonal    : B1 + post-monsoon NDVI/MNDWI/NDMI + seasonal amplitude dNDVI/dMNDWI of year t (16)
B4 sequence    : B3 at t-2..t+2 (80) + 5-year median/min/max of dry NDVI, post NDVI, dry SWIR1 (9)
C1 optical     : B3 ; C2 SAR only (6 S1 annual features) ; C3 = C1+C2 ; C4 = C3 + terrain (12) ; C5 = C4 + SPI-12(t-1) + CHIRPS mean annual rain
Missing neighbours (edge years, missing composites) stay NaN - tree models handle NaN; nothing is interpolated."""
from __future__ import annotations
import numpy as np

B1 = ["dry_blue", "dry_red", "dry_nir", "dry_swir1", "dry_swir2", "dry_ndvi", "dry_mndwi", "dry_ndmi", "dry_nbr", "sd_ndvi_5", "sd_nir_5"]
B3 = B1 + ["post_ndvi", "post_mndwi", "post_ndmi", "d_ndvi", "d_mndwi"]
S1F = ["s1_vv_dry", "s1_vh_dry", "s1_vh_wet", "s1_ratio", "s1_vv_min", "s1_vh_sd"]

def _L(H, names, yi):
    fi = [H["info"]["features"].index(n) for n in names]; T = H["L"].shape[1]
    if 0 <= yi < T: return H["L"][:, yi][:, fi]
    return np.full((H["L"].shape[0], len(fi)), np.nan, np.float32)

def build(H, fs: str, year: int, idx=None) -> tuple[np.ndarray, list[str]]:
    years = H["info"]["years"]; yi = years.index(year); sl = slice(None) if idx is None else idx
    def L(names, k=0): return _L(H, names, yi + k)[sl]
    if fs == "B1": return L(B1), B1
    if fs == "B2": return np.hstack([L(B1, k) for k in (-1, 0, 1)]), [f"{n}@{k:+d}" for k in (-1, 0, 1) for n in B1]
    if fs in ("B3", "C1"): return L(B3), B3
    if fs.startswith("B4") or fs == "B5":
        X = [L(B3, k) for k in (-2, -1, 0, 1, 2)]; names = [f"{n}@{k:+d}" for k in (-2, -1, 0, 1, 2) for n in B3]
        st = np.stack(X, 0); stats, sn = [], []
        for f in ("dry_ndvi", "post_ndvi", "dry_swir1"):
            v = st[:, :, B3.index(f)]
            with np.errstate(all="ignore"): stats += [np.nanmedian(v, 0), np.nanmin(v, 0), np.nanmax(v, 0)]
            sn += [f"{f}_5y_med", f"{f}_5y_min", f"{f}_5y_max"]
        X = np.hstack(X + [np.stack(stats, 1)]); names += sn
        if fs == "B4": return X, names
        if fs == "B4t": return np.hstack([X, H["T"][sl]]), names + H["info"]["tfeatures"]
        if fs == "B5": return np.hstack([X, spi(H, year, idx)[:, None]]), names + ["spi12_prev"]
    if fs in ("C2", "C3", "C4", "C5"):
        sy = H["info"]["syears"]
        S = H["S"][:, sy.index(year)][:, [H["info"]["sfeatures"].index(n) for n in S1F]][sl] if year in sy else np.full((len(H["meta"]) if idx is None else len(np.arange(len(H["meta"]))[idx]), 6), np.nan, np.float32)
        if fs == "C2": return S, S1F
        X, n = np.hstack([L(B3), S]), B3 + S1F
        if fs == "C3": return X, n
        X, n = np.hstack([X, H["T"][sl]]), n + H["info"]["tfeatures"]
        if fs == "C4": return X, n
        return np.hstack([X, spi(H, year, idx)[:, None], H["meta"].chirps_mean_mm.values[sl][:, None]]), n + ["spi12_prev", "chirps_mean_mm"]
    raise KeyError(fs)

def spi(H, year, idx=None):
    c = H["climate"]; m = H["meta"] if idx is None else H["meta"].iloc[np.arange(len(H["meta"]))[idx]]
    look = c[c.year == year].set_index("window").spi12_prev
    return m.window.map(look).values.astype(np.float32)
