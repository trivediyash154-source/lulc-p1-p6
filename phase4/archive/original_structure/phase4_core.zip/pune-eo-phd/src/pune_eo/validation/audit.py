"""Phase-1 audit: re-verify every claim the data foundation makes, from the files themselves.

Each check returns {"check", "status" PASS/WARN/FAIL/INFO, "evidence", "detail"}. Nothing is
taken from documentation; everything is recomputed from boundary files, manifests, metadata
and (where present) rasters.
"""
from __future__ import annotations
import glob, hashlib, json
from collections import Counter, defaultdict
from pathlib import Path
import geopandas as gpd
import numpy as np
import pandas as pd
import rasterio
from .. import config
from ..grid import Grid, district_grid
from ..provenance import sha256

R = config.ROOT
def _res(check, status, evidence, detail=None):
    return {"check": check, "status": status, "evidence": evidence, "detail": detail}

# ------------------------------------------------------------------ boundary
def audit_boundary() -> list[dict]:
    out = []
    meta = json.loads((R / "data/boundary/study_area.metadata.json").read_text())
    eq = config.load("study_area")["equal_area_crs"]
    gj = gpd.read_file(R / "data/boundary/study_area.geojson")
    gp = gpd.read_file(R / "data/boundary/study_area.gpkg", layer="study_area_wgs84")
    sh = gpd.read_file(R / "data/boundary/study_area.shp")
    a = [g.to_crs(eq).area.iloc[0] / 1e6 for g in (gj, gp, sh)]
    same = max(a) - min(a) < 0.01
    sym = gj.geometry.iloc[0].symmetric_difference(gp.geometry.iloc[0]).area
    out.append(_res("boundary formats identical (geojson/gpkg/shp)", "PASS" if same and sym < 1e-9 else "FAIL",
                    f"areas {', '.join(f'{x:.3f}' for x in a)} km²; geojson-gpkg sym.diff {sym:.2e} deg²"))
    valid = bool(gj.geometry.iloc[0].is_valid)
    out.append(_res("boundary geometry valid, single part", "PASS" if valid and gj.geometry.iloc[0].geom_type == "Polygon" else "FAIL",
                    f"valid={valid}, type={gj.geometry.iloc[0].geom_type}, vertices={meta['geometry_repair']['n_vertices']}"))
    out.append(_res("district area vs official", "PASS" if abs(a[0] - meta["official_area_km2"]) / meta["official_area_km2"] < 0.01 else "FAIL",
                    f"{a[0]:,.2f} km² equal-area vs official {meta['official_area_km2']:,} ({100*(a[0]-meta['official_area_km2'])/meta['official_area_km2']:+.3f} %)"))
    gk = meta["cross_checks"]["GADM 4.1 IND level 2"]
    out.append(_res("boundary agreement with GADM 4.1", "WARN" if gk["iou"] < 0.99 else "PASS",
                    f"IoU {gk['iou']:.3f}, sym. diff {gk['symmetric_difference_km2']:.0f} km², Hausdorff {gk['hausdorff_m']:.0f} m",
                    "boundary uncertainty must be carried into edge statistics"))
    out.append(_res("boundary CRS", "PASS" if gj.crs.to_epsg() == 4326 else "FAIL", f"geojson EPSG:{gj.crs.to_epsg()}; analysis CRS {config.load('grid')['crs']}"))
    return out

# ------------------------------------------------------------------ grids
def audit_grids() -> list[dict]:
    out = []
    ev = json.loads((R / "data/boundary/grids.json").read_text())
    f = ev["findings"]
    out.append(_res("G30 lattice == native Landsat lattice", "PASS" if f["G30_matches_landsat_native"] else "FAIL",
                    f"Landsat corner offsets mod 30 m: {f['landsat_lattice_offset_mod30']} across {len(ev['native_lattice_evidence']['landsat'])} path/rows"))
    out.append(_res("G10 lattice == native Sentinel-2 lattice", "PASS" if f["G10_matches_sentinel2_native"] else "FAIL",
                    f"S2 corner offsets mod 10 m: {f['sentinel2_lattice_offset_mod10']}"))
    for n, g in ev["grids"].items():
        rec = district_grid(n).to_dict()
        same = all(abs(rec[k] - g[k]) < 1e-6 for k in ("x0", "y1", "res")) and rec["width"] == g["width"] and rec["height"] == g["height"]
        out.append(_res(f"grid {n} reproducible from boundary", "PASS" if same else "FAIL", f"{g['width']}x{g['height']} @ {g['res']} m, origin ({g['x0']}, {g['y1']})"))
    return out

# ------------------------------------------------------------------ manifests
def audit_manifests() -> tuple[list[dict], dict]:
    out, facts = [], {}
    from ..acquisition.manifest import SCHEMA
    for fam in ("landsat", "sentinel2", "sentinel1"):
        g = gpd.read_parquet(R / f"data/manifests/{fam}_manifest.parquet")
        miss = set(SCHEMA) - set(g.columns)
        dup = int(g.product_id.duplicated().sum())
        bad_sel = int((g.selected & g.exclusion_reason.notna()).sum() + (~g.selected & g.exclusion_reason.isna()).sum())
        out.append(_res(f"{fam} manifest schema & selection logic", "PASS" if not miss and dup == 0 and bad_sel == 0 else "FAIL",
                        f"{len(g):,} items, {int(g.selected.sum()):,} selected, duplicates {dup}, missing columns {sorted(miss)}, inconsistent selection rows {bad_sel}"))
        s = g[g.selected]
        facts[fam] = {"n": len(g), "selected": int(s.selected.sum()), "first": str(s.date.min()), "last": str(s.date.max()),
                      "per_year": s.groupby("year").size().to_dict(), "platforms": s.platform.value_counts().to_dict(),
                      "cutoff": str(g.archive_cutoff_utc.iloc[0])}
        if fam == "landsat":
            l7late = int(((s.platform == "landsat-7") & (s.date > "2021-12-31")).sum())
            t2 = int((s.collection_category == "T2").sum())
            out.append(_res("Landsat rules: no L7 after 2021, no Tier-2, only L2SP", "PASS" if l7late == 0 and t2 == 0 and (s.processing_level == "L2SP").all() else "FAIL",
                            f"L7 after 2021 selected: {l7late}; T2 selected: {t2}; levels {s.processing_level.unique().tolist()}"))
            slc = int(s.quality_flags.fillna("").str.contains("SLC_OFF").sum())
            out.append(_res("Landsat-7 SLC-off flagged", "INFO", f"{slc} selected SLC-off scenes flagged (2003-06 → 2021)"))
            yrs = sorted(s.year.unique()); gaps = [y for y in range(1990, 2027) if y not in yrs]
            out.append(_res("Landsat: every year 1990-2026 has selected scenes", "PASS" if not gaps else "FAIL", f"missing years: {gaps or 'none'}"))
        if fam == "sentinel2":
            k = s.mgrs_tile.astype(str) + s.datetime_utc.astype(str)
            out.append(_res("Sentinel-2: one product per tile/datetime after de-duplication", "PASS" if not k.duplicated().any() else "FAIL",
                            f"{int(k.duplicated().sum())} duplicates among selected"))
        if fam == "sentinel1":
            st = s.groupby("year").orbit_state.nunique()
            out.append(_res("Sentinel-1: single orbit direction per year", "PASS" if (st <= 1).all() else "FAIL", f"orbit states per year: {st.to_dict()}"))
            rtc_note = "PC sentinel-1-rtc lacks ~half of 2025 S1A frames vs GRD (Phase-1 finding)"
            out.append(_res("Sentinel-1 archive completeness (2025)", "WARN", rtc_note))
    return out, facts

# ------------------------------------------------------------------ products (metadata-level)
REQUIRED = config.load("qa")["required_metadata"]
def audit_products(root: Path | None = None) -> tuple[list[dict], pd.DataFrame]:
    """Metadata-level audit of every product under `root` (default data/composites; the Phase-1 audit passes the
    immutable Phase-1 snapshot so that Phase-2 reprocessing in progress does not leak into the Phase-1 verdict)."""
    root = root or R / "data/composites"
    out, rows = [], []
    for m in sorted(root.glob("**/metadata.json")):
        d = json.loads(m.read_text())
        if "product_id" not in d: continue
        parts = m.relative_to(root).parts
        rows.append({"path": str(m.relative_to(R)), "grid": parts[0], "year": int(parts[1]), "family": parts[2],
                     "period": d["temporal"]["period"], "kind": d["temporal"]["kind"], "complete": d["temporal"]["complete"],
                     "product_id": d["product_id"], "qa": d.get("qa", {}).get("status", "not_run"),
                     "missing_keys": ",".join(k for k in REQUIRED if k not in d), "git_commit": d["code"]["git_commit"],
                     "harmonization": d.get("processing", {}).get("harmonization"),
                     "n_items": d["statistics"]["n_items"], "valid": d["statistics"]["district_valid_fraction"],
                     "reliable": d["statistics"]["district_reliable_fraction_ge3"],
                     "sensors": ",".join(sorted(d.get("sensors", {}))),
                     "rasters_present": all((R / f["path"]).exists() for f in d["files"].values()),
                     "n_files": len(d["files"]), "corrections": len(d.get("corrections", []))})
    df = pd.DataFrame(rows)
    out.append(_res("product metadata complete", "PASS" if (df.missing_keys == "").all() else "FAIL",
                    f"{len(df)} products; {int((df.missing_keys != '').sum())} missing required keys"))
    out.append(_res("product ids unique", "PASS" if df.product_id.is_unique else "FAIL", f"{df.product_id.nunique()} unique of {len(df)}"))
    qa = df.qa.value_counts().to_dict()
    out.append(_res("every product has automated QA", "PASS" if "not_run" not in qa else "FAIL", f"QA status counts {qa}"))
    # expected structure: Landsat 4 periods/year; Sentinel 16/year
    # *_on_G30 families are single-period registration/consistency test products, not cube products
    for (fam, grid), g in df[~df.family.str.startswith("landsat_cal") & ~df.family.str.endswith("_on_G30")].groupby(["family", "grid"]):
        per_year = g.groupby("year").size()
        expect = 4 if fam == "landsat" else 16
        bad = per_year[per_year != expect]
        out.append(_res(f"{fam} {grid}: period structure", "PASS" if bad.empty else "FAIL",
                        f"{per_year.index.min()}-{per_year.index.max()}, {len(per_year)} years × {expect} periods; irregular years: {bad.to_dict() or 'none'}"))
    nogit = df[df.git_commit.str.contains("no-git|dirty")]
    out.append(_res("code version recorded for every product", "WARN" if len(nogit) else "PASS",
                    f"{len(nogit)} of {len(df)} products record 'no-git' or '-dirty' code versions",
                    "products built before the repository was committed (or with uncommitted edits) cannot be tied to an exact commit; "
                    "the final code that reproduces them is in this package and the reproducibility test below checks it"))
    present = int(df.rasters_present.sum())
    out.append(_res("rasters present locally", "INFO", f"{present} of {len(df)} products have rasters here (delivered package carried metadata + samples; the rest regenerate from manifests)"))
    corr = int(df.corrections.sum())
    out.append(_res("metadata corrections logged", "INFO", f"{corr} products carry a logged correction (calibration product_id fix)"))
    return out, df

# ------------------------------------------------------------------ rasters
def audit_rasters(df: pd.DataFrame, limit: int = 40) -> list[dict]:
    out = []
    sub = df[df.rasters_present]
    issues = defaultdict(list); n = 0
    for _, r in sub.head(limit).iterrows():
        d = json.loads((R / r.path).read_text()); g = d["grid"]; n += 1
        files = {k: R / v["path"] for k, v in d["files"].items()}
        for k, p in files.items():
            with rasterio.open(p) as s:
                if (s.height, s.width) != (g["height"], g["width"]) or any(abs(a - b) > 1e-6 for a, b in zip(list(s.transform)[:6], g["transform"])):
                    issues["grid/transform mismatch"].append(f"{r.product_id}:{k}")
                if s.crs.to_string() != g["crs"]: issues["crs mismatch"].append(f"{r.product_id}:{k}")
            if sha256(p) != d["files"][k]["sha256"]: issues["checksum mismatch vs metadata"].append(f"{r.product_id}:{k}")
        with rasterio.open(files["observation_count"]) as s: n_cnt = s.read(1)
        with rasterio.open(files["qa"]) as s: qa = s.read(); names = list(s.descriptions)
        with rasterio.open(files["valid_mask"]) as s: vm = s.read(1)
        if not np.array_equal(qa[names.index("n_clear")], n_cnt): issues["qa n_clear != observation_count"].append(r.product_id)
        if (qa[names.index("n_clear")] > qa[names.index("n_observed")]).any(): issues["n_clear > n_observed"].append(r.product_id)
        exp_vm = np.where(n_cnt >= 3, 3, np.where(n_cnt >= 1, 2, 1)); exp_vm[vm == 0] = 0
        if not np.array_equal(vm, exp_vm): issues["valid_mask inconsistent with counts"].append(r.product_id)
        main = files.get("optical_composite")
        if main is not None:
            with rasterio.open(main) as s: c = s.read(1)
            with rasterio.open(files["uncertainty"]) as s: u = s.read(1)
            if ((c != -32768) & (n_cnt == 0)).any(): issues["composite value where no clear observation"].append(r.product_id)
            if ((c == -32768) & (n_cnt > 0) & (vm > 0)).any(): issues["missing composite where observations exist"].append(r.product_id)
            if ((u != -32768) & (n_cnt < 3)).any(): issues["uncertainty reported with n<3"].append(r.product_id)
            per = sum(qa[names.index(x)] for x in names if x.startswith("n_clear_"))
            if not np.array_equal(per, n_cnt): issues["per-sensor counts do not sum to total"].append(r.product_id)
    out.append(_res(f"raster internal consistency ({n} products with rasters)", "PASS" if not issues else "FAIL",
                    "; ".join(f"{k}: {len(v)}" for k, v in issues.items()) or "grid, CRS, checksums, count/QA/mask/uncertainty logic all consistent",
                    {k: v[:5] for k, v in issues.items()}))
    return out

# ------------------------------------------------------------------ alignment against an independent layer
def audit_alignment(product_dir: Path, ref_path: Path, shifts: int = 2) -> dict:
    """Shift-search IoU between our dry-season water (MNDWI>0) and JRC permanent water: the peak must be at (0,0)."""
    with rasterio.open(product_dir / "optical_composite.tif") as s:
        names = list(s.descriptions); g = s.read(names.index("green") + 1).astype(float); sw = s.read(names.index("swir16") + 1).astype(float)
    ok = (g != -32768) & (sw != -32768)
    ours = ok & ((g - sw) / np.where(g + sw == 0, 1, g + sw) > 0)
    with rasterio.open(ref_path) as s: j = s.read(1)
    ref = (j >= 90) & (j != 255)
    best = {}
    for dy in range(-shifts, shifts + 1):
        for dx in range(-shifts, shifts + 1):
            a = np.roll(np.roll(ours, dy, 0), dx, 1)[shifts:-shifts, shifts:-shifts]; b = ref[shifts:-shifts, shifts:-shifts]
            best[(dy, dx)] = (a & b).sum() / max((a | b).sum(), 1)
    peak = max(best, key=best.get)
    return {"peak_shift_px": peak, "iou_at_zero": round(best[(0, 0)], 4), "iou_at_peak": round(best[peak], 4)}

def summarise_years(df: pd.DataFrame) -> pd.DataFrame:
    q = df[df.family.isin(["landsat", "sentinel1", "sentinel2"])]
    return q.pivot_table(index=["family", "grid", "year"], columns="period", values="qa", aggfunc="first")

# ------------------------------------------------------------------ sub-pixel co-registration
def _upsampled_dft(data, up, region, off_y, off_x):
    """Matrix-multiply DFT of `data` evaluated on an up-sampled grid of size region around (off_y, off_x)."""
    ny, nx = data.shape
    kc = np.exp((-2j * np.pi / (nx * up)) * (np.fft.ifftshift(np.arange(nx))[:, None] - nx // 2) * (np.arange(region) - off_x)[None, :])
    kr = np.exp((-2j * np.pi / (ny * up)) * (np.arange(region) - off_y)[:, None] * (np.fft.ifftshift(np.arange(ny))[None, :] - ny // 2))
    return kr @ data @ kc

def phase_correlation(a: np.ndarray, b: np.ndarray, up: int = 50) -> tuple[float, float, float]:
    """Sub-pixel shift (dy, dx) of b relative to a; Hann-windowed cross-correlation with Guizar-Sicairos et al.
    (2008) upsampled-DFT refinement (1/up px). Returns (dy, dx, peak strength)."""
    a = np.nan_to_num(a - np.nanmean(a)); b = np.nan_to_num(b - np.nanmean(b))
    w = np.outer(np.hanning(a.shape[0]), np.hanning(a.shape[1]))
    A = np.fft.fft2(a * w); B = np.fft.fft2(b * w)
    cps = B * np.conj(A)          # NOT phase-normalised: verified unbiased on non-circular synthetic shifts (tests)
    r = np.real(np.fft.ifft2(cps)); py, px = np.unravel_index(np.argmax(r), r.shape)
    sh = np.array([py, px], float); mid = np.array(r.shape) // 2
    sh[sh > mid] -= np.array(r.shape)[sh > mid]
    region = int(np.ceil(up * 1.5)); dft_shift = np.trunc(region / 2.0)
    sh = np.round(sh * up) / up
    off = dft_shift - sh * up
    cc = np.abs(_upsampled_dft(np.conj(cps), up, region, off[0], off[1]))
    my, mx = np.unravel_index(np.argmax(cc), cc.shape)
    sh = sh + (np.array([my, mx]) - dft_shift) / up
    return float(sh[0]), float(sh[1]), float(r.max() / (np.sqrt((a * w) ** 2).sum() * np.sqrt((b * w) ** 2).sum() / a.size + 1e-12))

def registration_test(path_a: Path, path_b: Path, band_a: str, band_b: str, tiles: int = 3) -> dict:
    """Shift of image B relative to A on a common grid, estimated per tile (consistency check)."""
    def rd(p, band):
        with rasterio.open(p) as s:
            x = s.read(list(s.descriptions).index(band) + 1).astype(float); x[x == -32768] = np.nan; return x
    a, b = rd(path_a, band_a), rd(path_b, band_b)
    H, W = a.shape; th, tw = H // tiles, W // tiles; res = []
    for i in range(tiles):
        for j in range(tiles):
            sa = a[i*th:(i+1)*th, j*tw:(j+1)*tw]; sb = b[i*th:(i+1)*th, j*tw:(j+1)*tw]
            if np.isnan(sa).mean() > 0.2 or np.isnan(sb).mean() > 0.2: continue
            res.append(phase_correlation(sa, sb))
    r = np.array(res)
    return {"n_tiles": len(res), "dy_px_median": float(np.median(r[:, 0])), "dx_px_median": float(np.median(r[:, 1])),
            "dy_px_iqr": float(np.subtract(*np.percentile(r[:, 0], [75, 25]))), "dx_px_iqr": float(np.subtract(*np.percentile(r[:, 1], [75, 25]))),
            "peak_median": float(np.median(r[:, 2])), "tiles": r.round(3).tolist()}
