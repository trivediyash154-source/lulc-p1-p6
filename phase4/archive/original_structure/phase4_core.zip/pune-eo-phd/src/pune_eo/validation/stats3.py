"""Paired statistics for Phase 3: spatial block bootstrap (resampling 3 km blocks, not pixels), McNemar, per-class CIs."""
from __future__ import annotations
import numpy as np
from scipy.stats import chi2

def block_bootstrap_diff(stat_fn, blocks: np.ndarray, n: int = 1000, seed: int = 20261020) -> dict:
    """stat_fn(index_array) -> scalar difference (model X - model Y) on the SAME cells. Blocks are resampled with replacement."""
    rng = np.random.default_rng(seed); ub, inv = np.unique(blocks, return_inverse=True); members = [np.flatnonzero(inv == i) for i in range(len(ub))]
    point = stat_fn(np.arange(len(blocks))); bs = []
    for _ in range(n):
        pick = rng.integers(0, len(ub), len(ub)); idx = np.concatenate([members[i] for i in pick]); bs.append(stat_fn(idx))
    bs = np.array(bs); lo, hi = np.nanpercentile(bs, [2.5, 97.5])
    return {"estimate": float(point), "ci95": [float(lo), float(hi)], "excludes_zero": bool(lo > 0 or hi < 0), "n_blocks": int(len(ub)), "n_boot": n}

def mcnemar(correct_a: np.ndarray, correct_b: np.ndarray) -> dict:
    """Exact-continuity McNemar on paired correctness. NOTE: assumes independent items - spatial autocorrelation makes p optimistic;
    the block bootstrap is the primary test, McNemar is reported as secondary."""
    b = int((correct_a & ~correct_b).sum()); c = int((~correct_a & correct_b).sum())
    stat = (abs(b - c) - 1) ** 2 / (b + c) if (b + c) else 0.0
    return {"a_only_correct": b, "b_only_correct": c, "chi2": float(stat), "p_value": float(chi2.sf(stat, 1)) if (b + c) else 1.0}
