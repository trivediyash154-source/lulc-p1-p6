"""Phase-3 experiment registry: PRE-REGISTRATION, immutable results.

Statuses : PENDING (registered, not executed or not executable) | PASS (executed, results valid) | FAIL (execution failed) |
           INVALID (executed, results found invalid - kept with reason) | SUPERSEDED (replaced by a newer version - kept, points to it)
Outcome  : SUPPORTED | NOT_SUPPORTED | INCONCLUSIVE | NA  (hypothesis outcome, separate from execution status)
Records live in experiments/registry3/<ID>.json. A completed record is never overwritten: a re-run must use a new version
(<ID>@v2), and the old record is marked SUPERSEDED with a pointer."""
from __future__ import annotations
import json, platform, subprocess, time
from pathlib import Path
from .. import config
from ..provenance import utcnow

REG = config.path("experiments", "registry3")
FIELDS = ["experiment_id", "group", "hypothesis", "reason", "dataset_version", "region", "years", "features", "labels", "label_tier", "model",
          "training_split", "validation_split", "test_split", "seed", "hyperparameters", "metrics_planned"]
STATUSES = {"PENDING", "PASS", "FAIL", "INVALID", "SUPERSEDED"}; OUTCOMES = {"SUPPORTED", "NOT_SUPPORTED", "INCONCLUSIVE", "NA"}

def _git():
    try:
        c = subprocess.run(["git", "-C", str(config.ROOT), "rev-parse", "--short", "HEAD"], capture_output=True, text=True).stdout.strip()
        d = subprocess.run(["git", "-C", str(config.ROOT), "status", "--porcelain", "src", "configs", "scripts"], capture_output=True, text=True).stdout.strip()
        return c + ("-dirty" if d else "")
    except Exception:
        return "no-git"

def path(eid: str) -> Path: return REG / f"{eid.replace('@', '_at_')}.json"
def load(eid: str) -> dict | None:
    p = path(eid); return json.loads(p.read_text()) if p.exists() else None
def _write(rec):
    REG.mkdir(parents=True, exist_ok=True); p = path(rec["experiment_id"]); t = p.with_suffix(".tmp")
    t.write_text(json.dumps(rec, indent=1, default=str)); t.replace(p); return rec

def register(**spec) -> dict:
    """Pre-register (status PENDING). Re-registering an identical PENDING spec is a no-op; changing a completed one is refused."""
    miss = [k for k in FIELDS if k not in spec]
    if miss: raise ValueError(f"pre-registration missing {miss}")
    old = load(spec["experiment_id"])
    if old and old["status"] != "PENDING": raise RuntimeError(f"{spec['experiment_id']} already {old['status']}: register a new version (@v2)")
    rec = {**spec, "status": "PENDING", "outcome": None, "registered_utc": (old or {}).get("registered_utc", utcnow()), "code_version_at_registration": _git()}
    return _write(rec)

class Run:
    """Context for executing a pre-registered experiment."""
    def __init__(self, eid: str):
        self.rec = load(eid)
        if self.rec is None: raise RuntimeError(f"{eid} was not pre-registered")
        if self.rec["status"] != "PENDING": raise RuntimeError(f"{eid} is {self.rec['status']} - immutable")
        self.t0 = time.time(); self.rec.update(started_utc=utcnow(), code_version=_git(), environment={"python": platform.python_version()})
    def complete(self, metrics: dict, outcome: str, result: str, outputs: dict | None = None, uncertainty=None, n_samples=None):
        assert outcome in OUTCOMES
        self.rec.update(status="PASS", outcome=outcome, metrics=metrics, result=result, outputs=outputs or {}, uncertainty=uncertainty,
                        n_samples=n_samples, runtime_s=round(time.time() - self.t0, 1), finished_utc=utcnow())
        return _write(self.rec)
    def fail(self, error: str, attempted: str, remaining: str):
        self.rec.update(status="FAIL", error=error, attempted=attempted, remaining=remaining, runtime_s=round(time.time() - self.t0, 1), finished_utc=utcnow())
        return _write(self.rec)

def mark_pending_reason(eid: str, reason: str, needs: str):
    rec = load(eid); rec.update(not_run_reason=reason, needs=needs); return _write(rec)

def invalidate(eid: str, reason: str):
    rec = load(eid); rec.update(status="INVALID", invalid_reason=reason, invalidated_utc=utcnow()); return _write(rec)

def supersede(eid: str, new_id: str, reason: str):
    rec = load(eid); rec.update(status="SUPERSEDED", superseded_by=new_id, superseded_reason=reason, superseded_utc=utcnow()); return _write(rec)

def table() -> list[dict]:
    return [json.loads(p.read_text()) for p in sorted(REG.glob("*.json"))]
