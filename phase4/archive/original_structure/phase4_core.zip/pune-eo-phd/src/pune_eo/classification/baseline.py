"""Baseline L1 classification on the 30 m benchmark windows (logistic regression, Gaussian MLC, Random Forest, XGBoost).

Samples come from the feature cube (data/features/cube/<grid>.zarr) and the silver labels / spatial splits (data/labels/<grid>/).
Model selection uses VAL blocks only; TEST blocks are scored once. Metrics are 'agreement with the silver reference' (see
docs/label_protocol.md) - never map accuracy."""
from __future__ import annotations
import numpy as np, pandas as pd, rasterio, xarray as xr
from sklearn.metrics import confusion_matrix, f1_score, precision_recall_fscore_support, cohen_kappa_score, balanced_accuracy_score
from .. import config

CLASSES = [1, 2, 3, 4]                      # built_up, agriculture, natural_vegetation, water (supported L1 classes)
CLASS_NAMES = {1: "built_up", 2: "agriculture", 3: "natural_vegetation", 4: "water"}
DRY_BANDS = ["dry_blue", "dry_green", "dry_red", "dry_nir", "dry_swir1", "dry_swir2"]

def window_grid_id(w: str) -> str: return w if w.startswith("pune_") else f"pune_G30_{w}"

def open_cube(w: str) -> xr.Dataset:
    return xr.open_zarr(config.path("data", "features", "cube", f"{window_grid_id(w)}.zarr"), consolidated=True)

def _r(p, b=1):
    with rasterio.open(p) as s: return s.read(b)

def feature_stack(ds: xr.Dataset, year: int, feats: list[str]) -> np.ndarray:
    """(n_feat, H, W) from landsat (year), terrain (static) and sentinel (year) variables."""
    out = []
    lf, tf, sf = list(ds.feature.values), list(ds.tfeature.values), list(ds.sfeature.values)
    L = ds.landsat.sel(year=year).values if any(f in lf for f in feats) else None
    S = ds.sentinel.sel(syear=year).values if any(f in sf for f in feats) and year in ds.syear.values else None
    T = ds.terrain.values if any(f in tf for f in feats) else None
    for f in feats:
        if f in lf: out.append(L[lf.index(f)])
        elif f in tf: out.append(T[tf.index(f)])
        elif f in sf: out.append(S[sf.index(f)] if S is not None else np.full(ds.terrain.shape[1:], np.nan, np.float32))
        else: raise KeyError(f)
    a = np.stack(out).astype(np.float32); a[~np.isfinite(a)] = np.nan
    return a

def samples(windows: list[str], year: int, feats: list[str], split: dict | None = None, cap: dict | None = None, seed: int = 0,
            label: str = "silver_l1") -> pd.DataFrame:
    """Labelled cells with features. split: {window: split array} (default data/labels/<w>/splits.tif).
    cap: max cells per class per window per split, e.g. {1: 4000, 2: 5000, 3: None}."""
    rng = np.random.default_rng(seed); frames = []
    for w in windows:
        gid = window_grid_id(w); d = config.path("data", "labels", gid)
        lab = _r(d / f"{label}.tif"); sp = split[w] if split and w in split else _r(d / "splits.tif")
        X = feature_stack(open_cube(w), year, feats)
        for s in (1, 2, 3):
            for c in np.unique(lab[(sp == s) & np.isin(lab, CLASSES)]):     # unsupported classes (bare_sparse, other) excluded
                r, cc = np.nonzero((sp == s) & (lab == c))
                k = cap.get(s) if cap else None
                if k and r.size > k:
                    i = rng.choice(r.size, k, replace=False); r, cc = r[i], cc[i]
                df = pd.DataFrame(X[:, r, cc].T, columns=feats)
                df["label"], df["split"], df["window"], df["row"], df["col"] = int(c), s, gid, r, cc
                frames.append(df)
    return pd.concat(frames, ignore_index=True)

def prune_correlated(X: pd.DataFrame, rho: float = 0.95) -> tuple[list[str], list[dict]]:
    """Greedy, in registry order: drop a feature whose |Spearman rho| with an already-kept feature exceeds `rho`."""
    C = X.rank().corr().abs(); keep, dropped = [], []
    for f in X.columns:
        hit = [k for k in keep if C.loc[f, k] > rho]
        if hit: dropped.append({"dropped": f, "kept_partner": hit[0], "abs_spearman": round(float(C.loc[f, hit[0]]), 4)})
        else: keep.append(f)
    return keep, dropped

def make_model(name: str, seed: int = 0, n_jobs: int = 2, **hp):
    from sklearn.pipeline import make_pipeline
    from sklearn.impute import SimpleImputer
    from sklearn.preprocessing import StandardScaler
    if name == "logreg":
        from sklearn.linear_model import LogisticRegression
        return make_pipeline(SimpleImputer(strategy="median"), StandardScaler(), LogisticRegression(max_iter=2000, C=hp.get("C", 1.0), random_state=seed))
    if name == "gaussian_mlc":
        from sklearn.discriminant_analysis import QuadraticDiscriminantAnalysis
        return make_pipeline(SimpleImputer(strategy="median"), StandardScaler(), QuadraticDiscriminantAnalysis(reg_param=hp.get("reg_param", 0.1)))
    if name == "rf":
        from sklearn.ensemble import RandomForestClassifier
        return RandomForestClassifier(n_estimators=hp.get("n_estimators", 300), min_samples_leaf=hp.get("min_samples_leaf", 2),
                                      max_features=hp.get("max_features", "sqrt"), n_jobs=n_jobs, random_state=seed)
    if name == "xgb":
        from xgboost import XGBClassifier
        return XGBClassifier(n_estimators=hp.get("n_estimators", 600), learning_rate=hp.get("learning_rate", 0.08), max_depth=hp.get("max_depth", 6),
                             subsample=0.8, colsample_bytree=0.8, tree_method="hist", n_jobs=n_jobs, random_state=seed,
                             early_stopping_rounds=hp.get("early_stopping_rounds", 40), eval_metric="mlogloss")
    raise KeyError(name)

def fit(model_name, model, Xtr, ytr, Xva=None, yva=None):
    if model_name == "xgb":
        enc = {c: i for i, c in enumerate(CLASSES)}
        model.fit(Xtr, np.vectorize(enc.get)(ytr), eval_set=[(Xva, np.vectorize(enc.get)(yva))], verbose=False)
    else:
        model.fit(Xtr, ytr)
    return model

def predict(model_name, model, X):
    p = model.predict(X)
    return np.asarray(CLASSES)[p] if model_name == "xgb" else p

def predict_proba(model, X):
    return model.predict_proba(X)

def pontius(cm: np.ndarray) -> dict:
    """Quantity and allocation disagreement (Pontius & Millones 2011) from a confusion matrix of counts."""
    p = cm / cm.sum(); q = float(np.abs(p.sum(0) - p.sum(1)).sum() / 2); d = 1 - float(np.trace(p))
    return {"quantity_disagreement": round(q, 4), "allocation_disagreement": round(d - q, 4), "total_disagreement": round(d, 4)}

def evaluate(y, yhat) -> dict:
    labs = [c for c in CLASSES if (np.asarray(y) == c).any() or (np.asarray(yhat) == c).any()]
    cm = confusion_matrix(y, yhat, labels=labs); P, R, F, N = precision_recall_fscore_support(y, yhat, labels=labs, zero_division=0)
    return {"n": int(len(y)), "overall_agreement": round(float(np.trace(cm) / cm.sum()), 4),
            "balanced_accuracy": round(float(balanced_accuracy_score(y, yhat)), 4),
            "macro_f1": round(float(f1_score(y, yhat, labels=labs, average="macro", zero_division=0)), 4),
            "kappa": round(float(cohen_kappa_score(y, yhat)), 4), **pontius(cm),
            "per_class": {CLASS_NAMES[c]: {"precision": round(float(P[i]), 4), "recall": round(float(R[i]), 4), "f1": round(float(F[i]), 4), "support": int(N[i])}
                          for i, c in enumerate(labs)},
            "confusion_matrix": {"labels": [CLASS_NAMES[c] for c in labs], "counts": cm.tolist()}}
