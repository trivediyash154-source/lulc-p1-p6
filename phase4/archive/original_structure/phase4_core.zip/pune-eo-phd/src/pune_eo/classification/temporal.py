"""Temporal LULC 1990-2026: per-year classifier posteriors -> hidden-Markov smoothing -> trajectories.

HMM (per pixel, K=4 states, T years):
  emission  e_t(k) = p(k | x_t) / pi_k   (classifier posterior as a scaled likelihood; pi = training class prior)
            missing year (no composite / all-NaN features) -> e_t = 1 (uninformative): the gap is bridged, never invented
  transition A (K x K) estimated by Baum-Welch on TRAIN-block pixels only (no independent reference is used to tune it)
  decoding  Viterbi path (labels) + forward-backward posteriors gamma_t(k) and pairwise xi_t(j,k) (transition probability)
Vectorised over pixels (numpy, log-space); memory O(T*K*N_chunk)."""
from __future__ import annotations
import numpy as np

def _norm(a, axis=-1):
    s = a.sum(axis=axis, keepdims=True); return a / np.where(s > 0, s, 1)

def emissions(post: np.ndarray, prior: np.ndarray, valid: np.ndarray | None = None, floor: float = 1e-4) -> np.ndarray:
    """post (T, K, N) -> scaled likelihoods (T, K, N); invalid years -> 1."""
    e = np.maximum(post, floor) / prior[None, :, None]
    if valid is not None: e = np.where(valid[:, None, :], e, 1.0)
    return e / e.max(axis=1, keepdims=True)

def forward_backward(e: np.ndarray, A: np.ndarray, p0: np.ndarray):
    """e (T,K,N). Returns gamma (T,K,N), xi_sum (K,K) summed over t and N, loglik (N,)."""
    T, K, N = e.shape; alpha = np.empty_like(e); c = np.empty((T, N))
    a = p0[:, None] * e[0]; c[0] = a.sum(0); alpha[0] = a / c[0]
    for t in range(1, T):
        a = (A.T @ alpha[t - 1]) * e[t]; c[t] = a.sum(0); alpha[t] = a / c[t]
    beta = np.ones_like(e); xi = np.zeros((K, K))
    for t in range(T - 2, -1, -1):
        b = A @ (e[t + 1] * beta[t + 1]); beta[t] = b / c[t + 1]
        xi += np.einsum("in,ij,jn,jn->ij", alpha[t], A, e[t + 1], beta[t + 1] / c[t + 1][None])
    gamma = _norm(alpha * beta, axis=1)
    return gamma, xi, np.log(c).sum(0)

def baum_welch(e: np.ndarray, K: int, iters: int = 30, self_init: float = 0.95, tol: float = 1e-4):
    A = np.full((K, K), (1 - self_init) / (K - 1)); np.fill_diagonal(A, self_init); p0 = np.full(K, 1 / K); ll_old = -np.inf; hist = []
    for it in range(iters):
        gamma, xi, ll = forward_backward(e, A, p0)
        A = _norm(xi + 1e-6, axis=1); p0 = _norm(gamma[0].sum(1) + 1e-6, axis=0); L = float(ll.mean()); hist.append(L)
        if abs(L - ll_old) < tol: break
        ll_old = L
    return A, p0, hist

def viterbi(e: np.ndarray, A: np.ndarray, p0: np.ndarray) -> np.ndarray:
    T, K, N = e.shape; lA = np.log(A); d = np.log(p0)[:, None] + np.log(e[0]); bp = np.empty((T, K, N), np.int8)
    for t in range(1, T):
        s = d[:, None, :] + lA[:, :, None]                       # (from, to, N)
        bp[t] = s.argmax(0); d = s.max(0) + np.log(e[t])
    path = np.empty((T, N), np.int8); path[-1] = d.argmax(0)
    for t in range(T - 1, 0, -1): path[t - 1] = np.take_along_axis(bp[t], path[t][None], 0)[0]
    return path

def flip_rate(labels: np.ndarray) -> np.ndarray:
    """Number of class changes per pixel over the series (T, N) -> (N,)."""
    return (np.diff(labels.astype(np.int16), axis=0) != 0).sum(0)
