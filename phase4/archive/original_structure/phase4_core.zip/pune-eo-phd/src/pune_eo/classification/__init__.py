"""Classification: baseline L1 models (baseline.py) and temporal LULC (temporal.py). Results only via experiments/registry."""
