"""Freeze / verify the Phase-4 evaluation protocol and the Phase-4 experiment registry (experiments/registry4/).
* code_hash(): SHA-256 over the evaluation modules (evaluation4 metrics/stats/history + calibration metrics/conformal) - the frozen code.
* freeze(): writes the hash + UTC time into configs/phase4_evaluation_protocol.yaml (refuses to re-freeze a different hash unless a new protocol version is given).
* verify_frozen(): raises if the evaluation code differs from the frozen hash.
* Registry4: like registry3, plus `kind` (exploratory | confirmatory) and `family` (for FDR). A CONFIRMATORY experiment records the protocol version and
  code hash at registration and refuses to run if either changed. Completed records are immutable; corrections are new versions (@v2)."""
from __future__ import annotations
import hashlib, json, platform, subprocess, time
from pathlib import Path
import yaml
from .. import config
from ..provenance import utcnow
PKG = Path(__file__).parent; MODULES = ("evaluation4/metrics.py", "evaluation4/stats.py", "evaluation4/history.py", "evaluation4/protocol.py", "calibration/metrics.py", "calibration/conformal.py"); PROTO = config.path("configs", "phase4_evaluation_protocol.yaml"); REG = config.path("experiments", "registry4")
FIELDS = ["experiment_id", "kind", "family", "hypothesis", "comparator", "primary_metric", "direction", "threshold", "dataset_version", "evaluation_set", "region", "years", "features", "labels",
          "label_tier", "model", "seeds", "splits", "metrics_planned"]
OUTCOMES = {"SUPPORTED", "NOT_SUPPORTED", "INCONCLUSIVE", "NA"}

def code_hash() -> str:
    h = hashlib.sha256()
    for m in MODULES: h.update(m.encode()); h.update((PKG.parent / m).read_bytes())
    return h.hexdigest()

def load_protocol(path: Path | None = None) -> dict: return yaml.safe_load(open(path or PROTO))

def protocol_hash(path: Path | None = None) -> str:
    """SHA-256 of the protocol YAML with the `frozen:` block removed (thresholds, gates, regions, rules are therefore pinned too - protocol v2)."""
    txt = open(path or PROTO).read(); txt = txt.split("\nfrozen:")[0].rstrip() + "\n"; return hashlib.sha256(txt.encode()).hexdigest()

def freeze(path: Path | None = None) -> dict:
    path = path or PROTO; P = load_protocol(path); cur = code_hash(); fz = P.get("frozen") or {}
    if fz.get("code_sha256") and (fz["code_sha256"] != cur or fz.get("protocol_sha256", protocol_hash(path)) != protocol_hash(path)):
        raise RuntimeError("protocol already frozen with a different code/protocol hash: write a new protocol_version file and record why")
    if not fz.get("code_sha256"):
        txt = open(path).read().rstrip() + f"\nfrozen:\n  code_sha256: {cur}\n  protocol_sha256: {protocol_hash(path)}\n  frozen_utc: '{utcnow()}'\n  modules: {list(MODULES)}\n"; open(path, "w").write(txt)
    return load_protocol(path)

def verify_frozen(path: Path | None = None) -> str:
    P = load_protocol(path or PROTO); fz = P.get("frozen") or {}
    if not fz.get("code_sha256"): raise RuntimeError("evaluation protocol not frozen")
    if fz["code_sha256"] != code_hash(): raise RuntimeError("evaluation code changed after freeze - confirmatory runs refused")
    if "protocol_sha256" in fz and fz["protocol_sha256"] != protocol_hash(path): raise RuntimeError("protocol YAML changed after freeze - confirmatory runs refused")
    return fz["code_sha256"]

def check_confirmatory_records() -> dict:
    """Gate G8 automated check: every non-superseded confirmatory record carries the CURRENT protocol version and code hash and was registered after the freeze."""
    P = load_protocol(); fz = P.get("frozen") or {}; out = {"protocol_version": P.get("protocol_version"), "records": {}, "ok": True}
    for p in sorted(REG.glob("*.json")):
        r = json.loads(p.read_text())
        if r.get("kind") != "confirmatory" or r.get("status") == "SUPERSEDED": continue
        ok = r.get("protocol_version") == P.get("protocol_version") and r.get("eval_code_sha256") == fz.get("code_sha256") and str(r.get("registered_utc", "")) >= str(fz.get("frozen_utc", ""))
        out["records"][r["experiment_id"]] = {"ok": bool(ok), "status": r["status"]}; out["ok"] &= bool(ok)
    return out

def supersede(eid, new_id, reason): rec = load(eid); rec.update(status="SUPERSEDED", superseded_by=new_id, superseded_reason=reason, superseded_utc=utcnow()); return _write(rec)

def _git():
    try: return subprocess.run(["git", "-C", str(config.ROOT), "rev-parse", "--short", "HEAD"], capture_output=True, text=True).stdout.strip()
    except Exception: return None
def path(eid): return REG / f"{eid.replace('@', '_at_')}.json"
def load(eid): p = path(eid); return json.loads(p.read_text()) if p.exists() else None
def _write(rec): REG.mkdir(parents=True, exist_ok=True); path(rec["experiment_id"]).write_text(json.dumps(rec, indent=1, default=str)); return rec

def register(**spec) -> dict:
    miss = [k for k in FIELDS if k not in spec]
    if miss: raise ValueError(f"pre-registration missing {miss}")
    if spec["kind"] not in ("exploratory", "confirmatory"): raise ValueError("kind must be exploratory or confirmatory")
    old = load(spec["experiment_id"])
    if old and old["status"] != "PENDING": raise RuntimeError(f"{spec['experiment_id']} already {old['status']}: register a new version (@v2)")
    rec = {**spec, "status": "PENDING", "outcome": None, "registered_utc": (old or {}).get("registered_utc", utcnow()), "code_version_at_registration": _git()}
    if spec["kind"] == "confirmatory":
        P = load_protocol(); rec["protocol_version"] = P["protocol_version"]; rec["eval_code_sha256"] = verify_frozen()
    return _write(rec)

class Run:
    def __init__(self, eid):
        self.rec = load(eid)
        if self.rec is None: raise RuntimeError(f"{eid} was not pre-registered")
        if self.rec["status"] != "PENDING": raise RuntimeError(f"{eid} is {self.rec['status']} - immutable")
        if self.rec["kind"] == "confirmatory":
            if verify_frozen() != self.rec["eval_code_sha256"] or load_protocol()["protocol_version"] != self.rec["protocol_version"]:
                raise RuntimeError("protocol or evaluation code changed since registration - confirmatory run refused")
        self.t0 = time.time(); self.rec.update(started_utc=utcnow(), code_version=_git(), environment={"python": platform.python_version()})
    def complete(self, metrics, outcome, result, outputs=None):
        assert outcome in OUTCOMES
        self.rec.update(status="PASS", outcome=outcome, metrics=metrics, result=result, outputs=outputs or {}, runtime_s=round(time.time() - self.t0, 1), finished_utc=utcnow()); return _write(self.rec)
    def fail(self, error, attempted, remaining):
        self.rec.update(status="FAIL", error=error, attempted=attempted, remaining=remaining, runtime_s=round(time.time() - self.t0, 1), finished_utc=utcnow()); return _write(self.rec)

def mark_pending_reason(eid, reason, needs): rec = load(eid); rec.update(not_run_reason=reason, needs=needs); return _write(rec)
def invalidate(eid, reason): rec = load(eid); rec.update(status="INVALID", invalid_reason=reason, invalidated_utc=utcnow()); return _write(rec)
