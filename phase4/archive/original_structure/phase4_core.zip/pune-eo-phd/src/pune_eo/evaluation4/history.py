"""Phase-4 whole-area historical tests: class areas per epoch, transition matrices, trajectory comparison with independent series,
and plausibility checks. A model that scores well on sampled pixels but produces impossible whole-area trajectories is rejected (protocol)."""
from __future__ import annotations
import numpy as np

def class_shares(label_map, classes, mask=None, nodata=0):
    a = np.asarray(label_map); m = (a != nodata) if mask is None else (mask & (a != nodata)); n = m.sum()
    return {c: float(((a == c) & m).sum() / n) if n else np.nan for c in classes}

def transition_matrix(map_t0, map_t1, classes, mask=None, nodata=0, normalise="row"):
    a, b = np.asarray(map_t0), np.asarray(map_t1); m = (a != nodata) & (b != nodata) if mask is None else mask & (a != nodata) & (b != nodata)
    T = np.array([[((a == i) & (b == j) & m).sum() for j in classes] for i in classes], float)
    if normalise == "row": T = T / np.clip(T.sum(1, keepdims=True), 1, None)
    elif normalise == "all": T = T / max(T.sum(), 1)
    return T

def compare_series(model, reference):
    """model, reference: {epoch: value} on common epochs -> MAE, bias, Pearson/Spearman correlation, sign agreement of changes."""
    ep = sorted(set(model) & set(reference)); x = np.array([model[e] for e in ep], float); y = np.array([reference[e] for e in ep], float)
    from scipy.stats import spearmanr, pearsonr
    dx, dy = np.diff(x), np.diff(y)
    return {"epochs": ep, "mae": float(np.mean(np.abs(x - y))), "bias": float(np.mean(x - y)),
            "pearson": float(pearsonr(x, y)[0]) if len(ep) > 2 and x.std() > 0 and y.std() > 0 else np.nan,
            "spearman": float(spearmanr(x, y)[0]) if len(ep) > 2 and x.std() > 0 and y.std() > 0 else np.nan,
            "change_sign_agreement": float(np.mean(np.sign(dx) == np.sign(dy))) if len(ep) > 1 else np.nan}

def built_plausibility(series, max_relative_decline=0.10):
    """Built-up land is quasi-irreversible at district scale: flags every consecutive-epoch decline larger than `max_relative_decline` of the earlier value.
    Returns the decline events and an implausibility index = summed relative declines beyond the tolerance."""
    ep = sorted(series); v = np.array([series[e] for e in ep], float); ev = []
    for i in range(1, len(v)):
        if v[i - 1] > 0 and (v[i - 1] - v[i]) / v[i - 1] > max_relative_decline: ev.append({"from": ep[i - 1], "to": ep[i], "relative_decline": float((v[i - 1] - v[i]) / v[i - 1])})
    return {"declines": ev, "implausibility_index": float(sum(e["relative_decline"] - max_relative_decline for e in ev)), "plausible": not ev}
