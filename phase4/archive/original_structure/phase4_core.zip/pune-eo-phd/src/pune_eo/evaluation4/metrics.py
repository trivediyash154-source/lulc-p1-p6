"""Phase-4 frozen evaluation metrics. Pure functions, no I/O. Labels are integer class codes; `classes` fixes the class order.
Rules fixed here (configs/phase4_evaluation_protocol.yaml):
  * macro averages are taken over classes PRESENT in the reference (n_ref > 0) - an absent class never enters a macro mean (Phase-3 defect);
  * abstentions are passed as label `abstain` (default -1) and are excluded from accuracy, but always reported as coverage;
  * stratified area/accuracy estimation follows the Olofsson et al. (2014) estimators for a stratified random sample with map-class strata
    (generalised: strata need not equal map classes, weights = stratum area share / stratum sample size)."""
from __future__ import annotations
import numpy as np

def confusion(y_ref, y_map, classes, weights=None):
    """rows = reference, cols = map. weights: optional per-sample weights."""
    y_ref, y_map = np.asarray(y_ref), np.asarray(y_map); w = np.ones(len(y_ref)) if weights is None else np.asarray(weights, float)
    idx = {c: i for i, c in enumerate(classes)}; M = np.zeros((len(classes), len(classes)))
    for r, m, ww in zip(y_ref, y_map, w):
        if r in idx and m in idx: M[idx[r], idx[m]] += ww
    return M

def per_class(M, classes):
    tp = np.diag(M); ref = M.sum(1); mp = M.sum(0)
    out = {}
    for i, c in enumerate(classes):
        prec = tp[i] / mp[i] if mp[i] > 0 else np.nan; rec = tp[i] / ref[i] if ref[i] > 0 else np.nan
        f1 = 2 * tp[i] / (ref[i] + mp[i]) if (ref[i] + mp[i]) > 0 else np.nan; iou = tp[i] / (ref[i] + mp[i] - tp[i]) if (ref[i] + mp[i] - tp[i]) > 0 else np.nan
        out[c] = {"n_ref": float(ref[i]), "n_map": float(mp[i]), "precision_users": prec, "recall_producers": rec, "f1": f1, "iou": iou}
    return out

def summary(y_ref, y_map, classes, weights=None, abstain=-1):
    """accuracy, macro-F1 / macro-IoU over present classes, per-class table, coverage (share not abstained)."""
    y_ref, y_map = np.asarray(y_ref), np.asarray(y_map); keep = y_map != abstain; cov = float(keep.mean()) if len(keep) else np.nan
    w = None if weights is None else np.asarray(weights, float)[keep]
    M = confusion(y_ref[keep], y_map[keep], classes, w); pc = per_class(M, classes); present = [c for c in classes if pc[c]["n_ref"] > 0]
    tot = M.sum()
    return {"n": int(keep.sum()), "coverage": cov, "accuracy": float(np.trace(M) / tot) if tot > 0 else np.nan,
            "macro_f1_present": float(np.nanmean([pc[c]["f1"] for c in present])) if present else np.nan,
            "macro_iou_present": float(np.nanmean([pc[c]["iou"] for c in present])) if present else np.nan,
            "classes_present": present, "per_class": pc, "confusion": M.tolist()}

def stratified_estimates(y_ref, y_map, strata, stratum_area, classes):
    """Olofsson et al. (2014)-type estimators for a stratified random sample.
    strata: stratum id per sample; stratum_area: {stratum: area (or pixel count) of the stratum in the population}.
    Returns overall accuracy, user's / producer's accuracy and reference-class area proportion, each with a standard error."""
    y_ref, y_map, strata = map(np.asarray, (y_ref, y_map, strata)); A = float(sum(stratum_area.values()))
    hs = [h for h in stratum_area if (strata == h).any()]; W = {h: stratum_area[h] / A for h in hs}; n = {h: int((strata == h).sum()) for h in hs}
    def est(z):          # stratified mean of indicator z and its variance
        m = sum(W[h] * z[strata == h].mean() for h in hs)
        v = sum(W[h] ** 2 * (z[strata == h].var(ddof=1) / n[h] if n[h] > 1 else 0.0) for h in hs); return m, v
    oa, voa = est((y_ref == y_map).astype(float)); out = {"overall_accuracy": oa, "overall_accuracy_se": float(np.sqrt(voa)), "classes": {}}
    for k in classes:
        p_ref, v_ref = est((y_ref == k).astype(float))                                  # area proportion of reference class k
        # ratio estimators (users = P(ref=k | map=k), producers = P(map=k | ref=k)) with linearised variance
        def ratio(num, den):
            Rh = num.astype(float); Dh = den.astype(float)
            Y = sum(W[h] * Rh[strata == h].mean() for h in hs); X = sum(W[h] * Dh[strata == h].mean() for h in hs)
            if X == 0: return np.nan, np.nan
            r = Y / X; e = Rh - r * Dh
            v = sum(W[h] ** 2 * (e[strata == h].var(ddof=1) / n[h] if n[h] > 1 else 0.0) for h in hs) / X ** 2; return float(r), float(np.sqrt(v))
        ua, ua_se = ratio((y_ref == k) & (y_map == k), y_map == k); pa, pa_se = ratio((y_ref == k) & (y_map == k), y_ref == k)
        out["classes"][k] = {"area_proportion": float(p_ref), "area_proportion_se": float(np.sqrt(v_ref)), "area": float(p_ref * A), "area_se": float(np.sqrt(v_ref) * A),
                             "users_accuracy": ua, "users_se": ua_se, "producers_accuracy": pa, "producers_se": pa_se}
    return out

def selective(conf, correct, coverages=(0.5, 0.7, 0.8, 0.9, 1.0)):
    """Risk-coverage: keep the most confident fraction; accuracy at fixed coverages and area under the risk-coverage curve (AURC, lower = better)."""
    conf, correct = np.asarray(conf, float), np.asarray(correct, bool); o = np.argsort(-conf, kind="stable"); c = correct[o]
    n = len(c); acc_k = np.cumsum(c) / np.arange(1, n + 1); risk = 1 - acc_k
    at = {f"{cv:.2f}": float(acc_k[max(1, int(np.ceil(cv * n))) - 1]) for cv in coverages}
    return {"accuracy_at_coverage": at, "aurc": float(risk.mean()), "base_accuracy": float(c.mean())}

def abstain_by_threshold(p, tau):
    """predicted class (argmax, 1-based index into columns) or -1 where max probability < tau."""
    p = np.asarray(p); lab = p.argmax(1) + 1; return np.where(p.max(1) >= tau, lab, -1)
