"""Phase-4 frozen statistics: bootstrap CIs (stratified for designed samples, spatial-block for maps), paired differences, seed summaries,
Benjamini-Hochberg FDR. Fixed defaults are the protocol values (configs/phase4_evaluation_protocol.yaml)."""
from __future__ import annotations
import numpy as np

def _ci(vals, alpha=0.05): lo, hi = np.nanpercentile(vals, [100 * alpha / 2, 100 * (1 - alpha / 2)]); return float(lo), float(hi)

def stratified_bootstrap(stat, strata, n=2000, seed=20261110, alpha=0.05):
    """stat(index_array) -> scalar; resamples WITHIN each stratum (design-consistent for stratified random samples)."""
    strata = np.asarray(strata); rng = np.random.default_rng(seed); groups = [np.flatnonzero(strata == s) for s in np.unique(strata)]
    point = stat(np.arange(len(strata))); bs = np.array([stat(np.concatenate([rng.choice(g, len(g)) for g in groups])) for _ in range(n)])
    lo, hi = _ci(bs, alpha); return {"estimate": float(point), "ci": [lo, hi], "n_boot": n, "unit": "sample within stratum"}

def block_bootstrap(stat, blocks, n=2000, seed=20261110, alpha=0.05):
    """stat(index_array) -> scalar; resamples whole spatial blocks with replacement."""
    blocks = np.asarray(blocks); rng = np.random.default_rng(seed); ub, inv = np.unique(blocks, return_inverse=True); mem = [np.flatnonzero(inv == i) for i in range(len(ub))]
    point = stat(np.arange(len(blocks))); bs = []
    for _ in range(n): bs.append(stat(np.concatenate([mem[i] for i in rng.integers(0, len(ub), len(ub))])))
    lo, hi = _ci(np.array(bs), alpha); return {"estimate": float(point), "ci": [lo, hi], "n_boot": n, "n_blocks": int(len(ub)), "unit": "spatial block"}

def paired_difference(stat_a, stat_b, resample="block", groups=None, **kw):
    """Difference stat_a - stat_b computed on the SAME resampled units; excludes_zero flag."""
    f = (lambda i: stat_a(i) - stat_b(i)); r = (block_bootstrap if resample == "block" else stratified_bootstrap)(f, groups, **kw)
    r["excludes_zero"] = bool(r["ci"][0] > 0 or r["ci"][1] < 0); return r

def seed_summary(values, alpha=0.05):
    """mean, median, sd, min, max and a t-interval for the mean across random seeds."""
    v = np.asarray(values, float); k = len(v)
    from scipy.stats import t
    half = t.ppf(1 - alpha / 2, k - 1) * v.std(ddof=1) / np.sqrt(k) if k > 1 else np.nan
    return {"n_seeds": k, "mean": float(v.mean()), "median": float(np.median(v)), "sd": float(v.std(ddof=1)) if k > 1 else np.nan, "min": float(v.min()), "max": float(v.max()),
            "ci_mean": [float(v.mean() - half), float(v.mean() + half)] if k > 1 else [np.nan, np.nan]}

def bh_fdr(pvals, q=0.05):
    """Benjamini-Hochberg: returns adjusted p-values (q-values) and rejection flags at level q."""
    p = np.asarray(pvals, float); m = len(p); o = np.argsort(p); ranked = p[o] * m / np.arange(1, m + 1)
    adj = np.minimum.accumulate(ranked[::-1])[::-1]; adj = np.clip(adj, 0, 1); out = np.empty(m); out[o] = adj
    return {"q_values": out.tolist(), "reject": (out <= q).tolist(), "q": q}

def bootstrap_p_two_sided(diff_samples):
    """two-sided bootstrap p-value for H0: difference = 0 (share of resamples on the other side of zero, doubled)."""
    d = np.asarray(diff_samples, float); return float(min(1.0, 2 * min((d <= 0).mean(), (d >= 0).mean())))

def stratified_block_bootstrap(stat, strata, blocks, n=2000, seed=20261110, alpha=0.05):
    """Cluster-aware design bootstrap (protocol v2): within each stratum, resample whole spatial blocks (primary sampling units) with replacement,
    keeping all sample points of a drawn block. Accounts for several points sharing a 6 km block (clustering), which a point-level bootstrap ignores."""
    strata, blocks = np.asarray(strata), np.asarray(blocks); rng = np.random.default_rng(seed)
    groups = []
    for s in np.unique(strata):
        idx = np.flatnonzero(strata == s); ub = np.unique(blocks[idx]); groups.append([idx[blocks[idx] == b] for b in ub])
    point = stat(np.arange(len(strata))); bs = []
    for _ in range(n): bs.append(stat(np.concatenate([np.concatenate([g[i] for i in rng.integers(0, len(g), len(g))]) for g in groups])))
    lo, hi = _ci(np.array(bs), alpha); return {"estimate": float(point), "ci": [lo, hi], "n_boot": n, "unit": "block within stratum", "n_psu": int(sum(len(g) for g in groups))}
