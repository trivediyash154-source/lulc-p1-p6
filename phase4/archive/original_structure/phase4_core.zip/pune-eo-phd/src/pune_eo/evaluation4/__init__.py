"""Phase-4 frozen evaluation package. The SHA-256 of these modules is recorded in configs/phase4_evaluation_protocol.yaml at freeze time;
confirmatory runs refuse to execute if the code has changed since (pune_eo.evaluation4.protocol.verify_frozen)."""
