"""Monthly Sentinel-2 + Sentinel-1 time series on the 30 m windows, and temporal deep-learning classifiers.

Channels per month: S2 NDVI, NDMI (B8A/B11), NDRE (B8A/B05), MNDWI (B03/B11), S1 VV dB, VH dB (S2 native Sen2Cor reflectance:
S2-only models need no S2->OLI transform). Missing month (cloud, no acquisition) -> NaN in the stack; models receive the
standardised value with 0 filled AND a per-channel-group observation mask, so a gap is never presented as a measurement.
Models: TempCNN (Pelletier et al. 2019), LSTM, Transformer encoder (masked attention over missing months)."""
from __future__ import annotations
import numpy as np, rasterio
from .. import config

CH = ["ndvi", "ndmi", "ndre", "mndwi", "vv_db", "vh_db"]

def _nd(a, b):
    with np.errstate(all="ignore"): return (a - b) / (a + b)

def monthly_stack(gid: str, year: int) -> tuple[np.ndarray, dict]:
    """(12, len(CH), H, W) float32 with NaN for missing; info on availability."""
    base = config.path("data", "composites", gid, str(year)); out = None; info = {}
    for m in range(1, 13):
        p2 = base / "sentinel2" / "monthly" / f"{year}-{m:02d}" / "optical_composite.tif"
        p1 = base / "sentinel1" / "monthly" / f"{year}-{m:02d}" / "backscatter_median_db.tif"
        if out is None:
            ref = p2 if p2.exists() else p1
            with rasterio.open(ref) as s: H, W = s.height, s.width
            out = np.full((12, len(CH), H, W), np.nan, np.float32)
        if p2.exists():
            with rasterio.open(p2) as s:
                a = s.read().astype(np.float32); d = list(s.descriptions)
            a[a == -32768] = np.nan; a /= 10000.0; b = {k: a[d.index(k)] for k in d}
            out[m - 1, 0] = _nd(b["nir08"], b["red"]); out[m - 1, 1] = _nd(b["nir08"], b["swir16"])
            out[m - 1, 2] = _nd(b["nir08"], b["re1"]); out[m - 1, 3] = _nd(b["green"], b["swir16"])
        if p1.exists():
            with rasterio.open(p1) as s:
                a = s.read().astype(np.float32); d = [x.lower() for x in s.descriptions]
            a[(a == -9999) | ~np.isfinite(a)] = np.nan
            for k, j in (("vv", 4), ("vh", 5)):
                hit = [i for i, x in enumerate(d) if k in x]
                if hit: out[m - 1, j] = a[hit[0]]
        info[m] = {"s2": p2.exists(), "s1": p1.exists()}
    out[~np.isfinite(out)] = np.nan
    return out, info

# ----------------------------------------------------------------- deep models (PyTorch, CPU)
def _torch():
    import torch, torch.nn as nn
    return torch, nn

def build(name: str, n_ch: int, n_cls: int, T: int = 12):
    torch, nn = _torch()
    class TempCNN(nn.Module):
        def __init__(s, h=64, k=5, p=0.2):
            super().__init__()
            L = []
            for i in range(3): L += [nn.Conv1d(n_ch if i == 0 else h, h, k, padding=k // 2), nn.BatchNorm1d(h), nn.ReLU(), nn.Dropout(p)]
            s.f = nn.Sequential(*L); s.head = nn.Sequential(nn.Flatten(), nn.Linear(h * T, 128), nn.ReLU(), nn.Dropout(p), nn.Linear(128, n_cls))
        def forward(s, x, m=None): return s.head(s.f(x.transpose(1, 2)))
    class LSTM(nn.Module):
        def __init__(s, h=64, p=0.2):
            super().__init__(); s.r = nn.LSTM(n_ch, h, num_layers=1, batch_first=True); s.drop = nn.Dropout(p); s.head = nn.Linear(h, n_cls)
        def forward(s, x, m=None): o, _ = s.r(x); return s.head(s.drop(o[:, -1]))
    class Transformer(nn.Module):
        def __init__(s, d=64, heads=4, layers=2, p=0.2):
            super().__init__(); s.inp = nn.Linear(n_ch, d); s.pos = nn.Parameter(torch.randn(1, T, d) * 0.02)
            s.enc = nn.TransformerEncoder(nn.TransformerEncoderLayer(d, heads, 2 * d, p, batch_first=True), layers); s.head = nn.Linear(d, n_cls)
        def forward(s, x, m=None):
            pad = None if m is None else ~(m.any(-1))                         # month with no observation at all -> masked
            if pad is not None: pad = pad & ~pad.all(1, keepdim=True)          # never mask every step
            z = s.enc(s.inp(x) + s.pos, src_key_padding_mask=pad)
            if pad is not None: w = (~pad).float().unsqueeze(-1); return s.head((z * w).sum(1) / w.sum(1).clamp(min=1))
            return s.head(z.mean(1))
    return {"tempcnn": TempCNN, "lstm": LSTM, "transformer": Transformer}[name]()

def prepare(X: np.ndarray, stats=None):
    """X (N, T, C) with NaN -> standardised, NaN->0, plus mask (N, T, C_groups) and concatenated input (N, T, C + groups)."""
    if stats is None: stats = (np.nanmean(X, axis=(0, 1)), np.nanstd(X, axis=(0, 1)) + 1e-6)
    Z = (X - stats[0]) / stats[1]; m = np.isfinite(Z); Z = np.where(m, Z, 0.0)
    grp = np.stack([m[..., :4].all(-1), m[..., 4:].all(-1)], -1)              # S2 observed, S1 observed
    return np.concatenate([Z, grp.astype(np.float32)], -1).astype(np.float32), grp, stats

def train(name, Xtr, ytr, Xva, yva, n_cls, seed=0, epochs=30, patience=5, lr=1e-3, bs=512, threads=2):
    torch, nn = _torch(); torch.manual_seed(seed); np.random.seed(seed); torch.set_num_threads(threads)
    net = build(name, Xtr.shape[-1], n_cls, Xtr.shape[1]); opt = torch.optim.Adam(net.parameters(), lr=lr, weight_decay=1e-4)
    w = torch.tensor(len(ytr) / (n_cls * np.bincount(ytr, minlength=n_cls).clip(1)), dtype=torch.float32)
    lossf = nn.CrossEntropyLoss(weight=w); Xt, yt = torch.tensor(Xtr), torch.tensor(ytr); Xv, yv = torch.tensor(Xva), torch.tensor(yva)
    best, best_state, bad, hist = np.inf, None, 0, []
    for ep in range(epochs):
        net.train(); perm = torch.randperm(len(yt))
        for i in range(0, len(yt), bs):
            b = perm[i:i + bs]; opt.zero_grad(); l = lossf(net(Xt[b], Xt[b][..., -2:] > 0.5), yt[b]); l.backward(); opt.step()
        net.eval()
        with torch.no_grad(): vl = float(lossf(net(Xv, Xv[..., -2:] > 0.5), yv))
        hist.append(vl)
        if vl < best - 1e-4: best, bad, best_state = vl, 0, {k: v.clone() for k, v in net.state_dict().items()}
        else:
            bad += 1
            if bad >= patience: break
    net.load_state_dict(best_state); return net, hist

def predict_proba(net, X, bs=4096, mc_dropout: int = 0):
    torch, _ = _torch(); out = []
    if mc_dropout: net.train()
    else: net.eval()
    with torch.no_grad():
        for i in range(0, len(X), bs):
            xb = torch.tensor(X[i:i + bs]); mb = xb[..., -2:] > 0.5
            if mc_dropout: out.append(torch.stack([torch.softmax(net(xb, mb), -1) for _ in range(mc_dropout)]).numpy())
            else: out.append(torch.softmax(net(xb, mb), -1).numpy())
    return np.concatenate(out, axis=1 if mc_dropout else 0)
