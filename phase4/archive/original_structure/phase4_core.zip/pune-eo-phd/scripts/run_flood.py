"""Flood module (registry EXP-FLD-001): monsoon SAR open-water frequency 2017-2025, exposure overlay, CHIRPS cross-check.
HAZARD proxy  = frequency of observed non-permanent open water in Jun-Oct S1 acquisitions (slope<=5, HAND<=20 m)
EXPOSURE      = built-up (2021 map, EXP-LULC-T-001 raw; and GHSL 2020 built fraction, independent) and agriculture in frequently wet cells
VULNERABILITY = NOT assessed (no socio-economic data) - so no 'risk' map is produced.
Event mapping for the cited 2019-09-25 / 2024-07-25 events: NOT POSSIBLE (no S1 acquisition in the event windows; Phase-1 event reports)."""
import json, sys, warnings
import numpy as np, pandas as pd, rasterio, xarray as xr
from scipy.stats import spearmanr
sys.path.insert(0, "src"); warnings.filterwarnings("ignore")
from pune_eo import config
from pune_eo.flood import sar_frequency as SF
from pune_eo.io import write_cog
from pune_eo.modelling.registry import Experiment
from rasterio.warp import transform_bounds
WN = sys.argv[1].split(",") if len(sys.argv) > 1 else ["khadakwasla_mutha", "baramati_agri", "mulshi_ghats"]
out = config.path("results/flood"); out.mkdir(parents=True, exist_ok=True)
e = Experiment(experiment_id="EXP-FLD-001", research_question="RQ-F: Where is open water repeatedly observed during the monsoon outside permanent water bodies, and what is exposed there?",
               hypothesis="repeated monsoon open water concentrates on low-HAND floodplain cells; built-up exposure is under-observed (double bounce)",
               dataset_version="Sentinel-1 RTC (PC), G30 windows; JRC GSW v1.3; Copernicus GLO-30 HAND", years=list(range(2017, 2026)), resolution_m=30,
               features=["VV dB", "VH dB"], labels="calibration: JRC permanent water (>=90 %) vs JRC 0", split="n/a", model="per-acquisition Otsu thresholds (clipped)",
               hyperparameters={"months": [6, 7, 8, 9, 10], "vv_clip": [-22, -12], "vh_clip": [-28, -18], "slope_max": 5, "hand_max": 20}, seed=0)
with rasterio.open(config.path("data/processed/climate/chirps_v2_monthly_stack.tif")) as s:
    CH = s.read().astype(float); CH[CH < 0] = np.nan; desc = list(s.descriptions); ctr = s.transform; ccrs = s.crs
res = {}
for w in WN:
    r = SF.run(w); gid = r["grid"].id; L = r["log"]; L.to_csv(out / f"s1_acquisitions_{gid}.csv", index=False)
    yrs = sorted(r["freq"]); F = np.stack([r["freq"][y] for y in yrs]); Nv = np.stack([r["nval"][y] for y in yrs]).astype(float)
    tot = np.nansum(F * Nv, 0) / np.maximum(Nv.sum(0), 1); tot = np.where(Nv.sum(0) > 0, tot, np.nan)
    tot_np = np.where(r["perm"], np.nan, tot)
    write_cog(out / f"monsoon_open_water_frequency_{gid}.tif", np.nan_to_num(np.stack([tot_np] + [np.where(r["perm"], np.nan, f) for f in F]), nan=-1).astype(np.float32),
              r["grid"], nodata=-1, dtype="float32", descriptions=["freq_2017_2025"] + [f"freq_{y}" for y in yrs])
    try:
        P = xr.open_zarr(config.path("data/products/lulc", f"{gid}.zarr")); lc21 = P.raw_label.sel(year=2021).values
    except Exception: lc21 = None
    with rasterio.open(config.path("data/labels", gid, "ghsl_built_fraction_90m.tif")) as s: gh = s.read(7).astype(float)
    H, Wd = tot.shape; gh3 = np.pad(np.repeat(np.repeat(gh, 3, 0), 3, 1), ((0, max(0, H - 3 * gh.shape[0])), (0, max(0, Wd - 3 * gh.shape[1]))), constant_values=np.nan)[:H, :Wd]
    with rasterio.open(config.path("data/features/terrain", gid, "terrain.tif")) as s: t = s.read(); dsc = list(s.descriptions)
    hand = t[dsc.index("hand_m")]
    ok = L[L.status == "ok"]; wet = np.isfinite(tot_np) & (tot_np >= 0.25)
    rr = {"acquisitions_ok": int(len(ok)), "acquisitions_low_coverage": int((L.status == "low_coverage").sum()), "read_errors": int(L.status.str.startswith("read_error").sum()),
          "perm_water_recall_median": float(ok.perm_water_recall.median()) if len(ok) and ok.perm_water_recall.notna().any() else None,
          "land_false_rate_median": float(ok.land_false_rate.median()) if len(ok) and ok.land_false_rate.notna().any() else None,
          "cells_freq_ge_0.25_km2": float(wet.sum() * 0.0009), "hand_median_wet_cells_m": float(np.nanmedian(hand[wet])) if wet.any() else None,
          "hand_median_all_masked_cells_m": float(np.nanmedian(hand[r["mask"]])),
          "exposure": {"built_2021_map_km2": float((wet & (lc21 == 1)).sum() * 0.0009) if lc21 is not None else None,
                       "agriculture_2021_map_km2": float((wet & (lc21 == 2)).sum() * 0.0009) if lc21 is not None else None,
                       "ghsl2020_built_surface_km2": float(np.nansum(np.where(wet, gh3, 0)) * 0.0009)}}
    # CHIRPS monthly cross-check: monthly sum of non-permanent water detections vs monthly rain
    x0, y0, x1, y1 = r["grid"].bounds; lo0, la0, lo1, la1 = transform_bounds("EPSG:32643", ccrs, x0, y0, x1, y1)
    c0, r0 = ~ctr * (lo0, la1); c1, r1 = ~ctr * (lo1, la0)
    rain = pd.Series(np.nanmean(CH[:, int(np.floor(r0)):int(np.ceil(r1)), int(np.floor(c0)):int(np.ceil(c1))], axis=(1, 2)), index=[d[-7:] for d in desc])
    if len(ok):
        ok = ok.assign(ym=ok.date.astype(str).str[:7]); mm = ok.groupby("ym").water_px_nonperm_masked.mean()
        rv = rain.reindex(mm.index); f = rv.notna()
        rr["rho_monthly_wet_area_vs_rain"] = (float(spearmanr(mm[f], rv[f])[0]), int(f.sum())) if f.sum() >= 8 else (None, int(f.sum()))
    res[gid] = rr; print(gid, json.dumps(rr), flush=True)
json.dump(res, open(out / f"flood_summary_{'_'.join(WN)}.json", "w"), indent=1, default=str)
e.finish(res, result="hazard proxy + exposure; no risk map (vulnerability not assessed); no event maps (no acquisitions in event windows)",
         outputs={"frequency": "results/flood/monsoon_open_water_frequency_<grid>.tif"})
