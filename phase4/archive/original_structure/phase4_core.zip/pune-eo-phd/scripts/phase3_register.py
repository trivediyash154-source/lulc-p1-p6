"""Pre-register the Phase-3 experiment matrix (status PENDING) BEFORE any Phase-3 model is trained.
Writes configs/phase3_experiments.yaml (the definitions) and experiments/registry3/*.json (pre-registration records)."""
import sys, yaml
sys.path.insert(0, "src")
from pune_eo import config
from pune_eo.validation import registry3 as R3

W3 = ["khadakwasla_mutha", "baramati_agri", "mulshi_ghats"]
HET = "het_v1: sampled cells x years 1990-2026 (Landsat 23 features, terrain 12, S1 7 for 2017-2025, climate context); built by scripts/build_het.py"
SIL = "silver_l1 2021 (Tier C)"; SPL = "3 km hashed blocks: train"; VAL = "3 km blocks: val"; TST = "3 km blocks: test"
M_HIST = ["false built-up rate on never-settled TEST cells by year/era/climate class", "stable-built recall", "deep-water recall", "macro-F1 silver test 2021", "paired block-bootstrap CI"]
M_CLS = ["macro-F1", "per-class F1", "per-class IoU", "ECE", "Brier", "confusion matrix (agri<->natveg, agri<->built)", "paired block-bootstrap CI"]
E = []
def add(eid, group, hyp, reason, features, model, labels=SIL, tier="C", years="2021", region="3 windows", train=SPL, val=VAL, test=TST, metrics=M_CLS, hp=None, seed=20261020):
    E.append(dict(experiment_id=eid, group=group, hypothesis=hyp, reason=reason, dataset_version=HET, region=region, years=years, features=features, labels=labels,
                  label_tier=tier, model=model, training_split=train, validation_split=val, test_split=test, seed=seed, hyperparameters=hp or {}, metrics_planned=metrics))
# ---- A: reference validation of the 2021 model (Phase-2 best: XGB Landsat+terrain; and RF for comparability)
add("P3-A1", "A reference validation", "high agreement with silver reference products on held-out blocks", "re-state the 0.979 with IoU and calibration", "landsat_terrain (28)", "XGBoost (Phase-2 config) + RF")
add("P3-A1b", "A reference validation", "agreement with INDEPENDENT Tier-B products for the classes they cover (built: WSF 2015 / GHSL 2020; water: JRC) is lower than with silver", "silver = easy pure cells; Tier B covers mixed cells", "landsat_terrain", "same model", labels="WSF-Evolution, GHSL R2023A, JRC GSW (Tier B)", tier="B", test="all TEST-block cells")
add("P3-A2", "A reference validation", "agreement with independent human gold interpretation", "Tier-A validation of the 2021 map", "landsat_terrain", "same model", labels="gold sample (Tier A, human VHR)", tier="A", test="558 gold points (test blocks)")
add("P3-A2p", "A reference validation", "agreement with a provisional, blind AI visual interpretation of Sentinel-2 10 m chips is lower than with silver (it includes mixed cells)", "independent-of-pipeline check while Tier A is pending; NEVER reported as gold", "landsat_terrain", "same model", labels="provisional AI visual interpretation of S2 10 m chips (Tier C)", tier="C", test="gold points, 2021 epoch")
add("P3-A3", "A reference validation", "agreement drops on an unseen landscape (leave-one-window-out)", "Phase-2 finding 0.57-0.82; restate with IoU/calibration", "landsat_terrain", "XGBoost/RF", train="2 windows train blocks", val="2 windows val blocks", test="held-out window, all silver cells")
add("P3-A4", "A reference validation", "agreement holds for an adjacent year (2020) but not for historical years (Tier-B built/water by epoch)", "temporal hold-out", "landsat_terrain", "XGBoost", years="train 2021; test 2020 (silver) + 1990-2015 (Tier B)", metrics=M_HIST + M_CLS)
# ---- B: temporal information (historical classification); factor: training labels 2021-only vs multi-year stable-segment (Tier D, training only)
FS_B = {"B1": "single-date: dry-season composite of year t (11 features)", "B2": "multi-date: B1 for t-1, t, t+1 (33)", "B3": "seasonal: dry + post-monsoon + seasonal amplitude of year t (16)",
        "B4": "temporal sequence: B3 for t-2..t+2 + 5-year robust statistics (89)"}
for k, f in FS_B.items():
    add(f"P3-{k}", "B temporal", f"{k} lowers historical false built-up vs B1 (B1 itself = baseline)" if k != "B1" else "baseline", "does temporal information reduce historical misclassification?", f, "Random Forest (300 trees)", years="train 2021; evaluate 1990-2026", metrics=M_HIST)
    add(f"P3-{k}m", "B temporal", f"{k} trained on multi-year stable-segment labels lowers dry-year false built-up vs the same features trained on 2021 only", "separates label-time diversity from feature-time context", f, "Random Forest",
        labels="silver 2021 extended along PELT change-free segments (Tier D, TRAINING ONLY)", tier="D(train)/B(test)", years="train 1990-2026 stable segments; evaluate 1990-2026", metrics=M_HIST)
add("P3-B5m", "B temporal", "adding drought context (SPI-12 of previous monsoon) to B4m lowers dry-year false built-up further", "does rainfall context resolve fallow/built confusion?", FS_B["B4"] + " + SPI-12(t-1)", "Random Forest",
    labels="as B4m (Tier D training only)", tier="D(train)/B(test)", years="train 1990-2026; evaluate 1990-2026", metrics=M_HIST)
add("P3-B4t", "B temporal", "terrain added to B4m changes historical false built-up", "terrain was a strong within-window feature in Phase 2", FS_B["B4"] + " + terrain (12)", "Random Forest", labels="as B4m", tier="D(train)/B(test)", years="1990-2026", metrics=M_HIST)
# ---- C: sensor fusion (S1 era)
FS_C = {"C1": "optical (B3, year t)", "C2": "SAR only (S1 annual: VV/VH dry, VH wet, ratio, VV min, VH sd)", "C3": "optical + SAR", "C4": "optical + SAR + DEM/terrain", "C5": "optical + SAR + DEM + environmental context (SPI-12 t-1, CHIRPS 1991-2020 mean annual rain)"}
for k, f in FS_C.items():
    add(f"P3-{k}", "C fusion", "fusion beats optical alone within-window, on unseen windows and in the S1-era dry year (2019)" if k != "C1" else "optical reference for C", "do SAR/DEM/context add information under identical splits?", f, "XGBoost (identical hyperparameters, seed)",
        labels="silver 2020+2021 (Tier C)", years="train 2020+2021; evaluate 2017-2025 (S1 availability) + LOWO", metrics=M_CLS + M_HIST)
# ---- D: drought robustness (evaluation strata over B and C models)
for k, c in (("D1", "normal"), ("D2", "dry"), ("D3", "wet")):
    add(f"P3-{k}", "D drought robustness", f"performance in {c} years (SPI-12 t-1 class) relative to normal years; temporal/SAR/context reduce the dry-year degradation", "Phase-2: false built-up tracks drought",
        "all B and C models", "evaluation stratum of B*/C* predictions", tier="B", years=f"{c} years per window (configs/phase3.yaml)", metrics=M_HIST)
# ---- E: spatial transfer
for k, (src, dst) in {"E1": ("khadakwasla_mutha", "baramati_agri"), "E2": ("baramati_agri", "mulshi_ghats"), "E3": ("mulshi_ghats", "khadakwasla_mutha"),
                      "E1r": ("baramati_agri", "khadakwasla_mutha"), "E2r": ("mulshi_ghats", "baramati_agri"), "E3r": ("khadakwasla_mutha", "mulshi_ghats")}.items():
    add(f"P3-{k}", "E spatial transfer", f"a model trained in {src} transfers to {dst} worse than within-window; temporal and SAR features reduce the gap", "single-source transfer matrix", "B1, B3, B4, C3, C4", "XGBoost", region=f"{src} -> {dst}",
        train=f"{src} train+val blocks", val=f"{src} val blocks", test=f"{dst} all silver cells")
add("P3-E4", "E spatial transfer", "two-source training transfers better than single-source", "multi-landscape training", "B1, B3, B4, C3, C4", "XGBoost", region="2 windows -> held-out window (x3)", train="2 windows train blocks", val="2 windows val blocks", test="held-out window")
# ---- F: advanced temporal AI (gated on B results)
for k, m in (("F1", "Temporal CNN"), ("F2", "GRU"), ("F3", "Temporal Transformer")):
    add(f"P3-{k}", "F temporal AI", f"{m} on the B4 sequence beats RF-B4 on historical false built-up and unseen-landscape macro-F1", "only if B4 > B1 (justification gate)", "B4 sequence (5 years x 16)", m, years="train 2021 (+ multi-year variant); evaluate 1990-2026, LOWO", metrics=M_HIST + M_CLS)
# ---- G: representation learning
add("P3-G1", "G representation", "supervised-from-scratch temporal encoder (reference for G2/G3)", "baseline for SSL", "annual sequence 1990-2026 (16 features/year)", "Transformer encoder from scratch", metrics=M_CLS + ["label fractions 10/25/50/100 %"])
add("P3-G2", "G representation", "masked-autoencoder pretraining on unlabelled pixels + linear probe matches G1 with fewer labels", "label scarcity / generalisation", "same", "MAE-pretrained encoder, frozen + linear head", labels="none for pretraining; silver 2021 for probe", metrics=M_CLS + ["label fractions"])
add("P3-G3", "G representation", "SSL pretraining + fine-tuning beats G1 on unseen windows at low label fractions", "label scarcity / generalisation", "same", "MAE-pretrained encoder, fine-tuned", labels="as G2", metrics=M_CLS + ["label fractions", "LOWO"])
# ---- H: uncertainty calibration on unseen landscapes
for k, m in (("H1", "uncalibrated"), ("H2", "temperature scaling / isotonic / Platt (fitted on source validation)"), ("H3", "5-member bootstrap ensemble"),
             ("H4", "conformal: LAC, APS, class-conditional; source-calibrated vs third-landscape-calibrated")):
    add(f"P3-{k}", "H uncertainty", "calibration and 90 % coverage hold on unseen landscapes" if k != "H1" else "reference", "Phase-2: 90 % sets covered only 42-74 % on unseen windows", "landsat_terrain (+S1 variant)", m,
        train="2 windows", val="2 windows val blocks (calibration)", test="held-out window", metrics=["ECE", "Brier", "NLL", "reliability diagram", "coverage", "set size"])
# ---- I: harmonisation validation
add("P3-I1", "I harmonisation", "s2_to_oli_v1 (fitted on the corridor) leaves |residual bias| < 0.01 reflectance in other windows, classes, seasons and years", "Phase-2 correction fitted on 19 corridor pairs only",
    "same-day S2/Landsat pairs in all 3 windows", "residual analysis + leave-one-window-out refit", labels="none", tier="NA", years="2019-2026", metrics=["residual bias/MAD per band by window, class, month, year, sun elevation", "NDVI bias"])
# ---- J: domain shift and adaptation
add("P3-J1", "J domain shift", "feature distributions differ between windows mainly in phenology (post-monsoon/seasonal amplitude) and terrain; shift predicts transfer error", "explain WHY transfer fails",
    "landsat_terrain (+S1)", "MMD, domain classifier, per-feature KS, class-conditional shift", labels="silver (class-conditional)", metrics=["MMD^2 with permutation p", "domain-classifier AUC", "KS ranking", "error vs domain probability"])
add("P3-J2", "J adaptation", "few target labels (25-250 per class) close most of the transfer gap; unsupervised CORAL / importance weighting close less", "minimal additional reference data",
    "landsat_terrain", "XGBoost: no adaptation, CORAL, importance weighting, self-training (Tier D), few-shot k in {10,25,50,100,250}", region="LOWO x3", train="2 windows (+k target train-block labels)", test="target test blocks")
# ---- K: change detection
add("P3-K1", "K change detection", "most Phase-2 timing misses come from gradual growth, sensor transitions, noisy series or uncertain reference years - not from the detector alone", "diagnose before trying new algorithms",
    "post/dry NDVI series", "failure decomposition of EXP-CP-001 breaks", labels="WSF first year + GHSL epochs (Tier B)", tier="B", years="1990-2026", metrics=["miss categories", "recall by category"])
add("P3-K2", "K change detection", "probabilistic change timing (posterior P(change in t)) is calibrated against WSF timing and gives honest credible intervals", "change should carry probability",
    "class posteriors (reconstruction) + BOCPD run-length posteriors", "HMM forward-backward transition posteriors; BOCPD", labels="WSF (Tier B)", tier="B", years="1990-2026", metrics=["coverage of 80 % timing intervals", "reliability of P(change within window)"])
# ---- L: label efficiency / active learning
add("P3-L1", "L label efficiency", "performance saturates below 100 % of training labels; SSL lowers the requirement", "how many labels are needed (silver as stand-in until gold exists)", "landsat_terrain; SSL embedding",
    "RF / XGBoost / SSL fine-tune", metrics=["macro-F1 vs label fraction 10/25/50/75/100 % (3 seeds)", "LOWO"])
add("P3-L2", "L active learning", "uncertainty/disagreement sampling reaches a target macro-F1 on a new landscape with fewer labels than random sampling", "prioritise human interpretation", "landsat_terrain", "XGBoost + entropy / margin / committee / random",
    region="LOWO x3 (simulation; silver as oracle)", metrics=["macro-F1 vs annotation budget"])
# ---- M: agriculture state framework
add("P3-M1", "M agriculture", "an agricultural STATE framework (cropland probability, seasonal activity, irrigation-likelihood proxy) can be produced with OBSERVED/INFERRED/PROXY tags; crop TYPE cannot (no labels)", "do not overclaim crops",
    "S2/S1 monthly, Landsat seasonal", "rule-based proxies + model probabilities", labels="none (crop labels absent)", tier="NA", metrics=["coverage", "proxy definitions", "consistency with rainfall (association)"])
add("P3-M2", "M agriculture", "10 m Sentinel-2 + S1 phenology separates cropping regimes better than 30 m (silhouette)", "Phase-2: not separable at 30 m (silhouette 0.13)", "S2 10 m monthly NDVI + S1 VH", "k-means silhouette 10 m vs 30 m, same cells",
    region="baramati_agri", labels="none", tier="NA", years="2021", metrics=["silhouette by k", "cluster stability (bootstrap ARI)"])
add("P3-M3", "M agriculture", "official agricultural statistics can serve as an independent area-level reference", "independent agricultural reference search", "district crop statistics", "comparison of mapped cropland area with official net sown area", labels="official statistics (Tier B if obtained)", tier="B", metrics=["availability", "area agreement"])
# ---- N: flood (inventory only)
add("P3-N1", "N flood", "historical flood events have usable S1 pre/event/post acquisitions", "do not model floods without observations", "S1 acquisition dates vs cited event dates", "inventory", labels="cited event reports", tier="B", metrics=["events with acquisitions within -1..+3 days"])
# ---- O: products and synthesis
add("P3-O1", "O reconstruction", "an era-aware probabilistic annual reconstruction (probabilities, uncertainty, observation quality, transition probability) can be produced; defensibility decided by Gate 6", "Phase-3 product",
    "selected model", "selected by multi-criteria table", tier="B (evaluation)", years="1990-2026", metrics=["Tier-B agreement by era", "entropy by era", "Gate 6"])
add("P3-O2", "O synthesis", "errors can be attributed to a taxonomy (sensor/QA, seasonal, drought, ambiguity, spatial/temporal transfer, label, model)", "where models fail", "all evaluated predictions", "rule-based attribution", tier="B/C", metrics=["error share by category"])
add("P3-O3", "O synthesis", "district-wide scaling of the selected workflow", "only after gates", "selected", "selected", region="Pune district (15,643 km2)", tier="B", years="2021 (+ history if Gate 6)", metrics=["coverage", "runtime"])
yaml.safe_dump({"experiments": E}, open(config.path("configs/phase3_experiments.yaml"), "w"), sort_keys=False, width=200)
n = 0
for spec in E:
    old = R3.load(spec["experiment_id"])
    if old and old["status"] != "PENDING": continue
    R3.register(**spec); n += 1
print(f"{len(E)} experiments defined; {n} pre-registered PENDING")
