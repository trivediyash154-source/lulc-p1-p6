"""Reproducibility audit: regenerate delivered sample products from the immutable manifests."""
import json, logging, sys
logging.basicConfig(level=logging.WARNING)
from pune_eo.compositing.engine import run_year
from pune_eo.compositing.windows import resolve
for grid, window, years in [("G240", "district", [1990, 2005, 2025]), ("G30", "khadakwasla_mutha", [1990, 2026])]:
    g, w, wn = resolve(grid, window)
    for y in years:
        r = run_year("landsat", y, g, window=w, window_name=wn, threads=10)
        print(json.dumps({k: r.get(k) for k in ("job_id", "status", "seconds", "n_items", "n_failed")}), flush=True)
