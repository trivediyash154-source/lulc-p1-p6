"""Fit the Sentinel-2 (Sen2Cor L2A) -> Landsat-OLI (LaSRC C2 L2, local_pune_g30_v2) per-band linear transform
from same-day pairs (|dt| < 15 min) on the G30 corridor window; leave-one-PAIR-out evaluation.
Inputs : results/audit/same_day_pixel_samples.pkl (scripts/same_day_pairs.py)
Outputs: results/harmonization/s2_to_oli_v1.yaml, results/audit/s2_to_oli_lopo.csv"""
import pickle, sys, json
import numpy as np, pandas as pd, yaml
sys.path.insert(0, "src")
from pune_eo.provenance import utcnow

BANDS = ["blue", "green", "red", "nir08", "swir16", "swir22"]
pairs = pickle.load(open("results/audit/same_day_pixel_samples.pkl", "rb"))
for p in pairs:   # arrays are (6, n) in BANDS order (scripts/same_day_pairs.py: B)
    p["L"] = {b: p["L"][i].astype(np.float64) for i, b in enumerate(BANDS)}
    p["S"] = {b: p["S"][i].astype(np.float64) for i, b in enumerate(BANDS)}

def stack(ps, b):
    L = np.concatenate([p["L"][b] for p in ps]); S = np.concatenate([p["S"][b] for p in ps])
    m = np.isfinite(L) & np.isfinite(S) & (L > 0) & (S > 0) & (L < 1) & (S < 1)
    return S[m], L[m]

def rma(x, y):
    """Reduced-major-axis (symmetric; neither sensor is error-free) with robust trimming of |resid| > 3 MAD."""
    for _ in range(2):
        b = np.sign(np.corrcoef(x, y)[0, 1]) * np.std(y) / np.std(x); a = np.mean(y) - b * np.mean(x)
        r = y - (a + b * x); mad = 1.4826 * np.median(np.abs(r - np.median(r)))
        keep = np.abs(r - np.median(r)) < 3 * mad; x, y = x[keep], y[keep]
    return float(b), float(a)

def ndvi(d): return (d["nir08"] - d["red"]) / (d["nir08"] + d["red"])

rows = []
for i, held in enumerate(pairs):
    train = [p for j, p in enumerate(pairs) if j != i]
    coef = {b: rma(*stack(train, b)) for b in BANDS}
    adj = {}
    for b in BANDS:
        S, L = held["S"][b], held["L"][b]
        adj[b] = coef[b][0] * S + coef[b][1]
        m = np.isfinite(S) & np.isfinite(L)
        rows.append({"held_out": held["date"], "pb": held["pb"], "band": b, "n": int(m.sum()),
                     "bias_before": float(np.median(S[m] - L[m])), "bias_after": float(np.median(adj[b][m] - L[m])),
                     "mad_before": float(np.median(np.abs(S[m] - L[m]))), "mad_after": float(np.median(np.abs(adj[b][m] - L[m])))})
    nb, na, nl = ndvi(held["S"]), ndvi(adj), ndvi(held["L"]); m = np.isfinite(nb) & np.isfinite(nl) & np.isfinite(na)
    rows.append({"held_out": held["date"], "pb": held["pb"], "band": "ndvi", "n": int(m.sum()),
                 "bias_before": float(np.median(nb[m] - nl[m])), "bias_after": float(np.median(na[m] - nl[m])),
                 "mad_before": float(np.median(np.abs(nb[m] - nl[m]))), "mad_after": float(np.median(np.abs(na[m] - nl[m])))})
df = pd.DataFrame(rows); df.to_csv("results/audit/s2_to_oli_lopo.csv", index=False)
df["pb_group"] = np.where(df.pb.astype(float) >= 4, "PB>=04.00", "PB<04.00")
summ = df.groupby(["band"])[["bias_before", "bias_after", "mad_before", "mad_after"]].median().round(4)
summ_pb = df.groupby(["pb_group", "band"])[["bias_before", "bias_after"]].median().round(4)
print(summ.to_string()); print(summ_pb.to_string())

# Does a single transform fit both processing baselines? Fit separately and compare slopes.
grp = {g: [p for p in pairs if (float(p["pb"]) >= 4) == (g == "ge4")] for g in ("lt4", "ge4")}
by_pb = {g: {b: rma(*stack(ps, b)) for b in BANDS} for g, ps in grp.items() if len(ps) >= 3}
full = {b: rma(*stack(pairs, b)) for b in BANDS}
out = {"name": "s2_to_oli_v1", "created_utc": utcnow(),
       "direction": "Landsat_OLI_equivalent = slope * S2_L2A_reflectance + intercept (BOA offset already removed)",
       "reference": "Landsat C2 L2 harmonised with local_pune_g30_v2 (OLI-equivalent), read onto G30 corridor window",
       "method": "robust RMA (2x 3-MAD trim), pooled pixels from same-day pairs |dt|<15 min, <=20k px per pair",
       "n_pairs": len(pairs), "pair_dates": [p["date"] for p in pairs],
       "band_map": {"blue": "B02", "green": "B03", "red": "B04", "nir08": "B8A", "swir16": "B11", "swir22": "B12"},
       "slope": {b: round(full[b][0], 4) for b in BANDS}, "intercept": {b: round(full[b][1], 5) for b in BANDS},
       "by_processing_baseline": {g: {"n_pairs": len(grp[g]), "slope": {b: round(v[0], 4) for b, v in c.items()},
                                      "intercept": {b: round(v[1], 5) for b, v in c.items()}} for g, c in by_pb.items()},
       "leave_one_pair_out": {b: {k: float(v) for k, v in summ.loc[b].items()} for b in summ.index},
       "status": "FITTED — apply only for Landsat+S2 fusion; S2-only products remain native Sen2Cor reflectance",
       "limitations": ["fitted on one 30 m window (urban/peri-urban/reservoir) — landscape dependence not tested",
                       "pairs are dry/post-monsoon dominated (cloud-free same-day pairs); monsoon not represented",
                       "S2 bands resampled to G30 by area-average before pairing (scripts/same_day_pairs.py)",
                       "slopes << 1 are NOT a PSF/MTF artefact: they persist under 90-300 m block aggregation and S2 Gaussian "
                       "blurring lowers r (results/audit/s2_oli_scale_test.csv); dark water agrees between sensors, bright "
                       "surfaces are 20-50% brighter in Sen2Cor -> processor (atmospheric-correction) gain difference whose "
                       "attribution (which processor is closer to truth) is NOT established; AERONET Pune comparison PENDING"]}
yaml.safe_dump(out, open("results/harmonization/s2_to_oli_v1.yaml", "w"), sort_keys=False)
print(json.dumps({"slope": out["slope"], "intercept": out["intercept"]}, indent=0))
