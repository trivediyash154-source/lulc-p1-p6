"""Correction of the B-group outcome logic (found on review, 2026-10-02): run_phase3_temporal.py compared every multi-year ('m') model with P3-B1m,
but the PRE-REGISTERED hypotheses name other comparators:
  P3-B1m..B4m : vs the same feature set trained on 2021 only (B1..B4)
  P3-B5m      : vs P3-B4m (does SPI add anything?)        P3-B4t : vs P3-B4m (two-sided: does terrain change FBR?)
The predictions of those runs are valid (same code, seed, data); only the outcome comparison was wrong. The affected records are marked INVALID
(never overwritten) and re-registered as @v2 (B5m: @v3) whose execution re-uses the saved predictions and applies the registered comparator."""
import json, sys, warnings
import numpy as np
sys.path.insert(0, "src"); warnings.filterwarnings("ignore")
from pune_eo import config
from pune_eo.historical_reconstruction import het
from pune_eo.validation import registry3 as R3
from pune_eo.validation.stats3 import block_bootstrap_diff
H = het.load(); M = H["meta"]; YEARS = H["info"]["years"]; CL = H["climate"]; TD = config.path("results/phase3/temporal")
ev = np.load(TD / "eval_cells.npy"); mm = M.iloc[ev].reset_index(drop=True)
def dry_rate(P, kind):
    out = np.full(len(ev), np.nan)
    for g in mm.window.unique():
        k = CL[CL.window == g].set_index("year").climate_class.reindex(YEARS).values == "dry"; w = (mm.window == g).values & mm[kind].values
        if k.any(): out[w] = (P[w][:, k] == 1).mean(1)
    return out
FIX = {"P3-B1m": ("P3-B1m", "P3-B1", "lower"), "P3-B2m": ("P3-B2m", "P3-B2", "lower"), "P3-B3m": ("P3-B3m", "P3-B3", "lower"), "P3-B4m": ("P3-B4m", "P3-B4", "lower"),
       "P3-B5m@v2": ("P3-B5m@v2", "P3-B4m", "lower"), "P3-B4t": ("P3-B4t", "P3-B4m", "two_sided")}
for old, (pred_id, comp, kind_) in FIX.items():
    rec = R3.load(old)
    if rec["status"] == "PASS": R3.invalidate(old, f"outcome computed against P3-B1m instead of the pre-registered comparator {comp}; predictions valid and re-used by the corrected record")
    new = old.split("@")[0] + ("@v3" if old == "P3-B5m@v2" else "@v2")
    if R3.load(new) is None:
        spec = {k: rec[k] for k in R3.FIELDS}; spec["experiment_id"] = new; spec["reason"] = rec["reason"] + f" | {new}: corrected comparator ({comp}) per the registered hypothesis; predictions re-used from {old} (identical code/seed)"
        R3.register(**spec)
    if R3.load(new)["status"] != "PENDING": continue
    run = R3.Run(new); A, Bp = np.load(TD / f"pred_{pred_id}.npy"), np.load(TD / f"pred_{comp}.npy"); res = {"comparator": comp, "predictions": f"results/phase3/temporal/pred_{pred_id}.npy"}
    for kind in ("never_settled", "stable_built"):
        a, b = dry_rate(A, kind), dry_rate(Bp, kind); ok = np.isfinite(a) & np.isfinite(b)
        res[kind] = block_bootstrap_diff(lambda i: float(np.mean(a[ok][i] - b[ok][i])), mm.block.values[ok]) | {"model_mean": float(a[ok].mean()), "comparator_mean": float(b[ok].mean())}
    res["by_window_dry_fbr"] = {g[9:]: {"model": float(np.nanmean(dry_rate(A, "never_settled")[(mm.window == g).values])), "comparator": float(np.nanmean(dry_rate(Bp, "never_settled")[(mm.window == g).values]))} for g in mm.window.unique()}
    c = res["never_settled"]; rel = c["estimate"] / c["comparator_mean"] if c["comparator_mean"] else 0; rd = res["stable_built"]["estimate"]
    if kind_ == "lower": outcome = "SUPPORTED" if (c["estimate"] < 0 and c["excludes_zero"] and rd >= -0.05) else ("NOT_SUPPORTED" if (not c["excludes_zero"] or c["estimate"] > 0) else "INCONCLUSIVE")
    else: outcome = "SUPPORTED" if c["excludes_zero"] else "NOT_SUPPORTED"
    msg = f"dry-year FBR vs {comp}: {c['estimate']:+.4f} (rel {rel:+.0%}, CI {c['ci95'][0]:+.4f}..{c['ci95'][1]:+.4f}); stable-built recall change {rd:+.3f}"
    run.complete(res, outcome, msg, outputs={"predictions": res["predictions"]}); print(new, outcome, msg, flush=True)
