"""Run the Phase-1 audit and write results/audit/phase1_audit.json (+ the facts used by docs/phase1_audit.md)."""
import json
from pathlib import Path
import numpy as np, pandas as pd
from pune_eo import config
from pune_eo.provenance import sha256, utcnow
from pune_eo.validation import audit as A
R = config.ROOT; out = R / "results/audit"; out.mkdir(parents=True, exist_ok=True)
checks = []
checks += A.audit_boundary(); checks += A.audit_grids()
mc, facts = A.audit_manifests(); checks += mc
SNAP = R / "data/_phase1_snapshot/composites"
pc, df = A.audit_products(SNAP); checks += pc          # Phase-1 product set as delivered (702 products)
_, df_now = A.audit_products()                       # current tree, incl. Phase-2 reprocessing
checks += A.audit_rasters(df_now, limit=60)
def _same_version(a, b):
    pa, pb = a.get("processing", {}), b.get("processing", {})
    return a.get("processing_version") == b.get("processing_version") and pa.get("harmonization") == pb.get("harmonization")
# reproducibility: regenerated products vs the checksums recorded at Phase-1 time
rep = []
for m in sorted((R / "data/_phase1_snapshot/composites").glob("*/*/*/**/metadata.json")):
    rel = m.relative_to(R / "data/_phase1_snapshot/composites"); new = R / "data/composites" / rel
    a = json.loads(m.read_text())
    if not new.exists(): continue
    b = json.loads(new.read_text())
    if b["created_utc"] == a["created_utc"]: continue          # not regenerated
    same = {k: a["files"][k]["sha256"] == sha256(R / b["files"][k]["path"]) for k in a["files"]}
    rep.append({"product_id": a["product_id"], "files_identical": f"{sum(same.values())}/{len(same)}",
                "sources_identical": sorted(s["item_id"] for s in a["sources"]) == sorted(s["item_id"] for s in b["sources"]),
                "same_version": _same_version(a, b), "new_harmonization": b.get("processing", {}).get("harmonization")})
regen = [r for r in rep if r["same_version"]]; reproc = [r for r in rep if not r["same_version"]]
ok = all(r["files_identical"].split("/")[0] == r["files_identical"].split("/")[1] and r["sources_identical"] for r in regen)
nid = sum(r["files_identical"].split("/")[0] == r["files_identical"].split("/")[1] for r in regen)
checks.append(A._res("reproducibility: regenerated from manifests in a fresh environment (same processing version)",
                     "PASS" if regen and ok else ("FAIL" if regen else "INFO"), f"{len(regen)} products regenerated with an unchanged version; bit-identical: {nid}", regen))
checks.append(A._res("Phase-2 reprocessing (corrected transform) — not a reproducibility test", "INFO",
                     f"{len(reproc)} Phase-1 products already re-made with a changed processing version "
                     f"({sorted({r['new_harmonization'] for r in reproc})}); Phase-1 checksums kept in data/_phase1_snapshot", reproc[:5]))
# geolocation: image-to-image sub-pixel registration (windowed cross-correlation + upsampled DFT; unbiased to 0.03 px on
# synthetic shifts, tests/test_audit_registration.py). The Phase-1 JRC-water IoU shift search is NOT used: it is confounded by
# reservoir shoreline drawdown between the JRC epoch and our dry season (IoU gain at best shift only 0.008).
C = R / "data/composites/pune_G30_khadakwasla_mutha"
regs = {}
for lab, pa, pb in [("L5 1990 vs L8/9 2026 (dry)", C / "1990/landsat/seasonal/dry", C / "2026/landsat/seasonal/dry"),
                    ("L7 2005 vs L8/9 2026 (dry)", C / "2005/landsat/seasonal/dry", C / "2026/landsat/seasonal/dry")]:
    try:
        regs[lab] = {b: A.registration_test(pa / "optical_composite.tif", pb / "optical_composite.tif", b, b) for b in ("nir08", "swir16")}
    except Exception as e:
        regs[lab] = {"error": repr(e)}
s2c = json.loads((R / "results/audit/s2_landsat_consistency.json").read_text())
regs["S2 vs L8/9 2024 (dry)"] = s2c["registration_px"]
mx = max(max(abs(v["dy_px_median"]), abs(v["dx_px_median"])) for r in regs.values() for v in r.values() if isinstance(v, dict) and "dy_px_median" in v)
checks.append(A._res("geolocation: sub-pixel image registration across sensors (corridor, 9 tiles per band)",
                     "PASS" if mx <= 0.2 else "FAIL", f"max |median shift| = {mx:.3f} px (30 m px) over L5/L7/L8-9/S2 pairs", regs))
# sensor transitions in the harmonised district series (dry season)
s = pd.read_csv(R / "results/timeline/district_dry_season_series_pune_G240.csv").set_index("year")
d = s.ndvi_median.diff().abs(); ok_years = s.support_pct >= 50
typ = d[ok_years & ok_years.shift(1, fill_value=False)]
for a_, b_, lab in [(1999, 2000, "L5→L5+L7"), (2012, 2013, "L7→L7+L8"), (2021, 2022, "L7+L8→L8+L9")]:
    pct = (typ < d.loc[b_]).mean() * 100
    checks.append(A._res(f"sensor transition {lab} ({a_}→{b_}): NDVI jump vs normal interannual change", "PASS" if pct < 90 else "WARN",
                         f"|ΔNDVI| {d.loc[b_]:.3f}; larger than {pct:.0f} % of all supported year-to-year changes"))
terr = sorted(p.parent.name for p in (R / "data/features/terrain").glob("*/terrain.tif"))
checks.append(A._res("DEM / terrain layer", "WARN" if terr else "FAIL",
                     "NOT built in Phase 1; built in this audit (Copernicus GLO-30, 12 bands incl. HAND/TWI/distance to drainage) for: "
                     + (", ".join(terr) or "none"), "district-wide 30 m terrain PENDING (only benchmark windows built)"))
import yaml as _y
s2o = _y.safe_load((R / "results/harmonization/s2_to_oli_v1.yaml").read_text())
lo = s2o["leave_one_pair_out"]
checks.append(A._res("Sentinel-2 ↔ Landsat radiometric consistency", "WARN",
                     f"{s2o['n_pairs']} same-day pairs: S2 brighter than OLI (median bias blue {lo['blue']['bias_before']:+.4f} … swir22 "
                     f"{lo['swir22']['bias_before']:+.4f}; NDVI {lo['ndvi']['bias_before']:+.4f}); gain-type, scale-invariant 30-300 m. "
                     f"s2_to_oli_v1 fitted: leave-one-pair-out NDVI bias {lo['ndvi']['bias_after']:+.4f}",
                     "fusion of S2 with Landsat MUST apply s2_to_oli_v1; attribution of the processor difference unresolved"))
checks.append(A._res("district-scale products resolution", "WARN", "district cube is the 240 m benchmark (overview reads); 30 m exists only for one window",
                     "area statistics and classification must use 30 m products"))
checks.append(A._res("harmonisation fit resolution", "WARN", "Phase 1: transform fitted at 240 m, L9 term not reproduced at 30 m. "
                     "Corrected: G30 now uses local_pune_g30_v2 (pooled 30 m RMA L7->OLI, L9 identity); landscape slope spread up to 0.08",
                     "L7-era (1999-2013) values carry a landscape-dependent harmonisation uncertainty"))
yrs = A.summarise_years(df)
res = {"created_utc": utcnow(), "checks": checks, "manifest_facts": facts,
       "status_counts": pd.Series([c["status"] for c in checks]).value_counts().to_dict()}
(out / "phase1_audit.json").write_text(json.dumps(res, indent=1, default=str))
yrs.to_csv(out / "phase1_year_status.csv"); df.to_csv(out / "phase1_products.csv", index=False)
for c in checks: print(f"[{c['status']:<4}] {c['check']}: {c['evidence']}")
print(res["status_counts"])
