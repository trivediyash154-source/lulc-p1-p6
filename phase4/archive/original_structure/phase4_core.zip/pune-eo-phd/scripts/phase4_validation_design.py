"""Phase 4: district-wide stratified validation design for HUMAN Tier-A interpretation (Pune District, 30 m cells).
Design rules (docs/phase4_gold_protocol.md):
  * population = 30 m cells inside the district boundary;
  * independence: 6 km hashed blocks (salt 'phase4-v1'); points are drawn ONLY from validation blocks (30 % of blocks), which are excluded from every
    training, tuning and model-selection step (configs/phase4_evaluation_protocol.yaml);
  * strata are mutually exclusive and assigned in a fixed priority order from district-wide layers that are NOT our model outputs
    (product consensus/disagreement, settlement history, terrain, water, rainfall zone) - deliberately including difficult landscapes;
  * allocation: equal-ish allocation with a floor per stratum and oversampling of disagreement / transforming / hard strata (Olofsson-type estimators
    re-weight by stratum area, so oversampling hard strata does not bias area or accuracy estimates);
  * regions for leave-one-region-out: CHIRPS 1991-2020 mean-annual-rainfall zones (wet west >= 1200 mm, transition 700-1200, dry east < 700).
Outputs: data/labels/gold/phase4/sampling_design/, blind forms + KML in data/labels/gold/phase4/blind/, key in data/labels/gold/phase4/_key/."""
import hashlib, json, sys, warnings
import numpy as np, pandas as pd, rasterio
from rasterio.enums import Resampling
from scipy.ndimage import distance_transform_edt, label as cc_label, uniform_filter
sys.path.insert(0, "src"); warnings.filterwarnings("ignore")
from pune_eo import config
from pune_eo.grid import district_grid
from pune_eo.io import write_cog, write_json
from pune_eo.provenance import utcnow
from pune_eo.labels import sources as SRC
SEED = 20261111; rng = np.random.default_rng(SEED); G = district_grid("G30"); PX = config.path("data/products_ext"); LB = config.path("data/labels/pune_G30")
OUT = config.path("data/labels/gold/phase4"); [ (OUT / d).mkdir(parents=True, exist_ok=True) for d in ("sampling_design", "blind", "_key", "raw_interpreter_A", "raw_interpreter_B", "adjudicated", "metadata") ]
def rd(p, b=1):
    with rasterio.open(p) as s: return s.read(b)
mask = rd(PX / "district/district_mask_30m.tif").astype(bool)
# ---------- terrain (district COP-DEM GLO-30, acquired here if missing)
demf = PX / "dem" / "copdem30_district_30m.tif"
if not demf.exists():
    demf.parent.mkdir(exist_ok=True); items = list(SRC.client().search(collections=["cop-dem-glo-30"], bbox=SRC._bbox_ll(G)).items()); dem = np.full(G.shape, np.nan, np.float32)
    for it in items:
        a = SRC._warp(it.assets["data"].href, G, Resampling.bilinear, dst_nodata=-9999, dtype="float32"); dem = np.where(a > -9999, a, dem)
    write_cog(demf, np.nan_to_num(dem, nan=-9999), G, nodata=-9999, dtype="float32", descriptions=["elevation_m"]); write_json(demf.with_suffix(".json"), {"source": "Copernicus DEM GLO-30 (DSM) via Planetary Computer", "tiles": [i.id for i in items], "created_utc": utcnow()})
dem = rd(demf).astype(np.float32); dem[dem == -9999] = np.nan
gy, gx = np.gradient(np.nan_to_num(dem, nan=float(np.nanmedian(dem))), 30.0); slope = np.degrees(np.arctan(np.hypot(gx, gy))).astype(np.float32); del gx, gy
# ---------- rainfall zones (CHIRPS mean annual 1991-2020)
with rasterio.open(config.path("data/processed/climate/chirps_v2_monthly_stack.tif")) as s:
    desc = list(s.descriptions); idx = [i + 1 for i, d in enumerate(desc) if d and 1991 <= int(d[:4]) <= 2020]; tot = np.zeros((s.height, s.width))
    for i in idx: tot += np.nan_to_num(s.read(i).astype(float), nan=0)
    ann = tot / 30.0; prof = s.profile
import tempfile, os
tmp = tempfile.NamedTemporaryFile(suffix=".tif", delete=False).name; prof.update(count=1, dtype="float32", nodata=-1)
with rasterio.open(tmp, "w", **prof) as d: d.write(ann.astype(np.float32), 1)
rain = SRC._warp(tmp, G, Resampling.bilinear, dst_nodata=-1, dtype="float32", sign=False); os.unlink(tmp)
region = np.where(rain >= 1200, 1, np.where(rain >= 700, 2, 3)).astype(np.uint8); RNAME = {1: "wet_west_ge1200mm", 2: "transition_700_1200mm", 3: "dry_east_lt700mm"}
# ---------- products -> L1 (1 built, 2 agri, 3 natveg, 4 water, 5 bare/sparse, 6 other)
GLC_L1 = {10: 2, 11: 2, 12: 2, 20: 2, **{c: 3 for c in (51, 52, 61, 62, 71, 72, 81, 82, 91, 92, 120, 121, 122, 130, 140)}, 150: 5, 152: 5, 153: 5, **{c: 6 for c in range(181, 188)}, 190: 1, 200: 5, 201: 5, 202: 5, 210: 4, 220: 6}
cw = config.load("labels")["crosswalks"]
def l1(a, table): out = np.zeros(a.shape, np.uint8); [out.__setitem__(a == int(k), v) for k, v in table.items()]; return out
with rasterio.open(PX / "glc_fcs30d/glc_fcs30d_district_30m.tif") as s: yrs = [int(d) for d in s.descriptions]; glc20 = l1(s.read(yrs.index(2020) + 1), GLC_L1); glc00 = l1(s.read(yrs.index(2000) + 1), GLC_L1); glcraw20 = s.read(yrs.index(2020) + 1)
with rasterio.open(PX / "esri/esri_district_30m_mode.tif") as s: ey = [int(d) for d in s.descriptions]; esri20 = l1(s.read(ey.index(2020) + 1), cw["esri_lulc"])
with rasterio.open(PX / "worldcover/worldcover_district_30m_mode.tif") as s: wy = [int(d) for d in s.descriptions]; wc20 = l1(s.read(wy.index(2020) + 1), cw["esa_worldcover"])
wsf = rd(LB / "wsf_evolution_first_year.tif"); gisa = rd(PX / "gisa/gisa2_first_year_district_30m.tif")
jrc = rd(LB / "jrc_gsw.tif", 1).astype(float); jrc[jrc == 255] = np.nan
with rasterio.open(LB / "ghsl_built_fraction_90m.tif") as s: gh20 = s.read(7).astype(float)
gh20 = np.repeat(np.repeat(gh20, 3, 0), 3, 1)[:G.shape[0], :G.shape[1]]; gh20 = np.pad(gh20, ((0, G.shape[0] - gh20.shape[0]), (0, G.shape[1] - gh20.shape[1])), constant_values=np.nan)
# water geometry: reservoirs = connected JRC>=50 bodies >= 1 km2; river corridor = other JRC>=25 cells
wet = np.nan_to_num(jrc) >= 50; lab, n = cc_label(wet); sizes = np.bincount(lab.ravel()); big = np.isin(lab, np.flatnonzero(sizes >= 1111)) & (lab > 0)
d_res = distance_transform_edt(~big) * 30; riv = (np.nan_to_num(jrc) >= 25) & ~big; d_riv = distance_transform_edt(~riv) * 30
# ---------- strata (priority order, mutually exclusive)
cons = (glc20 == esri20) & (esri20 == wc20); urban_old = ((wsf > 0) & (wsf <= 2000)) & (np.nan_to_num(gh20) >= 0.3)
urbanised = (((wsf >= 2001) & (wsf <= 2015)) | ((gisa >= 2001) & (gisa <= 2021)) | ((glc00 != 1) & (glc20 == 1))) & ~urban_old
irrig = cons & (glc20 == 2) & (glcraw20 == 20); rainfed = cons & (glc20 == 2) & ~irrig
ST = [("water_permanent", np.nan_to_num(jrc) >= 75), ("reservoir_margin_le1km", (d_res <= 1000) & ~(np.nan_to_num(jrc) >= 75)),
      ("urban_core_settled_by_2000", urban_old), ("peri_urban_transforming_2001_2021", urbanised),
      ("river_corridor_le300m", d_riv <= 300), ("product_disagreement_2020", ~cons),
      ("forest_natveg_hilly_slope_ge8", cons & (glc20 == 3) & (slope >= 8)), ("natveg_open_plateau", cons & (glc20 == 3) & (slope < 8)),
      ("irrigated_agriculture", irrig), ("rainfed_dry_agriculture", rainfed), ("bare_sparse_other", cons & np.isin(glc20, [5, 6])), ("built_consensus_other", cons & (glc20 == 1))]
stratum = np.zeros(G.shape, np.uint8); names = []
for i, (nm, m) in enumerate(ST, 1): stratum[(stratum == 0) & m & mask] = i; names.append(nm)
stratum[(stratum == 0) & mask] = len(ST) + 1; names.append("residual")
# ---------- 6 km hashed blocks
bx = ((np.arange(G.shape[1]) * 30 + G.x0) // 6000).astype(int); by = ((G.y1 - np.arange(G.shape[0]) * 30) // 6000).astype(int)
ubx, uby = np.unique(bx), np.unique(by)
tab = np.array([[int(hashlib.sha256(f"phase4-v1:{a}:{b}".encode()).hexdigest(), 16) % 100 for a in ubx] for b in uby], np.uint8)
val_block = (tab[np.searchsorted(uby, by)][:, np.searchsorted(ubx, bx)] < 30)
# ---------- design v2 (protocol v2): exclude the Phase-3 benchmark windows + 2 km from the validation frame
win_mask = np.zeros(G.shape, bool)
for w in ("khadakwasla_mutha", "baramati_agri", "mulshi_ghats"):
    gj = json.load(open(config.path("data/labels", f"pune_G30_{w}", "splits.json")))["grid"]; c0 = int(round((gj["x0"] - G.x0) / 30)); r0 = int(round((G.y1 - gj["y1"]) / 30))
    win_mask[max(r0, 0):r0 + gj["height"], max(c0, 0):c0 + gj["width"]] = True
excl = distance_transform_edt(~win_mask) * 30 <= 2000
frame = val_block & mask & ~excl
write_cog(OUT / "sampling_design/strata_30m.tif", stratum, G, nodata=0, dtype="uint8", descriptions=["stratum"], overview_resampling="nearest")
write_cog(OUT / "sampling_design/validation_blocks_30m.tif", (val_block & mask).astype(np.uint8), G, nodata=None, dtype="uint8", descriptions=["validation_block"], overview_resampling="nearest")
# ---------- allocation (population = all district cells of each stratum; sample frame = validation-block cells)
N_TOTAL, FLOOR, MAXPB = 600, 30, 4; area = {names[i - 1]: int((stratum == i).sum()) for i in range(1, len(names) + 1)}
TINY = 0.0025 * int(mask.sum())          # strata below 0.25 % of the district get at most 5 points (v1 gave 30 points to 0.2 km2)
hard = {"product_disagreement_2020", "peri_urban_transforming_2001_2021", "reservoir_margin_le1km", "river_corridor_le300m", "urban_core_settled_by_2000", "rainfed_dry_agriculture"}
w = {k: (np.sqrt(v) * (1.6 if k in hard else 1.0)) for k, v in area.items() if v > 0}; tot = sum(w.values())
alloc = {k: (min(5, max(1, int(round(N_TOTAL * v / tot)))) if area[k] < TINY else max(FLOOR, int(round(N_TOTAL * v / tot)))) for k, v in w.items()}
rows = []
for i, nm in enumerate(names, 1):
    if nm not in alloc: continue
    cand = rng.permutation(np.flatnonzero(((stratum == i) & frame).ravel())); pick, per_block = [], {}
    for p in cand:                                   # at most MAXPB points of a stratum per 6 km block (limits clustering)
        if len(pick) >= alloc[nm]: break
        r_, c_ = divmod(int(p), G.shape[1]); kb = (bx[c_], by[r_])
        if per_block.get(kb, 0) >= MAXPB: continue
        per_block[kb] = per_block.get(kb, 0) + 1; pick.append(p)
    for p in pick:
        r, c = divmod(int(p), G.shape[1]); rows.append({"stratum": nm, "row": r, "col": c, "x_utm": G.x0 + (c + 0.5) * 30, "y_utm": G.y1 - (r + 0.5) * 30, "region": RNAME[int(region[r, c])],
                                                        "block": f"{bx[c]}:{by[r]}", "elev_m": float(dem[r, c]), "slope_deg": float(slope[r, c]), "rain_mm": float(rain[r, c])})
D = pd.DataFrame(rows)
from pyproj import Transformer
t = Transformer.from_crs(G.crs, 4326, always_xy=True); D["lon"], D["lat"] = t.transform(D.x_utm.values, D.y_utm.values)
D["stratum_area_cells"] = D.stratum.map(area); D["n_stratum_sample"] = D.stratum.map(D.stratum.value_counts()); D["inclusion_prob_frame"] = D.n_stratum_sample / D.stratum.map({nm: int(((stratum == i) & frame).sum()) for i, nm in enumerate(names, 1)})
D = D.sample(frac=1, random_state=SEED).reset_index(drop=True); D.insert(0, "anon_id", [f"P4-{i + 1:04d}" for i in range(len(D))])
D["double_interpretation"] = False; D.loc[D.sample(frac=0.25, random_state=SEED + 1).index, "double_interpretation"] = True
D.to_csv(OUT / "_key/phase4_gold_key.csv", index=False); NB = int(D.block.nunique())
json.dump({"design_version": 2, "protocol_version": 2, "created_utc": utcnow(), "seed": SEED, "frame": "validation blocks inside the district, excluding the 3 Phase-3 benchmark windows + 2 km",
           "frame_share_of_district": float(frame[mask].mean()), "max_points_per_block_per_stratum": MAXPB, "tiny_stratum_rule": "strata < 0.25 % of district: <= 5 points",
           "n_blocks_with_points": NB, "grid": G.to_dict(), "n_points": len(D), "strata_priority_order": names, "stratum_area_cells_population": area, "allocation_requested": alloc,
           "allocation_drawn": D.stratum.value_counts().to_dict(), "regions": RNAME, "region_counts": D.region.value_counts().to_dict(), "validation_block_share_of_district": float(val_block[mask].mean()), "validation_blocks_share_of_blocks": float((tab < 30).mean()),
           "block_km": 6, "block_salt": "phase4-v1", "estimator_note": "weights = stratum population area / stratum sample size (strata defined on the whole district; frame restricted to validation blocks)",
           "strata_layers_note": "layers are independent of OUR models; Esri/WorldCover are silver-label sources and GLC_FCS30D a benchmark product - used here only to stratify, never as labels", "layers": {"product_consensus": "GLC_FCS30D 2020, Esri 2020, WorldCover 2020 (L1 crosswalk)", "settlement": "WSF-Evolution, GISA 2.0, GLC_FCS30D 2000->2020 impervious", "water": "JRC GSW occurrence",
                      "terrain": "Copernicus DEM GLO-30 slope", "rainfall": "CHIRPS v2 1991-2020 mean annual"}}, open(OUT / "sampling_design/design.json", "w"), indent=1)
json.dump({"regions": RNAME, "rule": "CHIRPS 1991-2020 mean annual rainfall zones; leave-one-region-out unit"}, open(OUT / "sampling_design/regions.json", "w"), indent=1)
# ---------- blind forms (no stratum, no region, no block, no product layer)
EP = [2020, 2000, 2010, 1990]
cols = ["anon_id", "lat", "lon"] + [f"{f}_{e}" for e in EP for f in ("dominant_class", "dominant_share_3bins", "second_class", "confidence_1to3", "imagery_source", "imagery_date", "status", "notes")]
blind = D[["anon_id", "lat", "lon"]].copy()
for c in cols[3:]: blind[c] = ""
blind.to_csv(OUT / "blind/form_interpreter_A.csv", index=False)
blind[D.double_interpretation.values].sample(frac=1, random_state=SEED + 2).to_csv(OUT / "blind/form_interpreter_B.csv", index=False)
half = 15.0
def ring(x, y):
    pts = [(x - half, y - half), (x + half, y - half), (x + half, y + half), (x - half, y + half), (x - half, y - half)]; lo, la = t.transform(*zip(*pts)); return " ".join(f"{a:.7f},{b:.7f},0" for a, b in zip(lo, la))
k = ['<?xml version="1.0" encoding="UTF-8"?><kml xmlns="http://www.opengis.net/kml/2.2"><Document><name>Pune Phase-4 gold (blind)</name>'
     '<Style id="c"><LineStyle><color>ff00ffff</color><width>2</width></LineStyle><PolyStyle><fill>0</fill></PolyStyle></Style>']
for _, r in D.iterrows():
    k.append(f'<Placemark><name>{r.anon_id}</name><styleUrl>#c</styleUrl><MultiGeometry><Point><coordinates>{r.lon:.7f},{r.lat:.7f},0</coordinates></Point>'
             f'<Polygon><outerBoundaryIs><LinearRing><coordinates>{ring(r.x_utm, r.y_utm)}</coordinates></LinearRing></outerBoundaryIs></Polygon></MultiGeometry></Placemark>')
k.append("</Document></kml>"); (OUT / "blind/phase4_gold_cells.kml").write_text("".join(k))
print(json.dumps({"n": len(D), "drawn": D.stratum.value_counts().to_dict(), "regions": D.region.value_counts().to_dict(), "double": int(D.double_interpretation.sum())}, indent=1))
