"""Phase-3 group L — label efficiency (P3-L1) and active-learning simulation (P3-L2). Features: B3 + terrain (2021), labels silver 2021 (Tier C).
L1: random subsets (10/25/50/75/100 %) of labelled TRAIN cells, 3 seeds, RF and XGBoost; within (TEST blocks) and LOWO (held-out window, all silver cells).
    SSL arm read from results/phase3/ssl/ssl_summary.json (P3-G3 fine-tune at 10/25/50/100 %).
L2: new-landscape simulation per held-out window: source model data = two windows' TRAIN cells; target pool = held-out window TRAIN-block cells
    (labels revealed only when 'queried'); 50 random seed labels, then 6 rounds x 50 queries by entropy / margin / committee (3 bootstrap members) / random (3 seeds);
    evaluated on held-out window TEST blocks after every round. Simulation with silver labels as the oracle (Tier C) — not a field campaign."""
import json, sys, time, warnings
import numpy as np
sys.path.insert(0, "src"); warnings.filterwarnings("ignore")
from sklearn.metrics import f1_score
from pune_eo import config
from pune_eo.historical_reconstruction import het, features as F
from pune_eo.classification import baseline as B
from pune_eo.validation import registry3 as R3
H = het.load(); M = H["meta"]; SEED = 20261031; OUT = config.path("results/phase3/labels"); OUT.mkdir(parents=True, exist_ok=True)
WIN = ["pune_G30_khadakwasla_mutha", "pune_G30_baramati_agri", "pune_G30_mulshi_ghats"]; SH = {w: w[9:] for w in WIN}
sil = M.silver.between(1, 4).values; yv = M.silver.values; split = M.split.values; win = M.window.values
XA = np.hstack([F.build(H, "B3", 2021)[0], H["T"]]).astype(np.float32)
mf1 = lambda y, p: float(f1_score(y, p, labels=[1, 2, 3, 4], average="macro"))
def fit(name, tr, va, seed=SEED, n_est=None):
    present = sorted(set(yv[tr].tolist())); enc = {c: i for i, c in enumerate(present)}
    if name == "rf": m = B.make_model("rf", seed).fit(XA[tr], yv[tr]); return lambda X: m.predict_proba(X) @ np.eye(4)[[c - 1 for c in m.classes_]]
    m = B.make_model("xgb", seed, **({"n_estimators": n_est} if n_est else {})); vk = np.isin(yv[va], present)
    m.fit(XA[tr], np.vectorize(enc.get)(yv[tr]), eval_set=[(XA[va][vk], np.vectorize(enc.get)(yv[va][vk]))], verbose=False)
    return lambda X: m.predict_proba(X) @ np.eye(4)[[c - 1 for c in present]]
sub = lambda cells, f, s: np.sort(np.random.default_rng(SEED + s).choice(cells, max(40, int(round(f * len(cells)))), replace=False)) if f < 1 else cells
T0 = time.time(); L1 = {"within": {}, "lowo": {}}; FR = (0.10, 0.25, 0.50, 0.75, 1.00)
tr = np.flatnonzero(sil & (split == 1)); va = np.flatnonzero(sil & (split == 2)); te = np.flatnonzero(sil & (split == 3))
for name in ("xgb", "rf"):
    L1["within"][name] = {f"{int(f * 100)}%": [mf1(yv[te], fit(name, sub(tr, f, s), va, SEED + s)(XA[te]).argmax(1) + 1) for s in range(3 if f < 1 else 1)] for f in FR}
    print("L1 within", name, {k: round(np.mean(v), 4) for k, v in L1["within"][name].items()}, round(time.time() - T0), flush=True)
for t in WIN:
    og = win != t; trs = np.flatnonzero(sil & og & (split == 1)); vas = np.flatnonzero(sil & og & (split == 2)); ho = np.flatnonzero(sil & (win == t))
    L1["lowo"][t] = {f"{int(f * 100)}%": [mf1(yv[ho], fit("xgb", sub(trs, f, s), vas, SEED + s)(XA[ho]).argmax(1) + 1) for s in range(3 if f < 1 else 1)] for f in FR}
    print("L1 lowo", SH[t], {k: round(np.mean(v), 4) for k, v in L1["lowo"][t].items()}, flush=True)
def sat(d):
    full = np.mean(d["100%"]); return next((k for k in ("10%", "25%", "50%", "75%", "100%") if np.mean(d[k]) >= full - 0.005), "100%")
L1["saturation_fraction"] = {"within_xgb": sat(L1["within"]["xgb"]), "within_rf": sat(L1["within"]["rf"]), **{f"lowo_{SH[t]}": sat(L1["lowo"][t]) for t in WIN}}
sp = config.path("results/phase3/ssl/ssl_summary.json")
if sp.exists():
    S = json.loads(sp.read_text()); L1["ssl_arm_within"] = {k: {"G3_finetune": S["within"][k]["G3_finetune"]["macro_f1"], "xgb_same_cells": S["within"][k]["xgb_B3T"]["macro_f1"]} for k in S["within"] if k.endswith("%")}
    L1["ssl_arm_lowo"] = {SH[t]: {k: {"G3_finetune": S["lowo"][t][k]["G3_finetune"]["macro_f1"], "xgb_same_cells": S["lowo"][t][k]["xgb_B3T"]["macro_f1"]} for k in S["lowo"][t] if k.endswith("%")} for t in WIN}
fr_ok = [L1["saturation_fraction"][k] in ("10%", "25%", "50%") for k in L1["saturation_fraction"]]
ssl_low = None
if "ssl_arm_within" in L1: ssl_low = all(L1["ssl_arm_lowo"][SH[t]]["10%"]["G3_finetune"] > L1["ssl_arm_lowo"][SH[t]]["10%"]["xgb_same_cells"] + 0.01 for t in WIN)
R3.Run("P3-L1").complete(L1, "SUPPORTED" if (sum(fr_ok) >= 4 and ssl_low) else ("NOT_SUPPORTED" if (sum(fr_ok) < 3 or ssl_low is False) else "INCONCLUSIVE"),
                         f"saturation fraction (mean within 0.005 of 100 %): {L1['saturation_fraction']}; SSL fine-tune beats XGB at 10 % labels in all LOWO windows: {ssl_low}",
                         outputs={"summary": "results/phase3/labels/labels_summary.json"})
# ---------------- L2 active learning
def ent(p): return -(p * np.log(np.clip(p, 1e-12, 1))).sum(1)
def margin(p): s = np.sort(p, 1); return -(s[:, -1] - s[:, -2])
L2 = {}; BATCH, ROUNDS = 50, 6
for t in WIN:
    og = win != t; trs = np.flatnonzero(sil & og & (split == 1)); vas = np.flatnonzero(sil & og & (split == 2)); pool0 = np.flatnonzero(sil & (win == t) & (split == 1)); tte = np.flatnonzero(sil & (win == t) & (split == 3))
    L2[t] = {"source_only": mf1(yv[tte], fit("xgb", trs, vas, n_est=300)(XA[tte]).argmax(1) + 1)}
    for strat, seeds in (("entropy", (0,)), ("margin", (0,)), ("committee", (0,)), ("random", (0, 1, 2))):
        curves = []
        for s in seeds:
            rng = np.random.default_rng(SEED + s); lab = list(rng.choice(pool0, BATCH, replace=False)); curve = []
            for rd in range(ROUNDS + 1):
                trk = np.r_[trs, np.array(lab)]; f = fit("xgb", trk, vas, SEED + s, n_est=300); curve.append((len(lab), mf1(yv[tte], f(XA[tte]).argmax(1) + 1)))
                if rd == ROUNDS: break
                pool = np.setdiff1d(pool0, lab); cand = rng.choice(pool, min(4000, len(pool)), replace=False); p = f(XA[cand])
                if strat == "entropy": sc = ent(p)
                elif strat == "margin": sc = margin(p)
                elif strat == "committee":
                    ps = [p] + [fit("xgb", np.r_[rng.choice(trs, len(trs)), np.array(lab)], vas, SEED + 50 + k, n_est=200)(XA[cand]) for k in range(2)]
                    votes = np.stack([q.argmax(1) for q in ps], 1); sc = np.array([len(set(v)) for v in votes]) + 1e-3 * ent(np.mean(ps, 0))
                else: sc = rng.random(len(cand))
                lab += list(cand[np.argsort(-sc)[:BATCH]])
            curves.append(curve)
        L2[t][strat] = {"budget": [c[0] for c in curves[0]], "macro_f1_runs": [[c[1] for c in cv] for cv in curves]}
    rnd = np.mean(L2[t]["random"]["macro_f1_runs"], 0); target = rnd[-1]; L2[t]["target_f1_random_final_budget"] = float(target)
    L2[t]["labels_to_target"] = {s: next((b for b, v in zip(L2[t][s]["budget"], np.mean(L2[t][s]["macro_f1_runs"], 0)) if v >= target - 1e-9), None) for s in ("entropy", "margin", "committee", "random")}
    print("L2", SH[t], L2[t]["source_only"], L2[t]["labels_to_target"], flush=True)
final = BATCH * (ROUNDS + 1); win_ok = sum(1 for t in WIN if any((L2[t]["labels_to_target"][s] or 10 ** 9) <= final * 2 / 3 for s in ("entropy", "margin", "committee")))
json.dump({"L1": L1, "L2": L2}, open(OUT / "labels_summary.json", "w"), indent=1, default=float)
R3.Run("P3-L2").complete(L2, "SUPPORTED" if win_ok >= 2 else ("NOT_SUPPORTED" if win_ok == 0 else "INCONCLUSIVE"),
                         "labels needed to reach random-sampling F1 at the final budget (" + str(final) + "): " + "; ".join(f"{SH[t]} {L2[t]['labels_to_target']}" for t in WIN) + " (silver oracle, simulation)")
print("done", round(time.time() - T0), "s")
