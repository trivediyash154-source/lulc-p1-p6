"""Render docs/phase3_experiment_matrix.md from experiments/registry3 (every record, including corrected @v2 versions and INVALID/FAIL records)."""
import sys, json, re
sys.path.insert(0, "src")
from pune_eo import config
recs = [json.loads(p.read_text()) for p in sorted(config.path("experiments/registry3").glob("P3-*.json"))]
def key(r):
    m = re.match(r"P3-([A-Z])(\d*)(\w*?)(?:@v(\d+))?$", r["experiment_id"]); return (m.group(1), int(m.group(2) or 0), m.group(3), int(m.group(4) or 1)) if m else (r["experiment_id"],)
recs.sort(key=key); n = {}
for r in recs: n[r["status"]] = n.get(r["status"], 0) + 1
L = ["# Phase 3 experiment matrix", "", "_Every experiment was registered before execution (`scripts/phase3_register.py`; later additions registered by the script that runs them, before running). "
     "Status = execution (PENDING / PASS / FAIL / INVALID / SUPERSEDED); outcome = verdict on the pre-registered hypothesis (SUPPORTED / NOT_SUPPORTED / INCONCLUSIVE / NA). "
     "Completed records are immutable: corrections are new versions (`@v2`), the old record stays._", "", "Totals: " + ", ".join(f"{k} {v}" for k, v in sorted(n.items())), "",
     "| id | group | hypothesis | features | model | labels (tier) | status | outcome | result / reason |", "|---|---|---|---|---|---|---|---|---|"]
cl = lambda x: str(x).replace("|", "/").replace("\n", " ")
for r in recs:
    res = r.get("result") or r.get("not_run_reason") or r.get("invalid_reason") or r.get("error") or ""
    L.append("| " + " | ".join(cl(x) for x in [r["experiment_id"], r["group"], r["hypothesis"], r["features"], r["model"], f"{r['labels']} ({r['label_tier']})", r["status"], r.get("outcome") or "—", res[:400]]) + " |")
config.path("docs/phase3_experiment_matrix.md").write_text("\n".join(L) + "\n"); print(len(recs), n)
