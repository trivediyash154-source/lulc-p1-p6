"""Leave-one-WINDOW-out transfer (spatial extrapolation to an unseen landscape) - tests whether features (esp. terrain)
act as a geographic shortcut. Train on train+val blocks of 2 windows (val of those windows for early stopping),
test on ALL silver cells of the held-out window. Registry: EXP-L1-LOWO-{heldout}-{model}-{fs}."""
import json, sys, warnings
import numpy as np, pandas as pd
sys.path.insert(0, "src"); warnings.filterwarnings("ignore")
from pune_eo import config
from pune_eo.classification import baseline as B
from pune_eo.modelling.registry import Experiment
W = ["khadakwasla_mutha", "baramati_agri", "mulshi_ghats"]; YEAR = 2021; SEED = 20261004
pr = json.load(open(config.path("results/classification/feature_pruning.json")))
LS_ALL = [f for f in pr["kept"] if not f in ("elevation", "slope", "aspect_sin", "aspect_cos", "curv_prof", "curv_plan", "tpi_150", "tpi_1050", "log_facc", "hand", "dist_drain", "twi")]
FS = {"landsat": LS_ALL, "landsat_terrain": pr["kept"]}
df = B.samples(W, YEAR, pr["kept"], cap={1: 4000, 2: 4000, 3: 20000}, seed=SEED)
rows = []
for held in W:
    gid = B.window_grid_id(held); trw = df[(df.window != gid) & (df.split == 1)]; vaw = df[(df.window != gid) & (df.split == 2)]
    te = df[df.window == gid]
    for fs, feats in FS.items():
        for mdl in ["logreg", "rf", "xgb"]:
            eid = f"EXP-L1-LOWO-{held}-{mdl}-{fs}"
            e = Experiment(experiment_id=eid, research_question="RQ-LOWO: Does an L1 model transfer to an unseen landscape, and do terrain features help or act as a shortcut?",
                           hypothesis="terrain improves within-window agreement but transfers worse than spectral-temporal features",
                           dataset_version="cube G30 local_pune_g30_v2; labels silver v1", years=[YEAR], resolution_m=30, features=feats,
                           labels="silver_l1", split=f"leave-one-window-out: train 2 windows (train blocks), early-stop on their val blocks, test all cells of {held} (test cells capped 20k/class)",
                           model=mdl, hyperparameters={}, seed=SEED, heldout=held)
            try:
                m = B.make_model(mdl, SEED); B.fit(mdl, m, trw[feats], trw.label.values, vaw[feats], vaw.label.values)
                yt = B.predict(mdl, m, te[feats]); mt = B.evaluate(te.label.values, yt)
                e.finish({"test_heldout": mt}, result=f"held-out {held}: macro-F1 {mt['macro_f1']:.3f}", n_samples={"train": len(trw), "val": len(vaw), "test": len(te)})
                rows.append({"heldout": held, "model": mdl, "features": fs, "macro_f1": mt["macro_f1"], "overall": mt["overall_agreement"],
                             **{f"f1_{k}": v["f1"] for k, v in mt["per_class"].items()}, **{f"n_{k}": v["support"] for k, v in mt["per_class"].items()}})
                print(json.dumps(rows[-1]), flush=True)
            except Exception as ex:
                e.fail(repr(ex), eid, "fix and rerun"); print("FAILED", eid, repr(ex), flush=True)
pd.DataFrame(rows).to_csv(config.path("results/classification/lowo_summary.csv"), index=False)
