"""Phase-4 figures (figures/phase4/) from saved results only. Palette: reference categorical order (dataviz skill), fixed per entity."""
import json, sys, warnings
import numpy as np, pandas as pd, rasterio
import matplotlib; matplotlib.use("Agg"); import matplotlib.pyplot as plt
from matplotlib.colors import ListedColormap
sys.path.insert(0, "src"); warnings.filterwarnings("ignore")
from pune_eo import config
OUT = config.path("figures/phase4"); OUT.mkdir(parents=True, exist_ok=True)
CAT = ["#2a78d6", "#eb6834", "#1baf7a", "#eda100", "#e87ba4", "#008300", "#4a3aa7", "#e34948"]; INK, MUTED = "#0b0b0b", "#52514e"
plt.rcParams.update({"font.size": 8, "axes.spines.top": False, "axes.spines.right": False, "axes.edgecolor": MUTED, "axes.labelcolor": INK, "xtick.color": MUTED, "ytick.color": MUTED,
                     "axes.grid": True, "grid.color": "#e6e5e0", "grid.linewidth": 0.6, "figure.dpi": 150, "legend.frameon": False})
done, skipped = [], []
def fig(name):
    def deco(f):
        try: f(); plt.savefig(OUT / f"{name}.png", bbox_inches="tight", facecolor="#fcfcfb"); plt.close("all"); done.append(name)
        except Exception as e: plt.close("all"); skipped.append((name, repr(e)[:150]))
    return deco
J = lambda p: json.loads(config.path(p).read_text())
@fig("P4F1_observation_density")
def _():
    C = pd.read_csv(config.path("data/inventory/composites.csv")); G = C[(C.grid == "pune_G240") & (C.family == "landsat") & (C.kind == "season")]
    fig_, ax = plt.subplots(1, 2, figsize=(10, 3))
    for i, (p, lab) in enumerate((("dry", "dry (Jan-May)"), ("post_monsoon", "post-monsoon (Oct-Dec)"), ("wet", "wet (Jun-Sep)"))):
        d = G[G.period == p].sort_values("year"); ax[0].plot(d.year, d.n_clear_median, color=CAT[i], lw=2, label=lab); ax[1].plot(d.year, d.reliable_fraction_ge3, color=CAT[i], lw=2, label=lab)
    for a in ax: a.axvline(2013, color=MUTED, ls=":", lw=1); a.set_xlabel("year")
    ax[0].set_ylabel("median clear Landsat observations per pixel"); ax[1].set_ylabel("share of district with >= 3 clear obs"); ax[0].legend(fontsize=7)
    ax[0].text(2013.3, ax[0].get_ylim()[1] * 0.9, "Landsat 8", fontsize=7, color=MUTED); fig_.suptitle("District observation density by season (G240 composites): the pre-2013 record is thin", fontsize=9)
@fig("P4F2_built_trajectories_products")
def _():
    R = J("results/phase4/benchmark/district_benchmark.json")["built_trajectories_km2"]; order = ["GHSL_BUILT_S_surface", "ESA_CCI_urban_300m", "GISA2_impervious", "WSF_Evolution_settlement", "GLC_FCS30D_impervious", "WorldCover_built", "Esri_built"]
    lab = {"GHSL_BUILT_S_surface": "GHSL built surface (fraction-weighted)", "ESA_CCI_urban_300m": "ESA CCI urban (300 m)", "GISA2_impervious": "GISA 2.0 impervious", "WSF_Evolution_settlement": "WSF-Evolution settlement",
           "GLC_FCS30D_impervious": "GLC_FCS30D impervious", "WorldCover_built": "WorldCover built (Tier C)", "Esri_built": "Esri built area (Tier C)"}
    fig_, ax = plt.subplots(figsize=(8, 4))
    for i, k in enumerate(order):
        v = R[k]; x = sorted(int(y) for y in v); y = [v[str(t)] for t in x]; ax.plot(x, y, color=CAT[i], lw=2, marker="o" if len(x) < 10 else None, ms=4, label=lab[k])
        ax.text(x[-1] + 0.4, y[-1] + (35 if k == "WorldCover_built" else (-25 if k == "WSF_Evolution_settlement" else 0)), lab[k].split(" (")[0], fontsize=6.5, color=MUTED, va="center")
    ax.set_xlim(1984, 2033); ax.set_ylabel("built-up area in Pune District (km²)"); ax.set_xlabel("year"); ax.legend(fontsize=6.5, loc="upper left")
    ax.set_title("Seven products, seven definitions: district built-up area differs up to 4x in the same year", fontsize=9)
@fig("P4F3_class_shares_2020")
def _():
    S = pd.read_csv(config.path("results/phase4/benchmark/class_shares_by_product_year.csv")); rows = [("GLC_FCS30D", 2020), ("ESA_CCI_300m", 2020), ("Esri", 2020), ("WorldCover", 2020), ("WorldCover", 2021)]
    cls = ["built_up", "agriculture", "natural_vegetation", "water", "bare_sparse"]; fig_, ax = plt.subplots(figsize=(8, 3)); w = 0.15
    for i, (p, y) in enumerate(rows):
        r = S[(S["product"] == p) & (S.year == y)].iloc[0]; ax.bar(np.arange(len(cls)) + (i - 2) * w, [r[c] for c in cls], w * 0.9, color=CAT[i], label=f"{p} {y}")
    ax.set_xticks(range(len(cls))); ax.set_xticklabels([c.replace("_", " ") for c in cls]); ax.set_ylabel("share of district"); ax.legend(fontsize=6.5, ncol=3)
    ax.set_title("District class shares in 2020-21 by product (WorldCover 2020 -> 2021 is an algorithm-version change, not land change)", fontsize=8.5)
@fig("P4F4_consensus_maps")
def _():
    with rasterio.open(config.path("results/phase4/benchmark/l1_consensus_2020_30m.tif")) as s: c = s.read(1, out_shape=(s.height // 6, s.width // 6))
    with rasterio.open(config.path("results/phase4/benchmark/built_votes_2015_30m.tif")) as s: b = s.read(1, out_shape=(s.height // 6, s.width // 6))
    R = J("results/phase4/benchmark/district_benchmark.json"); st = R.get("no_full_consensus_share_by_stratum", {})
    fig_, ax = plt.subplots(1, 3, figsize=(13, 4))
    ax[0].imshow(np.ma.masked_equal(c, 0), cmap=ListedColormap(["#d9d8d3", CAT[3], CAT[7]]), vmin=1, vmax=3, interpolation="nearest"); ax[0].set_title("L1 class 2020: grey all agree / yellow two / red none\n(GLC_FCS30D, Esri, WorldCover)", fontsize=8)
    bb = np.ma.masked_less(b, 2); ax[1].imshow(bb, cmap=ListedColormap([CAT[3], CAT[1], CAT[7]]), vmin=2, vmax=4, interpolation="nearest"); ax[1].set_title("built 2015: votes of WSF, GISA, GLC_FCS30D\n(yellow 1, orange 2, red 3)", fontsize=8)
    for a in ax[:2]: a.set_xticks([]); a.set_yticks([]); a.grid(False)
    ks = [k for k in st if st[k] > 0 and k != "product_disagreement_2020"]; ks = sorted(ks, key=lambda k: st[k])
    ax[2].barh(range(len(ks)), [st[k] for k in ks], color=CAT[0]); ax[2].set_yticks(range(len(ks))); ax[2].set_yticklabels([k.replace("_", " ") for k in ks], fontsize=7); ax[2].set_xlabel("share without full L1 consensus")
    ax[2].set_title("where products disagree (by validation stratum)", fontsize=8)
@fig("P4F5_sensor_era_pif")
def _():
    R = pd.read_csv(config.path("results/phase4/sensor_era/regime_differences.csv")); R = R[R.contrast == "L5-L8_9"]
    bands = ["dry_red", "dry_nir", "dry_swir1", "dry_ndvi"]; fig_, ax = plt.subplots(1, 4, figsize=(12, 3))
    for j, b in enumerate(bands):
        d = R[R.band == b].reset_index(drop=True)
        for i, r in d.iterrows():
            col = {"water_pif": CAT[0], "impervious_pif": CAT[1], "forest_pif": CAT[2]}[r.pif]; ax[j].errorbar(r["diff"], i, xerr=[[r["diff"] - r.ci_lo], [r.ci_hi - r["diff"]]] if "ci_lo" in r else None, fmt="o", color=col, ms=5)
        ax[j].axvline(0, color=MUTED, lw=1); ax[j].set_yticks(range(len(d))); ax[j].set_yticklabels([f"{w[:8]} {p.replace('_pif', '')}" for w, p in zip(d.window, d.pif)] if j == 0 else [], fontsize=7); ax[j].set_title(b.replace("dry_", "dry-season "), fontsize=8)
    ax[0].set_xlabel("Landsat-5 years minus Landsat-8/9 years"); fig_.suptitle("Pseudo-invariant targets after harmonisation: Landsat-5-era years have higher red and lower NDVI on every target class (SPI-normal years, exploratory)", fontsize=8.5, y=1.06)
@fig("P4F6_validation_design")
def _():
    K = pd.read_csv(config.path("data/labels/gold/phase4/_key/phase4_gold_key.csv"))
    with rasterio.open(config.path("data/labels/gold/phase4/sampling_design/strata_30m.tif")) as s: st = s.read(1, out_shape=(s.height // 6, s.width // 6)); tr = s.transform
    fig_, ax = plt.subplots(figsize=(7, 6)); ax.imshow(np.ma.masked_equal(st, 0), cmap="Greys", alpha=0.45, interpolation="nearest", extent=[tr.c, tr.c + tr.a * s.width, tr.f + tr.e * s.height, tr.f])
    for i, (rg, d) in enumerate(K.groupby("region")): ax.scatter(d.x_utm, d.y_utm, s=9, color=CAT[i], label=f"{rg} (n={len(d)})", edgecolor="white", linewidth=0.3)
    ax.legend(fontsize=7, loc="lower left"); ax.set_xticks([]); ax.set_yticks([]); ax.grid(False)
    ax.set_title(f"Phase-4 district validation design: {len(K)} points in independent 6 km validation blocks\n(grey = 13 strata; colours = leave-one-region-out rainfall zones)", fontsize=8.5)
@fig("P4F7_p3f3_vs_products")
def _():
    X = J("results/phase4/benchmark/p3f3_vs_products_windows.json"); fig_, ax = plt.subplots(1, 3, figsize=(12, 3), sharey=False)
    for j, (w, d) in enumerate(X.items()):
        ys = sorted(int(y) for y in d)
        for i, (k, lab) in enumerate((("ours_built_share", "our P3-F3 reconstruction"), ("glc_built_share", "GLC_FCS30D"), ("wsf_built_share", "WSF-Evolution"), ("gisa_built_share", "GISA 2.0"))):
            v = [d[str(y)][k] for y in ys]; ax[j].plot([y for y, x in zip(ys, v) if x is not None], [x for x in v if x is not None], color=CAT[i], lw=2, marker="o", ms=4, label=lab)
        ax[j].set_title(w[9:], fontsize=8); ax[j].set_xlabel("epoch")
    ax[0].set_ylabel("built share of window"); ax[0].legend(fontsize=7); fig_.suptitle("Our Phase-3 reconstruction vs independent products: implausible 1990 built-up in the corridor and Baramati", fontsize=9)
json.dump({"done": done, "skipped": skipped}, open(OUT / "figures_index.json", "w"), indent=1); print(done, skipped)
