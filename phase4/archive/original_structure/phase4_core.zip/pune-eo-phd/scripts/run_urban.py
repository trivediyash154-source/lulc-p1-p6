"""Urban module (registry EXP-URB-001 expansion/LEI/fragmentation; EXP-DRV-001 conversion drivers).
Built-up series from TWO sources, analysed identically (robustness, not validation):
  ours : AOA-gated HMM built-up (EXP-LULC-T-002), epochs 2000/2005/2010/2015/2020 (1990/1995 reported only with their AOA share)
  wsf  : WSF-Evolution settled-by-year (independent product), epochs 1990-2015
Drivers: P(non-built at t0 -> built at t1) with logistic regression (standardised odds ratios), RF and XGBoost; spatial-block CV AUC
(5 hashed 3 km folds); SHAP (TreeExplainer) for XGBoost; per-window models for spatial heterogeneity. ASSOCIATIONS, not causes;
present-day road networks are excluded as endogenous (roads follow development) - road covariates PENDING a historical road source."""
import json, sys, warnings, hashlib
import numpy as np, pandas as pd, rasterio, xarray as xr
from scipy import ndimage as ndi
sys.path.insert(0, "src"); warnings.filterwarnings("ignore")
from pune_eo import config
from pune_eo.urban import expansion as U
from pune_eo.labels.splits import block_index
from pune_eo.grid import Grid
from pune_eo.modelling.registry import Experiment
W = ["pune_G30_khadakwasla_mutha", "pune_G30_baramati_agri"]          # Mulshi: < 0.5 % built - too few conversions
out = config.path("results/urban"); out.mkdir(parents=True, exist_ok=True)
def rd(p, b=1):
    with rasterio.open(p) as s: return s.read(b)
def up3(a, H, Wd): return np.pad(np.repeat(np.repeat(a, 3, 0), 3, 1), ((0, max(0, H - 3 * a.shape[0])), (0, max(0, Wd - 3 * a.shape[1]))), constant_values=np.nan)[:H, :Wd]
series = {}
for gid in W:
    P = xr.open_zarr(config.path("data/products/lulc_aoa", f"{gid}.zarr")); yrs = list(P.year.values)
    hm = P.hmm_aoa_label.values == 1; ins = P.inside_aoa.values; wsf = rd(config.path("data/labels", gid, "wsf_evolution_first_year.tif"))
    series[gid] = {"ours": {y: hm[yrs.index(y)] for y in (1990, 1995, 2000, 2005, 2010, 2015, 2020, 2025)},
                   "ours_aoa_share": {y: float(ins[yrs.index(y)].mean()) for y in (1990, 1995, 2000, 2005, 2010, 2015, 2020, 2025)},
                   "wsf": {y: (wsf > 0) & (wsf <= y) for y in (1990, 1995, 2000, 2005, 2010, 2015)}}
eU = Experiment(experiment_id="EXP-URB-001", research_question="RQ-U: How did built-up extent, expansion mode (infill/edge/outlying) and fragmentation evolve?",
                hypothesis="expansion shifts from edge growth to infill as the corridor densifies; Baramati grows by edge expansion around the town",
                dataset_version="EXP-LULC-T-002 products; WSF-Evolution v1", years=[1990, 2025], resolution_m=30, features="n/a", labels="n/a",
                split="n/a (descriptive)", model="LEI (Liu et al. 2010), class-level landscape metrics", hyperparameters={"lei_buffer": "1 cell ring, 8-connectivity", "min_patch_cells": 2}, seed=0)
res = {}
for gid, s in series.items():
    r = {"aoa_share": s["ours_aoa_share"]}
    for src in ("ours", "wsf"):
        eps = sorted(s[src]); fr = {y: U.fragmentation(s[src][y]) for y in eps}
        le = {f"{a}-{b}": {k: v for k, v in U.lei(s[src][a], s[src][b]).items() if k != "patches"} for a, b in zip(eps[:-1], eps[1:])}
        r[src] = {"fragmentation": fr, "lei": le}
    res[gid] = r
    print(gid, "built ha ours:", {y: round(v["built_area_ha"]) for y, v in r["ours"]["fragmentation"].items()}, "wsf:", {y: round(v["built_area_ha"]) for y, v in r["wsf"]["fragmentation"].items()})
    print("  LEI area shares ours:", {k: {t: round(x["area_share"], 2) for t, x in v["by_type"].items()} for k, v in r["ours"]["lei"].items() if v.get("by_type")})
    print("  LEI area shares wsf :", {k: {t: round(x["area_share"], 2) for t, x in v["by_type"].items()} for k, v in r["wsf"]["lei"].items() if v.get("by_type")}, flush=True)
json.dump(res, open(out / "urban_expansion.json", "w"), indent=1, default=str)
eU.finish(res, result="see results/urban/urban_expansion.json")

# ------------------------------------------------------------------ drivers
eD = Experiment(experiment_id="EXP-DRV-001", research_question="RQ-D: Which location factors are associated with conversion to built-up (2000->2015), and do the associations differ between landscapes?",
                hypothesis="proximity to existing built-up dominates; terrain (slope/HAND) constrains; associations differ between corridor and Baramati",
                dataset_version="EXP-LULC-T-002; WSF-Evolution; GLO-30 terrain; GHS-POP R2023A", years=[2000, 2015], resolution_m=30,
                features=["dist_built_t0", "built_density_1km_t0", "slope", "elevation", "hand", "dist_drain", "tpi_1050", "pop_density_2000", "dist_largest_patch_t0"],
                labels="response: non-built 2000 -> built 2015 (ours within AOA; WSF)", split="5 hashed 3 km block folds (spatial CV)",
                model="logistic regression, RF, XGBoost + SHAP", hyperparameters={"n_per_class_per_window": 6000}, seed=20261009)
from sklearn.linear_model import LogisticRegression
from sklearn.preprocessing import StandardScaler
from sklearn.metrics import roc_auc_score
from xgboost import XGBClassifier
from sklearn.ensemble import RandomForestClassifier
import shap
rng = np.random.default_rng(20261009); drv = {}
for gid in W:
    with rasterio.open(config.path("data/features/terrain", gid, "terrain.tif")) as s: T = s.read(); td = list(s.descriptions)
    pop = rd(config.path("data/features/covariates", gid, "ghs_pop_density_90m.tif"), 1).astype(float); pop[pop < 0] = np.nan
    H, Wd = T.shape[1:]; pop3 = up3(pop, H, Wd)
    ds = xr.open_zarr(config.path("data/products/lulc_aoa", f"{gid}.zarr")); yrs = list(ds.year.values)
    ins = ds.inside_aoa.values[yrs.index(2000)] & ds.inside_aoa.values[yrs.index(2015)]
    gj = json.loads(xr.open_zarr(config.path("data/features/cube", f"{gid}.zarr")).attrs["grid"])
    G = Grid(gid, gj["crs"], gj["res"], gj["x0"], gj["y1"], gj["width"], gj["height"], gj["corner_offset"]); bx, by = block_index(G, 3000)
    fold = np.vectorize(lambda a, b: int(hashlib.sha256(f"{a}:{b}:fold".encode()).hexdigest(), 16) % 5)(bx, by)
    water = rd(config.path("data/labels", gid, "jrc_gsw.tif")); water = (water >= 50) & (water != 255)
    for src in ("ours", "wsf"):
        b0, b1 = series[gid][src][2000], series[gid][src][2015]
        cand = ~b0 & ~water & np.isfinite(T[td.index("slope_deg")]) & (ins if src == "ours" else True)
        conv = cand & b1
        lab0, n0 = ndi.label(b0, structure=np.ones((3, 3))); sizes = ndi.sum(b0, lab0, range(1, n0 + 1)); big = lab0 == (int(np.argmax(sizes)) + 1)
        X = {"dist_built_t0": ndi.distance_transform_edt(~b0) * 30, "built_density_1km_t0": ndi.uniform_filter(b0.astype(float), 33),
             "dist_largest_patch_t0": ndi.distance_transform_edt(~big) * 30, "slope": T[td.index("slope_deg")], "elevation": T[td.index("elevation_m")],
             "hand": T[td.index("hand_m")], "dist_drain": T[td.index("dist_drainage_m")], "tpi_1050": T[td.index("tpi_1050m")], "pop_density_2000": pop3}
        names = list(X)
        r1, c1 = np.nonzero(conv); r0, c0 = np.nonzero(cand & ~b1)
        if r1.size < 200: drv[f"{gid}|{src}"] = {"status": "too few conversions", "n_conv": int(r1.size)}; continue
        k1 = rng.choice(r1.size, min(6000, r1.size), replace=False); k0 = rng.choice(r0.size, min(6000, r0.size), replace=False)
        rr = np.r_[r1[k1], r0[k0]]; cc = np.r_[c1[k1], c0[k0]]; y = np.r_[np.ones(len(k1)), np.zeros(len(k0))].astype(int)
        M = np.stack([X[n][rr, cc] for n in names], 1); ok = np.isfinite(M).all(1); M, y, f = M[ok], y[ok], fold[rr, cc][ok]
        aucs = {"logit": [], "rf": [], "xgb": []}
        for k in range(5):
            tr, te = f != k, f == k
            if te.sum() < 50 or len(np.unique(y[te])) < 2: continue
            sc = StandardScaler().fit(M[tr]); lg = LogisticRegression(max_iter=2000).fit(sc.transform(M[tr]), y[tr]); aucs["logit"].append(roc_auc_score(y[te], lg.predict_proba(sc.transform(M[te]))[:, 1]))
            rf = RandomForestClassifier(300, min_samples_leaf=5, n_jobs=2, random_state=0).fit(M[tr], y[tr]); aucs["rf"].append(roc_auc_score(y[te], rf.predict_proba(M[te])[:, 1]))
            xg = XGBClassifier(n_estimators=300, max_depth=4, learning_rate=0.05, subsample=0.8, n_jobs=2, random_state=0).fit(M[tr], y[tr]); aucs["xgb"].append(roc_auc_score(y[te], xg.predict_proba(M[te])[:, 1]))
        sc = StandardScaler().fit(M); lg = LogisticRegression(max_iter=2000).fit(sc.transform(M), y)
        xg = XGBClassifier(n_estimators=300, max_depth=4, learning_rate=0.05, subsample=0.8, n_jobs=2, random_state=0).fit(M, y)
        sv = shap.TreeExplainer(xg).shap_values(M[:3000]); imp = np.abs(sv).mean(0)
        drv[f"{gid}|{src}"] = {"n_conv": int(y.sum()), "n_nonconv": int((y == 0).sum()), "spatial_cv_auc": {k: [round(float(np.mean(v)), 3), round(float(np.std(v)), 3)] for k, v in aucs.items() if v},
                               "logit_std_odds_ratio": dict(zip(names, np.round(np.exp(lg.coef_[0]), 3).tolist())),
                               "shap_mean_abs": dict(sorted(zip(names, np.round(imp, 4).tolist()), key=lambda t: -t[1]))}
        np.savez_compressed(out / f"shap_{gid}_{src}.npz", shap=sv, X=M[:3000], names=names)
        print(gid, src, json.dumps({k: drv[f"{gid}|{src}"][k] for k in ("n_conv", "spatial_cv_auc")}), list(drv[f"{gid}|{src}"]["shap_mean_abs"])[:4], flush=True)
json.dump(drv, open(out / "conversion_drivers.json", "w"), indent=1)
eD.finish(drv, result="associations only; see results/urban/conversion_drivers.json", outputs={"shap": "results/urban/shap_<grid>_<src>.npz"})
