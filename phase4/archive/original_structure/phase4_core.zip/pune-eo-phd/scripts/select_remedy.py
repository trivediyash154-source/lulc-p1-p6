"""Pre-declared selection of the temporal-transfer variant on VAL blocks (never test):
criterion = mean |mapped built share - WSF settled share| over epochs 1990/2000/2010/2015 and the two windows with settlement
(corridor, Baramati); tie (<0.005) broken by mean GHSL change r. Writes results/temporal/remedy_selection.json"""
import json, sys
sys.path.insert(0, "src")
from pune_eo import config
S = json.load(open(config.path("results/temporal/remedies_summary.json"))); W = ["pune_G30_khadakwasla_mutha", "pune_G30_baramati_agri"]; rows = {}
for v, r in S.items():
    mae = [abs(r["val"][w][f"built_share_{y}"] - r["val"][w][f"wsf_share_{y}"]) for w in W for y in (1990, 2000, 2010, 2015)]
    ch = [r["val"][w]["ghsl_change_r"] for w in W if r["val"][w]["ghsl_change_r"] is not None]
    rows[v] = {"val_mae_built_vs_wsf": round(sum(mae) / len(mae), 4), "val_mean_ghsl_change_r": round(sum(ch) / len(ch), 4), "silver_test_2021_macro_f1": r["silver_test_2021_macro_f1"]}
best = min(rows, key=lambda v: (round(rows[v]["val_mae_built_vs_wsf"] / 0.005), -rows[v]["val_mean_ghsl_change_r"]))
json.dump({"criterion": __doc__.split("\n")[1:3], "candidates": rows, "selected": best}, open(config.path("results/temporal/remedy_selection.json"), "w"), indent=1)
print(json.dumps(rows, indent=1), "\nselected:", best)
