"""Why does the 2021-trained classifier over-predict built-up in early years? Feature medians per year on cells that are
STABLE according to independent references (no project imagery used to define them):
  stable_built : WSF settled by 1985 AND GHSL 1990 >= 0.3      deep_water : JRC occurrence >= 95
  stable_open  : WSF never settled AND GHSL 2020 < 0.02 AND JRC == 0 (land use may still change: agriculture/grass)
Output results/temporal/shift_diagnosis.csv"""
import sys, numpy as np, pandas as pd, rasterio
sys.path.insert(0, "src")
from pune_eo import config
from pune_eo.classification import baseline as B
F = ["dry_blue", "dry_red", "dry_nir", "dry_swir1", "dry_swir2", "dry_ndvi", "dry_mndwi", "dry_ndmi", "post_ndvi", "sd_nir_5"]
def rd(p, b=None):
    with rasterio.open(p) as s: return s.read(b) if b else s.read()
rows = []
for gid in ["pune_G30_khadakwasla_mutha", "pune_G30_baramati_agri", "pune_G30_mulshi_ghats"]:
    d = config.path("data/labels", gid); ds = B.open_cube(gid)
    wsf = rd(d / "wsf_evolution_first_year.tif", 1); gh = rd(d / "ghsl_built_fraction_90m.tif").astype(float); jrc = rd(d / "jrc_gsw.tif", 1).astype(float)
    H, W = wsf.shape; up = lambda a: np.pad(np.repeat(np.repeat(a, 3, 0), 3, 1), ((0, max(0, H - 3 * a.shape[0])), (0, max(0, W - 3 * a.shape[1]))), constant_values=np.nan)[:H, :W]
    S = {"stable_built": (wsf == 1985) & (up(gh[0]) >= 0.3), "deep_water": (jrc >= 95) & (jrc != 255), "stable_open": (wsf == 0) & (up(gh[6]) < 0.02) & (jrc == 0)}
    L = ds.landsat.sel(feature=F).values
    P = None
    try:
        import xarray as xr; P = xr.open_zarr(config.path("data/products/lulc", f"{gid}.zarr")).raw_label.values
    except Exception: pass
    for st, m in S.items():
        if m.sum() < 50: continue
        for i, y in enumerate(ds.year.values):
            r = {"window": gid, "stratum": st, "year": int(y), "n": int(m.sum())}
            for j, f in enumerate(F): r[f] = float(np.nanmedian(L[i, j][m]))
            if P is not None: r["raw_built_share"] = float((P[i][m] == 1).mean())
            rows.append(r)
df = pd.DataFrame(rows); df.to_csv(config.path("results/temporal/shift_diagnosis.csv"), index=False)
pd.set_option("display.width", 250)
for (w, st), g in df.groupby(["window", "stratum"]):
    print(w, st, g.n.iloc[0]); print(g[g.year.isin([1990, 1995, 1999, 2000, 2005, 2010, 2013, 2015, 2020, 2021, 2025])][["year"] + F + ["raw_built_share"]].round(3).to_string(index=False))
