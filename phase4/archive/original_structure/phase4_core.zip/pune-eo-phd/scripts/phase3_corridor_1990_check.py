"""Descriptive check (not a registered test): the Phase-2 headline '75 % of the corridor mapped built-up in 1990' re-measured the same way
(share of ALL window cells labelled built in 1990) for the Phase-3 re-fit of the 2021 configuration (XGB B3+terrain) and the selected product model (P3-F3),
next to the independent references (GHSL 1990 built-surface fraction, WSF settled by 1990)."""
import json, sys, warnings
import numpy as np, rasterio, xarray as xr, joblib
sys.path.insert(0, "src"); warnings.filterwarnings("ignore")
from pune_eo import config
from pune_eo.historical_reconstruction import features as F
out = {}
for gid in ("pune_G30_khadakwasla_mutha", "pune_G30_baramati_agri", "pune_G30_mulshi_ghats"):
    ds = xr.open_zarr(config.path("data/features/cube", f"{gid}.zarr")); fl = ds.feature.values.tolist(); L = ds.landsat.sel(year=1990).values
    X = np.concatenate([L[[fl.index(n) for n in F.B3]], ds.terrain.values]).reshape(28, -1).T; ok = np.isfinite(X).all(1)
    m = joblib.load(config.path("results/phase3/baseline/xgb_B3T_2021.joblib")); pred = np.zeros(len(X), int); pred[ok] = m.predict_proba(X[ok]).argmax(1) + 1
    with rasterio.open(config.path("results/phase3/product", gid, "recon_1990.tif")) as s: f3 = s.read(5).ravel()
    with rasterio.open(config.path("data/labels", gid, "wsf_evolution_first_year.tif")) as s: wsf = s.read(1).ravel()
    with rasterio.open(config.path("data/labels", gid, "ghsl_built_fraction_90m.tif")) as s: gh = s.read(1).astype(float)
    out[gid] = {"xgb_2021_config_built_share_1990": float((pred[ok] == 1).mean()), "p3_f3_product_built_share_1990": float((f3 == 1).mean()),
                "wsf_settled_by_1990_share": float(((wsf > 0) & (wsf <= 1990)).mean()), "ghsl_1990_mean_built_fraction": float(np.nanmean(gh))}
json.dump(out, open(config.path("results/phase3/product/corridor_1990_check.json"), "w"), indent=1); print(json.dumps(out, indent=0))
# window-wide built share by year: product (P3-F3) vs WSF settled share (WSF covers 1985-2015)
traj = {}
for gid in out:
    with rasterio.open(config.path("data/labels", gid, "wsf_evolution_first_year.tif")) as s: wsf = s.read(1)
    traj[gid] = {}
    for y in range(1990, 2027):
        with rasterio.open(config.path("results/phase3/product", gid, f"recon_{y}.tif")) as s: c = s.read(5)
        traj[gid][y] = {"product_built_share": float((c == 1).mean()), "wsf_settled_share": float(((wsf > 0) & (wsf <= y)).mean()) if y <= 2015 else None}
json.dump({"by_window_1990": out, "trajectory": traj}, open(config.path("results/phase3/product/corridor_1990_check.json"), "w"), indent=1)
for gid, t in traj.items(): print(gid[9:], {y: (round(v["product_built_share"], 3), None if v["wsf_settled_share"] is None else round(v["wsf_settled_share"], 3)) for y, v in t.items() if y in (1990, 1993, 1995, 2000, 2005, 2010, 2015, 2021, 2025)})
