"""POST-HOC supplementary analysis (not a registered test): the pooled era-matched dry-normal contrast (P3-D2) per window,
because the pooled estimate mixes windows with opposite raw contrasts. Reported as exploratory."""
import json, sys, warnings
import numpy as np
sys.path.insert(0, "src"); warnings.filterwarnings("ignore")
from pune_eo import config
from pune_eo.historical_reconstruction import het
from pune_eo.validation.stats3 import block_bootstrap_diff
src = open("scripts/run_phase3_climate.py").read(); head = src[:src.index("R = {}")]; exec(head)          # reuse the exact definitions (cell_rates, contrast, models)
out = {"note": "POST-HOC, exploratory; per-window era-matched contrasts of never-settled false built-up"}
for name in ("P3-B1", "P3-B4", "P3-B1m", "P3-B4m"):
    out[name] = {}
    for cls in ("dry", "wet"):
        raw, em = contrast(*models[name], "never_settled", "climate_class", cls)
        for g in mm.window.unique():
            w = (mm.window == g).values
            for lab_, v in (("raw", raw), ("era_matched", em)):
                ok = w & np.isfinite(v)
                out[name][f"{g[9:]}|{cls}|{lab_}"] = block_bootstrap_diff(lambda i, v=v[ok]: float(np.mean(v[i])), mm.block.values[ok]) if ok.sum() > 50 else None
json.dump(out, open(config.path("results/phase3/climate/climate_by_window_posthoc.json"), "w"), indent=1)
f = lambda d: f"{d['estimate']:+.3f} [{d['ci95'][0]:+.3f},{d['ci95'][1]:+.3f}]" if d else "n/a"
for k, v in out["P3-B1"].items(): print("B1", k, f(v))
