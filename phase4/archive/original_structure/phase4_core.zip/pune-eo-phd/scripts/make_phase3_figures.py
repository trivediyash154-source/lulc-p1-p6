"""Phase-3 publication figures (results/figures/phase3/). Each figure is drawn only from saved result files; a missing input skips that figure
and is reported (never filled with placeholder numbers)."""
import json, sys, warnings
import numpy as np, pandas as pd
import matplotlib; matplotlib.use("Agg"); import matplotlib.pyplot as plt
sys.path.insert(0, "src"); warnings.filterwarnings("ignore")
from pune_eo import config
R = config.path("results/phase3"); OUT = config.path("results/figures/phase3"); OUT.mkdir(parents=True, exist_ok=True)
W3 = ["khadakwasla_mutha", "baramati_agri", "mulshi_ghats"]; WF = {w: f"pune_G30_{w}" for w in W3}; COL = {"khadakwasla_mutha": "#1b6ca8", "baramati_agri": "#c47f17", "mulshi_ghats": "#2e8540"}
plt.rcParams.update({"font.size": 8, "axes.spines.top": False, "axes.spines.right": False, "figure.dpi": 150})
J = lambda p: json.loads(config.path(p).read_text())
reg = lambda e: J(f"experiments/registry3/{e.replace('@', '_at_')}.json")
R3load = lambda e: config.path(f"experiments/registry3/{e.replace('@', '_at_')}.json").exists() and reg(e).get("status") == "PASS"
done, skipped = [], []
def fig(name):
    def deco(f):
        try: f(); plt.savefig(OUT / f"{name}.png", bbox_inches="tight"); plt.close("all"); done.append(name)
        except Exception as e: plt.close("all"); skipped.append((name, repr(e)[:160]))
        return f
    return deco
CLIM = None
try:
    sys_h = __import__("pune_eo.historical_reconstruction.het", fromlist=["load"]); HH = sys_h.load(); CLIM = HH["climate"]
except Exception: pass

@fig("F01_validation_ladder_2021")
def _():
    a1, a1b, a3 = reg("P3-A1")["metrics"], reg("P3-A1b")["metrics"], reg("P3-A3")["metrics"]; g = J("results/phase3/gold/gold_provisional_eval.json")
    fig_, ax = plt.subplots(1, 2, figsize=(9, 3.2))
    labels = ["silver\nTEST (C)", "provisional\nAI (C)"] + [f"unseen\n{w.split('_')[0]}" for w in W3]
    vals = [a1["xgb"]["macro_f1"], g["products"]["phase3_xgb_B3T"]["unweighted"]["macro_f1"]] + [a3[WF[w]]["macro_f1"] for w in W3]
    ci = [None, g["products"]["phase3_xgb_B3T"]["ci95_unweighted"]["macro_f1"], None, None, None]
    ax[0].bar(range(5), vals, color=["#777", "#9b59b6"] + [COL[w] for w in W3])
    for i, c in enumerate(ci):
        if c: ax[0].errorbar(i, vals[i], yerr=[[vals[i] - c[0]], [c[1] - vals[i]]], color="k", capsize=3)
    ax[0].set_xticks(range(5)); ax[0].set_xticklabels(labels, fontsize=6.5); ax[0].set_ylim(0.5, 1); ax[0].set_ylabel("macro-F1 (agreement, NOT accuracy)")
    ax[0].axhline(0.979, ls=":", c="k", lw=0.8); ax[0].text(4.4, 0.981, "Phase-2 0.979", fontsize=6, ha="right")
    ax[1].bar(range(3), [a1b[WF[w]]["built_vs_GHSL2020_ge0.2"]["f1"] for w in W3], color=[COL[w] for w in W3]); ax[1].axhline(a1["xgb"]["per_class_f1"]["built_up"], ls=":", c="k")
    ax[1].set_xticks(range(3)); ax[1].set_xticklabels(W3, fontsize=7); ax[1].set_ylabel("built-up F1 vs GHSL 2020 (Tier B), all TEST cells"); ax[1].set_ylim(0, 1)
    ax[1].text(2.4, a1["xgb"]["per_class_f1"]["built_up"] + 0.01, "silver built F1", fontsize=6, ha="right"); fig_.suptitle("2021 model re-assessed: the 0.979 is silver agreement on easy cells", fontsize=9)

@fig("F02_gold_provisional_qc")
def _():
    g = J("results/phase3/gold/gold_provisional_eval.json"); fig_, ax = plt.subplots(1, 3, figsize=(10, 3))
    s = g["abstention"]["by_stratum"]; ax[0].bar(range(len(s)), list(s.values()), color="#9b59b6"); ax[0].set_xticks(range(len(s))); ax[0].set_xticklabels([k.replace("_", "\n") for k in s], fontsize=6); ax[0].set_ylabel("AI abstention rate (uncertain/ambiguous)")
    s = g["abstention"]["by_interpreter_instance"]; ax[1].bar(range(len(s)), list(s.values()), color="#8e44ad"); ax[1].set_xticks(range(len(s))); ax[1].set_xticklabels([k.split("_")[-1] for k in s], fontsize=7)
    ax[1].set_title(f"by AI instance (chi2 p={g['abstention']['interpreter_heterogeneity_chi2_p']:.1e})", fontsize=7)
    pr = g["products"]; names = [k for k in ("phase3_xgb_B3T", "phase2_raw", "phase2_hmm_aoa", "worldcover_2021", "esri_2021", "silver_l1") if k in pr]
    ax[2].barh(range(len(names)), [pr[k]["unweighted"]["macro_f1"] for k in names], color="#555"); ax[2].set_yticks(range(len(names))); ax[2].set_yticklabels(names, fontsize=7); ax[2].set_xlim(0.6, 1)
    ax[2].set_xlabel("macro-F1 vs provisional AI (non-abstained)"); fig_.suptitle(f"Provisional AI interpretation (Tier C, never gold): self-consistency kappa {g['self_consistency']['cohen_kappa_all_categories']:.2f}; Gate 1 NOT passed", fontsize=9)

def dry_years(w): return CLIM[(CLIM.window == WF[w]) & (CLIM.climate_class == "dry")].year.tolist() if CLIM is not None else []
@fig("F03_false_builtup_by_year")
def _():
    fig_, ax = plt.subplots(1, 3, figsize=(11, 3), sharey=True)
    for i, w in enumerate(W3):
        for e, st in (("P3-B1", ":"), ("P3-B4", "-"), ("P3-B4m", "--")):
            r = reg(e)["metrics"]["by_window"][WF[w]]; ys = sorted(int(k) for k in r["fbr_by_year"]); ax[i].plot(ys, [r["fbr_by_year"][str(y)] if str(y) in r["fbr_by_year"] else r["fbr_by_year"][y] for y in ys], st, label=e, lw=1.2)
        for y in dry_years(w): ax[i].axvspan(y - 0.5, y + 0.5, color="#e67e22", alpha=0.25, lw=0)
        ax[i].set_title(w, fontsize=8); ax[i].set_xlabel("year")
    ax[0].set_ylabel("false built-up rate, never-settled TEST cells (Tier B)"); ax[0].legend(fontsize=6); fig_.suptitle("Historical false built-up: single-date vs 5-year temporal models (orange = SPI-12(t-1) dry years)", fontsize=9)

@fig("F04_temporal_ablation")
def _():
    ids = ["P3-B1", "P3-B2", "P3-B3", "P3-B4", "P3-B1m", "P3-B2m", "P3-B3m", "P3-B4m", "P3-B5m@v2", "P3-B4t"]; ids = [i for i in ids if reg(i).get("metrics")]   # INVALID records here are outcome-comparator corrections; their metrics/predictions are valid (see @v2 records)
    fig_, ax = plt.subplots(1, 2, figsize=(10, 3.2))
    for k, i in enumerate(ids):
        m = reg(i)["metrics"]
        for j, w in enumerate(W3): ax[0].scatter(k + (j - 1) * 0.2, m["by_window"][WF[w]]["fbr_dry"] or np.nan, color=COL[w], s=14, label=w if k == 0 else None)
        ax[1].scatter(k, m["silver_macro_f1_2021"], color="k", s=14)
        v2 = {"P3-B5m@v2": "P3-B5m@v3"}.get(i, i.split("@")[0] + "@v2"); c = reg(v2)["metrics"]["never_settled"] if R3load(v2) else (m.get("dry_year_vs_P3-B1") or {}).get("never_settled")
        if c: ax[0].text(k, 0.95, f"{c['estimate']:+.2f}", fontsize=5.5, ha="center")
    for a in ax: a.set_xticks(range(len(ids))); a.set_xticklabels([i[3:] for i in ids], fontsize=7)
    ax[0].set_ylabel("dry-year false built-up (Tier B)"); ax[0].set_ylim(0, 1); ax[0].legend(fontsize=6); ax[1].set_ylabel("silver macro-F1 2021 TEST (Tier C)")
    fig_.suptitle("Temporal ablation (RF): numbers = pooled dry-year FBR change vs the PRE-REGISTERED comparator (B2-B4 vs B1; Bkm vs Bk; B5m, B4t vs B4m)", fontsize=8)

@fig("F05_multimodal_ablation")
def _():
    ids = [f"P3-C{i}" for i in range(1, 6)]; fig_, ax = plt.subplots(figsize=(7, 3))
    for k, i in enumerate(ids):
        m = reg(i)["metrics"]; ax.scatter(k - 0.25, m["within"]["2021"], marker="s", color="k", s=16, label="within (TEST blocks)" if k == 0 else None)
        for j, w in enumerate(W3): ax.scatter(k + (j - 0.5) * 0.18, m["unseen"][WF[w]]["macro_f1"], color=COL[w], s=16, label=f"unseen {w}" if k == 0 else None)
    ax.set_xticks(range(5)); ax.set_xticklabels(["C1 optical", "C2 SAR", "C3 opt+SAR", "C4 +terrain", "C5 +climate"], fontsize=7); ax.set_ylabel("silver macro-F1 2021"); ax.legend(fontsize=6)
    g = J("results/phase3/fusion/fusion_summary.json")["gate3"]; ax.set_title(f"Multimodal fusion, identical XGBoost/splits/seed. Gate 3 passed: {g['passed']}", fontsize=8)

@fig("F06_transfer_matrix")
def _():
    T = J("results/phase3/transfer/transfer_summary.json")["matrix"]; fsets = ["B1", "B3", "B4", "C3", "C4"]; fig_, ax = plt.subplots(1, 5, figsize=(13, 2.8))
    for k, f in enumerate(fsets):
        A = np.full((3, 3), np.nan)
        for i, s in enumerate(W3):
            for j, t in enumerate(W3):
                key = f"{s}->{t}|{f}"
                if key in T: A[i, j] = T[key]["cross"]; A[i, i] = T[key]["within"]
        im = ax[k].imshow(A, vmin=0.3, vmax=1, cmap="viridis"); ax[k].set_title(f, fontsize=8)
        for i in range(3):
            for j in range(3): ax[k].text(j, i, f"{A[i, j]:.2f}" if np.isfinite(A[i, j]) else "", ha="center", va="center", fontsize=6, color="w")
        ax[k].set_xticks(range(3)); ax[k].set_xticklabels([w[:5] for w in W3], fontsize=6); ax[k].set_yticks(range(3)); ax[k].set_yticklabels([w[:5] for w in W3] if k == 0 else [], fontsize=6)
    ax[0].set_ylabel("train window"); fig_.colorbar(im, ax=ax, fraction=0.01); fig_.suptitle("Spatial transfer (silver macro-F1; diagonal = within-window TEST blocks)", fontsize=9)

@fig("F07_domain_shift")
def _():
    j1 = J("results/phase3/transfer/transfer_summary.json")["J1"]; pairs = [k for k in j1["pairs"] if k.startswith("B3T")]; fig_, ax = plt.subplots(1, 2, figsize=(9, 3))
    ax[0].bar(range(len(pairs)), [j1["pairs"][p]["domain_auc_blockcv"] for p in pairs], color="#555"); ax[0].set_xticks(range(len(pairs))); ax[0].set_xticklabels([p.split("|")[1] for p in pairs], fontsize=6); ax[0].set_ylabel("domain-classifier AUC (block CV)"); ax[0].set_ylim(0.5, 1)
    for p in pairs:
        for k, v in j1["pairs"][p].items():
            if k.startswith("error_vs"): ax[1].plot(range(1, len(v["error_by_quintile"]) + 1), v["error_by_quintile"], marker="o", ms=3, label=k.replace("error_vs_target_prob_", ""))
    ax[1].set_xlabel("quintile of P(target domain | x)"); ax[1].set_ylabel("cross-window error rate"); ax[1].legend(fontsize=5); fig_.suptitle("Domain shift between landscapes (association only)", fontsize=9)

@fig("F08_domain_adaptation")
def _():
    j2 = J("results/phase3/transfer/transfer_summary.json")["J2"]; meths = ["none", "coral", "importance_weighting", "self_training", "fewshot_25", "fewshot_50", "fewshot_100", "fewshot_250", "target_supervised_reference"]
    fig_, ax = plt.subplots(figsize=(9, 3))
    for j, w in enumerate(W3):
        ax.plot(range(len(meths)), [j2[WF[w]][m]["macro_f1"] for m in meths], marker="o", color=COL[w], label=w)
    ax.set_xticks(range(len(meths))); ax.set_xticklabels([m.replace("_", "\n") for m in meths], fontsize=6); ax.set_ylabel("held-out window macro-F1 (TEST blocks)"); ax.legend(fontsize=6)
    ax.set_title("Domain adaptation after characterising transfer failure (two source windows -> target)", fontsize=8)

@fig("F09_label_efficiency_ssl")
def _():
    L = J("results/phase3/labels/labels_summary.json")["L1"]; fig_, ax = plt.subplots(1, 2, figsize=(9, 3)); fr = [10, 25, 50, 75, 100]
    for n, st in (("xgb", "-"), ("rf", "--")): ax[0].plot(fr, [np.mean(L["within"][n][f"{f}%"]) for f in fr], st, marker="o", ms=3, label=f"{n} within")
    for w in W3: ax[0].plot(fr, [np.mean(L["lowo"][WF[w]][f"{f}%"]) for f in fr], ":", marker="s", ms=3, color=COL[w], label=f"xgb unseen {w[:6]}")
    ax[0].set_xlabel("% of training labels"); ax[0].set_ylabel("macro-F1"); ax[0].legend(fontsize=5)
    S = J("results/phase3/ssl/ssl_summary.json")
    for m, st in (("G1_scratch", ":"), ("G2_probe", "--"), ("G3_finetune", "-"), ("xgb_B3T", "-.")):
        ks = [k for k in S["within"] if k.endswith("%")]; ax[1].plot([int(k[:-1]) for k in ks], [S["within"][k][m]["macro_f1"] for k in ks], st, marker="o", ms=3, label=m)
    ax[1].set_xlabel("% of training labels"); ax[1].set_title("self-supervised (MAE) vs supervised, within", fontsize=8); ax[1].legend(fontsize=6)

@fig("F10_active_learning")
def _():
    L2 = J("results/phase3/labels/labels_summary.json")["L2"]; fig_, ax = plt.subplots(1, 3, figsize=(11, 3), sharey=True)
    for i, w in enumerate(W3):
        for s in ("random", "entropy", "margin", "committee"):
            d = L2[WF[w]][s]; ax[i].plot(d["budget"], np.mean(d["macro_f1_runs"], 0), marker="o", ms=3, label=s)
        ax[i].axhline(L2[WF[w]]["source_only"], ls=":", c="k"); ax[i].set_title(w, fontsize=8); ax[i].set_xlabel("target labels queried")
    ax[0].set_ylabel("target TEST macro-F1"); ax[0].legend(fontsize=6); fig_.suptitle("Active-learning simulation (silver oracle) on a new landscape", fontsize=9)

@fig("F11_calibration_unseen")
def _():
    C = J("results/phase3/calibration/calibration_summary.json"); fig_, ax = plt.subplots(1, 3, figsize=(11, 3.2))
    for w in W3:
        r = C["B3T"][WF[w]]; rel = [b for b in r["H1_uncalibrated"]["reliability"] if b["n"] > 20]
        ax[0].plot([b["mean_conf"] for b in rel], [b["accuracy"] for b in rel], marker="o", ms=3, color=COL[w], label=w)
    ax[0].plot([0, 1], [0, 1], "k:", lw=0.8); ax[0].set_xlabel("confidence"); ax[0].set_ylabel("accuracy (held-out window)"); ax[0].set_title("uncalibrated reliability", fontsize=8); ax[0].legend(fontsize=6)
    meths = ["H1", "temperature", "isotonic", "platt", "ensemble"]
    for j, w in enumerate(W3):
        r = C["B3T"][WF[w]]; v = [r["H1_uncalibrated"]["ece"], r["H2"]["temperature"]["ece"], r["H2"]["isotonic"]["ece"], r["H2"]["platt"]["ece"], r["H3_ensemble5"]["ece"]]
        ax[1].plot(range(5), v, marker="o", color=COL[w])
    ax[1].axhline(0.05, ls=":", c="r"); ax[1].set_xticks(range(5)); ax[1].set_xticklabels(meths, fontsize=7); ax[1].set_ylabel("held-out ECE")
    p2 = {"khadakwasla_mutha": 0.508, "baramati_agri": 0.423, "mulshi_ghats": 0.742}
    for j, w in enumerate(W3):
        r = C["B3T"][WF[w]]["H4"]; third = np.mean([[x["coverage"] for kx, x in v.items() if kx.startswith("third")][0] for v in r["third_landscape"].values()])
        ax[2].plot(range(5), [p2[w], r["LAC"]["coverage"], r["APS"]["coverage"], r["class_conditional_LAC"]["coverage"], third], marker="o", color=COL[w])
    ax[2].axhline(0.9, ls=":", c="k"); ax[2].axhline(0.85, ls=":", c="r"); ax[2].set_xticks(range(5)); ax[2].set_xticklabels(["Phase-2\nLAC", "LAC", "APS", "class-\ncond.", "3rd-landscape\nLAC (mean)"], fontsize=6.5); ax[2].set_ylabel("90 % set coverage, held-out")
    fig_.suptitle("Calibration on unseen landscapes (B3+terrain XGBoost; maps fitted on source data only)", fontsize=9)

@fig("F12_change_detection")
def _():
    k = J("results/phase3/change/change_summary.json"); fig_, ax = plt.subplots(1, 2, figsize=(9, 3))
    s = k["K1"]["miss_attribution_share"]; ax[0].barh(range(len(s)), list(s.values()), color="#555"); ax[0].set_yticks(range(len(s))); ax[0].set_yticklabels(list(s), fontsize=7); ax[0].set_xlabel("share of timing misses")
    ax[0].set_title(f"K1: recall +-2 y {k['K1']['recall_pm2']:.2f} (urbanised cells)", fontsize=8)
    rel = [b for b in k["K2"]["p_change_binary"]["reliability"] if b["n"] > 20]; ax[1].plot([b["mean_conf"] for b in rel], [b["accuracy"] for b in rel], marker="o"); ax[1].plot([0.5, 1], [0.5, 1], "k:")
    ax[1].set_xlabel("confidence of P(transition 1991-2026)"); ax[1].set_ylabel("observed frequency"); ax[1].set_title(f"K2: 80 % sets cover WSF year {k['K2']['coverage80_exact_wsf_year']:.0%}; ECE {k['K2']['p_change_binary']['ece']:.2f}", fontsize=8)

@fig("F13_harmonisation_generalisation")
def _():
    h = J("results/phase3/harmonization/harmonization_generalisation.json"); B = ["blue", "green", "red", "nir08", "swir16", "swir22", "ndvi"]; fig_, ax = plt.subplots(figsize=(7, 3))
    for j, w in enumerate(W3):
        if w in h["by_window"]: ax.bar(np.arange(7) + (j - 1) * 0.27, [h["by_window"][w][b]["bias_after"] for b in B], 0.27, color=COL[w], label=f"{w} ({h['n_pairs_by_window'].get(w, 0)} pairs)")
    ax.axhspan(-0.01, 0.01, color="g", alpha=0.1); ax.set_xticks(range(7)); ax.set_xticklabels(B); ax.set_ylabel("median residual after s2_to_oli_v1"); ax.legend(fontsize=6)
    ax.set_title("Sensor harmonisation fitted on the corridor does not transfer unchanged", fontsize=8)

@fig("F14_reconstruction_product")
def _():
    import rasterio
    p = J("results/phase3/product/product_summary.json"); w = WF["khadakwasla_mutha"]; yrs = [1993, 2004, 2013, 2021]; fig_, ax = plt.subplots(2, 4, figsize=(11, 5))
    from matplotlib.colors import ListedColormap
    cm = ListedColormap(["#d62728", "#f2c14e", "#2ca02c", "#1f77b4"])
    for i, y in enumerate(yrs):
        with rasterio.open(config.path("results/phase3/product", w, f"recon_{y}.tif")) as s: c, e, era = s.read(5), s.read(6) / 200, s.tags()["era"]
        ax[0, i].imshow(c, cmap=cm, vmin=1, vmax=4, interpolation="nearest"); ax[0, i].set_title(f"{y} ({era})", fontsize=7); ax[1, i].imshow(e, cmap="magma", vmin=0, vmax=1)
        for a in ax[:, i]: a.set_xticks([]); a.set_yticks([])
    ax[0, 0].set_ylabel("most likely class"); ax[1, 0].set_ylabel("normalised entropy"); fig_.suptitle(f"Era-aware probabilistic reconstruction ({p['selected']}), khadakwasla_mutha — NOT validated by Tier A; Gate 6 not passed", fontsize=9)

@fig("F15_gate_dashboard")
def _():
    g = J("results/phase3/gates.json"); fig_, ax = plt.subplots(figsize=(11, 2.8)); ax.axis("off")
    short = {"G1": "0/558 human (Tier-A) labels", "G2": "5-yr window: pooled dry-year FBR -49 % vs single-date; Baramati still 0.51",
             "G3": "S1 adds +0.03..+0.06 unseen macro-F1, CI > 0 in 3/3 windows (S1 era)", "G4": "B4+S1+terrain beats B1 on 3/3 held-out windows (* designed after C results)",
             "G5": "source-calibrated LAC coverage 0.63-0.69; ECE > 0.05 in some windows", "G6": "needs G1; dry FBR Baramati 0.18; block MAE > 0.10 (early era)"}
    rows = [[k, ("PASSED" + ("*" if k == "G4" else "")) if v["passed"] else ("NOT PASSED" if v["passed"] is False else "NOT EVALUATED"), short.get(k, v["evidence"][:80])] for k, v in g.items()]
    t = ax.table(cellText=rows, colLabels=["gate", "status", "evidence (full text: results/phase3/gates.json)"], loc="center", cellLoc="left", colWidths=[0.06, 0.12, 0.82]); t.auto_set_font_size(False); t.set_fontsize(7.5); t.scale(1, 1.3)
    for (r, c), cell in t.get_celld().items():
        if r > 0 and c == 1: cell.set_facecolor("#c8e6c9" if rows[r - 1][1].startswith("PASSED") else "#ffcdd2")
    ax.set_title("Phase-3 decision gates (criteria committed in configs/phase3.yaml before the experiments)", fontsize=9)
json.dump({"done": done, "skipped": skipped}, open(OUT / "figures_index.json", "w"), indent=1); print("done", done); print("skipped", skipped)
