"""Temporal L1 LULC 1990-2026 on the 3 benchmark windows: calibrated XGBoost (best baseline by VAL) -> per-year posteriors ->
HMM (transition matrix by Baum-Welch on TRAIN-block pixels) -> Viterbi labels + smoothed posteriors.
Outputs data/products/lulc/<grid>.zarr ; registry EXP-LULC-T-001 ; evaluation in scripts/eval_temporal_lulc.py"""
import json, sys, time, warnings
import numpy as np, pandas as pd, xarray as xr, joblib, rasterio
sys.path.insert(0, "src"); warnings.filterwarnings("ignore")
from sklearn.isotonic import IsotonicRegression
from pune_eo import config
from pune_eo.classification import baseline as B, temporal as H
from pune_eo.modelling.registry import Experiment
W = ["khadakwasla_mutha", "baramati_agri", "mulshi_ghats"]; YEAR = 2021; SEED = 20261004; YEARS = list(range(1990, 2027))
feats = json.load(open(config.path("results/classification/feature_pruning.json")))["kept"]
e = Experiment(experiment_id="EXP-LULC-T-001", research_question="RQ-T: Can defensible L1 land-cover states be reconstructed 1990-2026 and does temporal (HMM) "
               "modelling separate real change from sensor/cloud/model noise?",
               hypothesis="HMM smoothing lowers spurious year-to-year flips without degrading agreement with independent multi-epoch references (GHSL, WSF, JRC)",
               dataset_version="cube G30 local_pune_g30_v2; labels silver v1", years=YEARS, resolution_m=30, features=feats, labels="silver_l1 2021 (training only)",
               split="train blocks (fit), val blocks (early stopping + isotonic calibration + nothing else); HMM fitted on train-block pixels",
               model="XGBoost (isotonic-calibrated) + 4-state HMM (Baum-Welch, Viterbi, forward-backward)", hyperparameters={}, seed=SEED)
t0 = time.time()
df = B.samples(W, YEAR, feats, cap={1: 4000, 2: 4000, 3: None}, seed=SEED)
tr, va, te = df[df.split == 1], df[df.split == 2], df[df.split == 3]
m = B.make_model("xgb", SEED); B.fit("xgb", m, tr[feats], tr.label.values, va[feats], va.label.values)
# isotonic calibration (one-vs-rest on VAL), renormalised
pv = m.predict_proba(va[feats]); iso = []
for k, c in enumerate(B.CLASSES):
    ir = IsotonicRegression(out_of_bounds="clip", y_min=1e-4, y_max=1 - 1e-4).fit(pv[:, k], (va.label.values == c).astype(float)); iso.append(ir)
def calib(p):
    q = np.stack([iso[k].predict(p[:, k]) for k in range(p.shape[1])], 1); return q / q.sum(1, keepdims=True)
def ece(p, y, bins=15):
    conf = p.max(1); pred = np.asarray(B.CLASSES)[p.argmax(1)]; out = 0.0
    for lo in np.linspace(0, 1, bins + 1)[:-1]:
        s = (conf > lo) & (conf <= lo + 1 / bins)
        if s.any(): out += s.mean() * abs((pred[s] == y[s]).mean() - conf[s].mean())
    return float(out)
pt = m.predict_proba(te[feats]); cal = {"test_ece_raw": round(ece(pt, te.label.values), 4), "test_ece_isotonic": round(ece(calib(pt), te.label.values), 4)}
print("calibration", cal, flush=True)
mdir = config.path("results/models"); mdir.mkdir(parents=True, exist_ok=True)
joblib.dump({"model": m, "isotonic": iso, "features": feats, "classes": B.CLASSES}, mdir / "EXP-LULC-T-001_xgb_iso.joblib")
prior = np.array([(tr.label.values == c).mean() for c in B.CLASSES])
# per-year posteriors
post, valid, shapes = {}, {}, {}
for w in W:
    gid = B.window_grid_id(w); ds = B.open_cube(w); Hh, Ww = ds.terrain.shape[1:]; shapes[w] = (Hh, Ww)
    P = np.zeros((len(YEARS), 4, Hh * Ww), np.float32); V = np.zeros((len(YEARS), Hh * Ww), bool)
    for i, y in enumerate(YEARS):
        X = B.feature_stack(ds, y, feats).reshape(len(feats), -1).T
        V[i] = np.isfinite(X[:, feats.index("dry_red")]) & np.isfinite(X[:, feats.index("dry_nir")])
        P[i] = calib(m.predict_proba(X)).T
    post[w], valid[w] = P, V; print(w, "posteriors done", round(time.time() - t0), flush=True)
# HMM transition matrix from TRAIN-block pixels only (sample)
rng = np.random.default_rng(SEED); E_fit = []
for w in W:
    with rasterio.open(config.path("data/labels", B.window_grid_id(w), "splits.tif")) as s: sp = s.read(1).ravel()
    idx = np.flatnonzero(sp == 1); idx = rng.choice(idx, min(15000, idx.size), replace=False)
    E_fit.append(H.emissions(post[w][:, :, idx], prior, valid[w][:, idx]))
A, p0, hist = H.baum_welch(np.concatenate(E_fit, axis=2), 4, iters=40)
print("A diag", np.round(np.diag(A), 4), "iters", len(hist), flush=True)
out = config.path("data/products/lulc"); out.mkdir(parents=True, exist_ok=True); stats = {}
for w in W:
    gid = B.window_grid_id(w); Hh, Ww = shapes[w]; N = Hh * Ww
    E = H.emissions(post[w], prior, valid[w]); vit = np.empty((len(YEARS), N), np.int8); gam = np.empty((len(YEARS), 4, N), np.float32)
    for c0 in range(0, N, 40000):
        sl = slice(c0, min(c0 + 40000, N)); vit[:, sl] = H.viterbi(E[:, :, sl], A, p0); gam[:, :, sl] = H.forward_backward(E[:, :, sl], A, p0)[0]
    raw = post[w].argmax(1).astype(np.int8)
    ds0 = B.open_cube(w)
    xr.Dataset({"raw_label": (("year", "y", "x"), (raw + 1).reshape(len(YEARS), Hh, Ww)),
                "hmm_label": (("year", "y", "x"), (vit + 1).reshape(len(YEARS), Hh, Ww)),
                "raw_prob": (("year", "class", "y", "x"), np.round(post[w] * 250).astype(np.uint8).reshape(len(YEARS), 4, Hh, Ww)),
                "hmm_prob": (("year", "class", "y", "x"), np.round(gam * 250).astype(np.uint8).reshape(len(YEARS), 4, Hh, Ww)),
                "observed": (("year", "y", "x"), valid[w].reshape(len(YEARS), Hh, Ww))},
               coords={"year": YEARS, "class": [B.CLASS_NAMES[c] for c in B.CLASSES], "y": ds0.y.values, "x": ds0.x.values},
               attrs={"labels": "1 built_up, 2 agriculture, 3 natural_vegetation, 4 water", "prob_scale": "uint8 / 250",
                      "experiment": "EXP-LULC-T-001", "transition_matrix": json.dumps(np.round(A, 5).tolist())}).to_zarr(out / f"{gid}.zarr", mode="w")
    stats[gid] = {"flip_rate_raw_mean": float(H.flip_rate(raw).mean()), "flip_rate_hmm_mean": float(H.flip_rate(vit).mean()),
                  "share_pixels_any_change_raw": float((H.flip_rate(raw) > 0).mean()), "share_pixels_any_change_hmm": float((H.flip_rate(vit) > 0).mean())}
    print(gid, stats[gid], flush=True)
e.rec["hyperparameters"] = {"xgb_best_iteration": int(m.best_iteration), "calibration": "isotonic one-vs-rest on val", "hmm_iters": len(hist)}
e.finish({"calibration": cal, "transition_matrix": np.round(A, 5).tolist(), "initial": np.round(p0, 4).tolist(), "baum_welch_loglik": hist, "flip_stats": stats},
         result="products written; evaluation against independent references in EXP-LULC-T-EVAL",
         outputs={"products": "data/products/lulc/<grid>.zarr", "model": "results/models/EXP-LULC-T-001_xgb_iso.joblib"},
         n_samples={"train": len(tr), "val": len(va), "test": len(te)})
