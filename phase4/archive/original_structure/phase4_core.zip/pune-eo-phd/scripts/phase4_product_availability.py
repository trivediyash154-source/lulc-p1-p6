"""Phase 4: probe which existing land-cover / built-up / water products are reachable from this environment and what Pune needs from each.
Writes data/inventory/product_availability.json (status checked live; class/method notes are from the producers' documentation and are
re-checked against the user guides when a product is acquired)."""
import json, sys, requests
sys.path.insert(0, "src")
from pune_eo import config
from pune_eo.provenance import utcnow
S = requests.Session(); T = 60
def code(u):
    try: return S.head(u, timeout=T, allow_redirects=True).status_code
    except Exception as e: return repr(e)[:80]
def zen(rid):
    try:
        r = S.get(f"https://zenodo.org/api/records/{rid}", timeout=T).json(); return {"title": r["metadata"]["title"], "doi": r.get("doi"), "license": r["metadata"].get("license", {}).get("id"), "n_files": len(r.get("files", []))}
    except Exception as e: return {"error": repr(e)[:100]}
pc = {c["id"]: c for c in S.get("https://planetarycomputer.microsoft.com/api/stac/v1/collections", timeout=T).json()["collections"]}
pcs = lambda i: {"on_planetary_computer": i in pc, "temporal": pc[i]["extent"]["temporal"]["interval"] if i in pc else None}
P = {
 "GLC_FCS30D": {"producer": "Zhang, Liu et al. (AIRCAS); ESSD 2024", "resolution_m": 30, "temporal": "1985, 1990, 1995 (5-yearly) + annual 2000-2022", "classes": "35 fine classes (LCCS-based) / 10 basic",
   "method": "Landsat time series, continuous change detection + local adaptive classification (producer)", "known_limitations": "class definitions differ from ours (impervious vs built-up; cropland subclasses); temporal consistency enforced by change detection; producer accuracy is global, not Pune-specific",
   "access": "Zenodo record 15063683 (CC-BY 4.0), zip per 10-degree band; Pune needs tiles E70N20 + E75N20 from GLC_FCS30D_19852022maps_E70-E75.zip (~390 MB via HTTP range reads)", "zenodo": zen(15063683), "reachable": True, "status": "ACQUIRABLE"},
 "GISA_2.0": {"producer": "Ren, Huang et al.; ISPRS J. 2025", "resolution_m": 30, "temporal": "first year of impervious surface 1972-2021", "classes": "impervious (first-year), non-impervious",
   "method": "multi-source Landsat-based impervious mapping (producer)", "known_limitations": "impervious != built-up land cover; irreversible by construction; early years sparse", "access": "Zenodo 14848113 tile 20N_60E (CC-BY 4.0)", "zenodo": zen(14848113), "reachable": True, "status": "ACQUIRABLE"},
 "GAIA": {"producer": "Gong et al.; RSE 2020", "resolution_m": 30, "temporal": "annual impervious 1985-2018", "classes": "impervious first-year", "method": "Landsat, GEE",
   "known_limitations": "impervious only; irreversible", "access": "Google Earth Engine (Tsinghua/FROM-GLC/GAIA/v10) or PCL StarCloud portal (account)", "reachable": "GEE not configured here (no earthengine-api, no credentials)", "status": "NEEDS_USER_GEE"},
 "Dynamic_World": {"producer": "Google / WRI; Sci. Data 2022", "resolution_m": 10, "temporal": "2015-06 onwards, per Sentinel-2 image", "classes": "9 class probabilities", "method": "per-image deep model on S2",
   "known_limitations": "per-scene probabilities need temporal compositing; S2-based (shares evidence with WorldCover/Esri/our gold chips); no pre-2015 history", "access": "Google Earth Engine only (GOOGLE/DYNAMICWORLD/V1)", "reachable": "GEE not configured here", "status": "NEEDS_USER_GEE"},
 "GHSL_BUILT_S_R2023A": {"producer": "JRC", "resolution_m": 100, "temporal": "1975-2030 5-yearly (2025/2030 projected)", "classes": "built-up surface fraction", "method": "multitemporal Landsat/S2 + modelling",
   "known_limitations": "fractional, 100 m (Mollweide); epochs are modelled", "access": "JRC FTP (CC-BY 4.0); code exists (labels.sources.ghsl_built)", "reachable": code("https://jeodpp.jrc.ec.europa.eu/ftp/jrc-opendata/GHSL/") == 200, "status": "IN_REPO_WINDOWS; ACQUIRABLE_DISTRICT"},
 "WSF_Evolution": {"producer": "DLR (Marconcini et al. 2021)", "resolution_m": 30, "temporal": "settlement extent 1985-2015 (first year)", "classes": "settled / not", "method": "Landsat temporal statistics",
   "known_limitations": "settlement extent (includes mixed settled cells); ends 2015", "access": "DLR geoservice tiles (code exists: labels.sources.wsf_evolution)", "reachable": code("https://download.geoservice.dlr.de/") in (200, 302), "status": "IN_REPO_WINDOWS; ACQUIRABLE_DISTRICT"},
 "ESA_CCI_LC": {"producer": "ESA CCI", "resolution_m": 300, "temporal": "annual 1992-2020", "classes": "22 LCCS classes", "method": "AVHRR/SPOT-VGT/PROBA-V/MERIS", "known_limitations": "300 m: too coarse for 30 m pixel comparison; area trends only",
   **pcs("esa-cci-lc"), "status": "ACQUIRABLE"},
 "ESA_WorldCover": {"producer": "ESA", "resolution_m": 10, "temporal": "2020, 2021", "classes": "11", **pcs("esa-worldcover"), "known_limitations": "silver-label source (used for training) -> NOT independent of our models", "status": "IN_REPO (windows + G240 district mode)"},
 "Esri_IO_LULC": {"producer": "Esri / Impact Observatory", "resolution_m": 10, "temporal": "annual 2017-2023", "classes": "9", **pcs("io-lulc-annual-v02"), "known_limitations": "silver-label source (2020-21) -> NOT independent; other years usable as Tier C", "status": "IN_REPO (windows)"},
 "JRC_GSW": {"producer": "JRC", "resolution_m": 30, "temporal": "1984-2021 (occurrence, monthly history)", "classes": "water occurrence", **pcs("jrc-gsw"), "known_limitations": "surface water only", "status": "IN_REPO (windows + G240)"},
 "ALOS_FNF": {"producer": "JAXA", "resolution_m": 25, "temporal": "2015-2020", "classes": "forest / non-forest", **pcs("alos-fnf-mosaic"), "known_limitations": "L-band SAR forest definition", "status": "ACQUIRABLE"},
 "MS_Building_Footprints": {"producer": "Microsoft", "resolution_m": "vector", "temporal": "2014-2023 imagery mix", **pcs("ms-buildings"), "known_limitations": "undated per building; modern only", "status": "ACQUIRABLE (modern built-up check)"},
 "India_Decadal_LULC_1985_1995_2005": {"producer": "Roy et al. 2015 (ORNL DAAC)", "resolution_m": 100, "temporal": "1985, 1995, 2005", "classes": "national classification", "access": "NASA Earthdata login",
   "reachable": code("https://daac.ornl.gov/"), "known_limitations": "100 m; Landsat/IRS visual-digital interpretation; class scheme differs", "status": "NEEDS_USER_EARTHDATA"},
 "NRSC_LULC_50K": {"producer": "NRSC/ISRO (Bhuvan)", "resolution_m": "1:50,000", "temporal": "2005-06, 2011-12, 2015-16", "access": "Bhuvan viewing/WMS; bulk download restricted", "reachable": code("https://bhuvan.nrsc.gov.in/"),
   "known_limitations": "licence restricts redistribution", "status": "VIEW_ONLY (useful for human interpreters as context, not as data)"},
}
json.dump({"checked_utc": utcnow(), "products": P}, open(config.path("data/inventory/product_availability.json"), "w"), indent=1, default=str)
for k, v in P.items(): print(k, "|", v["status"])
