"""Phase-3 group A: re-assess the 2021 result (P3-A1, P3-A1b, P3-A3, P3-A4). Model = Phase-2 best configuration (XGBoost, Landsat
seasonal + terrain = B3 + terrain, 28 features) re-fitted on the HET 2021 train cells; RF reported alongside.
A1  silver reference agreement, TEST blocks                       (Tier C)
A1b independent products over ALL test-block cells: built vs GHSL 2020 (>= 0.2 built surface in the parent 90 m cell),
    water vs JRC occurrence >= 50                                (Tier B)
A3  unseen landscape (leave-one-window-out)                      (Tier C, held-out window)
A4  temporal hold-out: 2020 silver; Tier-B history (FBR on never-settled, stable-built recall) by year"""
import json, sys, warnings
import numpy as np, pandas as pd, rasterio, xarray as xr
from sklearn.metrics import f1_score, confusion_matrix
sys.path.insert(0, "src"); warnings.filterwarnings("ignore")
from pune_eo import config
from pune_eo.historical_reconstruction import het, features as F
from pune_eo.classification import baseline as B
from pune_eo.validation import registry3 as R3
from pune_eo.calibration import metrics as CM
H = het.load(); M = H["meta"]; YEARS = H["info"]["years"]; SEED = 20261025; OUT = config.path("results/phase3/baseline"); OUT.mkdir(parents=True, exist_ok=True)
def Xof(year, idx): X, n = F.build(H, "B3", year, idx); return np.hstack([X, H["T"][idx]]), n + H["info"]["tfeatures"]
def fit(model_name, idx_tr, idx_va):
    Xtr, _ = Xof(2021, idx_tr); Xva, _ = Xof(2021, idx_va); m = B.make_model(model_name, SEED)
    B.fit(model_name, m, Xtr, M.silver.values[idx_tr], Xva, M.silver.values[idx_va]); return m
def full_eval(m, model_name, idx, year=2021):
    X, _ = Xof(year, idx); p = m.predict_proba(X); y = M.silver.values[idx]; yh = np.asarray(B.CLASSES)[p.argmax(1)]
    e = B.evaluate(y, yh); cm = np.array(e["confusion_matrix"]["counts"]); labs = e["confusion_matrix"]["labels"]
    iou = {l: float(cm[i, i] / (cm[i].sum() + cm[:, i].sum() - cm[i, i])) if (cm[i].sum() + cm[:, i].sum() - cm[i, i]) else None for i, l in enumerate(labs)}
    cal = CM.all_metrics(p, np.vectorize({c: i for i, c in enumerate(B.CLASSES)}.get)(y))
    pairs = {"agri->natveg": int(((y == 2) & (yh == 3)).sum()), "natveg->agri": int(((y == 3) & (yh == 2)).sum()), "agri->built": int(((y == 2) & (yh == 1)).sum()), "built->agri": int(((y == 1) & (yh == 2)).sum())}
    return {"n": int(len(y)), "macro_f1": e["macro_f1"], "per_class_f1": {k: v["f1"] for k, v in e["per_class"].items()}, "per_class_iou": iou, "calibration": cal,
            "confusion": e["confusion_matrix"], "key_confusions": pairs, "quantity_dis": e["quantity_disagreement"], "allocation_dis": e["allocation_disagreement"]}
silver = M.silver.between(1, 4).values; TR = np.flatnonzero(silver & (M.split == 1).values); VA = np.flatnonzero(silver & (M.split == 2).values); TE = np.flatnonzero(silver & (M.split == 3).values)
res = {}
# ---------------- A1
run = R3.Run("P3-A1"); a1 = {}
for mn in ("xgb", "rf"):
    m = fit(mn, TR, VA); a1[mn] = full_eval(m, mn, TE)
    if mn == "xgb": mx = m
a1["phase2_registry_value"] = json.loads(config.path("experiments/registry/EXP-L1-B-xgb-landsat_terrain.json").read_text())["metrics"]["test"]["macro_f1"]
run.complete(a1, "NA", f"silver agreement (HET test cells): XGB macro-F1 {a1['xgb']['macro_f1']:.3f}, RF {a1['rf']['macro_f1']:.3f}; Phase-2 value {a1['phase2_registry_value']:.3f} (all test cells). NOT ground truth.",
             n_samples={"train": len(TR), "test": len(TE)}); res["A1"] = a1; print("A1", a1["xgb"]["macro_f1"], a1["rf"]["macro_f1"], flush=True)
# ---------------- A1b independent products over ALL test-block cells (full maps 2021)
run = R3.Run("P3-A1b"); a1b = {}
for gid in M.window.unique():
    ds = xr.open_zarr(config.path("data/features/cube", f"{gid}.zarr")); d = config.path("data/labels", gid)
    with rasterio.open(d / "splits.tif") as s: sp = s.read(1)
    with rasterio.open(d / "ghsl_built_fraction_90m.tif") as s: gh = s.read(7).astype(float)
    with rasterio.open(d / "jrc_gsw.tif") as s: jrc = s.read(1).astype(float)
    Hh, Ww = sp.shape; gh3 = het._up3(gh, Hh, Ww); f = ds.feature.values.tolist()
    L = ds.landsat.sel(year=2021).values; X = np.concatenate([L[[f.index(n) for n in F.B3]], ds.terrain.values]).reshape(28, -1).T
    yh = np.asarray(B.CLASSES)[mx.predict_proba(X).argmax(1)].reshape(Hh, Ww); te = sp == 3
    out = {}
    for name, pred, ref in (("built_vs_GHSL2020_ge0.2", yh == 1, gh3 >= 0.2), ("water_vs_JRC_occ_ge50", yh == 4, (jrc >= 50) & (jrc != 255))):
        v = te & np.isfinite(gh3) if "built" in name else te & (jrc != 255)
        tp = (pred & ref & v).sum(); fp = (pred & ~ref & v).sum(); fn = (~pred & ref & v).sum()
        out[name] = {"precision": float(tp / max(tp + fp, 1)), "recall": float(tp / max(tp + fn, 1)), "f1": float(2 * tp / max(2 * tp + fp + fn, 1)), "iou": float(tp / max(tp + fp + fn, 1)),
                     "ref_share": float(ref[v].mean()), "pred_share": float(pred[v].mean()), "n_cells": int(v.sum())}
    a1b[gid] = out
run.complete(a1b, "SUPPORTED" if all(a1b[g]["built_vs_GHSL2020_ge0.2"]["f1"] < a1["xgb"]["per_class_f1"]["built_up"] for g in a1b) else "NOT_SUPPORTED",
             "built-up F1 vs GHSL over all test cells: " + ", ".join(f"{g[9:]} {v['built_vs_GHSL2020_ge0.2']['f1']:.2f}" for g, v in a1b.items()) + f" (silver built F1 {a1['xgb']['per_class_f1']['built_up']:.2f})")
res["A1b"] = a1b; print("A1b", {g[9:]: round(v["built_vs_GHSL2020_ge0.2"]["f1"], 3) for g, v in a1b.items()}, flush=True)
# ---------------- A3 unseen landscape
run = R3.Run("P3-A3"); a3 = {}
for g in M.window.unique():
    tr = np.flatnonzero(silver & (M.split == 1).values & (M.window != g).values); va = np.flatnonzero(silver & (M.split == 2).values & (M.window != g).values)
    te = np.flatnonzero(silver & (M.window == g).values); m = fit("xgb", tr, va); a3[g] = full_eval(m, "xgb", te)
run.complete(a3, "SUPPORTED" if all(v["macro_f1"] < a1["xgb"]["macro_f1"] for v in a3.values()) else "NOT_SUPPORTED",
             "held-out macro-F1: " + ", ".join(f"{g[9:]} {v['macro_f1']:.3f} (ECE {v['calibration']['ece']:.3f})" for g, v in a3.items()))
res["A3"] = a3; print("A3", {g[9:]: round(v["macro_f1"], 3) for g, v in a3.items()}, flush=True)
# ---------------- A4 temporal hold-out
run = R3.Run("P3-A4"); ev = np.flatnonzero((M.split == 3).values); P = np.zeros((len(ev), len(YEARS)), np.int8)
for j, y in enumerate(YEARS): X, _ = Xof(y, ev); P[:, j] = np.asarray(B.CLASSES)[mx.predict_proba(X).argmax(1)]
m_ = M.iloc[ev].reset_index(drop=True); a4 = {"silver_2020": full_eval(mx, "xgb", TE, 2020), "by_window": {}}
for g in m_.window.unique():
    w = (m_.window == g).values; ns, sb = w & m_.never_settled.values, w & m_.stable_built.values
    a4["by_window"][g] = {"fbr_by_year": dict(zip(YEARS, np.round((P[ns] == 1).mean(0), 4).tolist())), "built_recall_by_year": dict(zip(YEARS, np.round((P[sb] == 1).mean(0), 4).tolist())),
                          "n_never_settled": int(ns.sum()), "n_stable_built": int(sb.sum())}
np.save(OUT / "pred_A4_xgb_B3T.npy", P)
fb90 = {g[9:]: v["fbr_by_year"][1990] for g, v in a4["by_window"].items()}
run.complete(a4, "SUPPORTED" if a4["silver_2020"]["macro_f1"] > 0.9 and max(fb90.values()) > 0.1 else "INCONCLUSIVE",
             f"2020 silver macro-F1 {a4['silver_2020']['macro_f1']:.3f}; 1990 false built-up on never-settled test cells {fb90}")
res["A4"] = a4; print("A4", a4["silver_2020"]["macro_f1"], fb90, flush=True)
json.dump(res, open(OUT / "baseline_reassessment.json", "w"), indent=1, default=str)
import joblib; joblib.dump(mx, config.path("results/phase3/baseline/xgb_B3T_2021.joblib"))
