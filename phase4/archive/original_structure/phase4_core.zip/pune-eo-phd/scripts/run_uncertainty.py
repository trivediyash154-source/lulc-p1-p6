"""Uncertainty experiments (registry EXP-UNC-001), L1 XGBoost on Landsat+terrain (2021):
  U1 split conformal (LAC, alpha=0.1) calibrated on VAL blocks -> coverage + set size on TEST blocks, and on a held-out WINDOW (LOWO)
     (exchangeability is violated across landscapes: the test of whether the guarantee survives spatial transfer)
  U2 5-member bootstrap ensemble -> predictive entropy / vote disagreement; AUROC for flagging errors (test blocks and LOWO)
  U3 AOA dissimilarity index (Meyer & Pebesma 2021) of LOWO held-out cells: error rate inside vs outside AOA
  U4 maps for 2021: ensemble entropy, conformal set size, AOA (results/uncertainty/*.tif)"""
import json, sys, warnings, hashlib
import numpy as np, rasterio
from sklearn.metrics import roc_auc_score
sys.path.insert(0, "src"); warnings.filterwarnings("ignore")
from pune_eo import config
from pune_eo.classification import baseline as B
from pune_eo.uncertainty.aoa import AOA
from pune_eo.labels.splits import block_index
from pune_eo.grid import Grid
from pune_eo.io import write_cog
from pune_eo.modelling.registry import Experiment
W = ["pune_G30_khadakwasla_mutha", "pune_G30_baramati_agri", "pune_G30_mulshi_ghats"]; SEED = 20261011; ALPHA = 0.1
feats = json.load(open(config.path("results/classification/feature_pruning.json")))["kept"]
e = Experiment(experiment_id="EXP-UNC-001", research_question="RQ-UNC: Are the L1 model's uncertainty estimates informative, and do they survive spatial transfer?",
               hypothesis="conformal coverage holds within-window but drops on an unseen window; ensemble entropy and AOA-DI flag errors (AUROC > 0.7)",
               dataset_version="cube G30 local_pune_g30_v2; labels silver v1", years=[2021], resolution_m=30, features=feats, labels="silver_l1",
               split="train/val/test 3 km blocks; LOWO for transfer", model="XGBoost (5 bootstrap members) + split conformal (LAC) + AOA", hyperparameters={"alpha": ALPHA, "members": 5}, seed=SEED)
df = B.samples(W, 2021, feats, cap={1: 4000, 2: 4000, 3: 20000}, seed=SEED); rng = np.random.default_rng(SEED)
enc = {c: i for i, c in enumerate(B.CLASSES)}
def fit_members(tr, va, n=5):
    ms = []
    for k in range(n):
        idx = rng.choice(len(tr), len(tr), replace=True); m = B.make_model("xgb", SEED + k); B.fit("xgb", m, tr[feats].values[idx], tr.label.values[idx], va[feats].values, va.label.values); ms.append(m)
    return ms
def ens_proba(ms, X): return np.stack([m.predict_proba(X) for m in ms])          # (M, N, K)
def entropy(p): return -(p * np.log(np.clip(p, 1e-9, 1))).sum(-1)
def conformal_q(p_cal, y_cal):
    s = 1 - p_cal[np.arange(len(y_cal)), y_cal]; n = len(s); return float(np.quantile(s, np.ceil((n + 1) * (1 - ALPHA)) / n, method="higher"))
def sets(p, q): return p >= 1 - q
def evaluate(ms, q, te, aoa=None):
    P = ens_proba(ms, te[feats].values); pm = P.mean(0); y = np.vectorize(enc.get)(te.label.values); pred = pm.argmax(1); err = pred != y
    S = sets(pm, q); cov = S[np.arange(len(y)), y]; votes = (P.argmax(-1) != pred[None]).mean(0); H = entropy(pm)
    r = {"n": int(len(y)), "error_rate": float(err.mean()), "conformal_coverage": float(cov.mean()), "mean_set_size": float(S.sum(1).mean()),
         "auroc_entropy_flags_error": float(roc_auc_score(err, H)) if 0 < err.sum() < len(err) else None,
         "auroc_vote_disagreement_flags_error": float(roc_auc_score(err, votes)) if 0 < err.sum() < len(err) and votes.std() > 0 else None,
         "coverage_by_class": {B.CLASS_NAMES[c]: float(cov[y == enc[c]].mean()) for c in B.CLASSES if (y == enc[c]).any()}}
    if aoa is not None:
        di = aoa.di(te[feats].values); ins = di <= aoa.threshold
        r["aoa"] = {"share_inside": float(ins.mean()), "error_inside": float(err[ins].mean()) if ins.any() else None, "error_outside": float(err[~ins].mean()) if (~ins).any() else None,
                    "auroc_di_flags_error": float(roc_auc_score(err, di)) if 0 < err.sum() < len(err) else None}
    return r
def folds_for(d):
    out = np.zeros(len(d), int)
    for gid in d.window.unique():
        gj = json.loads(B.open_cube(gid).attrs["grid"]); G = Grid(gid, gj["crs"], gj["res"], gj["x0"], gj["y1"], gj["width"], gj["height"], gj["corner_offset"])
        bx, by = block_index(G, 3000); m = (d.window == gid).values
        out[m] = [int(hashlib.sha256(f"{bx[r, c]}:{by[r, c]}:fold".encode()).hexdigest(), 16) % 5 for r, c in zip(d.row.values[m], d.col.values[m])]
    return out
res = {}
tr, va, te = df[df.split == 1], df[df.split == 2], df[df.split == 3]
ms = fit_members(tr, va); pv = ens_proba(ms, va[feats].values).mean(0); q = conformal_q(pv, np.vectorize(enc.get)(va.label.values))
imp = ms[0].get_booster().get_score(importance_type="gain"); wts = np.array([imp.get(f"f{i}", 0.0) for i in range(len(feats))]) + 1e-6
aoa = AOA(tr[feats].values, wts, folds_for(tr), seed=SEED)
res["within_window_test_blocks"] = evaluate(ms, q, te, aoa); res["conformal_qhat"] = q; res["aoa_threshold"] = aoa.threshold
print("within", json.dumps(res["within_window_test_blocks"]), flush=True)
for held in W:
    trw, vaw, tew = df[(df.window != held) & (df.split == 1)], df[(df.window != held) & (df.split == 2)], df[df.window == held]
    msw = fit_members(trw, vaw, 3); pvw = ens_proba(msw, vaw[feats].values).mean(0); qw = conformal_q(pvw, np.vectorize(enc.get)(vaw.label.values))
    aw = AOA(trw[feats].values, wts, folds_for(trw), seed=SEED)
    res[f"lowo_{held}"] = evaluate(msw, qw, tew, aw); print(held, json.dumps(res[f"lowo_{held}"]), flush=True)
# U4 maps 2021
od = config.path("results/uncertainty"); od.mkdir(parents=True, exist_ok=True)
for gid in W:
    ds = B.open_cube(gid); X = B.feature_stack(ds, 2021, feats); Fn, Hh, Ww = X.shape; Xf = X.reshape(Fn, -1).T
    P = ens_proba(ms, Xf); pm = P.mean(0); H = entropy(pm).reshape(Hh, Ww); S = sets(pm, q).sum(1).reshape(Hh, Ww); di = aoa.di(Xf).reshape(Hh, Ww)
    gj = json.loads(ds.attrs["grid"]); G = Grid(gid, gj["crs"], gj["res"], gj["x0"], gj["y1"], gj["width"], gj["height"], gj["corner_offset"])
    write_cog(od / f"uncertainty_2021_{gid}.tif", np.stack([H, S.astype(np.float32), di, (di <= aoa.threshold).astype(np.float32)]).astype(np.float32), G, nodata=None, dtype="float32",
              descriptions=["ensemble_entropy_nats", "conformal_set_size_alpha0.1", "aoa_dissimilarity_index", "inside_aoa"])
    res.setdefault("maps_2021", {})[gid] = {"mean_entropy": float(H.mean()), "share_set_size_gt1": float((S > 1).mean()), "share_inside_aoa": float((di <= aoa.threshold).mean())}
json.dump(res, open(od / "uncertainty_summary.json", "w"), indent=1)
e.finish(res, result="see results/uncertainty/uncertainty_summary.json", outputs={"maps": "results/uncertainty/uncertainty_2021_<grid>.tif"})
