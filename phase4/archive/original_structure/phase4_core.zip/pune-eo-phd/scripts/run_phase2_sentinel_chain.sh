#!/bin/sh
# Phase-2 Sentinel products on the 30 m benchmark windows (priority order: label epoch 2020-21 first).
cd "$(dirname "$0")/.."
for w in baramati_agri khadakwasla_mutha mulshi_ghats; do python3 scripts/run_sentinel.py sentinel2 --grid G30 --window $w --years 2020-2021 --threads 4; done
for w in baramati_agri khadakwasla_mutha mulshi_ghats; do python3 scripts/run_sentinel.py sentinel1 --grid G30 --window $w --years 2020-2021 --threads 4; done
for w in khadakwasla_mutha mulshi_ghats baramati_agri; do python3 scripts/run_sentinel.py sentinel1 --grid G30 --window $w --years 2017-2019 --threads 4; python3 scripts/run_sentinel.py sentinel1 --grid G30 --window $w --years 2022-2025 --threads 4; done
python3 scripts/run_sentinel.py sentinel2 --grid G30 --window baramati_agri --years 2019-2019 --threads 4
python3 scripts/run_sentinel.py sentinel2 --grid G30 --window baramati_agri --years 2022-2024 --threads 4
