"""Phase-3 start audit: verify Phase-2 FILES (not the summary). Writes results/audit/phase2_audit.json.
Checks: registry integrity; WSF decoding in every label folder + no experiment that used WSF ran before the fix; S2 reader version of
every Sentinel-2 product family; valid/no-data separation in S2 status rasters; gold form/KML/chips; label rasters vs their JSON;
map products vs exports; files cited by phase2_results.md exist."""
import json, glob, re, sys, zipfile
from pathlib import Path
import numpy as np, rasterio, xarray as xr, pandas as pd
sys.path.insert(0, "src")
from pune_eo import config
from pune_eo.provenance import utcnow
R = config.ROOT; W = ["pune_G30_khadakwasla_mutha", "pune_G30_baramati_agri", "pune_G30_mulshi_ghats"]
checks, facts = [], {}
def chk(name, status, evidence, detail=None): checks.append({"check": name, "status": status, "evidence": evidence, "detail": detail})
# ---------------- registry
REG = {Path(p).stem: json.loads(Path(p).read_text()) for p in sorted(glob.glob(str(R / "experiments/registry/*.json")))}
st = pd.Series({k: v.get("status") for k, v in REG.items()}).value_counts().to_dict(); facts["registry_status_counts"] = st
bad = [k for k, v in REG.items() if v.get("status") == "DONE" and not v.get("metrics")]
chk("registry: every DONE record has metrics", "PASS" if not bad else "FAIL", f"{len(REG)} records {st}; DONE without metrics: {bad}")
chk("registry: no RUNNING/FAILED leftovers", "PASS" if not ({"RUNNING", "FAILED"} & set(st)) else "FAIL", str(st))
facts["pending"] = {k: {"reason": v.get("reason"), "needs": v.get("needs")} for k, v in REG.items() if v.get("status") == "PENDING"}
facts["done_by_group"] = pd.Series([re.sub(r"-.*", "", k.replace("EXP-", "")) for k, v in REG.items() if v.get("status") == "DONE"]).value_counts().to_dict()
# ---------------- WSF corrected everywhere
wsf_fix = None
for gid in W:
    p = R / "data/labels" / gid / "wsf_evolution_first_year.tif"
    with rasterio.open(p) as s: a = s.read(1)
    u = np.unique(a); ok = set(u.tolist()) <= ({0} | set(range(1985, 2016)))
    meta = json.loads((p.with_suffix(".json")).read_text()); wsf_fix = max(wsf_fix or "", meta["created_utc"])
    chk(f"WSF decoding valid ({gid})", "PASS" if ok and (a == 0).any() and (a > 0).any() and (a == 0).mean() > 0.3 else "FAIL",
        f"values ⊆ {{0,1985..2015}}: {ok}; never-settled share {float((a == 0).mean()):.3f}; settled share {float((a > 0).mean()):.3f}; created {meta['created_utc']}")
users = [k for k, v in REG.items() if "WSF" in json.dumps(v.get("labels", "")) + json.dumps(v.get("research_question", "")) + json.dumps(v.get("dataset_version", ""))
         or "wsf" in json.dumps(v.get("metrics", ""))[:20000].lower()]
early = [k for k in users if REG[k].get("started_utc") and REG[k]["started_utc"] < wsf_fix]
chk("no WSF-using experiment ran before the WSF fix", "PASS" if not early else "FAIL", f"{len(users)} WSF-using records; latest WSF rebuild {wsf_fix}; started before: {early}")
# ---------------- Sentinel-2 reader version + valid/no-data separation
cur = config.config_hash("sentinel2", "grid", "temporal", "study_area"); s2fam = {}
for p in glob.glob(str(R / "data/manifests/jobs/sentinel2_*.json")):
    d = json.loads(Path(p).read_text()); s2fam[Path(p).stem] = sorted({v.get("version", "").split("|")[-1] for v in d.values()})
facts["s2_job_versions"] = s2fam; facts["s2_current_hash"] = cur
g30_ok = all(v == [cur] for k, v in s2fam.items() if k.startswith("sentinel2_pune_G30_"))     # window products used in Phase 2 models
chk("S2 30 m window products built with corrected SCL reader (reader_version 2)", "PASS" if g30_ok else "FAIL", f"current hash {cur}; {s2fam}")
old = [k for k, v in s2fam.items() if v != [cur]]
chk("pre-fix S2 products quarantined from Phase-3 modelling", "WARN" if old else "PASS", f"old-reader families: {old} -> excluded from Phase 3 (configs/phase3.yaml: quarantine)")
for gid in W:
    q = R / "data/composites" / gid / "2021/sentinel2/monthly/2021-07/qa.tif"; c = R / "data/composites" / gid / "2021/sentinel2/monthly/2021-07/observation_count.tif"
    with rasterio.open(q) as s: qa = s.read(); dsc = list(s.descriptions)
    with rasterio.open(c) as s: nc = s.read(1)
    nobs, ncl = qa[dsc.index("n_observed")], qa[dsc.index("n_clear")]
    viol = int((ncl > nobs).sum()) + int((nc != ncl).sum())
    chk(f"S2 valid/no-data separation ({gid}, 2021-07)", "PASS" if viol == 0 else "FAIL",
        f"cells with n_clear > n_observed or count != n_clear: {viol}; never-observed cells: {int((nobs == 0).sum())}; observed-not-clear: {int(((nobs > 0) & (ncl == 0)).sum())} "
        "(monsoon 'never observed' includes scenes excluded at manifest level for scene cloud > 80 %)")
# ---------------- gold sample files
gold = {}
for gid in W:
    d = R / "data/labels/gold" / gid; f = pd.read_csv(d / "gold_form.csv"); lab_cols = [c for c in f.columns if c.startswith("label_L1_")]
    nlab = int(f[lab_cols].notna().sum().sum()); chips = sorted((d / "chips").glob("*.png")); kml = (d / "gold_cells.kml").read_text().count("<Placemark")
    gold[gid] = {"points": len(f), "labelled_entries": nlab, "chips": len(chips), "kml_placemarks": kml, "strata": f.stratum.value_counts().to_dict(),
                 "status_values": f.status.unique().tolist(), "stratum_column_present": "stratum" in f.columns}
    chk(f"gold files consistent ({gid})", "PASS" if len(f) == len(chips) == kml else "FAIL", f"{len(f)} rows, {len(chips)} chips, {kml} KML placemarks, labelled entries {nlab}")
facts["gold"] = gold; tot = sum(v["points"] for v in gold.values()); facts["gold_total"] = tot
chk("gold sample interpreted", "FAIL", f"{tot} points, 0 labelled entries — Tier A validation does not exist yet", "blocks every ground-truth accuracy claim")
chk("gold form is blind", "WARN", "gold_form.csv carries the 'stratum' column (= silver class): an interpreter would see the reference product's answer",
    "Phase 3 builds a blind form without stratum, in randomised order")
# ---------------- label rasters vs JSON
for gid in W:
    d = R / "data/labels" / gid; sj = json.loads((d / "silver_labels.json").read_text())["stats"]
    with rasterio.open(d / "silver_l1.tif") as s: l1 = s.read(1)
    names = config.load("labels")["level1_classes"]; ok = all(int((l1 == c).sum()) == sj["l1_counts"][names[c]] for c in range(1, 7))
    with rasterio.open(d / "splits.tif") as s: sp = s.read(1)
    sjs = json.loads((d / "splits.json").read_text())["stats"]
    ok2 = int((sp == 3).sum()) == sjs["cells"]["test"] and sjs["block_size_m"] == 3000
    chk(f"label rasters match their provenance JSON ({gid})", "PASS" if ok and ok2 else "FAIL", f"silver counts match: {ok}; splits 3 km & counts match: {ok2}")
# ---------------- maps
for gid in W:
    P = xr.open_zarr(R / "data/products/lulc_aoa" / f"{gid}.zarr"); lab = P.hmm_aoa_label.values
    ex = R / "results/export" / gid / "lulc_l1_hmm_aoa_1990_2026.tif"
    with rasterio.open(ex) as s: e = s.read()
    chk(f"map product == exported COG ({gid})", "PASS" if np.array_equal(e, lab.astype(np.uint8)) else "FAIL",
        f"{lab.shape[0]} years; classes {sorted(np.unique(lab).tolist())}; experiment {P.attrs.get('experiment')}, variant {P.attrs.get('variant')}")
# ---------------- files cited by the results doc
doc = (R / "docs/phase2_results.md").read_text(); cited = sorted(set(re.findall(r"`((?:results|data|docs|configs)/[^`*<>]+?)`", doc)))
missing = [c for c in cited if not (R / c).exists()]
chk("files cited in phase2_results.md exist", "PASS" if not missing else "WARN", f"{len(cited)} cited; missing: {missing}")
facts["phase2_headline"] = {"best_2021_macro_f1_vs_silver": REG["EXP-L1-B-xgb-landsat_terrain"]["metrics"]["test"]["macro_f1"],
                            "lowo_range": [float(pd.read_csv(R / "results/classification/lowo_summary.csv").macro_f1.min()), float(pd.read_csv(R / "results/classification/lowo_summary.csv").macro_f1.max())]}
out = {"created_utc": utcnow(), "checks": checks, "facts": facts, "status_counts": pd.Series([c["status"] for c in checks]).value_counts().to_dict()}
(R / "results/audit/phase2_audit.json").write_text(json.dumps(out, indent=1, default=str))
for c in checks: print(f"[{c['status']:<4}] {c['check']}: {c['evidence'][:200]}")
print(out["status_counts"])
