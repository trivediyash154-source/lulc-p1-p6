"""Phase-3 group H (uncertainty calibration on UNSEEN landscapes) — pre-registered P3-H1..H4.
Phase-2 baseline to beat: LOWO split-conformal (LAC, alpha 0.1) coverage 0.508 / 0.423 / 0.742 (docs/phase2_results.md).
Design (leave-one-window-out, 2021 silver, Tier C):
  model      : XGBoost on landsat_terrain (B3 + terrain = 'B3T') and the S1 variant (C4 = B3 + S1 + terrain), trained on 2 windows' TRAIN blocks,
               early stopping on half A of their VAL blocks.
  calibrate  : every map / conformal threshold is fitted on half B of the SOURCE val blocks (blocks split by hash, never pixels).
  test       : all silver cells of the held-out window.
  selection  : the calibration map used for Gate 5 is chosen on SOURCE data only (lowest ECE on half A when fitted on half B) — never on the target.
  H1 uncalibrated ; H2 temperature / isotonic / Platt ; H3 5-member block-bootstrap ensemble ; H4 conformal LAC, APS, class-conditional LAC
  H4 also: third-landscape calibration = model trained on ONE source window, conformal threshold fitted on the OTHER source window, tested on target.
Gate 5: held-out ECE <= 0.05 AND 90 % conformal coverage >= 0.85 in every window (selected map + LAC)."""
import json, sys, warnings
import numpy as np
sys.path.insert(0, "src"); warnings.filterwarnings("ignore")
from pune_eo import config
from pune_eo.historical_reconstruction import het, features as F
from pune_eo.classification import baseline as B
from pune_eo.calibration import metrics as CM
from pune_eo.validation import registry3 as R3
H = het.load(); M = H["meta"]; SEED = 20261029; OUT = config.path("results/phase3/calibration"); OUT.mkdir(parents=True, exist_ok=True)
WIN = ["pune_G30_khadakwasla_mutha", "pune_G30_baramati_agri", "pune_G30_mulshi_ghats"]; SH = {w: w[9:] for w in WIN}
sil = M.silver.between(1, 4).values; yv = M.silver.values; split = M.split.values; win = M.window.values; blk = M.block.values; ALPHA = 0.1
import hashlib; half = np.array([int(hashlib.md5(b.encode()).hexdigest(), 16) % 2 for b in blk])   # block-level split of source val
def X_(fs, cells):
    if fs == "B3T": X, _ = F.build(H, "B3", 2021, cells); return np.hstack([X, H["T"][cells]])
    return F.build(H, fs, 2021, cells)[0]
class Fitted:
    def __init__(s, m, present): s.m, s.present = m, present
    def predict_proba(s, X): out = np.full((len(X), 4), 1e-6); out[:, [c - 1 for c in s.present]] = s.m.predict_proba(X); return out / out.sum(1, keepdims=True)
def fit(fs, tr, va, seed=SEED):
    ytr = yv[tr]; present = sorted(set(ytr.tolist())); enc = {c: i for i, c in enumerate(present)}; vk = np.isin(yv[va], present)
    m = B.make_model("xgb", seed); m.fit(X_(fs, tr), np.vectorize(enc.get)(ytr), eval_set=[(X_(fs, va)[vk], np.vectorize(enc.get)(yv[va][vk]))], verbose=False); return Fitted(m, present)
def met(p, y): d = CM.all_metrics(p, y - 1); return {k: d[k] for k in ("ece", "classwise_ece", "brier", "nll", "accuracy", "mean_confidence", "reliability")}
from pune_eo.calibration.conformal import lac_threshold as lac_q, lac_sets, aps_threshold, aps_sets as _aps_sets, classcond_thresholds as cc_q, classcond_sets as cc_sets, coverage
def aps_q(p, y, rng): return aps_threshold(p, y, ALPHA, rng)
def aps_sets(p, q, rng): return _aps_sets(p, q, rng)
def cov(S, y): return coverage(S, y, ["built_up", "agriculture", "natural_vegetation", "water"])
R = {}; rng = np.random.default_rng(SEED)
for fs in ("B3T", "C4"):
    R[fs] = {}
    for t in WIN:
        og = win != t; tr = np.flatnonzero(sil & og & (split == 1)); vaA = np.flatnonzero(sil & og & (split == 2) & (half == 0)); vaB = np.flatnonzero(sil & og & (split == 2) & (half == 1))
        te = np.flatnonzero(sil & (win == t)); yte, yA, yB = yv[te], yv[vaA], yv[vaB]
        m = fit(fs, tr, vaA); pte, pA, pB = m.predict_proba(X_(fs, te)), m.predict_proba(X_(fs, vaA)), m.predict_proba(X_(fs, vaB))
        r = {"n_test": int(len(te)), "H1_uncalibrated": met(pte, yte)}
        maps = {"temperature": CM.Temperature().fit(pB, yB - 1), "isotonic": CM.Isotonic().fit(pB, yB - 1), "platt": CM.Platt().fit(pB, yB - 1)}
        r["H2"] = {k: met(v.transform(pte), yte) for k, v in maps.items()}
        if hasattr(maps["temperature"], "T"): r["H2"]["temperature"]["T"] = maps["temperature"].T
        src_sel = {k: CM.ece(v.transform(pA), yA - 1) for k, v in maps.items()}; src_sel["none"] = CM.ece(pA, yA - 1); sel = min(src_sel, key=src_sel.get)
        r["selection_on_source_halfA_ece"] = src_sel; r["selected_map"] = sel
        # ensemble: 5 members trained on block-bootstrap resamples of the source train blocks
        ub = np.unique(blk[tr]); mem = []
        for e in range(5):
            rr = np.random.default_rng(SEED + 100 + e); pick = set(rr.choice(ub, len(ub), replace=True)); idx = tr[np.isin(blk[tr], list(pick))]
            mem.append(fit(fs, idx, vaA, seed=SEED + e).predict_proba(X_(fs, te)))
        pens = np.mean(mem, 0); r["H3_ensemble5"] = met(pens, yte); r["H3_ensemble5"]["mean_member_disagreement"] = float(np.mean([np.mean(mm.argmax(1) != pens.argmax(1)) for mm in mem]))
        # conformal (thresholds on source half B; selected map applied first)
        f = (lambda p: p) if sel == "none" else maps[sel].transform; pBc, ptec = f(pB), f(pte)
        q = lac_q(pBc, yB); qa = aps_q(pBc, yB, np.random.default_rng(1)); qc = cc_q(pBc, yB)
        r["H4"] = {"LAC": {"q": q, **cov(lac_sets(ptec, q), yte)}, "APS": {"q": qa, **cov(aps_sets(ptec, qa, np.random.default_rng(2)), yte)},
                   "class_conditional_LAC": {"q": qc, **cov(cc_sets(ptec, qc), yte)},
                   "source_halfA_LAC_coverage": cov(lac_sets(f(pA), q), yA)["coverage"]}
        # third-landscape calibration: train on one source window, calibrate on the other source window, test on target
        srcs = [s for s in WIN if s != t]; tl = {}
        for s_tr, s_cal in (srcs, srcs[::-1]):
            m1 = fit(fs, np.flatnonzero(sil & (win == s_tr) & (split == 1)), np.flatnonzero(sil & (win == s_tr) & (split == 2)))
            own_cal = np.flatnonzero(sil & (win == s_tr) & (split == 2)); third = np.flatnonzero(sil & (win == s_cal)); p_t = m1.predict_proba(X_(fs, te))
            q_own = lac_q(m1.predict_proba(X_(fs, own_cal)), yv[own_cal]); q_3 = lac_q(m1.predict_proba(X_(fs, third)), yv[third])
            tl[f"train_{SH[s_tr]}"] = {"source_calibrated": {"q": q_own, **cov(lac_sets(p_t, q_own), yte)}, f"third_landscape_calibrated_{SH[s_cal]}": {"q": q_3, **cov(lac_sets(p_t, q_3), yte)}}
        r["H4"]["third_landscape"] = tl
        r["gate5"] = {"ece_selected": r["H2"][sel]["ece"] if sel != "none" else r["H1_uncalibrated"]["ece"], "lac_coverage": r["H4"]["LAC"]["coverage"]}
        r["gate5"]["passed"] = bool(r["gate5"]["ece_selected"] <= 0.05 and r["gate5"]["lac_coverage"] >= 0.85)
        R[fs][t] = r; print(fs, SH[t], "ECE raw", round(r["H1_uncalibrated"]["ece"], 3), "sel", sel, round(r["gate5"]["ece_selected"], 3), "LAC cov", round(r["H4"]["LAC"]["coverage"], 3), "APS", round(r["H4"]["APS"]["coverage"], 3), flush=True)
json.dump(R, open(OUT / "calibration_summary.json", "w"), indent=1, default=float)
def line(fs, k): return ", ".join(f"{SH[t]} {k(R[fs][t]):.3f}" for t in WIN)
R3.Run("P3-H1").complete({fs: {SH[t]: R[fs][t]["H1_uncalibrated"] for t in WIN} for fs in R}, "NA", "uncalibrated held-out ECE B3T: " + line("B3T", lambda r: r["H1_uncalibrated"]["ece"]) + "; C4: " + line("C4", lambda r: r["H1_uncalibrated"]["ece"]),
                         outputs={"summary": "results/phase3/calibration/calibration_summary.json"})
for eid, key, fn in (("P3-H2", "H2", lambda r: min(v["ece"] for v in r["H2"].values())), ("P3-H3", "H3_ensemble5", lambda r: r["H3_ensemble5"]["ece"])):
    ok = all(fn(R[fs][t]) <= 0.05 for fs in R for t in WIN); bad = any(fn(R[fs][t]) > 0.05 for fs in R for t in WIN)
    sel_ok = all((R[fs][t]["H2"][R[fs][t]["selected_map"]]["ece"] if R[fs][t]["selected_map"] != "none" else R[fs][t]["H1_uncalibrated"]["ece"]) <= 0.05 for fs in R for t in WIN) if eid == "P3-H2" else ok
    R3.Run(eid).complete({fs: {SH[t]: R[fs][t][key] for t in WIN} for fs in R} | ({"selected": {fs: {SH[t]: R[fs][t]["selected_map"] for t in WIN} for fs in R}} if eid == "P3-H2" else {}),
                         "SUPPORTED" if sel_ok else "NOT_SUPPORTED", f"held-out ECE (B3T): " + line("B3T", fn) + "; C4: " + line("C4", fn) + ("; source-selected map: " + ", ".join(f"{SH[t]} {R['B3T'][t]['selected_map']}" for t in WIN) if eid == "P3-H2" else ""))
cv = lambda r: r["H4"]["LAC"]["coverage"]
R3.Run("P3-H4").complete({fs: {SH[t]: R[fs][t]["H4"] for t in WIN} for fs in R}, "SUPPORTED" if all(cv(R[fs][t]) >= 0.85 for fs in R for t in WIN) else "NOT_SUPPORTED",
                         "90 % LAC coverage held-out B3T: " + line("B3T", cv) + "; C4: " + line("C4", cv) + "; APS B3T: " + line("B3T", lambda r: r["H4"]["APS"]["coverage"]) + " (Phase 2: 0.508/0.423/0.742)")
g5 = {fs: {SH[t]: R[fs][t]["gate5"] for t in WIN} for fs in R}; json.dump(g5, open(OUT / "gate5.json", "w"), indent=1)
print("GATE5", {fs: all(v["passed"] for v in g5[fs].values()) for fs in g5})
