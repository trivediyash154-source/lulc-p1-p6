"""Land-change HINDCAST (registry EXP-HC-001) - the gate for any scenario output.
Train transition potential on 2000->2010 conversions (features at 2000), predict 2010->2020 (features at 2010) with quantity
extrapolated from 2000-2010 (Markov-type quantity), allocate the most suitable non-built cells. Compare with:
  persistence (no change), random allocation (same quantity), distance-only allocation (closest to existing built-up).
Metrics on the 2010->2020 change: figure of merit (FoM), hits/misses/false alarms, quantity & allocation disagreement
(Pontius & Millones 2011), at 30 m and aggregated to 300 m (multi-resolution).
Built-up series: ours (AOA-gated HMM, cells inside AOA in 2000/2010/2020) and GHSL (built fraction >= 0.2 at 90 m -> G30; independent)."""
import json, sys, warnings
import numpy as np, rasterio, xarray as xr
from scipy import ndimage as ndi
sys.path.insert(0, "src"); warnings.filterwarnings("ignore")
from pune_eo import config
from pune_eo.modelling.registry import Experiment
from xgboost import XGBClassifier
W = ["pune_G30_khadakwasla_mutha", "pune_G30_baramati_agri"]; SEED = 20261010; rng = np.random.default_rng(SEED)
def rd(p, b=1):
    with rasterio.open(p) as s: return s.read(b)
def up3(a, H, Wd): return np.pad(np.repeat(np.repeat(a, 3, 0), 3, 1), ((0, max(0, H - 3 * a.shape[0])), (0, max(0, Wd - 3 * a.shape[1]))), constant_values=np.nan)[:H, :Wd]
e = Experiment(experiment_id="EXP-HC-001", research_question="RQ-H: Can a transition-potential model trained on 2000-2010 reproduce 2010-2020 built-up change better than null models?",
               hypothesis="FoM(model) > FoM(distance-only) > FoM(random) > 0 = FoM(persistence) at 30 m and 300 m",
               dataset_version="EXP-LULC-T-002 built-up; GHSL R2023A; GLO-30; GHS-POP", years=[2000, 2010, 2020], resolution_m=30,
               features=["dist_built", "built_density_1km", "slope", "hand", "elevation", "dist_drain", "pop_density"], labels="observed built-up 2010 (training), 2020 (hindcast test)",
               split="temporal hold-out: train 2000->2010, test 2010->2020", model="XGBoost transition potential + quantity extrapolation", hyperparameters={"n_estimators": 300, "max_depth": 4}, seed=SEED)
def fom(obs0, obs1, pred1, valid):
    oc = obs1 & ~obs0 & valid; pc = pred1 & ~obs0 & valid; hits = (oc & pc).sum(); miss = (oc & ~pc).sum(); fa = (pc & ~oc).sum()
    return {"fom": float(hits / max(hits + miss + fa, 1)), "hits": int(hits), "misses": int(miss), "false_alarms": int(fa),
            "observed_change_cells": int(oc.sum()), "predicted_change_cells": int(pc.sum())}
def agg(a, valid, k=10):
    H, Wd = a.shape[0] // k * k, a.shape[1] // k * k
    return (np.where(valid, a, 0)[:H, :Wd].reshape(H // k, k, Wd // k, k).sum(axis=(1, 3)), valid[:H, :Wd].reshape(H // k, k, Wd // k, k).sum(axis=(1, 3)))
def pontius_change(obs0, obs1, pred1, valid, k=10):
    """quantity/allocation disagreement of predicted vs observed BUILT share at k*30 m cells (multi-resolution)."""
    o, n = agg(obs1.astype(float), valid, k); p, _ = agg(pred1.astype(float), valid, k); m = n > 0
    q = abs(p[m].sum() - o[m].sum()) / n[m].sum(); tot = np.abs(p[m] - o[m]).sum() / n[m].sum()
    return {"quantity": float(q), "allocation": float(tot - q), "total": float(tot)}
res = {}
for gid in W:
    with rasterio.open(config.path("data/features/terrain", gid, "terrain.tif")) as s: T = s.read(); td = list(s.descriptions)
    H, Wd = T.shape[1:]; pop = rd(config.path("data/features/covariates", gid, "ghs_pop_density_90m.tif"), None) if False else None
    with rasterio.open(config.path("data/features/covariates", gid, "ghs_pop_density_90m.tif")) as s: pop = s.read().astype(float)
    pop[pop < 0] = np.nan; popd = {2000: up3(pop[0], H, Wd), 2010: up3(pop[1], H, Wd)}
    with rasterio.open(config.path("data/labels", gid, "ghsl_built_fraction_90m.tif")) as s: gh = s.read().astype(float)
    water = rd(config.path("data/labels", gid, "jrc_gsw.tif")); water = (water >= 50) & (water != 255)
    P = xr.open_zarr(config.path("data/products/lulc_aoa", f"{gid}.zarr")); yrs = list(P.year.values)
    ins = P.inside_aoa.values[[yrs.index(y) for y in (2000, 2010, 2020)]].all(0)
    S = {"ours": ({y: P.hmm_aoa_label.values[yrs.index(y)] == 1 for y in (2000, 2010, 2020)}, ins & ~water),
         "ghsl": ({y: up3(gh[[1990, 1995, 2000, 2005, 2010, 2015, 2020].index(y)], H, Wd) >= 0.2 for y in (2000, 2010, 2020)}, np.isfinite(up3(gh[0], H, Wd)) & ~water)}
    for src, (B_, valid) in S.items():
        valid = valid & np.isfinite(T[td.index("slope_deg")])
        for y in B_: B_[y] = B_[y] & valid | (B_[y] & ~valid)            # keep built outside valid for distance features
        def feats(b, y):
            return np.stack([ndi.distance_transform_edt(~b) * 30, ndi.uniform_filter(b.astype(float), 33), T[td.index("slope_deg")], T[td.index("hand_m")],
                             T[td.index("elevation_m")], T[td.index("dist_drainage_m")], popd[y]], -1)
        F0 = feats(B_[2000], 2000); cand0 = valid & ~B_[2000]; conv = cand0 & B_[2010]
        r1, c1 = np.nonzero(conv); r0, c0 = np.nonzero(cand0 & ~B_[2010])
        if r1.size < 200: res[f"{gid}|{src}"] = {"status": "too few 2000-2010 conversions", "n": int(r1.size)}; continue
        k1 = rng.choice(r1.size, min(8000, r1.size), replace=False); k0 = rng.choice(r0.size, min(16000, r0.size), replace=False)
        X = np.r_[F0[r1[k1], c1[k1]], F0[r0[k0], c0[k0]]]; y = np.r_[np.ones(len(k1)), np.zeros(len(k0))]
        m = XGBClassifier(n_estimators=300, max_depth=4, learning_rate=0.05, subsample=0.8, n_jobs=2, random_state=SEED).fit(X, y)
        F1 = feats(B_[2010], 2010); cand1 = valid & ~B_[2010]
        rate = (B_[2010] & valid).sum() - (B_[2000] & valid).sum(); n_new = int(max(rate, 0))          # same absolute quantity per decade (linear extrapolation)
        rr, cc = np.nonzero(cand1); pot = m.predict_proba(F1[rr, cc])[:, 1]
        def alloc(score):
            out = B_[2010].copy(); o = np.argsort(-score)[:n_new]; out[rr[o], cc[o]] = True; return out
        preds = {"persistence": B_[2010].copy(), "random": alloc(rng.random(rr.size)), "distance_only": alloc(-F1[rr, cc, 0]), "xgb_potential": alloc(pot)}
        r = {"n_train_conv": int(len(k1)), "quantity_predicted_cells": n_new, "quantity_observed_cells": int((B_[2020] & valid & ~B_[2010]).sum()),
             "quantity_error_pct": float(100 * (n_new - (B_[2020] & valid & ~B_[2010]).sum()) / max((B_[2020] & valid & ~B_[2010]).sum(), 1))}
        for name, pr in preds.items():
            r[name] = {"30m": fom(B_[2010], B_[2020], pr, valid), "pontius_300m": pontius_change(B_[2010], B_[2020], pr, valid, 10),
                       "fom_300m_share": None}
            o, n = agg((B_[2020] & ~B_[2010]).astype(float), valid); p, _ = agg((pr & ~B_[2010]).astype(float), valid); mm = n > 0
            r[name]["change_share_corr_300m"] = float(np.corrcoef(o[mm] / n[mm], p[mm] / n[mm])[0, 1]) if (p[mm].std() > 0 and o[mm].std() > 0) else None
        res[f"{gid}|{src}"] = r
        print(gid, src, {k: (round(v["30m"]["fom"], 3), v["change_share_corr_300m"] and round(v["change_share_corr_300m"], 3)) for k, v in r.items() if isinstance(v, dict)},
              "qty err %", round(r["quantity_error_pct"], 1), flush=True)
json.dump(res, open(config.path("results/temporal/hindcast.json"), "w"), indent=1)
ok = [k for k, v in res.items() if isinstance(v, dict) and "xgb_potential" in v and v["xgb_potential"]["30m"]["fom"] > max(v["distance_only"]["30m"]["fom"], v["random"]["30m"]["fom"])]
e.finish(res, result=f"model beats distance-only and random FoM in {len(ok)}/{len(res)} window-source cases: {ok}", outputs={"hindcast": "results/temporal/hindcast.json"})
