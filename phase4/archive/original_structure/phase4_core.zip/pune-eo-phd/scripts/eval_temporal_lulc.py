"""Evaluate temporal LULC (raw per-year vs HMM) against INDEPENDENT multi-epoch references. Registry EXP-LULC-T-EVAL.
  GHSL BUILT-S (90 m, 1990-2020/5y): r and MAE of built fraction; r of built change since 1990
  WSF-Evolution (30 m): per-epoch built F1 vs 'settled by year'; timing error of first built year for cells settled 1991-2015
  JRC GSW occurrence: water frequency 1990-2020 vs occurrence (Spearman); permanent-water recall
  Esri LULC 2017-19, 2022-23 (semi-independent): macro-F1 on pure cells in TEST blocks
  Silver 2020/2021: macro-F1 on TEST blocks
GHSL measures built SURFACE (roof) fraction, our class labels whole 30 m cells -> bias is expected; correlations are the test."""
import json, sys, warnings
import numpy as np, pandas as pd, xarray as xr, rasterio
from scipy.stats import spearmanr, pearsonr
sys.path.insert(0, "src"); warnings.filterwarnings("ignore")
from pune_eo import config
from pune_eo.classification import baseline as B, temporal as H
from pune_eo.modelling.registry import Experiment
W = ["pune_G30_khadakwasla_mutha", "pune_G30_baramati_agri", "pune_G30_mulshi_ghats"]
def rd(p, b=None):
    with rasterio.open(p) as s: return s.read(b) if b else s.read()
e = Experiment(experiment_id="EXP-LULC-T-EVAL", research_question="RQ-T: raw vs HMM temporal LULC against independent multi-epoch references",
               hypothesis="HMM reduces flips and improves agreement with independent references (timing, persistence)",
               dataset_version="products EXP-LULC-T-001", years=list(range(1990, 2027)), resolution_m=30, features="n/a (evaluation)",
               labels="GHSL R2023A, WSF-Evolution v1, JRC GSW v1.3, Esri 2017-19/2022-23, silver 2020/21 (test blocks)",
               split="independent products: all cells; Esri/silver: test blocks only", model="EXP-LULC-T-001", hyperparameters={}, seed=0)
res = {}
for gid in W:
    P = xr.open_zarr(config.path("data/products/lulc", f"{gid}.zarr")); years = list(P.year.values); d = config.path("data/labels", gid)
    L = {"raw": P.raw_label.values, "hmm": P.hmm_label.values}; obs = P.observed.values; T, Hh, Ww = L["raw"].shape; r = {}
    r["flip_rate_mean"] = {k: float(H.flip_rate(v.reshape(T, -1)).mean()) for k, v in L.items()}
    # GHSL
    gh = rd(d / "ghsl_built_fraction_90m.tif").astype(float); gh[gh < 0] = np.nan; eps = [1990, 1995, 2000, 2005, 2010, 2015, 2020]
    h3, w3 = gh.shape[1], gh.shape[2]; g = {}
    for k, v in L.items():
        bf = (v[:, :h3 * 3, :w3 * 3] == 1).reshape(T, h3, 3, w3, 3).mean(axis=(2, 4)); per = {}
        for i, ep in enumerate(eps):
            a, b = bf[years.index(ep)].ravel(), gh[i].ravel(); f = np.isfinite(b)
            per[ep] = {"pearson_r": round(float(pearsonr(a[f], b[f])[0]), 4), "mae": round(float(np.abs(a[f] - b[f]).mean()), 4), "bias": round(float((a[f] - b[f]).mean()), 4),
                       "mapped_mean": round(float(a[f].mean()), 4), "ghsl_mean": round(float(b[f].mean()), 4)}
        da = (bf[years.index(2020)] - bf[years.index(1990)]).ravel(); db = (gh[6] - gh[0]).ravel(); f = np.isfinite(db)
        g[k] = {"by_epoch": per, "change_1990_2020_pearson_r": round(float(pearsonr(da[f], db[f])[0]), 4),
                "change_mapped_mean": round(float(da[f].mean()), 4), "change_ghsl_mean": round(float(db[f].mean()), 4)}
    r["ghsl"] = g
    # WSF
    wsf = rd(d / "wsf_evolution_first_year.tif", 1).astype(int); wv = {}
    for k, v in L.items():
        per = {}
        for ep in [1990, 1995, 2000, 2005, 2010, 2015]:
            ref = (wsf > 0) & (wsf <= ep); mp = v[years.index(ep)] == 1
            tp = (ref & mp).sum(); per[ep] = {"f1": round(float(2 * tp / max(ref.sum() + mp.sum(), 1)), 4), "ref_share": round(float(ref.mean()), 4), "mapped_share": round(float(mp.mean()), 4)}
        # timing: first year of the FINAL built run (built in 2015 and every year after the onset up to 2015)
        cand = (wsf >= 1991) & (wsf <= 2015) & (v[years.index(2015)] == 1)
        vv = v[:years.index(2015) + 1][:, cand]                       # (t, n)
        notb = vv != 1; last_not = np.where(notb.any(0), (notb.shape[0] - 1) - np.argmax(notb[::-1], 0), -1)
        onset = np.array(years)[np.clip(last_not + 1, 0, len(years) - 1)]
        err = onset - wsf[cand]
        wv[k] = {"by_epoch": per, "timing_n": int(cand.sum()), "timing_error_median_y": float(np.median(err)) if err.size else None,
                 "timing_abs_error_median_y": float(np.median(np.abs(err))) if err.size else None,
                 "timing_within_2y_share": round(float((np.abs(err) <= 2).mean()), 4) if err.size else None,
                 "onset_before_1991_share": round(float((onset <= 1990).mean()), 4) if err.size else None}
    r["wsf"] = wv
    # JRC
    jrc = rd(d / "jrc_gsw.tif", 1).astype(float); jrc[jrc == 255] = np.nan; jv = {}
    i0, i1 = years.index(1990), years.index(2020)
    for k, v in L.items():
        wf = ((v[i0:i1 + 1] == 4) & obs[i0:i1 + 1]).sum(0) / np.maximum(obs[i0:i1 + 1].sum(0), 1)
        f = np.isfinite(jrc) & ((jrc > 0) | (wf > 0))
        perm = np.isfinite(jrc) & (jrc >= 90)
        jv[k] = {"spearman_water_freq_vs_occurrence": round(float(spearmanr(wf[f], jrc[f])[0]), 4) if f.sum() > 50 else None, "n": int(f.sum()),
                 "permanent_cells": int(perm.sum()), "permanent_recall_wf_ge_0.9": round(float((wf[perm] >= 0.9).mean()), 4) if perm.any() else None}
    r["jrc"] = jv
    # Esri other years + silver (test blocks only)
    sp = rd(d / "splits.tif", 1); es = {}
    for yr in [2017, 2018, 2019, 2022, 2023]:
        fr = rd(d / f"esri_lulc_{yr}_l1_fractions.tif").astype(float); fr[fr < 0] = np.nan
        ref = np.zeros(sp.shape, int)
        for c in B.CLASSES: ref[fr[c - 1] >= 0.78] = c
        m = (sp == 3) & (ref > 0)
        es[yr] = {k: B.evaluate(ref[m], v[years.index(yr)][m])["macro_f1"] for k, v in L.items()} | {"n": int(m.sum())}
    sil = rd(d / "silver_l1.tif", 1); m = (sp == 3) & np.isin(sil, B.CLASSES)
    r["esri_other_years_macro_f1"] = es
    r["silver_test_macro_f1"] = {yr: {k: B.evaluate(sil[m], v[years.index(yr)][m])["macro_f1"] for k, v in L.items()} for yr in (2020, 2021)}
    res[gid] = r; print(gid, json.dumps({"flip": r["flip_rate_mean"], "ghsl_change_r": {k: v["change_1990_2020_pearson_r"] for k, v in g.items()},
                                         "wsf_timing": {k: (v["timing_abs_error_median_y"], v["timing_within_2y_share"]) for k, v in wv.items()},
                                         "jrc": {k: v["spearman_water_freq_vs_occurrence"] for k, v in jv.items()}}), flush=True)
out = config.path("results/temporal"); out.mkdir(parents=True, exist_ok=True)
json.dump(res, open(out / "eval_temporal_lulc.json", "w"), indent=1, default=str)
e.finish(res, result="see results/temporal/eval_temporal_lulc.json", outputs={"eval": "results/temporal/eval_temporal_lulc.json"})
