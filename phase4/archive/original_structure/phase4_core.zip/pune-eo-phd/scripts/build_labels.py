"""Bring every reference source onto each benchmark window's G30 grid (Task: label system, Phase 2).
Usage: python3 scripts/build_labels.py [--windows a,b,c] [--steps fractions,ghsl,wsf,jrc]"""
import argparse, json, sys, time
sys.path.insert(0, "src")
from pune_eo.compositing.windows import resolve
from pune_eo.labels import sources, silver, splits
from pune_eo import config

ap = argparse.ArgumentParser()
ap.add_argument("--windows", default="khadakwasla_mutha,baramati_agri,mulshi_ghats")
ap.add_argument("--steps", default="fractions,ghsl,wsf,jrc")
a = ap.parse_args()
log = config.path("results", "labels"); log.mkdir(parents=True, exist_ok=True)
for w in a.windows.split(","):
    g, win, wn = resolve("G30", w); sub = g.subgrid(win, f"_{wn}")
    for step in a.steps.split(","):
        t0 = time.time()
        fn = {"fractions": sources.landcover_fractions, "ghsl": sources.ghsl_built, "wsf": sources.wsf_evolution,
              "jrc": getattr(sources, "jrc_water", None), "silver": silver.build_silver,
              "splits": lambda gg: {k: v for k, v in splits.make_splits(gg).items() if k != "split"}}[step]
        if fn is None: continue
        try:
            r = fn(sub); status = "done"
        except Exception as e:
            r = {"error": repr(e)}; status = "failed"
        rec = {"window": sub.id, "step": step, "status": status, "seconds": round(time.time() - t0, 1), "result": r}
        print(json.dumps(rec, default=str)[:600], flush=True)
        with open(log / "build_labels.jsonl", "a") as f: f.write(json.dumps(rec, default=str) + "\n")
