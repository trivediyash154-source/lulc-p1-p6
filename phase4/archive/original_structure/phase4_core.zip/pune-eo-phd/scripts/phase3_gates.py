"""Evaluate the six Phase-3 decision gates from saved results against the criteria fixed in configs/phase3.yaml -> results/phase3/gates.json."""
import json, sys
sys.path.insert(0, "src")
from pune_eo import config
J = lambda p: json.loads(config.path(p).read_text()) if config.path(p).exists() else None
reg = lambda e: J(f"experiments/registry3/{e.replace('@', '_at_')}.json")
crit = __import__("yaml").safe_load(open(config.path("configs/phase3.yaml")))["gates"]; G = {}
g = J("results/phase3/gold/gold_provisional_eval.json")
G["G1"] = {"passed": False, "criterion": crit["G1_gold_reliable"], "evidence": "0/558 Tier-A (human VHR) labels; provisional AI labels (Tier C) cannot pass by protocol" + (f"; AI self-consistency kappa {g['self_consistency']['cohen_kappa_all_categories']:.2f} (not inter-annotator)" if g else "")}
b4 = reg("P3-B4")["metrics"]["dry_year_vs_P3-B1"]; c = b4["never_settled"]; rel = c["estimate"] / c["base_mean"]; rd = b4["stable_built"]["estimate"]
ok2 = rel <= -0.25 and c["excludes_zero"] and rd >= -0.05
per_w = {w[9:]: round(v["fbr_dry"], 3) for w, v in reg("P3-B4")["metrics"]["by_window"].items()}
G["G2"] = {"passed": bool(ok2), "criterion": crit["G2_temporal_helps_history"], "evidence": f"P3-B4 vs P3-B1 pooled dry-year FBR {c['estimate']:+.3f} (rel {rel:+.0%}, CI {c['ci95'][0]:+.3f}..{c['ci95'][1]:+.3f}), built-recall change {rd:+.3f}; per-window dry FBR after B4: {per_w} (baramati_agri remains > 0.5)"}
fu = J("results/phase3/fusion/fusion_summary.json")
if fu:
    g3 = fu["gate3"]; G["G3"] = {"passed": g3["passed"], "criterion": crit["G3_sar_helps"], "evidence": "C3-C1 unseen macro-F1: " + ", ".join(f"{w[9:]} {v['estimate']:+.3f} [{v['ci95'][0]:+.3f},{v['ci95'][1]:+.3f}]" for w, v in g3["by_window"].items()) + " (S1 era, 2021)"}
else: G["G3"] = {"passed": None, "criterion": crit["G3_sar_helps"], "evidence": "fusion results missing"}
e5 = reg("P3-E5")
if e5 and e5["status"] == "PASS":
    G["G4"] = {"passed": e5["metrics"]["gate4_passed"], "criterion": crit["G4_multimodal_temporal_transfer"], "evidence": e5["result"] + " — caveat: P3-E5 was registered after the C-group (SAR/terrain) results were seen, so this is not a blind test"}
else: G["G4"] = {"passed": None, "criterion": crit["G4_multimodal_temporal_transfer"], "evidence": "P3-E5 not completed"}
g5 = J("results/phase3/calibration/gate5.json")
if g5:
    G["G5"] = {"passed": any(all(v["passed"] for v in d.values()) for d in g5.values()), "criterion": crit["G5_calibrated"],
               "evidence": "; ".join(f"{fs}: " + ", ".join(f"{w} ECE {v['ece_selected']:.3f} / LAC cov {v['lac_coverage']:.3f}" for w, v in d.items()) for fs, d in g5.items())}
else: G["G5"] = {"passed": None, "criterion": crit["G5_calibrated"], "evidence": "calibration results missing"}
p = J("results/phase3/product/product_summary.json")
if p:
    g6 = p["gate6"]; G["G6"] = {"passed": g6["passed"], "criterion": crit["G6_history_defensible"], "evidence": f"G1 not passed; selected {g6['selected_model']}: dry-year FBR " +
                                ", ".join(f"{w[9:]} {v['dry_year_fbr']:.3f}" for w, v in g6["by_window"].items()) + f"; block MAE vs WSF <= 0.10 everywhere: {g6['mae_ok']}"}
else: G["G6"] = {"passed": False, "criterion": crit["G6_history_defensible"], "evidence": "G1 not passed (sufficient for failure); product not yet evaluated"}
json.dump(G, open(config.path("results/phase3/gates.json"), "w"), indent=1); [print(k, v["passed"], "|", v["evidence"][:200]) for k, v in G.items()]
