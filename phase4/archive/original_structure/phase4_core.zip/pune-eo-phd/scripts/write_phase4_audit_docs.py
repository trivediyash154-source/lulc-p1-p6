"""Write the Phase-4 audit documents from data/inventory/* (numbers are read from files).
docs/phase4_data_inventory.md, docs/phase4_data_quality.md, docs/phase4_training_labels.md, docs/phase4_existing_products.md (availability part),
docs/existing_product_benchmark.md (pointer), docs/phase4_audit.md (weakness matrix, dependency graph, the seven-part assessment)."""
import json, sys
import numpy as np, pandas as pd
sys.path.insert(0, "src")
from pune_eo import config
I = config.path("data/inventory"); D = config.path("docs")
S = pd.read_csv(I / "scenes_by_year_season.csv"); C = pd.read_csv(I / "composites.csv"); CU = pd.read_csv(I / "cubes.csv"); LR = pd.read_csv(I / "labels_reference.csv")
DS = pd.read_csv(I / "datasets.csv"); SUM = json.load(open(I / "inventory_summary.json")); LA = json.load(open(I / "label_audit.json")); PA = json.load(open(I / "product_availability.json"))
COV = SUM["coverage"]; W3 = ["khadakwasla_mutha", "baramati_agri", "mulshi_ghats"]; WF = {w: f"pune_G30_{w}" for w in W3}
def table(h, rows): return "\n".join(["| " + " | ".join(map(str, h)) + " |", "|" + "---|" * len(h)] + ["| " + " | ".join(str(c).replace("|", "/") for c in r) + " |" for r in rows])
def write(n, L): (D / n).write_text("\n".join(L) + "\n"); print("wrote", n)
L5 = S[S.family == "landsat"]; LP = L5[L5.year >= 1989].pivot_table(index="year", columns="season", values="selected", aggfunc="sum").fillna(0).astype(int)
PL = L5[L5.year >= 1989].pivot_table(index="year", columns="platform", values="selected", aggfunc="sum").fillna(0).astype(int)
G = C[(C.grid == "pune_G240") & (C.family == "landsat") & (C.kind == "season")]
NC = G.pivot_table(index="year", columns="period", values="n_clear_median"); RF = G.pivot_table(index="year", columns="period", values="reliable_fraction_ge3")
s2 = S[S.family == "sentinel2"].pivot_table(index="year", columns="season", values="selected", aggfunc="sum").fillna(0).astype(int)
s1 = S[S.family == "sentinel1"].pivot_table(index="year", columns="season", values="selected", aggfunc="sum").fillna(0).astype(int)
# =============== inventory
rows = []
for y in LP.index:
    pl = PL.loc[y]; rows.append([y, " / ".join(f"{p[-1]}:{int(pl[p])}" for p in PL.columns if pl[p] > 0) or "—", LP.loc[y].get("dry", 0), LP.loc[y].get("post_monsoon", 0), LP.loc[y].get("wet", 0),
                 "—" if y not in NC.index else f"{NC.loc[y].get('dry', np.nan):.0f} / {NC.loc[y].get('post_monsoon', np.nan):.0f} / {NC.loc[y].get('wet', np.nan):.0f}",
                 "—" if y not in RF.index else f"{RF.loc[y].get('dry', np.nan):.2f} / {RF.loc[y].get('post_monsoon', np.nan):.2f} / {RF.loc[y].get('wet', np.nan):.2f}"])
inv = ["# Phase 4 — data inventory", "", f"_Generated from the repository files by `scripts/phase4_inventory.py` (machine-readable: `data/inventory/`). Inventory date {SUM['created_utc']}._", "",
       "## 1. Scale of what exists", "", table(["item", "value"], [["Pune District area", f"{COV['district_area_km2']:.0f} km²"], ["30 m analysis-ready area (3 benchmark windows)", f"{COV['windows_30m_total_km2']:.0f} km² = **{100 * COV['windows_share_of_district']:.1f} % of the district**"],
       ["district-wide 30 m cube", "**not built**"], ["district-wide data", "240 m benchmark grid (G240) composites — metadata for all products, rasters for only a minority (section 4)"],
       ["Landsat scenes (selected / discovered)", f"{SUM['scenes']['landsat']['selected']} / {SUM['scenes']['landsat']['discovered']} ({SUM['scenes']['landsat']['years_with_selected']})"],
       ["Sentinel-2 scenes", f"{SUM['scenes']['sentinel2']['selected']} / {SUM['scenes']['sentinel2']['discovered']} ({SUM['scenes']['sentinel2']['years_with_selected']}; dense from 2018)"],
       ["Sentinel-1 scenes", f"{SUM['scenes']['sentinel1']['selected']} / {SUM['scenes']['sentinel1']['discovered']} ({SUM['scenes']['sentinel1']['years_with_selected']})"],
       ["composite products (metadata)", f"{SUM['composites']['n_products']} ({SUM['composites']['products_metadata_only']} metadata-only: rasters deleted)"],
       ["human-labelled (Tier A) points", f"**{SUM['gold']['human_tier_A_labels']}**"], ["provisional AI labels (Tier C, 2021)", SUM["gold"]["provisional_ai_tier_C_labels_2021"]]]), "",
       "## 2. Landsat temporal coverage (district)", "", "Scenes = selected Landsat scenes intersecting the district. Clear obs = median number of clear observations per pixel in the district G240 seasonal composite (dry Jan-May / post-monsoon Oct-Dec / wet Jun-Sep). "
       "≥3-obs = share of the district with at least three clear observations.", "", table(["year", "platform:scenes", "dry", "post", "wet", "clear obs dry/post/wet", "≥3-obs share dry/post/wet"], rows), "",
       "Reading: 1990-2012 rests on 2-11 clear dry-season observations and typically 1-4 post-monsoon observations; the wet season is almost never observed optically. 1997 and 2003 are the weakest dry seasons (≥3-obs share 0.15 and 0.22). "
       "From 2013 (Landsat 8) observation density roughly triples. 1985-1988 has no selected scene; 1989 has six. Landsat-7 alone (SLC-off) carries 2003-2007 and 2012.", "",
       "## 3. Sentinel coverage (district, selected scenes)", "", "Sentinel-2:", "", table(["season"] + list(s2.index), [[s] + list(s2.T.loc[s]) for s in s2.columns]), "", "Sentinel-1:", "", table(["season"] + list(s1.index), [[s] + list(s1.T.loc[s]) for s in s1.columns]), "",
       "## 4. Composite products on disk", "", table(["grid", "family", "products", "rasters present"], [[g, f, len(d), int((d.files_present > 0).sum())] for (g, f), d in C.groupby(["grid", "family"])]), "",
       "District (G240) rasters were mostly removed in earlier phases to save disk; their metadata (statistics, QA) remain. At 240 m they are a district overview, not a 30 m land-cover basis. Sentinel-2 at 30 m exists only for 2021 and 2024; at 10 m only for Baramati 2021.", "",
       "## 5. Datasets (all fields required by the brief)", "", table(list(DS.columns), DS.fillna("—").values.tolist()), "",
       "## 6. Label and reference rasters", "", f"{len(LR)} rasters (`data/inventory/labels_reference.csv`); {int(LR.has_provenance_json.sum())} have a provenance JSON sidecar, {int((~LR.has_provenance_json).sum())} do not (their provenance is only in the generating code and git history).", ""]
write("phase4_data_inventory.md", inv)
# =============== quality
qa = pd.crosstab([C.family, C.kind], C.qa_status)
w30 = C[C.grid.str.startswith("pune_G30") & (C.family == "landsat") & (C.kind == "season")]
qual = ["# Phase 4 — data quality", "", "## 1. Composite QA status (all grids)", "", table(["family / kind"] + list(qa.columns), [[f"{a} / {b}"] + list(qa.loc[(a, b)]) for a, b in qa.index]), "",
        f"Wet-season Landsat composites: {int(((C.family == 'landsat') & (C.period == 'wet') & (C.qa_status == 'FAIL')).sum())} of {int(((C.family == 'landsat') & (C.period == 'wet')).sum())} FAIL and {int(((C.family == 'landsat') & (C.period == 'wet') & (C.qa_status == 'WARNING')).sum())} WARN (cloud); S2/S1 monthly FAILs are monsoon months. "
        f"{int(C.qa_warn.fillna('').str.contains('SLC-off is the only sensor').sum())} products carry 'Landsat-7 SLC-off is the only sensor'; {int(C.qa_warn.fillna('').str.contains('< 3').sum())} carry 'median clear observations < 3' ({int(C.qa_warn.fillna('').str.contains('< 3|< 2').sum())} including '< 2').", "",
        "## 2. Observation density in the 30 m windows (Landsat seasonal composites, median clear obs)", "", table(["window", "dry min / median / max", "post min / median / max", "wet min / median / max"],
        [[w] + [f"{d.n_clear_median.min():.0f} / {d.n_clear_median.median():.0f} / {d.n_clear_median.max():.0f}" for p in ("dry", "post_monsoon", "wet") for d in [w30[(w30.grid == WF[w]) & (w30.period == p)]]] for w in W3]), "",
        "Baramati sits in a WRS-2 path overlap (about twice the observations of the other windows) — a density advantage that does not hold for the district.", "",
        "## 3. Known processing issues and their status", "", table(["issue", "found", "status", "residual risk"], [
         ["WSF GDAL nodata bump", "Phase 2", "fixed; no experiment used the pre-fix product (Phase-3 audit)", "low"],
         ["S2 SCL reader v1 counted no-data as observed", "Phase 2", "fixed (v2); old products quarantined", "low"], ["S1 cube reader filename", "Phase 2", "fixed", "low"],
         ["S2 -> OLI transform fitted on corridor only", "Phase 3 (P3-I1)", "NOT fixed: window-specific residuals up to ~0.025 (NIR/SWIR Baramati), NDVI -0.035 (Mulshi)", "high for Landsat+S2 fusion"],
         ["Landsat cross-sensor harmonisation (local_pune_g30_v2)", "Phase 1-2", "fitted on overlaps; not validated on pseudo-invariant targets across eras", "medium-high for 1990s"],
         ["sparse early-era observations (1990-98: 2-6 clear dry obs; post-monsoon 1-4)", "Phase 4 audit", "inherent", "high: annual maps before 2013 weakly constrained"],
         ["L7 SLC-off-only years (2003-2007, 2012)", "Phase 1", "gap-filled by compositing", "medium (striping residue)"],
         ["DEM is a DSM (Copernicus)", "Phase 1", "documented", "medium for HAND/flood"], ["2025 S1 archive incomplete; 2026 partial", "Phase 2", "documented", "low"]]), "",
        "## 4. What the quality allows", "", "* 2013-2026: dense optical record; S1 from 2017 (S1B gap after Dec 2021); S2 dense from 2018 — annual 30 m maps are observationally supported.",
        "* 1999-2012: dry-season composites supported in most years; post-monsoon weak in about half the years; annual change detection at ±1 y precision is not supported everywhere.",
        "* 1990-1998: TM only, 2-6 clear dry observations, post-monsoon often 1-2; epoch-level (multi-year) reconstruction is defensible to attempt, annual reconstruction must carry explicit temporal uncertainty.",
        "* Wet season: no optical basis in any year before 2014 and weak after; SAR only from 2015."]
write("phase4_data_quality.md", qual)
# =============== training labels
la = LA["windows"]
tl = ["# Phase 4 — training-label and validation-label audit", "", "_From `scripts/phase4_label_audit.py` -> `data/inventory/label_audit.json`._", "", "## 1. Training labels (silver L1)", "",
      "Definition: a 30 m cell is labelled only if ESA WorldCover 2020, 2021 and Esri 2020, 2021 agree unanimously with purity >= 0.78. Valid for 2020-2021 only.", "",
      table(["window", "labelled share of cells", "built", "agriculture", "natural veg.", "water", "share of WorldCover-class cells that get a silver label (built/agri/natveg/water)"],
            [[w, f"{la[WF[w]]['silver_labelled_fraction']:.2f}"] + [la[WF[w]]["class_counts_all_silver"][c] for c in ("built_up", "agriculture", "natural_vegetation", "water")] +
             [" / ".join(f"{la[WF[w]]['silver_share_of_worldcover_class'][c]:.2f}" for c in ("built_up", "agriculture", "natural_vegetation", "water"))] for w in W3]), "",
      "## 2. Easy-cell bias", "", table(["window", "edge-cell share silver / unlabelled", "local SD of dry NDVI silver / unlabelled", "WorldCover purity silver / unlabelled"],
            [[w, f"{la[WF[w]]['easy_cell_bias']['edge_cell_share']['silver']:.2f} / {la[WF[w]]['easy_cell_bias']['edge_cell_share']['unlabelled']:.2f}",
              f"{la[WF[w]]['easy_cell_bias']['local_sd_dry_ndvi_median']['silver']:.3f} / {la[WF[w]]['easy_cell_bias']['local_sd_dry_ndvi_median']['unlabelled']:.3f}",
              f"{la[WF[w]]['easy_cell_bias']['worldcover_purity_median']['silver']:.2f} / {la[WF[w]]['easy_cell_bias']['worldcover_purity_median']['unlabelled']:.2f}"] for w in W3]), "",
      "Silver cells are interior cells: only 7-25 % sit on a class boundary versus 65-72 % of unlabelled cells. The model is trained and (in Phases 2-3) tested on the cells that are easiest by construction; boundary, mixed and "
      "transitional cells — where land-cover change actually happens — are almost absent. Class support is lopsided: corridor agriculture gets a silver label in only 8 % of its WorldCover cells (2 069 cells), "
      "Baramati natural vegetation has 98 cells, Mulshi built-up 393.", "",
      "## 3. Spatial autocorrelation vs the 3 km blocks", "", table(["window", "lag (m) where indicator correlation first drops below 0.1: built / agri / natveg / water"],
            [[w, " / ".join(str(la[WF[w]]["autocorrelation_range_m_corr_lt_0.1"][c]) for c in ("built_up", "agriculture", "natural_vegetation", "water"))] for w in W3]), "",
      "Class patterns stay correlated beyond 3 km for several class-window pairs (built-up in the corridor up to ~4 km). Train and test blocks are therefore not fully independent for those classes; within-window "
      "scores are optimistic. Leave-one-region-out and district-wide independent validation are required for generalisation claims.", "",
      "## 4. Temporal mismatch", "", f"* {LA['training_design']['label_years']}", f"* {LA['training_design']['temporal_mismatch']}", f"* {LA['training_design']['HET_sampling']}", "",
      "## 5. Is the model learning the reference products?", "", table(["evidence (Tier C, provisional AI 2021)", "value"], [[k.replace("_", " "), (f"{v:.3f}" if isinstance(v, float) else v)] for k, v in LA["reference_learning_evidence"].items()]), "",
      "Agreement with an independent visual reading falls from 0.92 on cells where the four products agree to 0.76 where they do not, and WorldCover itself agrees with the visual reading on only 0.44 of the no-consensus points. "
      "This is consistent with a model that has learned the products' consensus on easy cells; it does not show it has learned land cover where the products disagree. (Tier C; to be re-tested against human gold.)", "",
      "## 6. Validation labels", "", table(["tier", "what exists", "what it can validate"], [["A (human)", "0 points", "nothing yet"],
      ["B (independent products)", "WSF-Evolution 1985-2015 (30 m), GHSL BUILT-S 1990-2020 5-yearly (90/100 m), JRC GSW 1984-2021 — in the 3 windows only", "built-up and water history; NOT agriculture or natural vegetation"],
      ["C (silver / provisional AI)", "silver 2020-21 (easy cells); 437 AI-labelled 2021 points (S2-based, shares evidence with WorldCover/Esri)", "2020-21 agreement only"]]), "",
      "No epoch other than 2020-2021 has any reference for agriculture or natural vegetation. Historical reconstruction of those classes is currently unvalidatable.", "",
      "## 7. Consequences for Phase 4 labels", "", "1. Separate training labels from validation labels physically (different points, different blocks, different people where possible).",
      "2. Every training label carries provenance (source, epoch, purity, interpreter) — no blind merging.", "3. Training must include boundary/mixed/transitional cells (human or VHR-interpreted), not only consensus interiors.",
      "4. Label-quality experiment (A single-year silver, B multi-year silver, C independently validated, D human gold, E gold + filtered silver) needs human labels for C-E; A-B can run now as exploratory."]
write("phase4_training_labels.md", tl)
# =============== existing products (availability)
pr = PA["products"]
ep = ["# Phase 4 — existing land-cover / built-up / water products", "", f"_Availability probed live on {PA['checked_utc']} (`scripts/phase4_product_availability.py`). Method/limitation notes come from the producers' documentation and are re-checked against the user guides when acquired._", "",
      "## 1. Availability and suitability", "", table(["product", "resolution", "period", "classes", "status here", "role", "main limitation for Pune"],
      [[k.replace("_", " "), v.get("resolution_m"), v.get("temporal") if isinstance(v.get("temporal"), str) else (v.get("temporal") or ""), v.get("classes", "—"), v["status"],
        "NOT independent (silver source)" if "silver" in v.get("known_limitations", "") else ("benchmark (independent)" if "ACQ" in v["status"] or "IN_REPO" in v["status"] or "NEEDS" in v["status"] else "context"),
        v.get("known_limitations", "—")] for k, v in pr.items()]), "",
      "## 2. Decisions", "", "* GLC_FCS30D (1985-2022, 30 m) is the main independent historical benchmark: its own validation is global, so it is a reference product, not truth.",
      "* GISA 2.0 (impervious first-year 1972-2021) stands in for GAIA until Earth Engine access exists; both describe impervious surface, not our 'built-up' land-cover class — definitions are mapped explicitly before comparison.",
      "* WorldCover and Esri 2020-21 trained our silver labels: they are NOT independent of our models and are reported only as Tier C.",
      "* Dynamic World and GAIA need the user's Earth Engine project; India decadal LULC (1985/1995/2005) needs a NASA Earthdata login.",
      "* NRSC LULC 50K is view-only — useful as context for human interpreters, not as data.", "", "## 3. Benchmark results", "", "_Filled by the Phase-4 benchmark run (`docs/existing_product_benchmark.md`)._"]
write("phase4_existing_products.md", ep)
if not (D / "existing_product_benchmark.md").exists(): write("existing_product_benchmark.md", ["# Existing-product benchmark", "", "_Pending: produced by the Phase-4 benchmark run. Availability and suitability: `docs/phase4_existing_products.md`._"])
print("done")
