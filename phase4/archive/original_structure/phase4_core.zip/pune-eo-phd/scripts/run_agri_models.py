"""Agriculture / multimodal experiment on the 2021 monthly series (S2 + S1), silver L1 labels, 3 km spatial blocks.
  EXP-AG-{model}-{channels}: RF / XGB on flattened series vs TempCNN / LSTM / Transformer; channels s2 | s2s1
  Plus EXP-AG-*-LOWO for the best classical and best DL model (leave-one-window-out).
Caveat: silver labels come from S2-derived products -> agreement is optimistic for S2 features (docs/label_protocol.md)."""
import json, sys, time, warnings
import numpy as np, pandas as pd, rasterio
sys.path.insert(0, "src"); warnings.filterwarnings("ignore")
from pune_eo import config
from pune_eo.classification import baseline as B
from pune_eo.agriculture import timeseries as TS
from pune_eo.modelling.registry import Experiment
W = ["pune_G30_khadakwasla_mutha", "pune_G30_baramati_agri", "pune_G30_mulshi_ghats"]; YEAR = 2021; SEED = 20261007
CAP = {1: 4000, 2: 4000, 3: 20000}; rng = np.random.default_rng(SEED)
def rd(p):
    with rasterio.open(p) as s: return s.read(1)
rows = []; avail = {}
for gid in W:
    X, info = TS.monthly_stack(gid, YEAR); avail[gid] = info; d = config.path("data/labels", gid); lab, sp = rd(d / "silver_l1.tif"), rd(d / "splits.tif")
    for s in (1, 2, 3):
        for c in B.CLASSES:
            r, cc = np.nonzero((sp == s) & (lab == c))
            if r.size == 0: continue
            if CAP[s] and r.size > CAP[s]: k = rng.choice(r.size, CAP[s], replace=False); r, cc = r[k], cc[k]
            rows.append((X[:, :, r, cc].transpose(2, 0, 1), np.full(r.size, c), np.full(r.size, s), np.array([gid] * r.size)))
    del X
Xall = np.concatenate([r[0] for r in rows]); yall = np.concatenate([r[1] for r in rows]); sall = np.concatenate([r[2] for r in rows]); wall = np.concatenate([r[3] for r in rows])
s1_cover = {g: sum(v["s1"] for v in i.values()) for g, i in avail.items()}; print("S1 months available:", s1_cover, flush=True)
CHS = {"s2": [0, 1, 2, 3], "s2s1": [0, 1, 2, 3, 4, 5]}
enc = {c: i for i, c in enumerate(B.CLASSES)}; yi = np.vectorize(enc.get)(yall)
out = config.path("results/agriculture"); out.mkdir(parents=True, exist_ok=True); summ = []
def run(eid, model, ch, tr, va, te, split_desc, extra=None):
    prev = config.path("experiments/registry", f"{eid}.json")
    if prev.exists():
        pr = json.loads(prev.read_text())
        if pr.get("status") == "DONE":                                       # resume: reuse a finished registry record
            mt, mv = pr["metrics"]["test"], pr["metrics"]["val"]
            summ.append({"experiment_id": eid, "model": model, "channels": ch, "split": split_desc, "val_macro_f1": mv["macro_f1"], "test_macro_f1": mt["macro_f1"],
                         **{f"f1_{k}": v["f1"] for k, v in mt["per_class"].items()}, "fit_s": pr["metrics"].get("fit_seconds")}); print("reused", eid, flush=True); return
    e = Experiment(experiment_id=eid, research_question="RQ-AG: Do temporal deep models on S2(+S1) monthly series beat RF/XGB for L1 (esp. agriculture vs natural vegetation)?",
                   hypothesis="DL > RF/XGB only marginally; adding S1 helps where optical months are missing (monsoon)",
                   dataset_version=f"S2/S1 G30 monthly {YEAR} (S2 reader v2)", years=[YEAR], resolution_m=30, features=[TS.CH[i] for i in CHS[ch]] + ["obs-mask"],
                   labels="silver_l1", split=split_desc, model=model, hyperparameters={}, seed=SEED, windows=W)
    try:
        Xc = Xall[:, :, CHS[ch]]
        if ch == "s2": Xc = np.concatenate([Xc, np.full(Xc.shape[:2] + (2,), np.nan, np.float32)], -1)   # keep prepare() channel layout
        t0 = time.time()
        if model in ("rf", "xgb"):
            F = Xc[:, :, [i for i in range(Xc.shape[2]) if not (ch == "s2" and i >= 4)]].reshape(len(Xc), -1)
            m = B.make_model(model, SEED); B.fit(model, m, F[tr], yall[tr], F[va], yall[va]); pt = B.predict(model, m, F[te]); pv = B.predict(model, m, F[va])
            hp = {"n_estimators": getattr(m, "n_estimators", None), "best_iteration": int(getattr(m, "best_iteration", -1) or -1)}
        else:
            Z, grp, st = TS.prepare(Xc[tr]); Zv, _, _ = TS.prepare(Xc[va], st); Zt, _, _ = TS.prepare(Xc[te], st)
            if ch == "s2": Z, Zv, Zt = (np.delete(a, [4, 5, 7], axis=-1) for a in (Z, Zv, Zt))      # drop empty S1 channels + S1 mask
            net, hist = TS.train(model, Z, yi[tr], Zv, yi[va], 4, seed=SEED)
            pt = np.asarray(B.CLASSES)[TS.predict_proba(net, Zt).argmax(1)]; pv = np.asarray(B.CLASSES)[TS.predict_proba(net, Zv).argmax(1)]
            hp = {"epochs_run": len(hist), "best_val_loss": float(min(hist)), "arch": model}
        mt = B.evaluate(yall[te], pt); mv = B.evaluate(yall[va], pv); fit_s = time.time() - t0
        e.rec["hyperparameters"] = hp
        e.finish({"val": mv, "test": mt, "fit_seconds": round(fit_s, 1), **(extra or {})}, result=f"test macro-F1 {mt['macro_f1']:.3f} (vs silver)",
                 n_samples={"train": int(tr.sum()), "val": int(va.sum()), "test": int(te.sum())})
        summ.append({"experiment_id": eid, "model": model, "channels": ch, "split": split_desc, "val_macro_f1": mv["macro_f1"], "test_macro_f1": mt["macro_f1"],
                     **{f"f1_{k}": v["f1"] for k, v in mt["per_class"].items()}, "fit_s": round(fit_s, 1)})
        print(json.dumps(summ[-1]), flush=True)
    except Exception as ex:
        import traceback; traceback.print_exc(); e.fail(repr(ex), eid, "fix and rerun")
tr, va, te = sall == 1, sall == 2, sall == 3
for ch in ["s2", "s2s1"]:
    for model in ["rf", "xgb", "tempcnn", "lstm", "transformer"]:
        run(f"EXP-AG-{model}-{ch}", model, ch, tr, va, te, "3 km hashed blocks (silver test blocks)")
pd.DataFrame(summ).to_csv(out / "agri_model_comparison.csv", index=False)
# LOWO for best classical and best DL (by VAL) on s2s1
best_c = max([s for s in summ if s["model"] in ("rf", "xgb") and s["channels"] == "s2s1"], key=lambda s: s["val_macro_f1"])["model"]
best_d = max([s for s in summ if s["model"] not in ("rf", "xgb") and s["channels"] == "s2s1"], key=lambda s: s["val_macro_f1"])["model"]
for held in W:
    for model in (best_c, best_d):
        trw = (wall != held) & (sall == 1); vaw = (wall != held) & (sall == 2); tew = wall == held
        run(f"EXP-AG-LOWO-{held.replace('pune_G30_', '')}-{model}-s2s1", model, "s2s1", trw, vaw, tew, f"leave-one-window-out ({held})", {"heldout": held})
pd.DataFrame(summ).to_csv(out / "agri_model_comparison.csv", index=False)
