"""Google Earth Engine export of the DISTRICT 30 m cube (Phase 4, dependency H). Needs the user's Earth Engine project:
    pip install earthengine-api && earthengine authenticate
    python3 scripts/gee/export_district_cube.py --project <GEE_PROJECT> [--years 1990-2026] [--what landsat,s1,s2,dw,gaia] [--folder pune_eo_exports] [--dry-run]
Design (mirrors the repository cube so district products are comparable with the 3 benchmark windows):
  * grid: pune_G30 = native Landsat lattice, EPSG:32643, crsTransform [30,0,322065,0,-30,2146035], 6546 x 5624 (data/products_ext/district/district_grid.json) -> no resampling of Landsat;
  * Landsat C2 L2 SR (LT05, LE07, LC08, LC09): QA_PIXEL bits 1 (dilated cloud), 2 (cirrus), 3 (cloud), 4 (shadow) masked; QA_RADSAT == 0; scale 2.75e-5, offset -0.2;
    harmonisation = results/harmonization/local_pune_g30_v2.yaml (L7 pooled RMA to OLI; L5/L9 identity, per the recorded decisions);
  * seasons: dry Jan-May, post-monsoon Oct-Dec, wet Jun-Sep (configs/temporal.yaml); per season median SR + indices + clear-observation count (n_clear) — years with no clear
    observation are exported as masked, never filled;
  * Sentinel-1 GRD IW VV/VH (dB, as provided by GEE) seasonal medians + counts (2015+); Sentinel-2 SR harmonized with Cloud Score+ (cs_cdf >= 0.6) seasonal medians (2017+);
  * Dynamic World seasonal mean class probabilities (2016+, reduceResolution mean to 30 m) and GAIA change-year index — BENCHMARK products only, never training labels.
Outputs are Cloud-Optimized GeoTIFFs in Google Drive (or GCS) and must be registered in data/inventory after download (scripts/phase4_inventory.py)."""
import argparse, json, sys
from pathlib import Path
import yaml
ROOT = Path(__file__).resolve().parents[2]
GRID = json.load(open(ROOT / "data/products_ext/district/district_grid.json"))["grid"]; HARM = yaml.safe_load(open(ROOT / "results/harmonization/local_pune_g30_v2.yaml"))
CRS, TR, W, H = GRID["crs"], [GRID["res"], 0, GRID["x0"], 0, -GRID["res"], GRID["y1"]], GRID["width"], GRID["height"]
SEASONS = {"dry": (1, 5), "post_monsoon": (10, 12), "wet": (6, 9)}
LS = {"LT05": ("LANDSAT/LT05/C02/T1_L2", ["SR_B1", "SR_B2", "SR_B3", "SR_B4", "SR_B5", "SR_B7"], "landsat-5"), "LE07": ("LANDSAT/LE07/C02/T1_L2", ["SR_B1", "SR_B2", "SR_B3", "SR_B4", "SR_B5", "SR_B7"], "landsat-7"),
      "LC08": ("LANDSAT/LC08/C02/T1_L2", ["SR_B2", "SR_B3", "SR_B4", "SR_B5", "SR_B6", "SR_B7"], "landsat-8"), "LC09": ("LANDSAT/LC09/C02/T1_L2", ["SR_B2", "SR_B3", "SR_B4", "SR_B5", "SR_B6", "SR_B7"], "landsat-9")}
NAMES = ["blue", "green", "red", "nir08", "swir16", "swir22"]
def plan(years, what):
    tasks = []
    for y in years:
        for s in SEASONS:
            if "landsat" in what: tasks.append(("landsat", y, s))
            if "s1" in what and y >= 2015: tasks.append(("s1", y, s))
            if "s2" in what and y >= 2017: tasks.append(("s2", y, s))
            if "dw" in what and y >= 2016: tasks.append(("dw", y, s))
    if "gaia" in what: tasks.append(("gaia", None, None))
    return tasks
def main():
    ap = argparse.ArgumentParser(); ap.add_argument("--project"); ap.add_argument("--years", default="1990-2026"); ap.add_argument("--what", default="landsat,s1,s2,dw,gaia")
    ap.add_argument("--folder", default="pune_eo_exports"); ap.add_argument("--dry-run", action="store_true"); a = ap.parse_args()
    y0, _, y1 = a.years.partition("-"); years = list(range(int(y0), int(y1 or y0) + 1)); tasks = plan(years, a.what.split(","))
    print(json.dumps({"grid": GRID["id"], "crs": CRS, "crsTransform": TR, "dimensions": f"{W}x{H}", "n_tasks": len(tasks)}, indent=1))
    if a.dry_run:
        for t in tasks[:12]: print("would export", t)
        return
    import ee
    ee.Initialize(project=a.project)
    region = ee.Geometry.Rectangle([GRID["bounds"][0], GRID["bounds"][1], GRID["bounds"][2], GRID["bounds"][3]], ee.Projection(CRS), False)
    def ls_prep(key):
        cid, bands, plat = LS[key]; h = HARM["per_platform"].get(plat)
        def f(img):
            qa = img.select("QA_PIXEL"); m = qa.bitwiseAnd(1 << 1).eq(0).And(qa.bitwiseAnd(1 << 2).eq(0)).And(qa.bitwiseAnd(1 << 3).eq(0)).And(qa.bitwiseAnd(1 << 4).eq(0)).And(img.select("QA_RADSAT").eq(0))
            sr = img.select(bands, NAMES).multiply(2.75e-05).add(-0.2)
            if h:   # recorded RMA to OLI (landsat-7 only in local_pune_g30_v2)
                sr = sr.multiply(ee.Image.constant([h["slope"][n] for n in NAMES])).add(ee.Image.constant([h["intercept"][n] for n in NAMES])).rename(NAMES)
            return sr.updateMask(m).copyProperties(img, ["system:time_start"])
        return ee.ImageCollection(cid).filterBounds(region).map(f)
    def indices(img):
        nd = lambda a, b, n: img.normalizedDifference([a, b]).rename(n)
        return img.addBands([nd("nir08", "red", "ndvi"), nd("green", "swir16", "mndwi"), nd("nir08", "swir16", "ndmi"), nd("nir08", "swir22", "nbr"), nd("swir16", "nir08", "ndbi")])
    def export(img, name):
        t = ee.batch.Export.image.toDrive(image=img, description=name[:100], folder=a.folder, fileNamePrefix=name, crs=CRS, crsTransform=TR, region=region, maxPixels=int(1e10),
                                          fileFormat="GeoTIFF", formatOptions={"cloudOptimized": True}); t.start(); print("started", name, t.id)
    for kind, y, s in tasks:
        if kind == "gaia":
            export(ee.Image("Tsinghua/FROM-GLC/GAIA/v10").toUint8(), "gaia_v10_change_year_index"); continue   # index -> year mapping: verify against the catalog page before use
        m0, m1 = SEASONS[s]; start = ee.Date.fromYMD(y, m0, 1); end = ee.Date.fromYMD(y, m1, 1).advance(1, "month")
        if kind == "landsat":
            col = ee.ImageCollection([]).merge(ls_prep("LT05")).merge(ls_prep("LE07")).merge(ls_prep("LC08")).merge(ls_prep("LC09")).filterDate(start, end)
            img = indices(col.median()).addBands(col.select("red").count().rename("n_clear")).toFloat(); export(img, f"landsat_{y}_{s}")
        elif kind == "s1":
            col = ee.ImageCollection("COPERNICUS/S1_GRD").filterBounds(region).filterDate(start, end).filter(ee.Filter.eq("instrumentMode", "IW")) \
                    .filter(ee.Filter.listContains("transmitterReceiverPolarisation", "VH")).select(["VV", "VH"])
            export(col.median().addBands(col.select("VV").count().rename("n_obs")).toFloat(), f"s1_{y}_{s}")
        elif kind == "s2":
            cs = ee.ImageCollection("GOOGLE/CLOUD_SCORE_PLUS/V1/S2_HARMONIZED")
            col = ee.ImageCollection("COPERNICUS/S2_SR_HARMONIZED").filterBounds(region).filterDate(start, end).linkCollection(cs, ["cs_cdf"]) \
                    .map(lambda i: i.updateMask(i.select("cs_cdf").gte(0.6)).select(["B2", "B3", "B4", "B8", "B11", "B12"], ["blue", "green", "red", "nir", "swir16", "swir22"]).divide(10000))
            export(col.median().addBands(col.select("red").count().rename("n_clear")).toFloat(), f"s2_{y}_{s}")
        elif kind == "dw":
            dw = ee.ImageCollection("GOOGLE/DYNAMICWORLD/V1").filterBounds(region).filterDate(start, end)
            probs = dw.select(["water", "trees", "grass", "flooded_vegetation", "crops", "shrub_and_scrub", "built", "bare", "snow_and_ice"]).mean()
            probs = probs.reduceResolution(ee.Reducer.mean(), maxPixels=64).reproject(crs=CRS, crsTransform=TR)
            export(probs.addBands(dw.select("label").count().rename("n_obs")).toFloat(), f"dynamicworld_{y}_{s}")
if __name__ == "__main__": main()
