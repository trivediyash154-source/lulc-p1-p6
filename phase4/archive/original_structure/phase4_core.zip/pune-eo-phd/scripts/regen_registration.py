import json, logging
logging.basicConfig(level=logging.WARNING)
from pune_eo.compositing.engine import run_year
from pune_eo.compositing.periods import standard_periods
from pune_eo.compositing.windows import resolve
g, w, wn = resolve("G30", "khadakwasla_mutha")
dry = [p for p in standard_periods(2024) if p.name == "dry"]
r = run_year("landsat", 2024, g, window=w, window_name=wn, threads=10); print(json.dumps({k: r.get(k) for k in ("job_id", "status", "seconds")}), flush=True)
r = run_year("sentinel2", 2024, g, window=w, window_name=wn, periods=dry, threads=10, out_family="sentinel2_on_G30"); print(json.dumps({k: r.get(k) for k in ("job_id", "status", "seconds")}), flush=True)
