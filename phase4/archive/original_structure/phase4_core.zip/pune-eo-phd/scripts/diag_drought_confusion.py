"""Is temporal built-up over-prediction driven by drought-year fallow? (registry EXP-LULC-DIAG-001)
False built-up rate = share of cells mapped built-up among cells NEVER settled per WSF AND GHSL 2020 < 0.02 AND not JRC water
(independent definition). Spearman with previous-monsoon (Jun-Sep, year-1) rainfall over 1991-2026, raw and first-differenced."""
import json, sys
import numpy as np, pandas as pd, rasterio, xarray as xr
from scipy.stats import spearmanr
sys.path.insert(0, "src")
from pune_eo import config
from pune_eo.modelling.registry import Experiment
S = pd.read_csv(config.path("results/stress/annual_supply_response_series.csv"))
e = Experiment(experiment_id="EXP-LULC-DIAG-001", research_question="RQ-T4: Does the year-to-year false built-up rate track the previous monsoon (drought-year fallow confusion)?",
               hypothesis="false built-up rate on never-settled land is negatively associated with previous-monsoon rainfall", dataset_version="EXP-LULC-T-001/T-002 products; CHIRPS",
               years=list(range(1991, 2027)), resolution_m=30, features="n/a", labels="never-settled frame: WSF=0 & GHSL2020<0.02 & JRC=0", split="all cells of the frame",
               model="Spearman (levels and first differences)", hyperparameters={}, seed=0)
res = {}
for gid in ["pune_G30_khadakwasla_mutha", "pune_G30_baramati_agri", "pune_G30_mulshi_ghats"]:
    d = config.path("data/labels", gid); rd = lambda p, b=1: rasterio.open(p).read(b)
    wsf = rd(d / "wsf_evolution_first_year.tif"); gh = rd(d / "ghsl_built_fraction_90m.tif", 7).astype(float); jrc = rd(d / "jrc_gsw.tif")
    H, W = wsf.shape; gh3 = np.pad(np.repeat(np.repeat(gh, 3, 0), 3, 1), ((0, max(0, H - 3 * gh.shape[0])), (0, max(0, W - 3 * gh.shape[1]))), constant_values=np.nan)[:H, :W]
    frame = (wsf == 0) & (gh3 < 0.02) & (jrc == 0)
    s = S[S.window == gid].set_index("year"); rain_prev = s.monsoon_mm.shift(1)
    out = {"frame_cells": int(frame.sum())}
    for prod, var in (("lulc", "raw_label"), ("lulc", "hmm_label"), ("lulc_aoa", "raw_label"), ("lulc_aoa", "hmm_aoa_label")):
        P = xr.open_zarr(config.path("data/products", prod, f"{gid}.zarr")); yrs = P.year.values
        fb = pd.Series([(P[var].sel(year=y).values[frame] == 1).mean() for y in yrs], index=yrs)
        x, y_ = rain_prev.reindex(yrs).values, fb.values; f = np.isfinite(x) & np.isfinite(y_)
        dx, dy = np.diff(x), np.diff(y_); fd = np.isfinite(dx) & np.isfinite(dy)
        out[f"{prod}:{var}"] = {"false_built_rate": {int(k): round(float(v), 4) for k, v in fb.items()},
                                "rho_levels": [round(float(spearmanr(x[f], y_[f])[0]), 3), round(float(spearmanr(x[f], y_[f])[1]), 4), int(f.sum())],
                                "rho_first_diff": [round(float(spearmanr(dx[fd], dy[fd])[0]), 3), round(float(spearmanr(dx[fd], dy[fd])[1]), 4), int(fd.sum())]}
    res[gid] = out
    print(gid, {k: (v["rho_levels"], v["rho_first_diff"], v["false_built_rate"].get(2015), v["false_built_rate"].get(2021)) for k, v in out.items() if k != "frame_cells"}, flush=True)
json.dump(res, open(config.path("results/temporal/drought_confusion.json"), "w"), indent=1)
e.finish(res, result="see results/temporal/drought_confusion.json")
