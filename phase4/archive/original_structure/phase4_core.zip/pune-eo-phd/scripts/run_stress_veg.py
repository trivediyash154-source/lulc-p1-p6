"""Vegetation trends + coupled supply/demand/response analysis (registry EXP-VEG-001, EXP-STRESS-001). No composite index.
Annual series per window 1990-2026:
  supply   : CHIRPS monsoon (Jun-Sep) rainfall, SPI-12 at September (gamma fit per window, 1991-2020 baseline)
  storage  : reservoir post-monsoon / dry-season surface area (EXP-WAT-001)
  response : dry-season green-cropland share (dry NDVI > 0.4 on a FIXED agricultural frame = silver agriculture 2021 AND never settled per WSF
             AND GHSL 2020 < 0.05 - independent of our temporal maps), post-monsoon cropland NDVI, natural-vegetation dry NDVI
Associations: Spearman on FIRST DIFFERENCES (removes shared trends, incl. sensor-era drift), lags 0 and 1 year; n and p reported.
Vegetation trend: per-pixel Theil-Sen slope + Mann-Kendall of dry NDVI over 2000-2026 (ETM+/OLI) and 1990-2026, summarised by silver class.
TerraClimate water-balance variables: PENDING (Planetary Computer zarr access failed: adlfs async loop error)."""
import json, sys, warnings
import numpy as np, pandas as pd, rasterio
from scipy.stats import spearmanr, gamma, norm, kendalltau
sys.path.insert(0, "src"); warnings.filterwarnings("ignore")
from pune_eo import config
from pune_eo.classification import baseline as B
from pune_eo.modelling.registry import Experiment
from rasterio.warp import transform_bounds
W = ["pune_G30_khadakwasla_mutha", "pune_G30_baramati_agri", "pune_G30_mulshi_ghats"]; YRS = np.arange(1990, 2027)
def rd(p, b=1):
    with rasterio.open(p) as s: return s.read(b)
with rasterio.open(config.path("data/processed/climate/chirps_v2_monthly_stack.tif")) as s:
    CH = s.read().astype(float); CH[CH < 0] = np.nan; desc = list(s.descriptions); ctr = s.transform; ccrs = s.crs
idx = pd.to_datetime([d[-7:] for d in desc])
def rain(gid):
    x0, y0, x1, y1 = json.loads(B.open_cube(gid).attrs["grid"])["bounds"]; lo0, la0, lo1, la1 = transform_bounds("EPSG:32643", ccrs, x0, y0, x1, y1)
    c0, r0 = ~ctr * (lo0, la1); c1, r1 = ~ctr * (lo1, la0)
    return pd.Series(np.nanmean(CH[:, int(np.floor(r0)):int(np.ceil(r1)), int(np.floor(c0)):int(np.ceil(c1))], axis=(1, 2)), index=idx)
def spi12(m):
    acc = m.rolling(12).sum(); out = pd.Series(np.nan, index=m.index)
    for mo in range(1, 13):
        s = acc[acc.index.month == mo]; base = s[(s.index.year >= 1991) & (s.index.year <= 2020)].dropna()
        a, loc, sc = gamma.fit(base, floc=0); out[s.index] = norm.ppf(np.clip(gamma.cdf(s, a, loc, sc), 1e-6, 1 - 1e-6))
    return out
res = {"vegetation_trend": {}, "associations": {}}; series_rows = []
wat = pd.read_csv(config.path("results/water/reservoir_area_series.csv"))
eV = Experiment(experiment_id="EXP-VEG-001", research_question="RQ-V: Where and how has dry-season vegetation greenness changed (1990-2026, 2000-2026)?",
                hypothesis="natural vegetation shows positive greenness trends; trends 1990-2026 are partly confounded by the TM-era radiometric shift",
                dataset_version="cube G30 local_pune_g30_v2", years=YRS.tolist(), resolution_m=30, features=["dry_ndvi"], labels="silver_l1 (stratification only)",
                split="n/a", model="Theil-Sen + Mann-Kendall per pixel (sampled)", hyperparameters={"sample_per_class": 4000}, seed=0)
eS = Experiment(experiment_id="EXP-STRESS-001", research_question="RQ-S: How do rainfall supply, reservoir storage and agricultural/ecosystem greenness co-vary, and with what lag?",
                hypothesis="dry-season green-cropland share follows previous-monsoon rainfall and reservoir storage (lag 1), stronger where irrigation depends on local storage",
                dataset_version="cube G30; CHIRPS v2.0; EXP-WAT-001", years=YRS.tolist(), resolution_m=30, features=["dry_ndvi", "post_ndvi", "reservoir area", "CHIRPS"],
                labels="fixed agricultural frame (silver agri 2021 & WSF never settled & GHSL2020<0.05)", split="n/a (association, not causal)",
                model="Spearman on first differences, lags 0/1", hyperparameters={"green_threshold_dry_ndvi": 0.4}, seed=0)
rng = np.random.default_rng(0)
for gid in W:
    ds = B.open_cube(gid); d = config.path("data/labels", gid); sil = rd(d / "silver_l1.tif"); wsf = rd(d / "wsf_evolution_first_year.tif")
    gh = rd(d / "ghsl_built_fraction_90m.tif", 7).astype(float); H, Wd = sil.shape
    gh3 = np.pad(np.repeat(np.repeat(gh, 3, 0), 3, 1), ((0, max(0, H - 3 * gh.shape[0])), (0, max(0, Wd - 3 * gh.shape[1]))), constant_values=np.nan)[:H, :Wd]
    dn = ds.landsat.sel(feature="dry_ndvi").values; pn = ds.landsat.sel(feature="post_ndvi").values
    frame = (sil == 2) & (wsf == 0) & (gh3 < 0.05); natv = (sil == 3) & (wsf == 0)
    # vegetation trends by class (sampled pixels)
    vt = {}
    for c, nm in ((2, "agriculture"), (3, "natural_vegetation"), (1, "built_up")):
        r, cc = np.nonzero(sil == c)
        if r.size < 100: continue
        k = rng.choice(r.size, min(4000, r.size), replace=False); S = dn[:, r[k], cc[k]]; out = {}
        for lab, y0 in (("1990_2026", 1990), ("2000_2026", 2000)):
            t = YRS[YRS >= y0]; Y = S[YRS >= y0]; sl, pv = [], []
            for j in range(Y.shape[1]):
                f = np.isfinite(Y[:, j])
                if f.sum() < 10: continue
                from scipy.stats import theilslopes
                sl.append(theilslopes(Y[f, j], t[f])[0]); pv.append(kendalltau(t[f], Y[f, j])[1])
            sl, pv = np.array(sl), np.array(pv)
            out[lab] = {"median_slope_per_decade": float(np.median(sl) * 10), "share_sig_positive_p05": float(((sl > 0) & (pv < 0.05)).mean()),
                        "share_sig_negative_p05": float(((sl < 0) & (pv < 0.05)).mean()), "n": int(sl.size)}
        vt[nm] = out
    res["vegetation_trend"][gid] = vt
    # annual series
    rs = rain(gid); sp = spi12(rs)
    mons = rs[rs.index.month.isin([6, 7, 8, 9])]; mons = mons.groupby(mons.index.year).sum()
    df = pd.DataFrame({"year": YRS})
    df["monsoon_mm"] = mons.reindex(YRS).values; df["spi12_sep"] = sp[sp.index.month == 9].groupby(sp[sp.index.month == 9].index.year).first().reindex(YRS).values
    df["green_crop_share_dry"] = [float((dn[i][frame] > 0.4).mean()) if np.isfinite(dn[i][frame]).mean() > 0.9 else np.nan for i in range(len(YRS))]
    df["crop_post_ndvi"] = [float(np.nanmedian(pn[i][frame])) for i in range(len(YRS))]
    df["natveg_dry_ndvi"] = [float(np.nanmedian(dn[i][natv])) if natv.sum() > 100 else np.nan for i in range(len(YRS))]
    w = wat[wat.window == gid]
    if len(w):
        big = w.groupby("reservoir").area_post_km2.max().idxmax(); ww = w[w.reservoir == big].set_index("year")
        df["reservoir_post_km2"] = ww.area_post_km2.reindex(YRS).values; df["reservoir_dry_km2"] = ww.area_dry_km2.reindex(YRS).values
    df["window"] = gid; series_rows.append(df)
    def assoc(x, y, lag):
        a, b = df[x].diff().values, df[y].diff().values
        if lag: a, b = a[:-lag], b[lag:]
        f = np.isfinite(a) & np.isfinite(b)
        if f.sum() < 10: return {"rho": None, "p": None, "n": int(f.sum())}
        r_, p_ = spearmanr(a[f], b[f]); return {"rho": round(float(r_), 3), "p": round(float(p_), 4), "n": int(f.sum())}
    pairs = [("monsoon_mm", "crop_post_ndvi", 0), ("monsoon_mm", "green_crop_share_dry", 1), ("monsoon_mm", "natveg_dry_ndvi", 1),
             ("spi12_sep", "green_crop_share_dry", 1)]
    if "reservoir_post_km2" in df: pairs += [("monsoon_mm", "reservoir_post_km2", 0), ("reservoir_post_km2", "green_crop_share_dry", 1)]
    res["associations"][gid] = {f"{x} -> {y} (lag {l})": assoc(x, y, l) for x, y, l in pairs}
    print(gid, json.dumps(res["associations"][gid]), json.dumps({k: v.get("2000_2026", {}).get("median_slope_per_decade") for k, v in vt.items()}), flush=True)
out = config.path("results/stress"); pd.concat(series_rows).to_csv(out / "annual_supply_response_series.csv", index=False)
json.dump(res, open(out / "stress_vegetation_summary.json", "w"), indent=1)
eV.finish(res["vegetation_trend"], result="see results/stress/stress_vegetation_summary.json")
eS.finish(res["associations"], result="associations on first differences; NOT causal; see results/stress/", outputs={"series": "results/stress/annual_supply_response_series.csv"})
