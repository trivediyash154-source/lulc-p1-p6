"""Sentinel-2 L2A vs harmonised Landsat (OLI reference): co-registration and radiometric consistency."""
import json
from pathlib import Path
import numpy as np, rasterio
from pune_eo import config
from pune_eo.validation.audit import registration_test
from pune_eo.provenance import utcnow
C = config.path("data/composites/pune_G30_khadakwasla_mutha/2024")
L, S = C / "landsat/seasonal/dry", C / "sentinel2_on_G30/seasonal/dry"
pairs = {"blue": "blue", "green": "green", "red": "red", "nir08": "nir08", "swir16": "swir16", "swir22": "swir22"}
def rd(d, name):
    with rasterio.open(d / name) as s: a = s.read().astype(float); n = list(s.descriptions)
    a[a == -32768] = np.nan; return a / 1e4, n
la, ln = rd(L, "optical_composite.tif"); sa, sn = rd(S, "optical_composite.tif")
lu, _ = rd(L, "uncertainty.tif"); su, _ = rd(S, "uncertainty.tif")
with rasterio.open(L / "observation_count.tif") as s: lc = s.read(1)
with rasterio.open(S / "observation_count.tif") as s: sc = s.read(1)
reg = {b: registration_test(L / "optical_composite.tif", S / "optical_composite.tif", b, pairs[b]) for b in ("red", "nir08", "swir16")}
ok = (lc >= 3) & (sc >= 3)
rad = {}
for b, sb in pairs.items():
    x = la[ln.index(b)]; y = sa[sn.index(sb)]
    m = ok & np.isfinite(x) & np.isfinite(y) & (lu[ln.index(b)] < 0.01) & (su[sn.index(sb)] < 0.01)
    xx, yy = x[m], y[m]; r = np.corrcoef(xx, yy)[0, 1]
    s_rma = np.sign(r) * yy.std() / xx.std(); i_rma = yy.mean() - s_rma * xx.mean()
    rad[b] = {"n": int(m.sum()), "mean_landsat": float(xx.mean()), "mean_s2": float(yy.mean()), "bias_s2_minus_landsat": float((yy - xx).mean()),
              "rmsd": float(np.sqrt(((yy - xx) ** 2).mean())), "r": float(r), "rma_slope": float(s_rma), "rma_intercept": float(i_rma)}
nd = lambda a, n, b1, b2: (a[n.index(b1)] - a[n.index(b2)]) / (a[n.index(b1)] + a[n.index(b2)])
nl, ns = nd(la, ln, "nir08", "red"), nd(sa, sn, "nir08", "red"); m = ok & np.isfinite(nl) & np.isfinite(ns)
res = {"created_utc": utcnow(), "window": "khadakwasla_mutha", "grid": "G30", "period": "2024 dry (Jan-May)",
       "landsat": "harmonised to OLI (local_pune_v1)", "sentinel2": "L2A, SCL-masked, BOA offset applied, 10/20 m bands area-averaged to 30 m",
       "registration_px": {b: {k: v for k, v in r.items() if k != "tiles"} for b, r in reg.items()},
       "radiometry": rad, "ndvi": {"n": int(m.sum()), "bias_s2_minus_landsat": float((ns - nl)[m].mean()), "rmsd": float(np.sqrt(((ns - nl)[m] ** 2).mean())),
                                   "r": float(np.corrcoef(nl[m], ns[m])[0, 1])}}
out = config.path("results/audit/s2_landsat_consistency.json"); out.write_text(json.dumps(res, indent=1))
for b, r in reg.items(): print(f"registration {b:<7} dy {r['dy_px_median']:+.3f} dx {r['dx_px_median']:+.3f} px (IQR {r['dy_px_iqr']:.2f}/{r['dx_px_iqr']:.2f})")
for b, r in rad.items(): print(f"{b:<7} n={r['n']:>6} S2-L bias {r['bias_s2_minus_landsat']:+.4f} rmsd {r['rmsd']:.4f} r {r['r']:.3f} RMA slope {r['rma_slope']:.3f}")
print("NDVI", res["ndvi"])
