"""Phase-3 deliverable archives (each < 24 MiB; split automatically). Output: /mnt/user-data/outputs/phase3/
  phase3_core.zip                     code, configs, tests, docs, registry3, results/phase3 (json/csv), gold passes + freeze stamp, figures, git log + patches since Phase 2
  phase3_gold_blind_kit_partN.zip     blind interpreter kit for HUMAN Tier-A work: forms (2 interpreters), KML, Landsat + S2 10 m chips (no key, no strata)
  phase3_gold_KEY_evaluator_only.zip  the key (anon id -> sample, stratum, inclusion probability) - never give to interpreters
  phase3_product_<window>_partN.zip   era-aware probabilistic reconstruction rasters (research product, NOT validated; Gate 6 not passed)
Cubes, composites and the HET are regenerated with the scripts (README), not shipped."""
import os, subprocess, zipfile, sys
from pathlib import Path
sys.path.insert(0, "src")
from pune_eo import config
R = config.ROOT; OUT = Path(os.environ.get("PKG_OUT", "/mnt/user-data/outputs/phase3")); OUT.mkdir(parents=True, exist_ok=True); MAXB = 24 * 2 ** 20
def zip_files(name, files, root=R, prefix="pune-eo-phd"):
    parts, cur, size = [], [], 0
    for f in files:
        s = f.stat().st_size
        if cur and size + s > MAXB: parts.append(cur); cur, size = [], 0
        cur.append(f); size += s
    if cur: parts.append(cur)
    outs = []
    for i, fs in enumerate(parts):
        z = OUT / (f"{name}.zip" if len(parts) == 1 else f"{name}_part{i + 1}.zip")
        with zipfile.ZipFile(z, "w", zipfile.ZIP_DEFLATED) as zf:
            for f in fs: zf.write(f, Path(prefix) / f.relative_to(root))
        outs.append(z)
    return outs
SKIP = {".git", "__pycache__", ".pytest_cache", "ard_cache", "pune_eo.egg-info", "locks", ".venv", "export", "models", "_key", "_s2_cache", "chips_s2_2021", "sheets_s2_2021", "chips_landsat", "product"}
def core():
    pv = R / "results/provenance"; pv.mkdir(parents=True, exist_ok=True)
    (pv / "git_log_phase3.txt").write_text(subprocess.run(["git", "-C", str(R), "log", "--date=iso", "--pretty=%h %ad %s"], capture_output=True, text=True).stdout)
    pat = pv / "phase3_code_patches"; pat.mkdir(exist_ok=True)
    subprocess.run(["git", "-C", str(R), "format-patch", "-q", "-o", str(pat), "ba0a835..HEAD", "--", "src", "scripts", "configs", "tests", "docs", "README.md", ".gitignore"], check=False)
    fs = []
    for p in R.rglob("*"):
        if p.is_dir() or any(s in p.parts for s in SKIP): continue
        rel = p.relative_to(R); top = rel.parts[0]
        if top == "data":
            if rel.parts[1] in ("composites", "raw", "features", "products", "_phase1_snapshot"): continue
            if rel.parts[1] == "labels" and (p.suffix == ".tif" or "chips" in str(rel)): continue
        if top == "results" and (p.suffix in (".tif", ".npz", ".npy", ".pkl", ".parquet", ".joblib") or ("figures" in rel.parts and "phase3" not in rel.parts)): continue
        if p.stat().st_size > 20 * 2 ** 20: continue
        fs.append(p)
    return zip_files("phase3_core", sorted(fs))
def blind_kit():
    b = R / "data/labels/gold/blind"
    fs = sorted([p for p in b.glob("*") if p.is_file()] + list((b / "chips_landsat").rglob("*.png")) + list((b / "chips_s2_2021").glob("*.png")))
    return zip_files("phase3_gold_blind_kit", fs)
def key(): return zip_files("phase3_gold_KEY_evaluator_only", sorted((R / "data/labels/gold/_key").glob("*")))
def product():
    outs = []
    for d in sorted((R / "results/phase3/product").glob("pune_G30_*")): outs += zip_files(f"phase3_product_{d.name[9:]}", sorted(d.glob("recon_*.tif")))
    return outs
if __name__ == "__main__":
    allz = core() + blind_kit() + key() + product()
    for z in allz: print(z.name, round(z.stat().st_size / 2 ** 20, 1), "MiB")
    assert all(z.stat().st_size < 25 * 2 ** 20 for z in allz)
