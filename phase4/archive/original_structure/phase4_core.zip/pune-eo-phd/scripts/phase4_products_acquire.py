"""Phase 4: bring existing products onto the DISTRICT 30 m grid (pune_G30 = Landsat lattice over the buffered study area).
Independent benchmark products (never training labels): GLC_FCS30D 1985-2022, GISA 2.0 (impervious first year 1972-2021), WSF-Evolution 1985-2015,
GHSL BUILT-S 1990-2020 (90 m nested), JRC GSW, ESA CCI LC 1992-2020 (kept at 300 m).
Tier-C products (silver sources, NOT independent): ESA WorldCover 2020/2021, Esri LULC 2017-2023 (dominant class per 30 m cell, GDAL 'mode').
Outputs: data/products_ext/<product>/*.tif + provenance JSON; WSF/GHSL/JRC via the existing pune_eo.labels.sources functions -> data/labels/pune_G30/.
Usage: python3 scripts/phase4_products_acquire.py [step ...]   steps: grid glc gisa wsf ghsl jrc cci esri worldcover"""
import json, sys, time, warnings
from pathlib import Path
import numpy as np, rasterio, requests
from rasterio.enums import Resampling
from rasterio.vrt import WarpedVRT
from rasterio.features import rasterize
sys.path.insert(0, "src"); warnings.filterwarnings("ignore")
from pune_eo import config
from pune_eo.grid import district_grid, Grid
from pune_eo.io import write_cog, write_json
from pune_eo.provenance import utcnow
from pune_eo.labels import sources as SRC
OUT = config.path("data/products_ext"); RAW = config.path("data/raw/products"); OUT.mkdir(parents=True, exist_ok=True); RAW.mkdir(parents=True, exist_ok=True)
G = district_grid("G30"); steps = sys.argv[1:] or ["grid", "glc", "gisa", "wsf", "ghsl", "jrc", "cci", "esri", "worldcover"]
def log(*a): print(time.strftime("%H:%M:%S"), *a, flush=True)
def warp_file(path, resampling=Resampling.nearest, band=1, src_nodata=None, dst_nodata=0, dtype="uint8", grid=G):
    with rasterio.Env(**config.GDAL_ENV), rasterio.open(path) as src, WarpedVRT(src, crs=grid.crs, transform=grid.transform, width=grid.width, height=grid.height,
                                                                              resampling=resampling, src_nodata=src_nodata if src_nodata is not None else src.nodata, nodata=dst_nodata, dtype=dtype) as v:
        return v.read(band)
if "grid" in steps:
    import geopandas as gpd
    ba = gpd.read_file(config.path("data/boundary/study_area.gpkg")).to_crs(G.crs)
    m = rasterize([(g, 1) for g in ba.geometry], out_shape=G.shape, transform=G.transform, fill=0, dtype="uint8")
    d = OUT / "district"; d.mkdir(exist_ok=True); write_cog(d / "district_mask_30m.tif", m, G, nodata=None, dtype="uint8", descriptions=["inside_district"], overview_resampling="nearest")
    write_json(d / "district_grid.json", {"grid": G.to_dict(), "cells_inside": int(m.sum()), "area_km2_inside": float(m.sum() * 0.0009), "created_utc": utcnow()}); log("grid", G.shape, int(m.sum()))
if "glc" in steps:
    from remotezip import RemoteZip
    url = "https://zenodo.org/records/15063683/files/GLC_FCS30D_19852022maps_E70-E75.zip?download=1"; d = RAW / "glc_fcs30d"; d.mkdir(parents=True, exist_ok=True)
    want = [f"GLC_FCS30D_19852022maps_E70-E75/GLC_FCS30D_{p}_{t}_{k}_V1.1.tif" for t in ("E70N20", "E75N20") for p, k in (("19852000", "5years"), ("20002022", "Annual"))]
    with RemoteZip(url) as z:
        for w in want:
            if not (d / Path(w).name).exists(): log("extract", w); (d / Path(w).name).write_bytes(z.read(w))
    # files are PIXEL-interleaved (all bands decoded together): read the district window of ALL bands once per file, then reproject from memory
    from rasterio.warp import reproject
    from rasterio.windows import from_bounds
    years = [1985, 1990, 1995] + list(range(2000, 2023)); lo0, la0, lo1, la1 = SRC._bbox_ll(G); acc = np.zeros((len(years),) + G.shape, np.uint8)
    for t in ("E70N20", "E75N20"):
        for kind, ys in (("19852000_{t}_5years", years[:3]), ("20002022_{t}_Annual", years[3:])):
            f = d / f"GLC_FCS30D_{kind.format(t=t)}_V1.1.tif"
            with rasterio.open(f) as src:
                win = from_bounds(lo0 - 0.01, la0 - 0.01, lo1 + 0.01, la1 + 0.01, src.transform).round_offsets().round_lengths()
                win = win.intersection(rasterio.windows.Window(0, 0, src.width, src.height)); arr = src.read(window=win); tr = src.window_transform(win); crs = src.crs
            log("read", f.name, arr.shape)
            for bi, y in enumerate(ys):
                dst = np.zeros(G.shape, np.uint8); reproject(arr[bi], dst, src_transform=tr, src_crs=crs, src_nodata=0, dst_transform=G.transform, dst_crs=G.crs, dst_nodata=0, resampling=Resampling.nearest)
                k = years.index(y); acc[k] = np.where((acc[k] == 0) & (dst != 0) & (dst != 250), dst, acc[k])
    bands = list(acc); log("glc valid share per year", [round(float((b > 0).mean()), 3) for b in bands])
    o = OUT / "glc_fcs30d"; o.mkdir(exist_ok=True)
    write_cog(o / "glc_fcs30d_district_30m.tif", np.stack(bands), G, nodata=0, dtype="uint8", descriptions=[str(y) for y in years], overview_resampling="nearest")
    write_json(o / "glc_fcs30d_district_30m.json", {"source": "GLC_FCS30D v2 (Zenodo 10.5281/zenodo.15063683, CC-BY 4.0), tiles E70N20 + E75N20", "years": years,
               "note_5years_file": "the 19852000 '5years' file holds 1985, 1990, 1995 (user guide)", "method": "nearest onto pune_G30 (EPSG:32643)", "nodata": [0, 250],
               "producer_accuracy": "80.88 % (+-0.27) basic 10 classes; 73.24 % (+-0.30) LCCS level-1 17 classes (global; user guide)", "created_utc": utcnow()})
if "gisa" in steps:
    f = RAW / "gisa" / "GISA_new_1972_2021_20N_60E.tif"
    if not f.exists(): SRC._download("https://zenodo.org/records/14848113/files/GISA_new_1972_2021_20N_60E.tif?download=1", f)
    a = warp_file(f, src_nodata=None, dst_nodata=255); lut = [1972, 1978] + list(range(1985, 2022))
    yr = np.zeros(G.shape, np.uint16); ok = (a >= 1) & (a <= 39); yr[ok] = np.array(lut, np.uint16)[a[ok] - 1]
    o = OUT / "gisa"; o.mkdir(exist_ok=True); write_cog(o / "gisa2_first_year_district_30m.tif", yr, G, nodata=None, dtype="uint16", descriptions=["first_year_impervious_0_never"], overview_resampling="nearest")
    write_json(o / "gisa2_first_year_district_30m.json", {"source": "GISA 2.0, Ren, Huang et al. 2025 ISPRS J. 220:354-376; Zenodo 10.5281/zenodo.14848113 (CC-BY 4.0)", "lut": lut,
               "outside_tile_value_255": int((a == 255).sum()), "method": "nearest onto pune_G30; value -> first year via producer LUT", "created_utc": utcnow()}); log("gisa", int((yr > 0).sum()))
if "wsf" in steps: log("wsf", SRC.wsf_evolution(G))
if "ghsl" in steps: log("ghsl", SRC.ghsl_built(G))
if "jrc" in steps: log("jrc", SRC.jrc_water(G))
if "cci" in steps:
    g300 = Grid("pune_G300", G.crs, 300.0, G.x0, G.y1, int(np.ceil(G.width / 10)), int(np.ceil(G.height / 10)), G.corner_offset)
    items = sorted(SRC.client().search(collections=["esa-cci-lc"], bbox=SRC._bbox_ll(G)).items(), key=lambda i: str(i.datetime or i.properties.get("start_datetime")))
    bands, yrs = [], []
    for it in items:
        y = int(str(it.properties.get("start_datetime", it.datetime))[:4])
        if y in yrs: continue
        a = SRC._warp(it.assets["lccs_class"].href, g300, Resampling.nearest, dst_nodata=0); bands.append(a); yrs.append(y); log("cci", y)
    o = OUT / "esa_cci_lc"; o.mkdir(exist_ok=True)
    write_cog(o / "esa_cci_lc_district_300m.tif", np.stack(bands), g300, nodata=0, dtype="uint8", descriptions=[str(y) for y in yrs], overview_resampling="nearest")
    write_json(o / "esa_cci_lc_district_300m.json", {"source": "ESA CCI Land Cover (Planetary Computer esa-cci-lc)", "years": yrs, "grid": g300.to_dict(), "method": "nearest onto 300 m UTM grid aligned with pune_G30", "created_utc": utcnow()})
for prod, coll, asset in (("esri", "io-lulc-annual-v02", "data"), ("worldcover", "esa-worldcover", "map")):
    if prod not in steps: continue
    made = {}
    for it in SRC.client().search(collections=[coll], bbox=SRC._bbox_ll(G)).items(): made.setdefault(int(str(it.properties.get("start_datetime", it.datetime))[:4]), []).append(it)
    o = OUT / prod; o.mkdir(exist_ok=True); bands, yrs = [], []
    for y in sorted(made):
        acc = np.zeros(G.shape, np.uint8)
        for it in made[y]:
            a = SRC._warp(it.assets[asset].href, G, Resampling.mode, dst_nodata=0); acc = np.where(acc == 0, a, acc)
        bands.append(acc); yrs.append(y); log(prod, y, round(float((acc > 0).mean()), 3))
    write_cog(o / f"{prod}_district_30m_mode.tif", np.stack(bands), G, nodata=0, dtype="uint8", descriptions=[str(y) for y in yrs], overview_resampling="nearest")
    write_json(o / f"{prod}_district_30m_mode.json", {"collection": coll, "years": yrs, "method": "GDAL mode resampling 10 m -> pune_G30", "role": "Tier C (silver-label source 2020-21) - NOT independent", "created_utc": utcnow()})
log("done", steps)
