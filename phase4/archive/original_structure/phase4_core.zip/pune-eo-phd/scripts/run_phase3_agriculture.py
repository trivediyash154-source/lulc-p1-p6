"""Phase-3 group M — agriculture WITHOUT crop-type claims (no crop labels exist).
P3-M1  agricultural STATE framework per cell-year (HET cells, 1990-2026), every layer tagged:
         OBSERVED  seasonal_amplitude = post-monsoon NDVI - dry-season NDVI (Landsat composites, as observed)
         INFERRED  p_cropland = P(agriculture) from the Phase-3 2021 XGBoost (Landsat seasonal + terrain; silver Tier C) applied to year t
         PROXY     dry_green = dry-season NDVI >= 0.35 on cells with p_cropland >= 0.5 (an irrigation-LIKELIHOOD proxy, not irrigation)
         PROXY     cropping_intensity_s2 (2021 only, Baramati G30) = number of NDVI peaks >= 0.4 separated by >= 3 months in the S2 monthly series
       consistency with rainfall: Spearman of window-year means vs SPI-12(t-1) — association, not cause.
P3-M2  10 m vs 30 m separability of cropping regimes (Baramati 2021, agriculture silver cells): k-means on monthly S2 NDVI (+ S1 VH monthly, G30),
       silhouette for k = 2..6 and bootstrap ARI stability; the 10 m sample = the S2 pixel touching each 30 m cell centre (same n as 30 m).
P3-M3  official statistics: availability and usable spatial support (district aggregates only) — area agreement needs a district-scale map.
Usage: python3 scripts/run_phase3_agriculture.py m1m3 | m2"""
import json, sys, warnings
import numpy as np, pandas as pd, rasterio
sys.path.insert(0, "src"); warnings.filterwarnings("ignore")
from scipy.stats import spearmanr
from pune_eo import config
from pune_eo.historical_reconstruction import het, features as F
from pune_eo.validation import registry3 as R3
OUT = config.path("results/phase3/agriculture"); OUT.mkdir(parents=True, exist_ok=True); SEED = 20261102; part = sys.argv[1] if len(sys.argv) > 1 else "m1m3"
H = het.load(); M = H["meta"]; YEARS = H["info"]["years"]; fi = lambda n: H["info"]["features"].index(n)
if part == "m1m3":
    import joblib; mx = joblib.load(config.path("results/phase3/baseline/xgb_B3T_2021.joblib"))
    pc = np.stack([mx.predict_proba(np.hstack([F.build(H, "B3", y)[0], H["T"]]))[:, 1] for y in YEARS], 1).astype(np.float32)   # class order 1..4 -> col 1 = agriculture
    amp = (H["L"][:, :, fi("post_ndvi")] - H["L"][:, :, fi("dry_ndvi")]).astype(np.float32); dry = H["L"][:, :, fi("dry_ndvi")]
    dgreen = np.where(np.isfinite(dry) & (pc >= 0.5), (dry >= 0.35).astype(np.float32), np.nan)
    np.savez_compressed(OUT / "ag_state_het_cells.npz", p_cropland=pc, seasonal_amplitude=amp, dry_green_proxy=dgreen, years=np.array(YEARS))
    rows = []
    for g in M.window.unique():
        w = (M.window == g).values
        for j, y in enumerate(YEARS):
            crop = w & (pc[:, j] >= 0.5)
            rows.append({"window": g, "year": y, "coverage_observed": float(np.isfinite(amp[w, j]).mean()), "cropland_share_inferred": float(crop.sum() / w.sum()),
                         "mean_amplitude_on_cropland_observed": float(np.nanmean(amp[crop, j])) if crop.any() else None, "dry_green_share_proxy": float(np.nanmean(dgreen[crop, j])) if crop.any() else None})
    T = pd.DataFrame(rows).merge(H["climate"][["window", "year", "spi12_prev", "climate_class"]], on=["window", "year"], how="left"); T.to_csv(OUT / "ag_state_window_year.csv", index=False)
    assoc = {}
    for g, d in T.dropna(subset=["spi12_prev"]).groupby("window"):
        assoc[g] = {k: {"spearman": float(spearmanr(d.spi12_prev, d[k], nan_policy="omit").correlation), "p": float(spearmanr(d.spi12_prev, d[k], nan_policy="omit").pvalue)} for k in ("dry_green_share_proxy", "mean_amplitude_on_cropland_observed", "cropland_share_inferred")}
    # S2 cropping-intensity proxy, Baramati 2021 (G30 monthly composites, SCL reader v2)
    base = config.path("data/composites/pune_G30_baramati_agri/2021/sentinel2/monthly"); nd = []
    for mth in range(1, 13):
        with rasterio.open(base / f"2021-{mth:02d}" / "optical_composite.tif") as s: a = s.read([3, 7]).astype(float); a[a <= 0] = np.nan
        nd.append((a[1] - a[0]) / (a[1] + a[0]))
    nd = np.stack(nd); valid_months = np.isfinite(nd).sum(0)
    def peaks(v):
        k = np.flatnonzero(np.isfinite(v)); v = v[k]; pk = [k[i] for i in range(len(v)) if v[i] >= 0.4 and (i == 0 or v[i] >= v[i - 1]) and (i == len(v) - 1 or v[i] >= v[i + 1])]
        out = []
        for p in pk:
            if not out or p - out[-1] >= 3: out.append(p)
        return len(out)
    b = (M.window == "pune_G30_baramati_agri").values & (M.silver == 2).values; rr, cc = M.row.values[b], M["col"].values[b]
    ci = np.array([peaks(nd[:, r, c]) if valid_months[r, c] >= 8 else -1 for r, c in zip(rr, cc)])
    m1 = {"layers": {"seasonal_amplitude": "OBSERVED", "p_cropland": "INFERRED (silver-trained model, Tier C)", "dry_green_proxy": "PROXY (irrigation-likelihood, not irrigation)",
                     "cropping_intensity_s2_2021": "PROXY (NDVI peak count, 30 m S2 monthly)"},
          "coverage_observed_min_by_window": T.groupby("window").coverage_observed.min().round(4).to_dict(), "years_with_coverage_ge_0.9": T.groupby("window").apply(lambda d: int((d.coverage_observed >= 0.9).sum())).to_dict(),
          "association_with_spi12_prev": assoc, "cropping_intensity_s2_baramati_agri_cells": {"n": int(len(ci)), "share_by_peaks": pd.Series(ci).value_counts(normalize=True).sort_index().round(4).to_dict(),
                                                                                            "insufficient_months_share": float((ci == -1).mean()), "valid_months_median": float(np.median(valid_months[rr, cc]))},
          "crop_type": "NOT PRODUCED — no crop-type labels; any crop-type map would be fabrication"}
    cov_ok = all(v >= 0.9 * len(YEARS) for v in m1["years_with_coverage_ge_0.9"].values())
    R3.Run("P3-M1").complete(m1, "SUPPORTED" if cov_ok else "INCONCLUSIVE", f"state layers produced with tags for {len(M)} HET cells x {len(YEARS)} years; years with observed coverage >= 0.9: {m1['years_with_coverage_ge_0.9']}; "
                             f"dry-green proxy vs SPI-12(t-1) Spearman: " + ", ".join(f"{g[9:]} {v['dry_green_share_proxy']['spearman']:+.2f}" for g, v in assoc.items()) + " (association); crop type not produced",
                             outputs={"cells": "results/phase3/agriculture/ag_state_het_cells.npz", "table": "results/phase3/agriculture/ag_state_window_year.csv"})
    m3 = {"searched": ["district statistical abstract / Agricultural Statistical Information, Maharashtra", "district agriculture contingency plan"],
          "found": [{"source": "ICAR-CRIDA District Agriculture Contingency Plan, Pune (MPKV Rahuri, 31.03.2011), tables citing Agricultural Statistical Information, Maharashtra State (2006), Vol. I & II",
                     "url": "https://www.icar-crida.res.in/CP/Maharastra/MPKVV,%20Rahuri/MH8-%20PUNE%2031.03.2011.pdf",
                     "values_000_ha": {"geographical_area": 1562.0, "net_sown_area": 945, "area_sown_more_than_once": 203, "gross_cropped_area": 1148, "cropping_intensity_pct": 121,
                                       "forest": 165.1, "non_agricultural_use": 114.0, "current_fallows": 34.5, "other_fallows": 39.8, "net_irrigated": 287}},
                    {"source": "indiastatdistrictagri.com Pune district tables", "url": "https://www.indiastatdistrictagri.com/maharashtra/pune-district", "note": "subscription; not accessed"}],
          "spatial_support": "district totals (c. 2005 reference) — the three benchmark windows cover a small fraction of the district and do not coincide with tahsil boundaries",
          "area_agreement": "NOT COMPUTABLE until a district-scale cropland map exists (P3-O3); comparison would also need matching reference years and the NSA definition (net sown, not cropland cover)"}
    R3.Run("P3-M3").complete(m3, "INCONCLUSIVE", "official district aggregates available (NSA 945 kha, GCA 1148 kha, cropping intensity 121 %, c. 2005 via ICAR-CRIDA contingency plan); "
                             "no window-level statistics -> area agreement not computable at benchmark scale", outputs={})
    json.dump({"M1": m1, "M3": m3}, open(OUT / "agriculture_m1_m3.json", "w"), indent=1, default=float); print("M1/M3 done", m1["years_with_coverage_ge_0.9"])
else:
    from sklearn.cluster import KMeans
    from sklearn.metrics import silhouette_score, adjusted_rand_score
    b10 = config.path("data/composites/pune_G10_baramati_agri/2021/sentinel2/monthly"); b30 = config.path("data/composites/pune_G30_baramati_agri/2021/sentinel2/monthly"); s1 = config.path("data/composites/pune_G30_baramati_agri/2021/sentinel1/monthly")
    if not (b10 / "2021-01" / "optical_composite.tif").exists(): sys.exit("REFUSED: G10 S2 2021 composites missing (run scripts/run_sentinel.py sentinel2 --grid G10 --window baramati_agri --years 2021)")
    def ndvi_stack(base):
        out = []
        for mth in range(1, 13):
            with rasterio.open(base / f"2021-{mth:02d}" / "optical_composite.tif") as s: a = s.read([3, 7]).astype(float); a[a <= 0] = np.nan
            out.append((a[1] - a[0]) / (a[1] + a[0]))
        return np.stack(out)
    N10, N30 = ndvi_stack(b10), ndvi_stack(b30); VH = []
    for mth in range(1, 13):
        with rasterio.open(s1 / f"2021-{mth:02d}" / "backscatter_median_db.tif") as s: VH.append(s.read(2).astype(float))
    VH = np.stack(VH)
    b = np.flatnonzero((M.window == "pune_G30_baramati_agri").values & (M.silver == 2).values); rr, cc = M.row.values[b], M["col"].values[b]
    r10, c10 = 3 * rr + 1, 3 * cc                                     # G10 x0/y1 offset (+15 m, -5 m) from G30: pixel touching the cell centre
    ok10 = (r10 < N10.shape[1]) & (c10 < N10.shape[2]); rr, cc, r10, c10 = rr[ok10], cc[ok10], r10[ok10], c10[ok10]
    A30, A10, V = N30[:, rr, cc].T, N10[:, r10, c10].T, VH[:, rr, cc].T
    months = [m for m in range(12) if np.isfinite(A30[:, m]).mean() >= 0.8 and np.isfinite(A10[:, m]).mean() >= 0.8]
    keep = np.isfinite(A30[:, months]).all(1) & np.isfinite(A10[:, months]).all(1) & np.isfinite(V).all(1)
    rng = np.random.default_rng(SEED); idx = rng.choice(np.flatnonzero(keep), min(3000, keep.sum()), replace=False)
    sets = {"30m_ndvi": A30[idx][:, months], "10m_ndvi": A10[idx][:, months], "30m_ndvi+s1vh": np.hstack([A30[idx][:, months], (V[idx] + 20) / 20]), "10m_ndvi+s1vh": np.hstack([A10[idx][:, months], (V[idx] + 20) / 20])}
    res = {"months_used": [m + 1 for m in months], "n_cells": int(len(idx)), "silhouette": {}, "bootstrap_ari": {}}
    for name, X in sets.items():
        res["silhouette"][name] = {}; res["bootstrap_ari"][name] = {}
        for k in range(2, 7):
            km = KMeans(k, n_init=10, random_state=SEED).fit(X); res["silhouette"][name][k] = float(silhouette_score(X, km.labels_))
            aris = []
            for bsd in range(10):
                bi = rng.choice(len(X), len(X)); aris.append(adjusted_rand_score(km.labels_, KMeans(k, n_init=5, random_state=bsd).fit(X[bi]).predict(X)))
            res["bootstrap_ari"][name][k] = float(np.mean(aris))
    better = sum(res["silhouette"]["10m_ndvi"][k] > res["silhouette"]["30m_ndvi"][k] + 0.02 for k in range(2, 7)); worse = sum(res["silhouette"]["10m_ndvi"][k] < res["silhouette"]["30m_ndvi"][k] - 0.02 for k in range(2, 7))
    json.dump(res, open(OUT / "agriculture_m2.json", "w"), indent=1)
    R3.Run("P3-M2").complete(res, "SUPPORTED" if better >= 4 else ("NOT_SUPPORTED" if worse >= 1 or better <= 1 else "INCONCLUSIVE"),
                             "silhouette k=2..6 30 m " + str([round(res['silhouette']['30m_ndvi'][k], 3) for k in range(2, 7)]) + " vs 10 m " + str([round(res['silhouette']['10m_ndvi'][k], 3) for k in range(2, 7)]) +
                             f"; months used {res['months_used']}; clusters are NOT crop types", outputs={"summary": "results/phase3/agriculture/agriculture_m2.json"})
    print("M2", res["silhouette"])
