"""Phase 4 training-label and validation-label audit (read-only on existing data) -> data/inventory/label_audit.json, results/phase4/audit/.
Training labels = silver L1 (unanimous WorldCover 2020/2021 + Esri 2020/2021 with purity >= 0.78 at 30 m) and the Tier-D multi-year extension.
Measured per window: coverage and class counts, split balance, heterogeneity / edge / mixing bias of silver cells vs all cells ('easy-cell bias'),
spatial autocorrelation range of class indicators vs the 3 km block size, temporal mismatch, and evidence of reference-product learning (gold eval)."""
import json, sys, warnings
import numpy as np, pandas as pd, rasterio, xarray as xr
from scipy.ndimage import uniform_filter, maximum_filter, minimum_filter
sys.path.insert(0, "src"); warnings.filterwarnings("ignore")
from pune_eo import config
OUT = config.path("results/phase4/audit"); OUT.mkdir(parents=True, exist_ok=True); INV = config.path("data/inventory")
W = ["pune_G30_khadakwasla_mutha", "pune_G30_baramati_agri", "pune_G30_mulshi_ghats"]; CL = {1: "built_up", 2: "agriculture", 3: "natural_vegetation", 4: "water"}
rng = np.random.default_rng(20261105); R = {"windows": {}}
def rd(g, f, b=None):
    with rasterio.open(config.path("data/labels", g, f)) as s: return s.read(b) if b else s.read()
for g in W:
    sil = rd(g, "silver_l1.tif", 1); sp = rd(g, "splits.tif", 1); wc = rd(g, "esa_worldcover_2021_l1_fractions.tif").astype(float)
    gh = rd(g, "ghsl_built_fraction_90m.tif").astype(float); H, Wd = sil.shape; gh20 = np.repeat(np.repeat(gh[6], 3, 0), 3, 1)[:H, :Wd]
    gh20 = np.pad(gh20, ((0, H - gh20.shape[0]), (0, Wd - gh20.shape[1])), constant_values=np.nan)
    ds = xr.open_zarr(config.path("data/features/cube", f"{g}.zarr")); ndvi = ds.landsat.sel(year=2021, feature="dry_ndvi").values.astype(float)
    m = np.isfinite(ndvi); nd0 = np.where(m, ndvi, 0); mu = uniform_filter(nd0, 3); mu2 = uniform_filter(nd0 ** 2, 3); loc_sd = np.sqrt(np.clip(mu2 - mu ** 2, 0, None))
    dom = np.where(np.isfinite(wc).all(0), np.nanargmax(np.nan_to_num(wc, nan=-1), 0) + 1, 0); purity = np.nanmax(wc, 0)
    edge = (maximum_filter(dom, 3) != minimum_filter(dom, 3))
    lab = sil > 0; r = {"cells": int(sil.size), "silver_labelled_fraction": float(lab.mean()),
         "class_counts_all_silver": {CL[k]: int((sil == k).sum()) for k in CL}, "class_counts_by_split": {s_: {CL[k]: int(((sil == k) & (sp == c)).sum()) for k in CL} for c, s_ in ((1, "train"), (2, "val"), (3, "test"))},
         "silver_share_of_worldcover_class": {CL[k]: float(((sil == k) & (dom == k)).sum() / max((dom == k).sum(), 1)) for k in CL},
         "easy_cell_bias": {"local_sd_dry_ndvi_median": {"silver": float(np.median(loc_sd[lab & m])), "unlabelled": float(np.median(loc_sd[~lab & m]))},
                            "edge_cell_share": {"silver": float(edge[lab].mean()), "unlabelled": float(edge[~lab].mean())},
                            "worldcover_purity_median": {"silver": float(np.nanmedian(purity[lab])), "unlabelled": float(np.nanmedian(purity[~lab]))},
                            "ghsl2020_built_fraction_median_for_built": {"silver_built": float(np.nanmedian(gh20[sil == 1])) if (sil == 1).any() else None, "worldcover_built_not_silver": float(np.nanmedian(gh20[(dom == 1) & ~lab])) if ((dom == 1) & ~lab).any() else None}}}
    # spatial autocorrelation of class indicators (WorldCover dominant class, full coverage) - correlogram on random pairs
    corr = {}
    ys, xs = np.nonzero(dom > 0); n = 40000; i = rng.integers(0, len(ys), n)
    for lag_m in (90, 300, 600, 1000, 1500, 2000, 3000, 4000, 6000):
        ang = rng.uniform(0, 2 * np.pi, n); dy = np.round(np.sin(ang) * lag_m / 30).astype(int); dx = np.round(np.cos(ang) * lag_m / 30).astype(int)
        y2, x2 = ys[i] + dy, xs[i] + dx; ok = (y2 >= 0) & (y2 < H) & (x2 >= 0) & (x2 < Wd); a = dom[ys[i][ok], xs[i][ok]]; b = dom[y2[ok], x2[ok]]; ok2 = b > 0
        cc = {}
        for k in CL:
            ia, ib = (a[ok2] == k).astype(float), (b[ok2] == k).astype(float)
            cc[CL[k]] = float(np.corrcoef(ia, ib)[0, 1]) if ia.std() > 0 and ib.std() > 0 else None
        corr[lag_m] = cc
    rng_m = {}
    for k in CL.values():
        lags = [l for l in corr if corr[l][k] is not None and corr[l][k] < 0.1]; rng_m[k] = min(lags) if lags else ">6000"
    r["indicator_correlogram"] = corr; r["autocorrelation_range_m_corr_lt_0.1"] = rng_m
    R["windows"][g] = r; print(g, r["silver_labelled_fraction"], rng_m, flush=True)
# reference-product learning evidence from the Phase-3 gold evaluation (Tier C)
ge = json.loads(config.path("results/phase3/gold/gold_provisional_eval.json").read_text())
R["reference_learning_evidence"] = {"model_vs_AI_agreement_on_silver_points": ge["products"]["phase3_xgb_B3T"]["on_silver_labelled_points"], "model_vs_AI_agreement_on_no_silver_points": ge["products"]["phase3_xgb_B3T"]["on_no_silver_points"],
    "silver_l1_vs_AI_macro_f1": ge["products"]["silver_l1"]["unweighted"]["macro_f1"], "worldcover_vs_AI_on_no_silver_points": ge["products"]["worldcover_2021"]["on_no_silver_points"], "esri_vs_AI_on_no_silver_points": ge["products"]["esri_2021"]["on_no_silver_points"],
    "AI_abstention_by_stratum": ge["abstention"]["by_stratum"]}
het = json.loads(config.path("data/features/het_v1/info.json").read_text())
R["training_design"] = {"label_years": "silver valid for 2020-2021 only; models trained on 2021 (C group 2020+2021); Tier-D multi-year extension along PELT change-free segments (training only)",
    "temporal_mismatch": "applying 2021 labels to 1990-2019 features assumes no change and no sensor shift - a candidate cause of the historical failure (associated with it in Phase 3, not tested confirmatorily)",
    "HET_sampling": "silver cells capped per class and split (train 2500 / val 1500 / test 3000 per window) - balanced sample, NOT the population", "het_by_window": het.get("by_window")}
R["validation_labels"] = {"tier_A_human": 0, "tier_B": {"WSF_Evolution": "first settled year 1985-2015, 30 m, built only", "GHSL_BUILT_S": "1990-2020 5-yearly, 90 m built fraction", "JRC_GSW": "water occurrence 1984-2021, 30 m",
    "coverage": "3 windows only (district: JRC + WorldCover mode at 240 m)"}, "tier_C": {"silver": "2020-21, easy cells, 41-62 % of window cells", "provisional_AI": f"{int(437)} non-abstained 2021 points, S2-based (shares evidence with WorldCover/Esri)"},
    "classes_with_no_independent_reference": ["agriculture", "natural_vegetation"], "epochs_with_no_independent_reference_for_non_built_classes": "every epoch except 2020-2021 (silver/AI, Tier C)"}
json.dump(R, open(config.path("data/inventory/label_audit.json"), "w"), indent=1, default=str); print("ok")
