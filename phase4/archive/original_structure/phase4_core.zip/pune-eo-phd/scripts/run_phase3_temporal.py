"""Phase-3 group B (temporal information) - pre-registered P3-B1..B4, P3-B1m..B4m, P3-B5m, P3-B4t.
Training: silver 2021 train-block cells (2021-only) OR the same cells extended along PELT change-free segments (multi-year, Tier D, training only).
Evaluation (Tier B, TEST blocks only): false built-up rate (FBR) on never-settled cells, stable-built recall, deep-water recall, per year 1990-2026;
silver 4-class macro-F1 on test cells 2021 and 2020. Predictions saved for the D-group strata and paired block bootstrap."""
import json, sys, time, warnings
import numpy as np, pandas as pd
from sklearn.ensemble import RandomForestClassifier
from sklearn.metrics import f1_score
sys.path.insert(0, "src"); warnings.filterwarnings("ignore")
from pune_eo import config
from pune_eo.historical_reconstruction import het, features as F
from pune_eo.change_detection import changepoints as CP
from pune_eo.validation import registry3 as R3
from pune_eo.validation.stats3 import block_bootstrap_diff
H = het.load(); M = H["meta"]; YEARS = H["info"]["years"]; SEED = 20261024; rng = np.random.default_rng(SEED)
OUT = config.path("results/phase3/temporal"); OUT.mkdir(parents=True, exist_ok=True)
CL = H["climate"]; ERAS = {"early_historical": (1990, 1998), "landsat_dominant": (1999, 2014), "sentinel_dense": (2015, 2021), "current": (2022, 2026)}
ev = np.flatnonzero((M.split == 3).values)                                     # all evaluation cells: TEST blocks only
tr_cells = np.flatnonzero(((M.split == 1) & M.silver.between(1, 4)).values)
def rf(): return RandomForestClassifier(n_estimators=300, min_samples_leaf=2, max_features="sqrt", n_jobs=2, random_state=SEED)
# ---- multi-year stable-segment label extension (training cells only)
def stable_range(i):
    lo, hi = 1990, 2026
    for f in ("post_ndvi", "dry_ndvi"):
        y = H["L"][i, :, H["info"]["features"].index(f)]; cps = CP.detect(np.array(YEARS), y, "pelt_mean") or []
        for yr, mag in cps:
            if abs(mag) < 0.05: continue
            if yr <= 2021: lo = max(lo, yr)
            else: hi = min(hi, yr - 1)
    return lo, hi
t0 = time.time(); cache = OUT / "stable_ranges_train.npz"
if cache.exists() and (np.load(cache)["cells"] == tr_cells).all(): rngs = np.load(cache)["ranges"]
else: rngs = np.array([stable_range(i) for i in tr_cells]); np.savez(cache, cells=tr_cells, ranges=rngs)
print("stable ranges", round(time.time() - t0), "s", flush=True)
rows = [(c, y) for c, (lo, hi) in zip(tr_cells, rngs) for y in range(lo, hi + 1)]
rows = pd.DataFrame(rows, columns=["cell", "year"]); rows["label"] = M.silver.values[rows.cell]
rows = pd.concat([d.sample(min(len(d), 30000), random_state=SEED) for _, d in rows.groupby("label")], ignore_index=True)   # <= 120k rows, class-capped
json.dump({"n_rows": len(rows), "by_label": rows.label.value_counts().to_dict(), "by_era": pd.cut(rows.year, [1989, 1998, 2014, 2021, 2026]).value_counts().astype(int).to_dict().__repr__()},
          open(OUT / "multiyear_rows.json", "w"), indent=1)
def train_matrix(fs, multi):
    if not multi: X, _ = F.build(H, fs, 2021, tr_cells); return X, M.silver.values[tr_cells]
    Xs, ys = [], []
    for y, d in rows.groupby("year"):
        X, _ = F.build(H, fs, int(y), d.cell.values); Xs.append(X); ys.append(d.label.values)
    return np.vstack(Xs), np.concatenate(ys)
def evaluate(model, fs):
    P = np.zeros((len(ev), len(YEARS)), np.int8)
    for j, y in enumerate(YEARS):
        X, _ = F.build(H, fs, y, ev); P[:, j] = model.predict(X)
    m = M.iloc[ev].reset_index(drop=True); res = {"by_window": {}}
    for g in M.window.unique():
        w = (m.window == g).values; cl = CL[CL.window == g].set_index("year").climate_class.reindex(YEARS).values
        ns, sb, dw = w & m.never_settled.values, w & m.stable_built.values, w & m.deep_water.values
        fbr = (P[ns] == 1).mean(0) if ns.any() else np.full(len(YEARS), np.nan); rec = (P[sb] == 1).mean(0) if sb.any() else np.full(len(YEARS), np.nan)
        wr = (P[dw] == 4).mean(0) if dw.any() else np.full(len(YEARS), np.nan)
        r = {"n_never_settled": int(ns.sum()), "n_stable_built": int(sb.sum()), "n_deep_water": int(dw.sum()),
             "fbr_by_year": dict(zip(YEARS, np.round(fbr, 4).tolist())), "built_recall_by_year": dict(zip(YEARS, np.round(rec, 4).tolist())),
             "water_recall_by_year": dict(zip(YEARS, np.round(wr, 4).tolist()))}
        for c in ("dry", "normal", "wet"):
            k = cl == c; r[f"fbr_{c}"] = float(np.nanmean(fbr[k])) if k.any() else None; r[f"built_recall_{c}"] = float(np.nanmean(rec[k])) if k.any() else None
        for e, (a, b) in ERAS.items():
            k = (np.array(YEARS) >= a) & (np.array(YEARS) <= b); r[f"fbr_{e}"] = float(np.nanmean(fbr[k])); r[f"built_recall_{e}"] = float(np.nanmean(rec[k]))
        res["by_window"][g] = r
    sv = m.silver.between(1, 4).values
    for y in (2021, 2020):
        j = YEARS.index(y); res[f"silver_macro_f1_{y}"] = float(f1_score(m.silver.values[sv], P[sv, j], labels=[1, 2, 3, 4], average="macro"))
    return P, res
def dry_rate(P, kind):
    """per evaluation cell: mean over that window's DRY years of (pred == built) for never-settled, or recall for stable-built."""
    m = M.iloc[ev].reset_index(drop=True); out = np.full(len(ev), np.nan)
    for g in m.window.unique():
        cl = CL[CL.window == g].set_index("year").climate_class.reindex(YEARS).values; k = cl == "dry"; w = (m.window == g).values & m[kind].values
        if k.any(): out[w] = (P[w][:, k] == 1).mean(1)
    return out
summary = {}; preds = {}
ONLY = sys.argv[sys.argv.index("--only") + 1] if "--only" in sys.argv else None      # e.g. P3-B5m@v2 (re-registered after a FAIL)
plan = [("B1", False), ("B2", False), ("B3", False), ("B4", False), ("B1", True), ("B2", True), ("B3", True), ("B4", True), ("B5", True), ("B4t", True)]
if ONLY:
    want = ONLY.split("@")[0]; plan = [(f, m) for f, m in plan if (f"P3-{f}{'m' if m and f not in ('B5', 'B4t') else ''}" if f not in ("B5", "B4t") else {"B5": "P3-B5m", "B4t": "P3-B4t"}[f]) == want]
    for b in ("P3-B1", "P3-B1m"): preds[b] = np.load(OUT / f"pred_{b}.npy")
for fs, multi in plan:
    eid = f"P3-{fs}{'m' if multi and fs not in ('B5', 'B4t') else ''}" if fs not in ("B5", "B4t") else {"B5": "P3-B5m", "B4t": "P3-B4t"}[fs]
    if fs in ("B5", "B4t"): eid = {"B5": "P3-B5m", "B4t": "P3-B4t"}[fs]
    if ONLY: eid = ONLY
    run = R3.Run(eid)
    try:
        t1 = time.time(); X, y = train_matrix(fs, multi); mdl = rf().fit(X, y); fit_s = time.time() - t1
        P, res = evaluate(mdl, fs); preds[eid] = P; np.save(OUT / f"pred_{eid}.npy", P)
        res.update(fit_seconds=round(fit_s, 1), n_train_rows=int(len(y)), n_features=int(X.shape[1]))
        summary[eid] = res
        base = "P3-B1m" if multi else "P3-B1"; eid_base = eid.split("@")[0]
        if eid_base != base and base in preds:
            cmp = {}
            for kind in ("never_settled", "stable_built"):
                a, b = dry_rate(P, kind), dry_rate(preds[base], kind); ok = np.isfinite(a) & np.isfinite(b)
                cmp[kind] = block_bootstrap_diff(lambda i, a=a[ok], b=b[ok]: float(np.mean(a[i] - b[i])), M.iloc[ev].block.values[ok], n=1000)
                cmp[kind]["base_mean"] = float(np.mean(b[ok])); cmp[kind]["model_mean"] = float(np.mean(a[ok]))
            res["dry_year_vs_" + base] = cmp
        fb = {g: (round(r["fbr_dry"], 3) if r["fbr_dry"] is not None else None) for g, r in res["by_window"].items()}
        out_msg = f"silver2021 {res['silver_macro_f1_2021']:.3f}; dry-year FBR {fb}"
        outcome = "NA" if eid_base in ("P3-B1", "P3-B1m") else "INCONCLUSIVE"
        if "dry_year_vs_" + base in res:
            c = res["dry_year_vs_" + base]["never_settled"]; rel = c["estimate"] / c["base_mean"] if c["base_mean"] else 0
            rec_drop = res["dry_year_vs_" + base]["stable_built"]["estimate"]
            outcome = "SUPPORTED" if (rel <= -0.25 and c["excludes_zero"] and rec_drop >= -0.05) else ("NOT_SUPPORTED" if not (c["excludes_zero"] and c["estimate"] < 0) else "INCONCLUSIVE")
            out_msg += f"; dry-year FBR change vs {base}: {c['estimate']:+.3f} (rel {rel:+.0%}, CI {c['ci95'][0]:+.3f}..{c['ci95'][1]:+.3f}); built-recall change {rec_drop:+.3f}"
        run.complete(res, outcome, out_msg, outputs={"predictions": f"results/phase3/temporal/pred_{eid}.npy"}, n_samples={"train_rows": int(len(y)), "eval_cells": int(len(ev))})
        print(eid, out_msg, f"fit {fit_s:.0f}s", flush=True)
    except Exception as e:
        import traceback; traceback.print_exc(); run.fail(repr(e), eid, "fix and re-register as @v2")
json.dump(summary, open(OUT / ("temporal_summary.json" if not ONLY else f"temporal_summary_{ONLY.replace('@', '_at_')}.json"), "w"), indent=1, default=str)
np.save(OUT / "eval_cells.npy", ev)
