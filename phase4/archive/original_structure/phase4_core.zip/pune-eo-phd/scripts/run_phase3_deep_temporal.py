"""Phase-3 group F — deep temporal classifiers, run because P3-B4 (5-year window RF) beat P3-B1 (pre-declared condition).
P3-F1 TempCNN, P3-F2 GRU, P3-F3 Transformer on the B4 sequence (B3 features for t-2..t+2 = 5 x 16; missing years 0-filled + observation-mask channels).
Training: silver 2021 TRAIN-block cells (Tier C), early stopping on VAL blocks, class-weighted loss, seed fixed.
Compared with RF on the same B4 information (P3-B4 predictions for history; RF-B4 re-fitted per LOWO split for unseen windows):
  history : dry-year false built-up on never-settled TEST cells (paired block bootstrap vs RF-B4) + stable-built recall
  unseen  : leave-one-window-out macro-F1 (paired block bootstrap vs RF-B4 on the same held-out cells)
Hypothesis per model: beats RF-B4 on BOTH (dry FBR lower with CI < 0, and unseen macro-F1 higher with CI > 0 in >= 2 of 3 windows)."""
import json, sys, time, warnings
import numpy as np
sys.path.insert(0, "src"); warnings.filterwarnings("ignore")
from sklearn.ensemble import RandomForestClassifier
from sklearn.metrics import f1_score
from pune_eo import config
from pune_eo.historical_reconstruction import het, features as F
from pune_eo.temporal_models import window_sequence
from pune_eo.agriculture import timeseries as TS
from pune_eo.calibration import metrics as CM
from pune_eo.validation import registry3 as R3
from pune_eo.validation.stats3 import block_bootstrap_diff
H = het.load(); M = H["meta"]; YEARS = H["info"]["years"]; SEED = 20261103; OUT = config.path("results/phase3/deep_temporal"); OUT.mkdir(parents=True, exist_ok=True)
WIN = ["pune_G30_khadakwasla_mutha", "pune_G30_baramati_agri", "pune_G30_mulshi_ghats"]; SH = {w: w[9:] for w in WIN}; CL = H["climate"]
sil = M.silver.between(1, 4).values; yv = M.silver.values; split = M.split.values; win = M.window.values; blk = M.block.values
ev = np.load(config.path("results/phase3/temporal/eval_cells.npy")); mm = M.iloc[ev].reset_index(drop=True)
mf1 = lambda y, p: float(f1_score(y, p, labels=[1, 2, 3, 4], average="macro"))
def seq(cells, year): return window_sequence(H, year, cells, half=2)
def prep(X, stats=None):
    if stats is None: stats = (np.nanmean(X, axis=(0, 1)), np.nanstd(X, axis=(0, 1)) + 1e-6)
    Z = (X - stats[0]) / stats[1]; ob = np.isfinite(Z).all(-1, keepdims=True); Z = np.where(np.isfinite(Z), Z, 0.0)
    return np.concatenate([Z, ob, ob], -1).astype(np.float32), stats             # two identical mask channels (TS.train reads the last two)
def build_gru(n_ch, n_cls):
    import torch.nn as nn
    class GRU(nn.Module):
        def __init__(s, h=64, p=0.2): super().__init__(); s.r = nn.GRU(n_ch, h, batch_first=True); s.d = nn.Dropout(p); s.head = nn.Linear(h, n_cls)
        def forward(s, x, m=None): o, _ = s.r(x); return s.head(s.d(o[:, -1]))
    return GRU()
_orig = TS.build
TS.build = lambda name, n_ch, n_cls, T=12: build_gru(n_ch, n_cls) if name == "gru" else _orig(name, n_ch, n_cls, T)
def train(name, tr, va):
    Xtr, st = prep(seq(tr, 2021)); Xva, _ = prep(seq(va, 2021), st)
    net, hist = TS.train(name, Xtr, yv[tr] - 1, Xva, yv[va] - 1, 4, seed=SEED, epochs=40, patience=6); return net, st, hist
def proba(net, st, cells, year): return TS.predict_proba(net, prep(seq(cells, year), st)[0])
def rf_b4(tr): X, _ = F.build(H, "B4", 2021, tr); return RandomForestClassifier(n_estimators=300, min_samples_leaf=2, max_features="sqrt", n_jobs=2, random_state=SEED).fit(X, yv[tr])
def dry_rate(P, kind):
    out = np.full(len(ev), np.nan)
    for g in mm.window.unique():
        k = CL[CL.window == g].set_index("year").climate_class.reindex(YEARS).values == "dry"; w = (mm.window == g).values & mm[kind].values
        if k.any(): out[w] = (P[w][:, k] == 1).mean(1)
    return out
P_rf = np.load(config.path("results/phase3/temporal/pred_P3-B4.npy"))
tr = np.flatnonzero(sil & (split == 1)); va = np.flatnonzero(sil & (split == 2)); te = np.flatnonzero(sil & (split == 3))
rf_lowo = {}
for t in WIN:
    og = win != t; rf_lowo[t] = rf_b4(np.flatnonzero(sil & og & (split == 1))).predict(F.build(H, "B4", 2021, np.flatnonzero(sil & (win == t)))[0])
summary = {}
for eid, name in (("P3-F1", "tempcnn"), ("P3-F2", "gru"), ("P3-F3", "transformer")):
    run = R3.Run(eid); t0 = time.time()
    try:
        net, st, hist = train(name, tr, va); p21 = proba(net, st, te, 2021); c = CM.all_metrics(p21, yv[te] - 1)
        r = {"val_loss": hist, "silver_2021_test": {"macro_f1": mf1(yv[te], p21.argmax(1) + 1), "per_class_f1": dict(zip(["built_up", "agriculture", "natural_vegetation", "water"], f1_score(yv[te], p21.argmax(1) + 1, labels=[1, 2, 3, 4], average=None).round(4).tolist())), "ece": c["ece"], "brier": c["brier"]}}
        P = np.stack([proba(net, st, ev, y).argmax(1) + 1 for y in YEARS], 1).astype(np.int8); np.save(OUT / f"pred_{eid}.npy", P)
        r["history"] = {}
        for kind in ("never_settled", "stable_built"):
            a, b = dry_rate(P, kind), dry_rate(P_rf, kind); ok = np.isfinite(a) & np.isfinite(b)
            r["history"][kind] = block_bootstrap_diff(lambda i: float(np.mean(a[ok][i] - b[ok][i])), mm.block.values[ok]) | {"model_mean": float(a[ok].mean()), "rf_b4_mean": float(b[ok].mean())}
        r["history"]["fbr_by_window_dry"] = {SH[g]: float(np.nanmean(dry_rate(P, "never_settled")[(mm.window == g).values])) for g in WIN}
        r["unseen"] = {}
        for t in WIN:
            og = win != t; n2, s2, _ = train(name, np.flatnonzero(sil & og & (split == 1)), np.flatnonzero(sil & og & (split == 2))); ho = np.flatnonzero(sil & (win == t))
            pn = proba(n2, s2, ho, 2021).argmax(1) + 1; pr = rf_lowo[t]; y_ = yv[ho]
            r["unseen"][SH[t]] = {"macro_f1": mf1(y_, pn), "rf_b4_macro_f1": mf1(y_, pr), "diff": block_bootstrap_diff(lambda i: mf1(y_[i], pn[i]) - mf1(y_[i], pr[i]), blk[ho])}
        h_ok = r["history"]["never_settled"]["estimate"] < 0 and r["history"]["never_settled"]["excludes_zero"]; h_bad = r["history"]["never_settled"]["estimate"] > 0 and r["history"]["never_settled"]["excludes_zero"]
        u_ok = sum(1 for v in r["unseen"].values() if v["diff"]["estimate"] > 0 and v["diff"]["excludes_zero"]) >= 2; u_bad = any(v["diff"]["estimate"] < 0 and v["diff"]["excludes_zero"] for v in r["unseen"].values())
        outcome = "SUPPORTED" if h_ok and u_ok else ("NOT_SUPPORTED" if h_bad or u_bad or (not h_ok and not u_ok) else "INCONCLUSIVE")
        r["seconds"] = round(time.time() - t0, 1); summary[eid] = r
        msg = (f"{name}: silver2021 {r['silver_2021_test']['macro_f1']:.3f}; dry FBR vs RF-B4 {r['history']['never_settled']['estimate']:+.3f} [{r['history']['never_settled']['ci95'][0]:+.3f},{r['history']['never_settled']['ci95'][1]:+.3f}]; "
               "unseen vs RF-B4 " + ", ".join(f"{k} {v['diff']['estimate']:+.3f} [{v['diff']['ci95'][0]:+.3f},{v['diff']['ci95'][1]:+.3f}]" for k, v in r["unseen"].items()))
        run.complete(r, outcome, msg, outputs={"predictions": f"results/phase3/deep_temporal/pred_{eid}.npy"}, n_samples={"train": int(len(tr)), "eval_cells": int(len(ev))}); print(eid, msg, flush=True)
    except Exception as e:
        import traceback; traceback.print_exc(); run.fail(repr(e), name, "fix and re-register as @v2")
json.dump(summary, open(OUT / "deep_temporal_summary.json", "w"), indent=1, default=float)
