"""Remedies for the temporal domain shift of the 2021-trained classifier (EXP-LULC-T-001 maps 75 % built-up in 1990).
  base  : 2021 labels, 2021 features (= EXP-LULC-T-001 model, re-fitted here for a like-for-like comparison)
  R1    : silver labels extended along each TRAIN cell's change-free segment (PELT on post- and dry-season NDVI; label applies to all
          years of the final segment that contains 2020-21) -> model sees many years / sensors / rainfall regimes
  R2    : per-year relative radiometric normalisation of dry-season bands (and post-monsoon indices) to 2021 using pseudo-invariant
          features defined ONLY from independent products: JRC occurrence >= 95 (dark) and WSF<=1985 & GHSL1990>=0.3 (bright); Theil-Sen
  R1R2  : both
Selection uses independent references on VAL blocks only; TEST-block results are reported, never used to choose.
Registry: EXP-LULC-R-{variant}. Note R1 extends labels using the project's imagery (stability only) - documented in docs/label_protocol.md."""
import json, sys, time, warnings
import numpy as np, pandas as pd, rasterio
from scipy.stats import theilslopes, pearsonr
sys.path.insert(0, "src"); warnings.filterwarnings("ignore")
from pune_eo import config
from pune_eo.classification import baseline as B
from pune_eo.change_detection import changepoints as C
from pune_eo.modelling.registry import Experiment
W = ["pune_G30_khadakwasla_mutha", "pune_G30_baramati_agri", "pune_G30_mulshi_ghats"]; SEED = 20261006; YEARS = list(range(1990, 2027))
feats = json.load(open(config.path("results/classification/feature_pruning.json")))["kept"]
BANDS = ["dry_blue", "dry_green", "dry_red", "dry_nir", "dry_swir1", "dry_swir2"]
def rd(p, b=None):
    with rasterio.open(p) as s: return s.read(b) if b else s.read()
def up90(a, H, Wd): return np.pad(np.repeat(np.repeat(a, 3, 0), 3, 1), ((0, max(0, H - 3 * a.shape[0])), (0, max(0, Wd - 3 * a.shape[1]))), constant_values=np.nan)[:H, :Wd]
t0 = time.time(); D = {}
for gid in W:
    ds = B.open_cube(gid); d = config.path("data/labels", gid)
    L = ds.landsat; T = ds.terrain.values; fl = list(ds.feature.values); tf = list(ds.tfeature.values)   # L lazy (zarr)
    wsf = rd(d / "wsf_evolution_first_year.tif", 1); gh = rd(d / "ghsl_built_fraction_90m.tif").astype(float); gh[gh < 0] = np.nan
    jrc = rd(d / "jrc_gsw.tif", 1).astype(float); H, Wd = wsf.shape
    D[gid] = {"L": L, "T": T, "fl": fl, "tf": tf, "sil": rd(d / "silver_l1.tif", 1), "sp": rd(d / "splits.tif", 1), "wsf": wsf, "gh": gh, "jrc": jrc,
              "pif_dark": (jrc >= 95) & (jrc != 255), "pif_bright": (wsf == 1985) & (up90(gh[0], H, Wd) >= 0.3), "H": H, "W": Wd}
print("loaded", round(time.time() - t0), flush=True)

# ---------------- R2: PIF normalisation coefficients (pooled over windows), per year, per band / post index
rng = np.random.default_rng(SEED); NORM = BANDS + ["post_ndvi", "post_mndwi", "post_ndmi"]; coef = {}
i21 = YEARS.index(2021)
PS = {}
for gid, g in D.items():
    pts = []
    for m in (g["pif_dark"], g["pif_bright"]):
        r, c = np.nonzero(m)
        if r.size: k = rng.choice(r.size, min(3000, r.size), replace=False); pts.append((r[k], c[k]))
    for f in NORM:
        A = g["L"].sel(feature=f).values                                  # (T, H, W) one feature at a time
        PS[(gid, f)] = [A[:, r, c] for r, c in pts]; del A
for i, y in enumerate(YEARS):
    for f in NORM:
        xs, ys = [], []
        for gid in D:
            for v in PS[(gid, f)]:
                a, b = v[i], v[i21]; ok = np.isfinite(a) & np.isfinite(b); xs.append(a[ok]); ys.append(b[ok])
        x, yv = np.concatenate(xs), np.concatenate(ys)
        if x.size > 800: k = np.random.default_rng(i).choice(x.size, 800, replace=False); x, yv = x[k], yv[k]   # Theil-Sen is O(n^2)
        sl, ic, *_ = theilslopes(yv, x) if x.size > 50 else (1.0, 0.0)
        coef[(y, f)] = (float(sl), float(ic))
json.dump({f"{y}|{f}": v for (y, f), v in coef.items()}, open(config.path("results/temporal/pif_normalisation.json"), "w"), indent=0)
def nd(a, b):
    with np.errstate(all="ignore"): return (a - b) / (a + b)
CACHE = {}
def year_slice(g, i, norm):
    """(F, H, W) features of year index i, PIF-normalised if norm. One slice in memory at a time."""
    key = (id(g), i, norm)
    if key in CACHE: return CACHE[key]
    L = g["L"].isel(year=i).values.copy(); fl = g["fl"]; y = YEARS[i]
    if norm:
        for f in NORM: sl, ic = coef[(y, f)]; L[fl.index(f)] = sl * L[fl.index(f)] + ic
        b = {k: L[fl.index(k)] for k in BANDS}
        L[fl.index("dry_ndvi")] = nd(b["dry_nir"], b["dry_red"]); L[fl.index("dry_mndwi")] = nd(b["dry_green"], b["dry_swir1"])
        L[fl.index("dry_ndmi")] = nd(b["dry_nir"], b["dry_swir1"]); L[fl.index("dry_nbr")] = nd(b["dry_nir"], b["dry_swir2"])
        L[fl.index("d_ndvi")] = L[fl.index("post_ndvi")] - L[fl.index("dry_ndvi")]; L[fl.index("d_mndwi")] = L[fl.index("post_mndwi")] - L[fl.index("dry_mndwi")]
        L[fl.index("sd_ndvi_5")] *= coef[(y, "dry_nir")][0]; L[fl.index("sd_nir_5")] *= coef[(y, "dry_nir")][0]
    L[~np.isfinite(L)] = np.nan
    CACHE.clear(); CACHE[key] = L; return L
def series(g, f, norm):
    if not norm: return g["L"].sel(feature=f).values
    return np.stack([year_slice(g, i, True)[g["fl"].index(f)] for i in range(len(YEARS))])
print("R2 coefficients", round(time.time() - t0), flush=True)

def X_of(g, norm, i, r, c):
    Ly = year_slice(g, i, norm); cols = []
    for f in feats: cols.append(Ly[g["fl"].index(f), r, c] if f in g["fl"] else g["T"][g["tf"].index(f), r, c])
    return np.stack(cols, 1)

# ---------------- R1: stable-segment label extension for TRAIN cells (sampled)
def stable_years(g, norm, r, c):
    S = {f: series(g, f, norm)[:, r, c] for f in ("post_ndvi", "dry_ndvi")}; out = []
    for n_, (rr, cc) in enumerate(zip(r, c)):
        lo = 1990
        for f in ("post_ndvi", "dry_ndvi"):
            y = S[f][:, n_]; cps = C.detect(np.array(YEARS), y, "pelt_mean")
            for yr, mag in (cps or []):
                if yr <= 2020 and abs(mag) >= 0.05: lo = max(lo, yr)
        out.append(lo)
    return np.array(out)
def build_train(variant):
    Xs, ys, ws, pend = [], [], [], []
    for gid, g in D.items():
        L = "R2" in variant
        for c_ in B.CLASSES:
            r, c = np.nonzero((g["sp"] == 1) & (g["sil"] == c_))
            if r.size == 0: continue
            k = rng.choice(r.size, min(1500 if "R1" in variant else 4000, r.size), replace=False); r, c = r[k], c[k]
            if "R1" in variant:
                pend.append((g, c_, r, c, stable_years(g, L, r, c)))
            else:
                Xs.append(X_of(g, L, i21, r, c)); ys.append(np.full(r.size, c_)); ws.append(np.full(r.size, 2021))
    norm = "R2" in variant
    for gid in D:                                           # year-outer loop: one year slice in memory at a time
        P = [p for p in pend if p[0] is D[gid]]
        for yi, y in enumerate(YEARS):
            for g, c_, r, c, lo in P:
                m = lo <= y
                if m.any(): Xs.append(X_of(g, norm, yi, r[m], c[m])); ys.append(np.full(m.sum(), c_)); ws.append(np.full(m.sum(), y))
    return np.concatenate(Xs), np.concatenate(ys), np.concatenate(ws)
def val_set(variant, split):
    Xs, ys = [], []
    for gid, g in D.items():
        L = "R2" in variant; r, c = np.nonzero((g["sp"] == split) & np.isin(g["sil"], B.CLASSES))
        k = rng.choice(r.size, min(8000, r.size), replace=False); Xs.append(X_of(g, L, i21, r[k], c[k])); ys.append(g["sil"][r[k], c[k]])
    return np.concatenate(Xs), np.concatenate(ys)

def evaluate_maps(variant, m):
    """Independent references per split (2 = VAL for selection, 3 = TEST for reporting)."""
    res = {2: {}, 3: {}}
    for gid, g in D.items():
        L = "R2" in variant; H, Wd = g["H"], g["W"]; lab = np.zeros((len(YEARS), H, Wd), np.int8)
        rr, cc = np.nonzero(g["sp"] > 0)
        for i in range(len(YEARS)): lab[i, rr, cc] = B.predict("xgb", m, X_of(g, L, i, rr, cc))
        for s in (2, 3):
            ms = g["sp"] == s; out = {}
            # WSF per epoch F1 + built share
            for ep in (1990, 2000, 2010, 2015):
                ref = (g["wsf"] > 0) & (g["wsf"] <= ep); mp = lab[YEARS.index(ep)] == 1
                tp = (ref & mp & ms).sum(); out[f"wsf_f1_{ep}"] = float(2 * tp / max((ref & ms).sum() + (mp & ms).sum(), 1))
                out[f"built_share_{ep}"] = float(mp[ms].mean()); out[f"wsf_share_{ep}"] = float(ref[ms].mean())
            # GHSL 90 m parents fully inside split s
            h3, w3 = g["gh"].shape[1:]; s3 = ms[:h3 * 3, :w3 * 3].reshape(h3, 3, w3, 3).all(axis=(1, 3))
            for k_, ep in enumerate((1990, 1995, 2000, 2005, 2010, 2015, 2020)):
                bf = (lab[YEARS.index(ep), :h3 * 3, :w3 * 3] == 1).reshape(h3, 3, w3, 3).mean(axis=(1, 3)); gg = g["gh"][k_]; f = s3 & np.isfinite(gg)
                out[f"ghsl_r_{ep}"] = float(pearsonr(bf[f], gg[f])[0]) if f.sum() > 30 and gg[f].std() > 0 else None
            b90 = (lab[YEARS.index(1990), :h3 * 3, :w3 * 3] == 1).reshape(h3, 3, w3, 3).mean(axis=(1, 3)); b20 = (lab[YEARS.index(2020), :h3 * 3, :w3 * 3] == 1).reshape(h3, 3, w3, 3).mean(axis=(1, 3))
            dg = g["gh"][6] - g["gh"][0]; f = s3 & np.isfinite(dg)
            out["ghsl_change_r"] = float(pearsonr((b20 - b90)[f], dg[f])[0]) if f.sum() > 30 else None
            out["flip_rate"] = float((np.diff(lab[:, ms], axis=0) != 0).sum(0).mean())
            res[s][gid] = out
    return res

summary = {}
for variant in ["base", "R1", "R2", "R1R2"]:
    e = Experiment(experiment_id=f"EXP-LULC-R-{variant}", research_question="RQ-T2: Which remedy makes a classifier trained on the 2020-21 label epoch transfer to 1990-2019?",
                   hypothesis="R1 (multi-year stable-segment labels) and/or R2 (PIF normalisation) reduce early-year built-up over-prediction",
                   dataset_version="cube G30 local_pune_g30_v2; labels silver v1", years=YEARS, resolution_m=30, features=feats,
                   labels="silver_l1" + (" extended along PELT change-free segments (train blocks only)" if "R1" in variant else " 2021"),
                   split="train blocks fit; val blocks early-stopping + remedy selection (independent refs); test blocks report",
                   model="XGBoost", hyperparameters={"variant": variant, "R2_pifs": "JRC>=95 (dark), WSF<=1985 & GHSL1990>=0.3 (bright), Theil-Sen pooled per year"}, seed=SEED)
    try:
        Xtr, ytr, yrs = build_train(variant); Xva, yva = val_set(variant, 2); Xte, yte = val_set(variant, 3)
        m = B.make_model("xgb", SEED); B.fit("xgb", m, Xtr, ytr, Xva, yva)
        mt = B.evaluate(yte, B.predict("xgb", m, Xte)); ev = evaluate_maps(variant, m)
        summary[variant] = {"silver_test_2021_macro_f1": mt["macro_f1"], "n_train": int(len(ytr)), "train_years": [int(yrs.min()), int(yrs.max())],
                            "val": ev[2], "test": ev[3]}
        e.finish({"silver_test_2021": mt, "independent_val_blocks": ev[2], "independent_test_blocks": ev[3]},
                 result=f"silver test macro-F1 {mt['macro_f1']:.3f}; see independent metrics", n_samples={"train_rows": int(len(ytr)), "val": int(len(yva)), "test": int(len(yte))})
        v = ev[2]; print(variant, json.dumps({"silver_f1": mt["macro_f1"], "n_train": int(len(ytr)),
              "val_built_1990": {k[-12:]: round(x["built_share_1990"], 3) for k, x in v.items()}, "val_wsf_1990": {k[-12:]: round(x["wsf_share_1990"], 3) for k, x in v.items()},
              "val_ghsl_change_r": {k[-12:]: x["ghsl_change_r"] and round(x["ghsl_change_r"], 3) for k, x in v.items()},
              "val_wsf_f1_2000": {k[-12:]: round(x["wsf_f1_2000"], 3) for k, x in v.items()}}), round(time.time() - t0), flush=True)
    except Exception as ex:
        import traceback; traceback.print_exc(); e.fail(repr(ex), variant, "fix and rerun")
json.dump(summary, open(config.path("results/temporal/remedies_summary.json"), "w"), indent=1, default=str)
