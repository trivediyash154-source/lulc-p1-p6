#!/bin/sh
# Phase-3: complete Sentinel-1 G30 annual coverage for the S1-era experiments (C group, drought year 2019).
cd "$(dirname "$0")/.."
for w in baramati_agri mulshi_ghats; do python3 scripts/run_sentinel.py sentinel1 --grid G30 --window $w --years 2017-2019 --threads 3; done
for w in khadakwasla_mutha baramati_agri mulshi_ghats; do python3 scripts/run_sentinel.py sentinel1 --grid G30 --window $w --years 2022-2025 --threads 3; done
