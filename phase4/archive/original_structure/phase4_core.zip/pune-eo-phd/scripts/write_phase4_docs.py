"""Write the Phase-4 result/status documents from saved files (numbers are read, never typed)."""
import json, sys
import numpy as np, pandas as pd
sys.path.insert(0, "src")
from pune_eo import config
from pune_eo.evaluation4 import protocol as P4
J = lambda p: json.loads(config.path(p).read_text()) if config.path(p).exists() else None
D = config.path("docs"); W3 = ["khadakwasla_mutha", "baramati_agri", "mulshi_ghats"]; WF = {w: f"pune_G30_{w}" for w in W3}
def table(h, rows): return "\n".join(["| " + " | ".join(map(str, h)) + " |", "|" + "---|" * len(h)] + ["| " + " | ".join(str(c).replace("|", "/") for c in r) + " |" for r in rows])
def write(n, L): (D / n).write_text("\n".join(L) + "\n"); print("wrote", n)
B = J("results/phase4/benchmark/district_benchmark.json"); X2 = J("results/phase4/benchmark/p3f3_vs_products_windows.json"); S = pd.read_csv(config.path("results/phase4/benchmark/class_shares_by_product_year.csv"))
PIF = J("results/phase4/sensor_era/sensor_era_pif.json"); RD = pd.read_csv(config.path("results/phase4/sensor_era/regime_differences.csv")); DES = J("data/labels/gold/phase4/sampling_design/design.json")
INV = J("data/inventory/inventory_summary.json"); PA = J("data/inventory/product_availability.json")
T = B["built_trajectories_km2"]; tv = lambda k, y: T[k].get(str(y)); X3 = J("results/phase4/benchmark/disagreement_by_descriptor.json")
_c = {y: d for y, d in X2[WF["khadakwasla_mutha"]].items() if int(y) > 1990}
cr = {"nv": (min(d["ours_class_shares"]["natural_vegetation"] for d in _c.values()), max(d["ours_class_shares"]["natural_vegetation"] for d in _c.values())),
      "ag": (min(d["ours_class_shares"]["agriculture"] for d in _c.values()), max(d["ours_class_shares"]["agriculture"] for d in _c.values())),
      "gnv": (min(d["glc_class_shares"]["natural_vegetation"] for d in _c.values()), max(d["glc_class_shares"]["natural_vegetation"] for d in _c.values())),
      "gag": (min(d["glc_class_shares"]["agriculture"] for d in _c.values()), max(d["glc_class_shares"]["agriculture"] for d in _c.values()))}
# ================= benchmark
yrs = [1985, 1990, 1995, 2000, 2005, 2010, 2015, 2020, 2021, 2023]
rows = [[k.replace("_", " ")] + [("—" if tv(k, y) is None else f"{tv(k, y):.0f}") for y in yrs] + ["yes" if B["built_plausibility"][k]["plausible"] else "NO"] for k in T]
bm = ["# Existing-product benchmark (Phase 4, P4-X1 / P4-X2, exploratory)", "", f"District area {B['district_area_km2']:.0f} km² (30 m cells inside the boundary). Products on the district 30 m Landsat lattice, except GHSL (nested 90 m grid, bilinear) and ESA CCI (300 m). "
      "Esri and WorldCover are GDAL 'mode' aggregates from 10 m, which under-represents fragmented built-up. No product is treated as truth; WorldCover and Esri are silver-label sources (Tier C).", "",
      "## 1. Built-up area trajectories (km²)", "", table(["product"] + yrs + ["monotone (no >10 % decline)"], rows), "",
      f"* In 2020 the products span {min(v for k, v in ((k, tv(k, 2020)) for k in T) if v):.0f}-{max(v for k, v in ((k, tv(k, 2020)) for k in T) if v):.0f} km² (GHSL built surface ... Esri built area): definitions differ — "
      "built SURFACE fraction (GHSL), impervious surface (GISA, GLC_FCS30D), settlement extent (WSF), built-area land cover (Esri, WorldCover), coarse urban class (CCI).",
      "* No product shows a district built-up decline > 10 % between epochs (GLC_FCS30D has small declines 2018->19, 2020->22); all show growth of roughly 3-5.5x between 1990 (CCI: 1992) and their last epoch.", "* 'Built-up' in our legend has no single external equivalent: every comparison must state which definition it uses.", "",
      "## 2. Pairwise built-up agreement at 30 m", "", table(["year / pair", "F1", "Jaccard", "area ratio"], [[k, f"{v['f1']:.2f}", f"{v['jaccard']:.2f}", f"{v['area_ratio']:.2f}"] for k, v in B["built_pairwise_30m"].items()]), "",
      f"Agreement between independent built products rises from F1 0.32-0.43 (1990) to 0.64-0.70 (2015). Of all cells any of WSF/GISA/GLC_FCS30D calls built in 2015, {B['built_votes_2015_share_of_any_built']['3']:.0%} are called built by all three "
      f"and {B['built_votes_2015_share_of_any_built']['1']:.0%} by only one. Historical built-up is genuinely uncertain, not just uncertain for our model.", "",
      "## 3. Land-cover agreement 2020 (L1)", "", table(["pair", "agreement"], [[k, f"{v:.3f}"] for k, v in B["l1_agreement_2020"].items() if not isinstance(v, dict)]), "",
      "Per-class overlap (intersection/union) GLC_FCS30D vs Esri: " + ", ".join(f"{k} {v:.2f}" for k, v in B["l1_agreement_2020"]["per_class_glc_vs_esri"].items()) + ".", "",
      f"All three products agree on {B['consensus_2020_share']['all_agree']:.0%} of the district; two agree on {B['consensus_2020_share']['two_agree']:.0%}; none on {B['consensus_2020_share']['none_agree']:.0%}.", "",
      "Where products disagree (P4-X3, descriptors NOT derived from the consensus; the earlier by-stratum summary in P4-X1 was circular because strata were built from the same consensus): " +
      "; ".join(f"{k.replace('_', ' ')}: " + ", ".join(f"{c} {v['share']:.0%}" for c, v in d.items()) for k, d in X3["by_descriptor"].items()) + f" (district {X3['district_no_consensus_share']:.0%}).", "",
      "Disagreement is highest on gentle 3-8° slopes (foothills/transitional terrain), in the transition rainfall zone, within 300 m of water and in areas settled 2001-2015; lowest in the wet west and on flat or steep terrain.", "",
      "## 4. Temporal consistency", "", "Year-to-year share of district cells changing L1 class: GLC_FCS30D " + ", ".join(f"{k} {v:.1%}" for k, v in list(B["year_to_year_change_share"]["GLC_FCS30D"].items())[:4]) +
      " …; Esri " + ", ".join(f"{k} {v:.1%}" for k, v in B["year_to_year_change_share"]["Esri"].items()) + ". GLC_FCS30D is temporally smoothed by construction (continuous change detection); Esri's annual maps flicker "
      "(4.6-7 % of the district per year), far more than plausible land change — Esri year-to-year differences must not be read as change. WorldCover 2020 -> 2021 is a version change (v100 -> v200), not change.", "",
      "## 5. Our Phase-3 reconstruction (P3-F3) vs the products, inside the 3 windows (P4-X2)", "",
      table(["window", "epoch", "ours built", "GLC built", "WSF", "GISA", "ours agri / natveg", "GLC agri / natveg", "4-class agreement vs GLC"],
            [[w, y, f"{d['ours_built_share']:.2f}", f"{d['glc_built_share']:.2f}", "—" if d["wsf_built_share"] is None else f"{d['wsf_built_share']:.2f}", f"{d['gisa_built_share']:.2f}",
              f"{d['ours_class_shares']['agriculture']:.2f} / {d['ours_class_shares']['natural_vegetation']:.2f}", f"{d['glc_class_shares']['agriculture']:.2f} / {d['glc_class_shares']['natural_vegetation']:.2f}", f"{d['pixel_agreement_vs_glc_4class']:.2f}"]
             for w in W3 for y, d in X2[WF[w]].items() if y in ("1990", "2000", "2010", "2020")]), "",
      "* 1990: our model maps 50 % (corridor) and 63 % (Baramati) as built against 1-21 % in every independent product — the historical failure, seen against three independent references (GLC_FCS30D, WSF, GISA).",
      f"* Corridor composition: after 1990 our model calls {cr['nv'][0]:.0%}-{cr['nv'][1]:.0%} of the corridor natural vegetation and {cr['ag'][0]:.0%}-{cr['ag'][1]:.0%} agriculture where GLC_FCS30D has {cr['gnv'][0]:.0%}-{cr['gnv'][1]:.0%} and {cr['gag'][0]:.0%}-{cr['gag'][1]:.0%}. "
      "This is consistent with the label audit (corridor agriculture received silver labels in only 8 % of its cells) — an association, not a demonstrated cause.", "* Mulshi (forest/reservoir) agrees with GLC_FCS30D on ~0.9 of pixels after 1990.", "",
      "## 6. Products that could not be used here", "", "* Dynamic World, GAIA — Earth Engine only (needs the user's project; export script ready: `scripts/gee/export_district_cube.py --what dw,gaia`).",
      "* India decadal LULC 1985/1995/2005 (ORNL DAAC) — NASA Earthdata login needed.", "* NRSC LULC 50K — view-only.", "", "Figures: `figures/phase4/P4F2_built_trajectories_products.png`, `P4F3_class_shares_2020.png`, `P4F4_consensus_maps.png`, `P4F7_p3f3_vs_products.png`."]
write("existing_product_benchmark.md", bm)
ep = (D / "phase4_existing_products.md").read_text().split("## 3. Benchmark results")[0]
(D / "phase4_existing_products.md").write_text(ep + "## 3. Benchmark results\n\nSee `docs/existing_product_benchmark.md` (district trajectories, pairwise agreement, consensus/disagreement, temporal consistency, our model vs products). "
                                               "Gate G3 status is in `docs/phase4_readiness_gate.md`.\n"); print("updated phase4_existing_products.md")
# ================= sensor era
rd = RD[RD.contrast == "L5-L8_9"]
se = ["# Phase 4 — sensor-era validation", "", "## 1. Sensor eras in the archive", "", "Landsat-5 TM only 1990-1998; Landsat-5/7 1999-2002; Landsat-7 alone (SLC-off) 2003-2007 and 2012; L5+L7 2008-2011; L7+L8 2013-2021; L8+L9 2022-2026 "
      "(`docs/phase4_data_inventory.md`). Harmonisation in the cube (local_pune_g30_v2): L7 -> OLI pooled RMA; **L5 and L9 identity** (correction rejected by the held-out rule; evidence for L5 was mixed).", "",
      "## 2. P4-E1 (exploratory): pseudo-invariant targets", "", "PIF cells from independent products only: water (JRC >= 95 and GLC_FCS30D water every epoch), impervious (GLC_FCS30D impervious every epoch and WSF 1985), forest (GLC_FCS30D forest every epoch). "
      f"PIF cells per window: {PIF['pif_counts']}. Years are grouped by the dominant sensor (>= 80 % of clear pixels) and compared in SPI-normal years.", "",
      table(["window", "PIF", "band", "L5 minus L8/9 (95 % CI)", "L7 minus L8/9"], [[r.window, r.pif.replace("_pif", ""), r.band.replace("dry_", ""), f"{r.diff:+.4f} [{r.ci_lo:+.4f}, {r.ci_hi:+.4f}]",
             (lambda q: "—" if q.empty else f"{q['diff'].iloc[0]:+.4f}")(RD[(RD.contrast == "L7-L8_9") & (RD.window == r.window) & (RD.pif == r.pif) & (RD.band == r.band)])] for r in rd.itertuples() if r.band in ("dry_red", "dry_nir", "dry_swir1", "dry_ndvi")]), "",
      f"{int(RD.excludes_zero.sum())} of {len(RD)} contrasts have a percentile-bootstrap interval excluding zero, but each regime contains only 3-8 years, so these intervals under-cover and overstate precision. "
      "Point estimates: Landsat-5-dominated years have higher red (+0.01 to +0.03) and lower NDVI (-0.03 to -0.15) than Landsat-8/9-dominated years for every PIF class AVAILABLE in each window "
      "(Baramati has only the impervious PIF; Mulshi's impervious PIF has 47 cells; the corridor water NDVI interval includes zero). L7-minus-L8/9 contrasts are mixed (water red/NIR have the opposite sign). "
      "Sensor regime is fully confounded with time (L5 = 1990s, pure L8/9 = 2022-2026): a residual TM-vs-OLI difference is one explanation consistent with the pattern; real change of the targets "
      "(turbidity, roofing, canopy) and climate are others. The direction matches the historical failure, but this is an association, not an attribution.", "",
      "Note: `regime_differences.csv` and the script were re-written after the run only to add the CI columns already stored in `sensor_era_pif.json` (values unchanged).", "",
      "**Status:** exploratory. It motivated the confirmatory, pre-registered test P4-C2 (cross-sensor TM/ETM+ -> OLI transform vs identity), which will be decided on Tier-A gold, not on these PIF statistics.", "",
      "## 3. Still to do (needs the district cube and gold)", "", "* Spectral/feature distributions per era district-wide; class confusion, calibration, spatial and temporal transfer per era on gold (P4-C3).", "* Era-aware vs unified model (P4-C3)."]
write("phase4_sensor_era.md", se)
hm = ["# Phase 4 — harmonisation", "", "## 1. What is applied now", "", "* Landsat: local_pune_g30_v2 — L7 -> OLI pooled RMA from two windows (2014-2016 dry composites); L5/L4 and L9 identity. Recorded landscape slope spread between windows up to 0.08 (NIR) = an irreducible landscape-dependent uncertainty for pre-2013 L7.",
      "* Sentinel-2 -> OLI (s2_to_oli_v1): fitted on 19 corridor same-day pairs; **fails outside the corridor** (P3-I1: Baramati NIR/SWIR about -0.02, Mulshi NDVI -0.035; refitting on other windows does not remove the Baramati bias).", "",
      "## 2. New evidence (P4-E1, exploratory)", "", "Pseudo-invariant targets differ between Landsat-5- and Landsat-8/9-dominated years after harmonisation (higher red, lower NDVI in L5 years; regime confounded with time; few years per regime) — `docs/phase4_sensor_era.md`.", "",
      "## 3. Alternatives to evaluate (pre-registered P4-C2; not tuned on validation areas)", "", "1. Current (identity for TM). 2. Published cross-sensor TM/ETM+ -> OLI transformation (applied uniformly). 3. PIF-fitted per-sensor linear normalisation, fitted only on PIF cells in TRAINING blocks, evaluated on validation-block PIFs and on gold.",
      "Criteria: residual PIF differences per band (NIR, SWIR, red, NDVI, NDMI), early-era false built-up vs the envelope of independent products, and gold accuracy for 1990/2000.", "",
      "## 4. Status", "", "Gate-relevant harmonisation evidence requires the district cube (raw, unharmonised per-sensor composites must be exported so alternatives can be applied). The Earth Engine export applies the current harmonisation; "
      "for P4-C2 a raw-per-sensor export option must be added before running (documented, not yet executed)."]
write("phase4_harmonisation.md", hm)
# ================= historical
hr = ["# Phase 4 — historical reconstruction", "", "## 1. Benchmark for every epoch (built-up)", "", table(["product"] + [1990, 2000, 2010, 2015, 2020] , [[k.replace("_", " ")] + [("—" if tv(k, y) is None else f"{tv(k, y):.0f}") for y in (1990, 2000, 2010, 2015, 2020)] for k in T]), "",
      "No product agrees with another better than F1 0.43 on 1990 built-up cells (`docs/existing_product_benchmark.md`). Historical built-up has a wide external envelope; Gate G5 uses this envelope (± 0.02 of district share), not a single product.", "",
      "## 2. Whole-area test of the Phase-3 reconstruction", "", "Selected Phase-3 model (P3-F3): 1990 built share 0.50 (corridor) and 0.63 (Baramati) vs 0.01-0.21 in WSF, GISA, GLC_FCS30D; built share falls from 1990 to 2000 while all products rise. "
      "It fails the whole-area test and is **not accepted**, whatever its sampled-pixel scores.", "",
      "## 3. Causes — evidence so far", "", table(["candidate cause", "evidence", "status"], [
       ["sensor differences (TM vs OLI)", "PIF: higher red, lower NDVI in L5-dominated years (P4-E1; confounded with time, 3-8 years per regime)", "associated (exploratory) -> confirmatory P4-C2@v2"],
       ["sparse early observations", "1990-1998 dry 2-6 clear obs; post-monsoon 1-2 in many years", "documented; 1990-1991 are also edge years for 5-year windows"],
       ["training-label mismatch (2020-21 labels applied to 1990)", "historical failure grows with distance from label epoch (P3-O2: 66 % of false built-up attributed to 'temporal transfer' by a rule-based priority order)", "associated (Phase 3) -> confirmatory P4-C1@v2"],
       ["easy-cell / class-support bias", "corridor agriculture 8 % labelled; our corridor agri share far below GLC_FCS30D (P4-X2)", "associated (audit + P4-X2) -> P4-C1@v2"],
       ["dry agriculture / soil brightness", "Baramati raw dry-year excess +0.25, era-matched +0.07 (post-hoc)", "partly; confounded with era"],
       ["seasonality", "post-monsoon composites weak before 2013", "open"], ["mixed pixels / resolution", "silver excludes boundary cells (edge share 7-25 % vs 65-72 %)", "open - needs gold with dominant-share field"],
       ["class-definition differences", "products differ up to 4x for 'built-up'", "documented; mapping explicit"], ["historical reference limitations", "products agree F1 <= 0.43 in 1990", "documented"],
       ["model shortcut learning", "agreement with AI 0.92 on consensus cells vs 0.76 off-consensus (Tier C)", "suspected -> gold"], ["temporal domain shift", "Phase-3 transfer and era results", "-> P4-C3"]]), "",
      "## 4. Whole-area test protocol (frozen)", "", "Per epoch: class shares, transition matrices, change, spatial distribution; compared with the independent-product envelope, built plausibility (no district decline > 10 %), and gold. "
      "Code: `src/pune_eo/evaluation4/history.py` (unit-tested). Gate G5: `configs/phase4_evaluation_protocol.yaml`.", "", "## 5. Status", "", "G5 FAIL: no gold for any historical epoch; the only reconstruction available fails the whole-area test."]
write("phase4_historical_reconstruction.md", hr)
# ================= gold results
gk = pd.read_csv(config.path("data/labels/gold/phase4/_key/phase4_gold_key.csv"))
nA, nB = len(gk), int(gk.double_interpretation.sum()); ni = 4 * (nA + nB)
gr = ["# Phase 4 — gold results", "", "## Status: no human interpretation has been done (0 Tier-A labels). Gate G2 FAIL.", "", "This environment has no human interpreter and no Google Earth Pro historical imagery. No AI or product-derived labels were created as gold.", "",
      "## What is ready (design v2, protocol v2)", "", f"* District design: {DES['n_points']} points in {DES['n_blocks_with_points']} independent 6 km validation blocks; frame = validation blocks minus the three Phase-3 windows + 2 km "
      f"({DES['frame_share_of_district']:.0%} of the district; validation blocks are {DES['validation_blocks_share_of_blocks']:.1%} of blocks, {DES['validation_block_share_of_district']:.1%} of district area); at most {DES['max_points_per_block_per_stratum']} points per stratum per block; seed {DES['seed']}.",
      "* Allocation drawn: " + ", ".join(f"{k.replace('_', ' ')} {v}" for k, v in DES["allocation_drawn"].items()) + ".", f"* Regions (leave-one-region-out): {DES['region_counts']}.", f"* Double-interpretation subset: {nB} points ({nB / nA:.0%}).",
      "* Training eligibility: only cells >= 2 km from any validation block may be used for training/tuning (`sampling_design/training_eligible_30m.tif`); every gold point is >= 2 km from training-eligible cells.",
      "* Blind forms `blind/form_interpreter_A.csv` (all points) and `form_interpreter_B.csv` (double subset, re-shuffled), KML with 30 m cell squares; key in `_key/` (evaluator only; it is tracked in git, so blindness depends on process: interpreters must receive only the `blind/` folder).",
      "* Design v1 (672 points) was superseded before any interpretation (`v1_superseded/README.txt`): no buffer from training areas, 38 points inside the Phase-3 windows (24 in Phase-3 train blocks), up to 20 points per block, tiny strata over-allocated.",
      "* Stratum caveats: 'river_corridor_le300m' also captures ponds and tanks; the bare/sparse and residual strata are tiny (<= 5 points each, reported, not padded).", "",
      "## Next", "", f"Interpreter A: 2020 for all points, then 2000; interpreter B: the same epochs for the double subset; then adjudication. About {ni} interpretations for 4 epochs, roughly {ni // 60}-{ni // 30} interpreter-hours at 1-2 minutes each (`docs/phase4_gold_protocol.md`)."]
write("phase4_gold_results.md", gr)
st = ["# Phase 4 — spatial transfer", "", "## Evidence so far (Phase 3, 3 windows, Tier C)", "", "Within-window silver agreement 0.94-0.98; leave-one-window-out 0.69-0.86; single-source transfer gaps up to 0.29; SAR and terrain raise unseen-window agreement in the S1 era; "
      "unsupervised adaptation fails; 100-250 target labels per class close about half of the gap (`docs/domain_shift.md`). These are three windows covering 5.8 % of the district.", "",
      "## Phase-4 design (protocol v2, frozen)", "", "* Units: three CHIRPS rainfall regions (wet west, transition, dry east) for leave-one-region-out (v1 text said physiographic zones + windows; corrected in v2 before any run); 6 km hashed blocks; validation blocks never used for training; training only >= 2 km from validation blocks.",
      "* Confirmatory tests pre-registered: P4-C4@v2 (LORO gold macro-F1 >= 0.70, gap <= 0.10 — Gate G6) and P4-C6@v2 (optical+SAR+terrain vs optical in LORO, S1 era).", "", "## Status", "", "G6 FAIL until the district cube and gold exist; no district-scale generalisation is claimed."]
write("phase4_spatial_transfer.md", st)
un = ["# Phase 4 — uncertainty and abstention", "", "## Evidence so far (Phase 3, Tier C)", "", "Held-out ECE 0.03-0.12; source-calibrated conformal sets cover only 0.63-0.69 with 31-36 % empty sets; calibration on a third landscape restores 0.80-0.99 coverage (`docs/uncertainty_calibration.md`).", "",
      "## Phase-4 operational rule (to be validated on gold)", "", "1. Calibrate with temperature scaling fitted on non-target regions (third-landscape principle). 2. Abstain where calibrated max-probability < tau, tau chosen on tuning blocks for a target coverage (e.g. 80 %). "
      "3. Report accuracy-at-coverage (0.5/0.7/0.8/0.9/1.0), AURC, class-specific and spatial abstention maps. Code: `pune_eo.evaluation4.metrics.selective`, `abstain_by_threshold` (unit-tested).", "",
      "## Pre-registered", "", "P4-C5@v2 (Gate G7): ECE <= 0.05 and 90 % coverage >= 0.85 per region and era; abstention on the least-confident 20 % raises gold accuracy.", "", "## Status", "", "G7 PARTIAL: characterised in 3 windows against silver; not validated on gold."]
write("phase4_uncertainty.md", un)
wa = ["# Phase 4 — water", "", "## Separated concepts and what exists for each", "", table(["quantity", "what it is", "data in repo", "status"], [
       ["surface-water extent", "area covered by open water at a time", "JRC GSW occurrence/recurrence/seasonality (static 1984-2021 aggregates), our MNDWI composites (3 windows)", "district time series needs JRC monthly history (Earth Engine) or the district cube"],
       ["water level", "reservoir/river stage", "none", "needs dam authority / CWC data"], ["storage", "reservoir volume", "none", "needs WRD Maharashtra reservoir storage bulletins or level-area-volume curves"],
       ["groundwater", "aquifer levels", "none", "needs CGWB / GSDA well data; NOT observable by optical imagery"], ["water availability / demand", "hydrological balance / use", "none", "out of scope without official data"]]), "",
      "## Rules", "", "* No groundwater, storage or level claims from optical imagery.", "* Water masks are validated against independent observations (JRC monthly history, gauge-linked extents) — not against our own composites.", "",
      "## Status", "", "Inventory only. A district surface-water extent series is feasible once the district cube (or JRC monthly history via Earth Engine) is available."]
write("phase4_water.md", wa)
ag = ["# Phase 4 — agriculture", "", "* Crop type: **not produced** — no crop-type labels exist; none will be manufactured.", "* Established so far (Phase 3, Baramati/3 windows): agricultural state layers tagged OBSERVED / INFERRED / PROXY; 10 m vs 30 m cropping-regime separability NOT supported (silhouette < 0.25); "
      "official statistics exist only as district totals (c. 2005).", "* District-scale agricultural land, crop presence, seasonality and cropping-intensity proxies require the district cube (S2/S1 seasonal stacks).",
      "* Irrigation: only proxies (dry-season greenness on cropland; GLC_FCS30D irrigated vs rainfed cropland is a product label, not truth).", "* If independent crop labels are obtained (field surveys, state crop-cutting locations), S1+S2 temporal fusion becomes testable."]
write("phase4_agriculture.md", ag)
fl = ["# Phase 4 — flood", "", "Event inventory (Phase 3, P3-N1): of three cited events only Baramati 2025-05-25 has a Sentinel-1 acquisition within -1..+3 days; its candidate extent (1.1-3.6 km² depending on threshold) is UNVALIDATED.", "",
      "For each event the inventory requires: pre-event S1, post-event S1, rainfall, candidate inundation, independent evidence, validation. With one observable event and no independent extent, **no flood ML is built**.", "",
      "Next: extend the event list from official sources (district disaster management reports, IMD extreme-rainfall records), check S1 timing for each, and collect independent extents (news imagery, Sentinel-2 when cloud-free, field reports)."]
write("phase4_flood.md", fl)
co = ["# Phase 4 — coupled land-water-agriculture-urban analysis", "", "**Not started, by design.** The coupled analysis needs reliable individual products (G5-G7) at district scale (G9). None of these gates is passed.", "",
      "Planned design once prerequisites exist: taluka-level panel 1990-2026 of built-up, agriculture, natural vegetation, surface water, rainfall (CHIRPS/IMD), population (census/GHS-POP, noting GHS-POP is modelled from built-up); "
      "panel regressions with fixed effects and spatial autocorrelation diagnostics; all results reported as associations. Missing inputs: taluka boundaries, census tables, roads (OSM), reservoir storage."]
write("phase4_coupled_analysis.md", co)
pp = ["# Phase 4 — thesis paper structure (retained only where evidence supports it)", "", table(["paper", "focus", "evidence now", "missing", "status"], [
       ["1 Reliable multi-decadal land-cover reconstruction under sensor and landscape shift", "multi-year labels, temporal context, harmonisation, independent validation", "Phase 3: multi-year labels -39 to -41 % early false built-up; temporal context -49 %; P4-E1 sensor residuals; product benchmark shows a wide historical envelope",
        "Tier-A historical gold; district cube; P4-C1..C3", "RETAINED (core); confirmatory evidence pending"],
       ["2 Uncertainty-aware spatial transfer of multimodal EO models", "SAR, optical, terrain, domain shift, calibration, third-landscape calibration, abstention", "Phase 3 (3 windows): SAR/terrain gains on unseen windows; source-calibrated conformal fails; third-landscape calibration restores coverage",
        "district regions, gold-based calibration (P4-C4..C6)", "RETAINED (strong candidate)"],
       ["3 Coupled land-water-agriculture-urban transformation of Pune District", "district-scale evidence", "existing-product benchmark only", "reliable products (G5-G9), water/agri data, admin and census layers", "ON HOLD - not supported yet"]]), "",
      "A possible methods note independent of our models: 'How much do global products disagree on historical built-up in a fast-growing Indian district?' (P4-X1: up to 4x in area; F1 0.32-0.43 in 1990) — publishable as a short benchmark once gold quantifies which product is closest."]
write("phase4_papers.md", pp)
# ================= readiness gate + final report
recs4 = [json.loads(p.read_text()) for p in sorted(config.path("experiments/registry4").glob("*.json"))]; CK = P4.check_confirmatory_records()
G = {"G1 data foundation": ("FAIL", f"30 m data cover {100 * INV['coverage']['windows_share_of_district']:.1f} % of the district; district cube not built (export ready, needs Earth Engine); pre-2013 record sparse"),
     "G2 human validation": ("FAIL", "0 Tier-A labels; district design and blind kit ready"),
     "G3 existing-product benchmark": ("PARTIAL", "GLC_FCS30D, GISA 2.0, WSF, GHSL, ESA CCI, Esri, WorldCover compared district-wide with documented class mapping and disagreement maps; NOT compared: JRC (used only for strata/PIFs), ALOS FNF, MS buildings (acquirable), Dynamic World and GAIA (need Earth Engine)"),
     "G4 training-label quality": ("FAIL", "easy-cell bias and class gaps documented; label-quality family P4-C1@v2 pre-registered, needs gold"),
     "G5 historical validity": ("FAIL", "no historical gold; the only reconstruction fails the whole-area test"),
     "G6 spatial generalisation": ("FAIL", "3 windows only; LORO design frozen (P4-C4@v2)"),
     "G7 uncertainty": ("PARTIAL", "characterised in 3 windows on Tier C; not validated on gold (P4-C5@v2)"),
     "G8 confirmatory experiment": ("PASS (design)" if CK["ok"] else "FAIL", f"protocol v{P4.load_protocol()['protocol_version']} frozen (code {P4.load_protocol()['frozen']['code_sha256'][:12]}, protocol YAML {P4.load_protocol()['frozen']['protocol_sha256'][:12]}); automated check protocol.check_confirmatory_records(): ok={CK['ok']} for {len(CK['records'])} active confirmatory records (all PENDING, none executed); v1 records superseded before execution"),
     "G9 district scale": ("FAIL", "requires G1, G5, G6, G7")}
rg = ["# Phase 4 — readiness gate", "", table(["gate", "status", "evidence"], [[k, v[0], v[1]] for k, v in G.items()]), "", "## FINAL DECISION: **NOT_READY**", "",
      "Missing evidence, exactly:", "1. Tier-A human gold on the district design (G2) — at minimum 2020 and 2000 for >= 80 % of points, >= 20 % double interpreted (the design provides 25 %).",
      "2. District 30 m cube 1990-2026 (G1, G9) — run `scripts/gee/export_district_cube.py` with an Earth Engine project, then inventory it.",
      "3. Confirmatory results P4-C1@v2..C6@v2 on gold (G4-G7), run once with the frozen protocol v2.", "4. Historical reconstruction passing the whole-area test inside the independent-product envelope (G5).", "",
      "## Against the standard 'would a skeptical reviewer believe it?'", "", table(["component", "assessment"], [["valid data", "partly: archive and provenance sound; district 30 m data absent; pre-2013 sparse; residual sensor differences"],
       ["valid labels", "no: no human labels; silver labels biased to easy cells"], ["independent validation", "no: Tier B/C only"], ["spatial generalisation", "no: 3 windows"], ["temporal generalisation", "no: historical failure"],
       ["uncertainty", "partly characterised"], ["reproducibility", "yes: registry, frozen protocol, unit tests, inventory"], ["scientific interpretation", "partly: negative results reported; candidate causes examined only in exploratory analyses (none tested confirmatorily)"]])]
write("phase4_readiness_gate.md", rg)
fr = ["# Phase 4 — final report (this session)", "", "## What Phase 4 did", "", "1. Complete data inventory and quality audit (`docs/phase4_data_inventory.md`, `phase4_data_quality.md`, `data/inventory/`).",
      "2. Training- and validation-label audit (`phase4_training_labels.md`): silver labels are interior cells (edge share 7-25 % vs 65-72 %), some classes nearly absent, autocorrelation up to ~4 km.",
      "3. Entry audit with weakness matrix and dependency graph (`phase4_audit.md`).", "4. Evaluation protocol frozen (v1), independently verified, then corrected as v2 BEFORE any confirmatory run (selection rule, rainfall regions, 2 km training buffer, block-cluster bootstrap, YAML hashed); 15 unit tests; registry4 refuses confirmatory runs if code or protocol change (`phase4_evaluation_protocol.md`).",
      f"5. District validation design v2: {DES['n_points']} points in {DES['n_blocks_with_points']} independent blocks outside the Phase-3 windows, 13 strata oversampling hard landscapes and product disagreement; blind kit for two interpreters; design v1 superseded before use (`phase4_gold_protocol.md`).",
      "6. Existing products brought onto the district grid and benchmarked (`existing_product_benchmark.md`): built-up area differs up to 4x between products in 2020; 1990 built-up agreement F1 0.32-0.43; all three land-cover products agree on 60 % of the district; disagreement is highest on 3-8° slopes, in the transition rainfall zone, near water and in recently settled areas (P4-X3).",
      "7. Exploratory sensor-era test on pseudo-invariant targets (`phase4_sensor_era.md`): L5-dominated years show higher red and lower NDVI than L8/9-dominated years (confounded with time; few years per regime) — consistent with, not proof of, a residual sensor difference.",
      "8. Earth Engine export pipeline for the district cube (`scripts/gee/export_district_cube.py`, dry-run tested).", "9. Six confirmatory experiments pre-registered (now @v2 under protocol v2) before their gold data exist; P4-C2@v2 was motivated by exploratory P4-E1/X1/X2 and only its gold-based part is blind (recorded in the registry).", "",
      "## Registry4", "", table(["id", "kind", "status", "outcome", "result / reason"], [[r["experiment_id"], r["kind"], r["status"], r.get("outcome") or "—", (r.get("result") or r.get("not_run_reason") or "")[:180]] for r in recs4]), "",
      "## Decision", "", "**NOT_READY** (`phase4_readiness_gate.md`). The blocking items are human gold and the district cube; both need resources outside this sandbox (interpreters; an Earth Engine project)."]
write("phase4_final_report.md", fr)
