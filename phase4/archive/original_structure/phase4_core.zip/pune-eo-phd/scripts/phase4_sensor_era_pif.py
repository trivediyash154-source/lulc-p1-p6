"""P4-E1 (EXPLORATORY): residual sensor-era radiometric differences after harmonisation, measured on pseudo-invariant features (PIFs) in the 3 windows.
PIFs (from independent products, never from our models):
  water_pif      JRC occurrence >= 95 AND GLC_FCS30D water (210) in all 26 epochs 1985-2022
  impervious_pif GLC_FCS30D impervious (190) in all 26 epochs AND WSF-Evolution first year 1985
  forest_pif     GLC_FCS30D forest (51-92) in all 26 epochs
Per year: median dry-season surface reflectance of each PIF class from the 30 m cube (harmonised with local_pune_g30_v2: L7 -> OLI RMA, L5/L9 identity).
Sensor regime per year from the composite metadata (share of clear pixels by platform). Compared: years dominated (>= 80 %) by Landsat-5, by Landsat-7, by Landsat-8/9,
restricted to SPI-normal years to limit climate effects; year-level bootstrap CI of the regime differences. Real change of a PIF (turbidity, roofing, canopy) cannot be excluded:
this is evidence of radiometric inconsistency only where it is consistent across PIF classes and windows."""
import json, sys, warnings
import numpy as np, pandas as pd, rasterio, xarray as xr
sys.path.insert(0, "src"); warnings.filterwarnings("ignore")
from pune_eo import config
from pune_eo.grid import district_grid
from pune_eo.evaluation4 import protocol as P4
OUT = config.path("results/phase4/sensor_era"); OUT.mkdir(parents=True, exist_ok=True); G = district_grid("G30"); PX = config.path("data/products_ext")
W = ["pune_G30_khadakwasla_mutha", "pune_G30_baramati_agri", "pune_G30_mulshi_ghats"]; BANDS = ["dry_blue", "dry_green", "dry_red", "dry_nir", "dry_swir1", "dry_swir2", "dry_ndvi"]
if P4.load("P4-E1") is None:
    P4.register(experiment_id="P4-E1", kind="exploratory", family="sensor_era", hypothesis="after harmonisation, pseudo-invariant targets still show reflectance differences between Landsat-5-, Landsat-7- and Landsat-8/9-dominated years",
                comparator="L5-dominated vs L8/9-dominated and L7- vs L8/9-dominated SPI-normal years", primary_metric="difference of PIF median dry-season reflectance", direction="two-sided", threshold="none (exploratory)",
                dataset_version="cube 2026-10-02 + GLC_FCS30D/JRC/WSF", evaluation_set="PIF cells in 3 windows", region="3 benchmark windows", years="1990-2026", features=BANDS, labels="none", label_tier="B (PIF selection)",
                model="none", seeds=[], splits="none", metrics_planned=["regime difference with year-bootstrap CI", "inter-annual CV by regime"])
run = P4.Run("P4-E1")
C = pd.read_csv(config.path("data/inventory/composites.csv")); CL = pd.read_csv(config.path("data/features/het_v1/climate.csv"))
GLC = {10: 2, 11: 2, 12: 2, 20: 2}; FOREST = [51, 52, 61, 62, 71, 72, 81, 82, 91, 92]
res = {"pif_counts": {}, "series": {}, "regime_differences": {}}
with rasterio.open(PX / "glc_fcs30d/glc_fcs30d_district_30m.tif") as s: glc_all = s.read()
for w in W:
    ds = xr.open_zarr(config.path("data/features/cube", f"{w}.zarr")); gj = json.loads(ds.attrs["grid"]); c0 = int(round((gj["x0"] - G.x0) / 30)); r0 = int(round((G.y1 - gj["y1"]) / 30))
    gl = glc_all[:, r0:r0 + gj["height"], c0:c0 + gj["width"]]
    with rasterio.open(config.path("data/labels", w, "jrc_gsw.tif")) as s: jrc = s.read(1)
    with rasterio.open(config.path("data/labels", w, "wsf_evolution_first_year.tif")) as s: wsf = s.read(1)
    pif = {"water_pif": (jrc >= 95) & (jrc != 255) & (gl == 210).all(0), "impervious_pif": (gl == 190).all(0) & (wsf == 1985), "forest_pif": np.isin(gl, FOREST).all(0)}
    res["pif_counts"][w] = {k: int(v.sum()) for k, v in pif.items()}
    fl = ds.feature.values.tolist(); yrs = ds.year.values.tolist(); L = ds.landsat.values      # (year, feature, y, x)
    meta = C[(C.grid == w) & (C.family == "landsat") & (C.period == "dry")].set_index("year")
    rows = []
    for j, y in enumerate(yrs):
        sens = json.loads(meta.loc[y, "sensors"]) if y in meta.index and isinstance(meta.loc[y, "sensors"], str) else {}
        tot = sum(sens.values()) or 1; share = {k: v / tot for k, v in sens.items()}
        regime = "L5" if share.get("landsat-5", 0) >= 0.8 else ("L7" if share.get("landsat-7", 0) >= 0.8 else ("L8_9" if share.get("landsat-8", 0) + share.get("landsat-9", 0) >= 0.8 else "mixed"))
        spi = CL[(CL.window == w) & (CL.year == y)].climate_class.values; rec = {"year": y, "regime": regime, "climate": spi[0] if len(spi) else None, **{f"share_{k}": v for k, v in share.items()}}
        for k, m in pif.items():
            if m.sum() < 20: continue
            for b in BANDS: rec[f"{k}|{b}"] = float(np.nanmedian(L[j, fl.index(b)][m]))
        rows.append(rec)
    D = pd.DataFrame(rows); D.to_csv(OUT / f"pif_series_{w[9:]}.csv", index=False); res["series"][w] = {"regime_counts": D.regime.value_counts().to_dict()}
    rng = np.random.default_rng(20261112); N = D[D.climate == "normal"]
    for k in pif:
        for b in BANDS:
            col = f"{k}|{b}"
            if col not in D: continue
            for a_, b_ in (("L5", "L8_9"), ("L7", "L8_9")):
                xa, xb = N[N.regime == a_][col].dropna().values, N[N.regime == b_][col].dropna().values
                if len(xa) < 3 or len(xb) < 3: continue
                bs = [rng.choice(xa, len(xa)).mean() - rng.choice(xb, len(xb)).mean() for _ in range(2000)]
                lo, hi = np.percentile(bs, [2.5, 97.5])
                res["regime_differences"][f"{w[9:]}|{k}|{b}|{a_}-{b_}"] = {"diff": float(xa.mean() - xb.mean()), "ci": [float(lo), float(hi)], "excludes_zero": bool(lo > 0 or hi < 0), "n_years": [len(xa), len(xb)],
                                                                         "cv_a": float(np.std(xa) / abs(np.mean(xa))) if np.mean(xa) else None, "cv_b": float(np.std(xb) / abs(np.mean(xb))) if np.mean(xb) else None}
json.dump(res, open(OUT / "sensor_era_pif.json", "w"), indent=1, default=float)
RD = pd.DataFrame([{"key": k, **v} for k, v in res["regime_differences"].items()])
if len(RD):
    RD[["window", "pif", "band", "contrast"]] = RD.key.str.split("|", expand=True); RD["ci_lo"] = RD.ci.str[0]; RD["ci_hi"] = RD.ci.str[1]; RD.to_csv(OUT / "regime_differences.csv", index=False)
    sig = RD[RD.excludes_zero]; frac = float(RD.excludes_zero.mean())
    summ = f"{len(sig)} of {len(RD)} PIF x band x window contrasts differ between sensor regimes (CI excludes 0); median |diff| reflectance {RD[~RD.band.str.contains('ndvi')]['diff'].abs().median():.4f}, NDVI {RD[RD.band.str.contains('ndvi')]['diff'].abs().median():.3f}"
else: summ, frac = "too few regime-pure normal years", None
run.complete({"pif_counts": res["pif_counts"], "share_contrasts_excluding_zero": frac, "regime_counts": {w: res["series"][w]["regime_counts"] for w in res["series"]}}, "NA", summ,
             outputs={"summary": "results/phase4/sensor_era/sensor_era_pif.json", "table": "results/phase4/sensor_era/regime_differences.csv"})
print(summ); print(res["pif_counts"])
