"""Phase 4, first task: complete, machine-readable inventory of what the repository ACTUALLY contains (read from files, not from earlier docs).
Outputs (data/inventory/):
  scenes_by_year_season.csv   per sensor x year x season: discovered / selected scenes, cloud quantiles, district overlap, exclusion reasons
  composites.csv              every composite product (metadata.json): grid, family, kind, period, n scenes, clear-obs stats, valid fraction, QA, raster present?
  cubes.csv                   per 30 m window cube: shape, per-year dry-season valid fraction
  labels_reference.csv        every label / reference raster with its JSON provenance
  datasets.csv                one row per dataset with the fields required by the Phase-4 brief
  coverage.json               district vs window area, per-grid coverage
  inventory_summary.json"""
import json, os, sys, glob, warnings
import numpy as np, pandas as pd, geopandas as gpd
sys.path.insert(0, "src"); warnings.filterwarnings("ignore")
from pune_eo import config
from pune_eo.provenance import utcnow
R = config.ROOT; OUT = config.path("data/inventory"); OUT.mkdir(parents=True, exist_ok=True)
SEAS = {m: "dry" for m in range(1, 6)} | {m: "wet" for m in range(6, 10)} | {m: "post_monsoon" for m in range(10, 13)}
ERAS = [("early_historical", 1990, 1998), ("landsat_dominant", 1999, 2014), ("sentinel_dense", 2015, 2021), ("current", 2022, 2026)]
era = lambda y: next((e for e, a, b in ERAS if a <= y <= b), "pre_1990" if y < 1990 else "other")
# ---------------- 1. scenes
rows = []
for fam in ("landsat", "sentinel2", "sentinel1"):
    M = gpd.read_parquet(config.path("data/manifests", f"{fam}_manifest.parquet")); M["season"] = M.month.map(SEAS)
    for (pl, y, s), d in M.groupby(["platform", "year", "season"]):
        sel = d[d.selected]
        rows.append({"family": fam, "platform": pl, "year": int(y), "season": s, "era": era(int(y)), "discovered": len(d), "selected": len(sel),
                     "cloud_median_selected": float(sel.cloud_cover.median()) if len(sel) and sel.cloud_cover.notna().any() else None,
                     "cloud_p90_selected": float(sel.cloud_cover.quantile(0.9)) if len(sel) and sel.cloud_cover.notna().any() else None,
                     "district_overlap_fraction_median": float(sel.district_overlap_fraction.median()) if len(sel) else None,
                     "n_distinct_dates_selected": int(sel.date.nunique()),
                     "exclusion_reasons": json.dumps(d[~d.selected].exclusion_reason.value_counts().to_dict())})
S = pd.DataFrame(rows); S.to_csv(OUT / "scenes_by_year_season.csv", index=False)
# ---------------- 2. composites
crows = []
for f in sorted(glob.glob(str(R / "data/composites/*/*/*/*/*/metadata.json")) + glob.glob(str(R / "data/composites/*/*/*/*/metadata.json"))):
    try: d = json.load(open(f))
    except Exception: continue
    p = os.path.relpath(f, R).split(os.sep); st = d.get("statistics", {}) or {}; qa = d.get("qa", {}) or {}; tm = d.get("temporal", {}) or {}
    files = d.get("files", {}) or {}; present = [k for k, v in files.items() if os.path.exists(R / v["path"])] if isinstance(files, dict) else []
    crows.append({"grid": p[2], "year": tm.get("year"), "family": p[4] if len(p) > 5 else p[3], "kind": tm.get("kind"), "period": tm.get("period"), "complete": tm.get("complete"),
                  "n_items": st.get("n_items"), "n_items_with_clear_px": st.get("n_items_with_clear_px"), "n_clear_median": st.get("n_clear_median"), "n_clear_p10": st.get("n_clear_p10"),
                  "valid_fraction": st.get("district_valid_fraction", st.get("valid_fraction")), "reliable_fraction_ge3": st.get("district_reliable_fraction_ge3", st.get("reliable_fraction_ge3")),
                  "single_obs_fraction": st.get("single_obs_fraction"), "scene_cloud_mean": st.get("scene_cloud_mean"),
                  "sensors": json.dumps({k: v for k, v in (st.get("sensor_contribution_clear_px") or {}).items() if v}),
                  "qa_status": qa.get("status"), "qa_warn": "; ".join(qa.get("warn", []) or [])[:300], "processing_version": d.get("processing_version"),
                  "files_declared": len(files) if isinstance(files, dict) else 0, "files_present": len(present), "metadata": os.path.relpath(f, R)})
C = pd.DataFrame(crows); C.to_csv(OUT / "composites.csv", index=False)
# ---------------- 3. cubes
cub = []
for f in sorted(glob.glob(str(R / "data/features/cube/*.json"))):
    d = json.load(open(f)); g = os.path.basename(f)[:-5]; sh = d["shape"]["landsat"]
    for y, v in d["valid_fraction_landsat_dry_ndvi"].items(): cub.append({"grid": g, "year": int(y), "dry_ndvi_valid_fraction": v, "rows": sh[2], "cols": sh[3], "area_km2": sh[2] * sh[3] * 0.0009,
                                                                       "has_dry": d["availability"][str(y)]["dry"], "has_post": d["availability"][str(y)]["post"]})
CU = pd.DataFrame(cub); CU.to_csv(OUT / "cubes.csv", index=False)
# ---------------- 4. labels / reference rasters
import rasterio
lrows = []
for f in sorted(glob.glob(str(R / "data/labels/pune_G30_*/*.tif")) + glob.glob(str(R / "data/features/reference/*/*.tif")) + glob.glob(str(R / "data/raw/labels/ghs_pop/*.tif"))):
    with rasterio.open(f) as s: info = {"bands": s.count, "res": round(abs(s.transform.a), 1), "shape": f"{s.height}x{s.width}", "crs": str(s.crs), "descriptions": "; ".join(x or "" for x in s.descriptions)[:200]}
    j = f[:-4] + ".json"; meta = json.load(open(j)) if os.path.exists(j) else {}
    lrows.append({"path": os.path.relpath(f, R), "grid": f.split(os.sep)[-2], **info, "has_provenance_json": bool(meta), "provenance_keys": ",".join(list(meta.keys())[:8])})
L = pd.DataFrame(lrows); L.to_csv(OUT / "labels_reference.csv", index=False)
# ---------------- 5. coverage
study = json.load(open(R / "data/composites/pune_G240/2000/landsat/seasonal/post_monsoon/metadata.json"))["study_area"]
win_area = CU.groupby("grid").area_km2.first().to_dict(); dist_km2 = study["area_km2"]
cov = {"district_area_km2": dist_km2, "windows_30m_km2": win_area, "windows_30m_total_km2": float(sum(win_area.values())), "windows_share_of_district": float(sum(win_area.values()) / dist_km2),
       "g240_district_cells": 271568, "g10_s2_window": "baramati_agri only (2021, 2024 metadata; 2021 rasters)", "district_30m_cube": "NOT BUILT"}
json.dump(cov, open(OUT / "coverage.json", "w"), indent=1)
# ---------------- 6. gold
key = pd.read_csv(R / "data/labels/gold/_key/gold_key.csv"); p1 = pd.read_csv(R / "results/gold/provisional_ai_pass1.csv")
gold = {"design_points": len(key), "points_by_window": key.window.value_counts().to_dict(), "points_by_stratum": key.stratum.value_counts().to_dict(), "sampling_frame": "TEST blocks of the 3 benchmark windows only",
        "human_tier_A_labels": 0, "provisional_ai_tier_C_labels_2021": int((~p1.reference_class_2021.isin(["uncertain", "ambiguous"])).sum()), "epochs_planned": [1990, 2000, 2010, 2020, 2025]}
# ---------------- 7. datasets table (the brief's fields)
def sc(fam):
    d = S[S.family == fam]; return d
ls, s2, s1 = sc("landsat"), sc("sentinel2"), sc("sentinel1")
def yr(d, col="selected"): yy = d[d[col] > 0].year; return f"{int(yy.min())}-{int(yy.max())}" if len(yy) else "none"
G240 = C[C.grid == "pune_G240"]; W30 = C[C.grid.str.startswith("pune_G30")]
ds = [
 {"dataset": "Landsat C2 L2 surface reflectance scenes", "sensor_source": "Landsat 5 TM / 7 ETM+ / 8 OLI / 9 OLI-2 (Planetary Computer STAC)", "date_year": yr(ls), "spatial_coverage": "district (WRS-2 146/047, 146/048, 147/047, 147/048)",
  "resolution": "30 m", "bands": "blue, green, red, nir08, swir16, swir22 + QA_PIXEL", "quality": f"{int(ls.selected.sum())} selected of {int(ls.discovered.sum())} discovered; L1-L3 MSS excluded", "cloud_fraction": "scene cloud <= manifest threshold; per-pixel QA_PIXEL mask",
  "nodata_fraction": "per composite (composites.csv)", "processing_level": "L2SP (LaSRC/LEDAPS)", "source": "USGS via Microsoft Planetary Computer", "license": "public domain (USGS)", "preprocessing_version": "local_pune_g30_v2 harmonisation", "validation_role": "model input"},
 {"dataset": "Sentinel-2 L2A scenes", "sensor_source": "Sentinel-2A/B(/C) MSI", "date_year": yr(s2), "spatial_coverage": "district (MGRS tiles)", "resolution": "10/20 m", "bands": "B02-B12 + SCL",
  "quality": f"{int(s2.selected.sum())} selected; dense only from 2018", "cloud_fraction": "SCL mask (reader v2 since Phase 2 fix)", "nodata_fraction": "per composite", "processing_level": "L2A Sen2Cor", "source": "ESA Copernicus via Planetary Computer",
  "license": "Copernicus open", "preprocessing_version": "SCL reader v2 (job hash 1ec2a5a4fb52fb1e); s2_to_oli_v1 for fusion (corridor-fitted, NOT transferable: P3-I1)", "validation_role": "model input; gold-chip context (2021)"},
 {"dataset": "Sentinel-1 GRD scenes", "sensor_source": "Sentinel-1A/B IW GRD (RTC on PC)", "date_year": yr(s1), "spatial_coverage": "district", "resolution": "10 m native, composited to 30/240 m", "bands": "VV, VH (dB)",
  "quality": f"{int(s1.selected.sum())} selected; S1B gap after Dec 2021; 2025 archive incomplete", "cloud_fraction": "n/a (SAR)", "nodata_fraction": "per composite", "processing_level": "RTC gamma0", "source": "ESA via Planetary Computer",
  "license": "Copernicus open", "preprocessing_version": "S1 cube reader fixed in Phase 2", "validation_role": "model input"},
 {"dataset": "Landsat composites, district G240", "sensor_source": "Landsat", "date_year": "1990-2026", "spatial_coverage": "district", "resolution": "240 m (benchmark grid)", "bands": "6 SR + indices",
  "quality": f"{len(G240[G240.family == 'landsat'])} products; median clear obs per season in metadata", "cloud_fraction": "see composites.csv", "nodata_fraction": f"valid fraction median {G240[G240.family == 'landsat'].valid_fraction.median():.3f}",
  "processing_level": "seasonal/annual medoid composites", "source": "this repo", "license": "derived", "preprocessing_version": "cube-0.1.0", "validation_role": "district overview only (240 m too coarse for 30 m LULC)"},
 {"dataset": "Landsat/S1/S2 composites, 30 m windows", "sensor_source": "Landsat, S1, S2", "date_year": "1990-2026 (S1 2017-2025, S2 2021/2024)", "spatial_coverage": f"3 windows, {cov['windows_30m_total_km2']:.0f} km2 = {100 * cov['windows_share_of_district']:.1f} % of district",
  "resolution": "30 m", "bands": "SR, indices, VV/VH", "quality": f"{len(W30)} products", "cloud_fraction": "composites.csv", "nodata_fraction": f"valid median {W30.valid_fraction.median():.3f}", "processing_level": "composites", "source": "this repo", "license": "derived",
  "preprocessing_version": "cube-0.1.0, local_pune_g30_v2", "validation_role": "model input (benchmark windows)"},
 {"dataset": "30 m feature cubes", "sensor_source": "derived", "date_year": "1990-2026", "spatial_coverage": "3 windows", "resolution": "30 m", "bands": "23 Landsat feats, 3 quality, 12 terrain, 7 Sentinel (2017-2025)", "quality": f"dry-NDVI valid fraction min {CU.dry_ndvi_valid_fraction.min():.4f}",
  "cloud_fraction": "-", "nodata_fraction": f"min valid {CU.dry_ndvi_valid_fraction.min():.4f}", "processing_level": "analysis-ready features", "source": "this repo", "license": "derived", "preprocessing_version": "rebuilt 2026-10-02 with S1 2017-2025", "validation_role": "model input"},
 {"dataset": "DEM", "sensor_source": "Copernicus GLO-30 (DSM, primary), NASADEM (secondary)", "date_year": "2011-2015 / 2000", "spatial_coverage": "3 windows (terrain cubes)", "resolution": "30 m", "bands": "elevation, slope, aspect, TPI, HAND, ...", "quality": "DSM includes buildings/canopy",
  "cloud_fraction": "-", "nodata_fraction": "-", "processing_level": "derived terrain", "source": "Planetary Computer", "license": "Copernicus DEM licence / NASA", "preprocessing_version": "configs/dem.yaml", "validation_role": "covariate"},
 {"dataset": "CHIRPS v2 monthly rainfall", "sensor_source": "CHIRPS", "date_year": "1981-present (local series)", "spatial_coverage": "district", "resolution": "0.05 deg (~5.5 km)", "bands": "precipitation mm/month", "quality": "satellite-gauge blend, coarse",
  "cloud_fraction": "-", "nodata_fraction": "-", "processing_level": "monthly", "source": "UCSB CHC", "license": "public domain-like (CHC)", "preprocessing_version": "data/processed/climate", "validation_role": "covariate; SPI drought classes (proxy)"},
 {"dataset": "ESA WorldCover 2020/2021", "sensor_source": "S1+S2 (ESA)", "date_year": "2020, 2021", "spatial_coverage": "3 windows (fractions); district G240 mode 2021", "resolution": "10 m -> 30 m fractions", "bands": "11 classes", "quality": "global OA ~75-77 % (producer-reported)",
  "cloud_fraction": "-", "nodata_fraction": "-", "processing_level": "product", "source": "ESA", "license": "CC-BY 4.0", "preprocessing_version": "-", "validation_role": "silver label source (Tier C)"},
 {"dataset": "Esri/Impact Observatory LULC 2017-2023", "sensor_source": "S2 (Esri)", "date_year": "2017-2023", "spatial_coverage": "3 windows", "resolution": "10 m -> 30 m fractions", "bands": "9 classes", "quality": "producer-reported ~75-85 %", "cloud_fraction": "-", "nodata_fraction": "-",
  "processing_level": "product", "source": "Esri / Impact Observatory (PC io-lulc-annual-v02)", "license": "CC-BY 4.0", "preprocessing_version": "-", "validation_role": "silver label source (Tier C)"},
 {"dataset": "GHSL BUILT-S R2023A", "sensor_source": "JRC (Landsat/S2)", "date_year": "1990-2020 (5-yearly epochs)", "spatial_coverage": "3 windows", "resolution": "90 m (built fraction)", "bands": "built surface fraction", "quality": "multitemporal modelled", "cloud_fraction": "-", "nodata_fraction": "-",
  "processing_level": "product", "source": "JRC", "license": "CC-BY 4.0", "preprocessing_version": "-", "validation_role": "independent reference (Tier B)"},
 {"dataset": "WSF-Evolution", "sensor_source": "DLR (Landsat)", "date_year": "1985-2015 (first settled year)", "spatial_coverage": "3 windows", "resolution": "30 m", "bands": "first year settled", "quality": "GDAL nodata bug fixed in Phase 2", "cloud_fraction": "-", "nodata_fraction": "-",
  "processing_level": "product", "source": "DLR", "license": "CC-BY 4.0", "preprocessing_version": "rebuilt 2026-10-02", "validation_role": "independent reference (Tier B)"},
 {"dataset": "JRC Global Surface Water v1.3", "sensor_source": "JRC (Landsat)", "date_year": "1984-2021", "spatial_coverage": "3 windows + district G240", "resolution": "30 m", "bands": "occurrence etc.", "quality": "-", "cloud_fraction": "-", "nodata_fraction": "-",
  "processing_level": "product", "source": "JRC", "license": "CC-BY 4.0", "preprocessing_version": "-", "validation_role": "independent reference (Tier B)"},
 {"dataset": "GHS-POP R2023A", "sensor_source": "JRC", "date_year": "2000, 2010, 2020", "spatial_coverage": "tile R7_C26 (covers district)", "resolution": "100 m (Mollweide)", "bands": "population", "quality": "modelled from census + built-up (NOT independent of GHSL built-up)",
  "cloud_fraction": "-", "nodata_fraction": "-", "processing_level": "product", "source": "JRC", "license": "CC-BY 4.0", "preprocessing_version": "raw, not reprojected", "validation_role": "context (not independent of GHSL)"},
 {"dataset": "Gold sample (blind kit)", "sensor_source": "design: stratified random in TEST blocks", "date_year": "epochs 1990/2000/2010/2020/2025", "spatial_coverage": "3 windows only", "resolution": "30 m cell", "bands": "-",
  "quality": f"{gold['design_points']} points; HUMAN Tier-A labels: 0; provisional AI (Tier C, 2021) labelled: {gold['provisional_ai_tier_C_labels_2021']}", "cloud_fraction": "-", "nodata_fraction": "-", "processing_level": "-", "source": "this repo", "license": "-",
  "preprocessing_version": "blind kit v1 (Phase 3)", "validation_role": "would be Tier A once human-labelled"},
 {"dataset": "Agriculture data (crop type, irrigation, official stats)", "sensor_source": "-", "date_year": "-", "spatial_coverage": "-", "resolution": "-", "bands": "-", "quality": "NO crop-type labels; NO irrigation maps; district NSA/GCA totals c. 2005 only (P3-M3)", "cloud_fraction": "-",
  "nodata_fraction": "-", "processing_level": "-", "source": "-", "license": "-", "preprocessing_version": "-", "validation_role": "none available"},
 {"dataset": "Water: gauges, reservoir levels/storage, groundwater", "sensor_source": "-", "date_year": "-", "spatial_coverage": "-", "resolution": "-", "bands": "-", "quality": "NONE in repo (only JRC occurrence and our MNDWI-based masks)", "cloud_fraction": "-", "nodata_fraction": "-",
  "processing_level": "-", "source": "-", "license": "-", "preprocessing_version": "-", "validation_role": "none available"},
 {"dataset": "Flood events", "sensor_source": "configs/events.yaml (news/Wikipedia-cited)", "date_year": "2019-09-25, 2024-07-25, 2025-05-25", "spatial_coverage": "event bboxes", "resolution": "-", "bands": "-", "quality": "only 2025 Baramati has S1 within window; no independent extent",
  "cloud_fraction": "-", "nodata_fraction": "-", "processing_level": "-", "source": "news/Wikipedia", "license": "-", "preprocessing_version": "-", "validation_role": "inventory only"},
 {"dataset": "Roads / accessibility, population census, admin (taluka) boundaries", "sensor_source": "-", "date_year": "-", "spatial_coverage": "-", "resolution": "-", "bands": "-", "quality": "NOT in repo (district boundary only)", "cloud_fraction": "-", "nodata_fraction": "-",
  "processing_level": "-", "source": "-", "license": "-", "preprocessing_version": "-", "validation_role": "none"},
]
DS = pd.DataFrame(ds); DS.to_csv(OUT / "datasets.csv", index=False)
summ = {"created_utc": utcnow(), "scenes": {fam: {"discovered": int(d.discovered.sum()), "selected": int(d.selected.sum()), "years_with_selected": yr(d)} for fam, d in S.groupby("family")},
        "composites": {"n_products": len(C), "by_grid": C.grid.value_counts().to_dict(), "products_with_all_files_present": int((C.files_present == C.files_declared).sum()), "products_metadata_only": int(((C.files_present == 0) & (C.files_declared > 0)).sum())},
        "coverage": cov, "gold": gold, "n_label_reference_rasters": len(L)}
json.dump(summ, open(OUT / "inventory_summary.json", "w"), indent=1, default=str); print(json.dumps(summ, indent=1, default=str)[:3000])
