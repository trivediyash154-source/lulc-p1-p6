"""Phase-2 deliverable archives (each < 24 MiB; split automatically). Output: /mnt/user-data/outputs/phase2/
  phase2_core.zip            code, configs, tests, docs, experiment registry, results (json/csv/figures), label metadata, gold forms, git log + code patches
  phase2_maps_<window>.zip   multi-band COGs: AOA-gated HMM L1 1990-2026, raw L1, inside-AOA mask, uncertainty 2021, flood frequency, trajectories
  phase2_labels.zip          silver L1/L2, splits, WSF, JRC, GHSL rasters per window
  phase2_gold_chips_<window>_partN.zip  Landsat context chips for gold interpretation
Feature cubes (data/features/cube, ~2.6 GB) and composites are REGENERATED with the scripts (README Phase 2), not shipped."""
import os, subprocess, zipfile, json, sys
from pathlib import Path
import numpy as np, xarray as xr, rasterio
sys.path.insert(0, "src")
from pune_eo import config
from pune_eo.grid import Grid
from pune_eo.io import write_cog
R = config.ROOT; OUT = Path(os.environ.get("PKG_OUT", "/mnt/user-data/outputs/phase2")); OUT.mkdir(parents=True, exist_ok=True)
EXP = R / "results" / "export"; EXP.mkdir(parents=True, exist_ok=True); MAXB = 24 * 2 ** 20
W = ["pune_G30_khadakwasla_mutha", "pune_G30_baramati_agri", "pune_G30_mulshi_ghats"]
def grid_of(gid):
    gj = json.loads(xr.open_zarr(R / "data/features/cube" / f"{gid}.zarr").attrs["grid"])
    return Grid(gid, gj["crs"], gj["res"], gj["x0"], gj["y1"], gj["width"], gj["height"], gj["corner_offset"])
# ---- exports
for gid in W:
    G = grid_of(gid); P = xr.open_zarr(R / "data/products/lulc_aoa" / f"{gid}.zarr"); yrs = [int(y) for y in P.year.values]; d = EXP / gid; d.mkdir(exist_ok=True)
    for var, name in (("hmm_aoa_label", "lulc_l1_hmm_aoa"), ("raw_label", "lulc_l1_raw")):
        write_cog(d / f"{name}_1990_2026.tif", P[var].values.astype(np.uint8), G, nodata=0, dtype="uint8", descriptions=[str(y) for y in yrs], overview_resampling="nearest",
                  tags={"classes": "1 built_up, 2 agriculture, 3 natural_vegetation, 4 water", "experiment": "EXP-LULC-T-002", "note": "agreement metrics in docs/phase2_results.md; not ground-truth accuracy"})
    write_cog(d / "inside_aoa_1990_2026.tif", P.inside_aoa.values.astype(np.uint8), G, nodata=None, dtype="uint8", descriptions=[str(y) for y in yrs], overview_resampling="nearest")
    t = np.load(R / "results/change_detection" / f"trajectories_{gid}.npz")
    write_cog(d / "trajectories.tif", np.stack([t["type"], t["first_change"], t["n_transitions"]]).astype(np.int16), G, nodata=None, dtype="int16",
              descriptions=["type_0insuff_1stable_2single_3multi_4cyclic", "first_change_year", "n_transitions"], overview_resampling="nearest")
# ---- zips
def zip_files(name, files, root=R, prefix="pune-eo-phd"):
    parts, cur, size = [], [], 0
    for f in files:
        s = f.stat().st_size
        if cur and size + s > MAXB: parts.append(cur); cur, size = [], 0
        cur.append(f); size += s
    if cur: parts.append(cur)
    outs = []
    for i, fs in enumerate(parts):
        z = OUT / (f"{name}.zip" if len(parts) == 1 else f"{name}_part{i + 1}.zip")
        with zipfile.ZipFile(z, "w", zipfile.ZIP_DEFLATED) as zf:
            for f in fs: zf.write(f, Path(prefix) / f.relative_to(root))
        outs.append(z)
    return outs
SKIP_DIRS = {".git", "__pycache__", ".pytest_cache", "ard_cache", "pune_eo.egg-info", "locks", ".venv", "export", "models"}
def core():
    (R / "results/provenance").mkdir(parents=True, exist_ok=True)
    (R / "results/provenance/git_log_phase2.txt").write_text(subprocess.run(["git", "-C", str(R), "log", "--date=iso", "--pretty=%h %ad %s"], capture_output=True, text=True).stdout)
    pat = R / "results/provenance/phase2_code_patches"; pat.mkdir(exist_ok=True)
    subprocess.run(["git", "-C", str(R), "format-patch", "-q", "-o", str(pat), "658e750..HEAD", "--", "src", "scripts", "configs", "tests", "docs", "README.md", ".gitignore"], check=False)
    fs = []
    for p in R.rglob("*"):
        if p.is_dir() or any(s in p.parts for s in SKIP_DIRS): continue
        rel = p.relative_to(R); top = rel.parts[0]
        if top == "data":
            if rel.parts[1] in ("composites", "raw", "features", "products", "_phase1_snapshot"): continue
            if rel.parts[1] == "labels" and (p.suffix == ".tif" or "chips" in rel.parts): continue
        if top == "results" and (p.suffix in (".tif", ".npz", ".pkl", ".parquet") or "figures" in rel.parts and "phase2" not in rel.parts): continue
        fs.append(p)
    return zip_files("phase2_core", sorted(fs))
outs = core()
for gid in W:
    fs = sorted((EXP / gid).glob("*.tif")) + [p for p in (R / "results/uncertainty").glob(f"*{gid}.tif")] + [p for p in (R / "results/flood").glob(f"*{gid}.tif")]
    outs += zip_files(f"phase2_maps_{gid.replace('pune_G30_', '')}", fs)
lab = sorted(p for gid in W for n in ("silver_l1", "silver_l2", "splits", "wsf_evolution_first_year", "jrc_gsw", "ghsl_built_fraction_90m") for p in (R / "data/labels" / gid).glob(f"{n}.tif"))
outs += zip_files("phase2_labels", lab)
for gid in W:
    outs += zip_files(f"phase2_gold_chips_{gid.replace('pune_G30_', '')}", sorted((R / "data/labels/gold" / gid / "chips").glob("*.png")))
big = [str(o) for o in outs if o.stat().st_size > 25 * 2 ** 20]
print(json.dumps({"archives": [(o.name, round(o.stat().st_size / 2 ** 20, 1)) for o in outs], "over_25MiB": big}, indent=1))
