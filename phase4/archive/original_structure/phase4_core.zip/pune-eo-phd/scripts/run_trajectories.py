"""Transition trajectories (registry EXP-TRJ-001) from the AOA-gated HMM product (EXP-LULC-T-002): taxonomy, timing, frequency,
persistence, period transition matrices (km2, cells inside AOA in both years), Gi* hotspots of conversion to built-up (1 km cells)."""
import json, sys
import numpy as np, xarray as xr
sys.path.insert(0, "src")
from pune_eo import config
from pune_eo.change_detection import trajectories as TR
from pune_eo.modelling.registry import Experiment
W = ["pune_G30_khadakwasla_mutha", "pune_G30_baramati_agri", "pune_G30_mulshi_ghats"]; NAMES = ["built_up", "agriculture", "natural_vegetation", "water"]
e = Experiment(experiment_id="EXP-TRJ-001", research_question="RQ-TRJ: What trajectory types dominate each landscape, when did changes happen and where are conversion hotspots?",
               hypothesis="corridor: single agri/natveg->built transitions concentrated 2000-2015 at the urban edge; Mulshi: cyclic water<->vegetation (reservoir drawdown)",
               dataset_version="EXP-LULC-T-002", years=list(range(1990, 2027)), resolution_m=30, features="n/a", labels="n/a", split="n/a (descriptive)",
               model="trajectory taxonomy + Getis-Ord Gi*", hyperparameters={"min_valid_years": 10, "hotspot_cell_km": 0.9}, seed=0)
res = {}; out = config.path("results/change_detection"); out.mkdir(parents=True, exist_ok=True)
for gid in W:
    P = xr.open_zarr(config.path("data/products/lulc_aoa", f"{gid}.zarr")); yrs = P.year.values
    lab = P.hmm_aoa_label.values; ins = P.inside_aoa.values; T_, H, Wd = lab.shape
    r = TR.taxonomy(lab.reshape(T_, -1), ins.reshape(T_, -1), yrs)
    typ = r["type"]; cnt = {TR.TYPES[k]: float((typ == k).mean()) for k in TR.TYPES}
    fc = r["first_change"][typ >= 2]; hist = {int(y): int((fc == y).sum()) for y in np.unique(fc)} if fc.size else {}
    mats = {}
    for a, b in ((1990, 2000), (2000, 2010), (2010, 2020), (2020, 2026)):
        ia, ib = list(yrs).index(a), list(yrs).index(b); v = ins[ia] & ins[ib]
        mats[f"{a}-{b}"] = {"km2": np.round(TR.transition_matrix(lab[ia], lab[ib], v), 3).tolist(), "valid_share": float(v.mean())}
    i0, i1 = list(yrs).index(2000), list(yrs).index(2020); conv = (lab[i1] == 1) & (lab[i0] != 1) & ins[i0] & ins[i1]; vv = ins[i0] & ins[i1]
    k = 30; Hk, Wk = H // k * k, Wd // k * k
    share = np.where(vv[:Hk, :Wk].reshape(Hk // k, k, Wk // k, k).sum((1, 3)) > k * k / 2,
                     conv[:Hk, :Wk].reshape(Hk // k, k, Wk // k, k).sum((1, 3)) / np.maximum(vv[:Hk, :Wk].reshape(Hk // k, k, Wk // k, k).sum((1, 3)), 1), np.nan)
    z = TR.getis_ord(share)
    res[gid] = {"type_share": cnt, "first_change_year_hist": hist, "transition_matrices": mats, "class_order": NAMES,
                "hotspots_2000_2020": {"n_cells": int(np.isfinite(z).sum()), "n_hot_z_gt_1.96": int((z > 1.96).sum()), "n_cold_z_lt_-1.96": int((z < -1.96).sum()),
                                        "max_conversion_share": float(np.nanmax(share)) if np.isfinite(share).any() else None},
                "mean_transitions_changed_pixels": float(r["n_transitions"][typ >= 2].mean()) if (typ >= 2).any() else 0.0}
    np.savez_compressed(out / f"trajectories_{gid}.npz", type=typ.reshape(H, Wd), first_change=r["first_change"].reshape(H, Wd), n_transitions=r["n_transitions"].reshape(H, Wd),
                        persistence=r["persistence"].reshape(H, Wd), gi_star=z, conversion_share_1km=share)
    print(gid, json.dumps({"types": {k: round(v, 3) for k, v in cnt.items()}, "hot": res[gid]["hotspots_2000_2020"]}), flush=True)
json.dump(res, open(out / "trajectories_summary.json", "w"), indent=1)
e.finish(res, result="see results/change_detection/trajectories_summary.json", outputs={"rasters": "results/change_detection/trajectories_<grid>.npz"})
