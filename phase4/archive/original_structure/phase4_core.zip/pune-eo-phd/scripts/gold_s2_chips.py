"""Sentinel-2 10 m context chips for the 2021 epoch of the BLIND gold kit (anonymous IDs, no stratum/model output).
Per window: up to 5 lowest-cloud scenes in the dry season (Jan-Apr 2021) and post-monsoon (Oct-Dec 2021) on the native G10 lattice
(SCL reader v2), per-pixel median of clear observations. Chips 1.2 km x 1.2 km, the 30 m cell (3x3 px) outlined.
Also writes contact sheets (6 points per sheet, randomised order) used for the provisional AI interpretation (Tier C) and a
separately randomised repeat-pass set (15 %) for self-consistency."""
import sys, json, warnings
import numpy as np, pandas as pd, geopandas as gpd
import matplotlib; matplotlib.use("Agg"); import matplotlib.pyplot as plt
from matplotlib.patches import Rectangle
sys.path.insert(0, "src"); warnings.filterwarnings("ignore")
from pune_eo import config
from pune_eo.compositing import observations as obs
from pune_eo.compositing.windows import resolve
from pune_eo.provenance import utcnow
OUT = config.path("data/labels/gold/blind/chips_s2_2021"); SHEETS = config.path("data/labels/gold/blind/sheets_s2_2021"); OUT.mkdir(parents=True, exist_ok=True); SHEETS.mkdir(parents=True, exist_ok=True)
KEY = pd.read_csv(config.path("data/labels/gold/_key/gold_key.csv")); FORM = pd.read_csv(config.path("data/labels/gold/blind/gold_blind_form_interpreter1.csv"))
M = gpd.read_parquet(config.path("data/manifests/sentinel2_manifest.parquet")); M = M[M.selected]
BANDS = ["blue", "green", "red", "nir"]; SB = list(config.load("sentinel2")["bands"]); HALF = 60   # 121 px = 1.21 km
meta = {}
def season_composite(g, win, months):
    from pune_eo.acquisition.boundary import load_study_area
    sub = g.subgrid(win); x0, y0, x1, y1 = sub.bounds
    from pyproj import Transformer
    t = Transformer.from_crs(g.crs, 4326, always_xy=True); lo0, la0 = t.transform(x0, y0); lo1, la1 = t.transform(x1, y1)
    cand = M[(M.year == 2021) & M.month.isin(months)].copy()
    cand = cand[cand.geometry.intersects(__import__("shapely.geometry", fromlist=["box"]).box(lo0, la0, lo1, la1))].sort_values("cloud_cover")
    vals, used = [], []
    for _, r in cand.iterrows():
        if len(used) >= 5: break
        try: o = obs.sentinel2(r.to_dict(), g, win)
        except Exception: continue
        if o is None: continue
        v = np.full((4, int(win.height), int(win.width)), np.nan, np.float32)
        c0, r0 = int(o["win"].col_off - win.col_off), int(o["win"].row_off - win.row_off); h, w = o["values"].shape[1:]
        v[:, r0:r0 + h, c0:c0 + w] = o["values"][[SB.index(b) for b in BANDS]]
        if np.isfinite(v[0]).mean() < 0.2: continue
        vals.append(v); used.append({"item": r["product_id"], "date": str(r["date"]), "cloud": float(r["cloud_cover"]), "clear_frac": float(np.isfinite(v[0]).mean())})
    return (np.nanmedian(np.stack(vals), 0) if vals else None), used
def stretch(rgb, lo, hi): return np.clip((rgb - lo) / (hi - lo), 0, 1)
chips = {}
for w in ["khadakwasla_mutha", "baramati_agri", "mulshi_ghats"]:
    g, win, wn = resolve("G10", w); sub = g.subgrid(win)
    cache = config.path("data/labels/gold/blind/_s2_cache", f"{w}.npz"); cache.parent.mkdir(parents=True, exist_ok=True)
    if cache.exists():
        z = np.load(cache, allow_pickle=True); dry, post = z["dry"], z["post"]; ud, up = list(z["ud"]), list(z["up"])
    else:
        dry, ud = season_composite(g, win, [1, 2, 3, 4]); post, up = season_composite(g, win, [10, 11, 12])
        np.savez_compressed(cache, dry=dry.astype(np.float32), post=post.astype(np.float32), ud=np.array(ud, dtype=object), up=np.array(up, dtype=object))
    meta[w] = {"dry_scenes": [dict(x) for x in ud], "post_scenes": [dict(x) for x in up]}
    pts = KEY[KEY.window == f"pune_G30_{w}"]
    for _, p in pts.iterrows():
        col = int((p.x_utm - sub.x0) / 10); row = int((sub.y1 - p.y_utm) / 10)
        panels = []
        for comp, kind in ((dry, "dry"), (post, "post")):
            if comp is None: panels.append(None); continue
            a = np.full((4, 2 * HALF + 1, 2 * HALF + 1), np.nan, np.float32); r0, c0 = row - HALF, col - HALF
            ys, xs = slice(max(r0, 0), min(r0 + 2 * HALF + 1, comp.shape[1])), slice(max(c0, 0), min(c0 + 2 * HALF + 1, comp.shape[2]))
            a[:, ys.start - r0:ys.stop - r0, xs.start - c0:xs.stop - c0] = comp[:, ys, xs]; panels.append(a)
        chips[p.anon_id] = panels
    print(w, "dry scenes", len(ud), "post scenes", len(up), flush=True)
def draw(ax, a, kind, mode, zoom=False):
    if a is None: ax.text(0.5, 0.5, "no clear S2", ha="center"); ax.set_xticks([]); ax.set_yticks([]); return
    if zoom:
        z = 16; b, g_, r, n = a[:, HALF - z:HALF + z + 1, HALF - z:HALF + z + 1]
        img = stretch(np.stack([r, g_, b], -1), 0.02, 0.25) if mode == "rgb" else stretch(np.stack([n, r, g_], -1), 0.02, 0.45)
        ax.imshow(np.nan_to_num(img), interpolation="nearest"); ax.add_patch(Rectangle((z - 1.5, z - 1.5), 3, 3, fill=False, ec="yellow", lw=1.4))
        ax.set_xticks([]); ax.set_yticks([]); return
    b, g_, r, n = a
    img = stretch(np.stack([r, g_, b], -1), 0.02, 0.25) if mode == "rgb" else stretch(np.stack([n, r, g_], -1), 0.02, 0.45)
    ax.imshow(np.nan_to_num(img), interpolation="nearest"); ax.add_patch(Rectangle((HALF - 1.5, HALF - 1.5), 3, 3, fill=False, ec="yellow", lw=1.0))
    ax.add_patch(Rectangle((HALF - 16.5, HALF - 16.5), 33, 33, fill=False, ec="cyan", lw=0.5, ls=":")); ax.set_xticks([]); ax.set_yticks([])
for aid, pan in chips.items():
    fig, ax = plt.subplots(1, 3, figsize=(9, 3.2))
    draw(ax[0], pan[0], "dry", "rgb"); draw(ax[1], pan[0], "dry", "fcc"); draw(ax[2], pan[1], "post", "fcc")
    for a_, t in zip(ax, ("dry 2021 true colour", "dry 2021 NIR-R-G", "post-monsoon 2021 NIR-R-G")): a_.set_title(t, fontsize=7)
    fig.suptitle(f"{aid}  Sentinel-2 L2A 10 m, 1.2 km; yellow = 30 m cell; cyan = 330 m context", fontsize=7)
    fig.savefig(OUT / f"{aid}.png", dpi=100, bbox_inches="tight"); plt.close(fig)
def sheets(ids, tag):
    for s in range(0, len(ids), 5):
        grp = ids[s:s + 5]; fig, ax = plt.subplots(len(grp), 4, figsize=(10, 2.5 * len(grp)))
        ax = np.atleast_2d(ax)
        for i, aid in enumerate(grp):
            pan = chips[aid]; draw(ax[i, 0], pan[0], "dry", "rgb"); draw(ax[i, 1], pan[0], "dry", "rgb", True); draw(ax[i, 2], pan[0], "dry", "fcc", True); draw(ax[i, 3], pan[1], "post", "fcc", True)
            ax[i, 0].set_ylabel(aid, fontsize=11, fontweight="bold")
        for a_, t in zip(ax[0], ("dry 2021 true colour, 1.2 km", "dry true colour, 330 m", "dry NIR-R-G, 330 m", "post-monsoon NIR-R-G, 330 m")): a_.set_title(t, fontsize=8)
        fig.tight_layout(); fig.savefig(SHEETS / f"{tag}_{s // 5 + 1:03d}.png", dpi=95); plt.close(fig)
ids = list(FORM.anon_id); sheets(ids, "pass1")
rep = list(np.random.default_rng(20261022).choice(ids, int(round(0.15 * len(ids))), replace=False)); sheets(rep, "pass2")
json.dump({"created_utc": utcnow(), "scenes": meta, "n_chips": len(chips), "pass1_sheets": (len(ids) + 4) // 5, "pass2_ids": rep, "pass2_sheets": (len(rep) + 4) // 5},
          open(config.path("data/labels/gold/blind/s2_chips_2021.json"), "w"), indent=1)
print(len(chips), "chips;", (len(ids) + 4) // 5, "pass-1 sheets;", (len(rep) + 4) // 5, "pass-2 sheets")
