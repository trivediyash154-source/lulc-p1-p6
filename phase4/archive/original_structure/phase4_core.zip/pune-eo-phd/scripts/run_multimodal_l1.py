"""Multimodal ablation for L1 (registry EXP-MM-{fs}-{split}): Landsat+terrain vs +S1 vs +S2 red-edge vs +S1+S2, year 2021, XGBoost.
Within-window 3 km blocks AND leave-one-window-out. Requires cubes rebuilt with Sentinel layers (scripts/build_cubes.py)."""
import json, sys, warnings
import numpy as np, pandas as pd
sys.path.insert(0, "src"); warnings.filterwarnings("ignore")
from pune_eo import config
from pune_eo.classification import baseline as B
from pune_eo.modelling.registry import Experiment
W = ["khadakwasla_mutha", "baramati_agri", "mulshi_ghats"]; SEED = 20261013
LT = json.load(open(config.path("results/classification/feature_pruning.json")))["kept"]
S1 = ["s1_vv_dry", "s1_vh_dry", "s1_vh_wet", "s1_ratio", "s1_vv_min", "s1_vh_sd"]; S2 = ["s2_ndre_post"]
FS = {"landsat_terrain": LT, "+s1": LT + S1, "+s2re": LT + S2, "+s1+s2re": LT + S1 + S2}
df = B.samples(W, 2021, LT + S1 + S2, cap={1: 4000, 2: 4000, 3: 20000}, seed=SEED)
cov = {f: float(df[f].notna().mean()) for f in S1 + S2}; print("sentinel feature coverage", cov, flush=True)
rows = []
for fs, feats in FS.items():
    for split in ["blocks"] + [f"lowo_{w}" for w in W]:
        if split == "blocks": tr, va, te = df[df.split == 1], df[df.split == 2], df[df.split == 3]
        else:
            h = B.window_grid_id(split[5:]); tr, va, te = df[(df.window != h) & (df.split == 1)], df[(df.window != h) & (df.split == 2)], df[df.window == h]
        e = Experiment(experiment_id=f"EXP-MM-{fs.replace('+', 'p')}-{split}", research_question="RQ-MM: Do Sentinel-1 and Sentinel-2 red-edge add information to Landsat+terrain for L1 (2021), within and across landscapes?",
                       hypothesis="S1 helps agriculture vs natural vegetation (monsoon structure) and transfers better across landscapes", dataset_version="cube G30 incl. sentinel layers 2021",
                       years=[2021], resolution_m=30, features=feats, labels="silver_l1", split=split, model="xgb", hyperparameters={}, seed=SEED, sentinel_coverage=cov)
        m = B.make_model("xgb", SEED); B.fit("xgb", m, tr[feats], tr.label.values, va[feats], va.label.values); mt = B.evaluate(te.label.values, B.predict("xgb", m, te[feats]))
        e.finish({"test": mt}, result=f"macro-F1 {mt['macro_f1']:.3f}", n_samples={"train": len(tr), "val": len(va), "test": len(te)})
        rows.append({"features": fs, "split": split, "macro_f1": mt["macro_f1"], **{f"f1_{k}": v["f1"] for k, v in mt["per_class"].items()}}); print(json.dumps(rows[-1]), flush=True)
pd.DataFrame(rows).to_csv(config.path("results/classification/multimodal_ablation.csv"), index=False)
