"""P4-X3 (EXPLORATORY): where do existing products disagree? Replaces the circular P4-X1 'by validation stratum' summary (strata were built from the same consensus).
No-consensus share (GLC_FCS30D vs Esri vs WorldCover, L1, 2020) by descriptors that are NOT derived from the consensus: rainfall zone, slope class, distance to water, settlement history (WSF)."""
import json, os, sys, tempfile, warnings
import numpy as np, rasterio
from rasterio.enums import Resampling
from scipy.ndimage import distance_transform_edt
sys.path.insert(0, "src"); warnings.filterwarnings("ignore")
from pune_eo import config
from pune_eo.grid import district_grid
from pune_eo.labels import sources as SRC
from pune_eo.evaluation4 import protocol as P4
G = district_grid("G30"); PX = config.path("data/products_ext"); LB = config.path("data/labels/pune_G30"); OUT = config.path("results/phase4/benchmark")
if P4.load("P4-X3") is None:
    P4.register(experiment_id="P4-X3", kind="exploratory", family="benchmark", hypothesis="product disagreement varies with landscape descriptors independent of the consensus itself (rainfall zone, slope, distance to water, settlement history)",
                comparator="district-wide no-consensus share", primary_metric="no-consensus share by descriptor class", direction="descriptive", threshold="none (exploratory)", dataset_version="data/products_ext v1", evaluation_set="district",
                region="Pune District", years="2020", features="-", labels="none", label_tier="B/C", model="none", seeds=[], splits="none", metrics_planned=["share without full L1 consensus by class of each descriptor"])
run = P4.Run("P4-X3")
def rd(p, b=1):
    with rasterio.open(p) as s: return s.read(b)
mask = rd(PX / "district/district_mask_30m.tif").astype(bool); cons = rd(OUT / "l1_consensus_2020_30m.tif"); nocons = cons > 1
dem = rd(PX / "dem/copdem30_district_30m.tif").astype(np.float32); dem[dem == -9999] = np.nan
gy, gx = np.gradient(np.nan_to_num(dem, nan=float(np.nanmedian(dem))), 30.0); slope = np.degrees(np.arctan(np.hypot(gx, gy))).astype(np.float32); del gx, gy
with rasterio.open(config.path("data/processed/climate/chirps_v2_monthly_stack.tif")) as s:
    idx = [i + 1 for i, d in enumerate(s.descriptions) if d and 1991 <= int(d[:4]) <= 2020]; tot = sum(np.nan_to_num(s.read(i).astype(float)) for i in idx) / 30.0; prof = s.profile
tmp = tempfile.NamedTemporaryFile(suffix=".tif", delete=False).name; prof.update(count=1, dtype="float32", nodata=-1)
with rasterio.open(tmp, "w", **prof) as d: d.write(tot.astype(np.float32), 1)
rain = SRC._warp(tmp, G, Resampling.bilinear, dst_nodata=-1, dtype="float32", sign=False); os.unlink(tmp)
jrc = rd(LB / "jrc_gsw.tif").astype(float); jrc[jrc == 255] = 0; dwat = distance_transform_edt(~(jrc >= 25)) * 30; wsf = rd(LB / "wsf_evolution_first_year.tif")
desc = {"rainfall_zone": {"wet_west_ge1200": rain >= 1200, "transition_700_1200": (rain >= 700) & (rain < 1200), "dry_east_lt700": rain < 700},
        "slope": {"lt3deg": slope < 3, "3_8deg": (slope >= 3) & (slope < 8), "ge8deg": slope >= 8},
        "distance_to_water": {"le300m": dwat <= 300, "300m_1km": (dwat > 300) & (dwat <= 1000), "gt1km": dwat > 1000},
        "settlement_wsf": {"settled_by_2000": (wsf > 0) & (wsf <= 2000), "settled_2001_2015": (wsf >= 2001) & (wsf <= 2015), "never_settled": wsf == 0}}
R = {"district_no_consensus_share": float(nocons[mask].mean()), "by_descriptor": {k: {c: {"share": float(nocons[m & mask].mean()), "area_share": float((m & mask).sum() / mask.sum())} for c, m in v.items()} for k, v in desc.items()}}
json.dump(R, open(OUT / "disagreement_by_descriptor.json", "w"), indent=1)
run.complete(R, "NA", f"district no-consensus {R['district_no_consensus_share']:.2f}; " + "; ".join(f"{k}: " + ", ".join(f"{c} {v['share']:.2f}" for c, v in d.items()) for k, d in R["by_descriptor"].items()),
             outputs={"summary": "results/phase4/benchmark/disagreement_by_descriptor.json"})
print(json.dumps(R, indent=1))
