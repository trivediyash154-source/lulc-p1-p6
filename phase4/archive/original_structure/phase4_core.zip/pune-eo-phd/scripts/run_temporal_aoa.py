"""Temporal LULC with an area-of-applicability gate (registry EXP-LULC-T-002).
  1. classifier = variant selected on VAL blocks by the pre-declared criterion (results/temporal/remedy_selection.json)
  2. AOA (Meyer & Pebesma 2021) from the training feature matrix, importance-weighted, spatial-block folds
  3. per pixel-year: posterior + DI; outside AOA or no observation -> uninformative HMM emission (state bridged from in-AOA years)
  4. evaluation on TEST blocks vs WSF / GHSL (same metrics as the selection), for raw, raw-inside-AOA and AOA-gated HMM
Outputs data/products/lulc_aoa/<grid>.zarr, results/temporal/eval_temporal_aoa.json"""
import json, sys, time, warnings, hashlib
import numpy as np, pandas as pd, rasterio, xarray as xr
from scipy.stats import pearsonr
sys.path.insert(0, "src"); warnings.filterwarnings("ignore")
from pune_eo import config
from pune_eo.classification import baseline as B, temporal as H
from pune_eo.change_detection import changepoints as C
from pune_eo.labels.splits import block_index
from pune_eo.uncertainty.aoa import AOA
from pune_eo.modelling.registry import Experiment
W = ["pune_G30_khadakwasla_mutha", "pune_G30_baramati_agri", "pune_G30_mulshi_ghats"]; SEED = 20261008; YEARS = list(range(1990, 2027)); i21 = YEARS.index(2021)
feats = json.load(open(config.path("results/classification/feature_pruning.json")))["kept"]
sel = json.load(open(config.path("results/temporal/remedy_selection.json"))); VARIANT = sel["selected"]
COEF = {tuple(k.split("|")): v for k, v in json.load(open(config.path("results/temporal/pif_normalisation.json"))).items()}   # (year, feature) -> (slope, icpt)
NORM = ["dry_blue", "dry_green", "dry_red", "dry_nir", "dry_swir1", "dry_swir2", "post_ndvi", "post_mndwi", "post_ndmi"]
def _nd(a, b):
    with np.errstate(all="ignore"): return (a - b) / (a + b)
def normalise(L, fl, y):
    """R2: PIF relative radiometric normalisation to 2021 (coefficients fitted in run_temporal_remedies.py), indices recomputed."""
    L = L.copy()
    for f in NORM: sl, ic = COEF[(str(y), f)]; L[fl.index(f)] = sl * L[fl.index(f)] + ic
    g_ = lambda k: L[fl.index(k)]
    L[fl.index("dry_ndvi")] = _nd(g_("dry_nir"), g_("dry_red")); L[fl.index("dry_mndwi")] = _nd(g_("dry_green"), g_("dry_swir1"))
    L[fl.index("dry_ndmi")] = _nd(g_("dry_nir"), g_("dry_swir1")); L[fl.index("dry_nbr")] = _nd(g_("dry_nir"), g_("dry_swir2"))
    L[fl.index("d_ndvi")] = g_("post_ndvi") - g_("dry_ndvi"); L[fl.index("d_mndwi")] = g_("post_mndwi") - g_("dry_mndwi")
    L[fl.index("sd_ndvi_5")] *= COEF[(str(y), "dry_nir")][0]; L[fl.index("sd_nir_5")] *= COEF[(str(y), "dry_nir")][0]
    L[~np.isfinite(L)] = np.nan; return L
def rd(p, b=1):
    with rasterio.open(p) as s: return s.read(b)
e = Experiment(experiment_id="EXP-LULC-T-002", research_question="RQ-T3: Is the historical reconstruction defensible inside the area of applicability, and does an AOA-gated HMM recover it?",
               hypothesis="early-year built-up over-prediction is concentrated outside the AOA; AOA-gated HMM agrees better with WSF/GHSL than raw maps",
               dataset_version="cube G30 local_pune_g30_v2; labels silver v1", years=YEARS, resolution_m=30, features=feats,
               labels=f"silver_l1 ({VARIANT})", split="train blocks fit + AOA reference; val early stopping; TEST blocks for all reported metrics",
               model="XGBoost + AOA (Meyer & Pebesma 2021) + AOA-gated 4-state HMM", hyperparameters={"variant": VARIANT}, seed=SEED)
rng = np.random.default_rng(SEED); D = {}
for gid in W:
    ds = B.open_cube(gid); d = config.path("data/labels", gid)
    D[gid] = {"ds": ds, "fl": list(ds.feature.values), "tf": list(ds.tfeature.values), "T": ds.terrain.values, "sil": rd(d / "silver_l1.tif"),
              "sp": rd(d / "splits.tif"), "wsf": rd(d / "wsf_evolution_first_year.tif"), "gh": rd(d / "ghsl_built_fraction_90m.tif", None) if False else None}
    with rasterio.open(d / "ghsl_built_fraction_90m.tif") as s: gh = s.read().astype(float)
    gh[gh < 0] = np.nan; D[gid]["gh"] = gh
    gj = json.loads(ds.attrs["grid"]); from pune_eo.grid import Grid
    G = Grid(gid, gj["crs"], gj["res"], gj["x0"], gj["y1"], gj["width"], gj["height"], gj["corner_offset"]); bx, by = block_index(G, 3000)
    D[gid]["fold"] = np.vectorize(lambda a, b: int(hashlib.sha256(f"{a}:{b}:fold".encode()).hexdigest(), 16) % 5)(bx, by)
def Ly(g, i):
    L = g["ds"].landsat.isel(year=i).values
    return normalise(L, g["fl"], YEARS[i]) if "R2" in VARIANT else L
def X_of(g, L, r, c): return np.stack([L[g["fl"].index(f), r, c] if f in g["fl"] else g["T"][g["tf"].index(f), r, c] for f in feats], 1)
# ---- training matrix (base or R1): sample cells per class, then ONE pass over years per window
Xs, ys, fs = [], [], []
for gid, g in D.items():
    picks = []
    for c_ in B.CLASSES:
        r, c = np.nonzero((g["sp"] == 1) & (g["sil"] == c_))
        if r.size == 0: continue
        k = rng.choice(r.size, min(1500 if "R1" in VARIANT else 4000, r.size), replace=False); picks.append((c_, r[k], c[k]))
    if "R1" not in VARIANT:
        L21 = Ly(g, i21)
        for c_, r, c in picks: Xs.append(X_of(g, L21, r, c)); ys.append(np.full(r.size, c_)); fs.append(g["fold"][r, c])
        continue
    R = np.concatenate([p[1] for p in picks]); Cc = np.concatenate([p[2] for p in picks]); Y = np.concatenate([np.full(p[1].size, p[0]) for p in picks])
    Xall = np.stack([X_of(g, Ly(g, i), R, Cc) for i in range(len(YEARS))])            # (T, n, F); one year slice in memory at a time
    lo = np.full(R.size, 1990)
    for f in ("post_ndvi", "dry_ndvi"):
        S = Xall[:, :, feats.index(f)] if f in feats else None
        if S is None: continue
        for j in range(R.size):
            for yr, mag in (C.detect(np.array(YEARS), S[:, j], "pelt_mean") or []):
                if yr <= 2020 and abs(mag) >= 0.05: lo[j] = max(lo[j], yr)
    for yi, y in enumerate(YEARS):
        m_ = lo <= y
        if m_.any(): Xs.append(Xall[yi, m_]); ys.append(Y[m_]); fs.append(g["fold"][R[m_], Cc[m_]])
Xtr, ytr, ftr = np.concatenate(Xs), np.concatenate(ys), np.concatenate(fs)
Xva, yva = [], []
for gid, g in D.items():
    r, c = np.nonzero((g["sp"] == 2) & np.isin(g["sil"], B.CLASSES)); k = rng.choice(r.size, min(8000, r.size), replace=False)
    Xva.append(X_of(g, Ly(g, i21), r[k], c[k])); yva.append(g["sil"][r[k], c[k]])
Xva, yva = np.concatenate(Xva), np.concatenate(yva)
m = B.make_model("xgb", SEED); B.fit("xgb", m, Xtr, ytr, Xva, yva)
imp = m.get_booster().get_score(importance_type="gain"); wts = np.array([imp.get(f"f{i}", 0.0) for i in range(len(feats))]) + 1e-6
aoa = AOA(Xtr, wts, ftr, seed=SEED); print("AOA threshold", round(aoa.threshold, 3), "n_train", len(ytr), flush=True)
prior = np.array([(ytr == c).mean() for c in B.CLASSES])
# ---- per window: posteriors + DI for all cells of all years (DI on a 1-in-2 grid subsample for speed, then nearest fill)
out = config.path("data/products/lulc_aoa"); out.mkdir(parents=True, exist_ok=True); prods = {}
for gid, g in D.items():
    Hh, Ww = g["sil"].shape; N = Hh * Ww; P = np.zeros((len(YEARS), 4, N), np.float32); DI = np.zeros((len(YEARS), N), np.float32); V = np.zeros((len(YEARS), N), bool)
    rr, cc = np.divmod(np.arange(N), Ww)
    for i in range(len(YEARS)):
        L = Ly(g, i); X = X_of(g, L, rr, cc); V[i] = np.isfinite(X[:, feats.index("dry_red")]); P[i] = m.predict_proba(X).T
        sub = (rr % 2 == 0) & (cc % 2 == 0); d_ = np.full((Hh, Ww), np.nan, np.float32); d_[rr[sub], cc[sub]] = aoa.di(X[sub])
        d_ = np.where(np.isnan(d_), np.repeat(np.repeat(d_[::2, ::2], 2, 0), 2, 1)[:Hh, :Ww], d_); DI[i] = d_.ravel()
    inside = (DI <= aoa.threshold) & V
    raw = P.argmax(1).astype(np.int8)
    # HMM with AOA-gated emissions; A from train-block pixels
    prods[gid] = {"P": P, "inside": inside, "raw": raw, "V": V, "shape": (Hh, Ww)}
    print(gid, "posteriors+DI", {y: round(float(inside[YEARS.index(y)].mean()), 3) for y in (1990, 2000, 2010, 2021)}, flush=True)
E_fit = []
for gid, p in prods.items():
    idx = np.flatnonzero(D[gid]["sp"].ravel() == 1); idx = rng.choice(idx, min(15000, idx.size), replace=False)
    E_fit.append(H.emissions(p["P"][:, :, idx], prior, p["inside"][:, idx]))
A, p0, hist = H.baum_welch(np.concatenate(E_fit, 2), 4, iters=40); print("A diag", np.round(np.diag(A), 4), flush=True)
res = {"aoa_threshold": aoa.threshold, "transition_matrix": np.round(A, 5).tolist(), "variant": VARIANT, "windows": {}}
for gid, p in prods.items():
    g = D[gid]; Hh, Ww = p["shape"]; N = Hh * Ww; E = H.emissions(p["P"], prior, p["inside"]); vit = np.empty((len(YEARS), N), np.int8)
    for c0 in range(0, N, 40000): sl = slice(c0, min(c0 + 40000, N)); vit[:, sl] = H.viterbi(E[:, :, sl], A, p0)
    labs = {"raw": p["raw"] + 1, "hmm_aoa": vit + 1}
    xr.Dataset({"raw_label": (("year", "y", "x"), labs["raw"].reshape(-1, Hh, Ww).astype(np.int8)), "hmm_aoa_label": (("year", "y", "x"), labs["hmm_aoa"].reshape(-1, Hh, Ww).astype(np.int8)),
                "inside_aoa": (("year", "y", "x"), p["inside"].reshape(-1, Hh, Ww)), "raw_prob": (("year", "class", "y", "x"), np.round(p["P"] * 250).astype(np.uint8).reshape(len(YEARS), 4, Hh, Ww))},
               coords={"year": YEARS, "class": [B.CLASS_NAMES[c] for c in B.CLASSES], "y": g["ds"].y.values, "x": g["ds"].x.values},
               attrs={"experiment": "EXP-LULC-T-002", "variant": VARIANT, "aoa_threshold": aoa.threshold, "labels": "1 built,2 agri,3 natveg,4 water"}).to_zarr(out / f"{gid}.zarr", mode="w")
    ts = g["sp"].ravel() == 3; r_ = {"aoa_share_by_year_all": {y: float(p["inside"][i].mean()) for i, y in enumerate(YEARS)}}
    wsf = g["wsf"].ravel()
    for name, lab in (("raw", labs["raw"]), ("raw_inside_aoa", np.where(p["inside"], labs["raw"], 0)), ("hmm_aoa", labs["hmm_aoa"])):
        ep = {}
        for y in (1990, 2000, 2010, 2015):
            i = YEARS.index(y); ref = (wsf > 0) & (wsf <= y); evm = ts & (p["inside"][i] if name == "raw_inside_aoa" else True)
            mp = lab[i] == 1; tp = (ref & mp & evm).sum()
            ep[y] = {"built_share": float(mp[evm].mean()) if evm.any() else None, "wsf_share": float(ref[evm].mean()) if evm.any() else None,
                     "wsf_f1": float(2 * tp / max((ref & evm).sum() + (mp & evm).sum(), 1)), "n": int(evm.sum())}
        h3, w3 = g["gh"].shape[1:]; s3 = (g["sp"] == 3)[:h3 * 3, :w3 * 3].reshape(h3, 3, w3, 3).all(axis=(1, 3)); ghr = {}
        for k_, y in enumerate((1990, 1995, 2000, 2005, 2010, 2015, 2020)):
            L2 = lab[YEARS.index(y)].reshape(Hh, Ww); bf = (L2[:h3 * 3, :w3 * 3] == 1).reshape(h3, 3, w3, 3).mean(axis=(1, 3)); gg = g["gh"][k_]; f = s3 & np.isfinite(gg)
            if name == "raw_inside_aoa": f &= p["inside"][YEARS.index(y)].reshape(Hh, Ww)[:h3 * 3, :w3 * 3].reshape(h3, 3, w3, 3).all(axis=(1, 3))
            ghr[y] = float(pearsonr(bf[f], gg[f])[0]) if f.sum() > 30 and gg[f].std() > 0 else None
        r_[name] = {"wsf": ep, "ghsl_r": ghr, "mae_built_vs_wsf": float(np.mean([abs(v["built_share"] - v["wsf_share"]) for v in ep.values() if v["built_share"] is not None]))}
    res["windows"][gid] = r_; print(gid, json.dumps({k: (v["mae_built_vs_wsf"], v["wsf"][1990]["built_share"], v["wsf"][1990]["wsf_share"]) for k, v in r_.items() if k != "aoa_share_by_year_all"}), flush=True)
json.dump(res, open(config.path("results/temporal/eval_temporal_aoa.json"), "w"), indent=1, default=str)
e.finish(res, result="see results/temporal/eval_temporal_aoa.json", outputs={"products": "data/products/lulc_aoa/<grid>.zarr"}, n_samples={"train_rows": int(len(ytr))})
