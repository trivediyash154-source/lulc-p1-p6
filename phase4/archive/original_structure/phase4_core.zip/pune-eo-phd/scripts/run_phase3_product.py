"""Phase-3 group O — multi-criteria model selection, era-aware probabilistic reconstruction (P3-O1), error taxonomy (P3-O2),
district scaling decision (P3-O3) and Gate 6.
Selection follows configs/phase3.yaml:model_selection (declared before the C/E/H/F/G results were seen).
Product (benchmark windows only, every year 1990-2026, 30 m): uint8 bands
  1-4 class probabilities x 200 (temperature-calibrated on 2021 val blocks) | 5 most likely class | 6 normalised entropy x 200 |
  7 observation quality = n clear dry + post-monsoon Landsat observations (clipped 0-60) | 8 P(class differs from previous year) x 200
  tags: era, model, calibration, 'NOT VALIDATED BY TIER A - research product'.
Gate 6 = G1 AND built-vs-WSF MAE <= 0.10 (3 km TEST blocks, every window x era with WSF coverage) AND dry-year FBR <= 0.10."""
import json, sys, time, warnings
import numpy as np, pandas as pd, rasterio, xarray as xr
from rasterio.transform import from_origin
sys.path.insert(0, "src"); warnings.filterwarnings("ignore")
from sklearn.ensemble import RandomForestClassifier
from pune_eo import config
from pune_eo.historical_reconstruction import het, features as F
from pune_eo.calibration import metrics as CM
from pune_eo.validation import registry3 as R3
H = het.load(); M = H["meta"]; YEARS = np.array(H["info"]["years"]); CL = H["climate"]; SEED = 20261104
OUT = config.path("results/phase3/product"); OUT.mkdir(parents=True, exist_ok=True); TD = config.path("results/phase3/temporal")
ERAS = {"early_historical": (1990, 1998), "landsat_dominant": (1999, 2014), "sentinel_dense": (2015, 2021), "current": (2022, 2026)}
era_of = lambda y: next(e for e, (a, b) in ERAS.items() if a <= y <= b)
ev = np.load(TD / "eval_cells.npy"); mm = M.iloc[ev].reset_index(drop=True); WIN = sorted(M.window.unique())
def dry_cells(P, kind):
    out = np.full(len(ev), np.nan)
    for g in WIN:
        k = CL[CL.window == g].set_index("year").climate_class.reindex(YEARS).values == "dry"; w = (mm.window == g).values & mm[kind].values
        if k.any(): out[w] = (P[w][:, k] == 1).mean(1)
    return out
# ---------------- 1. criteria table
cand = {p.stem[5:]: np.load(p) for p in sorted(TD.glob("pred_P3-B*.npy"))}
cand.update({p.stem[5:]: np.load(p) for p in sorted(config.path("results/phase3/deep_temporal").glob("pred_P3-F*.npy"))})
NF = {"P3-B1": 11, "P3-B2": 33, "P3-B3": 16, "P3-B4": 89, "P3-B1m": 11, "P3-B2m": 33, "P3-B3m": 16, "P3-B4m": 89, "P3-B5m": 90, "P3-B4t": 101, "P3-F1": 80, "P3-F2": 80, "P3-F3": 80}
rows = []
for k, P in cand.items():
    rec = R3.load(k); met = rec.get("metrics", {}) if rec else {}
    sb = mm.stable_built.values; rows.append({"model": k, "dry_year_fbr": float(np.nanmean(dry_cells(P, "never_settled"))), "fbr_all_years": float((P[mm.never_settled.values] == 1).mean()),
        "stable_built_recall": float((P[sb] == 1).mean()), "silver_test_macro_f1_2021": met.get("silver_macro_f1_2021", (met.get("silver_2021_test") or {}).get("macro_f1")),
        "complexity": NF[k.split("@")[0]] * (3 if k.startswith("P3-F") else 1), "deep": k.startswith("P3-F"),
        **{f"dry_fbr_{g[9:]}": float(np.nanmean(dry_cells(P, "never_settled")[(mm.window == g).values])) for g in WIN}})
T = pd.DataFrame(rows)
fu = config.path("results/phase3/deep_temporal/deep_temporal_summary.json")
if fu.exists():
    D = json.loads(fu.read_text()); rfb4 = next(iter(D.values()))["unseen"]
    T["unseen_macro_f1_mean"] = T.model.map({**{k: np.mean([v["macro_f1"] for v in d["unseen"].values()]) for k, d in D.items()}, "P3-B4": np.mean([v["rf_b4_macro_f1"] for v in rfb4.values()])})
def pareto(df, cols, dirs):
    keep = []
    for i, r in df.iterrows():
        dom = False
        for j, s in df.iterrows():
            if i == j: continue
            ge = all((s[c] <= r[c]) if d == "lower" else (s[c] >= r[c]) for c, d in zip(cols, dirs)); gt = any((s[c] < r[c]) if d == "lower" else (s[c] > r[c]) for c, d in zip(cols, dirs))
            if ge and gt: dom = True; break
        keep.append(not dom)
    return np.array(keep)
T["pareto"] = pareto(T, ["dry_year_fbr", "stable_built_recall", "silver_test_macro_f1_2021"], ["lower", "higher", "higher"])
front = T[T.pareto].sort_values("complexity"); sel = front.iloc[0].model
# override only if another front member is better on unseen macro-F1 with CI excluding 0 (available for F vs RF-B4)
if fu.exists() and sel == "P3-B4":
    for k, d in D.items():
        if k in set(front.model) and sum(v["diff"]["estimate"] > 0 and v["diff"]["excludes_zero"] for v in d["unseen"].values()) >= 2: sel = k
T.to_csv(OUT / "model_selection_table.csv", index=False); print(T.round(4).to_string()); print("SELECTED", sel, flush=True)
# ---------------- 2. refit the selected model and calibrate (temperature on 2021 val blocks)
DEEP = {"P3-F1": "tempcnn", "P3-F2": "gru", "P3-F3": "transformer"}
tr_cells = np.flatnonzero(((M.split == 1) & M.silver.between(1, 4)).values); va = np.flatnonzero(((M.split == 2) & M.silver.between(1, 4)).values)
if sel in DEEP:
    from pune_eo.temporal_models import window_sequence
    from pune_eo.agriculture import timeseries as TS
    src_ = open(config.path("scripts/run_phase3_deep_temporal.py")).read(); exec(src_[src_.index("def prep("):src_.index("def train(")])   # prep(), build_gru(), TS.build patch - identical to P3-F*
    fs = f"B4 sequence ({DEEP[sel]})"; Xtr, stt = prep(window_sequence(H, 2021, tr_cells, half=2)); Xva, _ = prep(window_sequence(H, 2021, va, half=2), stt)
    net, _ = TS.train(DEEP[sel], Xtr, M.silver.values[tr_cells] - 1, Xva, M.silver.values[va] - 1, 4, seed=20261103, epochs=40, patience=6)
    raw_va = TS.predict_proba(net, Xva); temp = CM.Temperature().fit(raw_va, M.silver.values[va] - 1)
    def predict_year(Hc, y, n): return temp.transform(TS.predict_proba(net, prep(window_sequence(Hc, int(y), np.arange(n), half=2), stt)[0]))
else:
    fs = {"P3-B5m@v2": "B5", "P3-B1": "B1", "P3-B2": "B2", "P3-B3": "B3", "P3-B4": "B4", "P3-B1m": "B1", "P3-B2m": "B2", "P3-B3m": "B3", "P3-B4m": "B4", "P3-B4t": "B4t"}[sel]
    multi = sel.split("@")[0].endswith("m") or sel.split("@")[0] in ("P3-B5m", "P3-B4t")
    if multi:
        z = np.load(TD / "stable_ranges_train.npz"); R_ = pd.DataFrame([(c, y) for c, (lo, hi) in zip(tr_cells, z["ranges"]) for y in range(lo, hi + 1)], columns=["cell", "year"]); R_["label"] = M.silver.values[R_.cell]
        R_ = pd.concat([d.sample(min(len(d), 30000), random_state=20261024) for _, d in R_.groupby("label")], ignore_index=True)
        X = np.vstack([F.build(H, fs, int(y), d.cell.values)[0] for y, d in R_.groupby("year")]); y_ = np.concatenate([d.label.values for _, d in R_.groupby("year")])
    else: X, _ = F.build(H, fs, 2021, tr_cells); y_ = M.silver.values[tr_cells]
    rf = RandomForestClassifier(n_estimators=300, min_samples_leaf=2, max_features="sqrt", n_jobs=2, random_state=20261024).fit(X, y_)
    temp = CM.Temperature().fit(rf.predict_proba(F.build(H, fs, 2021, va)[0]), M.silver.values[va] - 1)
    def predict_year(Hc, y, n):
        P = temp.transform(rf.predict_proba(F.build(Hc, fs, int(y))[0])); P4 = np.zeros((len(P), 4)); P4[:, [c - 1 for c in rf.classes_]] = P; return P4
# ---------------- 3. full-window product (feature build from the cube, same definitions as the HET)
class Cube:
    """HET-like view of a whole window so features.build can be reused."""
    def __init__(s, gid):
        ds = xr.open_zarr(config.path("data/features/cube", f"{gid}.zarr")); s.ds = ds; s.Hh, s.Ww = ds.sizes["y"], ds.sizes["x"]
        s.info = H["info"]; s.L = np.moveaxis(ds.landsat.values.reshape(len(YEARS), ds.sizes["feature"], -1), 2, 0)   # (cells, years, feats)
        s.T = ds.terrain.values.reshape(ds.sizes["tfeature"], -1).T; s.Q = np.moveaxis(ds.quality.values.reshape(len(YEARS), ds.sizes["qfeature"], -1), 2, 0)
        s.meta = pd.DataFrame({"window": [gid] * s.L.shape[0]}); s.climate = CL
    def as_dict(s): return {"L": s.L, "T": s.T, "info": s.info, "meta": s.meta, "climate": s.climate}
summary = {}
for gid in WIN:
    t0 = time.time(); C = Cube(gid); Hc = C.as_dict(); prev = None; d = OUT / gid; d.mkdir(exist_ok=True); era_stats = {e: {"entropy": [], "n": 0} for e in ERAS}
    tf = from_origin(float(C.ds.x.values[0]) - 15, float(C.ds.y.values[0]) + 15, 30, 30)
    for j, y in enumerate(YEARS):
        P4 = predict_year(Hc, y, C.L.shape[0])
        ent = -(P4 * np.log(np.clip(P4, 1e-12, 1))).sum(1) / np.log(4); q = np.clip(np.nansum(C.Q[:, j, :2], 1), 0, 60)
        trans = (1 - (P4 * prev).sum(1)) if prev is not None else np.full(len(P4), np.nan); prev = P4
        bands = np.vstack([np.round(P4.T * 200), (P4.argmax(1) + 1)[None], np.round(ent * 200)[None], q[None], np.where(np.isfinite(trans), np.round(trans * 200), 255)[None]]).astype(np.uint8).reshape(8, C.Hh, C.Ww)
        with rasterio.open(d / f"recon_{y}.tif", "w", driver="GTiff", height=C.Hh, width=C.Ww, count=8, dtype="uint8", crs="EPSG:32643", transform=tf, compress="deflate", tiled=True) as o:
            o.write(bands); o.descriptions = ("p_built_x200", "p_agri_x200", "p_natveg_x200", "p_water_x200", "most_likely_class", "entropy_norm_x200", "n_clear_obs", "p_class_change_x200")
            o.update_tags(era=era_of(int(y)), model=sel, features=fs, calibration=f"temperature T={temp.T:.3f} (2021 val blocks)", status="NOT VALIDATED BY TIER A - research product; agreement metrics only")
        era_stats[era_of(int(y))]["entropy"].append(float(ent.mean()))
    summary[gid] = {"seconds": round(time.time() - t0), "mean_entropy_by_era": {e: float(np.mean(v["entropy"])) for e, v in era_stats.items()}}; print(gid, summary[gid], flush=True)
# ---------------- 4. Tier-B agreement by era, built-vs-WSF MAE (3 km TEST blocks), Gate 6
P = cand[sel]; g6 = {"by_window": {}}
for g in WIN:
    w = (mm.window == g).values; r = {}
    for e, (a, b) in ERAS.items():
        k = (YEARS >= a) & (YEARS <= b); ns, sb = w & mm.never_settled.values, w & mm.stable_built.values
        r[e] = {"fbr": float((P[ns][:, k] == 1).mean()) if ns.any() else None, "built_recall": float((P[sb][:, k] == 1).mean()) if sb.any() else None}
    with rasterio.open(config.path("data/labels", g, "wsf_evolution_first_year.tif")) as s: wsf = s.read(1)
    with rasterio.open(config.path("data/labels", g, "splits.tif")) as s: sp = s.read(1)
    from pune_eo.labels.splits import block_index
    from pune_eo.grid import Grid
    gj = json.loads(xr.open_zarr(config.path("data/features/cube", f"{g}.zarr")).attrs["grid"]); Gr = Grid(g, gj["crs"], gj["res"], gj["x0"], gj["y1"], gj["width"], gj["height"], gj["corner_offset"])
    bx, by = block_index(Gr, 3000); blk = np.asarray(bx).astype(np.int64) * 100000 + np.asarray(by).astype(np.int64)
    te = sp == 3; mae = {}
    for e, (a, b) in ERAS.items():
        yrs = [y for y in range(max(a, 1990), min(b, 2015) + 1)]
        if not yrs: mae[e] = None; continue
        errs = []
        for y in yrs[:: max(1, len(yrs) // 4)]:
            with rasterio.open(OUT / g / f"recon_{y}.tif") as s: cls = s.read(5)
            ref = (wsf > 0) & (wsf <= y)
            dfb = pd.DataFrame({"b": blk[te], "p": (cls[te] == 1), "r": ref[te]}).groupby("b").mean(); errs.append(float((dfb.p - dfb.r).abs().mean()))
        mae[e] = float(np.mean(errs))
    r["built_vs_wsf_block_mae"] = mae; r["dry_year_fbr"] = float(np.nanmean(dry_cells(P, "never_settled")[w])); g6["by_window"][g] = r
g1 = False
g6["mae_ok"] = all(v is None or v <= 0.10 for r in g6["by_window"].values() for v in r["built_vs_wsf_block_mae"].values()); g6["fbr_ok"] = all(r["dry_year_fbr"] <= 0.10 for r in g6["by_window"].values())
g6["G1"] = g1; g6["passed"] = bool(g1 and g6["mae_ok"] and g6["fbr_ok"]); g6["selected_model"] = sel
json.dump({"selection": T.to_dict(orient="records"), "selected": sel, "product": summary, "gate6": g6}, open(OUT / "product_summary.json", "w"), indent=1, default=float)
R3.Run("P3-O1").complete({"selected": sel, "product": summary, "gate6": g6}, "SUPPORTED" if g6["passed"] else "NOT_SUPPORTED",
                         f"era-aware probabilistic product produced for 3 benchmark windows x 37 years with {sel} ({fs}); Gate 6 NOT passed (G1 not passed; block MAE ok={g6['mae_ok']}, dry FBR ok={g6['fbr_ok']}: "
                         + ", ".join(f"{g[9:]} {r['dry_year_fbr']:.3f}" for g, r in g6["by_window"].items()) + ") -> product is NOT a defensible history; agreement metrics only",
                         outputs={"rasters": "results/phase3/product/<window>/recon_<year>.tif", "summary": "results/phase3/product/product_summary.json"})
R3.mark_pending_reason("P3-O3", "Gate 6 not passed (no Tier-A gold; dry-year false built-up above 0.10 in at least one window) -> district-wide scaling of an undefended history is not run",
                       "Tier-A gold (G1) and a model meeting G6 on the benchmark windows")
print("GATE6", g6["passed"], g6["mae_ok"], g6["fbr_ok"])
