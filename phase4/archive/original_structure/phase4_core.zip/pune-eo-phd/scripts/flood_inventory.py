"""P3-N1: for each cited flood event, list Sentinel-1 acquisitions (selected manifest AND all catalogued items) over each affected window
within -30..+30 days and flag whether any falls in the 'during' window (-1..+3 days of the peak). No inundation map is produced here."""
import json, sys
import pandas as pd, geopandas as gpd, yaml
from shapely.geometry import box
sys.path.insert(0, "src")
from pune_eo import config
from pune_eo.validation import registry3 as R3
run = R3.Run("P3-N1"); E = yaml.safe_load(open(config.path("configs/events.yaml")))["events"]; A = config.load("aois")
M = gpd.read_parquet(config.path("data/manifests/sentinel1_manifest.parquet")); M["date"] = pd.to_datetime(M["date"]); out = {}
for eid, ev in E.items():
    peak = pd.Timestamp(ev["peak_date"]); res = {}
    for w in ev.get("windows", []):
        bb = box(*A[w]["bbox_wgs84"]); x = M[M.geometry.intersects(bb) & (M.date - peak).dt.days.between(-30, 30)].copy(); x["delta"] = (x.date - peak).dt.days
        during = x[x.delta.between(-1, 3)]
        res[w] = {"acquisitions_pm30d": [{"date": str(d.date()), "delta_days": int(dl), "orbit": int(o), "selected": bool(s)} for d, dl, o, s in zip(x.date, x.delta, x.relative_orbit, x.selected)],
                  "during_window_hits": int(len(during)), "nearest_before": int(x[x.delta < 0].delta.max()) if (x.delta < 0).any() else None,
                  "nearest_after": int(x[x.delta > 0].delta.min()) if (x.delta > 0).any() else None,
                  "observable": bool(len(during)), "verdict": "event observable by S1" if len(during) else "UNAVAILABLE: no S1 acquisition within -1..+3 days of the peak"}
    out[eid] = {"peak_date": ev["peak_date"], "source": ev["source"], "source_status": ev["source_status"], "windows": res}
    print(eid, {w: (r["during_window_hits"], r["nearest_before"], r["nearest_after"]) for w, r in res.items()})
json.dump(out, open(config.path("results/phase3/flood_inventory.json"), "w"), indent=1)
obs = [f"{e}/{w}" for e, v in out.items() for w, r in v["windows"].items() if r["observable"]]
run.complete(out, "SUPPORTED" if obs else "NOT_SUPPORTED", f"events observable by S1 within -1..+3 days: {obs or 'none'} -> " + ("event mapping possible for these only" if obs else "no flood model is built"))
