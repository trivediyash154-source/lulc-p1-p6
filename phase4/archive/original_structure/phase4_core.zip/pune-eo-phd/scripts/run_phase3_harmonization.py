"""P3-I1 — does s2_to_oli_v1 (fitted on 19 corridor same-day pairs) generalise to other windows, classes, months, years?
Same-day Landsat-8/9 + Sentinel-2 L2A pairs (|dt| < 15 min, both scenes cloud < 20 %) whose footprints cover each benchmark window, from the manifests.
Each pair read on the window's G30 lattice exactly like the cube (Landsat -> local_pune_g30_v2 OLI-equivalent; S2 SCL reader v2), clear in both.
Residual = s2_to_oli_v1(S2) - Landsat, per band, stratified by window, silver class, month, year, sun elevation; NDVI residual.
Leave-one-window-out refit: RMA fitted on the other windows' pairs, applied to the held-out window.
Hypothesis: |median residual| < 0.01 reflectance per band in every window (and >= 90 % of window x class/month/year strata with n >= 1000)."""
import json, sys, time, warnings
import numpy as np, pandas as pd, geopandas as gpd, yaml, rasterio
from shapely.geometry import box
from pyproj import Transformer
sys.path.insert(0, "src"); warnings.filterwarnings("ignore")
from pune_eo import config
from pune_eo.compositing import observations as obs
from pune_eo.compositing.windows import resolve
from pune_eo.harmonization import landsat as harm
from pune_eo.validation import registry3 as R3
OUT = config.path("results/phase3/harmonization"); OUT.mkdir(parents=True, exist_ok=True)
B = ["blue", "green", "red", "nir08", "swir16", "swir22"]; SB = list(config.load("sentinel2")["bands"]); TF = yaml.safe_load(open(config.path("results/harmonization/s2_to_oli_v1.yaml")))
L = gpd.read_parquet(config.path("data/manifests/landsat_manifest.parquet")); S = gpd.read_parquet(config.path("data/manifests/sentinel2_manifest.parquet"))
L = L[L.platform.isin(["landsat-8", "landsat-9"]) & (L.cloud_cover < 20)]; S = S[S.cloud_cover < 20]
MAXP = int(sys.argv[1]) if len(sys.argv) > 1 else 10
def rma(x, y):
    for _ in range(2):
        b = np.sign(np.corrcoef(x, y)[0, 1]) * np.std(y) / np.std(x); a = np.mean(y) - b * np.mean(x); r = y - (a + b * x); mad = 1.4826 * np.median(np.abs(r - np.median(r)))
        k = np.abs(r - np.median(r)) < 3 * mad; x, y = x[k], y[k]
    return float(b), float(a)
def cut(o, ref):
    c0, r0 = int(o["win"].col_off - ref.col_off), int(o["win"].row_off - ref.row_off); out = np.full((o["values"].shape[0], int(ref.height), int(ref.width)), np.nan, np.float32); h, w = o["values"].shape[1:]
    ys, xs = slice(max(r0, 0), min(r0 + h, int(ref.height))), slice(max(c0, 0), min(c0 + w, int(ref.width))); out[:, ys, xs] = o["values"][:, ys.start - r0:ys.stop - r0, xs.start - c0:xs.stop - c0]; return out
samples, pairs_used = [], []
for w in ["khadakwasla_mutha", "baramati_agri", "mulshi_ghats"]:
    g, win, wn = resolve("G30", w); sub = g.subgrid(win, f"_{wn}"); t = Transformer.from_crs(g.crs, 4326, always_xy=True); x0, y0, x1, y1 = sub.bounds
    bb = box(*t.transform(x0, y0), *t.transform(x1, y1)); Lw = L[L.geometry.contains(bb)]; Sw = S[S.geometry.intersects(bb)]
    j = Lw.merge(Sw, on="date", suffixes=("_L", "_S")); j["dt_min"] = (pd.to_datetime(j.datetime_utc_S) - pd.to_datetime(j.datetime_utc_L)).dt.total_seconds() / 60
    j = j[j.dt_min.abs() < 15].copy(); j["cc"] = j.cloud_cover_L + j.cloud_cover_S; j = j.sort_values("cc").drop_duplicates("product_id_L")
    j = j.groupby("month_L", group_keys=False).head(2).sort_values("cc").head(MAXP)   # spread over months
    with rasterio.open(config.path("data/labels", f"pune_G30_{w}", "silver_l1.tif")) as s_: silver = s_.read(1)
    print(w, "candidate pairs", len(j), flush=True)
    for _, p in j.iterrows():
        try:
            lo = obs.landsat(L.set_index("product_id").loc[p.product_id_L].to_dict() | {"product_id": p.product_id_L}, g, win)
            so = obs.sentinel2(S.set_index("product_id").loc[p.product_id_S].to_dict() | {"product_id": p.product_id_S}, g, win)
        except Exception as e: print("skip", p.date, repr(e)[:80], flush=True); continue
        if lo is None or so is None: continue
        lv, sv = harm.apply(cut(lo, win), p.platform_L), cut(so, win); sv = sv[[SB.index(b) for b in B]]
        m = np.all(np.isfinite(lv), 0) & np.all(np.isfinite(sv), 0) & np.all((lv > 0) & (lv < 1) & (sv > 0) & (sv < 1), 0)
        if m.sum() < 5000: print("skip (clear px)", p.date, int(m.sum()), flush=True); continue
        idx = np.flatnonzero(m.ravel()); idx = np.random.default_rng(0).choice(idx, min(20000, idx.size), replace=False)
        samples.append({"window": w, "date": str(p.date), "month": int(p.month_L), "year": int(p.year_L), "sun_elev": float(p.sun_elevation_L), "pb": str(p.processing_baseline_S),
                        "L": np.stack([lv[i].ravel()[idx] for i in range(6)]), "S": np.stack([sv[i].ravel()[idx] for i in range(6)]), "cls": silver.ravel()[idx]})
        pairs_used.append({k: samples[-1][k] for k in ("window", "date", "month", "year", "sun_elev", "pb")} | {"n_px": int(len(idx)), "landsat": p.platform_L, "dt_min": round(float(p.dt_min), 1),
                           "in_v1_fit_set": bool(w == "khadakwasla_mutha" and str(p.date) in TF["pair_dates"])})
        print("pair", w, p.date, len(idx), flush=True)
import pickle; pickle.dump(samples, open(OUT / "same_day_samples_3windows.pkl", "wb"))
def adj(Sx, coef): return np.stack([coef[b][0] * Sx[i] + coef[b][1] for i, b in enumerate(B)])
v1 = {b: (TF["slope"][b], TF["intercept"][b]) for b in B}; rows = []
for s in samples:
    A = adj(s["S"], v1); nd = lambda X: (X[3] - X[2]) / (X[3] + X[2])
    for i, b in enumerate(B + ["ndvi"]):
        before = (s["S"][i] - s["L"][i]) if b != "ndvi" else nd(s["S"]) - nd(s["L"]); after = (A[i] - s["L"][i]) if b != "ndvi" else nd(A) - nd(s["L"])
        for c in np.unique(s["cls"]):
            k = s["cls"] == c; rows.append({"window": s["window"], "date": s["date"], "month": s["month"], "year": s["year"], "sun_elev": s["sun_elev"], "silver_class": int(c), "band": b,
                                            "n": int(k.sum()), "bias_before": float(np.median(before[k])), "bias_after": float(np.median(after[k])), "mad_after": float(np.median(np.abs(after[k] - np.median(after[k]))))})
D = pd.DataFrame(rows); D.to_csv(OUT / "residuals_by_pair_class.csv", index=False)
def wmed(d, col): return float(np.average(d[col], weights=d.n))
res = {"pairs": pairs_used, "n_pairs_by_window": pd.Series([p["window"] for p in pairs_used]).value_counts().to_dict(), "by_window": {}, "strata_pass_share": {}}
for w, d in D.groupby("window"):
    res["by_window"][w] = {b: {"bias_before": wmed(dd, "bias_before"), "bias_after": wmed(dd, "bias_after"), "mad_after": wmed(dd, "mad_after"), "n_px": int(dd.n.sum())} for b, dd in d.groupby("band")}
for by in ("silver_class", "month", "year"):
    g_ = D[D.band != "ndvi"].groupby(["window", "band", by]).apply(lambda d: pd.Series({"n": d.n.sum(), "bias": np.average(d.bias_after, weights=d.n)})).reset_index()
    g_ = g_[g_.n >= 1000]; res["strata_pass_share"][by] = float((g_.bias.abs() < 0.01).mean()); g_.to_csv(OUT / f"residual_by_{by}.csv", index=False)
sun = D[D.band != "ndvi"].groupby(["band"]).apply(lambda d: float(np.corrcoef(d.sun_elev, d.bias_after)[0, 1]) if d.sun_elev.nunique() > 2 else None).to_dict(); res["corr_bias_sun_elevation"] = sun
# leave-one-window-out refit
res["lowo_refit"] = {}
for w in set(s["window"] for s in samples):
    tr = [s for s in samples if s["window"] != w]; te = [s for s in samples if s["window"] == w]
    if not tr or not te: continue
    coef = {}
    for i, b in enumerate(B):
        x = np.concatenate([s["S"][i] for s in tr]); y = np.concatenate([s["L"][i] for s in tr]); coef[b] = rma(x, y)
    res["lowo_refit"][w] = {b: {"slope": coef[b][0], "intercept": coef[b][1], "v1_slope": v1[b][0], "bias_after_refit": float(np.median(np.concatenate([adj(s["S"], coef)[i] - s["L"][i] for s in te]))),
                               "bias_after_v1": float(np.median(np.concatenate([adj(s["S"], v1)[i] - s["L"][i] for s in te])))} for i, b in enumerate(B)}
json.dump(res, open(OUT / "harmonization_generalisation.json", "w"), indent=1, default=float)
other = [w for w in res["by_window"] if w != "khadakwasla_mutha"]
win_ok = all(abs(res["by_window"][w][b]["bias_after"]) < 0.01 for w in res["by_window"] for b in B); strata_ok = all(v >= 0.9 for v in res["strata_pass_share"].values())
run = R3.Run("P3-I1")
if not other: run.fail("no usable same-day pairs outside the corridor", "manifest search for L8/9+S2 same-day pairs covering baramati_agri / mulshi_ghats", "acquire pairs or relax cloud threshold")
else:
    run.complete(res, "SUPPORTED" if win_ok and strata_ok else "NOT_SUPPORTED",
                 "median residual after s2_to_oli_v1 (reflectance): " + "; ".join(f"{w}: " + ", ".join(f"{b} {res['by_window'][w][b]['bias_after']:+.4f}" for b in B) for w in res["by_window"]) +
                 f"; strata with |bias|<0.01: {res['strata_pass_share']}; pairs {res['n_pairs_by_window']}", outputs={"summary": "results/phase3/harmonization/harmonization_generalisation.json"},
                 n_samples={"pairs": len(pairs_used)})
print(json.dumps({w: {b: round(v["bias_after"], 4) for b, v in d.items()} for w, d in res["by_window"].items()}), res["strata_pass_share"])
