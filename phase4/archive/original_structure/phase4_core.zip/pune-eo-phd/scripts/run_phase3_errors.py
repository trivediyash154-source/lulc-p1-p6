"""P3-O2 — error taxonomy for the selected reconstruction model (results/phase3/product/product_summary.json) on Tier-B TEST cells, 1990-2026.
Errors: false built-up on never-settled cells, missed built on stable-built cells, missed water on deep-water cells (cell-years).
Each error is attributed to ONE category in a fixed priority order (rules written before counting):
  1 label_conflict      the cell's silver 2021 label contradicts its Tier-B stratum (e.g. never-settled but silver built) -> reference disagreement
  2 sensor_qa           < 3 clear Landsat observations (dry + post) in that year, or the year is Landsat-7-only SLC-off (2012)
  3 drought             the year is SPI-12(t-1) dry
  4 seasonal            no post-monsoon observation in that year (seasonal contrast unavailable)
  5 ambiguity           no silver consensus at the cell (mixed / disputed cell)
  6 temporal_transfer   |year - 2021| > 10 (far from the label epoch), none of the above
  7 model               remaining errors
Spatial transfer is not attributable here (within-window predictions); it is quantified separately in P3-E/J."""
import json, sys, warnings
import numpy as np, pandas as pd
sys.path.insert(0, "src"); warnings.filterwarnings("ignore")
from pune_eo import config
from pune_eo.historical_reconstruction import het
from pune_eo.validation import registry3 as R3
H = het.load(); M = H["meta"]; YEARS = np.array(H["info"]["years"]); CL = H["climate"]
S = json.loads(config.path("results/phase3/product/product_summary.json").read_text()); sel = S["selected"]
src = config.path("results/phase3/temporal") if sel.startswith("P3-B") else config.path("results/phase3/deep_temporal")
P = np.load(src / f"pred_{sel}.npy"); ev = np.load(config.path("results/phase3/temporal/eval_cells.npy")); mm = M.iloc[ev].reset_index(drop=True)
nq = np.nansum(H["Q"][ev][:, :, :2], 2); npost = H["Q"][ev][:, :, H["info"]["qfeatures"].index("n_post")]
dry = np.stack([(CL[CL.window == g].set_index("year").climate_class.reindex(YEARS).values == "dry") for g in mm.window], 0)
ERAS = {"early_historical": (1990, 1998), "landsat_dominant": (1999, 2014), "sentinel_dense": (2015, 2021), "current": (2022, 2026)}
rows = []
for kind, wrong, conflict in (("false_built_never_settled", lambda p: p == 1, lambda s: s == 1), ("missed_built_stable_built", lambda p: p != 1, lambda s: (s > 0) & (s != 1)),
                              ("missed_water_deep_water", lambda p: p != 4, lambda s: (s > 0) & (s != 4))):
    col = {"false_built_never_settled": "never_settled", "missed_built_stable_built": "stable_built", "missed_water_deep_water": "deep_water"}[kind]
    ci = np.flatnonzero(mm[col].values)
    for i in ci:
        e = np.flatnonzero(wrong(P[i]))
        for j in e:
            y = YEARS[j]; s = mm.silver.values[i]
            if conflict(s): cat = "label_conflict"
            elif nq[i, j] < 3 or y == 2012: cat = "sensor_qa"
            elif dry[i, j]: cat = "drought"
            elif not (npost[i, j] > 0): cat = "seasonal"
            elif s == 0: cat = "ambiguity"
            elif abs(y - 2021) > 10: cat = "temporal_transfer"
            else: cat = "model"
            rows.append((kind, mm.window.values[i], int(y), cat))
E = pd.DataFrame(rows, columns=["error_type", "window", "year", "category"]); E["era"] = E.year.map(lambda y: next(k for k, (a, b) in ERAS.items() if a <= y <= b))
E.to_csv(config.path("results/phase3/product/error_taxonomy_cells.csv"), index=False)
tot = {k: int(len(np.flatnonzero(mm[c].values)) * len(YEARS)) for k, c in (("false_built_never_settled", "never_settled"), ("missed_built_stable_built", "stable_built"), ("missed_water_deep_water", "deep_water"))}
res = {"selected_model": sel, "n_errors": E.error_type.value_counts().to_dict(), "cell_years_evaluated": tot,
       "share_by_category": E.groupby("error_type").category.value_counts(normalize=True).round(4).unstack().fillna(0).to_dict(orient="index"),
       "share_by_category_and_window": {k: d.groupby("window").category.value_counts(normalize=True).round(4).unstack().fillna(0).to_dict(orient="index") for k, d in E.groupby("error_type")},
       "errors_by_era": E.groupby(["error_type", "era"]).size().unstack().fillna(0).astype(int).to_dict(orient="index"),
       "rules": "priority: label_conflict > sensor_qa > drought > seasonal > ambiguity > temporal_transfer > model"}
json.dump(res, open(config.path("results/phase3/product/error_taxonomy.json"), "w"), indent=1, default=float)
fb = res["share_by_category"].get("false_built_never_settled", {})
R3.Run("P3-O2").complete(res, "SUPPORTED" if fb and fb.get("model", 1) < 0.5 else "NOT_SUPPORTED",
                         f"{sel}: false built-up errors attributed: " + ", ".join(f"{k} {v:.0%}" for k, v in sorted(fb.items(), key=lambda z: -z[1])) + " (rule-based, priority order fixed in advance)",
                         outputs={"summary": "results/phase3/product/error_taxonomy.json"})
print(json.dumps(res["share_by_category"], indent=0))
