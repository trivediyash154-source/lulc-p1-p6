"""Is the S2-vs-OLI 30 m contrast mismatch radiometric or spatial (PSF/MTF)? Re-read 4 same-day pairs and compare
RMA slope at block-aggregation scales 30/90/150/300 m and after Gaussian blurring S2 (sigma in 30 m px).
Output: results/audit/s2_oli_scale_test.csv"""
import json, warnings, sys
import geopandas as gpd, numpy as np, pandas as pd
from scipy.ndimage import gaussian_filter
sys.path.insert(0, "src")
from pune_eo import config
from pune_eo.compositing import observations as obs
from pune_eo.compositing.windows import resolve
from pune_eo.harmonization import landsat as harm
warnings.filterwarnings("ignore")
g, win, _ = resolve("G30", "khadakwasla_mutha")
pairs = pd.read_csv(config.path("results/audit/same_day_pairs.csv"))
pairs = pairs[pairs.platform_L.isin(["landsat-8", "landsat-9"]) & (pairs.dt_min.abs() < 15)].drop_duplicates("product_id_L")
pairs = pairs[pairs.date.isin(["2020-03-20", "2021-04-24", "2024-04-08", "2026-03-29"])]
L = gpd.read_parquet(config.path("data/manifests/landsat_manifest.parquet")).set_index("product_id")
S = gpd.read_parquet(config.path("data/manifests/sentinel2_manifest.parquet")).set_index("product_id")
B = ["blue", "green", "red", "nir08", "swir16", "swir22"]; SB = list(config.load("sentinel2")["bands"])
def rma(x, y): return float(np.std(y) / np.std(x)), float(np.corrcoef(x, y)[0, 1])
def blocks(a, k):
    H, W = a.shape[0] // k * k, a.shape[1] // k * k
    return a[:H, :W].reshape(H // k, k, W // k, k).mean(axis=(1, 3))
rows = []
for _, p in pairs.iterrows():
    lo = obs.landsat(L.loc[p.product_id_L].to_dict() | {"product_id": p.product_id_L}, g, win)
    so = obs.sentinel2(S.loc[p.product_id_S].to_dict() | {"product_id": p.product_id_S}, g, win)
    assert lo["win"] == so["win"] or True
    lv = harm.apply(lo["values"], p.platform_L); sv = so["values"]
    h = min(lv.shape[1], sv.shape[1]); w = min(lv.shape[2], sv.shape[2])   # both cut on the same G30 window
    for b in B:
        x = sv[SB.index(b)][:h, :w].astype(float); y = lv[B.index(b)][:h, :w].astype(float)
        m = np.isfinite(x) & np.isfinite(y)
        if m.mean() < 0.95: continue          # need near-complete images for blocks/blur
        fill = lambda a: np.where(m, a, np.nanmedian(a[m]))
        x, y = fill(x), fill(y)
        for k in (1, 3, 5, 10):
            s, r = rma(blocks(x, k).ravel(), blocks(y, k).ravel())
            rows.append({"date": p.date, "band": b, "test": f"block_{30*k}m", "rma_slope": s, "r": r})
        for sig in (0.5, 0.75, 1.0):
            s, r = rma(gaussian_filter(x, sig).ravel(), y.ravel())
            rows.append({"date": p.date, "band": b, "test": f"s2_gauss_sigma{sig}px", "rma_slope": s, "r": r})
    print(p.date, "done", flush=True)
df = pd.DataFrame(rows); df.to_csv(config.path("results/audit/s2_oli_scale_test.csv"), index=False)
print(df.groupby(["band", "test"]).rma_slope.median().unstack().round(3).to_string())
print(df.groupby(["band", "test"]).r.median().unstack().round(3).to_string())
