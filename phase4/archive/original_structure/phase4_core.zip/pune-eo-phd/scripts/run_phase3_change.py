"""Phase-3 group K — change detection diagnosis (P3-K1) and probabilistic change timing (P3-K2).
K1  failure decomposition of the Phase-2 best detector (EXP-CP-001: post-monsoon NDVI, PELT; 39 % of urbanised cells timed within +-2 y of WSF).
    Every urbanised sample cell gets non-exclusive diagnostic flags (thresholds fixed here, before looking at the outcome):
      insufficient_obs   detector returned None (< 10 observed years)
      no_signal          |median post-NDVI (ref+1..ref+5) - median (ref-5..ref-1)| < 0.05
      short_pre_period   < 4 observed years before the WSF year
      reference_disagreement  the GHSL 5-yearly epoch pair with the largest built-fraction gain does not bracket the WSF year (+-2 y)
      gradual            signal present, but the largest 1-year step of the 3-year running median < 40 % of the total pre/post change
      sensor_transition  the detector's nearest negative break lies within +-1 y of a Landsat transition (1999, 2003, 2012, 2013) and > 2 y from WSF
      noisy_series       robust noise sigma (MAD of first differences) > 0.08
    Misses are attributed exclusively in that priority order; remaining misses = 'detector' (mistimed or missed despite a clean, abrupt signal).
K2  P(transition to built in year t) per cell from annual class probabilities (XGBoost on B3+terrain, trained on multi-year stable-segment rows (Tier D),
    temperature-calibrated on 2021 val blocks) with an absorbing two-state model (not-built -> built, no reversal):
      P(tau) ~ prior(tau) * prod_{t<tau} e0(t) * prod_{t>=tau} e1(t), tau in {built by 1990, 1991..2026, never}, prior 1/3 each (uniform within 1991-2026),
      e1/e0 = [p_t / pi] / [(1 - p_t) / (1 - pi)] (pi = built share of training rows), missing years uninformative.
    Evaluated on TEST-block Tier-B cells: urbanised (WSF 1995-2012 & GHSL gain >= 0.2), never-settled, stable-built.
    Hypothesis: 80 % credible sets cover the WSF year for 70-90 % of urbanised cells AND binary ECE of P(transition 1991-2026) <= 0.10."""
import json, sys, time, warnings
import numpy as np, pandas as pd, rasterio
sys.path.insert(0, "src"); warnings.filterwarnings("ignore")
from pune_eo import config
from pune_eo.classification import baseline as B
from pune_eo.change_detection import changepoints as C
from pune_eo.historical_reconstruction import het, features as F
from pune_eo.calibration import metrics as CM
from pune_eo.validation import registry3 as R3
OUT = config.path("results/phase3/change"); OUT.mkdir(parents=True, exist_ok=True); SEED = 20261101
# ---------------- K1
bk = pd.read_parquet(config.path("results/change_detection/cp_sample_breaks.parquet")); u = bk[(bk.stratum == "urbanised") & (bk["index"] == "post_ndvi") & (bk.method == "pelt_mean")].copy()
SENS = np.array([1999, 2003, 2012, 2013]); rows = []
for gid, g in u.groupby("window"):
    ds = B.open_cube(gid); yrs = ds.year.values; Y = ds.landsat.sel(feature="post_ndvi").values
    with rasterio.open(config.path("data/labels", gid, "ghsl_built_fraction_90m.tif")) as s: gh = s.read().astype(float)
    EP = np.array([1990, 1995, 2000, 2005, 2010, 2015, 2020])
    for _, r in g.iterrows():
        y = Y[:, r.row, r.col]; ref = int(r.ref_year); ok = np.isfinite(y)
        pre = y[(yrs >= ref - 5) & (yrs <= ref - 1) & ok]; post = y[(yrs >= ref + 1) & (yrs <= ref + 5) & ok]
        tot = (np.median(post) - np.median(pre)) if len(pre) and len(post) else np.nan
        rm = pd.Series(y[ok], index=yrs[ok]).rolling(3, center=True, min_periods=2).median().values; step = np.nanmax(np.abs(np.diff(rm))) if len(rm) > 2 else np.nan
        ghv = gh[:, min(r.row // 3, gh.shape[1] - 1), min(r.col // 3, gh.shape[2] - 1)]; k = int(np.nanargmax(np.diff(ghv))) if np.isfinite(ghv).all() else None
        brk = json.loads(r.breaks) if isinstance(r.breaks, str) else None; neg = [c for c in (brk or []) if c[1] <= -0.05]
        err = min((c[0] - ref for c in neg), key=abs) if neg else None; nearest = (ref + err) if err is not None else None
        rows.append({"window": gid, "row": r.row, "col": r.col, "ref_year": ref, "hit": err is not None and abs(err) <= 2, "err": err, "any_neg_break": bool(neg),
                     "insufficient_obs": brk is None, "no_signal": bool(np.isfinite(tot) and abs(tot) < 0.05) or not np.isfinite(tot), "short_pre_period": int((ok & (yrs < ref)).sum()) < 4,
                     "reference_disagreement": bool(k is not None and not (EP[k] - 2 <= ref <= EP[k + 1] + 2)),
                     "gradual": bool(np.isfinite(tot) and abs(tot) >= 0.05 and np.isfinite(step) and step < 0.4 * abs(tot)),
                     "sensor_transition": bool(nearest is not None and np.min(np.abs(SENS - nearest)) <= 1 and abs(err) > 2),
                     "noisy_series": bool(C.noise_sigma(y[ok]) > 0.08) if ok.sum() > 3 else True, "total_change": float(tot) if np.isfinite(tot) else None})
K = pd.DataFrame(rows); K.to_csv(OUT / "k1_cells.csv", index=False)
CATS = ["insufficient_obs", "no_signal", "short_pre_period", "reference_disagreement", "gradual", "sensor_transition", "noisy_series"]
def attribute(r):
    if r.hit: return "hit"
    for c in CATS:
        if r[c]: return c
    return "detector_mistimed" if r.any_neg_break else "detector_missed"
K["attribution"] = K.apply(attribute, axis=1); miss = K[~K.hit]
k1 = {"n": len(K), "recall_pm2": float(K.hit.mean()), "phase2_value": 0.3899, "miss_attribution_share": miss.attribution.value_counts(normalize=True).round(4).to_dict(),
      "flag_prevalence": {c: float(K[c].mean()) for c in CATS}, "recall_by_flag": {c: {"with": float(K[K[c]].hit.mean()) if K[c].any() else None, "without": float(K[~K[c]].hit.mean()) if (~K[c]).any() else None, "n_with": int(K[c].sum())} for c in CATS},
      "recall_by_window": K.groupby("window").hit.mean().round(4).to_dict(), "recall_by_ref_year_bin": K.groupby(pd.cut(K.ref_year, [1994, 1999, 2004, 2008, 2012])).hit.mean().round(4).astype(float).to_dict().__repr__(),
      "median_err_when_mistimed": float(miss[miss.attribution == "detector_mistimed"].err.median()) if (miss.attribution == "detector_mistimed").any() else None}
nondet = float(miss.attribution.isin(CATS).mean()); k1["non_detector_share_of_misses"] = nondet
R3.Run("P3-K1").complete(k1, "SUPPORTED" if nondet > 0.5 else "NOT_SUPPORTED",
                         f"recall +-2y {k1['recall_pm2']:.3f} (Phase 2 0.390, same sample); misses attributed to data/reference categories {nondet:.0%}, detector {1 - nondet:.0%}: {k1['miss_attribution_share']}",
                         outputs={"cells": "results/phase3/change/k1_cells.csv"}, n_samples={"urbanised_cells": len(K)})
print("K1", k1["recall_pm2"], k1["miss_attribution_share"], flush=True)
# ---------------- K2
H = het.load(); M = H["meta"]; YEARS = np.array(H["info"]["years"]); tr_cells = np.flatnonzero(((M.split == 1) & M.silver.between(1, 4)).values)
z = np.load(config.path("results/phase3/temporal/stable_ranges_train.npz")); assert (z["cells"] == tr_cells).all(); rngs = z["ranges"]
R_ = pd.DataFrame([(c, y) for c, (lo, hi) in zip(tr_cells, rngs) for y in range(lo, hi + 1)], columns=["cell", "year"]); R_["label"] = M.silver.values[R_.cell]
R_ = pd.concat([d.sample(min(len(d), 30000), random_state=SEED) for _, d in R_.groupby("label")], ignore_index=True)
def XB(cells, year): return np.hstack([F.build(H, "B3", int(year), cells)[0], H["T"][cells]])
Xtr = np.vstack([XB(d.cell.values, y) for y, d in R_.groupby("year")]); ytr = np.concatenate([d.label.values for _, d in R_.groupby("year")])
va = np.flatnonzero(((M.split == 2) & M.silver.between(1, 4)).values); enc = {c: i for i, c in enumerate(B.CLASSES)}
m = B.make_model("xgb", SEED); m.fit(Xtr, np.vectorize(enc.get)(ytr), eval_set=[(XB(va, 2021), np.vectorize(enc.get)(M.silver.values[va]))], verbose=False)
temp = CM.Temperature().fit(m.predict_proba(XB(va, 2021)), M.silver.values[va] - 1); pi = float((ytr == 1).mean())
te = np.flatnonzero((M.split == 3).values & (M.urbanised | M.never_settled | M.stable_built).values)
P = np.stack([temp.transform(m.predict_proba(XB(te, y)))[:, 0] for y in YEARS], 1)          # P(built) per year
obs = np.isfinite(H["L"][te][:, :, H["info"]["features"].index("dry_ndvi")])
from pune_eo.change_detection.probabilistic import transition_posterior, hpd_set
post = transition_posterior(P, obs, pi)
p_change = post[:, 1:len(YEARS)].sum(1); mm = M.iloc[te].reset_index(drop=True)
truth = mm.urbanised.values.astype(int); keep = (mm.urbanised | mm.never_settled | mm.stable_built).values & ~(mm.urbanised & (mm.never_settled | mm.stable_built)).values
hpd = hpd_set
urb = np.flatnonzero(mm.urbanised.values); wsf = mm.wsf.values.astype(int)
lab_idx = lambda y: int(np.where(YEARS == y)[0][0])
cov0 = np.mean([lab_idx(wsf[i]) in hpd(post[i]) for i in urb]); cov1 = np.mean([bool({lab_idx(wsf[i]) + d for d in (-1, 0, 1)} & hpd(post[i])) for i in urb])
setsize = np.mean([len(hpd(post[i])) for i in urb]); mode = np.array([post[i].argmax() for i in urb]); merr = np.array([YEARS[min(k, len(YEARS) - 1)] - wsf[i] if 1 <= k < len(YEARS) else np.nan for k, i in zip(mode, urb)])
pb = np.stack([1 - p_change, p_change], 1)[keep]; tb = truth[keep]
from sklearn.metrics import roc_auc_score
k2 = {"n_urbanised": int(len(urb)), "n_never_settled": int(mm.never_settled.sum()), "n_stable_built": int(mm.stable_built.sum()), "temperature": temp.T, "pi_built_train": pi,
      "coverage80_exact_wsf_year": float(cov0), "coverage80_pm1": float(cov1), "mean_80pct_set_size_years": float(setsize),
      "mode_timing_error_median": float(np.nanmedian(merr)), "mode_within_pm2": float(np.nanmean(np.abs(merr) <= 2)), "mode_is_change_year_share": float(np.mean((mode >= 1) & (mode < len(YEARS)))),
      "p_change_binary": {"ece": CM.ece(pb, tb, bins=10), "brier": float(np.mean((p_change[keep] - tb) ** 2)), "auc": float(roc_auc_score(tb, p_change[keep])), "reliability": CM.reliability(pb, tb, 10)},
      "mean_p_change": {"urbanised": float(p_change[mm.urbanised.values].mean()), "never_settled": float(p_change[mm.never_settled.values].mean()), "stable_built": float(p_change[mm.stable_built.values].mean())},
      "by_window_coverage80": {g: float(np.mean([lab_idx(wsf[i]) in hpd(post[i]) for i in urb if mm.window.values[i] == g])) for g in mm.window.unique() if (mm.window.values[urb] == g).any()}}
np.savez_compressed(OUT / "k2_posteriors.npz", cells=te, post=post.astype(np.float32), p_built=P.astype(np.float32))
ok = 0.7 <= cov0 <= 0.9 and k2["p_change_binary"]["ece"] <= 0.10
R3.Run("P3-K2").complete(k2, "SUPPORTED" if ok else "NOT_SUPPORTED",
                         f"80 % credible sets contain the WSF year for {cov0:.1%} of urbanised test cells ({cov1:.1%} within +-1 y; mean set {setsize:.1f} y); P(transition 1991-2026) ECE {k2['p_change_binary']['ece']:.3f}, AUC {k2['p_change_binary']['auc']:.3f}; "
                         f"mean P(change): urbanised {k2['mean_p_change']['urbanised']:.2f}, never-settled {k2['mean_p_change']['never_settled']:.2f}, stable-built {k2['mean_p_change']['stable_built']:.2f}",
                         outputs={"posteriors": "results/phase3/change/k2_posteriors.npz"}, n_samples={"test_cells": int(len(te))})
json.dump({"K1": k1, "K2": k2}, open(OUT / "change_summary.json", "w"), indent=1, default=float); print("K2", cov0, k2["p_change_binary"]["ece"])
