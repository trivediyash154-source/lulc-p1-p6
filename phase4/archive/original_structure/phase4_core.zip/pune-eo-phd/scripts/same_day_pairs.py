"""Single-date OLI vs MSI comparison on same-day acquisitions (no compositing involved)."""
import json, warnings
import geopandas as gpd, numpy as np, pandas as pd
from pune_eo import config
from pune_eo.compositing import observations as obs
from pune_eo.compositing.windows import resolve
from pune_eo.harmonization import landsat as harm
warnings.filterwarnings("ignore")
g, win, _ = resolve("G30", "khadakwasla_mutha")
pairs = pd.read_csv(config.path("results/audit/same_day_pairs.csv"))
pairs = pairs[pairs.platform_L.isin(["landsat-8", "landsat-9"]) & (pairs.dt_min.abs() < 15)].drop_duplicates("product_id_L")
L = gpd.read_parquet(config.path("data/manifests/landsat_manifest.parquet")).set_index("product_id")
S = gpd.read_parquet(config.path("data/manifests/sentinel2_manifest.parquet")).set_index("product_id")
B = ["blue", "green", "red", "nir08", "swir16", "swir22"]; SB = list(config.load("sentinel2")["bands"])
rows = []; samples = []
for _, p in pairs.iterrows():
    lo = so = None
    for attempt in range(3):
        try:
            lo = obs.landsat(L.loc[p.product_id_L].to_dict() | {"product_id": p.product_id_L}, g, win)
            so = obs.sentinel2(S.loc[p.product_id_S].to_dict() | {"product_id": p.product_id_S}, g, win); break
        except Exception as e:
            print("retry", p.date, repr(e)[:80]); import time; time.sleep(5)
    if lo is None or so is None: continue
    # align the two windows (both on G30)
    def cut(o, ref):
        c0, r0 = int(o["win"].col_off - ref.col_off), int(o["win"].row_off - ref.row_off)
        out = np.full((o["values"].shape[0], int(ref.height), int(ref.width)), np.nan, np.float32)
        h, w = o["values"].shape[1:]
        ys, xs = slice(max(r0, 0), min(r0 + h, int(ref.height))), slice(max(c0, 0), min(c0 + w, int(ref.width)))
        out[:, ys, xs] = o["values"][:, ys.start - r0:ys.stop - r0, xs.start - c0:xs.stop - c0]; return out
    lv, sv = cut(lo, win), cut(so, win)
    lv = harm.apply(lv, p.platform_L)            # harmonised to OLI exactly as in the cube
    m = np.all(np.isfinite(lv), 0) & np.all(np.isfinite(sv[[SB.index(b) for b in B]]), 0)
    if m.sum() < 5000: continue
    r = {"date": p.date, "landsat": p.platform_L, "s2": p.platform_S, "pb": p.processing_baseline, "dt_min": round(p.dt_min, 1), "n": int(m.sum())}
    for b in B:
        x, y = lv[B.index(b)][m], sv[SB.index(b)][m]
        r[f"bias_{b}"] = float(np.median(y - x)); r[f"ratio_{b}"] = float(np.median(y) / np.median(x))
    nl = (lv[3] - lv[2]) / (lv[3] + lv[2]); ns = (sv[SB.index("nir08")] - sv[SB.index("red")]) / (sv[SB.index("nir08")] + sv[SB.index("red")])
    r["bias_ndvi"] = float(np.median((ns - nl)[m])); rows.append(r); print(json.dumps(r), flush=True)
    idx = np.flatnonzero(m.ravel()); idx = np.random.default_rng(0).choice(idx, min(20000, idx.size), replace=False)
    samples.append({"date": p.date, "pb": float(p.processing_baseline), "landsat": p.platform_L,
                    "L": np.stack([lv[B.index(b)].ravel()[idx] for b in B]), "S": np.stack([sv[SB.index(b)].ravel()[idx] for b in B])})
import pickle; pickle.dump(samples, open(config.path("results/audit/same_day_pixel_samples.pkl"), "wb"))
df = pd.DataFrame(rows); df.to_csv(config.path("results/audit/same_day_pair_comparison.csv"), index=False)
df["pb_group"] = np.where(df.pb.astype(float) >= 4, "PB>=04.00 (offset subtracted)", "PB<04.00 (no offset)")
print(df.groupby("pb_group")[[c for c in df.columns if c.startswith("bias_")]].median().round(4).T)
