"""Water module (registry EXP-WAT-001): surface-water persistence, reservoir area trajectories 1990-2026 (dry & post-monsoon),
rainfall association (CHIRPS window mean, same-year and lagged), Mutha river width transects (30 m). No depth/volume claims."""
import json, sys, warnings
import numpy as np, pandas as pd, rasterio
from scipy.stats import spearmanr
sys.path.insert(0, "src"); warnings.filterwarnings("ignore")
from pune_eo import config
from pune_eo.classification import baseline as B
from pune_eo.water import surface_water as SW
from pune_eo.modelling.registry import Experiment
from rasterio.warp import transform_bounds
W = ["pune_G30_khadakwasla_mutha", "pune_G30_baramati_agri", "pune_G30_mulshi_ghats"]
out = config.path("results/water"); out.mkdir(parents=True, exist_ok=True)
e = Experiment(experiment_id="EXP-WAT-001", research_question="RQ-W: How have open-water extent, persistence and reservoir surface area changed 1990-2026, and how do they track rainfall?",
               hypothesis="post-monsoon reservoir area tracks same-year monsoon rainfall; dry-season area tracks the previous monsoon (lag 1 season)",
               dataset_version="cube G30 local_pune_g30_v2; JRC GSW v1.3 geometry; CHIRPS v2.0", years=list(range(1990, 2027)), resolution_m=30,
               features=["dry_mndwi", "post_mndwi"], labels="validation: JRC GSW occurrence", split="n/a (descriptive + association)", model="MNDWI>0; Sen slope; Spearman",
               hyperparameters={"mndwi_threshold": 0.0, "reservoir_min_km2": 1.0}, seed=0)
# CHIRPS monthly stack -> window mean series
with rasterio.open(config.path("data/processed/climate/chirps_v2_monthly_stack.tif")) as s:
    chirps = s.read().astype(float); chirps[chirps < 0] = np.nan; desc = list(s.descriptions); ctr = s.transform; ccrs = s.crs
def window_rain(gid):
    gj = json.loads(B.open_cube(gid).attrs["grid"]); x0, y0, x1, y1 = gj["bounds"]
    lo0, la0, lo1, la1 = transform_bounds("EPSG:32643", ccrs, x0, y0, x1, y1)
    c0, r0 = ~ctr * (lo0, la1); c1, r1 = ~ctr * (lo1, la0)
    sub = chirps[:, int(np.floor(r0)):int(np.ceil(r1)), int(np.floor(c0)):int(np.ceil(c1))]
    return pd.Series(np.nanmean(sub, axis=(1, 2)), index=pd.to_datetime([d[-7:] for d in desc]))
res = {}; rows = []
for gid in W:
    ds = B.open_cube(gid); years = ds.year.values; r = {}
    with rasterio.open(config.path("data/labels", gid, "jrc_gsw.tif")) as s: occ = s.read(1).astype(float)
    occ[occ == 255] = np.nan
    wd, vd = SW.water_masks(ds, "dry"); wp, vp = SW.water_masks(ds, "post")
    i0, i1 = list(years).index(1990), list(years).index(2020)
    pers = wd[i0:i1 + 1].sum(0) / np.maximum(vd[i0:i1 + 1].sum(0), 1); f = np.isfinite(occ) & ((occ > 0) | (pers > 0))
    r["persistence_vs_jrc_spearman"] = float(spearmanr(pers[f], occ[f])[0]) if f.sum() > 50 else None
    r["jrc_permanent_recall_dry"] = {int(y): float(wd[i][occ >= 90].mean()) for i, y in enumerate(years)} if (occ >= 90).any() else None
    r["false_water_rate_on_jrc0"] = {int(y): float(wd[i][(occ == 0)].mean()) for i, y in enumerate(years)}
    lab, keep, sizes = SW.reservoirs(gid); rain = window_rain(gid)
    mons = rain[rain.index.month.isin([6, 7, 8, 9])].groupby(rain[rain.index.month.isin([6, 7, 8, 9])].index.year).sum()
    rr = {}
    for k in keep:
        m = lab == k; cy, cx = [float(v.mean()) for v in np.nonzero(m)]
        x = float(ds.x.values[int(cx)]); y = float(ds.y.values[int(cy)])
        ad = np.array([wd[i][m].sum() * 0.0009 if vd[i][m].mean() > 0.9 else np.nan for i in range(len(years))])
        ap = np.array([wp[i][m].sum() * 0.0009 if vp[i][m].mean() > 0.9 else np.nan for i in range(len(years))])
        mon = mons.reindex(years).values; prev = mons.reindex(years - 1).values
        def rho(a, b):
            f_ = np.isfinite(a) & np.isfinite(b); return (float(spearmanr(a[f_], b[f_])[0]), int(f_.sum())) if f_.sum() >= 10 else (None, int(f_.sum()))
        rr[f"res{k}"] = {"jrc_max_extent_km2": sizes[k], "centroid_utm": [x, y], "area_dry_km2": dict(zip(map(int, years), np.round(ad, 3).tolist())),
                         "area_post_km2": dict(zip(map(int, years), np.round(ap, 3).tolist())),
                         "trend_dry": SW.sens_slope(years.astype(float), ad), "trend_post": SW.sens_slope(years.astype(float), ap),
                         "rho_post_vs_same_monsoon": rho(ap, mon), "rho_dry_vs_previous_monsoon": rho(ad, prev), "rho_dry_vs_same_year_monsoon_(placebo)": rho(ad, mon)}
        for i, y in enumerate(years): rows.append({"window": gid, "reservoir": f"res{k}", "year": int(y), "area_dry_km2": ad[i], "area_post_km2": ap[i], "monsoon_rain_mm": mon[i] if i < len(mon) else np.nan})
    r["reservoirs"] = rr
    if gid.endswith("khadakwasla_mutha"):
        acc = SW.main_stem(gid, 0)
        with rasterio.open(config.path("data/features/terrain", gid, "terrain.tif")) as s: fa = s.read(list(s.descriptions).index("flow_acc_km2") + 1)
        stem = fa >= 0.5 * np.nanmax(fa); stem &= ~(occ >= 50)                  # main stem below the reservoir (exclude lake)
        wid = {}
        for yy in (1990, 2000, 2010, 2020, 2025):
            i = list(years).index(yy); w = SW.river_width(wd[i], stem); ws = np.array([t["width_m"] for t in w])
            wid[yy] = {"n_transects": len(w), "median_width_m": float(np.median(ws)) if ws.size else None, "share_zero_width": float((ws == 0).mean()) if ws.size else None}
        r["river_width_main_stem_dry"] = wid; r["river_stem_cells"] = int(stem.sum())
    res[gid] = r; print(gid, json.dumps({k: v for k, v in r.items() if k in ("persistence_vs_jrc_spearman", "river_width_main_stem_dry")}),
                       {k: (v["jrc_max_extent_km2"], v["trend_post"]["sen_slope_per_year"], v["rho_post_vs_same_monsoon"], v["rho_dry_vs_previous_monsoon"]) for k, v in r["reservoirs"].items()}, flush=True)
pd.DataFrame(rows).to_csv(out / "reservoir_area_series.csv", index=False); json.dump(res, open(out / "water_summary.json", "w"), indent=1, default=str)
e.finish(res, result="see results/water/water_summary.json", outputs={"series": "results/water/reservoir_area_series.csv"})
