"""Phase-4 existing-product benchmark (exploratory, descriptive; registered in registry4 before running).
P4-X1 district inter-product benchmark: L1 class shares per product-year, built-up area trajectories (WSF, GISA 2.0, GLC_FCS30D impervious, GHSL, ESA CCI, Esri, WorldCover),
      pairwise spatial agreement, temporal consistency (year-to-year L1 change rate), consensus / disagreement maps.
P4-X2 our Phase-3 reconstruction (P3-F3, 3 windows) vs the products: per-epoch class shares, built share, pixel agreement.
No product is treated as truth. Class definitions differ (impervious vs settlement vs built-up land cover) and are mapped explicitly (L1 crosswalks below)."""
import json, sys, warnings
import numpy as np, pandas as pd, rasterio
sys.path.insert(0, "src"); warnings.filterwarnings("ignore")
from pune_eo import config
from pune_eo.grid import district_grid
from pune_eo.io import write_cog
from pune_eo.evaluation4 import protocol as P4, history as HI
PX = config.path("data/products_ext"); LB = config.path("data/labels/pune_G30"); OUT = config.path("results/phase4/benchmark"); OUT.mkdir(parents=True, exist_ok=True); G = district_grid("G30")
L1N = {1: "built_up", 2: "agriculture", 3: "natural_vegetation", 4: "water", 5: "bare_sparse", 6: "other"}
GLC_L1 = {10: 2, 11: 2, 12: 2, 20: 2, **{c: 3 for c in (51, 52, 61, 62, 71, 72, 81, 82, 91, 92, 120, 121, 122, 130, 140)}, 150: 5, 152: 5, 153: 5, **{c: 6 for c in range(181, 188)}, 190: 1, 200: 5, 201: 5, 202: 5, 210: 4, 220: 6}
CCI_L1 = {10: 2, 11: 2, 12: 2, 20: 2, 30: 2, 40: 3, **{c: 3 for c in (50, 60, 61, 62, 70, 71, 72, 80, 81, 82, 90, 100, 110, 120, 121, 122, 130, 140)}, 150: 5, 151: 5, 152: 5, 153: 5, 160: 6, 170: 6, 180: 6, 190: 1, 200: 5, 201: 5, 202: 5, 210: 4, 220: 6}
cw = config.load("labels")["crosswalks"]
def l1(a, table):
    lut = np.zeros(256, np.uint8)
    for k, v in table.items(): lut[int(k)] = v
    return lut[a]
def rd(p, b=1):
    with rasterio.open(p) as s: return s.read(b)
def descs(p):
    with rasterio.open(p) as s: return [int(d) for d in s.descriptions]
for eid, hyp, fam in (("P4-X1", "existing products disagree substantially on Pune built-up history and class shares; disagreement concentrates in specific landscapes", "benchmark"),
                      ("P4-X2", "the Phase-3 reconstruction (P3-F3) departs from the independent products most in the early era", "benchmark")):
    if P4.load(eid) is None:
        P4.register(experiment_id=eid, kind="exploratory", family=fam, hypothesis=hyp, comparator="products against each other (X1); P3-F3 vs products (X2)", primary_metric="area share differences, pairwise agreement",
                    direction="descriptive", threshold="none (exploratory)", dataset_version="data/products_ext v1", evaluation_set="district (X1) / 3 windows (X2)", region="Pune District", years="1985-2023",
                    features="-", labels="none (products only)", label_tier="B/C", model="none / P3-F3", seeds=[], splits="none", metrics_planned=["class shares", "built area km2", "pairwise F1/Jaccard", "L1 agreement", "year-to-year change rate"])
mask = rd(PX / "district/district_mask_30m.tif").astype(bool); A = 0.0009; R = {"district_area_km2": float(mask.sum() * A)}
run = P4.Run("P4-X1")
# ---------- class shares per product-year
shares = []
fglc = PX / "glc_fcs30d/glc_fcs30d_district_30m.tif"; gy = descs(fglc); glc_l1 = {}
for i, y in enumerate(gy, 1):
    a = l1(rd(fglc, i), GLC_L1); glc_l1[y] = a; v = mask & (a > 0)
    shares.append({"product": "GLC_FCS30D", "year": y, "valid_share": float(v.sum() / mask.sum()), **{L1N[k]: float(((a == k) & v).sum() / v.sum()) for k in L1N}})
for prod, f, table in (("Esri", PX / "esri/esri_district_30m_mode.tif", cw["esri_lulc"]), ("WorldCover", PX / "worldcover/worldcover_district_30m_mode.tif", cw["esa_worldcover"])):
    for i, y in enumerate(descs(f), 1):
        a = l1(rd(f, i), table); v = mask & (a > 0); shares.append({"product": prod, "year": y, "valid_share": float(v.sum() / mask.sum()), **{L1N[k]: float(((a == k) & v).sum() / v.sum()) for k in L1N}})
        if prod == "Esri": glc_l1.setdefault(("esri", y), a)
        else: glc_l1.setdefault(("wc", y), a)
fcci = PX / "esa_cci_lc/esa_cci_lc_district_300m.tif"; m300 = mask[:(mask.shape[0] // 10) * 10, :(mask.shape[1] // 10) * 10].reshape(mask.shape[0] // 10, 10, mask.shape[1] // 10, 10).mean((1, 3)) >= 0.5
for i, y in enumerate(descs(fcci), 1):
    a = l1(rd(fcci, i), CCI_L1)[:m300.shape[0], :m300.shape[1]]; v = m300 & (a > 0); shares.append({"product": "ESA_CCI_300m", "year": y, "valid_share": float(v.sum() / m300.sum()), **{L1N[k]: float(((a == k) & v).sum() / v.sum()) for k in L1N}})
S = pd.DataFrame(shares); S.to_csv(OUT / "class_shares_by_product_year.csv", index=False)
# ---------- built-up trajectories (km2 inside the district)
wsf = rd(LB / "wsf_evolution_first_year.tif"); gisa = rd(PX / "gisa/gisa2_first_year_district_30m.tif")
with rasterio.open(LB / "ghsl_built_fraction_90m.tif") as s: gh = s.read().astype(float); gh[gh < 0] = np.nan; ghe = [int(d.split("_")[-1]) for d in s.descriptions]
m90 = mask[:(mask.shape[0] // 3) * 3, :(mask.shape[1] // 3) * 3].reshape(mask.shape[0] // 3, 3, mask.shape[1] // 3, 3).mean((1, 3)); m90 = m90[:gh.shape[1], :gh.shape[2]]
traj = {"WSF_Evolution_settlement": {y: float(((wsf > 0) & (wsf <= y) & mask).sum() * A) for y in range(1985, 2016)},
        "GISA2_impervious": {y: float(((gisa > 0) & (gisa <= y) & mask).sum() * A) for y in [1985] + list(range(1986, 2022))},
        "GLC_FCS30D_impervious": {y: float(((glc_l1[y] == 1) & mask).sum() * A) for y in gy},
        "GHSL_BUILT_S_surface": {e: float(np.nansum(gh[i] * m90) * 0.0081) for i, e in enumerate(ghe)},
        "ESA_CCI_urban_300m": {int(r.year): float(r.built_up * R["district_area_km2"]) for r in S[S["product"] == "ESA_CCI_300m"].itertuples()},
        "Esri_built": {int(r.year): float(r.built_up * R["district_area_km2"]) for r in S[S["product"] == "Esri"].itertuples()},
        "WorldCover_built": {int(r.year): float(r.built_up * R["district_area_km2"]) for r in S[S["product"] == "WorldCover"].itertuples()}}
R["built_trajectories_km2"] = traj; R["built_plausibility"] = {k: HI.built_plausibility(v) for k, v in traj.items()}
# ---------- pairwise built agreement at 30 m (common years)
pairs = {}
for y in (1990, 2000, 2010, 2015):
    B = {"WSF": (wsf > 0) & (wsf <= y), "GISA": (gisa > 0) & (gisa <= y), "GLC": glc_l1[min(gy, key=lambda z: abs(z - y))] == 1}
    for a in B:
        for b in B:
            if a < b:
                x, z = B[a] & mask, B[b] & mask; inter = (x & z).sum(); uni = (x | z).sum()
                pairs[f"{y}|{a}~{b}"] = {"jaccard": float(inter / max(uni, 1)), "f1": float(2 * inter / max(x.sum() + z.sum(), 1)), "area_ratio": float(x.sum() / max(z.sum(), 1))}
R["built_pairwise_30m"] = pairs
# ---------- L1 agreement 2020 (GLC vs Esri vs WorldCover) + consensus / disagreement map
g20, e20, w20 = glc_l1[2020], glc_l1[("esri", 2020)], glc_l1[("wc", 2020)]; v = mask & (g20 > 0) & (e20 > 0) & (w20 > 0)
agree = lambda a, b: float(((a == b) & v).sum() / v.sum())
R["l1_agreement_2020"] = {"GLC~Esri": agree(g20, e20), "GLC~WorldCover": agree(g20, w20), "Esri~WorldCover": agree(e20, w20), "all_three": float(((g20 == e20) & (e20 == w20) & v).sum() / v.sum()),
                          "per_class_glc_vs_esri": {L1N[k]: float(((g20 == k) & (e20 == k) & v).sum() / max((((g20 == k) | (e20 == k)) & v).sum(), 1)) for k in (1, 2, 3, 4, 5)}}
ncls = (g20 == e20).astype(np.uint8) + (e20 == w20) + (g20 == w20)
cons_map = np.where(~mask, 0, np.where((g20 == e20) & (e20 == w20), 1, np.where(ncls >= 1, 2, 3))).astype(np.uint8)      # 1 all agree, 2 two agree, 3 none agree
write_cog(OUT / "l1_consensus_2020_30m.tif", cons_map, G, nodata=0, dtype="uint8", descriptions=["1_all_agree_2_two_agree_3_none"], overview_resampling="nearest")
bc = ((wsf > 0) & (wsf <= 2015)).astype(np.uint8) + ((gisa > 0) & (gisa <= 2015)) + (glc_l1[2015] == 1)
write_cog(OUT / "built_votes_2015_30m.tif", np.where(mask, bc + 1, 0).astype(np.uint8), G, nodata=0, dtype="uint8", descriptions=["1+votes_WSF_GISA_GLC_2015"], overview_resampling="nearest")
R["built_votes_2015_share_of_any_built"] = {str(k): float(((bc == k) & mask).sum() / max(((bc > 0) & mask).sum(), 1)) for k in (1, 2, 3)}
R["consensus_2020_share"] = {"all_agree": float((cons_map == 1).sum() / mask.sum()), "two_agree": float((cons_map == 2).sum() / mask.sum()), "none_agree": float((cons_map == 3).sum() / mask.sum())}
# disagreement by landscape (rainfall zone / slope from the validation-design layers if present)
st = config.path("data/labels/gold/phase4/sampling_design/strata_30m.tif")
if st.exists():
    s_ = rd(st); names = json.load(open(config.path("data/labels/gold/phase4/sampling_design/design.json")))["strata_priority_order"]
    R["no_full_consensus_share_by_stratum"] = {names[i - 1]: float(((cons_map > 1) & (s_ == i)).sum() / max((s_ == i).sum(), 1)) for i in range(1, len(names) + 1)}
# ---------- temporal consistency: year-to-year L1 change share (annual products)
def yy(series):
    ks = sorted(series); return {f"{a}-{b}": float(((series[a] != series[b]) & mask & (series[a] > 0) & (series[b] > 0)).sum() / mask.sum()) for a, b in zip(ks[:-1], ks[1:])}
R["year_to_year_change_share"] = {"GLC_FCS30D": yy({y: glc_l1[y] for y in gy if y >= 2000}), "Esri": yy({y: glc_l1[("esri", y)] for y in descs(PX / "esri/esri_district_30m_mode.tif")})}
json.dump(R, open(OUT / "district_benchmark.json", "w"), indent=1, default=float)
run.complete({k: R[k] for k in ("l1_agreement_2020", "consensus_2020_share", "built_votes_2015_share_of_any_built", "built_plausibility")}, "NA",
             f"2020 L1 agreement GLC~Esri {R['l1_agreement_2020']['GLC~Esri']:.2f}, GLC~WorldCover {R['l1_agreement_2020']['GLC~WorldCover']:.2f}, Esri~WorldCover {R['l1_agreement_2020']['Esri~WorldCover']:.2f}; all three agree on "
             f"{R['l1_agreement_2020']['all_three']:.0%} of the district; built 2015: of cells any product calls built, {R['built_votes_2015_share_of_any_built']['3']:.0%} are called built by all of WSF/GISA/GLC",
             outputs={"summary": "results/phase4/benchmark/district_benchmark.json"})
print("X1", R["l1_agreement_2020"], R["consensus_2020_share"], R["built_votes_2015_share_of_any_built"])
# ---------- P4-X2 our P3-F3 product vs products inside the windows
run = P4.Run("P4-X2"); X2 = {}
for w in ("pune_G30_khadakwasla_mutha", "pune_G30_baramati_agri", "pune_G30_mulshi_ghats"):
    with rasterio.open(config.path("results/phase3/product", w, "recon_2000.tif")) as s: wt = s.transform; wh, ww = s.height, s.width
    c0 = int(round((wt.c - G.x0) / 30)); r0 = int(round((G.y1 - wt.f) / 30)); sl = (slice(r0, r0 + wh), slice(c0, c0 + ww)); X2[w] = {}
    for y in (1990, 1995, 2000, 2005, 2010, 2015, 2020, 2022):
        with rasterio.open(config.path("results/phase3/product", w, f"recon_{y}.tif")) as s: ours = s.read(5)
        g = glc_l1[y][sl] if y in glc_l1 else None; v = (ours > 0) & (g > 0) if g is not None else None
        X2[w][y] = {"ours_built_share": float((ours == 1).mean()), "glc_built_share": float((g == 1).mean()) if g is not None else None,
                    "wsf_built_share": float(((wsf[sl] > 0) & (wsf[sl] <= y)).mean()) if y <= 2015 else None, "gisa_built_share": float(((gisa[sl] > 0) & (gisa[sl] <= y)).mean()),
                    "ours_class_shares": {L1N[k]: float((ours == k).mean()) for k in (1, 2, 3, 4)}, "glc_class_shares": {L1N[k]: float((g == k).mean()) for k in (1, 2, 3, 4, 5)} if g is not None else None,
                    "pixel_agreement_vs_glc_4class": float(((ours == g) & v).sum() / v.sum()) if g is not None else None}
json.dump(X2, open(OUT / "p3f3_vs_products_windows.json", "w"), indent=1, default=float)
run.complete({w: {y: {k: v for k, v in d.items() if "class_shares" not in k} for y, d in X2[w].items()} for w in X2}, "NA",
             "P3-F3 vs GLC_FCS30D 4-class pixel agreement by epoch: " + "; ".join(f"{w[9:]} " + ", ".join(f"{y}:{d['pixel_agreement_vs_glc_4class']:.2f}" for y, d in X2[w].items() if d["pixel_agreement_vs_glc_4class"] is not None) for w in X2),
             outputs={"summary": "results/phase4/benchmark/p3f3_vs_products_windows.json"})
print("X2 done")
