"""Phase-3 group D (drought / normal / wet robustness) — pre-registered P3-D1..D3. Evaluation strata of the B (temporal) and C (fusion) predictions.
Climate class of year t = SPI-12 at September of t-1 (gamma, 1991-2020 baseline; McKee +-1), sensitivity with +-0.5 (configs/phase3.yaml).
Per TEST-block cell: mean false built-up (never-settled cells) / built recall (stable-built cells) over that window's dry, normal and wet years.
Because dry years cluster in 1996-2004 (Landsat-5/7 era, SLC-off from 2003), the dry-normal contrast is also computed ERA-MATCHED:
within each era that contains both classes, (dry mean - normal mean), averaged over eras weighted by number of dry years. Block bootstrap over 3 km blocks.
D2 hypothesis (joint): (i) the single-date baseline degrades in dry years (era-matched dFBR > 0, CI excludes 0) and (ii) a temporal model
reduces the degradation (paired difference of the degradations, CI excludes 0). D3 the same for wet years. D1 (normal) = reference levels.
Association only: climate class is a proxy for surface condition, no causal claim."""
import json, sys, warnings
import numpy as np, pandas as pd
sys.path.insert(0, "src"); warnings.filterwarnings("ignore")
from pune_eo import config
from pune_eo.historical_reconstruction import het
from pune_eo.validation import registry3 as R3
from pune_eo.validation.stats3 import block_bootstrap_diff
H = het.load(); M = H["meta"]; YEARS = np.array(H["info"]["years"]); SY = np.array(H["info"]["syears"]); CL = H["climate"]; OUT = config.path("results/phase3/climate"); OUT.mkdir(parents=True, exist_ok=True)
ERAS = {"early_historical": (1990, 1998), "landsat_dominant": (1999, 2014), "sentinel_dense": (2015, 2021), "current": (2022, 2026)}
TD, FD = config.path("results/phase3/temporal"), config.path("results/phase3/fusion")
ev = np.load(TD / "eval_cells.npy"); mm = M.iloc[ev].reset_index(drop=True)
models = {p.stem[5:]: (np.load(p), YEARS) for p in sorted(TD.glob("pred_P3-*.npy"))}
if (FD / "eval_cells.npy").exists():
    assert (np.load(FD / "eval_cells.npy") == ev).all()
    models.update({p.stem[10:]: (np.load(p), SY) for p in sorted(FD.glob("pred_hist_P3-*.npy"))})
era_of = lambda y: next(e for e, (a, b) in ERAS.items() if a <= y <= b)
def cell_rates(P, yrs, kind, ccol, cls):
    """per eval cell: mean(pred==built) over years of climate class `cls` (NaN where not applicable); also era-wise."""
    out = np.full(len(ev), np.nan); era = {e: np.full(len(ev), np.nan) for e in ERAS}
    for g in mm.window.unique():
        c = CL[CL.window == g].set_index("year")[ccol].reindex(yrs).values; w = (mm.window == g).values & mm[kind].values
        k = c == cls
        if k.any() and w.any(): out[w] = (P[w][:, k] == 1).mean(1)
        for e, (a, b) in ERAS.items():
            ke = k & (yrs >= a) & (yrs <= b)
            if ke.any() and w.any(): era[e][w] = (P[w][:, ke] == 1).mean(1)
    return out, era
def ndry(g, ccol, cls, yrs, e): c = CL[CL.window == g].set_index("year")[ccol].reindex(yrs).values; a, b = ERAS[e]; return int(((c == cls) & (yrs >= a) & (yrs <= b)).sum())
def contrast(P, yrs, kind, ccol, cls):
    """era-matched (cls - normal) per cell, weights = number of `cls` years in each era (per window)."""
    a, ea = cell_rates(P, yrs, kind, ccol, cls); b, eb = cell_rates(P, yrs, kind, ccol, "normal"); num = np.zeros(len(ev)); den = np.zeros(len(ev))
    for e in ERAS:
        nd = {g: ndry(g, ccol, cls, yrs, e) for g in mm.window.unique()}; wts = mm.window.map(nd).values.astype(float)
        ok = np.isfinite(ea[e]) & np.isfinite(eb[e]); num[ok] += wts[ok] * (ea[e][ok] - eb[e][ok]); den[ok] += wts[ok]
    return a - b, np.where(den > 0, num / np.maximum(den, 1e-9), np.nan)
R = {}
for ccol in ("climate_class", "climate_class_05"):
    R[ccol] = {}
    for name, (P, yrs) in models.items():
        r = {}
        for kind in ("never_settled", "stable_built"):
            lv = {c: cell_rates(P, yrs, kind, ccol, c)[0] for c in ("dry", "normal", "wet")}
            r[kind] = {"levels_by_window": {g[9:]: {c: (float(np.nanmean(lv[c][(mm.window == g).values])) if np.isfinite(lv[c][(mm.window == g).values]).any() else None) for c in lv} for g in mm.window.unique()}}
            for cls in ("dry", "wet"):
                raw, em = contrast(P, yrs, kind, ccol, cls)
                for lab_, v in (("raw", raw), ("era_matched", em)):
                    ok = np.isfinite(v)
                    r[kind][f"{cls}_minus_normal_{lab_}"] = block_bootstrap_diff(lambda i, v=v[ok]: float(np.mean(v[i])), mm.block.values[ok]) if ok.sum() > 50 else None
        R[ccol][name] = r
# paired: does a temporal model reduce the (era-matched) dry degradation vs its single-date base?
def paired(a, b, cls, ccol="climate_class", kind="never_settled"):
    _, ea = contrast(*models[a], kind, ccol, cls); _, eb = contrast(*models[b], kind, ccol, cls); ok = np.isfinite(ea) & np.isfinite(eb)
    return block_bootstrap_diff(lambda i: float(np.mean(ea[ok][i] - eb[ok][i])), mm.block.values[ok]) if ok.sum() > 50 else None
PAIRS = [("P3-B4", "P3-B1"), ("P3-B4m", "P3-B1m"), ("P3-B5m@v2", "P3-B1m"), ("P3-B4t", "P3-B1m"), ("P3-B3", "P3-B1"), ("P3-B2", "P3-B1")]
R["paired_degradation"] = {cls: {f"{a}_vs_{b}": paired(a, b, cls) for a, b in PAIRS if a in models and b in models} for cls in ("dry", "wet")}
s1 = {k: R["climate_class"][k]["never_settled"]["levels_by_window"] for k in models if k.startswith("P3-C")}
R["s1_era_note"] = "S1 era (2017-2025) has ONE dry year (2019, khadakwasla_mutha only): C-model drought contrasts are descriptive, not tests."; R["s1_era_levels"] = s1
json.dump(R, open(OUT / "climate_summary.json", "w"), indent=1, default=float)
def verdict(cls):
    base = R["climate_class"].get("P3-B1", {}).get("never_settled", {}).get(f"{cls}_minus_normal_era_matched"); pr = [v for v in R["paired_degradation"][cls].values() if v]
    i_ok = bool(base and base["estimate"] > 0 and base["excludes_zero"]); red = any(v["estimate"] < 0 and v["excludes_zero"] for v in pr); inc = any(v["estimate"] > 0 and v["excludes_zero"] for v in pr)
    if not i_ok: return "NOT_SUPPORTED", base, pr          # premise (baseline degrades) not shown
    if red: return "SUPPORTED", base, pr
    return ("NOT_SUPPORTED" if inc else "INCONCLUSIVE"), base, pr
fmt = lambda d: f"{d['estimate']:+.4f} [{d['ci95'][0]:+.4f},{d['ci95'][1]:+.4f}]" if d else "n/a"
R3.Run("P3-D1").complete({k: {kk: R["climate_class"][k][kk]["levels_by_window"] for kk in ("never_settled", "stable_built")} for k in models}, "NA",
                         "normal-year FBR (B1) " + json.dumps({g: (round(v["normal"], 3) if v["normal"] is not None else None) for g, v in R["climate_class"]["P3-B1"]["never_settled"]["levels_by_window"].items()}),
                         outputs={"summary": "results/phase3/climate/climate_summary.json"})
for eid, cls in (("P3-D2", "dry"), ("P3-D3", "wet")):
    o, base, pr = verdict(cls)
    R3.Run(eid).complete({"B1_era_matched": base, "B1_raw": R["climate_class"]["P3-B1"]["never_settled"][f"{cls}_minus_normal_raw"], "paired_degradation": R["paired_degradation"][cls],
                          "sensitivity_pm05_B1_era_matched": R["climate_class_05"]["P3-B1"]["never_settled"][f"{cls}_minus_normal_era_matched"]}, o,
                         f"B1 {cls}-normal FBR era-matched {fmt(base)} (raw {fmt(R['climate_class']['P3-B1']['never_settled'][f'{cls}_minus_normal_raw'])}); " +
                         "; ".join(f"{k} change in degradation {fmt(v)}" for k, v in R["paired_degradation"][cls].items()))
    print(eid, o, fmt(base), flush=True)
