"""Build the feature cube (Zarr) for each benchmark window. Usage: python3 scripts/build_cubes.py [windows]"""
import sys, json
sys.path.insert(0, "src")
from pune_eo.compositing.windows import resolve
from pune_eo.feature_engineering.cube import build_cube
for w in (sys.argv[1].split(",") if len(sys.argv) > 1 else ["khadakwasla_mutha", "baramati_agri", "mulshi_ghats"]):
    g, win, wn = resolve("G30", w); sub = g.subgrid(win, f"_{wn}")
    m = build_cube(sub); print(json.dumps({"window": sub.id, "shape": m["shape"], "seconds": m["seconds"],
          "min_dry_valid": min(m["valid_fraction_landsat_dry_ndvi"].values())}), flush=True)
