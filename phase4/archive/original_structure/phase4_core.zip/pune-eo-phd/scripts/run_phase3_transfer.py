"""Phase-3 groups E (spatial transfer), J1 (domain shift), J2 (domain adaptation) — pre-registered P3-E1..E3, E1r..E3r, E4, J1, J2.
Labels: silver 2021 (Tier C). Model: XGBoost (Phase-2 hyperparameters, one seed). Feature sets: B1, B3, B4, C3, C4 (+ terrain = 'B3T' for J).
within(S)  = trained on S train blocks (early stopping on S val blocks) -> S TEST blocks
cross(S,T) = same model -> ALL silver cells of T            ;  E4: trained on two windows -> held-out window (all silver cells)
Hypothesis per pair (joint): (i) cross < within for B3 (independent block bootstraps, CI of the difference excludes 0) AND
(ii) temporal (B4-B1) or SAR (C3-B3) raises cross macro-F1 on the same target cells (paired block bootstrap CI > 0).
J2 targets = each held-out window; evaluated on target TEST blocks; few-shot labels drawn only from target TRAIN blocks."""
import json, sys, time, warnings
import numpy as np, pandas as pd
from sklearn.metrics import f1_score, roc_auc_score
from scipy.stats import ks_2samp, spearmanr
sys.path.insert(0, "src"); warnings.filterwarnings("ignore")
from pune_eo import config
from pune_eo.historical_reconstruction import het, features as F
from pune_eo.classification import baseline as B
from pune_eo.calibration import metrics as CM
from pune_eo.validation import registry3 as R3
from pune_eo.validation.stats3 import block_bootstrap_diff
H = het.load(); M = H["meta"]; SEED = 20261028; OUT = config.path("results/phase3/transfer"); OUT.mkdir(parents=True, exist_ok=True)
WIN = ["pune_G30_khadakwasla_mutha", "pune_G30_baramati_agri", "pune_G30_mulshi_ghats"]; SH = {w: w[9:] for w in WIN}
sil = M.silver.between(1, 4).values; yv = M.silver.values; split = M.split.values; win = M.window.values; blk = M.block.values
CLN = ["built_up", "agriculture", "natural_vegetation", "water"]; FS = ["B1", "B3", "B4", "C3", "C4"]
mf1 = lambda y, p: float(f1_score(y, p, labels=[1, 2, 3, 4], average="macro"))
def X_(fs, cells):
    if fs == "B3T": X, _ = F.build(H, "B3", 2021, cells); return np.hstack([X, H["T"][cells]])
    if fs == "B4S": return np.hstack([F.build(H, "B4", 2021, cells)[0], F.build(H, "C2", 2021, cells)[0], H["T"][cells]])   # multimodal-temporal (P3-E5, Gate 4)
    return F.build(H, fs, 2021, cells)[0]
class Fitted:
    """XGBoost trained on the classes present in the source; predict_proba always returns the 4 model classes (absent class -> probability 0).
    A source without a class (Baramati has no natural_vegetation silver cells) cannot predict it - a label-space shift, reported as such."""
    def __init__(s, m, present): s.m, s.present = m, present
    def predict_proba(s, X): out = np.zeros((len(X), 4)); out[:, [c - 1 for c in s.present]] = s.m.predict_proba(X); return out
def fit(fs, tr, va, Xtr=None, ytr=None, w=None):
    Xtr = X_(fs, tr) if Xtr is None else Xtr; ytr = yv[tr] if ytr is None else ytr; present = sorted(set(ytr.tolist())); enc = {c: i for i, c in enumerate(present)}
    vk = np.isin(yv[va], present); m = B.make_model("xgb", SEED)
    m.fit(Xtr, np.vectorize(enc.get)(ytr), sample_weight=w, eval_set=[(X_(fs, va)[vk], np.vectorize(enc.get)(yv[va][vk]))], verbose=False); return Fitted(m, present)
def proba(m, fs, cells, X=None): return m.predict_proba(X_(fs, cells) if X is None else X)
lab = lambda p: np.asarray(B.CLASSES)[p.argmax(1)]
def report(y, p):
    yh = lab(p); f = f1_score(y, yh, labels=[1, 2, 3, 4], average=None); cm = np.array([[((y == a) & (yh == b)).sum() for b in range(1, 5)] for a in range(1, 5)])
    iou = np.diag(cm) / np.maximum(cm.sum(0) + cm.sum(1) - np.diag(cm), 1); present = [int((y == k).sum()) for k in range(1, 5)]
    cal = CM.all_metrics(p, y - 1)
    return {"macro_f1": mf1(y, yh), "per_class_f1": dict(zip(CLN, f.round(4).tolist())), "per_class_iou": dict(zip(CLN, iou.round(4).tolist())), "n_per_class": dict(zip(CLN, present)),
            "ece": cal["ece"], "brier": cal["brier"], "nll": cal["nll"], "confusion_rows_ref": cm.tolist(),
            "agri_to_natveg": int(cm[1, 2]), "natveg_to_agri": int(cm[2, 1]), "agri_to_built": int(cm[1, 0]), "built_to_agri": int(cm[0, 1])}
def indep_diff(ya, pa, ba, yb, pb, bb, n=1000, seed=SEED):
    """macro-F1(a) - macro-F1(b) for two DIFFERENT cell sets; blocks resampled independently in each."""
    rng = np.random.default_rng(seed); out = []
    ua, ia = np.unique(ba, return_inverse=True); ub, ib = np.unique(bb, return_inverse=True); ma = [np.flatnonzero(ia == i) for i in range(len(ua))]; mb = [np.flatnonzero(ib == i) for i in range(len(ub))]
    for _ in range(n):
        a = np.concatenate([ma[i] for i in rng.integers(0, len(ua), len(ua))]); b = np.concatenate([mb[i] for i in rng.integers(0, len(ub), len(ub))])
        out.append(mf1(ya[a], pa[a]) - mf1(yb[b], pb[b]))
    lo, hi = np.percentile(out, [2.5, 97.5]); return {"estimate": mf1(ya, pa) - mf1(yb, pb), "ci95": [float(lo), float(hi)], "excludes_zero": bool(lo > 0 or hi < 0)}
cells = lambda w, s=None: np.flatnonzero(sil & (win == w) & (True if s is None else (split == s)))
T0 = time.time(); within, cross, models = {}, {}, {}
for s in WIN:
    for fs in FS:
        m = fit(fs, cells(s, 1), cells(s, 2)); models[(s, fs)] = m; te = cells(s, 3); within[(s, fs)] = (te, proba(m, fs, te))
        for t in WIN:
            if t != s: ho = cells(t); cross[(s, t, fs)] = (ho, proba(m, fs, ho))
    print("source", SH[s], round(time.time() - T0), "s", flush=True)
PAIRS = {"P3-E1": (WIN[0], WIN[1]), "P3-E2": (WIN[1], WIN[2]), "P3-E3": (WIN[2], WIN[0]), "P3-E1r": (WIN[1], WIN[0]), "P3-E2r": (WIN[2], WIN[1]), "P3-E3r": (WIN[0], WIN[2])}
matrix = {}
for eid, (s, t) in PAIRS.items():
    run = R3.Run(eid); r = {"source": s, "target": t, "within": {}, "cross": {}}
    for fs in FS:
        te, pw = within[(s, fs)]; ho, pc = cross[(s, t, fs)]; r["within"][fs] = report(yv[te], pw); r["cross"][fs] = report(yv[ho], pc)
        matrix[f"{SH[s]}->{SH[t]}|{fs}"] = {"within": r["within"][fs]["macro_f1"], "cross": r["cross"][fs]["macro_f1"]}
    te, pw = within[(s, "B3")]; ho, pc = cross[(s, t, "B3")]
    r["gap_B3"] = indep_diff(yv[te], lab(pw), blk[te], yv[ho], lab(pc), blk[ho])
    yh = {fs: lab(cross[(s, t, fs)][1]) for fs in FS}; y_ = yv[ho]
    r["cross_B4_minus_B1"] = block_bootstrap_diff(lambda i: mf1(y_[i], yh["B4"][i]) - mf1(y_[i], yh["B1"][i]), blk[ho])
    r["cross_C3_minus_B3"] = block_bootstrap_diff(lambda i: mf1(y_[i], yh["C3"][i]) - mf1(y_[i], yh["B3"][i]), blk[ho])
    r["cross_C4_minus_B3"] = block_bootstrap_diff(lambda i: mf1(y_[i], yh["C4"][i]) - mf1(y_[i], yh["B3"][i]), blk[ho])
    i_ok = r["gap_B3"]["estimate"] > 0 and r["gap_B3"]["excludes_zero"]
    ii = [r[k] for k in ("cross_B4_minus_B1", "cross_C3_minus_B3")]; ii_ok = any(c["estimate"] > 0 and c["excludes_zero"] for c in ii)
    ii_neg = all(c["estimate"] <= 0 or not c["excludes_zero"] for c in ii) and any(c["excludes_zero"] for c in ii)
    outcome = "SUPPORTED" if (i_ok and ii_ok) else ("NOT_SUPPORTED" if (not i_ok and r["gap_B3"]["excludes_zero"]) or (i_ok and ii_neg) else "INCONCLUSIVE")
    msg = (f"{SH[s]}->{SH[t]}: B3 within {r['within']['B3']['macro_f1']:.3f} vs cross {r['cross']['B3']['macro_f1']:.3f} (gap {r['gap_B3']['estimate']:+.3f} [{r['gap_B3']['ci95'][0]:+.3f},{r['gap_B3']['ci95'][1]:+.3f}]); "
           f"cross B4-B1 {r['cross_B4_minus_B1']['estimate']:+.3f} [{r['cross_B4_minus_B1']['ci95'][0]:+.3f},{r['cross_B4_minus_B1']['ci95'][1]:+.3f}], C3-B3 {r['cross_C3_minus_B3']['estimate']:+.3f} [{r['cross_C3_minus_B3']['ci95'][0]:+.3f},{r['cross_C3_minus_B3']['ci95'][1]:+.3f}]")
    run.complete(r, outcome, msg, n_samples={"source_train": int(len(cells(s, 1))), "target_cells": int(len(ho))}); print(eid, msg, flush=True)
# ---------------- E4 two-source -> held-out
run = R3.Run("P3-E4"); e4 = {}; lowo = {}
for t in WIN:
    og = (win != t); tr = np.flatnonzero(sil & og & (split == 1)); va = np.flatnonzero(sil & og & (split == 2)); ho = cells(t); e4[t] = {}
    for fs in FS:
        m = fit(fs, tr, va); p = proba(m, fs, ho); lowo[(t, fs)] = (m, ho, p); e4[t][fs] = report(yv[ho], p)
    singles = {s: cross[(s, t, "B3")] for s in WIN if s != t}; y_ = yv[ho]; p2 = lab(lowo[(t, "B3")][2])
    e4[t]["two_minus_best_single_B3"] = max((block_bootstrap_diff(lambda i, ps=lab(pp): mf1(y_[i], p2[i]) - mf1(y_[i], ps[i]), blk[ho]) for _, (h_, pp) in singles.items()), key=lambda d: -d["estimate"])
k = sum(1 for t in WIN if e4[t]["two_minus_best_single_B3"]["estimate"] > 0 and e4[t]["two_minus_best_single_B3"]["excludes_zero"])
kn = sum(1 for t in WIN if e4[t]["two_minus_best_single_B3"]["estimate"] < 0 and e4[t]["two_minus_best_single_B3"]["excludes_zero"])
run.complete(e4, "SUPPORTED" if k >= 2 else ("NOT_SUPPORTED" if kn >= 1 or k == 0 else "INCONCLUSIVE"),
             "two-source B3 macro-F1 on held-out: " + ", ".join(f"{SH[t]} {e4[t]['B3']['macro_f1']:.3f} (vs best single {e4[t]['two_minus_best_single_B3']['estimate']:+.3f})" for t in WIN)); print("E4", {SH[t]: round(e4[t]["B3"]["macro_f1"], 3) for t in WIN}, flush=True)
# ---------------- E5 multimodal-temporal vs single-date on held-out windows (Gate 4)
run = R3.Run("P3-E5"); e5 = {}
for t in WIN:
    og = (win != t); tr = np.flatnonzero(sil & og & (split == 1)); va = np.flatnonzero(sil & og & (split == 2)); ho = cells(t)
    m = fit("B4S", tr, va); p = proba(m, "B4S", ho); y_ = yv[ho]; pb1 = lab(lowo[(t, "B1")][2]); pm = lab(p)
    e5[t] = {"B4S": report(y_, p), "B1_macro_f1": e4[t]["B1"]["macro_f1"], "diff_vs_B1": block_bootstrap_diff(lambda i: mf1(y_[i], pm[i]) - mf1(y_[i], pb1[i]), blk[ho])}
allpos = all(e5[t]["diff_vs_B1"]["estimate"] > 0 for t in WIN); nci = sum(1 for t in WIN if e5[t]["diff_vs_B1"]["estimate"] > 0 and e5[t]["diff_vs_B1"]["excludes_zero"])
e5["gate4_passed"] = bool(allpos and nci >= 2)
run.complete(e5, "SUPPORTED" if e5["gate4_passed"] else "NOT_SUPPORTED", "held-out macro-F1 B4+S1+terrain vs B1: " + "; ".join(f"{SH[t]} {e5[t]['B4S']['macro_f1']:.3f} vs {e5[t]['B1_macro_f1']:.3f} "
             f"({e5[t]['diff_vs_B1']['estimate']:+.3f} [{e5[t]['diff_vs_B1']['ci95'][0]:+.3f},{e5[t]['diff_vs_B1']['ci95'][1]:+.3f}])" for t in WIN)); print("E5", {SH[t]: round(e5[t]["B4S"]["macro_f1"], 3) for t in WIN}, flush=True)
# ---------------- J1 domain shift (B3 + terrain, 2021; S1 variant)
run = R3.Run("P3-J1"); rng = np.random.default_rng(SEED); j1 = {"pairs": {}}
def mmd2(A, Bm, nperm=200):
    Z = np.vstack([A, Bm]); d = ((Z[:, None] - Z[None]) ** 2).sum(-1); g = 1 / np.median(d[d > 0]); Kz = np.exp(-g * d); n = len(A)
    def stat(ix): a, b = ix[:n], ix[n:]; return Kz[np.ix_(a, a)].mean() + Kz[np.ix_(b, b)].mean() - 2 * Kz[np.ix_(a, b)].mean()
    s0 = stat(np.arange(len(Z))); perm = [stat(rng.permutation(len(Z))) for _ in range(nperm)]; return float(s0), float((1 + sum(p >= s0 for p in perm)) / (1 + nperm))
names = F.build(H, "B3", 2021, np.arange(2))[1] + H["info"]["tfeatures"]
for vname, fs in (("B3T", "B3T"), ("C3", "C3")):
    for a_i in range(3):
        for b_i in range(a_i + 1, 3):
            a, b = WIN[a_i], WIN[b_i]; ca, cb = cells(a), cells(b); Xa, Xb = X_(fs, ca), X_(fs, cb)
            fa = np.isfinite(Xa).all(1); fb = np.isfinite(Xb).all(1); sa = rng.choice(np.flatnonzero(fa), min(600, fa.sum()), replace=False); sb = rng.choice(np.flatnonzero(fb), min(600, fb.sum()), replace=False)
            mu, sd = np.vstack([Xa[sa], Xb[sb]]).mean(0), np.vstack([Xa[sa], Xb[sb]]).std(0) + 1e-9
            mm, p = mmd2((Xa[sa] - mu) / sd, (Xb[sb] - mu) / sd)
            # domain classifier with spatial (block) cross-validation
            Xd = np.vstack([Xa, Xb]); yd = np.r_[np.zeros(len(Xa)), np.ones(len(Xb))]; bd = np.r_[blk[ca], blk[cb]]; ub = np.unique(bd); fold = dict(zip(ub, rng.integers(0, 5, len(ub)))); fd = np.vectorize(fold.get)(bd)
            from xgboost import XGBClassifier
            pd_ = np.zeros(len(yd))
            for k_ in range(5):
                mdl = XGBClassifier(n_estimators=150, max_depth=4, learning_rate=0.1, n_jobs=2, random_state=SEED, tree_method="hist").fit(Xd[fd != k_], yd[fd != k_]); pd_[fd == k_] = mdl.predict_proba(Xd[fd == k_])[:, 1]
            fn = names if fs == "B3T" else F.build(H, "C3", 2021, np.arange(2))[1]
            ks = sorted(((fn[j], float(ks_2samp(Xa[:, j][np.isfinite(Xa[:, j])], Xb[:, j][np.isfinite(Xb[:, j])]).statistic)) for j in range(Xa.shape[1])), key=lambda z: -z[1])
            cc = {}
            for k_, cn in enumerate(CLN, 1):
                ia = np.flatnonzero(fa & (yv[ca] == k_)); ib = np.flatnonzero(fb & (yv[cb] == k_))
                if len(ia) > 50 and len(ib) > 50:
                    ia, ib = rng.choice(ia, min(300, len(ia)), replace=False), rng.choice(ib, min(300, len(ib)), replace=False); cc[cn] = mmd2((Xa[ia] - mu) / sd, (Xb[ib] - mu) / sd, nperm=100)
            j1["pairs"][f"{vname}|{SH[a]}~{SH[b]}"] = {"mmd2": mm, "mmd_perm_p": p, "domain_auc_blockcv": float(roc_auc_score(yd, pd_)), "ks_top10": ks[:10], "class_conditional_mmd2": cc}
            # error vs domain probability on the cross-window B3 predictions (both directions)
            if vname == "B3T":
                for s, t, pt in ((a, b, pd_[len(Xa):]), (b, a, 1 - pd_[:len(Xa)])):
                    ho, pc = cross[(s, t, "B3")]; err = (lab(pc) != yv[ho]).astype(float); rho = spearmanr(pt, err).correlation
                    q = pd.qcut(pt, 5, labels=False, duplicates="drop"); j1["pairs"][f"{vname}|{SH[a]}~{SH[b]}"][f"error_vs_target_prob_{SH[s]}->{SH[t]}"] = {"spearman": float(rho), "error_by_quintile": pd.Series(err).groupby(q).mean().round(4).tolist()}
phen = {"post_ndvi", "post_mndwi", "post_ndmi", "d_ndvi", "d_mndwi"}; terr = set(H["info"]["tfeatures"])
top5 = [f for k_, v in j1["pairs"].items() if k_.startswith("B3T") for f, _ in v["ks_top10"][:5]]; share = float(np.mean([f in phen | terr for f in top5]))
rhos = [v2["spearman"] for k_, v in j1["pairs"].items() if k_.startswith("B3T") for k2, v2 in v.items() if k2.startswith("error_vs")]
j1["summary"] = {"share_phenology_or_terrain_in_top5_KS": share, "expected_share_if_random": len(phen | terr) / len(names), "error_vs_domain_prob_spearman": rhos}
run.complete(j1, "SUPPORTED" if share >= 0.6 and np.mean(rhos) > 0.1 else ("NOT_SUPPORTED" if share < 0.4 or np.mean(rhos) <= 0 else "INCONCLUSIVE"),
             f"top-5 KS features phenology/terrain share {share:.2f} (random {j1['summary']['expected_share_if_random']:.2f}); error~domain-probability Spearman {np.round(rhos, 3).tolist()} (association, not cause); "
             + "; ".join(f"{k_}: MMD2 {v['mmd2']:.3f} p={v['mmd_perm_p']:.3f}, AUC {v['domain_auc_blockcv']:.3f}" for k_, v in j1["pairs"].items()))
print("J1", j1["summary"], flush=True)
# ---------------- J2 adaptation (B3T), each held-out target
run = R3.Run("P3-J2"); j2 = {}
def coral(Xs, Xt):
    med = np.nanmedian(np.vstack([Xs, Xt]), 0); Xs, Xt = np.where(np.isfinite(Xs), Xs, med), np.where(np.isfinite(Xt), Xt, med)
    def cov(X): return np.cov(X, rowvar=False) + np.eye(X.shape[1])
    def msqrt(C, inv=False): w_, V = np.linalg.eigh(C); w_ = np.clip(w_, 1e-6, None); return (V * (w_ ** (-0.5 if inv else 0.5))) @ V.T
    mu_s, mu_t = Xs.mean(0), Xt.mean(0); return (Xs - mu_s) @ msqrt(cov(Xs), True) @ msqrt(cov(Xt)) + mu_t, Xt
for t in WIN:
    og = win != t; tr = np.flatnonzero(sil & og & (split == 1)); va = np.flatnonzero(sil & og & (split == 2)); tte = cells(t, 3); ttr = cells(t, 1); ttr_all = np.flatnonzero((win == t) & (split == 1))
    y_ = yv[tte]; r = {}; Xs, Xtt, Xte = X_("B3T", tr), X_("B3T", ttr_all), X_("B3T", tte)
    base = fit("B3T", tr, va, Xs, yv[tr]); pb = base.predict_proba(Xte); r["none"] = report(y_, pb)
    own = fit("B3T", ttr, cells(t, 2)); r["target_supervised_reference"] = report(y_, own.predict_proba(Xte))
    gap = r["target_supervised_reference"]["macro_f1"] - r["none"]["macro_f1"]; r["gap"] = gap
    def add(name, p):
        r[name] = report(y_, p); yb, ya = lab(pb), lab(p)
        r[name]["vs_none"] = block_bootstrap_diff(lambda i: mf1(y_[i], ya[i]) - mf1(y_[i], yb[i]), blk[tte]); r[name]["gap_closed"] = float((r[name]["macro_f1"] - r["none"]["macro_f1"]) / gap) if gap > 0.005 else None
    for k_ in (25, 50, 100, 250):
        f1s = []
        for sd_ in range(3):
            rr = np.random.default_rng(SEED + sd_); pick = np.concatenate([rr.choice(ttr[yv[ttr] == c], min(k_, (yv[ttr] == c).sum()), replace=False) for c in range(1, 5) if (yv[ttr] == c).any()])
            trk = np.r_[tr, pick]; m = fit("B3T", trk, va, np.vstack([Xs, X_("B3T", pick)]), yv[trk]); p = m.predict_proba(Xte)
            if sd_ == 0: add(f"fewshot_{k_}", p)
            f1s.append(mf1(y_, lab(p)))
        r[f"fewshot_{k_}"]["macro_f1_3seeds"] = f1s
    Xs_c, Xtt_c = coral(Xs, Xtt); med = np.nanmedian(np.vstack([Xs, Xtt]), 0)
    m = B.make_model("xgb", SEED); enc = {c: i for i, c in enumerate(B.CLASSES)}; Xva_c = coral(X_("B3T", va), Xtt)[0]
    m.fit(Xs_c, np.vectorize(enc.get)(yv[tr]), eval_set=[(Xva_c, np.vectorize(enc.get)(yv[va]))], verbose=False); add("coral", m.predict_proba(np.where(np.isfinite(Xte), Xte, med)))
    from xgboost import XGBClassifier
    dc = XGBClassifier(n_estimators=150, max_depth=4, learning_rate=0.1, n_jobs=2, random_state=SEED, tree_method="hist").fit(np.vstack([Xs, Xtt]), np.r_[np.zeros(len(Xs)), np.ones(len(Xtt))])
    pt = np.clip(dc.predict_proba(Xs)[:, 1], 1e-3, 1 - 1e-3); wgt = np.clip(pt / (1 - pt) * len(Xs) / len(Xtt), 0.05, 20); wgt = wgt / wgt.mean()
    add("importance_weighting", fit("B3T", tr, va, Xs, yv[tr], w=wgt).predict_proba(Xte)); r["importance_weighting"]["weight_effective_n"] = float(wgt.sum() ** 2 / (wgt ** 2).sum())
    pu = base.predict_proba(Xtt); conf_ = pu.max(1) >= 0.9; Xst = np.vstack([Xs, Xtt[conf_]]); yst = np.r_[yv[tr], lab(pu)[conf_]]
    m = B.make_model("xgb", SEED); m.fit(Xst, np.vectorize(enc.get)(yst), eval_set=[(X_("B3T", va), np.vectorize(enc.get)(yv[va]))], verbose=False); add("self_training", m.predict_proba(Xte)); r["self_training"]["n_pseudo"] = int(conf_.sum())
    j2[t] = r; print("J2", SH[t], {k_: round(v["macro_f1"], 3) for k_, v in r.items() if isinstance(v, dict) and "macro_f1" in v}, flush=True)
fs_close = [j2[t][f"fewshot_{k_}"]["gap_closed"] for t in WIN for k_ in (100, 250) if j2[t][f"fewshot_{k_}"]["gap_closed"] is not None]
un_close = [j2[t][n]["gap_closed"] for t in WIN for n in ("coral", "importance_weighting") if j2[t][n]["gap_closed"] is not None]
j2["summary"] = {"fewshot_100_250_gap_closed": fs_close, "unsupervised_gap_closed": un_close}
ok = bool(fs_close) and np.median(fs_close) >= 0.5 and (not un_close or np.median(un_close) < np.median(fs_close))
run.complete(j2, "SUPPORTED" if ok else ("NOT_SUPPORTED" if fs_close and np.median(fs_close) < 0.25 else "INCONCLUSIVE"),
             "gap closed: few-shot(100/250) median " + (f"{np.median(fs_close):.2f}" if fs_close else "n/a") + ", CORAL/IW median " + (f"{np.median(un_close):.2f}" if un_close else "n/a") + "; " +
             "; ".join(f"{SH[t]} none {j2[t]['none']['macro_f1']:.3f}, target-supervised {j2[t]['target_supervised_reference']['macro_f1']:.3f}, few250 {j2[t]['fewshot_250']['macro_f1']:.3f}, coral {j2[t]['coral']['macro_f1']:.3f}, IW {j2[t]['importance_weighting']['macro_f1']:.3f}, self-train {j2[t]['self_training']['macro_f1']:.3f}" for t in WIN))
json.dump({"matrix": matrix, "E4": e4, "E5": e5, "J1": j1, "J2": j2}, open(OUT / "transfer_summary.json", "w"), indent=1, default=str)
print("done", round(time.time() - T0), "s")
