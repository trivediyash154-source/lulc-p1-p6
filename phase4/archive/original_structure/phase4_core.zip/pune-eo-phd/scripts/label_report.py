"""Silver-label sanity vs INDEPENDENT references + per-split class counts -> results/labels/label_report.json/.csv"""
import json, sys
import numpy as np, pandas as pd, rasterio
sys.path.insert(0, "src")
from pune_eo import config
W = ["pune_G30_khadakwasla_mutha", "pune_G30_baramati_agri", "pune_G30_mulshi_ghats"]
names = config.load("labels")["level1_classes"]; rows = []; sanity = {}
def rd(p, b=None):
    with rasterio.open(p) as s: return s.read(b) if b else s.read()
for w in W:
    d = config.path("data/labels", w)
    l1 = rd(d / "silver_l1.tif", 1); sp = rd(d / "splits.tif", 1); l2 = rd(d / "silver_l2.tif", 1)
    for s, sn in {1: "train", 2: "val", 3: "test"}.items():
        for c in range(1, 7): rows.append({"window": w, "split": sn, "class": names[c], "cells": int(((l1 == c) & (sp == s)).sum())})
        for c2, n2 in {11: "built_dense", 12: "built_low", 31: "tree", 32: "shrub_grass"}.items():
            rows.append({"window": w, "split": sn, "class": f"L2:{n2}", "cells": int(((l2 == c2) & (sp == s)).sum())})
    # GHSL 2020 built fraction (90 m) upsampled x3 by repetition onto G30
    gh = rd(d / "ghsl_built_fraction_90m.tif", 7); gh = np.repeat(np.repeat(gh, 3, 0), 3, 1)
    H, W_ = min(gh.shape[0], l1.shape[0]), min(gh.shape[1], l1.shape[1]); g = gh[:H, :W_]; L = l1[:H, :W_]
    jrc = rd(d / "jrc_gsw.tif", 1); wsf = rd(d / "wsf_evolution_first_year.tif", 1)
    def med(a, m): return float(np.median(a[m])) if m.any() else None
    sanity[w] = {"ghsl2020_built_frac_median": {names[c]: med(g, (L == c) & (g >= 0)) for c in (1, 2, 3, 4)},
                 "wsf_settled_by_2015_share": {names[c]: (float((wsf[l1 == c] > 0).mean()) if (l1 == c).any() else None) for c in (1, 2, 3, 4)},
                 "jrc_occurrence_ge50_share": {names[c]: (float(((jrc >= 50) & (jrc != 255))[l1 == c].mean()) if (l1 == c).any() else None) for c in (1, 2, 3, 4)}}
df = pd.DataFrame(rows); df.to_csv(config.path("results/labels/label_counts.csv"), index=False)
json.dump(sanity, open(config.path("results/labels/silver_vs_independent.json"), "w"), indent=1)
print(df.pivot_table(index="class", columns="split", values="cells", aggfunc="sum").to_string())
print(json.dumps(sanity, indent=1))
