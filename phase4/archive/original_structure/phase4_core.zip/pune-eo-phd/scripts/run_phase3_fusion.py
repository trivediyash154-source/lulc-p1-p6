"""Phase-3 group C (multimodal fusion, S1 era) — pre-registered P3-C1..C5. Identical XGBoost hyperparameters and seed for every set.
Training rows: silver train-block cells x {2020, 2021} (silver = WorldCover+Esri 2020-21 consensus, Tier C); early stopping on val blocks.
Evaluations (same cells for every feature set):
  within   : silver macro-F1, TEST blocks, 2021 and 2020
  unseen   : leave-one-window-out (train+val blocks of the other two windows -> all silver cells of the held-out window, 2021)
  history  : Tier-B FBR (never-settled) / stable-built recall / deep-water recall on TEST-block cells, 2017-2025, by SPI-12 class
Gate 3: C3 (optical+SAR) - C1 (optical) unseen-window macro-F1 >= 0.02 with block-bootstrap CI excluding 0 in >= 2 of 3 windows."""
import json, sys, time, warnings
import numpy as np, pandas as pd
from sklearn.metrics import f1_score
sys.path.insert(0, "src"); warnings.filterwarnings("ignore")
from pune_eo import config
from pune_eo.historical_reconstruction import het, features as F
from pune_eo.classification import baseline as B
from pune_eo.validation import registry3 as R3
from pune_eo.validation.stats3 import block_bootstrap_diff
H = het.load(); M = H["meta"]; SY = H["info"]["syears"]; SEED = 20261027; OUT = config.path("results/phase3/fusion"); OUT.mkdir(parents=True, exist_ok=True)
CL = H["climate"]; WIN = sorted(M.window.unique()); sil = M.silver.between(1, 4).values; yv = M.silver.values
TR = sil & (M.split == 1).values; VA = sil & (M.split == 2).values; TE = sil & (M.split == 3).values; EV = np.flatnonzero((M.split == 3).values)
SETS = {"P3-C1": "C1", "P3-C2": "C2", "P3-C3": "C3", "P3-C4": "C4", "P3-C5": "C5"}

def mat(fs, cells, years):
    Xs, ys = [], []
    for y in years: X, n = F.build(H, fs, y, cells); Xs.append(X); ys.append(yv[cells])
    return np.vstack(Xs), np.concatenate(ys), n
def fit(fs, tr, va):
    Xtr, ytr, _ = mat(fs, tr, (2020, 2021)); Xva, yva, _ = mat(fs, va, (2020, 2021)); m = B.make_model("xgb", SEED); return B.fit("xgb", m, Xtr, ytr, Xva, yva)
def pred(m, fs, cells, year): X, _ = F.build(H, fs, year, cells); return np.asarray(B.CLASSES)[m.predict_proba(X).argmax(1)]
mf1 = lambda y, p: float(f1_score(y, p, labels=[1, 2, 3, 4], average="macro"))

res, preds_unseen, preds_hist = {}, {}, {}
for eid, fs in SETS.items():
    run = R3.Run(eid); t0 = time.time()
    try:
        r = {"features": F.build(H, fs, 2021, np.arange(3))[1]}
        m = fit(fs, np.flatnonzero(TR), np.flatnonzero(VA)); te = np.flatnonzero(TE)
        r["within"] = {str(y): mf1(yv[te], pred(m, fs, te, y)) for y in (2021, 2020)}
        p21 = pred(m, fs, te, 2021); r["within_per_class_f1"] = dict(zip(["built_up", "agriculture", "natural_vegetation", "water"], f1_score(yv[te], p21, labels=[1, 2, 3, 4], average=None).round(4).tolist()))
        # history on Tier-B strata, S1 era
        P = np.stack([pred(m, fs, EV, y) for y in SY], 1); preds_hist[eid] = P; mm = M.iloc[EV].reset_index(drop=True); r["history"] = {}
        for g in WIN:
            w = (mm.window == g).values; ns, sb, dw = w & mm.never_settled.values, w & mm.stable_built.values, w & mm.deep_water.values
            cl = CL[CL.window == g].set_index("year").climate_class.reindex(SY).values
            fbr = (P[ns] == 1).mean(0) if ns.any() else np.full(len(SY), np.nan); rec = (P[sb] == 1).mean(0) if sb.any() else np.full(len(SY), np.nan)
            wr = (P[dw] == 4).mean(0) if dw.any() else np.full(len(SY), np.nan)
            r["history"][g] = {"fbr_by_year": dict(zip(SY, np.round(fbr, 4).tolist())), "built_recall_by_year": dict(zip(SY, np.round(rec, 4).tolist())),
                               "water_recall_by_year": dict(zip(SY, np.round(wr, 4).tolist())), "climate_by_year": dict(zip(SY, cl.tolist())),
                               **{f"fbr_{c}": (float(np.nanmean(fbr[cl == c])) if (cl == c).any() else None) for c in ("dry", "normal", "wet")}}
        # unseen windows
        r["unseen"] = {}
        for g in WIN:
            og = (M.window != g).values; m2 = fit(fs, np.flatnonzero(TR & og), np.flatnonzero(VA & og)); ho = np.flatnonzero(sil & (M.window == g).values)
            p = pred(m2, fs, ho, 2021); preds_unseen[(eid, g)] = (ho, p); r["unseen"][g] = {"macro_f1": mf1(yv[ho], p), "n": int(len(ho)),
                "per_class_f1": dict(zip(["built_up", "agriculture", "natural_vegetation", "water"], f1_score(yv[ho], p, labels=[1, 2, 3, 4], average=None).round(4).tolist()))}
        r["seconds"] = round(time.time() - t0, 1); res[eid] = r; np.save(OUT / f"pred_hist_{eid}.npy", P)
        outcome = "NA"
        if eid != "P3-C1":
            cmp = {}
            for g in WIN:
                ho, pa = preds_unseen[(eid, g)]; _, pb = preds_unseen[("P3-C1", g)]; y_ = yv[ho]
                cmp[g] = block_bootstrap_diff(lambda i: mf1(y_[i], pa[i]) - mf1(y_[i], pb[i]), M.block.values[ho], n=1000)
            r["unseen_vs_C1"] = cmp
            k = sum(1 for g in WIN if cmp[g]["estimate"] >= 0.02 and cmp[g]["excludes_zero"])
            neg = sum(1 for g in WIN if cmp[g]["estimate"] < 0 and cmp[g]["excludes_zero"])
            outcome = "SUPPORTED" if k >= 2 else ("NOT_SUPPORTED" if (neg >= 1 or all(not cmp[g]["excludes_zero"] for g in WIN)) else "INCONCLUSIVE")
        msg = (f"within 2021 {r['within']['2021']:.3f}; unseen " + ", ".join(f"{g[9:]} {r['unseen'][g]['macro_f1']:.3f}" for g in WIN)
               + ("" if eid == "P3-C1" else "; vs C1 " + ", ".join(f"{g[9:]} {r['unseen_vs_C1'][g]['estimate']:+.3f} [{r['unseen_vs_C1'][g]['ci95'][0]:+.3f},{r['unseen_vs_C1'][g]['ci95'][1]:+.3f}]" for g in WIN)))
        run.complete(r, outcome, msg, outputs={"history_predictions": f"results/phase3/fusion/pred_hist_{eid}.npy"}, n_samples={"train_cells": int(TR.sum()), "test_cells": int(TE.sum())})
        print(eid, msg, flush=True)
    except Exception as e:
        import traceback; traceback.print_exc(); run.fail(repr(e), eid, "fix and re-register as @v2")
# Gate 3 (C3 vs C1)
c3 = res.get("P3-C3", {}).get("unseen_vs_C1", {})
gate3 = {"criterion": "C3-C1 unseen macro-F1 >= 0.02, CI excludes 0, in >= 2 of 3 windows", "by_window": c3,
         "passed": sum(1 for g in c3 if c3[g]["estimate"] >= 0.02 and c3[g]["excludes_zero"]) >= 2 if c3 else None}
res["gate3"] = gate3; json.dump(res, open(OUT / "fusion_summary.json", "w"), indent=1, default=str); np.save(OUT / "eval_cells.npy", EV)
print("GATE 3", gate3["passed"])
