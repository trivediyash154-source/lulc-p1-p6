"""Justify the CV block size: empirical semivariogram of dry-season NDVI (2020) and of the silver built/vegetation indicators.
Range = smallest lag where semivariance reaches 95 % of the sill (mean of the 3 largest lags). Output results/labels/variogram.json"""
import json, sys
import numpy as np, rasterio
sys.path.insert(0, "src")
from pune_eo import config
W = ["pune_G30_khadakwasla_mutha", "pune_G30_baramati_agri", "pune_G30_mulshi_ghats"]
lags_px = np.array([1, 2, 3, 5, 7, 10, 15, 20, 30, 40, 50, 67, 83, 100, 133])     # 30 m .. 4 km
rng = np.random.default_rng(0); out = {}
def vario(a):
    H, Wd = a.shape; g = []
    for L in lags_px:
        n = 40000; r = rng.integers(0, H, n); c = rng.integers(0, Wd, n); th = rng.uniform(0, 2 * np.pi, n)
        r2 = np.round(r + L * np.sin(th)).astype(int); c2 = np.round(c + L * np.cos(th)).astype(int)
        ok = (r2 >= 0) & (r2 < H) & (c2 >= 0) & (c2 < Wd); v1, v2 = a[r[ok], c[ok]], a[r2[ok], c2[ok]]; f = np.isfinite(v1) & np.isfinite(v2)
        g.append(0.5 * np.mean((v1[f] - v2[f]) ** 2))
    g = np.array(g); sill = g[-3:].mean(); rr = lags_px[np.argmax(g >= 0.95 * sill)] * 30
    return {"lag_m": (lags_px * 30).tolist(), "gamma": g.round(6).tolist(), "sill": float(sill), "range95_m": int(rr)}
for w in W:
    if not config.path("data/composites", w, "2020/landsat/seasonal/dry/optical_composite.tif").exists(): print(w, "2020 composite missing - skipped"); continue
    with rasterio.open(config.path("data/composites", w, "2020/landsat/seasonal/dry/optical_composite.tif")) as s:
        a = s.read([3, 4]).astype(float); a[a == -32768] = np.nan
    ndvi = (a[1] - a[0]) / (a[1] + a[0])
    with rasterio.open(config.path("data/labels", w, "silver_l1.tif")) as s: l1 = s.read(1).astype(float)
    with rasterio.open(config.path("data/labels", w, "esa_worldcover_2021_l1_fractions.tif")) as s: fr = s.read().astype(float)
    fr[fr < 0] = np.nan
    out[w] = {"ndvi_dry_2020": vario(ndvi), "worldcover_built_fraction": vario(fr[0]), "worldcover_natveg_fraction": vario(fr[2])}
    print(w, {k: v["range95_m"] for k, v in out[w].items()})
json.dump(out, open(config.path("results/labels/variogram.json"), "w"), indent=1)
