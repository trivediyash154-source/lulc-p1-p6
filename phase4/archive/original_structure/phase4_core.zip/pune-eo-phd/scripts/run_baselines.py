"""Baseline L1 LULC experiments on the 3 benchmark windows (label epoch 2021). Every run is a registry record.
  EXP-L1-B{model}-{fs}: 4 models x 3 feature sets, 3 km spatial blocks, test scored once.
  EXP-L1-LEAK-{b}     : RF, same features, split design 0 (random pixels) / 1.5 / 3 / 6 km -> leakage magnitude.
  EXP-L1-TT-2020      : best baseline trained 2021, applied to 2020 features on the same test blocks (year robustness)."""
import json, sys, time, warnings
import numpy as np, pandas as pd, yaml
sys.path.insert(0, "src")
warnings.filterwarnings("ignore")
from pune_eo import config
from pune_eo.classification import baseline as B
from pune_eo.labels.splits import make_splits
from pune_eo.compositing.windows import resolve
from pune_eo.modelling.registry import Experiment
W = ["khadakwasla_mutha", "baramati_agri", "mulshi_ghats"]; YEAR = 2021; SEED = 20261004
CAP = {1: 4000, 2: 4000, 3: None}
reg = yaml.safe_load(open(config.path("configs/features.yaml")))
LS = [f for f, v in reg["features"].items() if v["group"] in ("landsat_dry", "landsat_post", "landsat_annual", "derived", "texture")]
TER = [f for f, v in reg["features"].items() if v["group"] == "terrain"]
out = config.path("results/classification"); out.mkdir(parents=True, exist_ok=True)

df = B.samples(W, YEAR, LS + TER, cap=CAP, seed=SEED)
keep, dropped = B.prune_correlated(df[df.split == 1][LS + TER], reg["prune_rho"])
json.dump({"rho": reg["prune_rho"], "candidates": LS + TER, "kept": keep, "dropped": dropped, "fit_on": f"train split, {YEAR}, 3 windows"},
          open(out / "feature_pruning.json", "w"), indent=1)
print("pruned:", [d["dropped"] for d in dropped])
FS = {"dry_bands": [f for f in B.DRY_BANDS if f in keep] or B.DRY_BANDS, "landsat": [f for f in keep if f in LS], "landsat_terrain": keep}
tr, va, te = df[df.split == 1], df[df.split == 2], df[df.split == 3]
n_s = {"train": tr.label.value_counts().sort_index().to_dict(), "val": va.label.value_counts().sort_index().to_dict(), "test": te.label.value_counts().sort_index().to_dict()}
print(n_s)
summary = []
def run(eid, model, fs, tr, va, te, split_desc, rq, hyp, extra=None, years=(YEAR,)):
    e = Experiment(experiment_id=eid, research_question=rq, hypothesis=hyp, dataset_version="cube G30 local_pune_g30_v2; labels silver v1",
                   years=list(years), resolution_m=30, features=FS[fs], labels="silver_l1 (WorldCover+Esri 2020/21 unanimous, purity>=0.78)",
                   split=split_desc, model=model, hyperparameters={}, seed=SEED, windows=W)
    try:
        m = B.make_model(model, SEED); t = time.time()
        B.fit(model, m, tr[FS[fs]], tr.label.values, va[FS[fs]], va.label.values); fit_s = time.time() - t
        mv = B.evaluate(va.label.values, B.predict(model, m, va[FS[fs]]))
        yt = B.predict(model, m, te[FS[fs]]); mt = B.evaluate(te.label.values, yt)
        per_w = {w: B.evaluate(te.label.values[te.window.values == w], yt[te.window.values == w]) for w in te.window.unique()}
        e.rec["hyperparameters"] = {k: v for k, v in (m.get_params().items() if hasattr(m, "get_params") else []) if isinstance(v, (int, float, str, type(None)))}
        if model == "xgb": e.rec["hyperparameters"]["best_iteration"] = int(m.best_iteration)
        rec = e.finish({"val": mv, "test": mt, "test_by_window": {k: {kk: v[kk] for kk in ("n", "overall_agreement", "macro_f1")} for k, v in per_w.items()},
                        "fit_seconds": round(fit_s, 1), **(extra or {})},
                       result=f"test macro-F1 {mt['macro_f1']:.3f} (agreement with silver reference, NOT map accuracy)",
                       n_samples={"train": len(tr), "val": len(va), "test": len(te)})
        summary.append({"experiment_id": eid, "model": model, "features": fs, "n_features": len(FS[fs]), "split": split_desc,
                        "val_macro_f1": mv["macro_f1"], "test_macro_f1": mt["macro_f1"], "test_overall": mt["overall_agreement"],
                        "test_quantity_dis": mt["quantity_disagreement"], "test_allocation_dis": mt["allocation_disagreement"],
                        **{f"test_f1_{k}": v["f1"] for k, v in mt["per_class"].items()}, "fit_s": round(fit_s, 1)})
        print(json.dumps(summary[-1]), flush=True); return m
    except Exception as ex:
        e.fail(repr(ex), f"{model} on {fs}", "rerun after fixing"); print("FAILED", eid, repr(ex), flush=True)

RQ = "RQ-L1: How well can L1 land cover be separated at 30 m from harmonised Landsat composites, and what do terrain features add?"
models = {}
for fs in FS:
    for mdl in ["logreg", "gaussian_mlc", "rf", "xgb"]:
        models[(mdl, fs)] = run(f"EXP-L1-B-{mdl}-{fs}", mdl, fs, tr, va, te, "3 km hashed blocks, 2 px buffer, 60/20/20", RQ,
                                "tree ensembles > linear/Gaussian; seasonal+terrain features > dry bands alone")
# leakage sensitivity
RQL = "RQ-LEAK: How much does the split design inflate apparent performance?"
for bm in [0, 1500, 3000, 6000]:
    sp = {w: make_splits(resolve("G30", w)[0].subgrid(resolve("G30", w)[1], f"_{w}"), write=False, block_m=bm)["split"] for w in W}
    d2 = B.samples(W, YEAR, FS["landsat_terrain"], split=sp, cap=CAP, seed=SEED)
    run(f"EXP-L1-LEAK-{bm}m", "rf", "landsat_terrain", d2[d2.split == 1], d2[d2.split == 2], d2[d2.split == 3],
        "random pixels (0 m)" if bm == 0 else f"{bm} m hashed blocks, 2 px buffer", RQL,
        "random-pixel splits overstate agreement relative to blocks >= variogram range (2-3 km)", {"block_m": bm})
pd.DataFrame(summary).to_csv(out / "baseline_summary.csv", index=False)
# temporal robustness: best (by VAL macro-F1) baseline trained on 2021, tested on 2020 features at the same test cells
best = max([s for s in summary if not s["experiment_id"].startswith("EXP-L1-LEAK")], key=lambda s: s["val_macro_f1"])
print("best by val:", best["experiment_id"])
mdl, fs = best["model"], best["features"]; m = models[(mdl, fs)]
d20 = B.samples(W, 2020, FS[fs], cap=CAP, seed=SEED); te20 = d20[d20.split == 3]
e = Experiment(experiment_id="EXP-L1-TT-2020", research_question="RQ-TT: Is a 2021-trained baseline stable when applied to another year's composite?",
               hypothesis="labels are stable 2020-21 by construction, so agreement should be close to the 2021 test value",
               dataset_version="cube G30 local_pune_g30_v2; labels silver v1", years=[2021, 2020], resolution_m=30, features=FS[fs],
               labels="silver_l1", split="3 km blocks; train 2021 -> test 2020", model=mdl, hyperparameters={"from": best["experiment_id"]}, seed=SEED)
mt = B.evaluate(te20.label.values, B.predict(mdl, m, te20[FS[fs]]))
e.finish({"test_2020": mt, "test_2021_macro_f1": best["test_macro_f1"]}, result=f"2020 macro-F1 {mt['macro_f1']:.3f} vs 2021 {best['test_macro_f1']:.3f}",
         n_samples={"test_2020": len(te20)})
print("TT 2020:", mt["macro_f1"], mt["overall_agreement"])
