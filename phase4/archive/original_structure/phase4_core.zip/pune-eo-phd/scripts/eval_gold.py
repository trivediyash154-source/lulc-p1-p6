"""P3-A2p — agreement of 2021 maps / reference products with the FROZEN provisional AI visual interpretation (Tier C, NEVER gold).
P3-A2 (Tier-A human gold) stays PENDING: no human VHR interpretation exists. Gate 1 is evaluated and reported NOT PASSED.

Refuses to run unless results/gold/provisional_ai_FROZEN.json exists and the pass files' SHA-256 match the stamp.
The key (data/labels/gold/_key/gold_key.csv) is first joined here, after the freeze.

Products at the 558 points (all in TEST blocks), year 2021:
  phase3_xgb_B3T   Phase-3 re-fit of the Phase-2 best configuration (XGB, Landsat seasonal + terrain) — results/phase3/baseline/xgb_B3T_2021.joblib
  phase2_raw       EXP-LULC-T-002 raw annual map, band 2021
  phase2_hmm_aoa   EXP-LULC-T-002 HMM + AOA map, band 2021
  silver_l1        silver consensus (WorldCover 2020-21 + Esri 2020-21); 0 = no consensus -> not evaluated
  worldcover_2021, esri_2021   dominant class of the 30 m fractions (6 classes)
Evaluation set: points whose AI label is one of the 4 model classes; AI bare_sparse/other reported separately; abstentions excluded and counted.
Uncertainty: stratified bootstrap over the sampling strata (window x stratum), 1000 reps; design weights = 1 / inclusion probability."""
import hashlib, json, sys, warnings
import numpy as np, pandas as pd, rasterio
sys.path.insert(0, "src"); warnings.filterwarnings("ignore")
from scipy.stats import chi2_contingency
from pune_eo import config
from pune_eo.labels import gold_qa as Q
from pune_eo.validation import registry3 as R3
from pune_eo.calibration import metrics as CM
from pune_eo.provenance import utcnow

STAMP = config.path("results/gold/provisional_ai_FROZEN.json"); OUT = config.path("results/phase3/gold"); OUT.mkdir(parents=True, exist_ok=True)
if not STAMP.exists(): sys.exit("REFUSED: no freeze stamp (results/gold/provisional_ai_FROZEN.json)")
st = json.loads(STAMP.read_text())
for f, h in st["files"].items():
    if hashlib.sha256(open(config.path(f), "rb").read()).hexdigest() != h: sys.exit(f"REFUSED: {f} changed after freeze")
CLS = ["built_up", "agriculture", "natural_vegetation", "water"]; C2I = {c: i + 1 for i, c in enumerate(CLS)}
WC6 = CLS + ["bare_sparse", "other"]; ABST = {"uncertain", "ambiguous"}; SEED, NB = 20261026, 1000

P1 = pd.read_csv(config.path("results/gold/provisional_ai_pass1.csv"), dtype={"confidence_1to3": int})
P2 = pd.read_csv(config.path("results/gold/provisional_ai_pass2.csv"), dtype={"confidence_1to3": int})
K = pd.read_csv(config.path("data/labels/gold/_key/gold_key.csv")); D = K.merge(P1, on="anon_id", validate="1:1")
assert len(D) == 558

# ---------------- products at points
prod = {k: np.zeros(len(D), int) for k in ("phase2_raw", "phase2_hmm_aoa", "silver_l1", "worldcover_2021", "esri_2021")}
xgb_p = np.full((len(D), 4), np.nan); mpath = config.path("results/phase3/baseline/xgb_B3T_2021.joblib")
xgb = __import__("joblib").load(mpath) if mpath.exists() else None
if xgb is not None:
    import xarray as xr
    from pune_eo.historical_reconstruction import features as F
for gid in D.window.unique():
    s = (D.window == gid).values; r, c = D.row.values[s], D["col"].values[s]
    for k, f, b in (("phase2_raw", f"results/export/{gid}/lulc_l1_raw_1990_2026.tif", 32), ("phase2_hmm_aoa", f"results/export/{gid}/lulc_l1_hmm_aoa_1990_2026.tif", 32),
                    ("silver_l1", f"data/labels/{gid}/silver_l1.tif", 1)):
        with rasterio.open(config.path(f)) as src:
            if k != "silver_l1": assert src.descriptions[b - 1] == "2021"
            prod[k][s] = src.read(b)[r, c]
    for k, f in (("worldcover_2021", "esa_worldcover_2021_l1_fractions.tif"), ("esri_2021", "esri_lulc_2021_l1_fractions.tif")):
        with rasterio.open(config.path("data/labels", gid, f)) as src: a = src.read()[:, r, c]
        prod[k][s] = np.where(np.isfinite(a).all(0) & (np.nansum(a, 0) > 0), np.nanargmax(np.nan_to_num(a, nan=-1), 0) + 1, 0)
    if xgb is not None:
        ds = xr.open_zarr(config.path("data/features/cube", f"{gid}.zarr")); fl = ds.feature.values.tolist(); L = ds.landsat.sel(year=2021).values
        X = np.concatenate([L[[fl.index(n) for n in F.B3]][:, r, c], ds.terrain.values[:, r, c]]).T; ok = np.isfinite(X).all(1)
        pr = np.full((s.sum(), 4), np.nan); pr[ok] = xgb.predict_proba(X[ok]); xgb_p[s] = pr
if xgb is not None: prod["phase3_xgb_B3T"] = np.where(np.isfinite(xgb_p).all(1), np.nan_to_num(xgb_p).argmax(1) + 1, 0)
# silver at point must equal the sampling stratum (consistency check of the key)
sv = D.stratum.map({**C2I, "no_silver_label": 0}).values; key_consistent = float((sv == prod["silver_l1"]).mean())

ai = D.reference_class_2021.values; conf = D.confidence_1to3.values; abst = np.isin(ai, list(ABST)); in4 = np.isin(ai, CLS)
yai = np.array([C2I.get(a, 0) for a in ai]); w = 1.0 / D.inclusion_prob.values; strata = (D.window + "|" + D.stratum).values

def scores(y, yh, wt=None):
    wt = np.ones(len(y)) if wt is None else wt; labs = range(1, 5); cm = np.array([[wt[(y == a) & (yh == b)].sum() for b in labs] for a in labs])
    tp = np.diag(cm); f1 = 2 * tp / np.maximum(cm.sum(1) + cm.sum(0), 1e-12); iou = tp / np.maximum(cm.sum(1) + cm.sum(0) - tp, 1e-12)
    present = cm.sum(1) > 0; acc = float(wt[y == yh].sum() / wt.sum())
    return {"agreement": acc, "macro_f1": float(f1[present].mean()), "per_class_f1": {CLS[i]: float(f1[i]) if present[i] else None for i in range(4)},
            "per_class_iou": {CLS[i]: float(iou[i]) if present[i] else None for i in range(4)}, "confusion_rows_AI_cols_product": cm.round(3).tolist(),
            "agri_to_natveg": float(cm[1, 2]), "natveg_to_agri": float(cm[2, 1]), "agri_to_built": float(cm[1, 0]), "built_to_agri": float(cm[0, 1])}

def boot(fn, sel, n=NB, seed=SEED):
    rng = np.random.default_rng(seed); idx = np.flatnonzero(sel); groups = [idx[strata[idx] == g] for g in np.unique(strata[idx])]; out = []
    for _ in range(n): out.append(fn(np.concatenate([rng.choice(g, len(g)) for g in groups])))
    return np.array(out)

def evaluate(name, yh):
    base = in4 & (yh > 0); res = {"n_eval": int(base.sum()), "n_product_nodata": int((in4 & (yh == 0)).sum())}
    res["unweighted"] = scores(yai[base], yh[base]); res["design_weighted"] = scores(yai[base], yh[base], w[base])
    bs = boot(lambda i: (lambda s_: [s_["agreement"], s_["macro_f1"]])(scores(yai[i], yh[i])), base)
    res["ci95_unweighted"] = {"agreement": np.percentile(bs[:, 0], [2.5, 97.5]).tolist(), "macro_f1": np.percentile(bs[:, 1], [2.5, 97.5]).tolist()}
    hc = base & (conf == 3); res["high_confidence_only"] = {"n": int(hc.sum()), **{k: v for k, v in scores(yai[hc], yh[hc]).items() if k in ("agreement", "macro_f1", "per_class_f1")}}
    res["by_window"] = {g[9:]: {"n": int((base & (D.window == g).values).sum()), "design_weighted_agreement": scores(yai[base & (D.window == g).values], yh[base & (D.window == g).values], w[base & (D.window == g).values])["agreement"],
                                "macro_f1": scores(yai[base & (D.window == g).values], yh[base & (D.window == g).values])["macro_f1"]} for g in sorted(D.window.unique())}
    res["by_confidence"] = {int(k): {"n": int((base & (conf == k)).sum()), "agreement": float((yai[base & (conf == k)] == yh[base & (conf == k)]).mean()) if (base & (conf == k)).any() else None} for k in (1, 2, 3)}
    res["on_silver_labelled_points"] = scores(yai[base & (sv > 0)], yh[base & (sv > 0)])["agreement"]
    res["on_no_silver_points"] = scores(yai[base & (sv == 0)], yh[base & (sv == 0)])["agreement"] if (base & (sv == 0)).any() else None
    res["product_label_on_AI_abstentions"] = {CLS[k - 1]: int(((yh == k) & abst).sum()) for k in range(1, 5)}
    res["product_label_on_AI_bare_or_other"] = {CLS[k - 1]: int(((yh == k) & np.isin(ai, ["bare_sparse", "other"])).sum()) for k in range(1, 5)}
    return res

R = {"created_utc": utcnow(), "tier": "C — provisional AI visual interpretation; NOT gold, NOT ground truth", "freeze": st["frozen_utc"], "key_stratum_equals_silver_at_point": key_consistent}
R["ai_label_distribution"] = D.reference_class_2021.value_counts().to_dict()
R["abstention"] = {"rate": float(abst.mean()), "by_window": D.assign(a=abst).groupby("window").a.mean().round(3).to_dict(),
                   "by_stratum": D.assign(a=abst).groupby("stratum").a.mean().round(3).to_dict(), "by_interpreter_instance": D.assign(a=abst).groupby("interpreter").a.mean().round(3).to_dict(),
                   "interpreter_heterogeneity_chi2_p": float(chi2_contingency(pd.crosstab(D.interpreter, abst))[1]),
                   "bare_or_other_rate": float(np.isin(ai, ["bare_sparse", "other"]).mean())}
R["products"] = {k: evaluate(k, v) for k, v in prod.items()}
if xgb is not None:
    ok = in4 & np.isfinite(xgb_p).all(1); R["products"]["phase3_xgb_B3T"]["calibration_vs_AI"] = {k: v for k, v in CM.all_metrics(xgb_p[ok], yai[ok] - 1).items() if k != "reliability"}
# paired differences (same points): model vs silver, phase2 raw vs hmm
def paired(a, b):
    sel = in4 & (prod[a] > 0) & (prod[b] > 0); d = boot(lambda i: float((prod[a][i] == yai[i]).mean() - (prod[b][i] == yai[i]).mean()), sel)
    ca, cb = prod[a][sel] == yai[sel], prod[b][sel] == yai[sel]; from pune_eo.validation.stats3 import mcnemar
    return {"n": int(sel.sum()), "agreement_diff": float(ca.mean() - cb.mean()), "ci95": np.percentile(d, [2.5, 97.5]).tolist(), "mcnemar": mcnemar(ca, cb)}
mname = "phase3_xgb_B3T" if xgb is not None else "phase2_raw"
R["paired"] = {f"{mname}_vs_silver_l1": paired(mname, "silver_l1"), "phase2_raw_vs_phase2_hmm_aoa": paired("phase2_raw", "phase2_hmm_aoa"),
               f"{mname}_vs_worldcover_2021": paired(mname, "worldcover_2021"), f"{mname}_vs_esri_2021": paired(mname, "esri_2021")}
# self-consistency of the AI interpretation (repeat pass by a different, blind model instance)
J = P1.merge(P2, on="anon_id", suffixes=("_1", "_2")); a1, a2 = J.reference_class_2021_1.values, J.reference_class_2021_2.values
both = ~np.isin(a1, list(ABST)) & ~np.isin(a2, list(ABST))
R["self_consistency"] = {"n": len(J), "what": "repeat pass by a separate blind model instance on re-shuffled sheets — intra-protocol consistency, NOT inter-annotator agreement",
    "exact_agreement_all_categories": float((a1 == a2).mean()), "cohen_kappa_all_categories": Q.cohen_kappa(a1, a2),
    "n_both_labelled": int(both.sum()), "cohen_kappa_both_labelled": Q.cohen_kappa(a1[both], a2[both]) if both.sum() > 1 else None,
    "abstained_pass1": float(np.isin(a1, list(ABST)).mean()), "abstained_pass2": float(np.isin(a2, list(ABST)).mean()),
    "krippendorff_alpha_nominal": Q.krippendorff_alpha_nominal([[x if x not in ABST else None, y if y not in ABST else None] for x, y in zip(a1, a2)])}
R["gate1"] = {"passed": False, "reason": "no Tier-A (human VHR) labels: 0/558 points interpreted by a human; provisional AI labels cannot pass Gate 1 by protocol"}
json.dump(R, open(OUT / "gold_provisional_eval.json", "w"), indent=1, default=float)

m = R["products"][mname]; sil = R["products"]["silver_l1"]
a1_val = json.loads(config.path("experiments/registry/EXP-L1-B-xgb-landsat_terrain.json").read_text())["metrics"]["test"]["macro_f1"]
outcome = "SUPPORTED" if m["ci95_unweighted"]["macro_f1"][1] < a1_val else "NOT_SUPPORTED"
run = R3.Run("P3-A2p")
run.complete({"model": mname, "macro_f1_vs_AI": m["unweighted"]["macro_f1"], "macro_f1_ci95": m["ci95_unweighted"]["macro_f1"], "agreement_vs_AI": m["unweighted"]["agreement"],
              "design_weighted_agreement_vs_AI": m["design_weighted"]["agreement"], "per_class_f1": m["unweighted"]["per_class_f1"], "per_class_iou": m["unweighted"]["per_class_iou"],
              "silver_reference_macro_f1_phase2": a1_val, "abstention_rate": R["abstention"]["rate"], "self_consistency_kappa": R["self_consistency"]["cohen_kappa_all_categories"],
              "calibration_vs_AI": m.get("calibration_vs_AI"), "gate1_passed": False},
             outcome, f"{mname} vs provisional AI (Tier C, n={m['n_eval']}): macro-F1 {m['unweighted']['macro_f1']:.3f} [{m['ci95_unweighted']['macro_f1'][0]:.3f}, {m['ci95_unweighted']['macro_f1'][1]:.3f}], "
             f"design-weighted agreement {m['design_weighted']['agreement']:.3f}; vs silver-test macro-F1 {a1_val:.3f}. AI abstained on {R['abstention']['rate']:.1%}. Not gold.",
             outputs={"eval": "results/phase3/gold/gold_provisional_eval.json"}, n_samples={"points": 558, "evaluated": m["n_eval"]})
R3.mark_pending_reason("P3-A2", "no human VHR interpretation available in this environment (0/558 Tier-A labels); blind kit ready in data/labels/gold/blind/",
                       "two human interpreters with VHR access (Google Earth Pro historical imagery), ~558 points x 5 epochs + 20 % double interpretation")
print(json.dumps({"model": mname, "macro_f1": m["unweighted"]["macro_f1"], "ci": m["ci95_unweighted"]["macro_f1"], "dw_agreement": m["design_weighted"]["agreement"],
                  "silver_vs_AI": sil["unweighted"]["macro_f1"], "abst": R["abstention"]["rate"], "kappa_self": R["self_consistency"]["cohen_kappa_all_categories"], "outcome": outcome}, indent=0, default=float))
