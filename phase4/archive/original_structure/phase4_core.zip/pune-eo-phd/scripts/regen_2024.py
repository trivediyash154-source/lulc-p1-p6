import json, logging
logging.basicConfig(level=logging.WARNING)
from pune_eo.compositing.engine import run_year
from pune_eo.compositing.windows import resolve
g, w, wn = resolve("G240", "district")
for fam in ("landsat", "sentinel2"):
    r = run_year(fam, 2024, g, threads=10)
    print(json.dumps({k: r.get(k) for k in ("job_id", "status", "seconds", "n_items", "n_failed")}), flush=True)
