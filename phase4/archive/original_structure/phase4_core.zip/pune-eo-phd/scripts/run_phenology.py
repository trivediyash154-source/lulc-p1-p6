"""Cropland phenology & cropping intensity, 2021 (registry EXP-AG-PHEN-001).
Frame: silver agriculture 2021 AND WSF never settled AND GHSL 2020 < 0.05 (fixed, independent of model maps).
Profile per pixel: S2 NDVI for the reliable months (Jan-Jun, Oct-Dec) + S1 VH dB for all 12 months (monsoon visibility).
k-means (k chosen by silhouette over 3..7 on a sample) -> clusters interpreted ONLY by explicit centroid rules:
  perennial_green   : NDVI >= 0.45 in >= 7 of 9 optical months (incl. Apr-May)          (consistent with sugarcane/orchards - NOT verified)
  double_season     : NDVI peak Oct-Dec >= 0.45 AND peak Jan-Mar >= 0.45 with a trough between
  monsoon_single    : high Oct-Dec (post-kharif) and low Feb-May
  dry_irrigated     : high Jan-Mar, low Oct-Dec
  low_or_fallow     : max NDVI < 0.35
Confidence = silhouette value per sampled pixel. Crop TYPE: PENDING (no crop-type reference data)."""
import json, sys, warnings
import numpy as np, rasterio
from sklearn.cluster import KMeans
from sklearn.metrics import silhouette_score, silhouette_samples
sys.path.insert(0, "src"); warnings.filterwarnings("ignore")
from pune_eo import config
from pune_eo.agriculture import timeseries as TS
from pune_eo.modelling.registry import Experiment
W = ["pune_G30_khadakwasla_mutha", "pune_G30_baramati_agri", "pune_G30_mulshi_ghats"]; OPT = [0, 1, 2, 3, 4, 5, 9, 10, 11]; SEED = 20261012
def rd(p, b=1):
    with rasterio.open(p) as s: return s.read(b)
e = Experiment(experiment_id="EXP-AG-PHEN-001", research_question="RQ-PH: What cropping-intensity regimes exist on the cropland frame and how do they differ between landscapes?",
               hypothesis="Baramati is dominated by perennial/irrigated regimes; corridor/Mulshi cropland by monsoon-single regimes",
               dataset_version="S2/S1 G30 monthly 2021", years=[2021], resolution_m=30, features=["S2 NDVI (9 months)", "S1 VH dB (12 months)"],
               labels="none (unsupervised); frame from silver agri & WSF & GHSL", split="n/a", model="k-means + rule-based interpretation", hyperparameters={"k_range": [3, 7]}, seed=SEED)
rng = np.random.default_rng(SEED); prof, wid, pos = [], [], []
for gid in W:
    X, info = TS.monthly_stack(gid, 2021); d = config.path("data/labels", gid)
    sil = rd(d / "silver_l1.tif"); wsf = rd(d / "wsf_evolution_first_year.tif"); gh = rd(d / "ghsl_built_fraction_90m.tif", 7).astype(float)
    H, Wd = sil.shape; gh3 = np.pad(np.repeat(np.repeat(gh, 3, 0), 3, 1), ((0, max(0, H - 3 * gh.shape[0])), (0, max(0, Wd - 3 * gh.shape[1]))), constant_values=np.nan)[:H, :Wd]
    r, c = np.nonzero((sil == 2) & (wsf == 0) & (gh3 < 0.05))
    if r.size > 25000: k = rng.choice(r.size, 25000, replace=False); r, c = r[k], c[k]
    nd = X[OPT, 0][:, r, c].T; vh = X[:, 5][:, r, c].T; ok = np.isfinite(nd).all(1) & np.isfinite(vh).all(1)
    prof.append(np.c_[nd[ok], vh[ok]]); wid += [gid] * int(ok.sum()); pos.append(np.c_[r[ok], c[ok]])
P = np.concatenate(prof); wid = np.array(wid); mu, sd = P.mean(0), P.std(0) + 1e-9; Z = (P - mu) / sd
samp = rng.choice(len(Z), min(8000, len(Z)), replace=False); scores = {}
for k in range(3, 8):
    km = KMeans(k, n_init=10, random_state=SEED).fit(Z[samp]); scores[k] = float(silhouette_score(Z[samp], km.labels_))
kbest = max(scores, key=scores.get); km = KMeans(kbest, n_init=20, random_state=SEED).fit(Z); lab = km.labels_
cent = km.cluster_centers_ * sd + mu; ndc = cent[:, :9]; months = np.array([1, 2, 3, 4, 5, 6, 10, 11, 12])
def interpret(n):
    hi = n >= 0.45; od = n[months >= 10].max(); jm = n[(months >= 1) & (months <= 3)].max(); am = n[(months == 4) | (months == 5)].max()
    if n.max() < 0.35: return "low_or_fallow"
    if hi.sum() >= 7 and am >= 0.45: return "perennial_green"
    if od >= 0.45 and jm >= 0.45 and n[(months >= 3) & (months <= 6)].min() < min(od, jm) - 0.1: return "double_season"
    if od >= 0.45 and n[(months >= 2) & (months <= 5)].max() < 0.35: return "monsoon_single"
    if jm >= 0.45 and od < 0.45: return "dry_irrigated"
    return "mixed_unresolved"
names = {i: interpret(ndc[i]) for i in range(kbest)}
ss = silhouette_samples(Z[samp], lab[samp])
res = {"k_silhouette": scores, "k": kbest, "clusters": {f"c{i}": {"regime": names[i], "ndvi_centroid_months_1-6_10-12": np.round(ndc[i], 3).tolist(),
                                                               "vh_db_centroid_12m": np.round(cent[i, 9:], 2).tolist(), "silhouette_mean": float(ss[lab[samp] == i].mean())} for i in range(kbest)},
       "share_by_window": {g: {f"c{i}:{names[i]}": float((lab[wid == g] == i).mean()) for i in range(kbest)} for g in W if (wid == g).any()},
       "separability_verdict": "weak (silhouette < 0.25): clusters are a dry-season-greenness gradient, NOT discrete cropping-intensity classes; cropping intensity PENDING (10 m per-acquisition series, field segmentation)" if max(scores.values()) < 0.25 else "separable",
       "n_pixels": {g: int((wid == g).sum()) for g in W}}
json.dump(res, open(config.path("results/agriculture/phenology_2021.json"), "w"), indent=1)
print(json.dumps({"k": kbest, "regimes": names, "share": {g[9:]: {k: round(v, 2) for k, v in s.items()} for g, s in res["share_by_window"].items()}}, indent=0))
e.finish(res, result="clusters weakly separated (silhouette < 0.25): a dry-season-greenness gradient, NOT discrete cropping-intensity classes; cropping intensity and crop type PENDING", outputs={"summary": "results/agriculture/phenology_2021.json"},
         n_samples=res["n_pixels"])
