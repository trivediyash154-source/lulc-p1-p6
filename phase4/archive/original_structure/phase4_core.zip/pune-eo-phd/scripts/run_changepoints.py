"""Compare change-point methods against an INDEPENDENT sample (registry EXP-CP-001). Parameters are fixed a priori
(validated only on synthetic series in tests/test_changepoints.py) - this sample is used once, never for tuning.
Strata per window (30 m cells; GHSL from the parent 90 m cell):
  urbanised      WSF first-settled year in 1995-2012 AND GHSL built fraction gain 1990->2020 >= 0.2   (reference year = WSF year)
  stable_open    WSF never settled AND GHSL 2020 < 0.02 AND JRC occurrence == 0                       (no urbanisation, no water)
  stable_built   WSF settled by 1985 AND GHSL 1990 >= 0.3
Series: post-monsoon NDVI (primary) and dry-season NDVI, 1990-2026 from the feature cube; missing years dropped."""
import json, sys, time, warnings
import numpy as np, pandas as pd, rasterio
sys.path.insert(0, "src"); warnings.filterwarnings("ignore")
from pune_eo import config
from pune_eo.classification import baseline as B
from pune_eo.change_detection import changepoints as C
from pune_eo.modelling.registry import Experiment
W = ["pune_G30_khadakwasla_mutha", "pune_G30_baramati_agri", "pune_G30_mulshi_ghats"]; SEED = 20261005
NMAX = {"urbanised": 1500, "stable_open": 1500, "stable_built": 500}; IDX = ["post_ndvi", "dry_ndvi"]
def rd(p, b=None):
    with rasterio.open(p) as s: return s.read(b) if b else s.read()
e = Experiment(experiment_id="EXP-CP-001", research_question="RQ-CP: Which change-point method best recovers the timing of urbanisation, and at what false-break rate?",
               hypothesis="trend-break/LandTrendr-type methods time urbanisation within +-2 y more often than level-shift or sequential methods",
               dataset_version="cube G30 local_pune_g30_v2", years=list(range(1990, 2027)), resolution_m=30, features=IDX,
               labels="independent: WSF-Evolution first year + GHSL R2023A gain + JRC occurrence (sample strata)", split="independent sample, used once",
               model=list(C.METHODS), hyperparameters={"pelt_mean": "beta=2, min_size=3", "trend_breaks": "max 3 breaks, min 4 obs, BIC",
               "landtrendr": "max 5 vertices, BIC, despike 0.9", "cusum": "h=8, k=1, baseline 5 obs", "bocpd": "hazard 1/15, p>0.5"}, seed=SEED)
rng = np.random.default_rng(SEED); rows = []; t0 = time.time()
SAVED = config.path("results/change_detection/cp_sample_breaks.parquet")
for gid in (W if not (len(sys.argv) > 1 and sys.argv[1] == "--reuse" and SAVED.exists()) else []):
    d = config.path("data/labels", gid); ds = B.open_cube(gid); years = ds.year.values
    wsf = rd(d / "wsf_evolution_first_year.tif", 1).astype(int); gh = rd(d / "ghsl_built_fraction_90m.tif").astype(float)
    jrc = rd(d / "jrc_gsw.tif", 1).astype(float)
    H, Wd = wsf.shape; up = lambda a: np.repeat(np.repeat(a, 3, 0), 3, 1)[:H, :Wd]
    g90, g20 = up(gh[0]), up(gh[6]); pad = lambda a: np.pad(a, ((0, H - a.shape[0]), (0, Wd - a.shape[1])), constant_values=np.nan)
    g90, g20 = pad(g90), pad(g20)
    strata = {"urbanised": (wsf >= 1995) & (wsf <= 2012) & (g20 - g90 >= 0.2),
              "stable_open": (wsf == 0) & (g20 < 0.02) & (jrc == 0),
              "stable_built": (wsf == 1985) & (g90 >= 0.3)}
    S = {i: ds.landsat.sel(feature=i).values for i in IDX}
    for st, m in strata.items():
        r, c = np.nonzero(m)
        if r.size == 0: continue
        k = rng.choice(r.size, min(NMAX[st], r.size), replace=False)
        for rr, cc in zip(r[k], c[k]):
            for ix in IDX:
                y = S[ix][:, rr, cc]
                for meth in C.METHODS:
                    cps = C.detect(years, y, meth)
                    rows.append({"window": gid, "stratum": st, "row": rr, "col": cc, "index": ix, "method": meth, "ref_year": int(wsf[rr, cc]) if st == "urbanised" else None,
                                 "n_obs": int(np.isfinite(y).sum()), "breaks": json.dumps(cps) if cps is not None else None})
    print(gid, "done", round(time.time() - t0), flush=True)
out = config.path("results/change_detection"); out.mkdir(parents=True, exist_ok=True)
if rows: df = pd.DataFrame(rows); df.to_parquet(out / "cp_sample_breaks.parquet")
else: df = pd.read_parquet(SAVED); e.rec["note"] = "detection outputs reused from cp_sample_breaks.parquet (scoring step re-run after a pandas groupby fix)"
def score(g, stratum):
    n_insuff = int(g.breaks.isna().sum()); g = g[g.breaks.notna()]                  # < 10 observed years: excluded, counted
    b = [json.loads(x) for x in g.breaks]
    if stratum == "urbanised":
        neg = [[c for c in bb if c[1] <= -0.05] for bb in b]; err = np.array([min((c[0] - ry for c in nb), key=abs) if nb else np.nan for nb, ry in zip(neg, g.ref_year)])
        return pd.Series({"n": len(g), "n_insufficient_obs": n_insuff, "recall_pm1": np.mean(np.abs(err) <= 1), "recall_pm2": np.mean(np.abs(err) <= 2), "recall_pm3": np.mean(np.abs(err) <= 3),
                          "any_neg_break": np.mean(np.isfinite(err)), "timing_median_err_y": np.nanmedian(err), "timing_mae_y": np.nanmean(np.abs(err))})
    return pd.Series({"n": len(g), "n_insufficient_obs": n_insuff, "any_break_rate": np.mean([len(bb) > 0 for bb in b]), "break_abs_ge_0.1_rate": np.mean([any(abs(c[1]) >= 0.1 for c in bb) for bb in b]),
                      "neg_break_le_-0.1_rate": np.mean([any(c[1] <= -0.1 for c in bb) for bb in b]), "mean_breaks": np.mean([len(bb) for bb in b])})
summ = pd.DataFrame([{"stratum": k[0], "index": k[1], "method": k[2], **score(g, k[0]).to_dict()} for k, g in df.groupby(["stratum", "index", "method"])])
byw = pd.DataFrame([{"window": k[0], "index": k[1], "method": k[2], **score(g, "urbanised").to_dict()} for k, g in df[df.stratum == "urbanised"].groupby(["window", "index", "method"])])
summ.to_csv(out / "cp_method_comparison.csv", index=False); byw.to_csv(out / "cp_method_comparison_by_window.csv", index=False)
print(summ.round(3).to_string())
e.finish({"by_stratum": json.loads(summ.round(4).to_json(orient="records")), "urbanised_by_window": json.loads(byw.round(4).to_json(orient="records"))},
         result="see results/change_detection/cp_method_comparison.csv", outputs={"breaks": "results/change_detection/cp_sample_breaks.parquet"},
         n_samples={f"{k[0]}|{k[1]}": int(v) for k, v in df.groupby(["window", "stratum"]).row.count().div(len(IDX) * len(C.METHODS)).items()})
