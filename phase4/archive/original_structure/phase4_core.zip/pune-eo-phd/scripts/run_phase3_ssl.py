"""Phase-3 group G (self-supervised temporal representation) — pre-registered P3-G1..G3; feeds P3-L1 (SSL arm).
Input: annual sequences 1990-2026 (37 years x 16 B3 features) per cell + observation mask (missing years never imputed into targets).
Encoder: Transformer (d=64, 2 layers, 4 heads) — pune_eo.temporal_models.ssl. Label = silver 2021 (Tier C) on the year-2021 token.
G1 supervised from scratch | G2 MAE-pretrained, frozen + linear probe | G3 MAE-pretrained + fine-tuning.
Pretraining data (unlabelled): within-window runs use all cells of TRAIN+VAL blocks of the 3 windows (never TEST blocks);
LOWO runs use only the two SOURCE windows' TRAIN+VAL cells (target pixels never seen). Label fractions: random subsets of the labelled TRAIN cells.
XGBoost on B3+terrain at the same fractions is reported as the non-deep reference."""
import json, sys, time, warnings
import numpy as np
sys.path.insert(0, "src"); warnings.filterwarnings("ignore")
from sklearn.metrics import f1_score
from pune_eo import config
from pune_eo.historical_reconstruction import het, features as F
from pune_eo.temporal_models import full_sequence, ssl
from pune_eo.classification import baseline as B
from pune_eo.calibration import metrics as CM
from pune_eo.validation import registry3 as R3
from pune_eo.validation.stats3 import block_bootstrap_diff
H = het.load(); M = H["meta"]; SEED = 20261030; OUT = config.path("results/phase3/ssl"); OUT.mkdir(parents=True, exist_ok=True); LOG = open(OUT / "ssl.log", "a")
def log(s): print(s, flush=True); LOG.write(s + "\n"); LOG.flush()
WIN = ["pune_G30_khadakwasla_mutha", "pune_G30_baramati_agri", "pune_G30_mulshi_ghats"]; SH = {w: w[9:] for w in WIN}
sil = M.silver.between(1, 4).values; yv = M.silver.values; split = M.split.values; win = M.window.values; blk = M.block.values; T21 = H["info"]["years"].index(2021)
CLN = ["built_up", "agriculture", "natural_vegetation", "water"]; FRACS = (0.10, 0.25, 0.50, 1.00)
SEQ = full_sequence(H, np.arange(len(M)))                         # (N, 37, 16)
mf1 = lambda y, p: float(f1_score(y, p, labels=[1, 2, 3, 4], average="macro"))
def report(y, p):
    yh = p.argmax(1) + 1; f = f1_score(y, yh, labels=[1, 2, 3, 4], average=None); cm = np.array([[((y == a) & (yh == b)).sum() for b in range(1, 5)] for a in range(1, 5)])
    iou = np.diag(cm) / np.maximum(cm.sum(0) + cm.sum(1) - np.diag(cm), 1); c = CM.all_metrics(p, y - 1)
    return {"macro_f1": mf1(y, yh), "per_class_f1": dict(zip(CLN, f.round(4).tolist())), "per_class_iou": dict(zip(CLN, iou.round(4).tolist())), "ece": c["ece"], "brier": c["brier"],
            "confusion_rows_ref": cm.tolist(), "agri_to_natveg": int(cm[1, 2]), "natveg_to_agri": int(cm[2, 1]), "agri_to_built": int(cm[1, 0]), "built_to_agri": int(cm[0, 1])}
def frac_cells(cells, f, seed): rng = np.random.default_rng(seed); return np.sort(rng.choice(cells, max(40, int(round(f * len(cells)))), replace=False)) if f < 1 else cells
def xgb_ref(tr, va, te):
    Xf = lambda c: np.hstack([F.build(H, "B3", 2021, c)[0], H["T"][c]]); present = sorted(set(yv[tr].tolist())); enc = {c: i for i, c in enumerate(present)}; vk = np.isin(yv[va], present)
    m = B.make_model("xgb", SEED); m.fit(Xf(tr), np.vectorize(enc.get)(yv[tr]), eval_set=[(Xf(va)[vk], np.vectorize(enc.get)(yv[va][vk]))], verbose=False)
    p = np.full((len(te), 4), 1e-6); p[:, [c - 1 for c in present]] = m.predict_proba(Xf(te)); return p / p.sum(1, keepdims=True)
def run_setting(pre_cells, tr_all, va, te, tag, fracs, seeds=(0,)):
    Z, obs, stats = ssl.standardise(SEQ[pre_cells]); t0 = time.time()
    enc_pre, hist = ssl.pretrain(Z, obs, Z.shape[-1], epochs=8, seed=SEED, log=lambda s: log(f"[{tag}] {s}")); log(f"[{tag}] pretrain {time.time() - t0:.0f}s")
    import torch; state = {k: v.clone() for k, v in enc_pre.state_dict().items()}
    zs = lambda c: ssl.standardise(SEQ[c], stats)[:2]; Zva, ova = zs(va); Zte, ote = zs(te); out = {"mae_loss": hist}
    for f in fracs:
        for sd in seeds:
            tr = frac_cells(tr_all, f, SEED + sd); Ztr, otr = zs(tr); key = f"{int(f * 100)}%" + (f"_s{sd}" if sd else ""); r = {"n_labels": int(len(tr))}
            e = ssl.build_encoder(Ztr.shape[-1], Ztr.shape[1]); e, h = ssl.finetune(e, Ztr, otr, T21, yv[tr] - 1, 4, Zva, ova, yv[va] - 1, seed=SEED + sd); pg1 = ssl.predict(e, h, Zte, ote, T21); r["G1_scratch"] = report(yv[te], pg1)
            e = ssl.build_encoder(Ztr.shape[-1], Ztr.shape[1]); e.load_state_dict(state); e, h = ssl.finetune(e, Ztr, otr, T21, yv[tr] - 1, 4, Zva, ova, yv[va] - 1, seed=SEED + sd, freeze=True, lr=2e-3)
            pg2 = ssl.predict(e, h, Zte, ote, T21); r["G2_probe"] = report(yv[te], pg2)
            e = ssl.build_encoder(Ztr.shape[-1], Ztr.shape[1]); e.load_state_dict(state); e, h = ssl.finetune(e, Ztr, otr, T21, yv[tr] - 1, 4, Zva, ova, yv[va] - 1, seed=SEED + sd); pg3 = ssl.predict(e, h, Zte, ote, T21); r["G3_finetune"] = report(yv[te], pg3)
            r["xgb_B3T"] = report(yv[te], xgb_ref(tr, va, te))
            y_ = yv[te]; l1, l2, l3 = pg1.argmax(1) + 1, pg2.argmax(1) + 1, pg3.argmax(1) + 1
            r["G2_minus_G1"] = block_bootstrap_diff(lambda i: mf1(y_[i], l2[i]) - mf1(y_[i], l1[i]), blk[te]); r["G3_minus_G1"] = block_bootstrap_diff(lambda i: mf1(y_[i], l3[i]) - mf1(y_[i], l1[i]), blk[te])
            out[key] = r; log(f"[{tag}] {key} n={len(tr)} " + " ".join(f"{k} {r[k]['macro_f1']:.3f}" for k in ("G1_scratch", "G2_probe", "G3_finetune", "xgb_B3T")))
    return out
R = {"within": None, "lowo": {}}; t_all = time.time()
pre = np.flatnonzero(np.isin(split, [1, 2])); tr_all = np.flatnonzero(sil & (split == 1)); va = np.flatnonzero(sil & (split == 2)); te = np.flatnonzero(sil & (split == 3))
R["within"] = run_setting(pre, tr_all, va, te, "within", FRACS, seeds=(0,))
for t in WIN:
    og = win != t; R["lowo"][t] = run_setting(np.flatnonzero(og & np.isin(split, [1, 2])), np.flatnonzero(sil & og & (split == 1)), np.flatnonzero(sil & og & (split == 2)),
                                              np.flatnonzero(sil & (win == t)), f"lowo_{SH[t]}", (0.10, 0.25, 1.00))
log(f"total {time.time() - t_all:.0f}s"); json.dump(R, open(OUT / "ssl_summary.json", "w"), indent=1, default=float)
W = R["within"]; g = lambda k, m: W[k][m]["macro_f1"]
R3.Run("P3-G1").complete({k: W[k]["G1_scratch"] for k in W if k.endswith("%")} | {"lowo": {SH[t]: {k: R["lowo"][t][k]["G1_scratch"]["macro_f1"] for k in R["lowo"][t] if k.endswith("%")} for t in WIN}}, "NA",
                         "G1 scratch within macro-F1 " + ", ".join(f"{k} {g(k, 'G1_scratch'):.3f}" for k in W if k.endswith("%")), outputs={"summary": "results/phase3/ssl/ssl_summary.json"})
match = [k for k in ("10%", "25%", "50%") if g(k, "G2_probe") >= g("100%", "G1_scratch") - 0.01]
R3.Run("P3-G2").complete({k: W[k]["G2_probe"] for k in W if k.endswith("%")}, "SUPPORTED" if match else "NOT_SUPPORTED",
                         "linear probe within: " + ", ".join(f"{k} {g(k, 'G2_probe'):.3f}" for k in W if k.endswith("%")) + f"; G1@100% {g('100%', 'G1_scratch'):.3f}; probe within 0.01 of it at: {match or 'none'}")
diff = {t: {k: R["lowo"][t][k]["G3_minus_G1"] for k in ("10%", "25%")} for t in WIN}
pos = sum(1 for t in WIN if all(d["estimate"] > 0 and d["excludes_zero"] for d in diff[t].values())); neg = sum(1 for t in WIN if any(d["estimate"] < 0 and d["excludes_zero"] for d in diff[t].values()))
R3.Run("P3-G3").complete({"lowo_G3_minus_G1": {SH[t]: diff[t] for t in WIN}, "lowo": {SH[t]: {k: {m: R["lowo"][t][k][m]["macro_f1"] for m in ("G1_scratch", "G2_probe", "G3_finetune", "xgb_B3T")} for k in R["lowo"][t] if k.endswith("%")} for t in WIN}},
                         "SUPPORTED" if pos >= 2 else ("NOT_SUPPORTED" if neg >= 1 or pos == 0 else "INCONCLUSIVE"),
                         "LOWO G3-G1 macro-F1 at 10 %/25 % labels (paired block bootstrap): " + "; ".join(f"{SH[t]} " + "/".join(f"{diff[t][k]['estimate']:+.3f} [{diff[t][k]['ci95'][0]:+.3f},{diff[t][k]['ci95'][1]:+.3f}]" for k in ("10%", "25%")) for t in WIN) + " (one seed per setting)")
print("done")
