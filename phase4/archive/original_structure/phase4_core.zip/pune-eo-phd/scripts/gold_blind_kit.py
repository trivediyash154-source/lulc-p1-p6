"""Blind gold-interpretation kit (Phase 3). The Phase-2 kit was NOT blind: gold_form.csv carried 'stratum' (= silver class) and the
chip titles printed it. This kit:
  - pools the 558 points of the 3 windows, assigns anonymous IDs (G-0001...) in a seeded random order
  - removes stratum, window, row/col and any model output from everything the interpreter sees
  - writes the key (anon -> sample_id, window, stratum, inclusion probability) to data/labels/gold/_key/ (interpreters must not open it)
  - flags a seeded 20 % subset for a SECOND, independent interpretation (inter-annotator agreement)
  - re-renders the Landsat context chips without the stratum and with the anonymous ID
Outputs: data/labels/gold/blind/{gold_blind_form_interpreter1.csv, gold_blind_form_interpreter2.csv, gold_blind_cells.kml, chips_landsat/}"""
import sys, json
import numpy as np, pandas as pd, geopandas as gpd
from shapely.geometry import box
sys.path.insert(0, "src")
from pune_eo import config
from pune_eo.compositing.windows import resolve
from pune_eo.labels import gold as G
from pune_eo.provenance import utcnow
SEED = 20261021; W = ["khadakwasla_mutha", "baramati_agri", "mulshi_ghats"]; EPOCHS = [1990, 2000, 2010, 2020, 2025]
OUT = config.path("data/labels/gold/blind"); KEY = config.path("data/labels/gold/_key"); OUT.mkdir(parents=True, exist_ok=True); KEY.mkdir(parents=True, exist_ok=True)
frames = []
for w in W:
    g = gpd.read_parquet(config.path("data/labels/gold", f"pune_G30_{w}", "gold_sample.parquet")); g["window"] = f"pune_G30_{w}"; frames.append(g)
A = pd.concat(frames, ignore_index=True); rng = np.random.default_rng(SEED); A = A.iloc[rng.permutation(len(A))].reset_index(drop=True)
A["anon_id"] = [f"G-{i + 1:04d}" for i in range(len(A))]
A["double_interpretation"] = False; A.loc[rng.choice(len(A), int(round(0.2 * len(A))), replace=False), "double_interpretation"] = True
A[["anon_id", "sample_id", "window", "stratum", "inclusion_prob", "row", "col", "x_utm", "y_utm", "double_interpretation"]].to_csv(KEY / "gold_key.csv", index=False)
CLASSES = "built_up | agriculture | natural_vegetation | water | bare_sparse | other | uncertain | ambiguous"
cols = ["anon_id", "lat", "lon", "x_utm", "y_utm", "double_interpretation"]
for who in (1, 2):
    F = A[cols].copy() if who == 1 else A.loc[A.double_interpretation, cols].copy()
    for y in EPOCHS:
        for c in ("reference_class", "label_L2", "confidence_1to3", "evidence_source", "evidence_date", "ambiguity_flag", "ambiguity_reason"): F[f"{c}_{y}"] = ""
    F["interpreter"] = ""; F["interpretation_date"] = ""; F["notes"] = ""; F["status"] = "PENDING_INTERPRETATION"
    F.to_csv(OUT / f"gold_blind_form_interpreter{who}.csv", index=False)
cells = gpd.GeoDataFrame(A[["anon_id"]].copy(), geometry=[box(x - 15, y - 15, x + 15, y + 15) for x, y in zip(A.x_utm, A.y_utm)], crs="EPSG:32643")
cells.to_crs(4326).to_file(OUT / "gold_blind_cells.kml", driver="KML")
# blind Landsat context chips (anon id in the title only)
n = 0
for w in W:
    gg, win, wn = resolve("G30", w); sub = gg.subgrid(win, f"_{wn}")
    S = gpd.GeoDataFrame(A[A.window == sub.id].copy()); S["sample_id"] = S["anon_id"]; S["stratum"] = "hidden"
    n += G.make_chips(sub, S, out_dir=OUT / "chips_landsat", blind=True)
json.dump({"created_utc": utcnow(), "seed": SEED, "n_points": len(A), "n_double": int(A.double_interpretation.sum()), "epochs": EPOCHS, "allowed_classes": CLASSES,
           "blind": "no stratum, window, row/col, silver class or model output in forms, KML or chips", "key": "data/labels/gold/_key/gold_key.csv (do not open while interpreting)",
           "chips": n}, open(OUT / "kit.json", "w"), indent=1)
print(len(A), "points;", int(A.double_interpretation.sum()), "double;", n, "blind chips")
