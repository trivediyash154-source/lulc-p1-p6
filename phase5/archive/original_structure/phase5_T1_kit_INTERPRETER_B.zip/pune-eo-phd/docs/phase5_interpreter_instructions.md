# Instructions for human interpreters (gold kit and T1 kit)

You receive one form (CSV) and one KML. You must not receive anything else from the project: no maps, no product layers, no predictions, no list of strata.

1. **Open the KML in Google Earth Pro.** Each point is a yellow 30 m square; the unit you label is that square.
2. **Record each epoch in the order 2020, 2000, 2010, 1990,** following `docs/phase4_gold_protocol.md` §3:
   * Use the historical-imagery slider.
   * Pick an image within ±2 calendar years of the epoch.
   * If no usable image exists, set `status_<epoch> = unavailable` and leave the class empty.
   * Never guess. Use `uncertain` or `ambiguous` when the image does not decide.
3. **Fill these columns for each epoch:**
   * `dominant_class`: one of built_up, agriculture, natural_vegetation, water, bare_sparse, other, uncertain, ambiguous.
   * `dominant_share_3bins`: `>=75`, `50-75` or `<50`.
   * `second_class`: a class, or `none`.
   * `confidence_1to3`: 1, 2 or 3.
   * `imagery_source`: e.g. `GEP_historical`.
   * `imagery_date`: the date of the image you used, as YYYY-MM-DD.
   * `status`: `done`, `unavailable` or `skipped`.
   * `notes`: free text.
4. **Do not change the rest of the form.** Keep `anon_id`, `lat` and `lon` exactly as given, keep every row (even unlabelled ones), and do not add or reorder columns.
5. **Return two files:** the filled CSV, plus a small text file named like the CSV but ending in `.meta.json`:

```json
{"interpreter_role": "A", "interpreter_id": "<your pseudonym>", "interpreter_type": "human", "software": "Google Earth Pro <version>",
 "interpretation_start": "YYYY-MM-DD", "interpretation_end": "YYYY-MM-DD", "blind_declaration": true}
```

* `interpreter_role` is `B` if you received the B form.
* `blind_declaration: true` confirms that you saw only the form and the KML.
* Do not consult the other interpreter.
* Do not use any land-cover product (WorldCover, Esri, Dynamic World, GHSL, …) or any AI tool to decide a label. An imagery source that names such a product or tool is rejected automatically; undeclared use cannot be detected by software, which is why your signed blind declaration matters.
