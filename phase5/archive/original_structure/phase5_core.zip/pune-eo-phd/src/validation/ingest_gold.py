"""Ingest Tier-A human gold for the Phase-4 district design v2 - and FAIL LOUDLY on any protocol violation.

Protocol: docs/phase4_gold_protocol.md, configs/phase4_evaluation_protocol.yaml (v2, frozen). Specification of this pipeline: docs/phase5_gold_ingestion.md.

Inputs (never edited):
  data/labels/gold/phase4/raw_interpreter_A/<name>.csv  + <name>.meta.json      wide blind form, as distributed (form_interpreter_A.csv) and filled in
  data/labels/gold/phase4/raw_interpreter_B/<name>.csv  + <name>.meta.json      the 160-point double subset (form_interpreter_B.csv)
  data/labels/gold/phase4/metadata/freeze_<pass>.json                            SHA-256 of every raw file of a completed pass (freeze_pass())
  data/labels/gold/phase4/adjudicated/<name>.csv                                 anon_id, epoch, label_A, label_B, adjudicated_label, rule, reviewer, date
  data/labels/gold/phase4/_key/phase4_gold_key.csv                               evaluator-only design key (strata, blocks, regions, cells)
Outputs (new files only): data/labels/gold/phase4/ingested/ - long table, final reference labels per epoch, validation report.

Rules enforced (each violation is collected; ingest() raises GoldProtocolError listing ALL of them):
  provenance  raw file frozen (hash matches the LATEST freeze of that path); a path frozen with different contents needs an interpreter-signed correction record
              (metadata/correction_*.json), otherwise RAW_REFROZEN; sidecar meta present; interpreter_type == 'human'; blind declaration true; A and B different people;
              a DECLARED imagery source naming a product/model (WorldCover, Esri, Dynamic World, GHSL, WSF, GISA, GLC, AI/model/Claude/GPT ...) is rejected.
              LIMIT: the code can only check what interpreters declare; undeclared use of products or AI cannot be detected by software - it is excluded by the blind
              process (interpreters receive only the form + KML) and the signed blind declaration.
  identity    every anon_id in the key; no duplicates; A covers all 641 points; B covers exactly the 160 double-interpretation points
  geometry    lat/lon equal the key (1e-6 deg); kind='gold': cell inside the district, inside a validation block, > 2 km from the Phase-3 windows, >= 2 km from training-eligible
              cells; kind='training' (T1): cell inside the district, training-eligible, outside validation blocks, >= 2 km from every gold point
  values      status in {done, unavailable, skipped, ''}; class / share bin / second class / confidence in their vocabularies; imagery_date ISO, calendar year in [epoch-2, epoch+2],
              not after the interpretation end date; 'unavailable' class <=> status unavailable; second_class != dominant_class
  adjudication every A/B disagreement where at least one interpreter gave a definite class has exactly one adjudication row (revision 2, 2026-10-02,
              before any gold: definite-vs-abstention mismatches are adjudicated too, not resolved in favour of A); label_A/label_B there equal the raw labels (no silent overwrite);
              reviewer differs from both interpreters unless rule == 'joint_review'
Nothing is imputed: an empty cell stays empty and is reported as not labelled.
Revision 2 (2026-10-02, after an independent review, before any gold or T1 label existed): re-freeze detection, symmetric adjudication, exact calendar-year window,
tier only for resolved labels, training-sample (T1) mode. docs/phase5_gold_ingestion.md §8."""
from __future__ import annotations
import argparse, datetime as dt, hashlib, json, re, subprocess, sys
from dataclasses import dataclass, field
from pathlib import Path
import numpy as np, pandas as pd

ROOT = Path(__file__).resolve().parents[2]
GOLD = ROOT / "data/labels/gold/phase4"
EPOCHS = (2020, 2000, 2010, 1990)
FIELDS = ("dominant_class", "dominant_share_3bins", "second_class", "confidence_1to3", "imagery_source", "imagery_date", "status", "notes")
DEFINITE = ("built_up", "agriculture", "natural_vegetation", "water", "bare_sparse", "other")
ABSTAIN = ("uncertain", "ambiguous", "unavailable")
CLASSES = DEFINITE + ABSTAIN
SHARE_BINS = (">=75", "50-75", "<50")
STATUS = ("done", "unavailable", "skipped", "")
SOURCES_OK = ("GEP_historical", "Landsat_context", "field", "Sentinel2_context", "other_vhr")
FORBIDDEN_SOURCE = re.compile(r"worldcover|esri|dynamic.?world|ghsl|wsf|gisa|glc|cci|osm|model|predict|classif|\bai\b|claude|gpt|gemini|llm|synthetic|silver", re.I)
DATE_WINDOW_YEARS = 2
COORD_TOL = 1e-6
MIN_DIST_TRAINING_M = 2000.0
MIN_DIST_WINDOWS_M = 2000.0
MIN_DIST_GOLD_M = 2000.0
T1 = ROOT / "data/labels/training/phase5_T1"
KEYS = {"gold": "_key/phase4_gold_key.csv", "training": "_key/phase5_T1_key.csv"}

class GoldProtocolError(RuntimeError):
    """Raised when supplied gold data violate the protocol. The message lists every violation."""

@dataclass
class Report:
    errors: list = field(default_factory=list)
    warnings: list = field(default_factory=list)
    info: dict = field(default_factory=dict)
    def err(self, code, msg, **ctx): self.errors.append({"code": code, "msg": msg, **ctx})
    def warn(self, code, msg, **ctx): self.warnings.append({"code": code, "msg": msg, **ctx})
    @property
    def ok(self): return not self.errors
    def raise_if_errors(self):
        if self.errors:
            head = "\n".join(f"  [{e['code']}] {e['msg']}" for e in self.errors[:60])
            raise GoldProtocolError(f"{len(self.errors)} gold protocol violation(s):\n{head}" + ("\n  ..." if len(self.errors) > 60 else ""))
    def to_dict(self): return {"ok": self.ok, "n_errors": len(self.errors), "n_warnings": len(self.warnings), "errors": self.errors, "warnings": self.warnings, "info": self.info}

def sha256(p: Path) -> str: return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def _utc(): return dt.datetime.now(dt.timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ")
def _git():
    try: return subprocess.run(["git", "-C", str(ROOT), "rev-parse", "--short", "HEAD"], capture_output=True, text=True).stdout.strip() or None
    except Exception: return None

# ----------------------------------------------------------------------------- spatial context
@dataclass
class Spatial:
    """Rasters needed for geometry/leakage checks, on the pune_G30 grid (row/col from the key)."""
    district: np.ndarray
    validation_block: np.ndarray
    dist_training_m: np.ndarray
    dist_windows_m: np.ndarray
    gold_xy: np.ndarray | None = None          # (n, 2) UTM of the gold design points (training mode)

def load_spatial(gold: Path = GOLD) -> Spatial:
    """Production spatial context from the repository rasters. Raises if any is missing - spatial checks are never silently skipped."""
    import rasterio, json as _j
    from scipy.ndimage import distance_transform_edt
    def rd(p):
        if not Path(p).exists(): raise GoldProtocolError(f"spatial check impossible: {p} missing (regenerate with scripts/phase4_products_acquire.py / phase4_validation_design.py)")
        with rasterio.open(p) as s: return s.read(1)
    district = rd(ROOT / "data/products_ext/district/district_mask_30m.tif").astype(bool)
    vb = rd(GOLD / "sampling_design/validation_blocks_30m.tif").astype(bool)          # the design rasters always come from the Phase-4 gold design
    te = rd(GOLD / "sampling_design/training_eligible_30m.tif").astype(bool)
    grid = _j.load(open(GOLD / "sampling_design/design.json"))["grid"]; win = np.zeros(district.shape, bool)
    for w in ("khadakwasla_mutha", "baramati_agri", "mulshi_ghats"):
        gj = _j.load(open(ROOT / "data/labels" / f"pune_G30_{w}" / "splits.json"))["grid"]
        c0 = int(round((gj["x0"] - grid["x0"]) / 30)); r0 = int(round((grid["y1"] - gj["y1"]) / 30))
        win[max(r0, 0):r0 + gj["height"], max(c0, 0):c0 + gj["width"]] = True
    gk = pd.read_csv(GOLD / KEYS["gold"])
    return Spatial(district, vb, distance_transform_edt(~te) * 30.0, distance_transform_edt(~win) * 30.0, gk[["x_utm", "y_utm"]].values)

# ----------------------------------------------------------------------------- freeze
def freeze_pass(pass_id: str, files: list[Path], frozen_by: str, gold: Path = GOLD, note: str = "") -> dict:
    """Record SHA-256 of the raw files of a COMPLETED pass. Immutable: an existing freeze with different content is refused."""
    if not re.fullmatch(r"[A-Za-z0-9_\-]+", pass_id): raise ValueError("pass_id: letters, digits, _ or - only")
    out = gold / "metadata" / f"freeze_{pass_id}.json"
    import time as _t
    rec = {"pass_id": pass_id, "created_utc": _utc(), "created_ns": _t.time_ns(), "frozen_by": frozen_by, "note": note, "code_version": _git(),
           "files": {str(Path(f).resolve().relative_to(gold.resolve())): sha256(f) for f in files}}
    for f in files:
        mp = Path(f).with_suffix(".meta.json")
        if mp.exists(): rec["files"][str(mp.resolve().relative_to(gold.resolve()))] = sha256(mp)
    if out.exists():
        old = json.loads(out.read_text())
        if old["files"] != rec["files"]: raise GoldProtocolError(f"{out.name} exists with different file hashes: raw gold is immutable - start a new pass id")
        return old
    out.parent.mkdir(parents=True, exist_ok=True); out.write_text(json.dumps(rec, indent=1)); return rec

def frozen_hashes(gold: Path = GOLD) -> dict:
    """{relative path: [((created_ns, created_utc), sha256, pass_id), ...] sorted by freeze time} over all freeze records."""
    h = {}
    for p in sorted((gold / "metadata").glob("freeze_*.json")):
        rec = json.loads(p.read_text())
        for rel, s_ in rec["files"].items(): h.setdefault(rel, []).append(((rec.get("created_ns") or 0, rec.get("created_utc", "")), s_, rec.get("pass_id")))
    return {k: sorted(v, key=lambda t: t[0]) for k, v in h.items()}

def corrections(gold: Path = GOLD) -> dict:
    """Interpreter-signed correction records: metadata/correction_*.json with file, previous_sha256, new_sha256, interpreter_id, reason, date, signed_by_interpreter."""
    out = {}
    for p in sorted((gold / "metadata").glob("correction_*.json")):
        c = json.loads(p.read_text()); out.setdefault(c.get("file"), []).append(c)
    return out

def check_frozen(rel: str, path: Path, fz: dict, corr: dict, rep: "Report", what: str = "raw file"):
    """The file must equal the LATEST frozen hash of its path; any change of a frozen path must be covered by a signed correction record."""
    if rel not in fz: rep.err("UNFROZEN", f"{rel}: {what} not frozen (run freeze after the pass is complete)", file=rel); return
    hist = fz[rel]; cur = sha256(path); latest = hist[-1][1]
    if cur != latest:
        rep.err("HASH_MISMATCH" if cur not in {h for _, h, _ in hist} else "STALE_RAW", f"{rel}: content differs from its latest freeze record - raw gold must never be edited", file=rel)
    for (t0, h0, _), (t1, h1, _) in zip(hist, hist[1:]):
        if h0 != h1:
            ok = any(c.get("previous_sha256") == h0 and c.get("new_sha256") == h1 and c.get("signed_by_interpreter") is True and c.get("reason") and c.get("interpreter_id")
                     and _parse_date(c.get("date")) for c in corr.get(rel, []))
            if not ok: rep.err("RAW_REFROZEN", f"{rel}: frozen again with different contents ({h0[:8]} -> {h1[:8]}) without an interpreter-signed correction record", file=rel)
            else: rep.warn("RAW_CORRECTED", f"{rel}: corrected {h0[:8]} -> {h1[:8]} under a signed correction record", file=rel)

# ----------------------------------------------------------------------------- parsing
def load_key(gold: Path = GOLD, kind: str = "gold") -> pd.DataFrame:
    return pd.read_csv(gold / KEYS[kind])

def wide_to_long(df: pd.DataFrame, role: str, meta: dict, source_file: str) -> pd.DataFrame:
    rows = []
    for _, r in df.iterrows():
        for e in EPOCHS:
            rec = {"anon_id": r["anon_id"], "lat": r["lat"], "lon": r["lon"], "epoch": e, "interpreter_role": role, "interpreter_id": meta.get("interpreter_id"), "source_file": source_file}
            for f in FIELDS:
                v = r.get(f"{f}_{e}", "")
                rec[f] = "" if (v is None or (isinstance(v, float) and np.isnan(v))) else str(v).strip()
            rows.append(rec)
    return pd.DataFrame(rows)

def _parse_date(s):
    try: return dt.date.fromisoformat(str(s)[:10]) if len(str(s)) >= 10 else None
    except ValueError: return None

# ----------------------------------------------------------------------------- validation
def validate_meta(meta: dict, role: str, fname: str, rep: Report):
    for k in ("interpreter_role", "interpreter_id", "interpreter_type", "software", "interpretation_start", "interpretation_end", "blind_declaration"):
        if k not in meta or meta[k] in (None, ""): rep.err("META_MISSING", f"{fname}: meta field '{k}' missing", file=fname)
    if meta.get("interpreter_role") not in (None, role): rep.err("META_ROLE", f"{fname}: meta role {meta.get('interpreter_role')} but file is in raw_interpreter_{role}", file=fname)
    if meta.get("interpreter_type") not in (None, "human"): rep.err("NOT_HUMAN", f"{fname}: interpreter_type must be 'human' (Tier A); got {meta.get('interpreter_type')!r}", file=fname)
    if meta.get("blind_declaration") is not True and "blind_declaration" in meta: rep.err("NOT_BLIND", f"{fname}: blind_declaration must be true (interpreter saw only the blind/ folder)", file=fname)
    if FORBIDDEN_SOURCE.search(str(meta.get("interpreter_id", ""))) or FORBIDDEN_SOURCE.search(str(meta.get("software", ""))):
        rep.err("NOT_HUMAN", f"{fname}: interpreter id/software names a model or product", file=fname)
    s, e = _parse_date(meta.get("interpretation_start")), _parse_date(meta.get("interpretation_end"))
    if "interpretation_start" in meta and s is None: rep.err("META_DATE", f"{fname}: interpretation_start not ISO date", file=fname)
    if "interpretation_end" in meta and e is None: rep.err("META_DATE", f"{fname}: interpretation_end not ISO date", file=fname)
    if s and e and e < s: rep.err("META_DATE", f"{fname}: interpretation_end before start", file=fname)
    if e and e > dt.date.today(): rep.err("META_DATE", f"{fname}: interpretation_end in the future", file=fname)

def validate_values(L: pd.DataFrame, rep: Report, interp_end: dict):
    for i, r in L.iterrows():
        tag = f"{r.interpreter_role}:{r.anon_id}:{r.epoch}"; st, cl = r.status, r.dominant_class
        if st not in STATUS: rep.err("STATUS", f"{tag}: status {st!r} not in {STATUS}"); continue
        if cl and cl not in CLASSES: rep.err("CLASS", f"{tag}: dominant_class {cl!r} not in vocabulary")
        if cl == "unavailable" and st != "unavailable": rep.err("UNAVAILABLE_STATUS", f"{tag}: class 'unavailable' requires status 'unavailable'")
        if st == "unavailable" and cl not in ("", "unavailable"): rep.err("UNAVAILABLE_STATUS", f"{tag}: status 'unavailable' but a class ({cl}) was given")
        if st == "" and any(r[f] for f in FIELDS if f not in ("status", "notes")): rep.err("STATUS_EMPTY", f"{tag}: fields filled but status empty")
        if st == "skipped" and cl: rep.err("SKIPPED_WITH_CLASS", f"{tag}: status 'skipped' but a class was given")
        if st == "done":
            if not cl: rep.err("DONE_NO_CLASS", f"{tag}: status done without dominant_class")
            if cl in DEFINITE:
                if r.dominant_share_3bins not in SHARE_BINS: rep.err("SHARE", f"{tag}: dominant_share_3bins {r.dominant_share_3bins!r} not in {SHARE_BINS}")
                if r.confidence_1to3 not in ("1", "2", "3", "1.0", "2.0", "3.0"): rep.err("CONFIDENCE", f"{tag}: confidence_1to3 {r.confidence_1to3!r} not 1/2/3")
            sc = r.second_class
            if sc and sc != "none" and sc not in DEFINITE: rep.err("SECOND_CLASS", f"{tag}: second_class {sc!r} not in vocabulary")
            if sc and sc == cl: rep.err("SECOND_CLASS", f"{tag}: second_class equals dominant_class")
            src = r.imagery_source
            if not src: rep.err("SOURCE_MISSING", f"{tag}: imagery_source empty")
            elif FORBIDDEN_SOURCE.search(src): rep.err("FORBIDDEN_SOURCE", f"{tag}: imagery_source {src!r} names a product/model - not allowed in Tier A")
            elif src.split(":")[0] not in SOURCES_OK: rep.warn("SOURCE_VOCAB", f"{tag}: imagery_source {src!r} outside the listed vocabulary {SOURCES_OK}")
            d = _parse_date(r.imagery_date)
            if d is None: rep.err("IMAGERY_DATE", f"{tag}: imagery_date {r.imagery_date!r} not YYYY-MM-DD")
            else:
                if not (r.epoch - DATE_WINDOW_YEARS <= d.year <= r.epoch + DATE_WINDOW_YEARS):
                    rep.err("IMAGERY_DATE_WINDOW", f"{tag}: imagery_date {d} outside epoch {r.epoch} +-{DATE_WINDOW_YEARS} y -> must be 'unavailable'")
                end = interp_end.get(r.source_file)
                if end and d > end: rep.err("IMAGERY_DATE_FUTURE", f"{tag}: imagery_date {d} after interpretation end {end}")
                if d.year < 1972: rep.err("IMAGERY_DATE", f"{tag}: imagery_date before 1972")

def validate_identity_geometry(L: pd.DataFrame, role: str, K: pd.DataFrame, sp: Spatial | None, rep: Report, fname: str, kind: str = "gold"):
    W = L.drop_duplicates("anon_id")
    unknown = sorted(set(W.anon_id) - set(K.anon_id))
    if unknown: rep.err("UNKNOWN_ID", f"{fname}: {len(unknown)} anon_id not in the design key (e.g. {unknown[:3]})", file=fname)
    dup = L.groupby(["anon_id", "epoch"]).size(); dup = dup[dup > 1]
    if len(dup): rep.err("DUPLICATE", f"{fname}: {len(dup)} duplicated (anon_id, epoch) rows", file=fname)
    expect = set(K.anon_id) if role == "A" else set(K.anon_id[K.double_interpretation.astype(bool)])
    miss, extra = sorted(expect - set(W.anon_id)), sorted(set(W.anon_id) - expect - set(unknown))
    if miss: rep.err("MISSING_POINTS", f"{fname}: {len(miss)} design points absent from the form (rows must stay, even if unlabelled)", file=fname)
    if extra: rep.err("NOT_IN_SUBSET", f"{fname}: {len(extra)} points are not in interpreter {role}'s subset", file=fname)
    m = W.merge(K[["anon_id", "lat", "lon", "row", "col"]], on="anon_id", how="inner", suffixes=("", "_key"))
    moved = m[(np.abs(pd.to_numeric(m.lat, errors="coerce") - m.lat_key) > COORD_TOL) | (np.abs(pd.to_numeric(m.lon, errors="coerce") - m.lon_key) > COORD_TOL)]
    if len(moved): rep.err("COORDINATES_CHANGED", f"{fname}: {len(moved)} points have lat/lon different from the design (e.g. {moved.anon_id.head(3).tolist()})", file=fname)
    if sp is None:
        rep.warn("SPATIAL_NOT_CHECKED", "raster-based geometry/leakage checks NOT run (no spatial context) - allowed in unit tests only; production ingest() requires them"); return
    r, c = m.row.values.astype(int), m.col.values.astype(int)
    if kind == "gold":
        checks = (("OUTSIDE_DISTRICT", ~sp.district[r, c]), ("OUTSIDE_VALIDATION_BLOCK", ~sp.validation_block[r, c]),
                  ("TOO_CLOSE_TO_TRAINING", sp.dist_training_m[r, c] < MIN_DIST_TRAINING_M), ("INSIDE_PHASE3_WINDOWS", sp.dist_windows_m[r, c] <= MIN_DIST_WINDOWS_M))
        rep.info.setdefault("min_distance_to_training_m", float(sp.dist_training_m[r, c].min()) if len(r) else None)
    else:
        from scipy.spatial import cKDTree
        xy = K.set_index("anon_id").loc[m.anon_id, ["x_utm", "y_utm"]].values
        dg = cKDTree(sp.gold_xy).query(xy)[0] if sp.gold_xy is not None and len(xy) else np.full(len(xy), np.inf)
        checks = (("OUTSIDE_DISTRICT", ~sp.district[r, c]), ("TRAINING_IN_VALIDATION_BLOCK", sp.validation_block[r, c]),
                  ("TRAINING_NOT_ELIGIBLE", sp.dist_training_m[r, c] > 0), ("TOO_CLOSE_TO_GOLD", dg < MIN_DIST_GOLD_M))
        rep.info.setdefault("min_distance_to_gold_m", float(dg.min()) if len(dg) else None)
    for name, bad in checks:
        if bad.any(): rep.err(name, f"{fname}: {int(bad.sum())} points fail {name} (e.g. {m.anon_id[bad].head(3).tolist()})", file=fname)

def read_raw(gold: Path, rep: Report, require_freeze: bool = True) -> dict:
    """Read every raw form + meta. Returns {role: [(fname, long_df, meta)]}."""
    fz = frozen_hashes(gold) if require_freeze else {}; corr = corrections(gold); out = {"A": [], "B": []}
    for role in ("A", "B"):
        for p in sorted((gold / f"raw_interpreter_{role}").glob("*.csv")):
            rel = str(p.resolve().relative_to(gold.resolve())); mp = p.with_suffix(".meta.json")
            if require_freeze:
                check_frozen(rel, p, fz, corr, rep)
                if mp.exists(): check_frozen(str(mp.resolve().relative_to(gold.resolve())), mp, fz, corr, rep, "meta file")
            if not mp.exists(): rep.err("META_MISSING", f"{rel}: sidecar {mp.name} missing", file=rel); meta = {}
            else: meta = json.loads(mp.read_text())
            validate_meta(meta, role, rel, rep)
            df = pd.read_csv(p, dtype=str, keep_default_na=False)
            need = ["anon_id", "lat", "lon"] + [f"{f}_{e}" for e in EPOCHS for f in FIELDS]
            miss = [c for c in need if c not in df.columns]
            if miss: rep.err("SCHEMA", f"{rel}: missing columns {miss[:6]}{'...' if len(miss) > 6 else ''}", file=rel); continue
            extra = [c for c in df.columns if c not in need]
            if extra: rep.warn("SCHEMA_EXTRA", f"{rel}: extra columns ignored {extra[:6]}", file=rel)
            df["lat"] = pd.to_numeric(df["lat"], errors="coerce"); df["lon"] = pd.to_numeric(df["lon"], errors="coerce")
            out[role].append((rel, wide_to_long(df, role, meta, rel), meta))
    return out

def validate_adjudication(final_pairs: pd.DataFrame, adj: pd.DataFrame | None, ids: dict, rep: Report):
    """final_pairs: rows (anon_id, epoch, label_A, label_B) for double points whose labels differ and at least one is a DEFINITE class."""
    need = ["anon_id", "epoch", "label_A", "label_B", "adjudicated_label", "rule", "reviewer", "date"]
    if len(final_pairs) == 0: return pd.DataFrame(columns=need)
    if adj is None or len(adj) == 0:
        rep.err("ADJUDICATION_MISSING", f"{len(final_pairs)} A/B disagreements have no adjudication file/rows"); return pd.DataFrame(columns=need)
    miss = [c for c in need if c not in adj.columns]
    if miss: rep.err("ADJ_SCHEMA", f"adjudication missing columns {miss}"); return pd.DataFrame(columns=need)
    adj = adj.copy(); adj["epoch"] = pd.to_numeric(adj.epoch, errors="coerce").astype("Int64")
    d = adj.groupby(["anon_id", "epoch"]).size()
    if (d > 1).any(): rep.err("ADJ_DUPLICATE", f"{int((d > 1).sum())} point-epochs adjudicated more than once")
    m = final_pairs.merge(adj, on=["anon_id", "epoch"], how="left", suffixes=("", "_adj"))
    if m.adjudicated_label.isna().any(): rep.err("ADJUDICATION_MISSING", f"{int(m.adjudicated_label.isna().sum())} disagreements without adjudication (e.g. {m[m.adjudicated_label.isna()].anon_id.head(3).tolist()})")
    mm = m.dropna(subset=["adjudicated_label"])
    ow = mm[(mm.label_A != mm.label_A_adj) | (mm.label_B != mm.label_B_adj)]
    if len(ow): rep.err("ADJ_OVERWRITE", f"{len(ow)} adjudication rows quote label_A/label_B different from the raw forms (silent overwrite)")
    bad = mm[~mm.adjudicated_label.isin(CLASSES)]
    if len(bad): rep.err("ADJ_CLASS", f"{len(bad)} adjudicated labels outside the vocabulary")
    for _, r in mm.iterrows():
        if not str(r.reviewer).strip(): rep.err("ADJ_REVIEWER", f"{r.anon_id}:{r.epoch}: reviewer empty")
        elif r.rule != "joint_review" and str(r.reviewer) in (ids.get("A"), ids.get("B")): rep.err("ADJ_REVIEWER", f"{r.anon_id}:{r.epoch}: reviewer is one of the interpreters (use rule 'joint_review' if done jointly)")
        if _parse_date(r.date) is None: rep.err("ADJ_DATE", f"{r.anon_id}:{r.epoch}: adjudication date not ISO")
    extra = adj.merge(final_pairs[["anon_id", "epoch"]], on=["anon_id", "epoch"], how="left", indicator=True)
    if (extra._merge == "left_only").any(): rep.warn("ADJ_EXTRA", f"{int((extra._merge == 'left_only').sum())} adjudication rows for point-epochs that need no adjudication")
    return mm[need]

def assemble(LA: pd.DataFrame, LB: pd.DataFrame | None, adj: pd.DataFrame | None, K: pd.DataFrame, rep: Report, ids: dict) -> pd.DataFrame:
    """Final reference label per (anon_id, epoch). Single points: A. Double points: A if A == B, else the adjudicated label. Abstentions kept and flagged."""
    def eff(L):   # effective label: 'unavailable' status -> 'unavailable'; empty/skipped -> '' (not labelled)
        return np.where(L.status == "unavailable", "unavailable", np.where(L.status == "done", L.dominant_class, ""))
    A = LA.set_index(["anon_id", "epoch"]); out = A[["dominant_class", "dominant_share_3bins", "second_class", "confidence_1to3", "imagery_source", "imagery_date", "status"]].copy()
    out["label_A"] = eff(A); out["label_B"] = ""; out["reference_label"] = out["label_A"]; out["label_source"] = np.where(out.label_A == "", "not_labelled", "A")
    if LB is not None and len(LB):
        B = LB.set_index(["anon_id", "epoch"]); idx = out.index.intersection(B.index); out.loc[idx, "label_B"] = pd.Series(eff(B), index=B.index).loc[idx]
        both = out.loc[idx]; rec = (both.label_A != "") & (both.label_B != ""); same = rec & (both.label_A == both.label_B)
        out.loc[both.index[same], "label_source"] = "A=B"
        out.loc[both.index[(both.label_A != "") & (both.label_B == "")], "label_source"] = "A_only_B_not_labelled"
        out.loc[both.index[(both.label_A == "") & (both.label_B != "")], "label_source"] = "B_only_A_not_labelled"   # reference stays empty (A is the reference interpreter)
        dis = both[rec & ~same]; need_adj = dis.label_A.isin(DEFINITE) | dis.label_B.isin(DEFINITE)
        pairs = dis[need_adj].reset_index()[["anon_id", "epoch", "label_A", "label_B"]]
        adjv = validate_adjudication(pairs, adj, ids, rep)
        for _, r in adjv.iterrows(): out.loc[(r.anon_id, int(r.epoch)), ["reference_label", "label_source"]] = [r.adjudicated_label, "adjudicated"]
        for k in dis[~need_adj].index:   # both abstained, differently (e.g. uncertain vs unavailable): an abstention either way, never a class
            out.loc[k, ["reference_label", "label_source"]] = ["uncertain", "both_abstained_differently"]
        unres = pairs.merge(adjv[["anon_id", "epoch"]], on=["anon_id", "epoch"], how="left", indicator=True)
        for _, r in unres[unres._merge == "left_only"].iterrows(): out.loc[(r.anon_id, int(r.epoch)), ["reference_label", "label_source"]] = ["", "unadjudicated"]
    cols = [c for c in ("anon_id", "stratum", "region", "block", "row", "col", "x_utm", "y_utm", "stratum_area_cells", "n_stratum_sample", "double_interpretation", "boundary", "split") if c in K.columns]
    out = out.reset_index().merge(K[cols], on="anon_id", how="left")
    resolved = out.label_source != "unadjudicated"
    out["labelled"] = resolved & (out.reference_label.isin(DEFINITE) | (out.reference_label == "unavailable"))     # G2 'labelled' (revision 2)
    out["abstained"] = resolved & out.reference_label.isin(["uncertain", "ambiguous"])
    out["in_accuracy_set"] = resolved & out.reference_label.isin(DEFINITE)
    out["tier"] = np.where(resolved & (out.reference_label != ""), "A", "")
    return out

def ingest(gold: Path = GOLD, spatial: Spatial | str | None = "load", require_freeze: bool = True, write: bool = True, kind: str = "gold") -> tuple[pd.DataFrame, Report]:
    """Full ingestion. kind='gold' (Phase-4 design, data/labels/gold/phase4) or 'training' (T1, data/labels/training/phase5_T1).
    spatial='load' (production) loads rasters and fails if absent; None only for unit tests (recorded as a warning)."""
    assert kind in KEYS; rep = Report(); K = load_key(gold, kind); rep.info["kind"] = kind
    sp = load_spatial(gold) if spatial == "load" else spatial
    raw = read_raw(gold, rep, require_freeze)
    if not raw["A"]: rep.err("NO_INTERPRETER_A", f"no raw_interpreter_A/*.csv: there are no human {'gold' if kind == 'gold' else 'T1 training'} labels to ingest"); rep.raise_if_errors()
    if len(raw["A"]) > 1: rep.err("MULTIPLE_A_FILES", f"{len(raw['A'])} interpreter-A files; supply one complete form per interpreter (later passes replace via a new freeze id)")
    if len(raw["B"]) > 1: rep.err("MULTIPLE_B_FILES", f"{len(raw['B'])} interpreter-B files")
    ends = {}
    for role in ("A", "B"):
        for fname, L, meta in raw[role]:
            ends[fname] = _parse_date(meta.get("interpretation_end")); validate_identity_geometry(L, role, K, sp, rep, fname, kind)
    ids = {role: (raw[role][0][2].get("interpreter_id") if raw[role] else None) for role in ("A", "B")}
    if ids["A"] and ids["B"] and ids["A"] == ids["B"]: rep.err("SAME_INTERPRETER", "interpreters A and B have the same id - double interpretation must be independent")
    LA = raw["A"][0][1]; LB = raw["B"][0][1] if raw["B"] else None
    validate_values(LA, rep, ends)
    if LB is not None: validate_values(LB, rep, ends)
    adj_files = sorted((gold / "adjudicated").glob("*.csv")); adj = pd.concat([pd.read_csv(p, dtype=str, keep_default_na=False) for p in adj_files]) if adj_files else None
    if require_freeze:
        fz, corr = frozen_hashes(gold), corrections(gold)
        for p in adj_files: check_frozen(str(p.resolve().relative_to(gold.resolve())), p, fz, corr, rep, "adjudication file")
    final = assemble(LA, LB, adj, K, rep, ids)
    rep.info.update({"n_points_key": len(K), "files": {r: [f for f, _, _ in raw[r]] for r in raw}, "interpreters": ids, "ingested_utc": _utc(), "code_version": _git(),
                     "labelled_share_by_epoch": final.groupby("epoch").labelled.mean().round(4).to_dict(), "label_source_counts": final.label_source.value_counts().to_dict()})
    if write:
        od = gold / "ingested"; od.mkdir(exist_ok=True)
        (od / "validation_report.json").write_text(json.dumps(rep.to_dict(), indent=1, default=str))
        if rep.ok:
            pd.concat([LA] + ([LB] if LB is not None else [])).to_csv(od / "gold_long_all_interpreters.csv", index=False)
            final.to_csv(od / "gold_reference_labels.csv", index=False)
            (od / "PROVENANCE.json").write_text(json.dumps({"raw_sha256": {f: sha256(gold / f) for r in raw for f, _, _ in raw[r]}, "adjudication_sha256": {p.name: sha256(p) for p in adj_files},
                                                            "key_sha256": sha256(gold / KEYS[kind]), "kind": kind, "code_version": _git(), "created_utc": _utc()}, indent=1))
    rep.raise_if_errors()
    return final, rep

def main(argv=None):
    ap = argparse.ArgumentParser(description=__doc__.split("\n")[0]); sp = ap.add_subparsers(dest="cmd", required=True)
    ap.add_argument("--kind", choices=["gold", "training"], default="gold", help="gold = Phase-4 district design; training = T1 sample")
    f = sp.add_parser("freeze", help="freeze the raw files of a completed pass"); f.add_argument("pass_id"); f.add_argument("--by", required=True); f.add_argument("--note", default="")
    sp.add_parser("ingest", help="validate + assemble (fails loudly)")
    a = ap.parse_args(argv); base = GOLD if a.kind == "gold" else T1
    if a.cmd == "freeze":
        files = sorted((base / "raw_interpreter_A").glob("*.csv")) + sorted((base / "raw_interpreter_B").glob("*.csv")) + sorted((base / "adjudicated").glob("*.csv"))
        if not files: print("no raw files to freeze"); return 2
        print(json.dumps(freeze_pass(a.pass_id, files, a.by, gold=base, note=a.note), indent=1)); return 0
    try:
        final, rep = ingest(base, kind=a.kind); print(json.dumps(rep.info, indent=1, default=str)); return 0
    except GoldProtocolError as e:
        print(str(e), file=sys.stderr); return 1

if __name__ == "__main__": sys.exit(main())
