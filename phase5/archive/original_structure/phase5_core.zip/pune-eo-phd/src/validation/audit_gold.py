"""Audit ingested Tier-A gold and evaluate Gate G2 exactly as written in the frozen protocol v2.

G2 (configs/phase4_evaluation_protocol.yaml): ">= 80 % of district design points labelled for epochs 2020 and 2000 (unavailable imagery recorded, not guessed);
>= 20 % double interpreted with Cohen kappa >= 0.6; adjudication logged".
Operational definitions FIXED BEFORE ANY GOLD EXISTS (docs/phase5_gold_ingestion.md; revision 2 on 2026-10-02 after independent review, still before any gold):
  labelled      resolved reference label that is a DEFINITE class or 'unavailable' (imagery recorded as unavailable, not guessed); 'uncertain'/'ambiguous' are reported
                as abstentions but do NOT count as labelled (revision 1 counted them; tightened so a pass of mostly 'uncertain' cannot meet G2)
  double        design points with a status-'done'/'unavailable' record from BOTH A and B for the epoch, share of 641
  kappa         primary: Cohen's kappa A vs B per epoch over double points where BOTH gave a definite class (built_up, agriculture, natural_vegetation, water,
                bare_sparse, other), computed only if n >= 30 such points (else NOT MEASURED -> criterion fails); secondary (reported, not gating): abstention codes as
                extra categories
  adjudication  every definite-class A/B disagreement has a valid adjudication row (ingest_gold enforces) and no point-epoch is 'unadjudicated'
  G2 passes only if all four hold for BOTH 2020 and 2000.
Also: completeness/abstention/unavailability by epoch, stratum, region; confidence and imagery-date offsets; and a leakage audit for any TRAINING label table."""
from __future__ import annotations
import argparse, json, sys
from pathlib import Path
import numpy as np, pandas as pd
sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from validation import ingest_gold as IG            # noqa: E402
from pune_eo.labels.gold_qa import cohen_kappa, krippendorff_alpha_nominal   # noqa: E402

G2 = {"labelled_min": 0.80, "double_min": 0.20, "kappa_min": 0.60, "kappa_min_n": 30, "epochs": (2020, 2000)}
OUT = IG.ROOT / "results/phase5/gold"

def _check_protocol_text():
    import yaml
    g = yaml.safe_load(open(IG.ROOT / "configs/phase4_evaluation_protocol.yaml"))["gates"]["G2_human_validation"]
    for tok in ("80 %", "2020 and 2000", "20 %", "kappa >= 0.6", "adjudication logged"):
        if tok not in g: raise RuntimeError(f"protocol G2 text changed ('{tok}' missing): update audit_gold only via a new protocol version")
    return g

def agreement(final: pd.DataFrame, long: pd.DataFrame, epoch: int) -> dict:
    A = long[(long.interpreter_role == "A") & (long.epoch == epoch)].set_index("anon_id"); B = long[(long.interpreter_role == "B") & (long.epoch == epoch)].set_index("anon_id")
    idx = A.index.intersection(B.index); a, b = A.loc[idx], B.loc[idx]
    rec = a.status.isin(["done", "unavailable"]) & b.status.isin(["done", "unavailable"])
    d = rec & a.dominant_class.isin(IG.DEFINITE) & b.dominant_class.isin(IG.DEFINITE)
    k1 = cohen_kappa(a.dominant_class[d].values, b.dominant_class[d].values) if d.sum() >= G2["kappa_min_n"] else float("nan")   # NaN = NOT MEASURED (n < 30)
    ca, cb = a.dominant_class.where(a.status != "unavailable", "unavailable"), b.dominant_class.where(b.status != "unavailable", "unavailable")
    k2 = cohen_kappa(ca[rec].values, cb[rec].values) if rec.sum() >= 2 else float("nan")
    alpha = krippendorff_alpha_nominal([[x, y] for x, y in zip(ca[rec], cb[rec])]) if rec.sum() >= 2 else float("nan")
    return {"n_double_records": int(rec.sum()), "double_share_of_design": float(rec.sum() / max(1, final.anon_id.nunique())), "n_both_definite": int(d.sum()),
            "raw_agreement_definite": float((a.dominant_class[d] == b.dominant_class[d]).mean()) if d.sum() else float("nan"),
            "kappa_primary_definite": k1, "kappa_secondary_with_abstentions": k2, "krippendorff_alpha_with_abstentions": alpha}

def g2(final: pd.DataFrame | None, long: pd.DataFrame | None) -> dict:
    gtxt = _check_protocol_text()
    if final is None or len(final) == 0:
        return {"gate": "G2_human_validation", "status": "FAIL", "protocol_text": gtxt, "reason": "no Tier-A gold has been ingested (0 labels)", "per_epoch": {}}
    per = {}
    for e in G2["epochs"]:
        f = final[final.epoch == e]; ag = agreement(final, long, e)
        lab = float(f.labelled.mean()); unadj = int((f.label_source == "unadjudicated").sum())
        crit = {"labelled_ge_0.80": lab >= G2["labelled_min"], "double_ge_0.20": ag["double_share_of_design"] >= G2["double_min"],
                "kappa_ge_0.60": bool(np.isfinite(ag["kappa_primary_definite"]) and ag["kappa_primary_definite"] >= G2["kappa_min"]), "adjudication_complete": unadj == 0}
        per[e] = {"labelled_share": lab, "abstained_share": float(f.abstained.mean()), "unadjudicated": unadj, **ag, "kappa_measured": bool(np.isfinite(ag["kappa_primary_definite"])), "criteria": crit, "pass": all(crit.values())}
    ok = all(v["pass"] for v in per.values())
    return {"gate": "G2_human_validation", "status": "PASS" if ok else "FAIL", "protocol_text": gtxt, "per_epoch": per,
            "reason": "all criteria met for 2020 and 2000" if ok else "; ".join(f"{e}: " + ", ".join(k for k, v in d["criteria"].items() if not v) for e, d in per.items() if not d["pass"])}

def describe(final: pd.DataFrame) -> dict:
    out = {}
    for e, f in final.groupby("epoch"):
        d = f[f.status == "done"]
        off = (pd.to_datetime(d.imagery_date, errors="coerce").dt.year - e).value_counts().sort_index().to_dict()
        out[int(e)] = {"labelled_share": float(f.labelled.mean()), "unavailable_share": float((f.reference_label == "unavailable").mean()), "abstained_share": float(f.abstained.mean()),
                       "abstention_share_of_done": float(d.reference_label.isin(["uncertain", "ambiguous"]).mean()) if len(d) else None,
                       "accuracy_set_n": int(f.in_accuracy_set.sum()), "class_counts": f[f.in_accuracy_set].reference_label.value_counts().to_dict(),
                       "outside_legend_n": int(f.reference_label.isin(["bare_sparse", "other"]).sum()),
                       "labelled_share_by_region": f.groupby("region").labelled.mean().round(3).to_dict() if "region" in f else None,
                       "labelled_share_by_stratum": f.groupby("stratum").labelled.mean().round(3).to_dict() if "stratum" in f else None,
                       "confidence_counts": d.confidence_1to3.value_counts().to_dict(), "imagery_year_offset_counts": {int(k): int(v) for k, v in off.items()},
                       "imagery_sources": d.imagery_source.value_counts().to_dict(), "label_source_counts": f.label_source.value_counts().to_dict()}
    return out

def audit_training_labels(df: pd.DataFrame, spatial: IG.Spatial, key: pd.DataFrame, grid: dict) -> dict:
    """Leakage audit for a TRAINING label table with x_utm, y_utm (EPSG:32643): must avoid validation blocks + 2 km and stay >= 2 km from every gold point."""
    from scipy.spatial import cKDTree
    c = np.floor((df.x_utm.values - grid["x0"]) / 30).astype(int); r = np.floor((grid["y1"] - df.y_utm.values) / 30).astype(int)
    inb = (r >= 0) & (r < spatial.district.shape[0]) & (c >= 0) & (c < spatial.district.shape[1])
    rr, cc = np.clip(r, 0, spatial.district.shape[0] - 1), np.clip(c, 0, spatial.district.shape[1] - 1)
    in_val = inb & spatial.validation_block[rr, cc]; near = inb & (spatial.dist_training_m[rr, cc] > 0)   # dist_training 0 == eligible cell
    d, _ = cKDTree(key[["x_utm", "y_utm"]].values).query(np.c_[df.x_utm.values, df.y_utm.values])
    res = {"n": int(len(df)), "outside_grid": int((~inb).sum()), "outside_district": int((inb & ~spatial.district[rr, cc]).sum()), "in_validation_blocks": int(in_val.sum()),
           "not_training_eligible": int(near.sum()), "min_distance_to_gold_m": float(d.min()) if len(d) else None, "within_2km_of_gold": int((d < 2000).sum())}
    res["ok"] = res["outside_grid"] == 0 and res["in_validation_blocks"] == 0 and res["not_training_eligible"] == 0 and res["within_2km_of_gold"] == 0
    return res

def run_t1(t1: Path = IG.T1, out: Path = IG.ROOT / "results/phase5/t1", spatial="load") -> dict:
    """Ingest + describe the human TRAINING sample T1 (training-leakage rules). No gate; the P4-C1@v2 checklist requires ingest PASS."""
    out.mkdir(parents=True, exist_ok=True); rep = {"created_utc": IG._utc(), "code_version": IG._git()}
    try:
        final, irep = IG.ingest(t1, spatial=spatial, write=True, kind="training")
        rep.update(ingest="PASS", ingest_warnings=irep.warnings, description=describe(final), min_distance_to_gold_m=irep.info.get("min_distance_to_gold_m"))
    except IG.GoldProtocolError as e:
        rep.update(ingest="FAIL", ingest_error=str(e))
    (out / "t1_audit.json").write_text(json.dumps(rep, indent=1, default=str)); return rep

def run(gold: Path = IG.GOLD, out: Path = OUT, spatial="load") -> dict:
    out.mkdir(parents=True, exist_ok=True); rep = {"created_utc": IG._utc(), "code_version": IG._git()}
    try:
        final, irep = IG.ingest(gold, spatial=spatial, write=True)
        long = pd.read_csv(gold / "ingested/gold_long_all_interpreters.csv", dtype={"confidence_1to3": str}, keep_default_na=False)
        long["epoch"] = long.epoch.astype(int)
        rep.update(ingest="PASS", ingest_warnings=irep.warnings, g2=g2(final, long), description=describe(final))
    except IG.GoldProtocolError as e:
        rep.update(ingest="FAIL", ingest_error=str(e), g2=g2(None, None))
    (out / "gold_audit.json").write_text(json.dumps(rep, indent=1, default=str))
    return rep

if __name__ == "__main__":
    ap = argparse.ArgumentParser(); ap.add_argument("--out", default=str(OUT)); ap.add_argument("--t1", action="store_true", help="audit the T1 training sample instead"); a = ap.parse_args()
    if a.t1: r = run_t1(); print(json.dumps({k: r.get(k) for k in ("ingest", "ingest_error")}, indent=1, default=str)[:2000])
    else: r = run(out=Path(a.out)); print(json.dumps({k: r[k] for k in ("ingest", "g2")}, indent=1, default=str)[:3000])
