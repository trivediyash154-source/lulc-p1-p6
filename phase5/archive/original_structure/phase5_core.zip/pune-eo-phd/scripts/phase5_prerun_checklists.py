"""Automated PRE-RUN CHECKLIST for every active confirmatory record (P4-C1@v2 ... P4-C6@v2). Read-only.
If any item fails the experiment MUST NOT run; `assert_runnable(eid)` is the guard any future confirmatory runner must call first.
LIMIT: the frozen registry class protocol.Run cannot call this guard (protocol.py is hash-pinned); enforcement is by convention + tests/test_phase5_guards.py.
Items: protocol hashes unchanged; registry status PENDING + G8 check; Tier-A gold ingested and G2 passed for the experiment's epochs; human training labels (C1 arms C-E);
addendum approved where the record is under-specified; validation blocks and training exclusion verified; district cube validated for the registered epochs/periods;
registered feature set available on the district grid; model-selection prerequisites (tuning rule; C1 completed for C2-C6); seeds == protocol seeds; test + FDR family defined."""
import json, sys
from pathlib import Path
sys.path.insert(0, "src")
import yaml
from pune_eo import config
from pune_eo.evaluation4 import protocol as P4
from pune_eo.provenance import utcnow
OUT = config.path("results/phase5/confirmatory"); OUT.mkdir(parents=True, exist_ok=True)
EPOCHS = {"P4-C1@v2": [2020, 2010, 2000, 1990], "P4-C2@v2": [1990, 2000], "P4-C3@v2": [1990, 2000, 2010, 2020], "P4-C4@v2": [2020], "P4-C5@v2": [2020, 2000], "P4-C6@v2": [2020]}
def J(p):
    p = config.path(p); return json.loads(p.read_text()) if p.exists() else None

def checklist(eid: str) -> dict:
    rec = P4.load(eid); proto = P4.load_protocol(); fz = proto["frozen"]; items = {}
    def it(name, ok, evidence): items[name] = {"ok": bool(ok), "evidence": evidence}
    it("protocol_code_hash_unchanged", P4.code_hash() == fz["code_sha256"] == rec.get("eval_code_sha256"), P4.code_hash()[:12])
    it("protocol_yaml_hash_unchanged", P4.protocol_hash() == fz["protocol_sha256"], P4.protocol_hash()[:12])
    it("protocol_version_matches_record", rec.get("protocol_version") == proto["protocol_version"], rec.get("protocol_version"))
    cc = P4.check_confirmatory_records(); it("registry_status_pending_and_G8_ok", rec["status"] == "PENDING" and cc["records"].get(eid, {}).get("ok", False), rec["status"])
    ga = J("results/phase5/gold/gold_audit.json") or {}
    it("tier_A_gold_ingested", ga.get("ingest") == "PASS", ga.get("ingest_error", "no audit")[:120] if ga.get("ingest") != "PASS" else "PASS")
    g2 = ga.get("g2", {}); per = g2.get("per_epoch", {})
    need = [e for e in EPOCHS[eid] if e in (2020, 2000)]
    it("G2_passed_for_2020_and_2000", g2.get("status") == "PASS", g2.get("reason"))
    for e in EPOCHS[eid]:
        d = (ga.get("description") or {}).get(str(e)) or (ga.get("description") or {}).get(e)
        it(f"gold_labelled_epoch_{e}", bool(d) and d.get("labelled_share", 0) >= 0.8, f"labelled_share={d.get('labelled_share') if d else 0}")
    ec = J("results/phase5/entry/entry_checks.json")["checks"]
    it("validation_blocks_correct", ec["design_points_in_hashed_validation_blocks"]["ok"] and ec["validation_block_raster_matches_reimplementation"]["ok"], "entry_checks.json")
    it("training_exclusion_2km_correct", ec["training_eligible_cells_ge_2km_from_validation_blocks"]["ok"] and ec["design_points_ge_2km_from_training_eligible"]["ok"], "entry_checks.json")
    cv = J("results/phase5/cube_validation/validation_report_min.json") or {}
    it("district_cube_validated_for_registered_years_and_periods", cv.get("ok") and cv.get("complete_for_required"), f"missing {len(cv.get('missing_required', ['all']))} year/period products" if cv else "no validation of the confirmatory minimum")
    it("registered_feature_set_on_district_grid", config.path("data/features/cube/pune_G30.zarr").exists(), "district feature cube data/features/cube/pune_G30.zarr (B3 + 5-year window + terrain)")
    seeds = proto["seeds"]["values"]; it("seeds_equal_protocol", rec.get("seeds") == seeds, rec.get("seeds"))
    it("statistical_test_and_FDR_family_defined", bool(proto["tests"]["decision_rule"]) and proto["tests"]["multiplicity"]["method"] == "benjamini_hochberg" and bool(rec.get("family")), rec.get("family"))
    t1 = config.path("data/labels/training/phase5_T1/sampling_design/design.json").exists()
    add = config.path("experiments/registry4/addenda/P4-C1_at_v2_addendum_1.json").exists()
    it("tuning_split_rule_adopted", add, "PROPOSED only (addendum not approved)" if not add else "adopted")
    if eid == "P4-C1@v2":
        it("arms_operationally_defined (addendum approved)", add, "experiments/registry4/addenda/P4-C1_at_v2_addendum_1_PROPOSED.json awaits approval")
        ta = J("results/phase5/t1/t1_audit.json") or {}
        it("human_training_labels_T1_ingested", ta.get("ingest") == "PASS", (ta.get("ingest_error") or "no T1 audit")[:120] if ta.get("ingest") != "PASS" else "PASS (training-leakage rules)")
        it("district_silver_arm_A_built", config.path("data/labels/pune_G30_district_silver").exists(), "needs WorldCover/Esri 10 m purity district-wide (acquirable, not built)")
    else:
        c1 = P4.load("P4-C1@v2")
        it("selection_prerequisite_P4-C1@v2_completed", c1["status"] == "PASS", f"P4-C1@v2 is {c1['status']} (selection uses its TUNING-split results)")
    if eid == "P4-C6@v2":
        it("sentinel1_rtc_2020_on_district_grid", config.path("data/composites/pune_G30/2020/sentinel1").exists(), "S1 RTC district 2020 not built")
    if eid == "P4-C2@v2":
        c2a = config.path("experiments/registry4/addenda/P4-C2_at_v2_addendum_1.json").exists()
        it("cross_sensor_transform_fixed (decision D2)", c2a, "approved addendum fixing 'published coefficients' vs 'PIF-fitted on non-validation blocks'" if c2a else "decision D2 open: the record allows two transforms; choosing after gold results would be a forking path")
    ok = all(v["ok"] for v in items.values())
    return {"experiment_id": eid, "run_allowed": ok, "decision": "RUN" if ok else "DO NOT RUN", "failed": [k for k, v in items.items() if not v["ok"]], "items": items}

def assert_runnable(eid: str):
    c = checklist(eid)
    if not c["run_allowed"]: raise RuntimeError(f"{eid}: pre-run checklist failed ({len(c['failed'])} items): {c['failed']}")
    return c

if __name__ == "__main__":
    res = {"created_utc": utcnow(), "records": {e: checklist(e) for e in EPOCHS}}
    (OUT / "prerun_checklists.json").write_text(json.dumps(res, indent=1, default=str))
    for e, c in res["records"].items(): print(e, c["decision"], f"{len(c['failed'])} failed:", c["failed"])
