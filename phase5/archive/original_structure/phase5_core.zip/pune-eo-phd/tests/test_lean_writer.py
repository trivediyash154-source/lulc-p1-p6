"""lean_writer (strip-assembled district products) must reproduce engine.write_products. All arrays are SYNTHETIC TEST DATA — NOT RESEARCH DATA."""
import json, shutil, uuid
import numpy as np, pandas as pd, rasterio
from pune_eo import config
from pune_eo.grid import Grid
from pune_eo.compositing import engine as E, lean_writer as LW
from pune_eo.compositing.periods import Period

def synth(H=20, W=16, seed=0):
    rng = np.random.default_rng(seed); nb = 6
    n_obs = rng.integers(0, 6, (H, W)).astype(np.uint16); n_clear = np.minimum(n_obs, rng.integers(0, 6, (H, W))).astype(np.uint16)
    comp = rng.uniform(0.01, 0.5, (nb, H, W)).astype(np.float32); comp[:, n_clear == 0] = np.nan
    unc = rng.uniform(0.0, 0.02, (nb, H, W)).astype(np.float32); unc[:, n_clear < 3] = np.nan
    per = np.zeros((5, H, W), np.uint16); per[1] = n_clear // 2; per[3] = n_clear - per[1]
    doy = np.where(n_clear > 0, rng.uniform(10, 150, (H, W)), np.nan).astype(np.float32)
    return {"n_observed": n_obs, "n_clear": n_clear, "per_platform": per, "doy_median": doy, "composite": comp, "uncertainty": unc}

def test_lean_writer_equals_engine():
    tmp_path = config.path('data/raw/_pytest_lean', uuid.uuid4().hex[:8]); tmp_path.mkdir(parents=True)   # engine writes metadata paths relative to the repo
    try:
        _run(tmp_path)
    finally:
        shutil.rmtree(tmp_path, ignore_errors=True)

def _run(tmp_path):
    H, W = 20, 16; g = Grid("synthetic_G30", "EPSG:32643", 30.0, 300015.0, 2000015.0, W, H, 15.0); res = synth(H, W)
    inside = np.ones((H, W), bool); inside[:3, :4] = False
    metas = [{"item_id": "SYN_A", "platform": "landsat-5", "date": "1990-01-10", "doy": 10, "cloud_cover": 5.0, "tile_id": "x", "n_clear_px": 10},
             {"item_id": "SYN_B", "platform": "landsat-8", "date": "1990-02-10", "doy": 41, "cloud_cover": None, "tile_id": "y", "n_clear_px": 0}]
    P = Period(1990, "season", "dry", (1, 2, 3, 4, 5)); cut = pd.Timestamp("2026-10-01", tz="UTC")
    E.write_products("landsat", P, g, {k: v.copy() for k, v in res.items()}, inside, metas, tmp_path / "engine", cut, "local_pune_g30_v2", {"processing": {}})
    strips = []
    for i, (r0, r1) in enumerate([(0, 7), (7, 20)]):
        p = tmp_path / f"s{i}.npz"; np.savez(p, **{k: (v[:, r0:r1] if v.ndim == 3 else v[r0:r1]) for k, v in res.items()}); strips.append((r0, r1, p))
    LW.write_products_from_strips("landsat", P, g, strips, inside, metas, tmp_path / "lean", cut, "local_pune_g30_v2", {"processing": {}})
    for f in ("optical_composite", "uncertainty", "observation_count", "valid_mask", "qa"):
        with rasterio.open(tmp_path / "engine" / f"{f}.tif") as a, rasterio.open(tmp_path / "lean" / f"{f}.tif") as b:
            assert np.array_equal(a.read(), b.read()), f
            assert a.descriptions == b.descriptions and a.nodata == b.nodata and a.dtypes == b.dtypes and a.transform == b.transform, f
    ma, mb = (json.loads((tmp_path / d / "metadata.json").read_text()) for d in ("engine", "lean"))
    for k in ("district_pixels", "district_valid_fraction", "district_reliable_fraction_ge3", "single_obs_fraction", "n_clear_median", "n_clear_p10", "n_clear_p90", "sensor_contribution_clear_px", "n_items", "n_items_with_clear_px"):
        assert ma["statistics"][k] == mb["statistics"][k], k
    assert abs(ma["statistics"]["clear_pct_mean"] - mb["statistics"]["clear_pct_mean"]) < 1e-9
    for b in ma["statistics"]["band_medians"]:
        assert abs(ma["statistics"]["band_medians"][b] - mb["statistics"]["band_medians"][b]) <= 0.6e-4
    assert ma["sources"] == mb["sources"] and ma["sensors"] == mb["sensors"] and ma["temporal"] == mb["temporal"]
